package com.ativacao.app;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.common.PlaybackException;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.PlayerView;
import androidx.media3.ui.AspectRatioFrameLayout;

import java.util.ArrayList;
import java.util.List;

/** TV: lista/categorias à esquerda + preview à direita. Primeiro OK seleciona; segundo OK abre tela cheia. */
public class LiveTvActivity extends android.app.Activity {
    private final List<ApiClient.Item> allChannels = new ArrayList<>();
    private LinearLayout rows;
    private PlayerView preview;
    private FrameLayout playerCard;
    private FrameLayout shell, fullscreenLayer;
    private LinearLayout content, rightColumn;
    private LinearLayout.LayoutParams playerNormalLp;
    private boolean fullscreen = false;
    private ExoPlayer player;
    private TextView title, epgNow, epgNext, hint;
    private ProgressBar loading;
    private ApiClient.Item current;
    private View currentRow;
    private long armedChannelId = -1L;
    private int channelLoadToken = 0;
    private String listMode = "all";
    private String searchQuery = "";
    private boolean adultOnly = false;
    private TextView tabAll, tabFav, tabRecent;
    private ProgressBar epgProgress;
    private TextView epgNowTitle, epgNowTime, epgNextTitle, epgNextTime;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        adultOnly=getIntent().getBooleanExtra("adult_only",false);
        FreeFootballSource.preload();
        immersive();
        setContentView(build());
        loadChannels();
    }

    private void warmMediaCatalog(){
        warmMediaType("movie",48);
        warmMediaType("series",30);
    }

    private void warmMediaType(String type,int limit){
        ApiClient.catalog(type,1,limit,"","","",new ApiClient.Callback<ApiClient.CatalogPage>(){
            @Override public void ok(ApiClient.CatalogPage p){
                if(p==null)return;
                int max=Math.min(p.items.size(),24);
                for(int n=0;n<max;n++){
                    ApiClient.Item i=p.items.get(n);
                    if(i==null)continue;
            if(isAdultChannelName(i.name))continue;
                    if(!i.tmdbLoaded){
                        ApiClient.tmdbEnrich(i,new ApiClient.Callback<ApiClient.Item>(){
                            @Override public void ok(ApiClient.Item x){
                                ImageLoader.preload(LiveTvActivity.this,cleanWarm(x.logo,x.backdrop));
                            }
                            @Override public void error(String m){ ImageLoader.preload(LiveTvActivity.this,cleanWarm(i.logo,i.backdrop)); }
                        });
                    }else ImageLoader.preload(LiveTvActivity.this,cleanWarm(i.logo,i.backdrop));
                }
            }
            @Override public void error(String m){}
        });
    }

    private String cleanWarm(String a,String b){
        String x=a==null?"":a.trim();
        if(!x.isEmpty()&&!"null".equalsIgnoreCase(x))return x;
        x=b==null?"":b.trim();
        return "null".equalsIgnoreCase(x)?"":x;
    }

    private View build() {
        shell=new FrameLayout(this);

        LinearLayout root=Ui.column(this);
        root.setBackground(Ui.diagonalGradient(0xFF061109,0xFF010302,0,this));
        shell.addView(root,new FrameLayout.LayoutParams(-1,-1));

        fullscreenLayer=new FrameLayout(this);
        fullscreenLayer.setBackgroundColor(Color.BLACK);
        fullscreenLayer.setVisibility(View.GONE);
        shell.addView(fullscreenLayer,new FrameLayout.LayoutParams(-1,-1));

        root.addView(YellowNav.bar(this,"TV"),new LinearLayout.LayoutParams(-1,Ui.dp(this,64)));

        LinearLayout main=new LinearLayout(this);
        main.setOrientation(LinearLayout.HORIZONTAL);
        main.setPadding(Ui.dp(this,18),Ui.dp(this,8),Ui.dp(this,18),Ui.dp(this,8));

        // LEFT
        LinearLayout left=Ui.column(this);
        left.setPadding(Ui.dp(this,8),0,Ui.dp(this,10),0);
        left.setBackground(Ui.round(0x66071109,10,this));

        TextView section=Ui.text(this,"TV AO VIVO  ⌁",24,Color.WHITE,true);
        left.addView(section,new LinearLayout.LayoutParams(-1,Ui.dp(this,38)));

        EditText search=new EditText(this);
        search.setSingleLine(true);
        search.setHint("Pesquisar canal...");
        search.setHintTextColor(0xFF8E9890);
        search.setTextColor(Color.WHITE);
        search.setTextSize(11);
        search.setPadding(Ui.dp(this,14),0,Ui.dp(this,14),0);
        search.setBackground(Ui.stroke(0x85090F0A,0xFF26372A,12,this));
        left.addView(search,new LinearLayout.LayoutParams(-1,Ui.dp(this,40)));

        LinearLayout filters=new LinearLayout(this);
        filters.setGravity(Gravity.CENTER_VERTICAL);
        tabAll=filterButton("TODOS",true);
        tabFav=filterButton("FAVORITOS",false);
        tabRecent=filterButton("RECENTES",false);
        filters.addView(tabAll,new LinearLayout.LayoutParams(0,Ui.dp(this,36),1));
        filters.addView(tabFav,new LinearLayout.LayoutParams(0,Ui.dp(this,36),1));
        filters.addView(tabRecent,new LinearLayout.LayoutParams(0,Ui.dp(this,36),1));
        TextView refresh=filterButton("↻",false);
        filters.addView(refresh,new LinearLayout.LayoutParams(Ui.dp(this,42),Ui.dp(this,36)));
        refresh.setOnClickListener(v->{CatalogPreloader.start(LiveTvActivity.this,true,()->runOnUiThread(()->{allChannels.clear();loadChannels();}));});
        LinearLayout.LayoutParams flp=new LinearLayout.LayoutParams(-1,Ui.dp(this,42));
        flp.topMargin=Ui.dp(this,7);flp.bottomMargin=Ui.dp(this,4);
        left.addView(filters,flp);

        tabAll.setOnClickListener(v->{listMode="all";updateFilterButtons();renderRowsFiltered(searchQuery);});
        tabFav.setOnClickListener(v->{listMode="fav";updateFilterButtons();renderRowsFiltered(searchQuery);});
        tabRecent.setOnClickListener(v->{listMode="recent";updateFilterButtons();renderRowsFiltered(searchQuery);});

        ScrollView sc=new ScrollView(this);
        sc.setVerticalScrollBarEnabled(false);
        sc.setFillViewport(true);
        rows=Ui.column(this);
        sc.addView(rows,new ScrollView.LayoutParams(-1,-2));
        left.addView(sc,new LinearLayout.LayoutParams(-1,0,1));

        search.addTextChangedListener(new android.text.TextWatcher(){
            public void beforeTextChanged(CharSequence cs,int st,int c,int a){}
            public void onTextChanged(CharSequence cs,int st,int b,int c){
                searchQuery=cs==null?"":cs.toString();
                renderRowsFiltered(searchQuery);
            }
            public void afterTextChanged(android.text.Editable e){}
        });

        LinearLayout.LayoutParams llp=new LinearLayout.LayoutParams(Ui.dp(this,365),-1);
        llp.rightMargin=Ui.dp(this,16);
        main.addView(left,llp);

        // RIGHT / PLAYER
        rightColumn=Ui.column(this);
        playerCard=new FrameLayout(this);
        playerCard.setFocusable(true);playerCard.setClickable(true);
        playerCard.setBackground(Ui.round(Color.BLACK,8,this));

        preview=new PlayerView(this);
        preview.setUseController(false);preview.setKeepScreenOn(true);preview.setFocusable(false);
        preview.setBackgroundColor(Color.BLACK);
        preview.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        playerCard.addView(preview,new FrameLayout.LayoutParams(-1,-1));

        loading=new ProgressBar(this);
        playerCard.addView(loading,new FrameLayout.LayoutParams(Ui.dp(this,42),Ui.dp(this,42),Gravity.CENTER));

        LinearLayout overlay=Ui.column(this);
        overlay.setPadding(Ui.dp(this,20),Ui.dp(this,7),Ui.dp(this,20),Ui.dp(this,7));
        overlay.setBackground(Ui.verticalGradient(0x05000000,0xED07100A,0,this));

        title=Ui.text(this,"Canal",18,Color.WHITE,true);
        overlay.addView(title,new LinearLayout.LayoutParams(-1,Ui.dp(this,30)));

        LinearLayout epgRow=new LinearLayout(this);
        epgRow.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout nowBox=Ui.column(this);
        epgNow=Ui.text(this,"AGORA",9,0xFFD8DDD9,true);
        nowBox.addView(epgNow,new LinearLayout.LayoutParams(-1,Ui.dp(this,20)));
        epgNowTitle=Ui.text(this,"Sem informação",10,Color.WHITE,false);
        epgNowTitle.setMaxLines(1);
        nowBox.addView(epgNowTitle,new LinearLayout.LayoutParams(-1,Ui.dp(this,22)));
        epgNowTime=Ui.text(this,"",8,0xFFC8D0CA,false);
        nowBox.addView(epgNowTime,new LinearLayout.LayoutParams(-1,Ui.dp(this,18)));
        epgRow.addView(nowBox,new LinearLayout.LayoutParams(0,Ui.dp(this,60),1));

        View divider=new View(this);divider.setBackgroundColor(0xFF314238);
        LinearLayout.LayoutParams dlp=new LinearLayout.LayoutParams(Ui.dp(this,1),Ui.dp(this,48));
        dlp.leftMargin=Ui.dp(this,12);dlp.rightMargin=Ui.dp(this,18);
        epgRow.addView(divider,dlp);

        LinearLayout nextBox=Ui.column(this);
        epgNext=Ui.text(this,"A SEGUIR",9,0xFFD8DDD9,true);
        nextBox.addView(epgNext,new LinearLayout.LayoutParams(-1,Ui.dp(this,20)));
        epgNextTitle=Ui.text(this,"—",10,Color.WHITE,false);
        epgNextTitle.setMaxLines(1);
        nextBox.addView(epgNextTitle,new LinearLayout.LayoutParams(-1,Ui.dp(this,22)));
        epgNextTime=Ui.text(this,"",8,0xFFC8D0CA,false);
        nextBox.addView(epgNextTime,new LinearLayout.LayoutParams(-1,Ui.dp(this,18)));
        epgRow.addView(nextBox,new LinearLayout.LayoutParams(0,Ui.dp(this,60),1));

        overlay.addView(epgRow,new LinearLayout.LayoutParams(-1,Ui.dp(this,62)));

        LinearLayout progressRow=new LinearLayout(this);progressRow.setGravity(Gravity.CENTER_VERTICAL);
        epgProgress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        epgProgress.setMax(100);epgProgress.setProgress(42);
        epgProgress.setProgressTintList(ColorStateList.valueOf(Ui.GREEN));
        epgProgress.setProgressBackgroundTintList(ColorStateList.valueOf(0xFF28342C));
        progressRow.addView(epgProgress,new LinearLayout.LayoutParams(0,Ui.dp(this,4),1));
        TextView liveBadge=Ui.text(this,"●  AO VIVO",8,Color.WHITE,true);
        liveBadge.setTextColor(0xFFFF5252);
        LinearLayout.LayoutParams lbp=new LinearLayout.LayoutParams(Ui.dp(this,92),Ui.dp(this,22));
        lbp.leftMargin=Ui.dp(this,14);progressRow.addView(liveBadge,lbp);
        overlay.addView(progressRow,new LinearLayout.LayoutParams(-1,Ui.dp(this,22)));

        hint=Ui.text(this,"OK seleciona • OK novamente abre tela cheia",7,0xFF9BA69E,false);
        hint.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        overlay.addView(hint,new LinearLayout.LayoutParams(-1,Ui.dp(this,18)));

        FrameLayout.LayoutParams olp=new FrameLayout.LayoutParams(-1,Ui.dp(this,142),Gravity.BOTTOM);
        playerCard.addView(overlay,olp);

        playerCard.setOnClickListener(v->openFullscreen());
        playerNormalLp=new LinearLayout.LayoutParams(-1,-1);
        rightColumn.addView(playerCard,playerNormalLp);
        main.addView(rightColumn,new LinearLayout.LayoutParams(0,-1,1));

        root.addView(main,new LinearLayout.LayoutParams(-1,0,1));

        // Bottom category strip: same composition as target mockup.
        // Navegação inferior removida: o menu superior já concentra as categorias.

        return shell;
    }

    private TextView filterButton(String text,boolean selected){
        TextView t=Ui.text(this,text,9,selected?Color.BLACK:0xFFDDE5DF,true);
        t.setGravity(Gravity.CENTER);t.setFocusable(true);t.setClickable(true);
        t.setBackground(selected?Ui.gradient(Ui.GREEN,Ui.GREEN_2,20,this):Ui.round(Color.TRANSPARENT,20,this));
        return t;
    }

    private void updateFilterButtons(){
        TextView[] bs={tabAll,tabFav,tabRecent};
        String[] ms={"all","fav","recent"};
        for(int i=0;i<bs.length;i++){
            boolean on=ms[i].equals(listMode);
            bs[i].setTextColor(on?Color.BLACK:0xFFDDE5DF);
            bs[i].setBackground(on?Ui.gradient(Ui.GREEN,Ui.GREEN_2,20,this):Ui.round(Color.TRANSPARENT,20,this));
        }
    }

    private void addCategoryTile(LinearLayout row,String label,String type,String smart,Runnable click){
        FrameLayout card=new FrameLayout(this);
        card.setFocusable(true);card.setClickable(true);card.setClipToOutline(true);
        Ui.focus(card,this,Ui.round(0xFF102018,9,this),Ui.stroke(0xFF102018,Ui.GREEN,9,this));

        ImageView img=new ImageView(this);img.setScaleType(ImageView.ScaleType.CENTER_CROP);img.setBackgroundColor(0xFF122018);
        card.addView(img,new FrameLayout.LayoutParams(-1,-1));

        View shade=new View(this);shade.setBackground(Ui.verticalGradient(0x22000000,0xE8000000,0,this));
        card.addView(shade,new FrameLayout.LayoutParams(-1,-1));

        TextView t=Ui.text(this,label,10,Color.WHITE,true);t.setGravity(Gravity.CENTER);
        card.addView(t,new FrameLayout.LayoutParams(-1,Ui.dp(this,34),Gravity.BOTTOM));
        card.setOnClickListener(v->click.run());

        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,1);
        lp.rightMargin=Ui.dp(this,8);row.addView(card,lp);

        ApiClient.catalog(type,1,1,"","",smart,new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){
                if(p!=null&&p.items!=null&&!p.items.isEmpty()){
                    ApiClient.Item it=p.items.get(0);
                    runOnUiThread(()->ImageLoader.into(LiveTvActivity.this,img,clean(it.backdrop,it.logo)));
                }
            }
            public void error(String m){}
        });
    }

    private void openCatalog(String type,String title,String smart){
        Intent i=new Intent(this,CatalogActivity.class);i.putExtra("type",type);i.putExtra("title",title);i.putExtra("smart",smart);startActivity(i);
    }
    private void openDiscover(String smart,String title){
        Intent i=new Intent(this,DiscoverActivity.class);i.putExtra("smart",smart);i.putExtra("title",title);startActivity(i);
    }

    private int phonePad(){return Ui.phone(this)?12:24;}
    private int phoneLeftWidth(){return Ui.phone(this)?315:380;}

    private void addNav(LinearLayout row,String label,boolean selected,Runnable action){
        TextView v=Ui.nav(this,label,selected); if(action!=null)v.setOnClickListener(x->action.run());
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1); row.addView(v,p);
    }

    private void loadChannels(){
        int token=++channelLoadToken;
        loadChannelPage(1, new ArrayList<>(), token);
    }

    private void loadChannelPage(int page, List<ApiClient.Item> acc, int token){
        if(token!=channelLoadToken || isFinishing() || isDestroyed()) return;
        ApiClient.catalog("live",page,72,"","","",new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){
                if(token!=channelLoadToken) return;
                int before=acc.size();
                if(p!=null && p.items!=null){
                    java.util.HashSet<Long> ids=new java.util.HashSet<>();
                    for(ApiClient.Item old:acc) ids.add(old.id);
                    for(ApiClient.Item item:p.items) if(item!=null && !ids.contains(item.id)){acc.add(item);ids.add(item.id);}
                }
                // Mostra a primeira página imediatamente. As demais entram em segundo plano,
                // então a tela não fica vazia esperando o catálogo inteiro.
                if(page==1 || page%3==0){
                    java.util.ArrayList<ApiClient.Item> snapshot=new java.util.ArrayList<>(acc);
                    runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())renderAll(snapshot);});
                }
                int pages=p==null?1:Math.max(1,p.pages);
                boolean apiHasNext=page<pages;
                boolean fullPage=p!=null && p.items!=null && p.items.size()>=72 && acc.size()>before;
                if(page<30 && (apiHasNext || fullPage)){ loadChannelPage(page+1,acc,token); return; }
                java.util.ArrayList<ApiClient.Item> snapshot=new java.util.ArrayList<>(acc);
                runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())renderAll(snapshot);});
            }
            public void error(String m){
                if(!acc.isEmpty()){java.util.ArrayList<ApiClient.Item> snapshot=new java.util.ArrayList<>(acc);runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())renderAll(snapshot);});return;}
                runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())Toast.makeText(LiveTvActivity.this,"Não foi possível carregar os canais",Toast.LENGTH_LONG).show();});
            }
        });
    }

    private void renderAll(List<ApiClient.Item> list){
        allChannels.clear(); if(list!=null)allChannels.addAll(list);
        renderRows();
    }


    private void renderRows(){ renderRowsFiltered(""); }

    private void renderRowsFiltered(String query){
        if(rows==null)return;
        rows.removeAllViews();
        String q=query==null?"":query.trim().toLowerCase(java.util.Locale.ROOT);

        List<ApiClient.Item> source=new ArrayList<>();
        if("fav".equals(listMode)){
            for(ApiClient.Item i:LocalStore.favorites(this))if(i!=null&&"live".equals(i.type))source.add(i);
        }else if("recent".equals(listMode)){
            for(ApiClient.Item i:LocalStore.history(this))if(i!=null&&"live".equals(i.type))source.add(i);
            ApiClient.Item last=LocalStore.lastLive(this);
            if(last!=null){
                boolean exists=false;for(ApiClient.Item x:source)if(x.id==last.id){exists=true;break;}
                if(!exists)source.add(0,last);
            }
        }else source.addAll(allChannels);

        List<ApiClient.Item> visible=new ArrayList<>();
        for(ApiClient.Item i:source){
            if(i==null)continue;
            boolean adult=isAdultChannelName(i.name)||isAdultChannelName(i.group);
            if(adultOnly && !adult)continue;
            if(!adultOnly && adult)continue;
            String nm=clean(i.name,"Canal").toLowerCase(java.util.Locale.ROOT);
            if(q.isEmpty()||nm.contains(q))visible.add(i);
        }

        if(visible.isEmpty()){
            TextView empty=Ui.text(this,"Nenhum canal encontrado",10,Ui.MUTED,false);
            empty.setGravity(Gravity.CENTER);
            rows.addView(empty,new LinearLayout.LayoutParams(-1,Ui.dp(this,90)));
            return;
        }

        ApiClient.Item last=LocalStore.lastLive(this);
        ApiClient.Item initial=null;
        if(current!=null)for(ApiClient.Item x:visible)if(x.id==current.id){initial=x;break;}
        if(initial==null&&last!=null)for(ApiClient.Item x:visible)if(x.id==last.id){initial=x;break;}
        if(initial==null)initial=visible.get(0);

        View focus=null;
        int n=1;
        for(ApiClient.Item i:visible){
            LinearLayout r=new LinearLayout(this);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(Ui.dp(this,4),Ui.dp(this,3),Ui.dp(this,8),Ui.dp(this,3));
            r.setFocusable(true);r.setClickable(true);

            TextView num=Ui.text(this,String.valueOf(n++),11,Ui.GREEN,true);
            num.setGravity(Gravity.CENTER);
            r.addView(num,new LinearLayout.LayoutParams(Ui.dp(this,28),-1));

            ImageView logo=new ImageView(this);
            logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            logo.setBackground(Ui.round(0x20FFFFFF,7,this));
            ImageLoader.into(this,logo,i.logo);
            LinearLayout.LayoutParams lip=new LinearLayout.LayoutParams(Ui.dp(this,42),Ui.dp(this,42));
            lip.rightMargin=Ui.dp(this,10);
            r.addView(logo,lip);

            LinearLayout names=Ui.column(this);
            TextView nm=Ui.text(this,clean(i.name,"Canal"),12,Color.WHITE,true);
            nm.setMaxLines(1);
            names.addView(nm,new LinearLayout.LayoutParams(-1,0,1));

            if(i.group!=null&&!i.group.trim().isEmpty()){
                TextView grp=Ui.text(this,i.group,8,0xFF8F9991,false);
                grp.setMaxLines(1);
                names.addView(grp,new LinearLayout.LayoutParams(-1,Ui.dp(this,18)));
            }
            r.addView(names,new LinearLayout.LayoutParams(0,-1,1));

            TextView fav=Ui.text(this,LocalStore.isFavorite(this,i.id)?"★":"☆",16,
                    LocalStore.isFavorite(this,i.id)?Ui.GREEN:0xFF6F7771,true);
            fav.setGravity(Gravity.CENTER);fav.setFocusable(true);fav.setClickable(true);
            fav.setOnClickListener(v->{
                LocalStore.toggleFavorite(this,i);
                boolean yes=LocalStore.isFavorite(this,i.id);
                fav.setText(yes?"★":"☆");fav.setTextColor(yes?Ui.GREEN:0xFF6F7771);
            });
            r.addView(fav,new LinearLayout.LayoutParams(Ui.dp(this,38),-1));

            android.graphics.drawable.Drawable normal=Ui.round(0x18000000,7,this);
            android.graphics.drawable.Drawable focused=Ui.stroke(0xFF102016,Ui.GREEN,7,this);
            r.setBackground(normal);

            r.setOnFocusChangeListener((v,has)->{
                v.animate().scaleX(has?1.018f:1f).scaleY(has?1.018f:1f).setDuration(90).start();
                v.setBackground(has?focused:normal);
                if(has){
                    if(current==null||current.id!=i.id){armedChannelId=-1L;previewChannel(i,v);}
                    else currentRow=v;
                }
            });

            r.setOnClickListener(v->{
                if(current==null||current.id!=i.id){
                    armedChannelId=i.id;
                    previewChannel(i,v);
                    currentRow=v;
                    hint.setText("OK novamente: tela cheia");
                    return;
                }
                if(armedChannelId==i.id){openFullscreen();return;}
                armedChannelId=i.id;currentRow=v;hint.setText("OK novamente: tela cheia");
            });

            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,Ui.dp(this,52));
            rp.bottomMargin=Ui.dp(this,4);
            rows.addView(r,rp);
            if(i.id==initial.id)focus=r;
        }

        previewChannel(initial,focus);
        if(focus!=null)focus.requestFocus();
    }

    private void previewChannel(ApiClient.Item i, View row){
        if(i==null)return;
        if(current!=null && current.id==i.id){currentRow=row;return;}
        current=i; currentRow=row; LocalStore.saveLastLive(this,i); LocalStore.addHistory(this,i);
        title.setText(clean(i.name,"Canal"));
        epgNow.setText("AGORA"); epgNext.setText("A SEGUIR");
        epgNowTitle.setText("Carregando programação...");epgNextTitle.setText("—");
        epgNowTime.setText("");epgNextTime.setText("");epgProgress.setProgress(35);
        hint.setText("OK seleciona • OK novamente abre tela cheia");
        loadEpg(i.id); startPreview(i.id);
    }

    private void startPreview(long id){
        if(isFinishing() || isDestroyed()) return;
        loading.setVisibility(View.VISIBLE);
        if(player!=null){try{preview.setPlayer(null);player.release();}catch(Exception ignored){} player=null;}
        try{
            String url=ApiClient.streamUrl(id);
            if(url==null || url.trim().isEmpty()) throw new IllegalArgumentException("URL do canal vazia");
            DefaultHttpDataSource.Factory http=new DefaultHttpDataSource.Factory().setUserAgent("DubaiPlayTV/4.0.22 Android").setConnectTimeoutMs(8000).setReadTimeoutMs(30000).setAllowCrossProtocolRedirects(true);
            player=new ExoPlayer.Builder(this).setMediaSourceFactory(new DefaultMediaSourceFactory(this).setDataSourceFactory(http)).build();
            preview.setPlayer(player);
            player.addListener(new Player.Listener(){
                @Override public void onPlaybackStateChanged(int state){if(state==Player.STATE_READY && loading!=null)loading.setVisibility(View.GONE);}
                @Override public void onPlayerError(PlaybackException error){
                    if(loading!=null)loading.setVisibility(View.GONE);
                    if(epgNowTitle!=null)epgNowTitle.setText("Sinal indisponível");
                }
            });
            player.setMediaItem(MediaItem.fromUri(url)); player.prepare(); player.play();
        }catch(Throwable e){
            loading.setVisibility(View.GONE);
            epgNowTitle.setText("Sinal indisponível");
        }
    }

    private void loadEpg(long id){
        ApiClient.epg(id,new ApiClient.Callback<ApiClient.EpgInfo>(){
            public void ok(ApiClient.EpgInfo e){runOnUiThread(()->{
                if(current==null||current.id!=id)return;
                epgNow.setText("AGORA");epgNext.setText("A SEGUIR");
                epgNowTitle.setText(clean(e.nowTitle,"Sem informação"));
                epgNextTitle.setText(clean(e.nextTitle,"—"));
                epgNowTime.setText(timeRange(e.nowStart,e.nowStop));
                epgNextTime.setText(clean(e.nextStart,""));
                epgProgress.setProgress(epgPercent(e.nowStart,e.nowStop));
            });}
            public void error(String m){runOnUiThread(()->{
                if(current!=null&&current.id==id){
                    epgNowTitle.setText("Sem informação");epgNextTitle.setText("—");
                    epgNowTime.setText("");epgNextTime.setText("");epgProgress.setProgress(40);
                }
            });}
        });
    }

    private String timeRange(String a,String b){
        String x=clean(a,""),y=clean(b,"");
        if(x.isEmpty()&&y.isEmpty())return "";
        return x+(y.isEmpty()?"":" - "+y);
    }

    private int epgPercent(String a,String b){
        try{
            java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("HH:mm",java.util.Locale.getDefault());
            java.util.Date s=f.parse(a),e=f.parse(b),n=f.parse(f.format(new java.util.Date()));
            if(s==null||e==null||n==null)return 42;
            long total=e.getTime()-s.getTime(),done=n.getTime()-s.getTime();
            if(total<=0)return 42;
            return Math.max(3,Math.min(97,(int)(done*100/total)));
        }catch(Exception ex){return 42;}
    }

    private void openFullscreen(){
        if(current==null || fullscreen)return;
        fullscreen=true;
        if(playerCard.getParent() instanceof android.view.ViewGroup){
            ((android.view.ViewGroup)playerCard.getParent()).removeView(playerCard);
        }
        fullscreenLayer.removeAllViews();
        preview.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FILL);
        fullscreenLayer.addView(playerCard,new FrameLayout.LayoutParams(-1,-1));
        fullscreenLayer.setVisibility(View.VISIBLE);
        fullscreenLayer.bringToFront();
        hint.setText("VOLTAR: lista de canais");
        playerCard.requestFocus();
        immersive();
    }

    private void closeFullscreen(){
        if(!fullscreen)return;
        fullscreen=false;
        if(playerCard.getParent() instanceof android.view.ViewGroup){
            ((android.view.ViewGroup)playerCard.getParent()).removeView(playerCard);
        }
        fullscreenLayer.setVisibility(View.GONE);
        preview.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        if(rightColumn!=null) rightColumn.addView(playerCard,0,playerNormalLp);
        hint.setText("1º OK seleciona • 2º OK abre tela cheia");
        if(currentRow!=null) currentRow.requestFocus();
        immersive();
    }

    private void openMain(){Intent in=new Intent(this,MainActivity.class);in.putExtra("show_highlights",true);startActivity(in);finish();}
    private void openCatalog(String type,String name){Intent in=new Intent(this,CatalogActivity.class);in.putExtra("type",type);in.putExtra("title",name);startActivity(in);}

    @Override public void onBackPressed(){if(fullscreen){closeFullscreen();return;}finish();}
    @Override protected void onResume(){super.onResume();immersive();try{if(player!=null)player.play();}catch(Throwable ignored){}}
    @Override protected void onPause(){try{if(player!=null)player.pause();}catch(Throwable ignored){}super.onPause();}
    @Override protected void onDestroy(){super.onDestroy();if(player!=null){try{player.release();}catch(Exception ignored){}}}
    private void immersive(){WindowCompat.setDecorFitsSystemWindows(getWindow(),false);WindowInsetsControllerCompat c=WindowCompat.getInsetsController(getWindow(),getWindow().getDecorView());c.hide(WindowInsetsCompat.Type.systemBars());c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);}
    private String clean(String v,String f){if(v==null)return f;String s=v.trim();return s.isEmpty()||"null".equalsIgnoreCase(s)?f:s;}

    private boolean isAdultChannelName(String name){
        if(name==null)return false;
        String x=name.toLowerCase(java.util.Locale.ROOT);
        String[] keys={"adulto","adultos","adult","18+","hot","sexy","privê","prive","erótico","erotico","porn","xxx"};
        for(String k:keys)if(x.contains(k))return true;
        return false;
    }
}
