package com.ativacao.app;

import android.app.Activity;
import android.content.Context;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Prepara o catálogo uma única vez por cliente/token.
 * Depois usa o cache persistente até o usuário tocar em ATUALIZAR.
 */
final class CatalogPreloader {
    private static final String PREF="dubai_content_preload";
    private static volatile boolean running=false;
    private static volatile boolean ready=false;

    static void init(Context c){
        if(c==null)return;
        String k=key(Session.token(c));
        ready=c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getBoolean(k,false);
    }
    static boolean isReady(){ return ready; }
    static boolean isPrepared(Context c){
        if(c==null)return ready;
        return c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getBoolean(key(Session.token(c)),false);
    }
    private static String key(String token){ return "ready_"+Integer.toHexString((token==null?"":token).hashCode()); }
    private static void markReady(Context c,boolean value){
        if(c==null)return;
        c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putBoolean(key(Session.token(c)),value).apply();
        ready=value;
    }

    static void start(Activity a, boolean force, Runnable done){
        if(a==null){ if(done!=null)done.run(); return; }
        if(!force && isPrepared(a)){ ready=true; if(done!=null)done.run(); return; }
        if(running){ return; }
        running=true;
        if(force){ ApiClient.clearCatalogCache(); markReady(a,false); }

        // O que precisa estar pronto antes de abrir a interface pela primeira vez:
        // TV, Filmes, Séries, HOT e listas de categorias.
        final List<String[]> jobs=Arrays.asList(
            new String[]{"live",""},
            new String[]{"movie",""},
            new String[]{"series",""},
            new String[]{"live","adult"},
            new String[]{"movie","adult"},
            new String[]{"series","adult"}
        );
        AtomicInteger pending=new AtomicInteger(jobs.size()+3);
        for(String[] job:jobs){
            String type=job[0], smart=job[1];
            int limit="live".equals(type)?72:48;
            ApiClient.catalog(type,1,limit,"","",smart,new ApiClient.Callback<ApiClient.CatalogPage>(){
                public void ok(ApiClient.CatalogPage p){ warmImagesFast(a,p); finishOne(pending,a,done); }
                public void error(String m){ finishOne(pending,a,done); }
            });
        }
        ApiClient.categories("movie",new ApiClient.Callback<List<String>>(){ public void ok(List<String>x){finishOne(pending,a,done);} public void error(String m){finishOne(pending,a,done);} });
        ApiClient.categories("series",new ApiClient.Callback<List<String>>(){ public void ok(List<String>x){finishOne(pending,a,done);} public void error(String m){finishOne(pending,a,done);} });
        ApiClient.hotCategories(new ApiClient.Callback<List<ApiClient.HotCategory>>(){ public void ok(List<ApiClient.HotCategory>x){finishOne(pending,a,done);} public void error(String m){finishOne(pending,a,done);} });
    }

    private static void finishOne(AtomicInteger pending,Activity a,Runnable done){
        if(pending.decrementAndGet()!=0)return;
        running=false; markReady(a,true);
        if(done!=null)done.run();
        backgroundWarm(a);
    }

    private static void backgroundWarm(Activity a){
        String[][] jobs={{"movie","kids"},{"series","kids"},{"movie","anime"},{"series","anime"}};
        for(String[] j:jobs){
            ApiClient.catalog(j[0],1,36,"","",j[1],new ApiClient.Callback<ApiClient.CatalogPage>(){
                public void ok(ApiClient.CatalogPage p){ warmImagesFast(a,p); }
                public void error(String m){}
            });
        }
    }

    private static void warmImagesFast(Activity a,ApiClient.CatalogPage p){
        if(p==null)return;
        int max=Math.min(p.items.size(),18);
        for(int n=0;n<max;n++){
            ApiClient.Item i=p.items.get(n); if(i==null)continue;
            ImageLoader.preload(a,clean(i.logo,i.backdrop));
        }
    }
    private static String clean(String a,String b){ String x=a==null?"":a.trim(); return x.isEmpty()?(b==null?"":b.trim()):x; }
}
