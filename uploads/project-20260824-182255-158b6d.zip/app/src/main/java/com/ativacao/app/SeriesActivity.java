package com.ativacao.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class SeriesActivity extends Activity {
    private final List<ApiClient.Item> episodes = new ArrayList<>();
    private ApiClient.SeriesData data;
    private LinearLayout seasonRow;
    private GridView grid;
    private EpisodeAdapter adapter;
    private TextView status, title, synopsis;
    private ImageView backdrop;
    private String seriesTitle;
    private boolean phone;
    private boolean portrait;

    @Override public void onCreate(Bundle b){
        super.onCreate(b); immersive(); phone=Ui.phone(this); portrait=Ui.portrait(this);
        seriesTitle=getIntent().getStringExtra("title");
        if(seriesTitle==null||seriesTitle.trim().isEmpty()) seriesTitle=getIntent().getStringExtra("name");
        if(seriesTitle==null) seriesTitle="Série";
        setContentView(build()); load();
    }

    private View build(){
        LinearLayout root=Ui.column(this); root.setBackgroundColor(Ui.BG);
        LinearLayout content=Ui.column(this); content.setPadding(Ui.dp(this,phone?14:24),Ui.dp(this,12),Ui.dp(this,phone?14:24),Ui.dp(this,12));

        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView back=Ui.button(this,"‹  VOLTAR"); back.setOnClickListener(v->finish()); top.addView(back,new LinearLayout.LayoutParams(Ui.dp(this,phone?120:145),Ui.dp(this,44)));
        title=Ui.text(this,seriesTitle,phone?20:25,Ui.TEXT,true); title.setMaxLines(1); LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,Ui.dp(this,44),1); tp.leftMargin=Ui.dp(this,12); top.addView(title,tp);
        content.addView(top,new LinearLayout.LayoutParams(-1,Ui.dp(this,48)));

        FrameLayout hero=new FrameLayout(this); hero.setBackground(Ui.stroke(Ui.PANEL,Ui.GREEN,10,this)); hero.setClipToOutline(true);
        backdrop=new ImageView(this); backdrop.setScaleType(ImageView.ScaleType.CENTER_CROP); backdrop.setAlpha(.42f); backdrop.setBackgroundColor(Ui.PANEL_2); hero.addView(backdrop,new FrameLayout.LayoutParams(-1,-1));
        View shade=new View(this); shade.setBackgroundColor(0x77000000); hero.addView(shade,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout info=Ui.column(this); info.setPadding(Ui.dp(this,20),Ui.dp(this,14),Ui.dp(this,20),Ui.dp(this,12));
        TextView badge=Ui.text(this,"SÉRIE • DUBAI PLAY",10,Ui.GREEN,true); info.addView(badge,new LinearLayout.LayoutParams(-1,Ui.dp(this,22)));
        synopsis=Ui.text(this,"Carregando temporadas e episódios...",phone?11:13,Color.rgb(220,225,236),false); synopsis.setMaxLines(3); info.addView(synopsis,new LinearLayout.LayoutParams(-1,0,1));
        hero.addView(info,new FrameLayout.LayoutParams(-1,-1)); content.addView(hero,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?100:125)));

        status=Ui.text(this,"Carregando...",11,Ui.MUTED,false); LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,Ui.dp(this,30)); sp.topMargin=Ui.dp(this,6); content.addView(status,sp);

        HorizontalScrollView seasonScroll=new HorizontalScrollView(this); seasonScroll.setHorizontalScrollBarEnabled(false);
        seasonRow=new LinearLayout(this); seasonRow.setGravity(Gravity.CENTER_VERTICAL); seasonScroll.addView(seasonRow);
        content.addView(seasonScroll,new LinearLayout.LayoutParams(-1,Ui.dp(this,48)));

        grid=new GridView(this); int sw=Ui.sw(this); int cols=phone?4:(sw<1000?5:7); grid.setNumColumns(cols); grid.setHorizontalSpacing(Ui.dp(this,9)); grid.setVerticalSpacing(Ui.dp(this,9)); grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH); grid.setSelector(android.R.color.transparent); grid.setPadding(0,Ui.dp(this,4),0,Ui.dp(this,8));
        adapter=new EpisodeAdapter(); grid.setAdapter(adapter); content.addView(grid,new LinearLayout.LayoutParams(-1,0,1));

        FrameLayout centered=Ui.centered(this,content,1260); root.addView(centered,new LinearLayout.LayoutParams(-1,-1)); back.requestFocus(); return root;
    }

    private void load(){
        ApiClient.series(seriesTitle,new ApiClient.Callback<ApiClient.SeriesData>(){
            public void ok(ApiClient.SeriesData d){runOnUiThread(()->apply(d));}
            public void error(String m){runOnUiThread(()->{status.setText("Falha ao carregar série • "+m); synopsis.setText("Não foi possível carregar os episódios.");});}
        });
    }

    private void apply(ApiClient.SeriesData d){
        data=d; title.setText(clean(d.title,seriesTitle)); synopsis.setText(clean(d.synopsis,"Escolha uma temporada para ver os episódios."));
        String img=clean(d.backdrop,""); if(img.isEmpty()) img=clean(d.logo,""); ImageLoader.into(this,backdrop,img);
        seasonRow.removeAllViews();
        if(d.seasons.isEmpty()){status.setText("Nenhum episódio encontrado."); return;}
        for(int i=0;i<d.seasons.size();i++){
            ApiClient.Season s=d.seasons.get(i); String label=s.number>0?"TEMPORADA "+s.number:"EPISÓDIOS";
            TextView b=Ui.button(this,label); final int idx=i; b.setOnClickListener(v->showSeason(idx)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(Ui.dp(this,phone?128:150),Ui.dp(this,40)); p.rightMargin=Ui.dp(this,8); seasonRow.addView(b,p); if(i==0)b.requestFocus();
        }
        showSeason(0);
        enrichSeriesFromTmdb(d);
    }

    private void enrichSeriesFromTmdb(ApiClient.SeriesData d){
        ApiClient.Item q=new ApiClient.Item();
        q.type="series";
        q.name=clean(d.title,seriesTitle);
        q.seriesTitle=q.name;
        q.year=d.year;
        q.logo=clean(d.logo,"");
        q.backdrop=clean(d.backdrop,"");
        q.synopsis=clean(d.synopsis,"");
        ApiClient.tmdbEnrich(q,new ApiClient.Callback<ApiClient.Item>(){
            public void ok(ApiClient.Item x){runOnUiThread(()->{
                title.setText(clean(x.name,seriesTitle));
                synopsis.setText(clean(x.synopsis,clean(d.synopsis,"Escolha uma temporada para ver os episódios.")));
                String img=clean(x.backdrop,clean(x.logo,clean(d.backdrop,d.logo)));
                ImageLoader.into(SeriesActivity.this,backdrop,img);
                if(!clean(x.logo,"").isEmpty()) d.logo=x.logo;
                if(!clean(x.backdrop,"").isEmpty()) d.backdrop=x.backdrop;
            });}
            public void error(String m){}
        });
    }

    private void showSeason(int index){
        if(data==null||index<0||index>=data.seasons.size())return;
        episodes.clear(); episodes.addAll(data.seasons.get(index).episodes); adapter.notifyDataSetChanged();
        int season=data.seasons.get(index).number; status.setText((season>0?"Temporada "+season+" • ":"")+episodes.size()+" episódios");
    }

    private void openEpisode(ApiClient.Item e){if(e==null)return;long saved=LocalStore.resumePosition(this,e.id);if(saved>10000)new AlertDialog.Builder(this).setTitle(clean(e.name,"Episódio")).setMessage("Continuar de onde parou ou começar do início?").setPositiveButton("CONTINUAR",(d,w)->playEpisode(e,saved)).setNegativeButton("DO INÍCIO",(d,w)->{LocalStore.clearResume(this,e.id);playEpisode(e,0);}).setNeutralButton("CANCELAR",null).show();else playEpisode(e,0);}
    private void playEpisode(ApiClient.Item e,long resume){LocalStore.addHistory(this,e);Intent in=new Intent(this,PlayerActivity.class);in.putExtra("id",e.id);in.putExtra("name",e.name);in.putExtra("group",e.group);in.putExtra("type","series");in.putExtra("format",e.format);if(resume>0)in.putExtra("resume_pos",resume);startActivity(in);}

    private class EpisodeAdapter extends BaseAdapter{
        public int getCount(){return episodes.size();}
        public Object getItem(int p){return episodes.get(p);}
        public long getItemId(int p){return episodes.get(p).id;}
        public View getView(int p,View convert,android.view.ViewGroup parent){
            LinearLayout card; ImageView image; TextView name,meta;
            int imageH=phone?92:105;
            if(convert==null){
                card=Ui.column(SeriesActivity.this); card.setPadding(Ui.dp(SeriesActivity.this,6),Ui.dp(SeriesActivity.this,6),Ui.dp(SeriesActivity.this,6),Ui.dp(SeriesActivity.this,6)); card.setFocusable(true); card.setClickable(true); Ui.focus(card,SeriesActivity.this);
                image=new ImageView(SeriesActivity.this); image.setId(201); image.setScaleType(ImageView.ScaleType.CENTER_CROP); image.setBackgroundColor(Ui.PANEL_2); card.addView(image,new LinearLayout.LayoutParams(-1,Ui.dp(SeriesActivity.this,imageH)));
                name=Ui.text(SeriesActivity.this,"",phone?10:11,Ui.TEXT,true); name.setId(202); name.setMaxLines(2); card.addView(name,new LinearLayout.LayoutParams(-1,Ui.dp(SeriesActivity.this,34)));
                meta=Ui.text(SeriesActivity.this,"",9,Ui.MUTED,false); meta.setId(203); card.addView(meta,new LinearLayout.LayoutParams(-1,Ui.dp(SeriesActivity.this,18))); convert=card;
            }else card=(LinearLayout)convert;
            image=convert.findViewById(201); name=convert.findViewById(202); meta=convert.findViewById(203);
            ApiClient.Item e=episodes.get(p); name.setText(clean(e.name,"Episódio")); meta.setText(e.episodeNumber>0?"Episódio "+e.episodeNumber:clean(e.group,"Dubai Play"));
            String img=clean(e.logo,""); if(img.isEmpty()&&data!=null)img=clean(data.logo,""); ImageLoader.into(SeriesActivity.this,image,img);
            card.setOnClickListener(v->openEpisode(e));
            return convert;
        }
    }

    private String clean(String v,String fallback){if(v==null)return fallback;String s=v.trim();return s.isEmpty()||"null".equalsIgnoreCase(s)?fallback:s;}
    private void immersive(){getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);}
}
