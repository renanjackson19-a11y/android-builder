package com.ativacao.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public class GamePlayerActivity extends Activity {
    private WebView web;
    private String name,url,controls;
    private boolean phone;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);Ui.immersive(this);phone=Ui.phone(this);
        name=getIntent().getStringExtra("name");url=getIntent().getStringExtra("url");controls=getIntent().getStringExtra("controls");
        setContentView(build());
        if(url!=null&&!url.isEmpty())web.loadUrl(url);
    }

    private View build(){
        FrameLayout root=new FrameLayout(this);root.setBackgroundColor(Color.BLACK);

        web=new WebView(this);web.setBackgroundColor(Color.BLACK);web.setFocusable(true);web.setFocusableInTouchMode(true);
        WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadWithOverviewMode(true);s.setUseWideViewPort(true);s.setBuiltInZoomControls(false);s.setDisplayZoomControls(false);
        web.setWebViewClient(new WebViewClient());web.setWebChromeClient(new WebChromeClient());
        root.addView(web,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(Ui.dp(this,12),0,Ui.dp(this,12),0);bar.setBackgroundColor(0xB8000000);
        TextView t=Ui.text(this,(name==null?"JOGO":name)+"  •  "+(phone?"Controle na tela":(controls==null?"Setas + OK":controls)),10,Color.WHITE,true);
        bar.addView(t,new LinearLayout.LayoutParams(0,-1,1));
        TextView exit=Ui.button(this,"SAIR");exit.setOnClickListener(v->finish());
        bar.addView(exit,new LinearLayout.LayoutParams(Ui.dp(this,90),Ui.dp(this,38)));
        FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(-1,Ui.dp(this,52),Gravity.TOP);
        root.addView(bar,bp);

        if(phone) addTouchControls(root);
        web.requestFocus();
        return root;
    }

    private void addTouchControls(FrameLayout root){
        int size=Ui.dp(this,58);

        LinearLayout dpad=Ui.column(this);dpad.setGravity(Gravity.CENTER);
        TextView up=touch("▲","ArrowUp");
        dpad.addView(up,new LinearLayout.LayoutParams(size,size));
        LinearLayout mid=new LinearLayout(this);mid.setGravity(Gravity.CENTER);
        mid.addView(touch("◀","ArrowLeft"),new LinearLayout.LayoutParams(size,size));
        mid.addView(touch("▼","ArrowDown"),new LinearLayout.LayoutParams(size,size));
        mid.addView(touch("▶","ArrowRight"),new LinearLayout.LayoutParams(size,size));
        dpad.addView(mid,new LinearLayout.LayoutParams(size*3,size));
        FrameLayout.LayoutParams dp=new FrameLayout.LayoutParams(size*3,size*2,Gravity.LEFT|Gravity.BOTTOM);
        dp.leftMargin=Ui.dp(this,18);dp.bottomMargin=Ui.dp(this,20);root.addView(dpad,dp);

        LinearLayout actions=new LinearLayout(this);actions.setGravity(Gravity.CENTER);
        TextView b=touch("B"," ");
        TextView a=touch("A","Enter");
        actions.addView(b,new LinearLayout.LayoutParams(size,size));
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(size,size);ap.leftMargin=Ui.dp(this,12);actions.addView(a,ap);
        FrameLayout.LayoutParams ac=new FrameLayout.LayoutParams(size*2+Ui.dp(this,12),size,Gravity.RIGHT|Gravity.BOTTOM);
        ac.rightMargin=Ui.dp(this,24);ac.bottomMargin=Ui.dp(this,28);root.addView(actions,ac);
    }

    private TextView touch(String label,String key){
        TextView v=Ui.text(this,label,18,Color.WHITE,true);v.setGravity(Gravity.CENTER);
        v.setBackground(Ui.stroke(0xAA111111,Ui.GREEN,30,this));
        v.setOnTouchListener((x,e)->{
            if(e.getAction()==MotionEvent.ACTION_DOWN){send(key,true);return true;}
            if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL){send(key,false);return true;}
            return true;
        });
        return v;
    }

    private String jsKey(String key,boolean down){
        String type=down?"keydown":"keyup";
        return "(function(){var e=new KeyboardEvent('"+type+"',{key:'"+key+"',code:'"+key+"',bubbles:true});document.dispatchEvent(e);if(document.activeElement)document.activeElement.dispatchEvent(e);})();";
    }

    private boolean send(String key,boolean down){
        if(web==null)return false;web.evaluateJavascript(jsKey(key,down),null);return true;
    }

    @Override public boolean onKeyDown(int keyCode,KeyEvent event){
        switch(keyCode){
            case KeyEvent.KEYCODE_DPAD_UP:return send("ArrowUp",true);
            case KeyEvent.KEYCODE_DPAD_DOWN:return send("ArrowDown",true);
            case KeyEvent.KEYCODE_DPAD_LEFT:return send("ArrowLeft",true);
            case KeyEvent.KEYCODE_DPAD_RIGHT:return send("ArrowRight",true);
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_BUTTON_A:send("Enter",true);send(" ",true);return true;
            case KeyEvent.KEYCODE_BACK:finish();return true;
        }return super.onKeyDown(keyCode,event);
    }

    @Override public boolean onKeyUp(int keyCode,KeyEvent event){
        switch(keyCode){
            case KeyEvent.KEYCODE_DPAD_UP:return send("ArrowUp",false);
            case KeyEvent.KEYCODE_DPAD_DOWN:return send("ArrowDown",false);
            case KeyEvent.KEYCODE_DPAD_LEFT:return send("ArrowLeft",false);
            case KeyEvent.KEYCODE_DPAD_RIGHT:return send("ArrowRight",false);
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_BUTTON_A:send("Enter",false);send(" ",false);return true;
        }return super.onKeyUp(keyCode,event);
    }

    @Override protected void onResume(){super.onResume();Ui.immersive(this);if(web!=null)web.onResume();}
    @Override protected void onPause(){if(web!=null)web.onPause();super.onPause();}
    @Override protected void onDestroy(){if(web!=null){web.stopLoading();web.destroy();web=null;}super.onDestroy();}
}
