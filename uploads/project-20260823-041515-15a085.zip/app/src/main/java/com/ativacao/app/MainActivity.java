package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends Activity {
    private TextView server;
    private TextView liveCount;
    private TextView movieCount;
    private TextView seriesCount;
    private TextView heroTitle;
    private TextView heroMeta;
    private TextView heroText;
    private ImageView heroImage;
    private TextView heroPlay;
    private LinearLayout liveRow;
    private LinearLayout movieRow;
    private LinearLayout seriesRow;
    private ApiClient.Item heroItem;
    private boolean phone;
    private boolean portrait;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        if (!Session.isLogged(this)) { startActivity(new Intent(this, LoginActivity.class)); finish(); return; }
        phone = Ui.phone(this);
        portrait = Ui.portrait(this);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        immersive();
        setContentView(build());
        refresh();
    }

    @Override protected void onResume() { super.onResume(); immersive(); }

    private View build() {
        LinearLayout root = Ui.column(this);
        root.setBackgroundColor(Ui.BG);
        if (phone) buildPhoneHeader(root); else buildTvHeader(root);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);

        LinearLayout content = Ui.column(this);
        int side = phone ? 14 : 28;
        content.setPadding(Ui.dp(this,side), Ui.dp(this,phone?12:20), Ui.dp(this,side), Ui.dp(this,32));

        content.addView(buildHero(), new LinearLayout.LayoutParams(-1, Ui.dp(this, phone ? (portrait ? 238 : 205) : 245)));
        content.addView(buildStats(), new LinearLayout.LayoutParams(-1, Ui.dp(this, phone ? 112 : 114)));

        liveRow = addShelf(content, "Canais ao vivo", "VER TODOS", "live", phone ? 165 : 178, true);
        movieRow = addShelf(content, "Filmes em destaque", "VER TODOS", "movie", phone ? 235 : 218, false);
        seriesRow = addShelf(content, "Séries em destaque", "VER TODOS", "series", phone ? 235 : 218, false);

        FrameLayout centered = Ui.centered(this, content, 1180);
        scroll.addView(centered, new ScrollView.LayoutParams(-1,-2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        return root;
    }

    private View buildHero() {
        FrameLayout hero = new FrameLayout(this);
        hero.setBackground(Ui.stroke(Ui.PANEL,Ui.BORDER,20,this));
        hero.setClipToOutline(true);
        heroImage = new ImageView(this);
        heroImage.setScaleType(ImageView.ScaleType.CENTER_CROP);
        heroImage.setAlpha(.50f);
        heroImage.setBackgroundColor(Color.rgb(18,26,43));
        hero.addView(heroImage,new FrameLayout.LayoutParams(-1,-1));
        View shade = new View(this);
        shade.setBackground(new ColorDrawable(0x76000000));
        hero.addView(shade,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout info = Ui.column(this);
        int hp = phone ? 18 : 32;
        info.setPadding(Ui.dp(this,hp),Ui.dp(this,phone?16:24),Ui.dp(this,hp),Ui.dp(this,16));
        TextView badge = Ui.text(this,"DUBAI PLAY • DESTAQUE",phone?9:11,Ui.GREEN,true);
        info.addView(badge,new LinearLayout.LayoutParams(-1,Ui.dp(this,24)));
        heroTitle = Ui.text(this,"Seu entretenimento em um só lugar",phone?22:31,Color.WHITE,true);
        heroTitle.setMaxLines(phone?2:1);
        info.addView(heroTitle,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?58:50)));
        heroMeta = Ui.text(this,"Filmes • Séries • Ao vivo",phone?11:13,Color.rgb(220,226,238),true);
        heroMeta.setMaxLines(1);
        info.addView(heroMeta,new LinearLayout.LayoutParams(-1,Ui.dp(this,26)));
        heroText = Ui.text(this,"Conteúdo organizado por seção e categoria.",phone?11:13,Color.rgb(190,200,217),false);
        heroText.setMaxLines(phone?2:2);
        info.addView(heroText,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?42:48)));

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
        heroPlay = Ui.primaryButton(this,"▶  ASSISTIR");
        heroPlay.setOnClickListener(v->playHero());
        TextView movies = Ui.button(this,"FILMES");
        movies.setOnClickListener(v->open("movie","Filmes"));
        actions.addView(heroPlay,new LinearLayout.LayoutParams(Ui.dp(this,phone?142:185),Ui.dp(this,44)));
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(Ui.dp(this,phone?100:140),Ui.dp(this,44)); mp.leftMargin=Ui.dp(this,8); actions.addView(movies,mp);
        info.addView(actions);
        hero.addView(info,new FrameLayout.LayoutParams(-1,-1));
        return hero;
    }

    private View buildStats() {
        if (phone) {
            HorizontalScrollView sc = new HorizontalScrollView(this); sc.setHorizontalScrollBarEnabled(false);
            LinearLayout row = new LinearLayout(this); row.setPadding(0,Ui.dp(this,12),0,0);
            liveCount=statCardFixed(row,"AO VIVO","0",Ui.BLUE,"live");
            movieCount=statCardFixed(row,"FILMES","0",Ui.PURPLE,"movie");
            seriesCount=statCardFixed(row,"SÉRIES","0",Ui.GREEN,"series");
            sc.addView(row); return sc;
        }
        LinearLayout row = new LinearLayout(this); row.setPadding(0,Ui.dp(this,14),0,0);
        liveCount=statCardWeighted(row,"AO VIVO","0",Ui.BLUE,"live");
        movieCount=statCardWeighted(row,"FILMES","0",Ui.PURPLE,"movie");
        seriesCount=statCardWeighted(row,"SÉRIES","0",Ui.GREEN,"series");
        return row;
    }

    private LinearLayout addShelf(LinearLayout content, String titleText, String actionText, String type, int height, boolean live) {
        LinearLayout head = new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = Ui.text(this,titleText,phone?18:20,Ui.TEXT,true);
        TextView action = Ui.text(this,actionText,phone?10:11,Ui.GREEN,true); action.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); action.setFocusable(true); action.setClickable(true); action.setOnClickListener(v->open(type,titleFor(type)));
        head.addView(title,new LinearLayout.LayoutParams(0,Ui.dp(this,42),1)); head.addView(action,new LinearLayout.LayoutParams(Ui.dp(this,phone?88:100),Ui.dp(this,42)));
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,Ui.dp(this,46)); hp.topMargin=Ui.dp(this,10); content.addView(head,hp);
        HorizontalScrollView sc = new HorizontalScrollView(this); sc.setHorizontalScrollBarEnabled(false); sc.setFillViewport(false);
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); sc.addView(row);
        content.addView(sc,new LinearLayout.LayoutParams(-1,Ui.dp(this,height)));
        return row;
    }

    private void buildPhoneHeader(LinearLayout root){
        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setPadding(Ui.dp(this,12),Ui.dp(this,7),Ui.dp(this,12),Ui.dp(this,5)); top.setBackgroundColor(Ui.BG_2);
        TextView logo=Ui.text(this,"▶",14,Color.WHITE,true);logo.setGravity(Gravity.CENTER);logo.setBackground(Ui.gradient(Ui.PURPLE,Ui.GREEN,11,this));top.addView(logo,new LinearLayout.LayoutParams(Ui.dp(this,38),Ui.dp(this,38)));
        TextView brand=Ui.text(this,"DUBAI PLAY",17,Ui.TEXT,true);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,Ui.dp(this,40),1);bp.leftMargin=Ui.dp(this,10);top.addView(brand,bp);
        server=Ui.text(this,"● ...",9,Ui.MUTED,true);server.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);top.addView(server,new LinearLayout.LayoutParams(Ui.dp(this,88),Ui.dp(this,36)));
        TextView settings=Ui.button(this,"⚙");settings.setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class)));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(Ui.dp(this,44),Ui.dp(this,36));sp.leftMargin=Ui.dp(this,5);top.addView(settings,sp);
        root.addView(top,new LinearLayout.LayoutParams(-1,Ui.dp(this,50)));

        HorizontalScrollView navScroll=new HorizontalScrollView(this);navScroll.setHorizontalScrollBarEnabled(false);navScroll.setBackgroundColor(Ui.BG_2);
        LinearLayout navRow=new LinearLayout(this);navRow.setPadding(Ui.dp(this,8),0,Ui.dp(this,8),Ui.dp(this,5));
        TextView home=nav("INÍCIO"),live=nav("AO VIVO"),movie=nav("FILMES"),series=nav("SÉRIES");
        live.setOnClickListener(v->open("live","Canais ao Vivo"));movie.setOnClickListener(v->open("movie","Filmes"));series.setOnClickListener(v->open("series","Séries"));
        for(TextView n:new TextView[]{home,live,movie,series}){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(Ui.dp(this,88),Ui.dp(this,36));p.rightMargin=Ui.dp(this,4);navRow.addView(n,p);}navScroll.addView(navRow);root.addView(navScroll,new LinearLayout.LayoutParams(-1,Ui.dp(this,41)));home.requestFocus();
    }

    private void buildTvHeader(LinearLayout root){
        LinearLayout inner=new LinearLayout(this);inner.setGravity(Gravity.CENTER_VERTICAL);inner.setPadding(Ui.dp(this,18),Ui.dp(this,8),Ui.dp(this,18),Ui.dp(this,8));
        TextView logo=Ui.text(this,"▶",17,Color.WHITE,true);logo.setGravity(Gravity.CENTER);logo.setBackground(Ui.gradient(Ui.PURPLE,Ui.GREEN,12,this));inner.addView(logo,new LinearLayout.LayoutParams(Ui.dp(this,42),Ui.dp(this,42)));
        TextView brand=Ui.text(this,"DUBAI PLAY",21,Ui.TEXT,true);LinearLayout.LayoutParams brandP=new LinearLayout.LayoutParams(Ui.dp(this,190),Ui.dp(this,44));brandP.leftMargin=Ui.dp(this,12);inner.addView(brand,brandP);
        TextView home=nav("INÍCIO"),live=nav("AO VIVO"),movie=nav("FILMES"),series=nav("SÉRIES");live.setOnClickListener(v->open("live","Canais ao Vivo"));movie.setOnClickListener(v->open("movie","Filmes"));series.setOnClickListener(v->open("series","Séries"));
        inner.addView(home,new LinearLayout.LayoutParams(Ui.dp(this,82),Ui.dp(this,40)));inner.addView(live,new LinearLayout.LayoutParams(Ui.dp(this,90),Ui.dp(this,40)));inner.addView(movie,new LinearLayout.LayoutParams(Ui.dp(this,84),Ui.dp(this,40)));inner.addView(series,new LinearLayout.LayoutParams(Ui.dp(this,84),Ui.dp(this,40)));
        View spacer=new View(this);inner.addView(spacer,new LinearLayout.LayoutParams(0,1,1));server=Ui.text(this,"● CONECTANDO",11,Ui.MUTED,true);server.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);inner.addView(server,new LinearLayout.LayoutParams(Ui.dp(this,170),Ui.dp(this,40)));
        TextView settings=Ui.button(this,"⚙");settings.setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class)));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(Ui.dp(this,50),Ui.dp(this,40));sp.leftMargin=Ui.dp(this,8);inner.addView(settings,sp);
        FrameLayout shell=Ui.centered(this,inner,1260);shell.setBackgroundColor(Ui.BG_2);root.addView(shell,new LinearLayout.LayoutParams(-1,Ui.dp(this,60)));home.requestFocus();
    }

    private TextView nav(String label){TextView t=Ui.text(this,label,11,Ui.MUTED,true);t.setGravity(Gravity.CENTER);t.setFocusable(true);t.setClickable(true);Ui.focus(t,this,Ui.round(Color.TRANSPARENT,10,this),Ui.stroke(Ui.PANEL_2,Ui.PURPLE,10,this));return t;}

    private TextView statCardFixed(LinearLayout row,String title,String value,int accent,String type){LinearLayout card=makeStat(title,value,accent,type);TextView count=(TextView)card.getChildAt(1);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(Ui.dp(this,146),Ui.dp(this,94));p.rightMargin=Ui.dp(this,8);row.addView(card,p);return count;}
    private TextView statCardWeighted(LinearLayout row,String title,String value,int accent,String type){LinearLayout card=makeStat(title,value,accent,type);TextView count=(TextView)card.getChildAt(1);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,Ui.dp(this,96),1);p.rightMargin=Ui.dp(this,12);row.addView(card,p);return count;}
    private LinearLayout makeStat(String title,String value,int accent,String type){LinearLayout card=Ui.column(this);card.setPadding(Ui.dp(this,16),Ui.dp(this,12),Ui.dp(this,16),Ui.dp(this,9));card.setFocusable(true);card.setClickable(true);Ui.focus(card,this);card.setOnClickListener(v->open(type,titleFor(type)));TextView t=Ui.text(this,title,10,accent,true);card.addView(t,new LinearLayout.LayoutParams(-1,Ui.dp(this,22)));TextView count=Ui.text(this,value,phone?23:27,Ui.TEXT,true);card.addView(count,new LinearLayout.LayoutParams(-1,Ui.dp(this,36)));TextView sub=Ui.text(this,"no catálogo",9,Ui.MUTED,false);card.addView(sub,new LinearLayout.LayoutParams(-1,Ui.dp(this,18)));return card;}

    private void refresh(){
        ApiClient.status(new ApiClient.Callback<String>(){public void ok(String s){runOnUiThread(()->{server.setText(phone?"● ONLINE":"● SERVIDOR ONLINE");server.setTextColor(Ui.GREEN);});}public void error(String m){runOnUiThread(()->{server.setText(phone?"● OFFLINE":"● SERVIDOR OFFLINE");server.setTextColor(Ui.RED);});}});
        ApiClient.home(new ApiClient.Callback<ApiClient.HomeData>(){public void ok(ApiClient.HomeData h){runOnUiThread(()->applyHome(h));}public void error(String m){runOnUiThread(()->{server.setText("● ERRO");server.setTextColor(Ui.RED);heroTitle.setText("Servidor temporariamente ocupado");heroMeta.setText(m);heroText.setText("O aplicativo tentará novamente ao abrir esta tela.");});}});
    }

    private void applyHome(ApiClient.HomeData h){
        liveCount.setText(String.valueOf(h.liveCount));movieCount.setText(String.valueOf(h.movieCount));seriesCount.setText(String.valueOf(h.seriesCount));heroItem=h.hero;
        if(h.hero!=null){heroTitle.setText(clean(h.hero.name,"Destaque Dubai Play"));String meta=clean(h.hero.group,"Destaque Dubai Play");if(h.hero.year>0)meta+=" • "+h.hero.year;heroMeta.setText(meta);heroText.setText(clean(h.hero.synopsis,"Assista agora no Dubai Play."));String img=clean(h.hero.backdrop,"");if(img.isEmpty())img=clean(h.hero.logo,"");ImageLoader.into(this,heroImage,img);heroPlay.setVisibility(View.VISIBLE);}else{heroTitle.setText("Dubai Play");heroMeta.setText("Seu catálogo está conectado");heroText.setText("Importe conteúdos no painel para começar.");heroPlay.setVisibility(View.GONE);}
        renderShelf(liveRow,h.live,true);renderShelf(movieRow,h.movies,false);renderShelf(seriesRow,h.series,false);
    }

    private void renderShelf(LinearLayout row,List<ApiClient.Item> items,boolean live){row.removeAllViews();int max=Math.min(items.size(),16);for(int i=0;i<max;i++){ApiClient.Item item=items.get(i);LinearLayout card=Ui.column(this);card.setFocusable(true);card.setClickable(true);card.setPadding(Ui.dp(this,6),Ui.dp(this,6),Ui.dp(this,6),Ui.dp(this,6));Ui.focus(card,this);ImageView image=new ImageView(this);image.setScaleType(live?ImageView.ScaleType.CENTER_INSIDE:ImageView.ScaleType.CENTER_CROP);image.setBackgroundColor(Ui.PANEL_2);int w=phone?(live?132:148):(live?150:172);int ih=phone?(live?88:164):(live?105:145);card.addView(image,new LinearLayout.LayoutParams(-1,Ui.dp(this,ih)));TextView n=Ui.text(this,clean(item.name,"Sem nome"),phone?10:11,Ui.TEXT,true);n.setMaxLines(2);card.addView(n,new LinearLayout.LayoutParams(-1,Ui.dp(this,34)));TextView g=Ui.text(this,clean(item.group,live?"Ao vivo":"Dubai Play"),9,Ui.MUTED,false);g.setMaxLines(1);card.addView(g,new LinearLayout.LayoutParams(-1,Ui.dp(this,18)));ImageLoader.into(this,image,item.logo);card.setOnClickListener(v->openPlayer(item));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(Ui.dp(this,w),Ui.dp(this,ih+64));p.rightMargin=Ui.dp(this,9);row.addView(card,p);}}

    private void openPlayer(ApiClient.Item item){String t=item.type==null||item.type.isEmpty()?"movie":item.type;if("series".equals(t)){Intent in=new Intent(this,SeriesActivity.class);in.putExtra("title",clean(item.seriesTitle,item.name));in.putExtra("name",item.name);in.putExtra("logo",item.logo);in.putExtra("backdrop",item.backdrop);startActivity(in);return;}Intent in=new Intent(this,PlayerActivity.class);in.putExtra("id",item.id);in.putExtra("name",item.name);in.putExtra("group",item.group);in.putExtra("type",t);in.putExtra("format",item.format);in.putExtra("synopsis",item.synopsis);startActivity(in);}
    private void playHero(){if(heroItem!=null)openPlayer(heroItem);} private void open(String type,String title){Intent i=new Intent(this,CatalogActivity.class);i.putExtra("type",type);i.putExtra("title",title);startActivity(i);} private String titleFor(String type){if("live".equals(type))return "Canais ao Vivo";if("movie".equals(type))return "Filmes";return "Séries";} private String clean(String v,String fallback){if(v==null)return fallback;String s=v.trim();return s.isEmpty()||"null".equalsIgnoreCase(s)?fallback:s;}
    private void immersive(){getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);}
}
