package com.ativacao.app;

import android.app.Activity;
import android.app.AlertDialog;

final class AppExit {
    private AppExit(){}

    static void confirm(Activity a){
        new AlertDialog.Builder(a)
                .setTitle("Sair do aplicativo")
                .setMessage("Deseja sair do Green Play?")
                .setNegativeButton("CANCELAR",null)
                .setPositiveButton("SAIR",(d,w)->{
                    a.finishAffinity();
                })
                .show();
    }
}
