package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class DetailActivity extends Activity {
    private ApiClient.Item item;
    private TextView fav, title, meta, synopsis;
    private ImageView backdrop, poster;

    @Override public void onCreate(Bundle b){super.onCreate(b);Ui.immersive(this);item=readItem();setContentView(build());refresh();loadFullMetadata();}
    @Override protected void onResume(){super.onResume();Ui.immersive(this);}

    private View build(){
        FrameLayout root=new FrameLayout(this); root.setBackgroundColor(Ui.BG);
        backdrop=new ImageView(this); backdrop.setScaleType(ImageView.ScaleType.CENTER_CROP); backdrop.setAlpha(.58f); root.addView(backdrop,new FrameLayout.LayoutParams(-1,-1));
        View shade=new View(this); shade.setBackground(Ui.gradient(0xFA000000,0x66000000,0,this)); root.addView(shade,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout shell=Ui.column(this); shell.setPadding(Ui.dp(this,34),Ui.dp(this,24),Ui.dp(this,34),Ui.dp(this,24));
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand=Ui.text(this,"FILME  •  DUBAI PLAY",10,Ui.GREEN,true);LinearLayout.LayoutParams brp=new LinearLayout.LayoutParams(0,Ui.dp(this,42),1);top.addView(brand,brp);shell.addView(top,new LinearLayout.LayoutParams(-1,Ui.dp(this,48)));

        LinearLayout content=new LinearLayout(this);content.setGravity(Gravity.CENTER_VERTICAL);content.setPadding(0,Ui.dp(this,10),0,0);
        poster=new ImageView(this);poster.setScaleType(ImageView.ScaleType.CENTER_CROP);poster.setBackgroundColor(Ui.PANEL_2);content.addView(poster,new LinearLayout.LayoutParams(Ui.dp(this,Ui.phone(this)?180:225),Ui.dp(this,Ui.phone(this)?265:330)));
        LinearLayout info=Ui.column(this);info.setPadding(Ui.dp(this,30),0,0,0);
        title=Ui.text(this,"",Ui.phone(this)?29:42,Color.WHITE,true);title.setMaxLines(2);info.addView(title,new LinearLayout.LayoutParams(-1,Ui.dp(this,105)));
        meta=Ui.text(this,"",12,0xFFE3E7E4,true);info.addView(meta,new LinearLayout.LayoutParams(-1,Ui.dp(this,34)));
        synopsis=Ui.text(this,"",Ui.phone(this)?11:14,0xFFD0D5D2,false);synopsis.setMaxLines(7);synopsis.setLineSpacing(0,1.12f);info.addView(synopsis,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout actions=new LinearLayout(this);actions.setGravity(Gravity.CENTER_VERTICAL);long savedPos=LocalStore.resumePosition(this,item.id);
        TextView play=Ui.primaryButton(this,savedPos>10000?"▶  CONTINUAR ASSISTINDO":"▶  REPRODUZIR");play.setOnClickListener(v->play(savedPos>10000?savedPos:0));actions.addView(play,new LinearLayout.LayoutParams(Ui.dp(this,190),Ui.dp(this,46)));
        fav=Ui.button(this,LocalStore.isFavorite(this,item.id)?"★ FAVORITO":"☆ FAVORITAR");fav.setOnClickListener(v->{LocalStore.toggleFavorite(this,item);fav.setText(LocalStore.isFavorite(this,item.id)?"★ FAVORITO":"☆ FAVORITAR");});LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(Ui.dp(this,160),Ui.dp(this,46));fp.leftMargin=Ui.dp(this,10);actions.addView(fav,fp);
        if(savedPos>10000){TextView restart=Ui.button(this,"↺ COMEÇAR DO INÍCIO");restart.setOnClickListener(v->{LocalStore.clearResume(this,item.id);play(0);});LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(Ui.dp(this,150),Ui.dp(this,46));rp.leftMargin=Ui.dp(this,10);actions.addView(restart,rp);}
        info.addView(actions,new LinearLayout.LayoutParams(-1,Ui.dp(this,54)));content.addView(info,new LinearLayout.LayoutParams(0,Ui.dp(this,Ui.phone(this)?310:370),1));shell.addView(content,new LinearLayout.LayoutParams(-1,0,1));root.addView(shell,new FrameLayout.LayoutParams(-1,-1));play.requestFocus();return root;
    }

    private void loadFullMetadata(){
        if(!"movie".equals(item.type))return;
        // Se o painel já entregou os metadados, abre instantaneamente.
        boolean complete=item.year>0
                && !clean(item.synopsis,"").isEmpty()
                && !clean(item.logo,"").isEmpty()
                && !clean(item.backdrop,"").isEmpty();
        if(complete)return;

        // Fallback apenas para catálogo antigo/incompleto.
        ApiClient.tmdbEnrich(item,new ApiClient.Callback<ApiClient.Item>(){
            public void ok(ApiClient.Item full){runOnUiThread(()->{merge(full);refresh();});}
            public void error(String m){}
        });
    }
    private void merge(ApiClient.Item full){if(full==null)return;/* preserva nome original; TMDB enriquece dados */item.logo=prefer(full.logo,item.logo);item.backdrop=prefer(full.backdrop,item.backdrop);item.group=prefer(full.group,item.group);item.synopsis=prefer(full.synopsis,item.synopsis);if(full.year>0)item.year=full.year;if(full.tmdbId>0)item.tmdbId=full.tmdbId;}
    private void refresh(){title.setText(clean(item.name,"Filme"));String m=clean(item.group,"Filmes");if(item.year>0)m+=(m.isEmpty()?"":"  •  ")+item.year;meta.setText(m);synopsis.setText(clean(item.synopsis,"Sinopse indisponível."));ImageLoader.into(this,poster,clean(item.logo,""));ImageLoader.into(this,backdrop,clean(item.backdrop,clean(item.logo,"")));}
    private void play(long resume){LocalStore.addHistory(this,item);Intent in=new Intent(this,PlayerActivity.class);MainActivity.putItem(in,item);if(resume>0)in.putExtra("resume_pos",resume);startActivity(in);}
    private ApiClient.Item readItem(){ApiClient.Item i=new ApiClient.Item();i.id=getIntent().getLongExtra("id",0);i.name=getIntent().getStringExtra("name");i.logo=getIntent().getStringExtra("logo");i.backdrop=getIntent().getStringExtra("backdrop");i.group=getIntent().getStringExtra("group");i.synopsis=getIntent().getStringExtra("synopsis");i.type=clean(getIntent().getStringExtra("type"),"movie");i.format=clean(getIntent().getStringExtra("format"),"auto");i.year=getIntent().getIntExtra("year",0);i.seriesTitle=getIntent().getStringExtra("series_title");i.tmdbId=getIntent().getIntExtra("tmdb_id",0);return i;}
    private String prefer(String a,String b){return clean(a,clean(b,""));} private String clean(String v,String f){if(v==null)return f;String s=v.trim();return s.isEmpty()||"null".equalsIgnoreCase(s)?f:s;}
}
