package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicInteger;

public class MediaHomeActivity extends Activity {
    private final List<ApiClient.Item> latest=new ArrayList<>();
    private final Handler slider=new Handler();
    private LinearLayout content;
    private String mode="series",active="SÉRIES",title="Séries";
    private int heroIndex=0;
    private Runnable heroTask;
    private boolean phone;

    @Override public void onCreate(Bundle b){
        super.onCreate(b); Ui.immersive(this); phone=Ui.phone(this);
        mode=clean(getIntent().getStringExtra("mode"),"series").toLowerCase(Locale.ROOT);
        if("kids".equals(mode)){active="KIDS";title="Kids";}
        else if("anime".equals(mode)){active="ANIMES";title="Anime";}
        else if("hot".equals(mode)){active="HOT";title="HOT";}
        else {mode="series";active="SÉRIES";title="Séries";}
        setContentView(AppBackground.wrap(this,build()));
        load();
    }

    @Override protected void onResume(){super.onResume();Ui.immersive(this);startSlider();}
    @Override protected void onPause(){super.onPause();slider.removeCallbacksAndMessages(null);}

    private View build(){
        LinearLayout root=Ui.column(this); root.setBackgroundColor(Color.TRANSPARENT);
        root.addView(YellowNav.bar(this,active),new LinearLayout.LayoutParams(-1,Ui.dp(this,64)));
        content=Ui.column(this);
        content.setPadding(Ui.dp(this,phone?14:28),Ui.dp(this,14),Ui.dp(this,phone?14:28),Ui.dp(this,14));
        root.addView(content,new LinearLayout.LayoutParams(-1,0,1));
        render(); return root;
    }

    private void load(){
        if("hot".equals(mode)){loadHot();return;}
        if("series".equals(mode)){
            ApiClient.catalogPrepared("series",1,60,"","","",new ApiClient.Callback<ApiClient.CatalogPage>(){
                public void ok(ApiClient.CatalogPage p){apply(p==null?new ArrayList<>():p.items);}
                public void error(String m){ApiClient.catalog("series",1,60,"","","",new ApiClient.Callback<ApiClient.CatalogPage>(){
                    public void ok(ApiClient.CatalogPage p){apply(p==null?new ArrayList<>():p.items);}
                    public void error(String e){apply(new ArrayList<>());}
                });}
            }); return;
        }

        ArrayList<ApiClient.Item> all=new ArrayList<>();
        AtomicInteger pending=new AtomicInteger(2);
        ApiClient.catalogPrepared("movie",1,48,"","",mode,new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){synchronized(all){if(p!=null)all.addAll(p.items);}if(pending.decrementAndGet()==0)apply(all);}
            public void error(String m){if(pending.decrementAndGet()==0)apply(all);}
        });
        ApiClient.catalogPrepared("series",1,30,"","",mode,new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){synchronized(all){if(p!=null)all.addAll(p.items);}if(pending.decrementAndGet()==0)apply(all);}
            public void error(String m){if(pending.decrementAndGet()==0)apply(all);}
        });
    }

    private void loadHot(){
        ApiClient.hotCategories(new ApiClient.Callback<List<ApiClient.HotCategory>>(){
            public void ok(List<ApiClient.HotCategory> cats){
                ArrayList<ApiClient.Item> all=new ArrayList<>();
                long synthetic=1;
                if(cats!=null)for(ApiClient.HotCategory h:cats){
                    ApiClient.Item i=new ApiClient.Item();
                    i.id=-synthetic++; i.name=clean(h.name,"HOT"); i.group=i.name;
                    i.logo=h.cover; i.backdrop=h.cover; i.type="hot";
                    i.sourceId=h.sourceId; i.sourceName=h.sourceName; all.add(i);
                }
                apply(all);
            }
            public void error(String m){apply(new ArrayList<>());}
        });
    }

    private void apply(List<ApiClient.Item> raw){
        runOnUiThread(()->{
            latest.clear();
            LinkedHashMap<String,ApiClient.Item> unique=new LinkedHashMap<>();
            if(raw!=null)for(ApiClient.Item it:raw){
                if(it==null)continue;
                String n=clean(it.name,"").toLowerCase(Locale.ROOT)
                        .replaceAll("[^a-z0-9áàâãéèêíìîóòôõúùûç]+"," ").trim();
                String key=n+"|"+it.year+"|"+clean(it.type,mode);
                ApiClient.Item old=unique.get(key);
                if(old==null)unique.put(key,it);
                else if(score(it)>score(old) || (score(it)==score(old)&&it.id>old.id))unique.put(key,it);
            }
            latest.addAll(unique.values());
            if(!"hot".equals(mode))Collections.sort(latest,(a,b)->{
                int ay=a==null?0:a.year,by=b==null?0:b.year;
                if(ay<=0&&by>0)return 1;if(by<=0&&ay>0)return -1;
                if(ay!=by)return Integer.compare(by,ay);
                return Long.compare(b==null?0:b.id,a==null?0:a.id);
            });
            heroIndex=0; render(); startSlider();
        });
    }

    private int score(ApiClient.Item i){
        return (clean(i.backdrop,"").isEmpty()?0:4)+(clean(i.logo,"").isEmpty()?0:2)+(clean(i.synopsis,"").isEmpty()?0:1);
    }

    private void render(){
        if(content==null)return; content.removeAllViews();
        LinearLayout stage=new LinearLayout(this);stage.setOrientation(LinearLayout.HORIZONTAL);stage.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout left=Ui.column(this);
        left.addView(hero(),new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout shortcuts=new LinearLayout(this);
        shortcuts.setOrientation(LinearLayout.HORIZONTAL);
        shortcuts.addView(shortcut("★","FAVORITOS",0),new LinearLayout.LayoutParams(0,-1,1));
        shortcuts.addView(shortcut("NEW","RECENTES",1),new LinearLayout.LayoutParams(0,-1,1));
        shortcuts.addView(shortcut("☰","GÊNERO",2),new LinearLayout.LayoutParams(0,-1,1));
        shortcuts.addView(shortcut("▦","TODOS",3),new LinearLayout.LayoutParams(0,-1,1));
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?78:116));sp.topMargin=Ui.dp(this,5);
        left.addView(shortcuts,sp);
        stage.addView(left,new LinearLayout.LayoutParams(0,-1,phone?1.45f:1.75f));

        int cards=Math.min(2,Math.max(0,latest.size()-1));
        for(int x=0;x<2;x++){
            int idx=latest.isEmpty()?0:(heroIndex+1+x)%latest.size();
            View v=x<cards?featureCard(latest.get(idx)):emptyCard();
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1);p.leftMargin=Ui.dp(this,7);stage.addView(v,p);
        }
        content.addView(stage,new LinearLayout.LayoutParams(-1,0,1));
    }

    private View hero(){
        FrameLayout f=new FrameLayout(this);f.setFocusable(true);f.setClickable(true);f.setClipChildren(false);
        Ui.focus(f,this,Ui.round(0x22000000,8,this),Ui.stroke(0x33000000,Ui.GREEN,8,this));
        if(latest.isEmpty())return f;
        ApiClient.Item i=latest.get(Math.min(heroIndex,latest.size()-1));
        ImageView bg=new ImageView(this);bg.setScaleType(ImageView.ScaleType.CENTER_CROP);bg.setBackgroundColor(0xFF07110B);
        String art=clean(i.backdrop,clean(i.logo,""));if(!art.isEmpty())ImageLoader.intoBackground(this,bg,art);
        f.addView(bg,new FrameLayout.LayoutParams(-1,-1));
        View shade=new View(this);shade.setBackground(Ui.gradient(0x22000000,0xD9000000,0,this));f.addView(shade,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout info=Ui.column(this);info.setGravity(Gravity.BOTTOM);info.setPadding(Ui.dp(this,18),0,Ui.dp(this,18),Ui.dp(this,18));
        TextView name=Ui.text(this,clean(i.name,title),phone?18:26,Color.WHITE,true);name.setMaxLines(2);info.addView(name,new LinearLayout.LayoutParams(-1,-2));
        String meta=(i.year>0?String.valueOf(i.year):"")+(clean(i.group,"").isEmpty()?"":"  •  "+clean(i.group,""));
        info.addView(Ui.text(this,meta,phone?9:11,0xFFE0E5E1,false),new LinearLayout.LayoutParams(-1,Ui.dp(this,24)));
        if(latest.size()>1){
            StringBuilder dots=new StringBuilder();int max=Math.min(6,latest.size());
            for(int d=0;d<max;d++)dots.append(d==heroIndex?"●":"○").append(" ");
            info.addView(Ui.text(this,dots.toString().trim(),phone?8:10,Ui.GREEN,true),new LinearLayout.LayoutParams(-1,Ui.dp(this,18)));
        }
        f.addView(info,new FrameLayout.LayoutParams(-1,-1));f.setOnClickListener(v->openItem(i));return f;
    }

    private View featureCard(ApiClient.Item i){
        FrameLayout f=new FrameLayout(this);f.setFocusable(true);f.setClickable(true);f.setClipChildren(false);
        Ui.focus(f,this,Ui.round(0x22000000,8,this),Ui.stroke(0x33101010,Ui.GREEN,8,this));
        ImageView p=new ImageView(this);p.setScaleType(ImageView.ScaleType.CENTER_CROP);p.setBackgroundColor(Ui.PANEL_2);
        ImageLoader.intoPoster(this,p,clean(i.logo,i.backdrop));f.addView(p,new FrameLayout.LayoutParams(-1,-1));
        View sh=new View(this);sh.setBackground(Ui.gradient(0x00000000,0xE6000000,0,this));f.addView(sh,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout info=Ui.column(this);info.setGravity(Gravity.BOTTOM);info.setPadding(Ui.dp(this,10),0,Ui.dp(this,8),Ui.dp(this,12));
        TextView n=Ui.text(this,clean(i.name,title),phone?10:13,Color.WHITE,true);n.setMaxLines(2);info.addView(n,new LinearLayout.LayoutParams(-1,-2));
        info.addView(Ui.text(this,i.year>0?String.valueOf(i.year):"",phone?8:9,0xFFE1E6E2,false),new LinearLayout.LayoutParams(-1,Ui.dp(this,20)));
        f.addView(info,new FrameLayout.LayoutParams(-1,-1));f.setOnClickListener(v->openItem(i));return f;
    }

    private View emptyCard(){FrameLayout f=new FrameLayout(this);f.setBackground(Ui.round(0xAA101713,8,this));return f;}

    private View shortcut(String icon,String label,int kind){
        FrameLayout f=new FrameLayout(this);f.setFocusable(true);f.setClickable(true);f.setClipChildren(false);
        Ui.focus(f,this,Ui.round(0xAA142119,7,this),Ui.stroke(0xAA1A2A20,Ui.GREEN,7,this));
        LinearLayout box=Ui.column(this);box.setGravity(Gravity.CENTER);
        TextView a=Ui.text(this,icon,phone?11:16,Ui.GREEN,true);a.setGravity(Gravity.CENTER);
        TextView b=Ui.text(this,label,phone?8:10,Color.WHITE,true);b.setGravity(Gravity.CENTER);
        box.addView(a,new LinearLayout.LayoutParams(-1,0,1));box.addView(b,new LinearLayout.LayoutParams(-1,0,1));
        f.addView(box,new FrameLayout.LayoutParams(-1,-1));
        f.setOnClickListener(v->{if(kind==0)openFavorites();else if(kind==1)openRecent();else if(kind==2)openGenre();else openAll();});
        return f;
    }

    private void openFavorites(){Intent i=new Intent(this,LibraryActivity.class);i.putExtra("mode","favorites");startActivity(i);}

    private void openItem(ApiClient.Item i){
        if("hot".equals(mode)){openHot();return;}
        Intent d=new Intent(this,DetailActivity.class);
        d.putExtra("type",clean(i.type,"series".equals(mode)?"series":"movie"));
        d.putExtra("id",i.id);d.putExtra("name",i.name);d.putExtra("logo",i.logo);d.putExtra("backdrop",i.backdrop);
        d.putExtra("year",i.year);d.putExtra("synopsis",i.synopsis);startActivity(d);
    }

    private void openRecent(){
        if("hot".equals(mode)){openHot();return;}
        Intent i=new Intent(this,CatalogActivity.class);
        i.putExtra("type","series".equals(mode)?"series":"movie");
        i.putExtra("title",title+" • Recentes");
        i.putExtra("smart","series".equals(mode)?"launch":mode);
        i.putExtra("browse",true);startActivity(i);
    }

    private void openGenre(){
        if("hot".equals(mode)){openHot();return;}
        Intent i=new Intent(this,CatalogActivity.class);
        i.putExtra("type","series".equals(mode)?"series":"movie");
        i.putExtra("title",title+" • Gêneros");
        if(!"series".equals(mode))i.putExtra("smart",mode);
        i.putExtra("focus_categories",true);i.putExtra("browse",true);startActivity(i);
    }

    private void openAll(){
        if("hot".equals(mode)){openHot();return;}
        Intent i=new Intent(this,CatalogActivity.class);
        i.putExtra("type","series".equals(mode)?"series":"movie");
        i.putExtra("title",title+" • Todos");
        if(!"series".equals(mode))i.putExtra("smart",mode);
        i.putExtra("browse",true);startActivity(i);
    }

    private void openHot(){Intent i=new Intent(this,DiscoverActivity.class);i.putExtra("smart","hot");i.putExtra("title","HOT");startActivity(i);}

    private void startSlider(){
        slider.removeCallbacksAndMessages(null);if(latest.size()<2)return;
        heroTask=()->{if(isFinishing()||isDestroyed()||latest.size()<2)return;heroIndex=(heroIndex+1)%Math.min(6,latest.size());render();slider.postDelayed(heroTask,11000);};
        slider.postDelayed(heroTask,11000);
    }

    @Override public void onBackPressed(){AppExit.confirm(this);}
    private static String clean(String a,String b){return a==null||a.trim().isEmpty()?b:a.trim();}
}
