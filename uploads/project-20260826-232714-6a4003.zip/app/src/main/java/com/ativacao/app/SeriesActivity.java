package com.ativacao.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class SeriesActivity extends Activity {
    private final List<ApiClient.Item> episodes = new ArrayList<>();
    private ApiClient.SeriesData data;
    private LinearLayout seasonRow;
    private GridView grid;
    private EpisodeAdapter adapter;
    private TextView status, title, meta, synopsis;
    private ImageView backdrop, poster;
    private String seriesTitle, initialLogo, initialBackdrop, initialSynopsis, initialGroup;
    private int initialYear;
    private boolean phone;

    @Override public void onCreate(Bundle b){
        super.onCreate(b); Ui.immersive(this); phone=Ui.phone(this);
        seriesTitle=clean(getIntent().getStringExtra("title"),clean(getIntent().getStringExtra("name"),"Série"));
        initialLogo=clean(getIntent().getStringExtra("logo"),"");
        initialBackdrop=clean(getIntent().getStringExtra("backdrop"),"");
        initialSynopsis=clean(getIntent().getStringExtra("synopsis"),"");
        initialGroup=clean(getIntent().getStringExtra("group"),"");
        initialYear=getIntent().getIntExtra("year",0);
        setContentView(build()); load();
    }

    private View build(){
        LinearLayout root=Ui.column(this); root.setBackground(Ui.diagonalGradient(0xFF061109,0xFF010402,0,this));

        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setPadding(Ui.dp(this,22),Ui.dp(this,10),Ui.dp(this,22),Ui.dp(this,6));
        title=Ui.text(this,seriesTitle,phone?22:30,Color.WHITE,true); title.setMaxLines(1); LinearLayout.LayoutParams tpp=new LinearLayout.LayoutParams(0,Ui.dp(this,44),1); top.addView(title,tpp);
        root.addView(top,new LinearLayout.LayoutParams(-1,Ui.dp(this,58)));

        FrameLayout hero=new FrameLayout(this); hero.setBackground(Ui.stroke(0xFF09130C,0xFF25422D,18,this)); hero.setClipToOutline(true);
        backdrop=new ImageView(this); backdrop.setScaleType(ImageView.ScaleType.CENTER_CROP); backdrop.setAlpha(.52f); backdrop.setBackgroundColor(Ui.PANEL_2); hero.addView(backdrop,new FrameLayout.LayoutParams(-1,-1));
        View shade=new View(this); shade.setBackground(Ui.gradient(0xF5000000,0x55000000,0,this)); hero.addView(shade,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout heroContent=new LinearLayout(this); heroContent.setGravity(Gravity.CENTER_VERTICAL); heroContent.setPadding(Ui.dp(this,24),Ui.dp(this,18),Ui.dp(this,24),Ui.dp(this,18));
        poster=new ImageView(this); poster.setScaleType(ImageView.ScaleType.CENTER_CROP); poster.setBackgroundColor(Ui.PANEL_2); heroContent.addView(poster,new LinearLayout.LayoutParams(Ui.dp(this,phone?128:160),Ui.dp(this,phone?184:224)));
        LinearLayout info=Ui.column(this); info.setPadding(Ui.dp(this,22),0,0,0);
        TextView badge=Ui.text(this,"SÉRIE  •  DUBAI PLAY",10,Ui.GREEN,true); info.addView(badge,new LinearLayout.LayoutParams(-1,Ui.dp(this,24)));
        meta=Ui.text(this,"",11,0xFFE2E7E3,true); info.addView(meta,new LinearLayout.LayoutParams(-1,Ui.dp(this,30)));
        synopsis=Ui.text(this,clean(initialSynopsis,"Carregando informações da série..."),phone?11:13,0xFFD0D6D2,false); synopsis.setMaxLines(phone?4:5); synopsis.setLineSpacing(0,1.10f); info.addView(synopsis,new LinearLayout.LayoutParams(-1,0,1));
        heroContent.addView(info,new LinearLayout.LayoutParams(0,-1,1)); hero.addView(heroContent,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?220:260)); hp.setMargins(Ui.dp(this,24),Ui.dp(this,2),Ui.dp(this,24),0); root.addView(hero,hp);

        LinearLayout lower=Ui.column(this); lower.setPadding(Ui.dp(this,24),Ui.dp(this,8),Ui.dp(this,24),Ui.dp(this,8));
        status=Ui.text(this,"Carregando temporadas...",11,Ui.MUTED,false); lower.addView(status,new LinearLayout.LayoutParams(-1,Ui.dp(this,28)));
        HorizontalScrollView seasonScroll=new HorizontalScrollView(this); seasonScroll.setHorizontalScrollBarEnabled(false); seasonRow=new LinearLayout(this); seasonRow.setGravity(Gravity.CENTER_VERTICAL); seasonScroll.addView(seasonRow); lower.addView(seasonScroll,new LinearLayout.LayoutParams(-1,Ui.dp(this,48)));

        grid=new GridView(this); int sw=Ui.sw(this); int cols=phone?3:(sw<1100?4:5); grid.setNumColumns(cols); grid.setHorizontalSpacing(Ui.dp(this,12)); grid.setVerticalSpacing(Ui.dp(this,12)); grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH); grid.setSelector(android.R.color.transparent); grid.setPadding(0,Ui.dp(this,4),0,Ui.dp(this,10));
        adapter=new EpisodeAdapter(); grid.setAdapter(adapter); lower.addView(grid,new LinearLayout.LayoutParams(-1,0,1)); root.addView(lower,new LinearLayout.LayoutParams(-1,0,1));
        grid.requestFocus();

        ImageLoader.into(this,poster,initialLogo); ImageLoader.into(this,backdrop,clean(initialBackdrop,initialLogo));
        meta.setText(buildMeta(initialGroup,initialYear,0,0));
        return AppBackground.wrap(this,root);
    }

    private void load(){
        ApiClient.series(seriesTitle,new ApiClient.Callback<ApiClient.SeriesData>(){
            public void ok(ApiClient.SeriesData d){runOnUiThread(()->apply(d));}
            public void error(String m){runOnUiThread(()->{status.setText("Não foi possível carregar os episódios."); synopsis.setText(clean(initialSynopsis,"Tente novamente em alguns instantes."));});}
        });
    }

    private void apply(ApiClient.SeriesData d){
        data=d; title.setText(clean(d.title,seriesTitle));
        synopsis.setText(clean(d.synopsis,clean(initialSynopsis,"Sinopse indisponível.")));
        ImageLoader.into(this,poster,clean(d.logo,initialLogo));
        ImageLoader.into(this,backdrop,clean(d.backdrop,clean(initialBackdrop,clean(d.logo,initialLogo))));
        int epTotal=0; for(ApiClient.Season s:d.seasons) epTotal+=s.episodes.size();
        meta.setText(buildMeta(clean(d.group,initialGroup),d.year>0?d.year:initialYear,d.seasons.size(),epTotal));
        seasonRow.removeAllViews();
        if(d.seasons.isEmpty()){status.setText("Nenhum episódio encontrado."); return;}
        for(int i=0;i<d.seasons.size();i++){
            ApiClient.Season s=d.seasons.get(i); String label=s.number>0?"TEMPORADA "+s.number:"EPISÓDIOS";
            TextView b=Ui.text(this,label,11,0xFFE9EEEA,true); b.setGravity(Gravity.CENTER); b.setFocusable(true); b.setClickable(true); final int idx=i;
            Ui.focus(b,this,Ui.round(0xFF151C17,14,this),Ui.stroke(0xFF17221A,Ui.GREEN,14,this)); b.setOnClickListener(v->showSeason(idx));
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(Ui.dp(this,phone?128:150),Ui.dp(this,40)); p.rightMargin=Ui.dp(this,8); seasonRow.addView(b,p);
        }
        showSeason(0); enrichSeriesFromTmdb(d);
    }

    private void enrichSeriesFromTmdb(ApiClient.SeriesData d){
        ApiClient.Item q=new ApiClient.Item(); q.type="series"; q.name=clean(d.title,seriesTitle); q.seriesTitle=q.name; q.year=d.year; q.logo=clean(d.logo,initialLogo); q.backdrop=clean(d.backdrop,initialBackdrop); q.synopsis=clean(d.synopsis,initialSynopsis);
        ApiClient.tmdbEnrich(q,new ApiClient.Callback<ApiClient.Item>(){
            public void ok(ApiClient.Item x){runOnUiThread(()->{
                // Mantém o título original da fonte; TMDB só enriquece arte/sinopse/ano.
                synopsis.setText(clean(x.synopsis,clean(d.synopsis,clean(initialSynopsis,"Sinopse indisponível."))));
                if(x.year>0)d.year=x.year;
                if(!clean(x.logo,"").isEmpty()){d.logo=x.logo;ImageLoader.into(SeriesActivity.this,poster,x.logo);}
                if(!clean(x.backdrop,"").isEmpty()){d.backdrop=x.backdrop;ImageLoader.into(SeriesActivity.this,backdrop,x.backdrop);}
                int epTotal=0;for(ApiClient.Season s:d.seasons)epTotal+=s.episodes.size(); meta.setText(buildMeta(clean(d.group,initialGroup),d.year,d.seasons.size(),epTotal));
            });}
            public void error(String m){}
        });
    }

    private String buildMeta(String group,int year,int seasons,int eps){
        StringBuilder s=new StringBuilder(); if(!clean(group,"").isEmpty())s.append(clean(group,"")); if(year>0){if(s.length()>0)s.append("  •  ");s.append(year);} if(seasons>0){if(s.length()>0)s.append("  •  ");s.append(seasons).append(seasons==1?" temporada":" temporadas");} if(eps>0){if(s.length()>0)s.append("  •  ");s.append(eps).append(" episódios");} return s.toString();
    }

    private void showSeason(int index){
        if(data==null||index<0||index>=data.seasons.size())return; episodes.clear(); episodes.addAll(data.seasons.get(index).episodes); adapter.notifyDataSetChanged(); int season=data.seasons.get(index).number; status.setText((season>0?"Temporada "+season+"  •  ":"")+episodes.size()+" episódios");
    }

    private void openEpisode(ApiClient.Item e){if(e==null)return;long saved=LocalStore.resumePosition(this,e.id);if(saved>10000)new AlertDialog.Builder(this).setTitle(clean(e.name,"Episódio")).setMessage("Continuar de onde parou ou começar do início?").setPositiveButton("CONTINUAR",(d,w)->playEpisode(e,saved)).setNegativeButton("DO INÍCIO",(d,w)->{LocalStore.clearResume(this,e.id);playEpisode(e,0);}).setNeutralButton("CANCELAR",null).show();else playEpisode(e,0);}
    private void playEpisode(ApiClient.Item e,long resume){LocalStore.addHistory(this,e);Intent in=new Intent(this,PlayerActivity.class);in.putExtra("id",e.id);in.putExtra("name",e.name);in.putExtra("group",e.group);in.putExtra("type","series");in.putExtra("format",e.format);if(resume>0)in.putExtra("resume_pos",resume);startActivity(in);}

    private class EpisodeAdapter extends BaseAdapter{
        public int getCount(){return episodes.size();} public Object getItem(int p){return episodes.get(p);} public long getItemId(int p){return episodes.get(p).id;}
        public View getView(int p,View convert,android.view.ViewGroup parent){
            LinearLayout card; ImageView image; TextView number,name;
            int imageH=phone?92:112;
            if(convert==null){
                card=Ui.column(SeriesActivity.this); card.setPadding(Ui.dp(SeriesActivity.this,6),Ui.dp(SeriesActivity.this,6),Ui.dp(SeriesActivity.this,6),Ui.dp(SeriesActivity.this,7)); card.setFocusable(true); card.setClickable(true); card.setBackground(Ui.round(0xFF0C130E,12,SeriesActivity.this)); Ui.focus(card,SeriesActivity.this,Ui.round(0xFF0C130E,12,SeriesActivity.this),Ui.stroke(0xFF152019,Ui.GREEN,12,SeriesActivity.this));
                image=new ImageView(SeriesActivity.this); image.setId(201); image.setScaleType(ImageView.ScaleType.CENTER_CROP); image.setBackgroundColor(0xFF101813); card.addView(image,new LinearLayout.LayoutParams(-1,Ui.dp(SeriesActivity.this,imageH)));
                number=Ui.text(SeriesActivity.this,"",9,Ui.GREEN,true); number.setId(203); LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,Ui.dp(SeriesActivity.this,20));np.topMargin=Ui.dp(SeriesActivity.this,5);card.addView(number,np);
                name=Ui.text(SeriesActivity.this,"",phone?10:11,Ui.TEXT,true); name.setId(202); name.setMaxLines(2); card.addView(name,new LinearLayout.LayoutParams(-1,Ui.dp(SeriesActivity.this,36))); convert=card;
            } else card=(LinearLayout)convert;
            image=convert.findViewById(201); name=convert.findViewById(202); number=convert.findViewById(203);
            ApiClient.Item e=episodes.get(p); number.setText(e.episodeNumber>0?"EPISÓDIO "+e.episodeNumber:"EPISÓDIO "+(p+1)); name.setText(clean(e.name,"Episódio "+(p+1)));
            String img=clean(e.logo,""); if(img.isEmpty()&&data!=null)img=clean(data.backdrop,clean(data.logo,"")); ImageLoader.into(SeriesActivity.this,image,img); card.setOnClickListener(v->openEpisode(e)); return convert;
        }
    }

    private String clean(String v,String fallback){if(v==null)return fallback;String s=v.trim();return s.isEmpty()||"null".equalsIgnoreCase(s)?fallback:s;}
}
