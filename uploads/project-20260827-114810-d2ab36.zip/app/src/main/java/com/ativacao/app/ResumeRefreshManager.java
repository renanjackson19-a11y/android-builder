package com.ativacao.app;

import android.app.Activity;
import android.app.Application;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

final class ResumeRefreshManager implements Application.ActivityLifecycleCallbacks {
    // Só atualiza se o app realmente ficou em segundo plano por pelo menos 7 s.
    private static final long REFRESH_AFTER_MS=7000L;
    // V206: mesmo sem sair do app, sincroniza periodicamente em segundo plano.
    private static final long PERIODIC_SYNC_MS=120000L;

    // Janela para distinguir troca de tela interna de saída real do aplicativo.
    // Ao abrir Filme/Série/Player, a próxima Activity normalmente inicia dentro
    // desse intervalo e cancela a marcação de background.
    private static final long BACKGROUND_CONFIRM_MS=1800L;

    private static final Handler main=new Handler(Looper.getMainLooper());
    private static int started=0;
    private static long backgroundAt=0L;
    private static boolean wasBackground=false;
    private static boolean refreshing=false;
    private static long lastPeriodicSync=0L;

    private static Activity foregroundActivity=null;
    private static final Runnable periodicTick=new Runnable(){
        @Override public void run(){
            Activity a=foregroundActivity;
            long now=System.currentTimeMillis();
            if(started>0 && a!=null && !a.isFinishing() && !refreshing && Session.isLogged(a)
                    && !(a instanceof LoginActivity) && !(a instanceof ContentRefreshActivity)
                    && (lastPeriodicSync==0L || now-lastPeriodicSync>=PERIODIC_SYNC_MS)){
                lastPeriodicSync=now;
                CatalogPreloader.refreshBackground(a);
            }
            main.postDelayed(this,30000L);
        }
    };
    private static final Runnable confirmBackground=()->{
        if(started==0 && !refreshing){
            wasBackground=true;
            backgroundAt=System.currentTimeMillis();
        }
    };

    static void install(Application app){
        app.registerActivityLifecycleCallbacks(new ResumeRefreshManager());
        main.removeCallbacks(periodicTick);
        main.postDelayed(periodicTick,30000L);
    }

    static void completeRefresh(){
        refreshing=false;
        wasBackground=false;
        backgroundAt=0L;
        main.removeCallbacks(confirmBackground);
    }

    @Override public void onActivityStarted(Activity a){
        foregroundActivity=a;
        // Se alguma tela do próprio Green Play iniciou logo em seguida,
        // então não houve saída real do aplicativo.
        main.removeCallbacks(confirmBackground);

        boolean returningFromOutside=(started==0 && wasBackground);
        long away=backgroundAt<=0?0:(System.currentTimeMillis()-backgroundAt);

        started++;

        // V206: o cliente pode ficar horas dentro do Green Play. Nesse caso também
        // atualiza os snapshots, sem limpar a tela atual e sem exigir reinício do app.
        long now=System.currentTimeMillis();
        if(!returningFromOutside && !refreshing && Session.isLogged(a)
                && !(a instanceof LoginActivity) && !(a instanceof ContentRefreshActivity)
                && (lastPeriodicSync==0L || now-lastPeriodicSync>=PERIODIC_SYNC_MS)){
            lastPeriodicSync=now;
            CatalogPreloader.refreshBackground(a);
        }

        if(returningFromOutside
                && away>=REFRESH_AFTER_MS
                && !refreshing
                && Session.isLogged(a)
                && !(a instanceof LoginActivity)
                && !(a instanceof ContentRefreshActivity)){

            // V185: volta instantaneamente para a tela em que o cliente estava.
            // O snapshot antigo continua visível e o painel sincroniza em segundo plano.
            refreshing=true;
            wasBackground=false;
            backgroundAt=0L;
            CatalogPreloader.refreshBackground(a);
            refreshing=false;
        }
    }

    @Override public void onActivityStopped(Activity a){
        started=Math.max(0,started-1);
        if(started==0)foregroundActivity=null;

        if(started==0
                && !a.isChangingConfigurations()
                && !(a instanceof ContentRefreshActivity)
                && !refreshing){

            // Não marca background imediatamente.
            // Espera para ver se outra Activity do próprio app vai abrir.
            main.removeCallbacks(confirmBackground);
            main.postDelayed(confirmBackground,BACKGROUND_CONFIRM_MS);
        }
    }

    @Override public void onActivityCreated(Activity a,Bundle b){}
    @Override public void onActivityResumed(Activity a){}
    @Override public void onActivityPaused(Activity a){}
    @Override public void onActivitySaveInstanceState(Activity a,Bundle b){}
    @Override public void onActivityDestroyed(Activity a){}
}
