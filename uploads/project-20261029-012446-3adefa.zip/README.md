# Velo Teste — protótipo Android

Projeto Android Studio em Java, independente dos APKs originais.

## Como gerar o APK
1. Abra a pasta `VeloTeste` no Android Studio com SDK 35 instalado.
2. Aguarde a sincronização do Gradle (Android Gradle Plugin 8.7.3; JDK 17).
3. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Instale o APK gerado em `app/build/outputs/apk/debug/app-debug.apk`.

## O que funciona
- Navegação pelas telas Canais, Filmes e Séries (sem catálogo conectado).
- Teste de player para URL HTTPS direta de vídeo compatível com Android VideoView, autorizada pelo usuário.

## O que falta
- API autorizada de catálogo, autenticação, EPG e URLs de reprodução.
- Reprodução HLS/DASH com Media3 ExoPlayer, se necessária.
- Login e persistência de sessão após integração com backend.

Este projeto não contém links privados extraídos de terceiros nem mecanismos para contornar autenticação.
