package fun.greenplay.app;
import android.app.*;import android.os.*;import android.view.*;import android.widget.*;import android.net.*;import java.util.*;
public class PlayerActivity extends Activity{
 VideoView v;
 public void onCreate(Bundle b){
  super.onCreate(b);
  getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
  v=new VideoView(this);setContentView(v);
  String u=getIntent().getStringExtra("url");
  v.setMediaController(new MediaController(this));
  try{
   Map<String,String> h=new HashMap<>();
   h.put("User-Agent","Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36");
   h.put("Referer","https://greenplay.fun/");
   h.put("Origin","https://greenplay.fun");
   v.setVideoURI(Uri.parse(u),h);
  }catch(Exception e){v.setVideoPath(u);}
  v.setOnPreparedListener(mp->{mp.setScreenOnWhilePlaying(true);v.start();});
  v.requestFocus();
 }
}
