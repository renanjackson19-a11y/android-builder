package com.greenplay.v5.ui.login;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.MotionEvent;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.greenplay.v5.BuildConfig;
import com.greenplay.v5.R;
import com.greenplay.v5.core.network.NetworkProvider;
import com.greenplay.v5.core.network.PanelHost;
import com.greenplay.v5.core.session.SessionStore;
import com.greenplay.v5.data.model.LoginResponse;
import com.greenplay.v5.data.model.StatusResponse;
import com.greenplay.v5.data.repository.AuthRepository;
import com.greenplay.v5.databinding.ActivityLoginBinding;
import com.greenplay.v5.ui.tv.TvActivity;
import com.squareup.picasso.Picasso;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public final class LoginActivity extends AppCompatActivity {
    private ActivityLoginBinding b;
    private AuthRepository auth;
    private int trialHours = 3;
    private boolean trialEnabled = false;
    private boolean passwordVisible = false;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        b = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        auth = new AuthRepository(this);

        SessionStore session = new SessionStore(this);
        if (session.isLogged() && !session.host().trim().isEmpty() && !session.user().trim().isEmpty() && !session.pass().isEmpty()) {
            openTv();
            return;
        }

        String device = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        if (device == null || device.trim().isEmpty()) device = "não disponível";
        b.txtDevice.setText("ID Dispositivo: " + device.toUpperCase());
        b.txtVersion.setText("Versão: " + BuildConfig.VERSION_NAME);

        b.btnEnter.setOnClickListener(v -> login());
        b.btnConnection.setOnClickListener(v -> testConnection());
        b.btnTrial.setOnClickListener(v -> createTrial());
        configurePasswordEye();
        loadPanelBranding();
    }

    private void configurePasswordEye() {
        b.inputPass.setOnTouchListener((v, event) -> {
            if (event.getAction() != MotionEvent.ACTION_UP) return false;
            if (b.inputPass.getCompoundDrawablesRelative()[2] == null) return false;
            int touchStart = b.inputPass.getWidth() - b.inputPass.getPaddingEnd()
                    - b.inputPass.getCompoundDrawablesRelative()[2].getBounds().width() - 24;
            if (event.getX() < touchStart) return false;

            int cursor = b.inputPass.getSelectionStart();
            passwordVisible = !passwordVisible;
            b.inputPass.setTransformationMethod(passwordVisible
                    ? HideReturnsTransformationMethod.getInstance()
                    : PasswordTransformationMethod.getInstance());
            b.inputPass.setSelection(Math.max(0, cursor));
            v.performClick();
            return true;
        });
    }

    private void loadPanelBranding() {
        setServerOnline(false);
        NetworkProvider.panel().status().enqueue(new Callback<StatusResponse>() {
            @Override public void onResponse(Call<StatusResponse> call, Response<StatusResponse> response) {
                StatusResponse st = response.body();
                if (!response.isSuccessful() || st == null) {
                    runOnUiThread(() -> setServerOnline(false));
                    return;
                }
                runOnUiThread(() -> {
                    setServerOnline(true);
                    applyStatus(st);
                });
            }
            @Override public void onFailure(Call<StatusResponse> call, Throwable t) {
                runOnUiThread(() -> setServerOnline(false));
            }
        });
    }

    private void applyStatus(StatusResponse st) {
        String bg = absoluteAsset(st.loginBackground);
        if (!bg.isEmpty()) {
            Picasso.get().load(bg).fit().centerCrop().into(b.loginBackground);
        }

        String logo = absoluteAsset(st.appLogo);
        if (!logo.isEmpty()) {
            Picasso.get().load(logo).fit().centerInside().into(b.appLogo, new com.squareup.picasso.Callback() {
                @Override public void onSuccess() { b.appLogo.setVisibility(View.VISIBLE); }
                @Override public void onError(Exception e) { b.appLogo.setVisibility(View.GONE); }
            });
        } else {
            b.appLogo.setVisibility(View.GONE);
        }

        trialEnabled = st.trialEnabled;
        trialHours = Math.max(1, st.trialHours);
        if (trialEnabled) {
            b.btnTrial.setVisibility(View.VISIBLE);
            b.btnTrial.setText("TESTE AUTOMÁTICO  •  " + trialHours + (trialHours == 1 ? " HORA" : " HORAS"));
        } else {
            b.btnTrial.setVisibility(View.GONE);
        }
    }

    private void testConnection() {
        b.btnConnection.setEnabled(false);
        b.txtError.setTextColor(ContextCompat.getColor(this, R.color.gp_muted));
        b.txtError.setText("Testando conexão...");
        NetworkProvider.panel().status().enqueue(new Callback<StatusResponse>() {
            @Override public void onResponse(Call<StatusResponse> call, Response<StatusResponse> response) {
                StatusResponse st = response.body();
                runOnUiThread(() -> {
                    b.btnConnection.setEnabled(true);
                    if (response.isSuccessful() && st != null) {
                        setServerOnline(true);
                        applyStatus(st);
                        b.txtError.setTextColor(ContextCompat.getColor(LoginActivity.this, R.color.gp_green_soft));
                        b.txtError.setText("Conexão OK • servidor online");
                    } else {
                        setServerOnline(false);
                        b.txtError.setTextColor(0xFFFF7979);
                        b.txtError.setText("Servidor indisponível no momento");
                    }
                });
            }
            @Override public void onFailure(Call<StatusResponse> call, Throwable t) {
                runOnUiThread(() -> {
                    b.btnConnection.setEnabled(true);
                    setServerOnline(false);
                    b.txtError.setTextColor(0xFFFF7979);
                    b.txtError.setText("Sem conexão com o servidor");
                });
            }
        });
    }

    private void setServerOnline(boolean online) {
        b.serverDot.setBackgroundResource(online ? R.drawable.bg_status_online : R.drawable.bg_status_offline);
    }

    private String absoluteAsset(String raw) {
        if (raw == null) return "";
        String s = raw.trim();
        if (s.isEmpty()) return "";
        if (s.startsWith("http://") || s.startsWith("https://")) return s;
        String root = PanelHost.root();
        if (root.endsWith("/")) root = root.substring(0, root.length() - 1);
        return root + (s.startsWith("/") ? s : "/" + s);
    }

    private void setLoading(boolean loading, String text) {
        b.progress.setVisibility(loading ? View.VISIBLE : View.GONE);
        b.btnEnter.setEnabled(!loading);
        b.btnConnection.setEnabled(!loading);
        b.btnTrial.setEnabled(!loading && trialEnabled);
        if (text != null) b.txtError.setText(text);
    }

    private void login() {
        String user = b.inputUser.getText().toString().trim();
        String pass = b.inputPass.getText().toString();
        if (user.isEmpty() || pass.isEmpty()) {
            b.txtError.setTextColor(0xFFFF7979);
            b.txtError.setText("Digite usuário e senha");
            return;
        }
        b.txtError.setTextColor(0xFFFF7979);
        setLoading(true, "");
        String device = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        auth.login(user, pass, device, new AuthRepository.Result() {
            @Override public void success(LoginResponse login) { runOnUiThread(() -> openTv()); }
            @Override public void error(String message) { runOnUiThread(() -> setLoading(false, message)); }
        });
    }

    private void createTrial() {
        if (!trialEnabled) return;
        b.txtError.setTextColor(ContextCompat.getColor(this, R.color.gp_muted));
        setLoading(true, "Criando teste de " + trialHours + (trialHours == 1 ? " hora..." : " horas..."));
        String device = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        NetworkProvider.panel().trial(device).enqueue(new Callback<LoginResponse>() {
            @Override public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                LoginResponse body = response.body();
                if (!response.isSuccessful() || body == null || !body.ok) {
                    String msg = body != null && body.message != null ? body.message : "Teste indisponível no momento";
                    runOnUiThread(() -> {
                        b.txtError.setTextColor(0xFFFF7979);
                        setLoading(false, msg);
                    });
                    return;
                }
                String user = body.username == null ? "" : body.username.trim();
                String pass = body.xtreamPassword == null ? "" : body.xtreamPassword;
                String host = body.xtreamHost == null || body.xtreamHost.trim().isEmpty() ? PanelHost.root() : body.xtreamHost.trim();
                new SessionStore(LoginActivity.this).save(host, user, pass, body.expiresAt, body.plan, body.adultAccess, body.userToken);
                runOnUiThread(() -> openTv());
            }
            @Override public void onFailure(Call<LoginResponse> call, Throwable t) {
                runOnUiThread(() -> {
                    b.txtError.setTextColor(0xFFFF7979);
                    setLoading(false, "Sem conexão com o painel");
                });
            }
        });
    }

    private void openTv() {
        startActivity(new Intent(LoginActivity.this, TvActivity.class));
        finish();
    }
}
