GreenPlay Android v16.74

Correção da barra de pesquisa.

- A barra da Home e a barra da tela de busca agora têm exatamente a mesma altura, largura, cor, raio e posição.
- Ao tocar em Buscar, a barra não cresce, não encolhe e não muda de lugar.
- O espaço ocupado pela logo vira o botão Voltar, mantendo a barra imóvel.
- Placeholder e ícone usam o mesmo tamanho da Home.
- Nenhuma alteração em painel, catálogo, TMDB, provedores ou banco.
