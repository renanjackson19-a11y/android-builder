package com.spotnet.music;

import android.Manifest;
import android.content.ComponentName;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.app.AlertDialog;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.*;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.Player;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionToken;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.google.common.util.concurrent.ListenableFuture;
import org.json.*;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends AppCompatActivity {
    LinearLayout bannerBox, sectionsBox;
    View homeTab, searchTab, queueTab, detailTab, accountTab;
    TextView homeStatus, searchStatus, queueStatus, nowTitle, nowSub, navHome, navSearch, navQueue, navAccount, detailTitle, detailStatus, planName, planExpiry, accountName, accountUser, accountStatus, accountReferral;
    EditText searchInput;
    ImageView nowThumb;
    Button playPause, previousBtn, nextBtn, shuffleBtn, queuePlayPause, queueNextBtn, detailPlay, detailShuffle, renewBtn;
    final ArrayList<MusicItem> searchItems = new ArrayList<>();
    final ArrayList<MusicItem> queueItems = new ArrayList<>();
    final ArrayList<MusicItem> detailItems = new ArrayList<>();
    SearchAdapter searchAdapter, queueAdapter, detailAdapter;
    ListenableFuture<MediaController> controllerFuture;
    MediaController controller;
    final AtomicInteger queueGeneration = new AtomicInteger(0);
    boolean shuffleEnabled = false;
    final Handler heartbeatHandler = new Handler(Looper.getMainLooper());
    final Runnable heartbeatTask = new Runnable(){@Override public void run(){sendHeartbeat();heartbeatHandler.postDelayed(this,60000);}};

    private final ActivityResultLauncher<String> notificationPermission = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(), granted -> {});

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        bannerBox=findViewById(R.id.bannerBox); sectionsBox=findViewById(R.id.sectionsBox);
        homeTab=findViewById(R.id.homeTab); searchTab=findViewById(R.id.searchTab); queueTab=findViewById(R.id.queueTab); detailTab=findViewById(R.id.detailTab); accountTab=findViewById(R.id.accountTab);
        homeStatus=findViewById(R.id.homeStatus); searchStatus=findViewById(R.id.searchStatus); queueStatus=findViewById(R.id.queueStatus);
        nowTitle=findViewById(R.id.nowTitle); nowSub=findViewById(R.id.nowSub); nowThumb=findViewById(R.id.nowThumb);
        planName=findViewById(R.id.planName); planExpiry=findViewById(R.id.planExpiry); renewBtn=findViewById(R.id.renewBtn); accountName=findViewById(R.id.accountName); accountUser=findViewById(R.id.accountUser); accountStatus=findViewById(R.id.accountStatus); accountReferral=findViewById(R.id.accountReferral);
        navHome=findViewById(R.id.navHome); navSearch=findViewById(R.id.navSearch); navQueue=findViewById(R.id.navQueue); navAccount=findViewById(R.id.navAccount); detailTitle=findViewById(R.id.detailTitle); detailStatus=findViewById(R.id.detailStatus);
        searchInput=findViewById(R.id.searchInput); playPause=findViewById(R.id.playPause);
        previousBtn=findViewById(R.id.previousBtn); nextBtn=findViewById(R.id.nextBtn); shuffleBtn=findViewById(R.id.shuffleBtn); queuePlayPause=findViewById(R.id.queuePlayPause); queueNextBtn=findViewById(R.id.queueNextBtn); detailPlay=findViewById(R.id.detailPlay); detailShuffle=findViewById(R.id.detailShuffle);

        RecyclerView searchList=findViewById(R.id.searchList); searchList.setLayoutManager(new LinearLayoutManager(this));
        searchAdapter=new SearchAdapter(searchItems,x->playQueue(new ArrayList<>(searchItems), Math.max(0,searchItems.indexOf(x)))); searchList.setAdapter(searchAdapter);
        RecyclerView queueList=findViewById(R.id.queueList); queueList.setLayoutManager(new LinearLayoutManager(this));
        queueAdapter=new SearchAdapter(queueItems,x->jumpToQueueItem(Math.max(0,queueItems.indexOf(x)))); queueList.setAdapter(queueAdapter);
        RecyclerView detailList=findViewById(R.id.detailList); detailList.setLayoutManager(new LinearLayoutManager(this));
        detailAdapter=new SearchAdapter(detailItems,x->playQueue(new ArrayList<>(detailItems),Math.max(0,detailItems.indexOf(x)))); detailList.setAdapter(detailAdapter);

        navHome.setOnClickListener(v->tab(0)); navSearch.setOnClickListener(v->tab(1)); navQueue.setOnClickListener(v->tab(2)); navAccount.setOnClickListener(v->{tab(4);loadProfile();});
        findViewById(R.id.searchBtn).setOnClickListener(v->search());
        searchInput.setOnEditorActionListener((v,action,event)->{if(action==EditorInfo.IME_ACTION_SEARCH){search();return true;}return false;});
        int[] quick={R.id.quickSertanejo,R.id.quickForro,R.id.quickPagode,R.id.quickGospel,R.id.quickFunk}; String[] qq={"Sertanejo lançamentos","Forró mais tocadas","Pagode sucessos","Gospel atual","Funk viral"}; for(int i=0;i<quick.length;i++){final String q=qq[i];findViewById(quick[i]).setOnClickListener(v->{searchInput.setText(q);search();});}
        findViewById(R.id.logout).setOnClickListener(v->{getSharedPreferences("auth",MODE_PRIVATE).edit().clear().apply();startActivity(new Intent(this,LoginActivity.class));finish();});
        playPause.setOnClickListener(v->toggle());
        previousBtn.setOnClickListener(v->{if(controller!=null&&controller.hasPreviousMediaItem())controller.seekToPreviousMediaItem();});
        nextBtn.setOnClickListener(v->{if(controller!=null&&controller.hasNextMediaItem())controller.seekToNextMediaItem();});
        queuePlayPause.setOnClickListener(v->toggle()); queueNextBtn.setOnClickListener(v->{if(controller!=null&&controller.hasNextMediaItem())controller.seekToNextMediaItem();});
        findViewById(R.id.detailBack).setOnClickListener(v->tab(0));
        detailPlay.setOnClickListener(v->playQueue(new ArrayList<>(detailItems),0));
        detailShuffle.setOnClickListener(v->{boolean old=shuffleEnabled;shuffleEnabled=true;playQueue(new ArrayList<>(detailItems),0);shuffleEnabled=old;});
        shuffleBtn.setOnClickListener(v->toggleShuffle());
        findViewById(R.id.miniPlayer).setOnClickListener(v->tab(2));
        requestNotificationPermission(); connectPlayer(); loadBanners(); loadHome(); loadProfile(); heartbeatHandler.post(heartbeatTask);
    }

    private void requestNotificationPermission(){
        if(android.os.Build.VERSION.SDK_INT>=33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS);
    }

    private void connectPlayer(){
        SessionToken token=new SessionToken(this,new ComponentName(this,PlaybackService.class));
        controllerFuture=new MediaController.Builder(this,token).buildAsync();
        controllerFuture.addListener(()->{
            try{
                controller=controllerFuture.get();
                controller.addListener(new Player.Listener(){
                    @Override public void onIsPlayingChanged(boolean isPlaying){runOnUiThread(()->{playPause.setText(isPlaying?"Ⅱ":"▶"); queuePlayPause.setText(isPlaying?"Ⅱ":"▶");});}
                    @Override public void onMediaMetadataChanged(MediaMetadata m){runOnUiThread(()->updateNowPlaying(m));}
                    @Override public void onMediaItemTransition(MediaItem item,int reason){runOnUiThread(()->updateQueueStatus());}
                    @Override public void onPlaybackStateChanged(int state){runOnUiThread(()->updateQueueStatus());}
                });
                updateNowPlaying(controller.getMediaMetadata());
                playPause.setText(controller.isPlaying()?"Ⅱ":"▶"); queuePlayPause.setText(controller.isPlaying()?"Ⅱ":"▶");
                updateQueueStatus();
            }catch(Exception e){Toast.makeText(this,"Falha ao iniciar o player",Toast.LENGTH_SHORT).show();}
        },ContextCompat.getMainExecutor(this));
    }

    void updateNowPlaying(MediaMetadata m){
        if(m.title!=null)nowTitle.setText(m.title);
        if(m.artist!=null)nowSub.setText(m.artist);
        if(m.artworkUri!=null)Glide.with(this).load(m.artworkUri).into(nowThumb);
    }

    void updateQueueStatus(){
        if(controller==null){queueStatus.setText("Player iniciando...");return;}
        int total=controller.getMediaItemCount(); int current=controller.getCurrentMediaItemIndex();
        queueStatus.setText(total==0?"A fila está vazia.":"Tocando "+(current+1)+" de "+total+(shuffleEnabled?" • Aleatório ativado":""));
    }

    void tab(int selected){
        homeTab.setVisibility(selected==0?View.VISIBLE:View.GONE);
        searchTab.setVisibility(selected==1?View.VISIBLE:View.GONE);
        queueTab.setVisibility(selected==2?View.VISIBLE:View.GONE);
        detailTab.setVisibility(selected==3?View.VISIBLE:View.GONE);
        accountTab.setVisibility(selected==4?View.VISIBLE:View.GONE);
        navHome.setTextColor(getColor(selected==0?R.color.green:R.color.muted));
        navSearch.setTextColor(getColor(selected==1?R.color.green:R.color.muted));
        navQueue.setTextColor(getColor(selected==2?R.color.green:R.color.muted));
        navAccount.setTextColor(getColor(selected==4?R.color.green:R.color.muted));
        if(selected==2)updateQueueStatus();
    }

    void loadBanners(){new Thread(()->{try{JSONArray a=new JSONObject(Net.get(BuildConfig.PANEL_URL+"/api/banners.php")).optJSONArray("banners");if(a==null)return;runOnUiThread(()->{bannerBox.removeAllViews();for(int i=0;i<a.length();i++){JSONObject b=a.optJSONObject(i);if(b==null)continue;LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(10,10,10,10);int w=getResources().getDisplayMetrics().widthPixels-dp(32);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(w,dp(190));cp.setMargins(dp(8),0,dp(8),0);card.setLayoutParams(cp);card.setBackgroundResource(R.drawable.card);ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);card.addView(im,new LinearLayout.LayoutParams(-1,dp(140)));String image=b.optString("image"); if(!image.startsWith("http")){if(!image.startsWith("/"))image="/"+image;image=BuildConfig.PANEL_URL+image;} Glide.with(this).load(image).into(im);TextView t=new TextView(this);t.setText(b.optString("title"));t.setTextColor(Color.WHITE);t.setTextSize(17);t.setTypeface(null,1);t.setPadding(8,8,8,0);card.addView(t);bannerBox.addView(card);}});}catch(Exception ignored){}}).start();}

    void loadHome(){homeStatus.setText("Atualizando músicas e artistas...");new Thread(()->{try{JSONObject j=new JSONObject(Net.get(BuildConfig.PANEL_URL+"/api/music/home.php?refresh="+(System.currentTimeMillis()/600000)));JSONArray secs=j.optJSONArray("sections");runOnUiThread(()->renderSections(secs,j.optJSONArray("items"),j.optJSONArray("categories")));}catch(Exception e){runOnUiThread(()->homeStatus.setText("Falha ao carregar a API: "+e.getMessage()));}}).start();}

    void renderSections(JSONArray secs,JSONArray fallback,JSONArray categories){sectionsBox.removeAllViews();addCategoryBar(categories);int made=0;if(secs!=null)for(int i=0;i<secs.length();i++){JSONObject s=secs.optJSONObject(i);if(s==null)continue;JSONArray items=s.optJSONArray("items");if(items==null||items.length()==0)continue;addSection(s.optString("title","Músicas"),items);made++;}if(made==0&&fallback!=null&&fallback.length()>0){addSection("Músicas",fallback);made++;}homeStatus.setText(made>0?"Atualizado automaticamente":"A API automática não retornou músicas agora.");}

    void addCategoryBar(JSONArray categories){
        if(categories==null||categories.length()==0)return;
        TextView h=new TextView(this);h.setText("Explore por categoria");h.setTextColor(Color.WHITE);h.setTextSize(22);h.setTypeface(null,1);h.setPadding(dp(16),dp(20),dp(8),dp(10));sectionsBox.addView(h);
        HorizontalScrollView sv=new HorizontalScrollView(this);sv.setHorizontalScrollBarEnabled(false);
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setPadding(dp(12),0,dp(12),dp(8));sv.addView(row);
        for(int i=0;i<categories.length();i++){String name=categories.optString(i);if(name.isEmpty())continue;TextView chip=new TextView(this);chip.setText(name);chip.setTextColor(Color.WHITE);chip.setTextSize(15);chip.setTypeface(null,1);chip.setGravity(android.view.Gravity.CENTER);chip.setPadding(dp(18),dp(11),dp(18),dp(11));chip.setBackgroundResource(R.drawable.search_bg);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,dp(46));lp.setMargins(dp(4),0,dp(4),0);chip.setLayoutParams(lp);chip.setOnClickListener(v->{tab(1);searchInput.setText(name+" mais tocadas");search();});row.addView(chip);}
        sectionsBox.addView(sv,new LinearLayout.LayoutParams(-1,dp(58)));
    }

    void addSection(String title,JSONArray arr){
        ArrayList<MusicItem> playlist=new ArrayList<>();
        for(int i=0;i<arr.length();i++){JSONObject x=arr.optJSONObject(i);if(x!=null){MusicItem item=parse(x);if(!item.videoId.isEmpty()||!item.id.isEmpty())playlist.add(item);}}
        if(playlist.isEmpty())return;
        LinearLayout heading=new LinearLayout(this);heading.setOrientation(LinearLayout.HORIZONTAL);heading.setGravity(android.view.Gravity.CENTER_VERTICAL);heading.setPadding(dp(16),dp(23),dp(10),dp(10));
        TextView h=new TextView(this);h.setText(title);h.setTextColor(Color.WHITE);h.setTextSize(22);h.setTypeface(null,1);heading.addView(h,new LinearLayout.LayoutParams(0,-2,1));
        Button playAll=new Button(this);playAll.setText("▶ Tocar");playAll.setTextSize(12);playAll.setOnClickListener(v->playQueue(new ArrayList<>(playlist),0));heading.addView(playAll,new LinearLayout.LayoutParams(dp(92),dp(42)));sectionsBox.addView(heading);
        HorizontalScrollView sv=new HorizontalScrollView(this);sv.setHorizontalScrollBarEnabled(false);LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setPadding(dp(9),0,dp(9),0);sv.addView(row);
        int max=Math.min(playlist.size(),24);for(int i=0;i<max;i++){MusicItem item=playlist.get(i);final int index=i;LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(7),dp(4),dp(7),dp(4));ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);card.addView(im,new LinearLayout.LayoutParams(dp(140),dp(140)));Glide.with(this).load(item.thumb).into(im);TextView t=new TextView(this);t.setText(item.title);t.setTextColor(Color.WHITE);t.setTypeface(null,1);t.setMaxLines(1);card.addView(t,new LinearLayout.LayoutParams(dp(140),-2));TextView sub=new TextView(this);sub.setText(item.subtitle);sub.setTextColor(getColor(R.color.muted));sub.setMaxLines(1);card.addView(sub,new LinearLayout.LayoutParams(dp(140),-2));card.setOnClickListener(v->loadExpandedPlaylist(title));row.addView(card,new LinearLayout.LayoutParams(dp(154),dp(205)));}sectionsBox.addView(sv,new LinearLayout.LayoutParams(-1,dp(210)));
    }

    void loadExpandedPlaylist(String title){
        detailTitle.setText(title); detailStatus.setText("Carregando até 100 músicas..."); detailItems.clear(); detailAdapter.notifyDataSetChanged(); tab(3);
        new Thread(()->{try{JSONObject j=new JSONObject(Net.get(BuildConfig.PANEL_URL+"/api/music/search.php?q="+URLEncoder.encode(title+" músicas artistas sucessos","UTF-8")+"&limit=100&expanded=1"));JSONArray a=j.optJSONArray("items");ArrayList<MusicItem> n=new ArrayList<>();if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null){MusicItem item=parse(x);if(!item.videoId.isEmpty())n.add(item);}}runOnUiThread(()->{detailItems.clear();detailItems.addAll(n);detailAdapter.notifyDataSetChanged();detailStatus.setText(n.size()+" músicas • toque em uma faixa para começar");});}catch(Exception e){runOnUiThread(()->detailStatus.setText("Falha ao carregar músicas: "+e.getMessage()));}}).start();
    }

    void showPlaylist(String title, ArrayList<MusicItem> items){
        detailItems.clear(); detailItems.addAll(items); detailAdapter.notifyDataSetChanged();
        detailTitle.setText(title); detailStatus.setText(items.size()+" músicas • toque em uma faixa para começar");
        tab(3);
    }

    MusicItem parse(JSONObject x){String id=x.optString("id",x.optString("video_id"));return new MusicItem(id,x.optString("type","song"),x.optString("title"),x.optString("subtitle",x.optString("artist")),x.optString("thumbnail"),x.optString("video_id",id));}

    void search(){String q=searchInput.getText().toString().trim();if(q.isEmpty())return;getSharedPreferences("search",MODE_PRIVATE).edit().putString("last",q).apply();searchStatus.setText("Buscando músicas, artistas, álbuns e playlists...");new Thread(()->{try{JSONObject j=new JSONObject(Net.get(BuildConfig.PANEL_URL+"/api/music/search.php?q="+URLEncoder.encode(q,"UTF-8")+"&limit=50"));JSONArray a=j.optJSONArray("items");ArrayList<MusicItem> n=new ArrayList<>();if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null){MusicItem item=parse(x);if(!item.videoId.isEmpty())n.add(item);}}runOnUiThread(()->{searchItems.clear();searchItems.addAll(n);searchAdapter.notifyDataSetChanged();searchStatus.setText(n.size()+" músicas encontradas • toque em uma para tocar todas em sequência");});}catch(Exception e){runOnUiThread(()->searchStatus.setText("Erro: "+e.getMessage()));}}).start();}

    void playQueue(ArrayList<MusicItem> source,int startIndex){
        if(controller==null){Toast.makeText(this,"Player iniciando. Toque novamente.",Toast.LENGTH_SHORT).show();return;}
        if(source.isEmpty())return;
        ArrayList<MusicItem> ordered=new ArrayList<>(source);
        if(shuffleEnabled){MusicItem first=ordered.remove(Math.min(startIndex,ordered.size()-1));Collections.shuffle(ordered);ordered.add(0,first);startIndex=0;}
        queueItems.clear();queueItems.addAll(ordered);queueAdapter.notifyDataSetChanged();
        int generation=queueGeneration.incrementAndGet();
        final int selected=Math.max(0,Math.min(startIndex,ordered.size()-1));
        queueStatus.setText("Preparando fila com "+ordered.size()+" músicas...");
        new Thread(()->{
            ArrayList<MediaItem> resolved=new ArrayList<>();
            for(int i=0;i<ordered.size();i++){
                if(queueGeneration.get()!=generation)return;
                MusicItem x=ordered.get(i);
                try{
                    String id=x.videoId.isEmpty()?x.id:x.videoId;
                    JSONObject src=new JSONObject(Net.get(BuildConfig.PANEL_URL+"/api/music/source.php?id="+URLEncoder.encode(id,"UTF-8")));
                    String url=src.optString("stream_url"); String videoId=src.optString("video_id",id);
                    if(url.isEmpty())url=StreamResolver.resolveAudio(videoId);
                    MediaMetadata metadata=new MediaMetadata.Builder().setTitle(x.title).setArtist(x.subtitle).setArtworkUri(x.thumb.isEmpty()?null:Uri.parse(x.thumb)).build();
                    MediaItem mediaItem=new MediaItem.Builder().setUri(url).setMediaId(x.id).setMediaMetadata(metadata).build();
                    resolved.add(mediaItem);
                    final int count=resolved.size();
                    if(i==selected){
                        ArrayList<MediaItem> initial=new ArrayList<>(resolved);
                        int initialIndex=initial.size()-1;
                        runOnUiThread(()->{if(queueGeneration.get()!=generation)return;controller.setMediaItems(initial,initialIndex,0);controller.prepare();controller.play();updateQueueStatus();});
                    }else if(i>selected){
                        runOnUiThread(()->{if(queueGeneration.get()!=generation)return;controller.addMediaItem(mediaItem);updateQueueStatus();});
                    }
                }catch(Exception ignored){}
                if(resolved.size()>=100)break;
            }
            runOnUiThread(()->{if(queueGeneration.get()==generation){queueStatus.setText(controller.getMediaItemCount()+" músicas prontas na fila"+(shuffleEnabled?" • Aleatório":""));}});
        }).start();
    }



    void sendHeartbeat(){
        String user=getSharedPreferences("auth",MODE_PRIVATE).getString("user","");
        String device=getSharedPreferences("auth",MODE_PRIVATE).getString("device","");
        String token=getSharedPreferences("auth",MODE_PRIVATE).getString("token","");
        if(user.isEmpty()||device.isEmpty()||token.isEmpty())return;
        new Thread(()->{try{String body="user="+URLEncoder.encode(user,"UTF-8")+"&device="+URLEncoder.encode(device,"UTF-8")+"&token="+URLEncoder.encode(token,"UTF-8");Net.post(BuildConfig.PANEL_URL+"/api/status.php",body);}catch(Exception ignored){}}).start();
    }

    void loadProfile(){
        String user=getSharedPreferences("auth",MODE_PRIVATE).getString("user","");
        if(user.isEmpty())return;
        new Thread(()->{try{JSONObject j=new JSONObject(Net.get(BuildConfig.PANEL_URL+"/api/client_profile.php?user="+URLEncoder.encode(user,"UTF-8")));if(!j.optBoolean("ok"))return;String plan=j.optString("plan","Sem plano");int days=j.optInt("days_remaining",0);String exp=j.optString("expires","");String renew=j.optString("renew_url",BuildConfig.PANEL_URL);String name=j.optString("name",user);String status=j.optString("status","");String ref=j.optString("referral_code","");int bonus=j.optInt("referral_bonus_days",0);runOnUiThread(()->{planName.setText(plan);planExpiry.setText(days+" dias restantes • vence em "+exp);accountName.setText(name);accountUser.setText("Usuário: "+user);accountStatus.setText("Plano: "+plan+"\nStatus: "+status+"\nVencimento: "+exp+"\nDias restantes: "+days);accountReferral.setText("Código de indicação: "+ref+"\nBônus ganhos: "+bonus+" dias");renewBtn.setOnClickListener(v->openRenewal());});}catch(Exception ignored){}}).start();
    }

    void openRenewal(){
        new Thread(()->{try{JSONObject j=new JSONObject(Net.get(BuildConfig.PANEL_URL+"/api/plans.php"));JSONArray a=j.optJSONArray("plans");runOnUiThread(()->showPlanDialog(a));}catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Falha ao carregar planos: "+e.getMessage(),Toast.LENGTH_LONG).show());}}).start();
    }
    void showPlanDialog(JSONArray plans){
        if(plans==null||plans.length()==0){Toast.makeText(this,"Nenhum plano disponível",Toast.LENGTH_SHORT).show();return;}
        String[] labels=new String[plans.length()];for(int i=0;i<plans.length();i++){JSONObject p=plans.optJSONObject(i);labels[i]=p.optString("name")+" • R$ "+p.optString("price")+" • "+p.optInt("days")+" dias";}
        new AlertDialog.Builder(this).setTitle("Renovar assinatura").setSingleChoiceItems(labels,0,null).setPositiveButton("Continuar",(d,w)->{int pos=((AlertDialog)d).getListView().getCheckedItemPosition();JSONObject p=plans.optJSONObject(Math.max(0,pos));showGatewayDialog(p);}).setNegativeButton("Cancelar",null).show();
    }
    void showGatewayDialog(JSONObject plan){
        String[] gateways={"Mercado Pago • PIX","MisticPay • PIX"};
        new AlertDialog.Builder(this).setTitle(plan.optString("name")+" — R$ "+plan.optString("price")).setSingleChoiceItems(gateways,0,null).setPositiveButton("Gerar PIX",(d,w)->{int pos=((AlertDialog)d).getListView().getCheckedItemPosition();askPayerData(plan,pos==0?"mercadopago":"misticpay");}).setNegativeButton("Voltar",null).show();
    }
    void askPayerData(JSONObject plan,String gateway){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(20),dp(8),dp(20),0);
        EditText email=new EditText(this);email.setHint("E-mail");email.setInputType(android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);email.setText(getSharedPreferences("payer",MODE_PRIVATE).getString("email",""));box.addView(email);
        EditText doc=new EditText(this);doc.setHint("CPF ou CNPJ");doc.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);doc.setText(getSharedPreferences("payer",MODE_PRIVATE).getString("doc",""));box.addView(doc);
        new AlertDialog.Builder(this).setTitle("Dados para o PIX").setView(box).setPositiveButton("Gerar cobrança",(d,w)->createPix(plan,gateway,email.getText().toString().trim(),doc.getText().toString().trim())).setNegativeButton("Cancelar",null).show();
    }
    void createPix(JSONObject plan,String gateway,String email,String doc){
        String user=getSharedPreferences("auth",MODE_PRIVATE).getString("user","");String name=accountName.getText().toString();
        getSharedPreferences("payer",MODE_PRIVATE).edit().putString("email",email).putString("doc",doc).apply();
        Toast.makeText(this,"Gerando PIX...",Toast.LENGTH_SHORT).show();
        new Thread(()->{try{String body="user="+URLEncoder.encode(user,"UTF-8")+"&plan_id="+URLEncoder.encode(plan.optString("id"),"UTF-8")+"&gateway="+gateway+"&payer_name="+URLEncoder.encode(name,"UTF-8")+"&email="+URLEncoder.encode(email,"UTF-8")+"&document="+URLEncoder.encode(doc,"UTF-8");JSONObject j=new JSONObject(Net.post(BuildConfig.PANEL_URL+"/api/payment_create.php",body));if(!j.optBoolean("ok"))throw new Exception(j.optString("message"));runOnUiThread(()->showPixDialog(j));}catch(Exception e){runOnUiThread(()->new AlertDialog.Builder(this).setTitle("Não foi possível gerar o PIX").setMessage(e.getMessage()).setPositiveButton("OK",null).show());}}).start();
    }
    void showPixDialog(JSONObject payment){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(22),dp(8),dp(22),0);
        TextView amount=new TextView(this);amount.setText(payment.optString("plan")+"\nR$ "+payment.optString("amount"));amount.setTextColor(Color.WHITE);amount.setTextSize(22);amount.setTypeface(null,1);box.addView(amount);
        EditText code=new EditText(this);code.setText(payment.optString("pix_code"));code.setTextColor(Color.WHITE);code.setMinLines(4);code.setSelectAllOnFocus(true);box.addView(code);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("PIX gerado dentro do aplicativo").setView(box).setPositiveButton("Copiar código",null).setNeutralButton("Verificar pagamento",null).setNegativeButton("Fechar",null).create();
        dialog.setOnShowListener(x->{dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{ClipboardManager cm=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);cm.setPrimaryClip(ClipData.newPlainText("PIX",code.getText()));Toast.makeText(this,"Código PIX copiado",Toast.LENGTH_SHORT).show();});dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v->checkPayment(payment.optString("payment_id"),dialog));});dialog.show();
    }
    void checkPayment(String id,AlertDialog dialog){String user=getSharedPreferences("auth",MODE_PRIVATE).getString("user","");new Thread(()->{try{JSONObject j=new JSONObject(Net.get(BuildConfig.PANEL_URL+"/api/payment_status.php?id="+URLEncoder.encode(id,"UTF-8")+"&user="+URLEncoder.encode(user,"UTF-8")));runOnUiThread(()->{if(j.optBoolean("approved")){Toast.makeText(this,"Pagamento aprovado. Plano renovado!",Toast.LENGTH_LONG).show();dialog.dismiss();loadProfile();}else Toast.makeText(this,"Pagamento ainda pendente",Toast.LENGTH_SHORT).show();});}catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Falha ao verificar pagamento",Toast.LENGTH_SHORT).show());}}).start();}

    void jumpToQueueItem(int index){if(controller!=null&&index>=0&&index<controller.getMediaItemCount()){controller.seekToDefaultPosition(index);controller.play();}}
    void toggleShuffle(){shuffleEnabled=!shuffleEnabled;shuffleBtn.setText(shuffleEnabled?"🔀 ON":"🔀");shuffleBtn.setAlpha(shuffleEnabled?1f:.65f);updateQueueStatus();}
    void toggle(){if(controller==null)return;if(controller.isPlaying())controller.pause();else controller.play();}
    int dp(int v){return (int)(v*getResources().getDisplayMetrics().density);}

    @Override protected void onDestroy(){heartbeatHandler.removeCallbacks(heartbeatTask);if(controllerFuture!=null)MediaController.releaseFuture(controllerFuture);super.onDestroy();}
}
