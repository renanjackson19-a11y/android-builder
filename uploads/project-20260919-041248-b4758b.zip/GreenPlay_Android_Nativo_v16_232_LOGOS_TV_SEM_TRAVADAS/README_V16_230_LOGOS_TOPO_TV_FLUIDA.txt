GreenPlay v16.230 - logos completas, categorias no topo e navegação TV mais fluida

- Corrigido o corte que fazia apenas os 16 primeiros canais carregarem logo automaticamente no modo TV/TV Box.
- Todos os canais materializados agora solicitam sua respectiva logo, inclusive os adicionados depois do 16º.
- Ao trocar de categoria (Globo, SBT, Infantil etc.), a lista de canais volta imediatamente para o topo.
- Removido o recentramento animado da faixa horizontal de categorias a cada toque no controle. A faixa só se desloca quando o item realmente sai da área visível.
- Desativado smooth scrolling nas listas de canais/categorias do modo TV para reduzir tremidas e microtravadas no D-pad.
- O carregamento dos cards continua completo, mas em lotes menores e ligeiramente espaçados para reduzir picos de layout em TV Box mais fraca.
- Mantidas todas as correções das v16.228 e v16.229.
