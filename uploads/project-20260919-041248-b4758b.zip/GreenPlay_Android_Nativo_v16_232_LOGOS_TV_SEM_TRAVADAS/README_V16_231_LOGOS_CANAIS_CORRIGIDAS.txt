GreenPlay v16.231 - logos dos canais corrigidas

- Corrigido o carregamento de logos/capas das categorias de canais adicionadas.
- A lista agora tenta primeiro a logo original do canal (stream_icon/tvg_logo) e usa as logos enriquecidas/EPG apenas como fallback.
- Quando uma fonte de logo falha, o app tenta automaticamente as demais URLs disponíveis para o mesmo canal.
- URLs de logo com HTML entities, barras escapadas, url(...) ou URL totalmente codificada são normalizadas antes do download.
- No modo TV, os primeiros cards visíveis carregam imediatamente; os demais carregam ao receber foco, evitando entupir a fila de imagens com centenas de downloads e reduzindo microtravadas.
- A logo do EPG e a faixa de canais do fullscreen usam a mesma resolução robusta de múltiplas fontes.
- Mantidas as correções da v16.230: troca de categoria volta ao topo e navegação horizontal sem smooth scroll.
