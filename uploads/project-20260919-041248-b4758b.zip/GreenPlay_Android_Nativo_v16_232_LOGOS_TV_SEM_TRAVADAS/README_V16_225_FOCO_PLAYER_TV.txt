GreenPlay v16.225 - foco visivel no controle do player da TV

- Ao navegar com o controle remoto, o item selecionado recebe borda verde forte.
- O foco tambem ganha leve zoom e elevacao para ficar evidente.
- A faixa preta dos controles permanece visivel enquanto existe foco nela.
- Voltar 10s, play/pause, avancar 10s, Zoom/Ajustar/Preencher e barra de progresso mantem o foco visivel.
- Vale para filmes e series porque ambos usam o mesmo PlayerActivity.
- Mantidas todas as correcoes anteriores.
