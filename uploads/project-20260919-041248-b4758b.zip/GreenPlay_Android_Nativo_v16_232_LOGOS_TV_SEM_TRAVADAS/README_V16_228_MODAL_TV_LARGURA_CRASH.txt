GreenPlay v16.228 - painel Assistir/Baixar TV + estabilidade

- Corrige o fechamento do app logo depois de abrir o painel de ações no modo TV/TV Box.
- Remove a troca insegura de LayoutParams do conteúdo do Dialog, que podia causar ClassCastException durante o layout.
- No modo TV, o painel de ações passa a usar uma janela realmente fullscreen, eliminando as margens laterais impostas pelo tema padrão de Dialog.
- Remove padding lateral do host no modo TV para o cartão preencher toda a largura disponível.
- Filmes e episódios usam a mesma correção.
- Mantidas as correções anteriores da v16.227.
