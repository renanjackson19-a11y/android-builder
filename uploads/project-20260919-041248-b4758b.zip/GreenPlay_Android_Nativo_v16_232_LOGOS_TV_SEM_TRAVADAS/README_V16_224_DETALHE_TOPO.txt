GreenPlay v16.224 - detalhe sempre abre no topo

- Corrige o caso em que a tela de detalhes abria ja rolada para baixo.
- O banner/hero, voltar e favorito ficam visiveis desde o primeiro frame.
- O foco inicial na TV fica no botao voltar, sem empurrar a tela ate Assistir.
- Mantidas todas as correcoes da v16.223 e v16.222.
