GreenPlay v16.223 - detalhes TV corrigidos

- Ao abrir detalhes na TV, a tela de categorias/grid fica totalmente oculta.
- A tela de detalhes agora tem fundo opaco e fica na frente do conteúdo anterior.
- Ao voltar, a tela anterior é restaurada corretamente.
- Mantidas todas as correções da v16.222: categorias completas, filmes/séries sem limite, canais completos, EPG e loading.
