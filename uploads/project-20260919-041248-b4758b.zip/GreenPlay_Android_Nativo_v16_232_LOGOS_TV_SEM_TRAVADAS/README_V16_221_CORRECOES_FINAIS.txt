GreenPlay v16.221 - correcoes finais

- Loading unico no inicio e na troca celular/TV.
- Categorias da TV fixas a esquerda com rolagem independente.
- Grid de capas usando melhor a largura da TV.
- Favoritos e Downloads centralizados.
- Player TV corrigido para evitar lateral preta temporaria.
- Menu TV, Destaque, Filmes, Series e Favoritos maior.
