GreenPlay v16.232 - logos dos canais + navegação TV sem microtravadas

Base: v16.231 completa.

Correções desta versão:

1. Logos/capas dos canais na lista da TV
- Corrigida a causa principal da lista ficar com o quadro da logo vazio.
- A tela estava mostrando primeiro o snapshot completo/enriquecido (com logos/EPG), mas depois refazia a lista com get_channel e substituía os canais enriquecidos por uma resposta mais simples.
- Quando o snapshot completo existe, ele agora é mantido como fonte principal e não é sobrescrito logo depois.
- Se for necessário usar get_channel como fallback, os canais retornados são mesclados com o snapshot em memória para recuperar logo, tvg-id, aliases, EPG e outros metadados que estiverem faltando.
- A resolução da logo agora procura também campos aninhados (source/raw/metadata/channel/stream/xtream/provider/epg/original/attributes/logos/images/logo_sources/logo_candidates/icons).
- Removida a regra antiga que só solicitava logo automaticamente para os primeiros canais da lista.
- Cards visíveis e próximos da tela carregam suas logos automaticamente; o foco também garante a solicitação da logo.
- Enquanto a logo remota ainda não chegou, o card usa um ícone de TV neutro em vez de ficar com um quadrado preto vazio.

2. Travadas/tremedeira ao navegar com o controle
- A lista completa de dados continua sem limite, mas os Views dos canais são materializados progressivamente conforme o usuário se aproxima do fim da parte já exibida.
- Isso evita criar centenas de cards de uma vez enquanto o player está tocando.
- As logos usam uma fila própria limitada, evitando várias decodificações simultâneas competindo com o vídeo e o D-pad.
- Removido o requestRectangleOnScreen forçado em cada mudança de foco de canal; o ScrollView faz o deslocamento natural do foco.
- Consulta individual de EPG foi atrasada para só disparar quando o foco realmente permanece no canal, reduzindo chamadas enquanto o usuário passa rápido pela lista.
- A lista não é reconstruída uma segunda vez quando o snapshot completo já foi carregado, eliminando um pico importante de layout durante a navegação.

3. Canais sem limitação
- O array completo da categoria continua em memória.
- Não existe teto de 16/20/300 canais: os cards seguintes são acrescentados antes de o foco chegar ao fim, e o scroll também aciona os próximos lotes.
- Mantida a correção que volta a lista ao topo ao trocar de categoria.

Versão: 1.16.232.0
versionCode: 243
