GreenPlay v16.227 - modal TV com largura total

- Corrige o espaço vazio lateral no painel Assistir/Baixar do modo TV/TV Box.
- A janela de ações agora usa a tela inteira como host e o cartão ocupa toda a largura útil.
- Filmes e episódios usam o mesmo ajuste.
- Mantido o foco verde do controle remoto no player e todas as correções anteriores.
