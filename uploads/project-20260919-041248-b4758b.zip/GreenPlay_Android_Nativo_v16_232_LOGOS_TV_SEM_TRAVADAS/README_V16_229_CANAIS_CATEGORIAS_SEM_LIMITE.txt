GreenPlay v16.229 - canais completos em todas as categorias

- Removida a dependencia do foco para liberar novos canais no modo TV/TV Box.
- Cada categoria agora materializa automaticamente todos os canais retornados pela fonte, em lotes apenas para preservar a fluidez da interface.
- Corrigida a paginacao de get_channel: o offset agora avanca pela quantidade realmente retornada pelo servidor, evitando saltos quando o backend limita o tamanho de cada lote.
- Protegida a troca entre cache rapido e resposta completa para evitar mistura/duplicacao de listas antigas ao trocar categoria.
- Mantidas as correcoes da v16.228 para o modal Assistir/Baixar e estabilidade.
