package com.spotnet.music;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_splash);
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            boolean logged = getSharedPreferences("auth", MODE_PRIVATE).getBoolean("ok", false);
            startActivity(new Intent(this, logged ? MainActivity.class : LoginActivity.class));
            finish();
        }, 2200);
    }
}
