package com.spotnet.music;

import android.content.ComponentName;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.Player;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionToken;
import com.bumptech.glide.Glide;
import com.google.common.util.concurrent.ListenableFuture;

public class PlayerActivity extends AppCompatActivity {
    private MediaController controller;
    private ListenableFuture<MediaController> future;
    private ImageView cover;
    private TextView title, artist, elapsed, duration;
    private ImageButton play, repeat, shuffle;
    private SeekBar seek;
    private final Runnable tick = new Runnable(){ public void run(){
        if(controller!=null){
            long p=Math.max(0,controller.getCurrentPosition()), d=Math.max(0,controller.getDuration());
            seek.setMax((int)Math.min(Integer.MAX_VALUE,d)); seek.setProgress((int)Math.min(Integer.MAX_VALUE,p));
            elapsed.setText(time(p)); duration.setText(time(d));
        }
        seek.postDelayed(this,500);
    }};
    @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_player);
        cover=findViewById(R.id.playerCover);title=findViewById(R.id.playerTitle);artist=findViewById(R.id.playerArtist);
        elapsed=findViewById(R.id.elapsed);duration=findViewById(R.id.duration);play=findViewById(R.id.playerPlay);
        repeat=findViewById(R.id.repeat);shuffle=findViewById(R.id.shuffle);seek=findViewById(R.id.seek);
        findViewById(R.id.closePlayer).setOnClickListener(v->finish());
        SessionToken token=new SessionToken(this,new ComponentName(this,PlaybackService.class));
        future=new MediaController.Builder(this,token).buildAsync();
        future.addListener(()->{try{controller=future.get();bind();controller.addListener(new Player.Listener(){
            @Override public void onIsPlayingChanged(boolean v){play.setImageResource(v?android.R.drawable.ic_media_pause:android.R.drawable.ic_media_play);}
            @Override public void onMediaMetadataChanged(MediaMetadata m){show(m);}
        });seek.post(tick);}catch(Exception ignored){}}, ContextCompat.getMainExecutor(this));
        play.setOnClickListener(v->{if(controller!=null){if(controller.isPlaying())controller.pause();else controller.play();}});
        findViewById(R.id.previous).setOnClickListener(v->{if(controller!=null)controller.seekToPreviousMediaItem();});
        findViewById(R.id.next).setOnClickListener(v->{if(controller!=null)controller.seekToNextMediaItem();});
        repeat.setOnClickListener(v->{if(controller!=null){int n=controller.getRepeatMode()==Player.REPEAT_MODE_ONE?Player.REPEAT_MODE_OFF:Player.REPEAT_MODE_ONE;controller.setRepeatMode(n);repeat.setAlpha(n==Player.REPEAT_MODE_ONE?1f:.45f);}});
        shuffle.setOnClickListener(v->{if(controller!=null){boolean n=!controller.getShuffleModeEnabled();controller.setShuffleModeEnabled(n);shuffle.setAlpha(n?1f:.45f);}});
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean from){if(from&&controller!=null)controller.seekTo(p);}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});
    }
    private void bind(){show(controller.getMediaMetadata());play.setImageResource(controller.isPlaying()?android.R.drawable.ic_media_pause:android.R.drawable.ic_media_play);}
    private void show(MediaMetadata m){title.setText(m.title==null?"Escolha uma música":m.title);artist.setText(m.artist==null?"Spotnet Music":m.artist);if(m.artworkUri!=null)Glide.with(this).load(m.artworkUri).into(cover);}
    private String time(long ms){if(ms<0)return "0:00";long s=ms/1000;return String.format("%d:%02d",s/60,s%60);}
    @Override protected void onDestroy(){seek.removeCallbacks(tick);if(future!=null)MediaController.releaseFuture(future);super.onDestroy();}
}
