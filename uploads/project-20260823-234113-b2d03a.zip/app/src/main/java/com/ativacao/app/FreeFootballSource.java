package com.ativacao.app;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class FreeFootballSource {
    private static final ExecutorService IO=Executors.newSingleThreadExecutor();
    static void load(ApiClient.Callback<List<ApiClient.FootballMatch>> cb){
        IO.execute(()->{
            try{
                ArrayList<ApiClient.FootballMatch> out=new ArrayList<>();
                String day=new SimpleDateFormat("yyyyMMdd",Locale.US).format(new Date());
                String[] leagues={"bra.1","eng.1","esp.1","ger.1","ita.1","fra.1","uefa.champions","uefa.europa"};
                for(String league:leagues){
                    try{parseEspn(get("https://site.api.espn.com/apis/site/v2/sports/soccer/"+league+"/scoreboard?dates="+day),out);}catch(Exception ignored){}
                }
                // Backup: open public-domain fixtures. Never leave the football page blank when a feed is temporarily unavailable.
                if(out.isEmpty()){
                    String[] seasons={"2026-27","2025-26"};
                    String[] files={"en.1.json","es.1.json","de.1.json","it.1.json","fr.1.json","pt.1.json"};
                    for(String season:seasons) for(String file:files){
                        try{parseOpenFootball(get("https://raw.githubusercontent.com/openfootball/football.json/master/"+season+"/"+file),out);}catch(Exception ignored){}
                        if(out.size()>=18) break;
                    }
                }
                cb.ok(out);
            }catch(Exception e){cb.error(e.getMessage()==null?"erro de rede":e.getMessage());}
        });
    }
    private static void parseEspn(String raw,List<ApiClient.FootballMatch> out)throws Exception{
        JSONObject root=new JSONObject(raw);JSONArray events=root.optJSONArray("events");if(events==null)return;
        for(int i=0;i<events.length();i++){
            JSONObject ev=events.optJSONObject(i);if(ev==null)continue;JSONArray comps=ev.optJSONArray("competitions");if(comps==null||comps.length()==0)continue;
            JSONObject comp=comps.optJSONObject(0);JSONArray teams=comp.optJSONArray("competitors");if(teams==null||teams.length()<2)continue;
            JSONObject home=null,away=null;for(int j=0;j<teams.length();j++){JSONObject t=teams.optJSONObject(j);if(t==null)continue;if("home".equals(t.optString("homeAway")))home=t;else if("away".equals(t.optString("homeAway")))away=t;}
            if(home==null||away==null)continue;
            ApiClient.FootballMatch m=new ApiClient.FootballMatch();
            JSONObject lg=root.optJSONObject("leagues")==null?null:root.optJSONArray("leagues").optJSONObject(0);m.league=lg==null?"Futebol":lg.optString("name","Futebol");
            m.home=teamName(home);m.away=teamName(away);m.homeLogo=teamLogo(home);m.awayLogo=teamLogo(away);
            String hs=home.optString("score","");String as=away.optString("score","");if(!hs.isEmpty()&&!as.isEmpty())m.score=hs+" - "+as;
            JSONObject st=ev.optJSONObject("status");JSONObject typ=st==null?null:st.optJSONObject("type");m.status=typ==null?"Agendado":typ.optString("shortDetail",typ.optString("description","Agendado"));
            m.clock=st==null?"":st.optString("displayClock","");m.date=ev.optString("date","");out.add(m);
        }
    }
    private static String teamName(JSONObject c){JSONObject t=c.optJSONObject("team");return t==null?"Time":t.optString("displayName",t.optString("name","Time"));}
    private static String teamLogo(JSONObject c){JSONObject t=c.optJSONObject("team");return t==null?"":t.optString("logo","");}
    private static void parseOpenFootball(String raw,List<ApiClient.FootballMatch> out)throws Exception{
        JSONObject root=new JSONObject(raw);String league=root.optString("name","Futebol");JSONArray a=root.optJSONArray("matches");if(a==null)return;
        String today=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());
        for(int i=0;i<a.length()&&out.size()<18;i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;String date=o.optString("date","");if(date.compareTo(today)<0)continue;ApiClient.FootballMatch m=new ApiClient.FootballMatch();m.league=league;m.date=date;m.home=team(o.opt("team1"));m.away=team(o.opt("team2"));m.clock=o.optString("time","");m.status=date.equals(today)?"Hoje":date;out.add(m);}
    }
    private static String team(Object x){if(x instanceof String)return (String)x;if(x instanceof JSONObject)return ((JSONObject)x).optString("name","Time");return "Time";}
    private static String get(String u)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(9000);c.setRequestProperty("User-Agent","DubaiPlayTV/4.0.13");BufferedReader b=new BufferedReader(new InputStreamReader(c.getInputStream()));StringBuilder s=new StringBuilder();String l;while((l=b.readLine())!=null)s.append(l);b.close();return s.toString();}
}
