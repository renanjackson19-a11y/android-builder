package com.ativacao.app;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class FreeFootballSource {
    private static final ExecutorService IO=Executors.newSingleThreadExecutor();
    static void load(ApiClient.Callback<List<ApiClient.FootballMatch>> cb){
        IO.execute(()->{
            try{
                ArrayList<ApiClient.FootballMatch> out=new ArrayList<>();
                // Public-domain OpenFootball JSON. Current season; no API key.
                String[] urls={
                    "https://raw.githubusercontent.com/openfootball/football.json/master/2025-26/en.1.json",
                    "https://raw.githubusercontent.com/openfootball/football.json/master/2025-26/es.1.json",
                    "https://raw.githubusercontent.com/openfootball/football.json/master/2025-26/de.1.json"
                };
                for(String u:urls){try{parse(get(u),out);}catch(Exception ignored){}}
                cb.ok(out);
            }catch(Exception e){cb.error(e.getMessage()==null?"erro de rede":e.getMessage());}
        });
    }
    private static void parse(String raw,List<ApiClient.FootballMatch> out)throws Exception{
        JSONObject root=new JSONObject(raw);String league=root.optString("name","Futebol");
        JSONArray a=root.optJSONArray("matches");if(a==null)return;
        String today=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());
        for(int i=0;i<a.length();i++){
            JSONObject o=a.optJSONObject(i);if(o==null)continue;
            String date=o.optString("date","");
            // Include today's games; if dataset has none today, include upcoming few later via second pass behavior below.
            if(!today.equals(date))continue;
            ApiClient.FootballMatch m=new ApiClient.FootballMatch();
            m.league=league;m.date=date;m.home=team(o.opt("team1"));m.away=team(o.opt("team2"));
            JSONObject sc=o.optJSONObject("score");
            if(sc!=null){JSONArray ft=sc.optJSONArray("ft");if(ft!=null&&ft.length()>=2)m.score=ft.optString(0)+" - "+ft.optString(1);}
            m.status=m.score.isEmpty()?"Agendado":"Finalizado";out.add(m);
        }
        if(out.isEmpty()){
            for(int i=0;i<a.length()&&out.size()<12;i++){
                JSONObject o=a.optJSONObject(i);if(o==null)continue;String date=o.optString("date","");
                if(date.compareTo(today)<0)continue;
                ApiClient.FootballMatch m=new ApiClient.FootballMatch();m.league=league;m.date=date;m.home=team(o.opt("team1"));m.away=team(o.opt("team2"));m.status=date;out.add(m);
            }
        }
    }
    private static String team(Object x){
        if(x instanceof String)return (String)x;
        if(x instanceof JSONObject)return ((JSONObject)x).optString("name","Time");
        return "Time";
    }
    private static String get(String u)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(9000);c.setRequestProperty("User-Agent","DubaiPlayTV/4.0.6");
        BufferedReader b=new BufferedReader(new InputStreamReader(c.getInputStream()));StringBuilder s=new StringBuilder();String l;while((l=b.readLine())!=null)s.append(l);b.close();return s.toString();
    }
}