package com.ativacao.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.role.RoleManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.PackageInfo;
import android.content.pm.Signature;
import android.content.pm.ResolveInfo;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.ColorFilter;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.util.Base64;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.GridLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;

public class LauncherActivity extends Activity {
    private final android.os.Handler handler = new android.os.Handler(android.os.Looper.getMainLooper());
    private JSONObject state;
    private boolean syncing=false;
    private volatile boolean foreground=false;
    private volatile boolean configApplying=false;
    private static final int REQ_REMOTE_INSTALL=8401;
    private static final int REQ_REMOTE_UNINSTALL=8402;
    private long pendingRemoteCommandId=0L;
    private String pendingRemotePackage="";
    private String pendingRemoteAction="";
    private String pendingRemoteToken="";
    private static final long LIVE_SYNC_MS=10000L;
    private static final long INVENTORY_SYNC_MS=120000L;
    private long lastInventorySyncAt=0L;
    private long updatePromptedCode=0L;
    private JSONArray promoBanners;
    private int promoIndex=0;
    private ImageView promoImageView;
    private TextView promoCounterView;
    private boolean internalSettingsOpen=false;
    private boolean defaultLauncherGateOpen=false;
    private long lastHomeRequestAt=0L;
    private final Runnable promoTick = new Runnable(){
        @Override public void run(){
            try{
                if(promoBanners!=null && promoBanners.length()>1 && promoImageView!=null){
                    promoIndex=(promoIndex+1)%promoBanners.length();
                    showPromoBanner();
                    handler.postDelayed(this,6000L);
                }
            }catch(Exception ignored){}
        }
    };
    private int primary=Color.rgb(233,31,53);
    private String launcherLayout="cinema";
    private final int BG=Color.rgb(10,10,14);
    private final int CARD=Color.rgb(24,24,32);
    private final int TEXT=Color.rgb(248,248,250);
    private final int MUTED=Color.rgb(180,180,195);
    private TextView clockView;
    private TextView dateView;
    private TextView networkView;
    private final Runnable clockTick = new Runnable(){
        @Override public void run(){ updateClock(); handler.postDelayed(this,30000L); }
    };
    private final Runnable syncWatch = new Runnable(){
        @Override public void run(){
            try{
                if(LauncherStore.isActivationComplete(LauncherActivity.this) && isTvBoxDevice() && isOnline() && !syncing){
                    if(System.currentTimeMillis()-LauncherStore.getLastSync(LauncherActivity.this) >= LIVE_SYNC_MS-500L) syncLauncher();
                }
            }catch(Exception ignored){}
            handler.postDelayed(this,LIVE_SYNC_MS);
        }
    };

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        if(isTv()) setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        if(DeviceControl.isDeviceOwner(this)) DeviceControl.enforceManagedState(this);
        renderBoot();
    }
    @Override protected void onResume(){
        super.onResume();
        foreground=true;
        if(DeviceControl.isDeviceOwner(this)) DeviceControl.enforceManagedState(this);
        if(!LauncherStore.isActivationComplete(this)){openActivator(false);return;}
        if(!isTvBoxDevice()){openActivator(true);finish();return;}
        if(isLauncherRequired()&&!isDefaultHome()){renderDefaultLauncherGate();return;}
        defaultLauncherGateOpen=false;
        if(isOnline()) syncLauncher(); else renderCachedOffline();
    }
    @Override protected void onPause(){
        foreground=false;
        handler.removeCallbacks(clockTick);
        handler.removeCallbacks(promoTick);
        // Mantém a consulta rápida viva enquanto o UniTV estiver aberto.
        // Assim o Device Owner pode bloquear/liberar somente o UniTV em poucos segundos.
        handler.removeCallbacks(syncWatch); handler.postDelayed(syncWatch,LIVE_SYNC_MS);
        super.onPause();
    }
    @Override protected void onDestroy(){
        handler.removeCallbacks(clockTick);
        handler.removeCallbacks(syncWatch);
        handler.removeCallbacks(promoTick);
        super.onDestroy();
    }

    @Override public boolean dispatchKeyEvent(KeyEvent event){
        if(defaultLauncherGateOpen){
            int key=event.getKeyCode();
            boolean confirm=key==KeyEvent.KEYCODE_DPAD_CENTER || key==KeyEvent.KEYCODE_ENTER || key==KeyEvent.KEYCODE_NUMPAD_ENTER;
            if(confirm){
                if(event.getAction()==KeyEvent.ACTION_UP) requestDefaultHome();
                return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }

    @Override public void onBackPressed(){
        if(internalSettingsOpen){
            internalSettingsOpen=false;
            if(state!=null) renderState(state,!isOnline()); else renderCachedOrLoading();
            return;
        }
        if(LauncherStore.isActivationComplete(this) && isLauncherRequired() && !isDefaultHome()){
            renderDefaultLauncherGate();
            return;
        }
        if(LauncherStore.isActivationComplete(this) && isDefaultHome()) return;
        super.onBackPressed();
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==901 || requestCode==902){
            verifyDefaultHomeAfterRequest();
            return;
        }
        if(requestCode==REQ_REMOTE_INSTALL || requestCode==REQ_REMOTE_UNINSTALL){
            finishRemotePackageConfirmation(requestCode,resultCode);
        }
    }

    private boolean isTvBoxDevice(){
        if(LauncherStore.isTvBoxMode(this)) return true;
        try{String c=LauncherStore.getCachedJson(this);if(!c.isEmpty()){String t=new JSONObject(c).optString("app_target","");if(!t.isEmpty()){LauncherStore.setDeviceType(this,t);return "tv_box".equals(t);}}}catch(Exception ignored){}
        return false;
    }

    private boolean isLauncherRequired(){
        if(!isTvBoxDevice()) return false;
        try{String c=LauncherStore.getCachedJson(this);if(!c.isEmpty())return new JSONObject(c).optBoolean("launcher_required",true);}catch(Exception ignored){}
        return true;
    }


    private void renderBoot(){
        ScrollView s=baseScroll();LinearLayout root=container(s);title(root,"ATIVADOR + LAUNCHER","2 PAINÉIS EM 1 • Carregando sua Launcher...");ProgressBar p=new ProgressBar(this);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(54),dp(54));lp.gravity=Gravity.CENTER_HORIZONTAL;root.addView(p,lp);setContentView(s);
    }

    private boolean isDefaultHome(){
        try{Intent i=new Intent(Intent.ACTION_MAIN);i.addCategory(Intent.CATEGORY_HOME);ResolveInfo ri=getPackageManager().resolveActivity(i,PackageManager.MATCH_DEFAULT_ONLY);return ri!=null&&ri.activityInfo!=null&&getPackageName().equals(ri.activityInfo.packageName);}catch(Exception e){return false;}
    }

    private void requestDefaultHome(){
        long now=System.currentTimeMillis();
        if(now-lastHomeRequestAt<900L) return;
        lastHomeRequestAt=now;

        // 1) Device Owner: é o caminho mais forte e persistente do Android.
        try{
            if(DeviceControl.isDeviceOwner(this) && DeviceControl.setAsPersistentHome(this)){
                Toast.makeText(this,"Ativador Launcher aplicada como tela inicial.",Toast.LENGTH_SHORT).show();
                defaultLauncherGateOpen=false;
                launchSelfAsHome();
                verifyDefaultHomeAfterRequest();
                return;
            }
        }catch(Throwable ignored){}

        // 2) Root: cobre AOSP, projetores e várias boxes que escondem a tela de HOME.
        new Thread(()->{
            boolean rootHome=DeviceControl.trySetHomeWithRoot(this);
            runOnUiThread(()->{
                if(rootHome){
                    handler.postDelayed(()->{
                        if(isDefaultHome()){
                            Toast.makeText(this,"Ativador Launcher aplicada como tela inicial.",Toast.LENGTH_SHORT).show();
                            defaultLauncherGateOpen=false;
                            launchSelfAsHome();
                            if(isOnline())syncLauncher(); else renderCachedOffline();
                        }else{
                            requestDefaultHomeSystemOnly();
                        }
                    },900L);
                }else{
                    requestDefaultHomeSystemOnly();
                }
            });
        },"universal-home").start();
    }

    private void requestDefaultHomeSystemOnly(){
        // 3) Android 10+: papel oficial HOME, quando o fabricante disponibiliza.
        try{
            if(Build.VERSION.SDK_INT>=29){
                RoleManager rm=(RoleManager)getSystemService(Context.ROLE_SERVICE);
                if(rm!=null && rm.isRoleAvailable(RoleManager.ROLE_HOME)){
                    if(rm.isRoleHeld(RoleManager.ROLE_HOME)){
                        verifyDefaultHomeAfterRequest();
                        return;
                    }
                    Intent roleIntent=rm.createRequestRoleIntent(RoleManager.ROLE_HOME);
                    if(roleIntent.resolveActivity(getPackageManager())!=null){
                        startActivityForResult(roleIntent,901);
                        return;
                    }
                }
            }
        }catch(Throwable ignored){}

        // 4) Tela específica de HOME.
        try{
            Intent homeSettings=new Intent(Settings.ACTION_HOME_SETTINGS);
            if(homeSettings.resolveActivity(getPackageManager())!=null){
                startActivityForResult(homeSettings,902);
                return;
            }
        }catch(Throwable ignored){}

        try{
            Intent legacyHomeSettings=new Intent("android.settings.HOME_SETTINGS");
            if(legacyHomeSettings.resolveActivity(getPackageManager())!=null){
                startActivityForResult(legacyHomeSettings,902);
                return;
            }
        }catch(Throwable ignored){}

        // 5) Alguns Android TV/Xiaomi escondem HOME, mas expõem Apps padrão.
        try{
            Intent defaults=new Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS);
            if(defaults.resolveActivity(getPackageManager())!=null){
                Toast.makeText(this,"Abra App de início / Tela inicial e escolha Ativador Launcher.",Toast.LENGTH_LONG).show();
                startActivityForResult(defaults,902);
                return;
            }
        }catch(Throwable ignored){}

        // 6) Força o resolver de HOME em firmwares antigos quando ele existe.
        try{
            Intent home=new Intent(Intent.ACTION_MAIN);
            home.addCategory(Intent.CATEGORY_HOME);
            Intent chooser=Intent.createChooser(home,"Escolha Ativador Launcher como tela inicial");
            if(chooser.resolveActivity(getPackageManager())!=null){
                startActivityForResult(chooser,902);
                return;
            }
        }catch(Throwable ignored){}

        // 7) Último fallback: configurações gerais, sem ficar travando o botão.
        try{
            Toast.makeText(this,"Este Android não expôs a seleção de Home. Abrindo Configurações para concluir.",Toast.LENGTH_LONG).show();
            Intent settings=new Intent(Settings.ACTION_SETTINGS);
            if(settings.resolveActivity(getPackageManager())!=null){
                startActivityForResult(settings,902);
                return;
            }
        }catch(Throwable ignored){}

        Toast.makeText(this,"A troca automática de Home exige modo gerenciado (Device Owner) ou root neste firmware.",Toast.LENGTH_LONG).show();
        renderDefaultLauncherGate();
    }

    private void launchSelfAsHome(){
        try{
            Intent i=new Intent(this,LauncherActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(i);
        }catch(Throwable ignored){}
    }

    private void launchHomeIntent(){
        try{
            Intent home=new Intent(Intent.ACTION_MAIN);
            home.addCategory(Intent.CATEGORY_HOME);
            home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(home);
        }catch(Exception ignored){}
    }

    private void verifyDefaultHomeAfterRequest(){
        handler.postDelayed(()->{
            if(isDefaultHome()){
                defaultLauncherGateOpen=false;
                if(isOnline()) syncLauncher();
                else renderCachedOffline();
            }else{
                renderDefaultLauncherGate();
            }
        },700L);
    }

    private String currentHomePackage(){
        try{Intent i=new Intent(Intent.ACTION_MAIN);i.addCategory(Intent.CATEGORY_HOME);ResolveInfo ri=getPackageManager().resolveActivity(i,PackageManager.MATCH_DEFAULT_ONLY);return ri!=null&&ri.activityInfo!=null?ri.activityInfo.packageName:"não identificado";}catch(Exception e){return "não identificado";}
    }

    private void renderDefaultLauncherGate(){
        defaultLauncherGateOpen=true;
        ScrollView s=baseScroll();
        LinearLayout root=container(s);
        title(root,"CONFIGURAR LAUNCHER","Para continuar, o Ativador Launcher precisa ser a tela inicial padrão da TV Box.");
        String owner=DeviceControl.isDeviceOwner(this)?"SIM":"NÃO";
        TextView diag=info("HOME ATUAL: "+currentHomePackage()+"  •  MODO GERENCIADO: "+owner,false);
        root.addView(diag);
        TextView t=info("ETAPA OBRIGATÓRIA\n\nSelecione “Ativador Launcher” como Tela inicial / Home / Launcher padrão. Em projetores que bloqueiam essa seleção, o app tenta aplicar automaticamente pelo modo gerenciado e, se disponível, pelo acesso root.",true);
        root.addView(t);

        if(DeviceControl.isDeviceOwner(this)){
            DeviceControl.enforceManagedState(this);
            TextView managed=info(DeviceControl.isUninstallProtectionActive(this)
                    ? "PROTEÇÃO COMPLETA ATIVA • Launcher fixada como Home • desinstalação protegida pelo gerenciamento do Android."
                    : "Modo gerenciado detectado. Aplicando proteção do aplicativo...",true);
            root.addView(managed);
        }else{
            TextView note=info("Proteção contra desinstalação: para impedir a remoção de verdade, este aparelho precisa estar provisionado como Device Owner. Em modo comum o Android não concede essa permissão a aplicativos normais.",false);
            root.addView(note);
        }

        Button b=button("DEFINIR COMO LAUNCHER PADRÃO");
        root.addView(b,new LinearLayout.LayoutParams(-1,dp(68)));
        b.setFocusable(true);
        b.setFocusableInTouchMode(true);
        b.setOnClickListener(v->requestDefaultHome());
        b.setOnKeyListener((v,keyCode,event)->{
            boolean confirm=keyCode==KeyEvent.KEYCODE_DPAD_CENTER || keyCode==KeyEvent.KEYCODE_ENTER || keyCode==KeyEvent.KEYCODE_NUMPAD_ENTER;
            if(confirm){
                if(event.getAction()==KeyEvent.ACTION_UP) requestDefaultHome();
                return true;
            }
            return false;
        });
        setContentView(s);
        b.post(()->{ b.requestFocus(); b.requestFocusFromTouch(); });
    }

    private void syncLauncher(){
        if(syncing)return; syncing=true;String code=LauncherStore.getDeviceCode(this);if(code.isEmpty()){if(foreground)renderNoCode();syncing=false;return;} if(state==null&&foreground)renderCachedOrLoading();
        new Thread(()->{
            try{
                String before=LauncherStore.getCachedJson(this);
                String did=Settings.Secure.getString(getContentResolver(),Settings.Secure.ANDROID_ID);String model=Build.MANUFACTURER+" "+Build.MODEL;
                String url=Config.BASE_URL+"/api/launcher_sync.php?device_code="+enc(code)+"&device_id="+enc(did==null?"":did)+"&model="+enc(model)+"&android="+enc(String.valueOf(Build.VERSION.SDK_INT))+"&app_version="+enc(currentVersionName())+"&app_target="+enc(LauncherStore.getDeviceType(this))+"&default_launcher="+(isDefaultHome()?"1":"0")+"&device_owner="+(DeviceControl.isDeviceOwner(this)?"1":"0")+"&_ts="+System.currentTimeMillis();
                String json=httpGet(url);JSONObject o=new JSONObject(json);if(!"ok".equalsIgnoreCase(o.optString("status")))throw new Exception(o.optString("mensagem","Falha de sincronização."));
                String serverTarget=o.optString("app_target","");if(!serverTarget.isEmpty())LauncherStore.setDeviceType(this,serverTarget);
                boolean changed=!json.equals(before);
                LauncherStore.setCachedJson(this,json);state=o;applyPolicy(o);precachePromoBanners(o);syncOnlineInstalledApps(o);processPendingConfigCommand(o);if(o.optJSONObject("pending_config_command")==null)processPendingConfig(o);
                runOnUiThread(()->{if(foreground){maybePromptSelfUpdate(o);if(changed)renderState(o,false);}});
            }catch(Exception e){String c=LauncherStore.getCachedJson(this);try{if(!c.isEmpty()){JSONObject o=new JSONObject(c);state=o;applyOfflineExpiry(o);applyPolicy(o);if(foreground)runOnUiThread(()->renderState(o,true));}else if(foreground)runOnUiThread(()->renderOfflineEmpty(e.getMessage()));}catch(Exception x){if(foreground)runOnUiThread(()->renderOfflineEmpty(e.getMessage()));}}
            finally{syncing=false;}
        },"launcher-sync").start();
    }

    private void applyOfflineExpiry(JSONObject o){
        // Modo off-line fail-safe: nunca muda o estado do cliente localmente.
        // A Launcher conserva o último estado CONFIRMADO pelo painel.
        // Assim, queda de API, hospedagem ou domínio não bloqueia um cliente ativo.
    }
    private void applyPolicy(JSONObject o){String pkg=o.optString("unitv_package","").trim();boolean block=o.optBoolean("block_unitv",false);String msg=o.optString("message","");DeviceControl.applyUnitvPolicy(this,pkg,block,msg);if(DeviceControl.isDeviceOwner(this))DeviceControl.enforceManagedState(this);}

    private void renderCachedOrLoading(){String c=LauncherStore.getCachedJson(this);if(c.isEmpty()){renderBoot();return;}try{JSONObject o=new JSONObject(c);applyOfflineExpiry(o);renderState(o,!isOnline());}catch(Exception e){renderBoot();}}
    private void renderCachedOffline(){String c=LauncherStore.getCachedJson(this);try{JSONObject o=c.isEmpty()?localFallbackState():new JSONObject(c);state=o;applyOfflineExpiry(o);applyPolicy(o);renderState(o,true);}catch(Exception e){try{renderState(localFallbackState(),true);}catch(Exception ignored){renderOfflineEmpty("Não foi possível carregar a Launcher local.");}}}
    private JSONObject localFallbackState() throws Exception{JSONObject o=new JSONObject();o.put("status","ok");o.put("assigned",false);o.put("block_unitv",false);o.put("client_status","offline");o.put("device_code",LauncherStore.getDeviceCode(this));o.put("message","Sem conexão. A Launcher continuará usando o último estado confirmado quando houver dados locais.");o.put("app_target",LauncherStore.getDeviceType(this));o.put("launcher_required",isTvBoxDevice());o.put("offline_mode",true);o.put("sync_minutes",1);o.put("sync_seconds",4);JSONObject b=new JSONObject();b.put("business_name","UniTV");b.put("launcher_title","Ativador Launcher");b.put("primary_color","#e91f35");b.put("logo_url","");b.put("banner_url","");b.put("background_url","");b.put("support_whatsapp","");o.put("branding",b);o.put("promo_banners",new JSONArray());o.put("apps",new JSONArray());o.put("tutorials",new JSONArray());o.put("plans",new JSONArray());o.put("gateways",new JSONArray());return o;}
    private void renderNoCode(){ScrollView s=baseScroll();LinearLayout r=container(s);title(r,"ATIVAÇÃO NECESSÁRIA","Primeiro conclua a ativação e a instalação do UniTV.");Button b=button("ABRIR ATIVADOR");r.addView(b,new LinearLayout.LayoutParams(-1,dp(64)));b.setOnClickListener(v->openActivator(true));setContentView(s);}
    private void renderOfflineEmpty(String err){ScrollView s=baseScroll();LinearLayout r=container(s);title(r,"SEM CONEXÃO","A primeira sincronização da Launcher precisa de internet.");r.addView(info(err==null?"Conecte à internet e tente novamente.":err,true));Button b=button("TENTAR NOVAMENTE");r.addView(b,new LinearLayout.LayoutParams(-1,dp(64)));b.setOnClickListener(v->syncLauncher());setContentView(s);}

    private void renderState(JSONObject o,boolean offline){
        if(isLauncherRequired()&&!isDefaultHome()){renderDefaultLauncherGate();return;}
        JSONObject brand=o.optJSONObject("branding"); if(brand==null) brand=new JSONObject();
        String color=brand.optString("primary_color","#e91f35"); try{primary=Color.parseColor(color);}catch(Exception ignored){primary=Color.rgb(233,31,53);}
        launcherLayout=brand.optString("launcher_layout","cinema").trim().toLowerCase(Locale.ROOT);
        if(!(launcherLayout.equals("cinema")||launcherLayout.equals("classic")||launcherLayout.equals("minimal")||launcherLayout.equals("compact")||launcherLayout.equals("showcase")))launcherLayout="cinema";

        ScrollView s=baseScroll();
        String bg=brand.optString("background_url",""); if(bg.isEmpty())bg=brand.optString("banner_url",""); if(!bg.isEmpty()) loadBackground(s,bg);
        LinearLayout root=launcherContainer(s);
        renderLauncherTop(root,brand,offline,o);

        if(!o.optBoolean("assigned",false)){
            renderUnassigned(root,o,offline);
            renderPromoCarousel(root,o);
            renderInstalledApps(root,o);
            renderLauncherFooter(root,o,offline,brand);
            setContentView(s); startClock(); return;
        }

        renderPlanStrip(root,o,offline);
        renderPromoCarousel(root,o);
        renderInstalledApps(root,o);
        renderPanelAvailableApps(root,o);
        renderLauncherFooter(root,o,offline,brand);
        setContentView(s);
        startClock();
    }

    private void renderUnassigned(LinearLayout r,JSONObject o,boolean offline){String code=o.optString("device_code",LauncherStore.getDeviceCode(this));TextView h=info("ENVIE ESTE CÓDIGO PARA O SEU REVENDEDOR",true);r.addView(h);TextView c=new TextView(this);c.setText(code);c.setTextColor(Color.WHITE);c.setTextSize(42);c.setTypeface(Typeface.MONOSPACE,Typeface.BOLD);c.setGravity(Gravity.CENTER);c.setPadding(10,22,10,22);c.setBackground(border(Color.argb(220,25,25,34),primary,18,2));r.addView(c,new LinearLayout.LayoutParams(-1,-2));TextView d=info(offline?"Sem conexão. Assim que a internet voltar, a Launcher consultará o painel novamente.":"O revendedor entra no painel, informa este código e escolhe o seu plano. A tela libera automaticamente.",true);r.addView(d);Button b=button("ATUALIZAR LIBERAÇÃO");LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(64));lp.setMargins(0,dp(14),0,0);r.addView(b,lp);b.setOnClickListener(v->{if(isOnline())syncLauncher();else Toast.makeText(this,"Sem internet. A Launcher continua funcionando com os dados locais.",Toast.LENGTH_LONG).show();});b.requestFocus();}

    private void launchUnitv(JSONObject o){if(o.optBoolean("block_unitv",true)){Toast.makeText(this,o.optString("message","Plano bloqueado."),Toast.LENGTH_LONG).show();return;}String pkg=o.optString("unitv_package","");if(pkg.isEmpty()){Toast.makeText(this,"Package do UniTV não configurado no painel.",Toast.LENGTH_LONG).show();return;}try{Intent i=getPackageManager().getLaunchIntentForPackage(pkg);if(i==null){Toast.makeText(this,"UniTV não está instalado.",Toast.LENGTH_LONG).show();return;}startActivity(i);}catch(Exception e){Toast.makeText(this,"Não foi possível abrir o UniTV.",Toast.LENGTH_LONG).show();}}

    private void renderLauncherTop(LinearLayout root,JSONObject brand,boolean offline,JSONObject o){
        LinearLayout top=new LinearLayout(this); top.setOrientation(LinearLayout.HORIZONTAL); top.setGravity(Gravity.CENTER_VERTICAL); top.setPadding(dp(8),dp(4),dp(8),dp(10));
        LinearLayout left=new LinearLayout(this); left.setOrientation(LinearLayout.HORIZONTAL); left.setGravity(Gravity.CENTER_VERTICAL);
        String logo=brand.optString("logo_url","");
        if(!logo.isEmpty()){
            ImageView iv=new ImageView(this); iv.setScaleType(ImageView.ScaleType.FIT_CENTER); iv.setAdjustViewBounds(true);
            left.addView(iv,new LinearLayout.LayoutParams(dp(150),dp(72))); loadImage(iv,logo,"logo.cache");
        }
        LinearLayout names=new LinearLayout(this); names.setOrientation(LinearLayout.VERTICAL); names.setPadding(dp(14),0,0,0);
        TextView title=new TextView(this); title.setText(brand.optString("launcher_title","Ativador Launcher")); title.setTextColor(TEXT); title.setTextSize(isTv()?27:22); title.setTypeface(Typeface.DEFAULT_BOLD);
        TextView business=new TextView(this); String businessName=brand.optString("business_name","UniTV"); business.setText(businessName.equalsIgnoreCase(brand.optString("launcher_title","Ativador Launcher"))?"":businessName); business.setTextColor(MUTED); business.setTextSize(isTv()?15:13); business.setVisibility(business.getText().length()==0?View.GONE:View.VISIBLE);
        TextView dual=new TextView(this); dual.setText("ATIVADOR + LAUNCHER  •  "+launcherLayout.toUpperCase(Locale.ROOT)); dual.setTextColor(primary); dual.setTextSize(isTv()?12:10); dual.setTypeface(Typeface.DEFAULT_BOLD); dual.setPadding(0,dp(4),0,0);
        names.addView(title); names.addView(business); names.addView(dual);
        String supportVisible=brand.optString("support_whatsapp","").trim();
        if(!supportVisible.isEmpty()){
            TextView supportText=new TextView(this);supportText.setText("SUPORTE • "+supportVisible);supportText.setTextColor(Color.WHITE);supportText.setTextSize(isTv()?13:11);supportText.setTypeface(Typeface.DEFAULT_BOLD);supportText.setPadding(0,dp(4),0,0);names.addView(supportText);
        }
        left.addView(names);
        top.addView(left,new LinearLayout.LayoutParams(0,-2,1f));

        LinearLayout right=new LinearLayout(this); right.setOrientation(LinearLayout.VERTICAL); right.setGravity(Gravity.END);
        clockView=new TextView(this); clockView.setTextColor(TEXT); clockView.setTextSize(isTv()?28:22); clockView.setTypeface(Typeface.DEFAULT_BOLD); clockView.setGravity(Gravity.END);
        dateView=new TextView(this); dateView.setTextColor(MUTED); dateView.setTextSize(isTv()?14:12); dateView.setGravity(Gravity.END);
        networkView=new TextView(this); networkView.setTextColor(offline?Color.rgb(255,190,95):Color.rgb(120,235,165)); networkView.setTextSize(isTv()?13:11); networkView.setGravity(Gravity.END);
        networkView.setText(offline?"● OFF-LINE":"● ON-LINE");
        right.addView(clockView); right.addView(dateView); right.addView(networkView); top.addView(right,new LinearLayout.LayoutParams(dp(isTv()?220:150),-2));
        root.addView(top,new LinearLayout.LayoutParams(-1,-2)); updateClock();
    }

    private void renderLauncherBanner(LinearLayout root,JSONObject brand){
        String banner=brand.optString("banner_url",""); if(banner.isEmpty()) return;
        ImageView iv=new ImageView(this); iv.setScaleType(ImageView.ScaleType.CENTER_CROP); iv.setAdjustViewBounds(false); iv.setBackground(border(Color.argb(150,18,18,26),Color.argb(80,255,255,255),18,1));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(isTv()?190:135)); lp.setMargins(0,dp(4),0,dp(18)); root.addView(iv,lp); loadImage(iv,banner,"banner.cache");
    }

    private void renderPlanStrip(LinearLayout root,JSONObject o,boolean offline){
        boolean blocked=o.optBoolean("block_unitv",true); String exp=o.optString("expires_at","");
        String status=o.optString("client_status",blocked?"blocked":"active").toLowerCase(Locale.ROOT);
        boolean expired="expired".equals(status);
        boolean adminBlocked="blocked".equals(status);
        int stroke=adminBlocked?Color.rgb(235,80,90):(expired?Color.rgb(255,145,60):Color.rgb(65,205,145));
        LinearLayout strip=new LinearLayout(this); strip.setOrientation(LinearLayout.VERTICAL); strip.setPadding(dp(18),dp(14),dp(18),dp(14)); strip.setBackground(border(Color.argb(232,16,19,28),stroke,18,2));
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout text=new LinearLayout(this);text.setOrientation(LinearLayout.VERTICAL);
        TextView st=new TextView(this);
        String label=adminBlocked?"ACESSO BLOQUEADO PELO ADMINISTRADOR":(expired?"PLANO VENCIDO":"PLANO ATIVO");
        st.setText(label+(offline?"  •  OFF-LINE":""));st.setTextColor(adminBlocked?Color.rgb(255,145,150):(expired?Color.rgb(255,195,105):Color.rgb(125,245,180)));st.setTypeface(Typeface.DEFAULT_BOLD);st.setTextSize(isTv()?18:15);
        TextView sub=new TextView(this);sub.setText(adminBlocked?o.optString("message","Entre em contato com o suporte para verificar seu acesso."):(expired?"Renove agora para liberar novamente o UniTV.":((offline?"Modo off-line seguro • último estado confirmado.  ":"")+"Vencimento: "+(exp.isEmpty()?"não informado":exp))));sub.setTextColor(MUTED);sub.setTextSize(isTv()?14:12);sub.setPadding(0,dp(5),0,0);
        text.addView(st);text.addView(sub);row.addView(text,new LinearLayout.LayoutParams(0,-2,1f));
        Button action=button(adminBlocked?"SUPORTE":(expired?"RENOVAR AGORA":"PLANOS"));action.setTextSize(isTv()?14:12);LinearLayout.LayoutParams blp=new LinearLayout.LayoutParams(dp(isTv()?200:150),dp(52));row.addView(action,blp);strip.addView(row);
        action.setOnClickListener(v->{
            if(adminBlocked){String support=brandingSupport(o);if(!support.isEmpty())openSupport(support);else Toast.makeText(this,"Entre em contato com o administrador.",Toast.LENGTH_LONG).show();return;}
            if(!isOnline()){Toast.makeText(this,"Conecte à internet para gerar o PIX.",Toast.LENGTH_LONG).show();return;}renderPlans(o);
        });
        root.addView(strip,new LinearLayout.LayoutParams(-1,-2));
        if((expired||adminBlocked)&&!offline){action.requestFocus();}
    }

    private void renderPromoCarousel(LinearLayout root,JSONObject o){
        handler.removeCallbacks(promoTick);
        promoBanners=o.optJSONArray("promo_banners");
        promoIndex=0; promoImageView=null; promoCounterView=null;
        if(promoBanners==null || promoBanners.length()==0) return;

        // Card de divulgação compacto e realmente quadrado.
        // A imagem nunca estica para preencher uma faixa horizontal.
        LinearLayout area=new LinearLayout(this);
        area.setOrientation(LinearLayout.VERTICAL);
        area.setGravity(Gravity.CENTER_HORIZONTAL);
        area.setPadding(0,dp(12),0,dp(8));

        TextView h=section("DIVULGAÇÃO");
        h.setGravity(Gravity.CENTER);
        h.setPadding(0,dp(8),0,dp(8));
        area.addView(h,new LinearLayout.LayoutParams(-1,-2));

        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(8),dp(8),dp(8),dp(7));
        box.setBackground(border(Color.argb(215,18,18,25),Color.argb(100,255,255,255),18,1));

        int screenW=getResources().getDisplayMetrics().widthPixels;
        int maxPx=isTv()?dp(200):dp(170);
        int size=Math.min(maxPx,Math.max(dp(135),(int)(screenW*(isTv()?0.18f:0.38f))));

        promoImageView=new ImageView(this);
        promoImageView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        promoImageView.setAdjustViewBounds(false);
        promoImageView.setPadding(dp(3),dp(3),dp(3),dp(3));
        promoImageView.setBackgroundColor(Color.rgb(8,8,12));
        box.addView(promoImageView,new LinearLayout.LayoutParams(size,size));

        promoCounterView=new TextView(this);
        promoCounterView.setTextColor(MUTED);
        promoCounterView.setTextSize(isTv()?11:10);
        promoCounterView.setGravity(Gravity.CENTER);
        promoCounterView.setPadding(0,dp(5),0,0);
        box.addView(promoCounterView,new LinearLayout.LayoutParams(-1,-2));

        LinearLayout.LayoutParams boxLp=new LinearLayout.LayoutParams(size+dp(16),-2);
        boxLp.gravity=Gravity.CENTER_HORIZONTAL;
        area.addView(box,boxLp);

        LinearLayout.LayoutParams areaLp=new LinearLayout.LayoutParams(-1,-2);
        areaLp.setMargins(0,0,0,dp(8));
        root.addView(area,areaLp);

        showPromoBanner();
        if(promoBanners.length()>1) handler.postDelayed(promoTick,6000L);
    }

    private void showPromoBanner(){
        if(promoImageView==null || promoBanners==null || promoBanners.length()==0) return;
        JSONObject b=promoBanners.optJSONObject(Math.max(0,Math.min(promoIndex,promoBanners.length()-1)));
        if(b==null)return;
        String url=b.optString("image_url","");
        if(url.isEmpty())return;
        promoImageView.setImageDrawable(null);
        loadImage(promoImageView,url,promoCacheName(b,url));
        if(promoCounterView!=null) promoCounterView.setText((promoIndex+1)+" / "+promoBanners.length());
    }

    private String promoCacheName(JSONObject b,String url){
        int id=b==null?0:b.optInt("id",0);
        return "promo_"+id+"_"+Integer.toHexString((url==null?"":url).hashCode())+".cache";
    }

    private void precachePromoBanners(JSONObject o){
        if(o==null || !isOnline())return;
        JSONArray arr=o.optJSONArray("promo_banners");
        if(arr==null || arr.length()==0)return;
        new Thread(()->{
            for(int i=0;i<arr.length();i++){
                try{
                    JSONObject b=arr.optJSONObject(i); if(b==null)continue;
                    String url=b.optString("image_url",""); if(url.isEmpty())continue;
                    File f=new File(getFilesDir(),promoCacheName(b,url));
                    if(f.isFile() && f.length()>128)continue;
                    byte[] bytes=downloadBytes(url);
                    if(bytes!=null && bytes.length>128){try(FileOutputStream out=new FileOutputStream(f,false)){out.write(bytes);}}
                }catch(Exception ignored){}
            }
        },"promo-cache").start();
    }

    private void renderInstalledApps(LinearLayout root,JSONObject o){
        List<ResolveInfo> apps=getLaunchableApps();
        String unitvPkg=o.optString("unitv_package","");

        // Tela inicial limpa: somente apps comuns de usuário. Aplicativos do sistema,
        // launcher original, Configurações e componentes internos ficam fora daqui.
        ArrayList<ResolveInfo> userApps=new ArrayList<>();
        for(ResolveInfo ri:apps){
            if(ri==null||ri.activityInfo==null)continue;
            String pkg=ri.activityInfo.packageName;
            String label=String.valueOf(ri.loadLabel(getPackageManager()));
            if(pkg.equals(getPackageName()))continue;
            if(isSystemSettingsPackage(pkg,label))continue;
            if(isSystemApplication(pkg))continue;
            JSONObject policy=findAppPolicy(o,pkg);
            if(policy!=null&&!policy.optBoolean("launcher_visible",true))continue;
            userApps.add(ri);
        }

        int columns=launcherColumns();
        int usable=getResources().getDisplayMetrics().widthPixels-dp(isTv()?90:36);
        int cardW=Math.max(dp(isTv()?145:105),usable/columns-dp(14));
        int cardH=dp(launcherLayout.equals("compact")?(isTv()?126:108):(launcherLayout.equals("minimal")?(isTv()?142:120):(isTv()?150:125)));

        TextView favTitle=section("FAVORITOS");
        root.addView(favTitle);
        GridLayout favGrid=new GridLayout(this);
        favGrid.setColumnCount(columns);
        favGrid.setAlignmentMode(GridLayout.ALIGN_BOUNDS);
        favGrid.setUseDefaultMargins(false);
        int favCount=0;
        for(ResolveInfo ri:userApps){
            String pkg=ri.activityInfo.packageName;
            if(!isFavoriteApp(pkg))continue;
            String label=String.valueOf(ri.loadLabel(getPackageManager()));
            boolean blocked=pkg.equals(unitvPkg)&&o.optBoolean("block_unitv",true);
            View card=installedAppCard(label,pkg,ri.loadIcon(getPackageManager()),blocked,o);
            addGridCard(favGrid,card,cardW,cardH);
            favCount++;
        }
        if(favCount>0){
            root.addView(favGrid,new LinearLayout.LayoutParams(-1,-2));
        }else{
            TextView empty=info("Abra TODOS OS APPS e segure OK / ENTER no aplicativo que deseja deixar na frente da Launcher.",false);
            empty.setGravity(Gravity.START);
            root.addView(empty,new LinearLayout.LayoutParams(-1,-2));
        }

        TextView frequentTitle=section("USADOS COM FREQUÊNCIA");
        root.addView(frequentTitle);
        GridLayout frequentGrid=new GridLayout(this);
        frequentGrid.setColumnCount(columns);
        frequentGrid.setAlignmentMode(GridLayout.ALIGN_BOUNDS);
        frequentGrid.setUseDefaultMargins(false);

        Collections.sort(userApps,(a,b)->{
            String pa=a.activityInfo==null?"":a.activityInfo.packageName;
            String pb=b.activityInfo==null?"":b.activityInfo.packageName;
            long ca=appOpenCount(pa), cb=appOpenCount(pb);
            if(ca!=cb)return Long.compare(cb,ca);
            long la=appLastOpened(pa), lb=appLastOpened(pb);
            if(la!=lb)return Long.compare(lb,la);
            String aa=String.valueOf(a.loadLabel(getPackageManager()));
            String bb=String.valueOf(b.loadLabel(getPackageManager()));
            return aa.compareToIgnoreCase(bb);
        });
        int frequentCount=0;
        int frequentLimit=Math.max(columns,columns*2);
        for(ResolveInfo ri:userApps){
            if(frequentCount>=frequentLimit)break;
            String pkg=ri.activityInfo.packageName;
            if(appOpenCount(pkg)<=0)continue;
            if(isFavoriteApp(pkg))continue;
            String label=String.valueOf(ri.loadLabel(getPackageManager()));
            boolean blocked=pkg.equals(unitvPkg)&&o.optBoolean("block_unitv",true);
            addGridCard(frequentGrid,installedAppCard(label,pkg,ri.loadIcon(getPackageManager()),blocked,o),cardW,cardH);
            frequentCount++;
        }
        if(frequentCount>0){
            root.addView(frequentGrid,new LinearLayout.LayoutParams(-1,-2));
        }else{
            TextView empty=info("Conforme o cliente abrir aplicativos pela Launcher, os mais usados aparecerão aqui automaticamente.",false);
            empty.setGravity(Gravity.START);
            root.addView(empty,new LinearLayout.LayoutParams(-1,-2));
        }

        TextView shortcutsTitle=section("ATALHOS");
        root.addView(shortcutsTitle);
        GridLayout shortcuts=new GridLayout(this);
        shortcuts.setColumnCount(columns);
        shortcuts.setAlignmentMode(GridLayout.ALIGN_BOUNDS);
        shortcuts.setUseDefaultMargins(false);
        int shortcutH=dp(launcherLayout.equals("compact")?(isTv()?106:94):(isTv()?122:104));
        addGridCard(shortcuts,actionCard("Todos os Apps",android.R.drawable.ic_menu_view,()->renderAllUserApps(o)),cardW,shortcutH);
        addGridCard(shortcuts,actionCard("Ativador",android.R.drawable.ic_lock_idle_lock,()->openActivator(true)),cardW,shortcutH);
        addGridCard(shortcuts,actionCard("Configurações",android.R.drawable.ic_menu_preferences,()->renderProtectedSettings(o)),cardW,shortcutH);
        String support=brandingSupport(o);
        if(!support.isEmpty()) addGridCard(shortcuts,actionCard("Suporte",android.R.drawable.ic_menu_call,()->openSupport(support)),cardW,shortcutH);
        JSONArray tutorials=o.optJSONArray("tutorials");
        if(tutorials!=null&&tutorials.length()>0) addGridCard(shortcuts,actionCard("Tutoriais",android.R.drawable.ic_menu_help,()->renderTutorials(o)),cardW,shortcutH);
        root.addView(shortcuts,new LinearLayout.LayoutParams(-1,-2));
    }

    private void renderAllUserApps(JSONObject o){
        ScrollView s=baseScroll();
        LinearLayout root=container(s);
        title(root,"TODOS OS APLICATIVOS","Somente aplicativos comuns do usuário. Segure OK / ENTER para adicionar ou remover dos Favoritos.");
        List<ResolveInfo> apps=getLaunchableApps();
        ArrayList<ResolveInfo> userApps=new ArrayList<>();
        for(ResolveInfo ri:apps){
            if(ri==null||ri.activityInfo==null)continue;
            String pkg=ri.activityInfo.packageName;
            String label=String.valueOf(ri.loadLabel(getPackageManager()));
            if(pkg.equals(getPackageName())||isSystemSettingsPackage(pkg,label)||isSystemApplication(pkg))continue;
            JSONObject policy=findAppPolicy(o,pkg);
            if(policy!=null&&!policy.optBoolean("launcher_visible",true))continue;
            userApps.add(ri);
        }
        Collections.sort(userApps,(a,b)->String.valueOf(a.loadLabel(getPackageManager())).compareToIgnoreCase(String.valueOf(b.loadLabel(getPackageManager()))));
        int columns=launcherColumns();
        int usable=getResources().getDisplayMetrics().widthPixels-dp(isTv()?90:36);
        int cardW=Math.max(dp(isTv()?145:105),usable/columns-dp(14));
        int cardH=dp(isTv()?150:125);
        GridLayout grid=new GridLayout(this);
        grid.setColumnCount(columns);
        grid.setAlignmentMode(GridLayout.ALIGN_BOUNDS);
        grid.setUseDefaultMargins(false);
        String unitvPkg=o.optString("unitv_package","");
        for(ResolveInfo ri:userApps){
            String pkg=ri.activityInfo.packageName;
            String label=String.valueOf(ri.loadLabel(getPackageManager()));
            boolean blocked=pkg.equals(unitvPkg)&&o.optBoolean("block_unitv",true);
            addGridCard(grid,installedAppCard(label,pkg,ri.loadIcon(getPackageManager()),blocked,o),cardW,cardH);
        }
        root.addView(grid,new LinearLayout.LayoutParams(-1,-2));
        if(userApps.isEmpty())root.addView(info("Nenhum aplicativo de usuário disponível neste aparelho.",true));
        backButton(root,()->renderState(o,!isOnline()));
        setContentView(s);
    }

    private boolean isSystemApplication(String pkg){
        try{
            ApplicationInfo ai=getPackageManager().getApplicationInfo(pkg,0);
            return (ai.flags&(ApplicationInfo.FLAG_SYSTEM|ApplicationInfo.FLAG_UPDATED_SYSTEM_APP))!=0;
        }catch(Exception e){return false;}
    }

    private void registerAppOpen(String pkg){
        if(pkg==null||pkg.isEmpty())return;
        android.content.SharedPreferences sp=getSharedPreferences("launcher_usage",MODE_PRIVATE);
        long count=sp.getLong("count:"+pkg,0L)+1L;
        sp.edit().putLong("count:"+pkg,count).putLong("last:"+pkg,System.currentTimeMillis()).apply();
    }

    private long appOpenCount(String pkg){
        if(pkg==null||pkg.isEmpty())return 0L;
        return getSharedPreferences("launcher_usage",MODE_PRIVATE).getLong("count:"+pkg,0L);
    }

    private long appLastOpened(String pkg){
        if(pkg==null||pkg.isEmpty())return 0L;
        return getSharedPreferences("launcher_usage",MODE_PRIVATE).getLong("last:"+pkg,0L);
    }

    private boolean isFavoriteApp(String pkg){
        if(pkg==null||pkg.isEmpty()) return false;
        String raw=getSharedPreferences("launcher_favorites",MODE_PRIVATE).getString("packages","");
        String token="\n"+pkg+"\n";
        return ("\n"+raw+"\n").contains(token);
    }

    private void toggleFavoriteApp(String pkg,String label,JSONObject launcherState){
        if(pkg==null||pkg.isEmpty()) return;
        String raw=getSharedPreferences("launcher_favorites",MODE_PRIVATE).getString("packages","");
        java.util.LinkedHashSet<String> items=new java.util.LinkedHashSet<>();
        if(raw!=null&&!raw.isEmpty()){
            String[] parts=raw.split("\n");
            for(String item:parts) if(item!=null&&!item.trim().isEmpty()) items.add(item.trim());
        }
        boolean added;
        if(items.contains(pkg)){items.remove(pkg);added=false;}else{items.add(pkg);added=true;}
        StringBuilder out=new StringBuilder();
        for(String item:items){if(out.length()>0)out.append('\n');out.append(item);}
        getSharedPreferences("launcher_favorites",MODE_PRIVATE).edit().putString("packages",out.toString()).apply();
        Toast.makeText(this,(label==null?"Aplicativo":label)+(added?" adicionado aos favoritos.":" removido dos favoritos."),Toast.LENGTH_SHORT).show();
        if(launcherState!=null){
            handler.postDelayed(new Runnable(){@Override public void run(){renderState(launcherState,!isOnline());}},120L);
        }
    }

    private boolean isSystemSettingsPackage(String pkg,String label){
        String p=pkg==null?"":pkg.toLowerCase(Locale.ROOT);
        String l=label==null?"":label.trim().toLowerCase(Locale.ROOT);
        return p.equals("com.android.settings")
                || p.equals("com.android.tv.settings")
                || p.equals("com.google.android.tv.settings")
                || p.equals("com.amazon.tv.settings")
                || p.equals("com.amazon.device.settings")
                || l.equals("configurações") || l.equals("settings");
    }

    private String protectedAppsPinHash(){
        try{
            JSONObject source=state;
            if(source==null){
                String cached=LauncherStore.getCachedJson(this);
                if(cached!=null && !cached.isEmpty()) source=new JSONObject(cached);
            }
            if(source!=null){
                JSONObject b=source.optJSONObject("branding");
                if(b!=null){
                    String hash=b.optString("settings_pin_hash","").trim().toLowerCase(Locale.ROOT);
                    if(hash.matches("[0-9a-f]{64}")) return hash;
                }
            }
        }catch(Exception ignored){}
        return "";
    }

    private String sha256(String value){
        try{
            java.security.MessageDigest md=java.security.MessageDigest.getInstance("SHA-256");
            byte[] out=md.digest(value.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            StringBuilder sb=new StringBuilder(out.length*2);
            for(byte b:out) sb.append(String.format(Locale.ROOT,"%02x",b & 0xff));
            return sb.toString();
        }catch(Exception ignored){return "";}
    }

    private boolean verifyProtectedAppsPin(String pin){
        String hash=protectedAppsPinHash();
        return !hash.isEmpty() && hash.equals(sha256(pin==null?"":pin.trim()));
    }

    private void renderProtectedSettings(JSONObject o){
        internalSettingsOpen=true;
        ScrollView s=baseScroll();
        s.setClipToPadding(false);

        LinearLayout out=new LinearLayout(this);
        out.setOrientation(LinearLayout.VERTICAL);
        out.setGravity(Gravity.CENTER);
        out.setPadding(dp(18),dp(isTv()?14:20),dp(18),dp(isTv()?14:20));
        s.addView(out,new ScrollView.LayoutParams(-1,-1));

        LinearLayout r=new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setGravity(Gravity.CENTER_HORIZONTAL);
        r.setPadding(dp(isTv()?24:20),dp(isTv()?18:22),dp(isTv()?24:20),dp(isTv()?18:22));
        r.setBackground(border(Color.argb(232,18,18,25),Color.argb(100,255,255,255),20,1));
        LinearLayout.LayoutParams cardLp=new LinearLayout.LayoutParams(isTv()?dp(720):-1,-2);
        cardLp.gravity=Gravity.CENTER;
        out.addView(r,cardLp);

        TextView heading=new TextView(this);
        heading.setText("CONFIGURAÇÕES DA TV BOX");
        heading.setTextColor(TEXT);
        heading.setTextSize(isTv()?25:22);
        heading.setTypeface(Typeface.DEFAULT_BOLD);
        heading.setGravity(Gravity.CENTER);
        r.addView(heading,new LinearLayout.LayoutParams(-1,-2));

        TextView subtitle=info("Use ↑ ↓ e OK no controle. Somente Aplicativos exige o PIN da revenda.",false);
        subtitle.setTextSize(isTv()?14:13);
        subtitle.setPadding(dp(8),dp(5),dp(8),dp(8));
        LinearLayout.LayoutParams subLp=new LinearLayout.LayoutParams(-1,-2);
        subLp.setMargins(0,0,0,dp(6));
        r.addView(subtitle,subLp);

        String protection=DeviceControl.isUninstallProtectionActive(this)
                ? "✓ PROTEÇÃO CONTRA DESINSTALAÇÃO ATIVA"
                : "Proteção reforçada disponível com Device Owner";
        TextView st=info(protection,true);
        st.setTextSize(isTv()?13:12);
        st.setPadding(dp(10),dp(7),dp(10),dp(7));
        st.setTextColor(DeviceControl.isUninstallProtectionActive(this)?Color.rgb(125,245,180):Color.rgb(255,195,105));
        LinearLayout.LayoutParams stLp=new LinearLayout.LayoutParams(-1,-2);
        stLp.setMargins(0,0,0,dp(5));
        r.addView(st,stLp);

        java.util.ArrayList<Button> focusButtons=new java.util.ArrayList<>();
        focusButtons.add(addSettingAction(r,"WI-FI",Settings.ACTION_WIFI_SETTINGS));
        focusButtons.add(addSettingAction(r,"BLUETOOTH",Settings.ACTION_BLUETOOTH_SETTINGS));
        focusButtons.add(addSettingAction(r,"TELA / IMAGEM",Settings.ACTION_DISPLAY_SETTINGS));
        focusButtons.add(addSettingAction(r,"SOM",Settings.ACTION_SOUND_SETTINGS));
        focusButtons.add(addSettingAction(r,"DATA E HORA",Settings.ACTION_DATE_SETTINGS));
        focusButtons.add(addSettingAction(r,"IDIOMA",Settings.ACTION_LOCALE_SETTINGS));
        focusButtons.add(addSettingAction(r,"ACESSIBILIDADE",Settings.ACTION_ACCESSIBILITY_SETTINGS));

        Button apps=settingsButton("🔒  APLICATIVOS • PIN");
        LinearLayout.LayoutParams alp=new LinearLayout.LayoutParams(-1,dp(isTv()?46:50));
        alp.setMargins(0,dp(5),0,0);
        r.addView(apps,alp);
        apps.setOnClickListener(v->requestAppsPin());
        focusButtons.add(apps);

        Button back=settingsButton("VOLTAR");
        LinearLayout.LayoutParams blp=new LinearLayout.LayoutParams(-1,dp(isTv()?44:48));
        blp.setMargins(0,dp(7),0,0);
        r.addView(back,blp);
        back.setOnClickListener(v->{internalSettingsOpen=false;renderState(o,!isOnline());});
        focusButtons.add(back);

        linkVerticalFocus(focusButtons);
        setContentView(s);
        if(!focusButtons.isEmpty()){
            focusButtons.get(0).requestFocus();
            s.postDelayed(()->s.smoothScrollTo(0,0),80L);
        }
    }

    private Button addSettingAction(LinearLayout r,String label,String action){
        Button b=settingsButton(label);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(isTv()?46:50));
        lp.setMargins(0,dp(4),0,0);
        r.addView(b,lp);
        b.setOnClickListener(v->{
            try{
                internalSettingsOpen=false;
                Intent i=new Intent(action);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            }catch(Exception e){Toast.makeText(this,"Esta configuração não está disponível nesta Box.",Toast.LENGTH_LONG).show();}
        });
        return b;
    }

    private Button settingsButton(String label){
        Button b=buttonSecondary(label);
        b.setTextSize(isTv()?16:15);
        b.setPadding(dp(12),0,dp(12),0);
        b.setFocusable(true);
        b.setFocusableInTouchMode(false);
        b.setOnFocusChangeListener((v,has)->{
            v.setScaleX(has?1.018f:1f);
            v.setScaleY(has?1.018f:1f);
            ((Button)v).setTextColor(Color.WHITE);
            v.setBackground(border(
                    has?Color.argb(250,43,43,58):Color.rgb(42,42,54),
                    has?primary:Color.argb(100,255,255,255),
                    12,
                    has?3:1));
        });
        return b;
    }

    private void linkVerticalFocus(java.util.List<Button> buttons){
        if(buttons==null||buttons.isEmpty()) return;
        for(Button b:buttons){ if(b.getId()==View.NO_ID) b.setId(View.generateViewId()); }
        for(int i=0;i<buttons.size();i++){
            Button current=buttons.get(i);
            if(i>0) current.setNextFocusUpId(buttons.get(i-1).getId());
            if(i<buttons.size()-1) current.setNextFocusDownId(buttons.get(i+1).getId());
        }
    }

    private void requestAppsPin(){
        if(protectedAppsPinHash().isEmpty()){
            new AlertDialog.Builder(this)
                    .setTitle("PIN não configurado")
                    .setMessage("O revendedor ainda não definiu o PIN da área de aplicativos. Configure em Minha Launcher no painel e aguarde a sincronização.")
                    .setPositiveButton("OK",null)
                    .show();
            return;
        }
        final EditText pin=new EditText(this);
        pin.setHint("PIN");
        pin.setSingleLine(true);
        pin.setInputType(android.text.InputType.TYPE_CLASS_NUMBER|android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        pin.setTextColor(Color.WHITE);
        pin.setHintTextColor(Color.rgb(145,145,155));
        pin.setPadding(dp(16),dp(12),dp(16),dp(12));
        pin.setBackground(border(Color.rgb(17,17,24),Color.rgb(80,80,95),12,1));

        LinearLayout wrap=new LinearLayout(this);
        wrap.setPadding(dp(22),dp(8),dp(22),0);
        wrap.addView(pin,new LinearLayout.LayoutParams(-1,dp(58)));

        AlertDialog d=new AlertDialog.Builder(this)
                .setTitle("Área de aplicativos protegida")
                .setMessage("Digite o PIN para abrir o gerenciamento de aplicativos.")
                .setView(wrap)
                .setNegativeButton("CANCELAR",null)
                .setPositiveButton("LIBERAR",null)
                .create();
        d.setOnShowListener(x->{
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
                if(verifyProtectedAppsPin(pin.getText().toString())){
                    d.dismiss();
                    try{
                        internalSettingsOpen=false;
                        Intent i=new Intent(Settings.ACTION_APPLICATION_SETTINGS);
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(i);
                    }catch(Exception e){Toast.makeText(this,"Gerenciador de aplicativos indisponível.",Toast.LENGTH_LONG).show();}
                }else{
                    pin.setError("PIN incorreto");
                    pin.setText("");
                    pin.requestFocus();
                }
            });
        });
        d.setOnDismissListener(x->{});
        d.show();
        pin.requestFocus();
    }

    private void renderPanelAvailableApps(LinearLayout root,JSONObject o){
        JSONArray arr=o.optJSONArray("apps"); if(arr==null) return; ArrayList<JSONObject> missing=new ArrayList<>();
        for(int i=0;i<arr.length();i++){JSONObject a=arr.optJSONObject(i); if(a==null||a.optBoolean("is_unitv",false)||!a.optBoolean("launcher_visible",true))continue; String pkg=a.optString("package_name",""); JSONObject policy=findAppPolicy(o,pkg); if(policy!=null&&!policy.optBoolean("launcher_visible",true))continue; if(!pkg.isEmpty()&&!isInstalled(pkg)&&!a.optString("download_url","").isEmpty())missing.add(a);}
        if(missing.isEmpty())return; TextView h=section("DISPONÍVEIS PARA INSTALAR");root.addView(h); GridLayout g=new GridLayout(this); g.setColumnCount(launcherColumns()); int columns=launcherColumns(); int usable=getResources().getDisplayMetrics().widthPixels-dp(isTv()?90:36); int w=Math.max(dp(145),usable/columns-dp(14)); int hh=dp(isTv()?115:95);
        for(JSONObject a:missing){String name=a.optString("name","Aplicativo"); View c=actionCard(name,android.R.drawable.stat_sys_download,()->{if(isOnline())downloadAndInstall(a.optString("download_url",""),name);else Toast.makeText(this,"Conecte à internet para instalar.",Toast.LENGTH_LONG).show();}); addGridCard(g,c,w,hh);} root.addView(g,new LinearLayout.LayoutParams(-1,-2));
    }

    private void renderLauncherFooter(LinearLayout root,JSONObject o,boolean offline,JSONObject brand){
        LinearLayout foot=new LinearLayout(this);foot.setOrientation(LinearLayout.HORIZONTAL);foot.setGravity(Gravity.CENTER_VERTICAL);foot.setPadding(dp(6),dp(22),dp(6),dp(4));
        TextView code=new TextView(this);code.setText("Aparelho: "+o.optString("device_code",LauncherStore.getDeviceCode(this)));code.setTextColor(MUTED);code.setTextSize(isTv()?13:11);foot.addView(code,new LinearLayout.LayoutParams(0,-2,1f));
        TextView sync=new TextView(this);long last=LauncherStore.getLastSync(this);String ls=last>0?new SimpleDateFormat("dd/MM HH:mm",Locale.getDefault()).format(new Date(last)):"nunca";sync.setText((offline?"Cache local • ":"Sincronizado • ")+ls);sync.setTextColor(MUTED);sync.setTextSize(isTv()?13:11);sync.setGravity(Gravity.END);foot.addView(sync,new LinearLayout.LayoutParams(0,-2,1f));root.addView(foot,new LinearLayout.LayoutParams(-1,-2));
    }

    private int launcherColumns(){int w=getResources().getDisplayMetrics().widthPixels;int base;if(isTv())base=w>=1500?7:(w>=1100?6:5);else base=w>=900?5:(w>=600?4:3);if(launcherLayout.equals("compact"))base+=1;if((launcherLayout.equals("minimal")||launcherLayout.equals("showcase"))&&base>3)base-=1;return Math.max(3,base);}

    private void addGridCard(GridLayout grid,View v,int w,int h){GridLayout.LayoutParams lp=new GridLayout.LayoutParams();lp.width=w;lp.height=h;lp.setMargins(dp(6),dp(6),dp(6),dp(6));grid.addView(v,lp);}

    private View installedAppCard(String label,String pkg,Drawable icon,boolean blocked,JSONObject state){
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setGravity(Gravity.CENTER);c.setPadding(dp(10),dp(10),dp(10),dp(8));c.setFocusable(true);c.setClickable(true);c.setLongClickable(true);int cardBg=launcherLayout.equals("minimal")?Color.argb(190,17,20,28):Color.argb(232,23,27,38);int radius=launcherLayout.equals("compact")?13:16;c.setBackground(border(cardBg,Color.argb(72,255,255,255),radius,1));
        ImageView iv=new ImageView(this);iv.setImageDrawable(icon);iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE);iv.setAdjustViewBounds(true);iv.setPadding(dp(5),dp(5),dp(5),dp(5));c.addView(iv,new LinearLayout.LayoutParams(dp(isTv()?76:60),dp(isTv()?76:60)));
        TextView t=new TextView(this);t.setText((blocked?"🔒 ":"")+(isFavoriteApp(pkg)?"★ ":"")+label);t.setTextColor(blocked?Color.rgb(210,150,155):TEXT);t.setTextSize(isTv()?14:12);t.setGravity(Gravity.CENTER);t.setMaxLines(2);t.setPadding(0,dp(8),0,0);c.addView(t,new LinearLayout.LayoutParams(-1,-2));
        applyTvFocus(c);
        c.setOnClickListener(v->{if(blocked){Toast.makeText(this,pkg.equals(state.optString("unitv_package",""))?state.optString("message","UniTV bloqueado pelo plano."):"Aplicativo bloqueado pelo administrador.",Toast.LENGTH_LONG).show();return;}registerAppOpen(pkg);openPackage(pkg);});
        c.setOnLongClickListener(v->{toggleFavoriteApp(pkg,label,state);return true;});
        return c;
    }

    private View actionCard(String label,int iconRes,Runnable action){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setGravity(Gravity.CENTER);c.setPadding(dp(10),dp(10),dp(10),dp(8));c.setFocusable(true);c.setClickable(true);int bg=launcherLayout.equals("minimal")?Color.argb(190,17,20,28):Color.argb(232,23,27,38);c.setBackground(border(bg,Color.argb(72,255,255,255),launcherLayout.equals("compact")?13:16,1));ImageView iv=new ImageView(this);iv.setImageResource(iconRes);iv.setColorFilter(Color.WHITE);c.addView(iv,new LinearLayout.LayoutParams(dp(isTv()?58:48),dp(isTv()?58:48)));TextView t=new TextView(this);t.setText(label);t.setTextColor(TEXT);t.setTextSize(isTv()?14:12);t.setGravity(Gravity.CENTER);t.setPadding(0,dp(8),0,0);c.addView(t,new LinearLayout.LayoutParams(-1,-2));applyTvFocus(c);c.setOnClickListener(v->action.run());return c;}

    private void applyTvFocus(View v){v.setOnFocusChangeListener((x,has)->{x.setScaleX(has?1.035f:1f);x.setScaleY(has?1.035f:1f);x.setBackground(border(has?Color.argb(245,38,38,48):Color.argb(225,26,26,35),has?primary:Color.argb(80,255,255,255),launcherLayout.equals("compact")?13:16,has?3:1));});}

    private List<ResolveInfo> getLaunchableApps(){
        PackageManager pm=getPackageManager();
        LinkedHashMap<String,ResolveInfo> map=new LinkedHashMap<>();
        java.util.HashSet<String> homePkgs=getHomeLauncherPackages(pm);

        Intent tv=new Intent(Intent.ACTION_MAIN);
        tv.addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
        for(ResolveInfo r:pm.queryIntentActivities(tv,0)){
            if(r.activityInfo==null)continue;
            String pkg=r.activityInfo.packageName;
            if(isLauncherShell(pm,r,homePkgs))continue;
            map.put(pkg,r);
        }

        Intent phone=new Intent(Intent.ACTION_MAIN);
        phone.addCategory(Intent.CATEGORY_LAUNCHER);
        for(ResolveInfo r:pm.queryIntentActivities(phone,0)){
            if(r.activityInfo==null)continue;
            String pkg=r.activityInfo.packageName;
            if(isLauncherShell(pm,r,homePkgs))continue;
            map.putIfAbsent(pkg,r);
        }
        return new ArrayList<>(map.values());
    }


    private boolean isLauncherShell(PackageManager pm,ResolveInfo r,java.util.HashSet<String> homePkgs){
        try{
            if(r==null||r.activityInfo==null)return false;
            String pkg=r.activityInfo.packageName==null?"":r.activityInfo.packageName;
            if(pkg.equals(getPackageName()))return true;
            if(homePkgs!=null&&homePkgs.contains(pkg))return true;
            String cls=r.activityInfo.name==null?"":r.activityInfo.name;
            String label=String.valueOf(r.loadLabel(pm));
            String probe=(pkg+" "+cls+" "+label).toLowerCase(java.util.Locale.ROOT);
            // Alguns firmwares (ex.: LongLauncher) expõem a HOME também como app comum
            // e não entram corretamente no CATEGORY_HOME. Nesses casos, não mostramos
            // componentes identificados como launcher na grade do usuário.
            return probe.contains("launcher");
        }catch(Exception ignored){return false;}
    }

    private java.util.HashSet<String> getHomeLauncherPackages(PackageManager pm){
        java.util.HashSet<String> homes=new java.util.HashSet<>();
        try{
            Intent home=new Intent(Intent.ACTION_MAIN);
            home.addCategory(Intent.CATEGORY_HOME);
            for(ResolveInfo r:pm.queryIntentActivities(home,0)){
                if(r!=null&&r.activityInfo!=null&&r.activityInfo.packageName!=null){
                    homes.add(r.activityInfo.packageName);
                }
            }
        }catch(Exception ignored){}
        // Nunca deixa a própria tela principal entrar na grade de aplicativos.
        homes.add(getPackageName());
        return homes;
    }

    private JSONObject findAppPolicy(JSONObject o,String pkg){JSONArray rules=o.optJSONArray("app_rules");for(int i=0;i<(rules==null?0:rules.length());i++){JSONObject a=rules.optJSONObject(i);if(a!=null&&pkg.equals(a.optString("package_name","")))return a;}JSONArray arr=o.optJSONArray("apps");for(int i=0;i<(arr==null?0:arr.length());i++){JSONObject a=arr.optJSONObject(i);if(a!=null&&pkg.equals(a.optString("package_name","")))return a;}return null;}

    private String brandingSupport(JSONObject o){JSONObject b=o.optJSONObject("branding");return b==null?"":b.optString("support_whatsapp","");}
    private void openSupport(String phone){String digits=phone.replaceAll("\\D+","");if(digits.isEmpty())return;try{Intent w=new Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/"+digits));if(isInstalled("com.whatsapp"))w.setPackage("com.whatsapp");startActivity(w);}catch(Exception e){ClipboardManager cb=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);cb.setPrimaryClip(ClipData.newPlainText("Suporte",phone));Toast.makeText(this,"Número de suporte copiado: "+phone,Toast.LENGTH_LONG).show();}}

    private boolean isOnline(){try{ConnectivityManager cm=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);if(cm==null)return false;if(Build.VERSION.SDK_INT>=23){android.net.Network n=cm.getActiveNetwork();if(n==null)return false;NetworkCapabilities c=cm.getNetworkCapabilities(n);return c!=null&&c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)&&(c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)||c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)||c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR));}android.net.NetworkInfo ni=cm.getActiveNetworkInfo();return ni!=null&&ni.isConnected();}catch(Exception e){return false;}}
    private void startClock(){handler.removeCallbacks(clockTick);handler.removeCallbacks(syncWatch);handler.post(clockTick);handler.postDelayed(syncWatch,1200L);}
    private void updateClock(){if(clockView==null)return;Date now=new Date();clockView.setText(new SimpleDateFormat("HH:mm",Locale.getDefault()).format(now));if(dateView!=null)dateView.setText(new SimpleDateFormat("EEE, dd MMM",new Locale("pt","BR")).format(now));if(networkView!=null){boolean on=isOnline();networkView.setText(on?"● ON-LINE":"● OFF-LINE");networkView.setTextColor(on?Color.rgb(120,235,165):Color.rgb(255,190,95));}}

    private LinearLayout launcherContainer(ScrollView s){LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setGravity(Gravity.TOP);int side=launcherLayout.equals("compact")?(isTv()?30:12):(isTv()?42:16);root.setPadding(dp(side),dp(isTv()?18:12),dp(side),dp(28));root.setBackgroundColor(launcherLayout.equals("minimal")?Color.argb(28,5,7,12):Color.argb(54,5,7,12));s.addView(root,new ScrollView.LayoutParams(-1,-2));return root;}

    private void renderApps(LinearLayout r,JSONObject o){renderInstalledApps(r,o);}
    private void renderTutorialButton(LinearLayout r,JSONObject o){JSONArray t=o.optJSONArray("tutorials");if(t==null||t.length()==0)return;Button b=buttonSecondary("TUTORIAIS");LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(58));lp.setMargins(0,dp(16),0,0);r.addView(b,lp);b.setOnClickListener(v->renderTutorials(o));}
    private void renderFooter(LinearLayout r,JSONObject o,boolean offline){TextView f=info("Código do aparelho: "+o.optString("device_code",LauncherStore.getDeviceCode(this))+(offline?"  •  OFF-LINE":""),false);r.addView(f);Button a=buttonSecondary("ATIVADOR / CONFIGURAÇÃO");LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(50));lp.setMargins(0,dp(10),0,0);r.addView(a,lp);a.setOnClickListener(v->openActivator(true));}

    private void renderPlans(JSONObject o){JSONArray plans=o.optJSONArray("plans");JSONArray gateways=o.optJSONArray("gateways");ScrollView s=baseScroll();LinearLayout r=container(s);title(r,"RENOVAR PLANO","O pagamento Pix é gerado e exibido aqui, sem abrir navegador.");if(plans==null||plans.length()==0){r.addView(info("Seu revendedor ainda não cadastrou planos.",true));backButton(r,()->renderState(o,false));setContentView(s);return;}if(gateways==null||gateways.length()==0){r.addView(info("Seu revendedor ainda não ativou Mercado Pago ou MisticPay.",true));backButton(r,()->renderState(o,false));setContentView(s);return;}for(int i=0;i<plans.length();i++){JSONObject p=plans.optJSONObject(i);if(p==null)continue;String label=p.optString("name")+" — R$ "+String.format(java.util.Locale.forLanguageTag("pt-BR"),"%.2f",p.optDouble("price"));Button b=button(label);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(66));lp.setMargins(0,dp(8),0,0);r.addView(b,lp);b.setOnClickListener(v->renderPayer(o,p));}backButton(r,()->renderState(o,false));setContentView(s);}

    private void renderPayer(JSONObject o,JSONObject plan){ScrollView s=baseScroll();LinearLayout r=container(s);title(r,"DADOS DO PAGADOR",plan.optString("name")+" — R$ "+String.format(java.util.Locale.forLanguageTag("pt-BR"),"%.2f",plan.optDouble("price")));EditText n=input("Nome completo",LauncherStore.getPayerName(this));EditText e=input("E-mail",LauncherStore.getPayerEmail(this));EditText d=input("CPF/CNPJ",LauncherStore.getPayerDoc(this));d.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);r.addView(n);r.addView(e);r.addView(d);configureDone(n,e);configureDone(e,d);JSONArray g=o.optJSONArray("gateways");for(int i=0;i<(g==null?0:g.length());i++){String provider=g.optString(i);Button b=button(provider.equals("mercadopago")?"GERAR PIX • MERCADO PAGO":"GERAR PIX • MISTICPAY");LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(64));lp.setMargins(0,dp(10),0,0);r.addView(b,lp);b.setOnClickListener(v->{String name=n.getText().toString().trim(),email=e.getText().toString().trim(),doc=d.getText().toString().replaceAll("\\D","");if(name.isEmpty()||doc.length()<11){Toast.makeText(this,"Preencha nome e CPF/CNPJ.",Toast.LENGTH_LONG).show();return;}if(provider.equals("mercadopago")&&email.isEmpty()){Toast.makeText(this,"Mercado Pago exige o e-mail do pagador.",Toast.LENGTH_LONG).show();return;}LauncherStore.setPayer(this,name,email,doc);createPix(o,plan,provider,name,email,doc);});}backButton(r,()->renderPlans(o));setContentView(s);n.requestFocus();}

    private void createPix(JSONObject o,JSONObject plan,String provider,String name,String email,String doc){renderPaymentLoading("Gerando Pix...");new Thread(()->{try{String body="device_code="+enc(LauncherStore.getDeviceCode(this))+"&plan_id="+plan.optInt("id")+"&provider="+enc(provider)+"&payer_name="+enc(name)+"&payer_email="+enc(email)+"&payer_document="+enc(doc);String json=httpPostForm(Config.BASE_URL+"/api/create_pix.php",body);JSONObject p=new JSONObject(json);if(!"ok".equalsIgnoreCase(p.optString("status")))throw new Exception(p.optString("mensagem","Falha ao gerar Pix."));runOnUiThread(()->renderPix(o,p));}catch(Exception ex){runOnUiThread(()->{Toast.makeText(this,ex.getMessage(),Toast.LENGTH_LONG).show();renderPlans(o);});}},"create-pix").start();}

    private void renderPaymentLoading(String txt){ScrollView s=baseScroll();LinearLayout r=container(s);title(r,"PAGAMENTO",txt);ProgressBar p=new ProgressBar(this);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(55),dp(55));lp.gravity=Gravity.CENTER_HORIZONTAL;r.addView(p,lp);setContentView(s);}
    private void renderPix(JSONObject launcher,JSONObject pay){ScrollView s=baseScroll();LinearLayout r=container(s);title(r,"PIX GERADO","Pague pelo aplicativo do seu banco. A liberação é automática após a confirmação.");String qr64=pay.optString("qr_base64","");if(qr64.startsWith("data:")){int comma=qr64.indexOf(',');if(comma>=0)qr64=qr64.substring(comma+1);}try{byte[] b=Base64.decode(qr64,Base64.DEFAULT);Bitmap bmp=BitmapFactory.decodeByteArray(b,0,b.length);if(bmp!=null){ImageView iv=new ImageView(this);iv.setImageBitmap(bmp);iv.setScaleType(ImageView.ScaleType.FIT_CENTER);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(300),dp(300));lp.gravity=Gravity.CENTER_HORIZONTAL;r.addView(iv,lp);}}catch(Exception ignored){}
        String code=pay.optString("pix_code","");EditText pix=input("Pix Copia e Cola",code);pix.setFocusable(false);r.addView(pix);Button copy=button("COPIAR PIX");r.addView(copy,new LinearLayout.LayoutParams(-1,dp(62)));copy.setOnClickListener(v->{ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);cm.setPrimaryClip(ClipData.newPlainText("Pix",code));Toast.makeText(this,"Pix copiado.",Toast.LENGTH_SHORT).show();});TextView st=info("Aguardando pagamento...",true);r.addView(st);Button check=buttonSecondary("VERIFICAR PAGAMENTO");LinearLayout.LayoutParams cl=new LinearLayout.LayoutParams(-1,dp(56));cl.setMargins(0,dp(10),0,0);r.addView(check,cl);Runnable poll=new Runnable(){@Override public void run(){checkPayment(pay.optInt("payment_id"),launcher,st,this);}};check.setOnClickListener(v->poll.run());handler.postDelayed(poll,3000);setContentView(s);copy.requestFocus();}
    private void checkPayment(int id,JSONObject launcher,TextView status,Runnable again){new Thread(()->{try{String json=httpGet(Config.BASE_URL+"/api/payment_status.php?payment_id="+id+"&device_code="+enc(LauncherStore.getDeviceCode(this))+"&_ts="+System.currentTimeMillis());JSONObject o=new JSONObject(json);String ps=o.optString("payment_status","");runOnUiThread(()->{if("paid".equals(ps)){status.setText("PAGAMENTO CONFIRMADO. Liberando...");handler.postDelayed(this::syncLauncher,1200);}else if("failed".equals(ps)){status.setText("Pagamento não aprovado.");}else{status.setText("Aguardando pagamento...");handler.postDelayed(again,3000);}});}catch(Exception e){runOnUiThread(()->handler.postDelayed(again,5000));}},"pay-check").start();}

    private void renderTutorials(JSONObject launcher){ScrollView s=baseScroll();LinearLayout r=container(s);title(r,"TUTORIAIS / DOWNLOADER","Conteúdo geral publicado pelo administrador.");JSONArray arr=launcher.optJSONArray("tutorials");for(int i=0;i<(arr==null?0:arr.length());i++){JSONObject t=arr.optJSONObject(i);if(t==null)continue;TextView h=section(t.optString("title","Tutorial"));r.addView(h);TextView b=info(t.optString("body",""),false);r.addView(b);String url=t.optString("video_url","");if(!url.isEmpty()){Button v=buttonSecondary("ABRIR VÍDEO");r.addView(v,new LinearLayout.LayoutParams(-1,dp(54)));v.setOnClickListener(x->{try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception ignored){}});}}backButton(r,()->renderState(launcher,false));setContentView(s);}


    private void syncOnlineInstalledApps(JSONObject launcher){try{String token=launcher.optString("device_apps_token","");String code=LauncherStore.getDeviceCode(this);if(token.isEmpty()||code.isEmpty()||!isOnline())return;long now=System.currentTimeMillis();boolean full=(lastInventorySyncAt==0L||now-lastInventorySyncAt>=INVENTORY_SYNC_MS);String body="device_code="+enc(code)+"&token="+enc(token);if(full){JSONArray inventory=buildInstalledAppsInventory();body+="&inventory_full=1&inventory="+enc(inventory.toString());}String json=httpPostForm(Config.BASE_URL+"/api/device_apps_sync.php",body);JSONObject reply=new JSONObject(json);if(!"ok".equalsIgnoreCase(reply.optString("status")))return;if(full)lastInventorySyncAt=now;JSONObject cmd=reply.optJSONObject("command");if(cmd!=null)processRemoteAppCommand(cmd,token);}catch(Exception ignored){}}

    private JSONArray buildInstalledAppsInventory(){JSONArray out=new JSONArray();try{PackageManager pm=getPackageManager();List<ApplicationInfo> list=pm.getInstalledApplications(PackageManager.GET_META_DATA);java.util.HashSet<String> seen=new java.util.HashSet<>();for(ApplicationInfo ai:list){if(ai==null||ai.packageName==null||ai.packageName.trim().isEmpty())continue;String pkg=ai.packageName.trim();boolean system=(ai.flags&(ApplicationInfo.FLAG_SYSTEM|ApplicationInfo.FLAG_UPDATED_SYSTEM_APP))!=0;if(!seen.add(pkg))continue;JSONObject a=new JSONObject();a.put("package_name",pkg);CharSequence label=pm.getApplicationLabel(ai);a.put("app_name",label==null?pkg:String.valueOf(label));try{PackageInfo pi=pm.getPackageInfo(pkg,0);a.put("version_name",pi.versionName==null?"":pi.versionName);if(Build.VERSION.SDK_INT>=28)a.put("version_code",pi.getLongVersionCode());else a.put("version_code",pi.versionCode);}catch(Exception e){a.put("version_name","");a.put("version_code",0);}a.put("is_system",system);out.put(a);if(out.length()>=1000)break;}}catch(Exception ignored){}return out;}

    private void processRemoteAppCommand(JSONObject cmd,String token){
        long id=cmd.optLong("id",0L);String action=cmd.optString("action","");String pkg=cmd.optString("package_name","").trim();
        if("install".equals(action)){String url=cmd.optString("download_url","");String name=cmd.optString("app_name",pkg);if(!url.isEmpty())installRemoteApk(id,url,pkg,name,token);}
        else if("uninstall".equals(action)){if(!pkg.isEmpty()&&!pkg.equals(getPackageName()))uninstallRemotePackage(id,pkg,token);}
    }

    private void reportRemoteCommand(long id,String token,String status,String error){
        if(id<=0||token==null||token.isEmpty())return;String code=LauncherStore.getDeviceCode(this);if(code.isEmpty())return;
        new Thread(()->{try{String body="device_code="+enc(code)+"&token="+enc(token)+"&command_id="+id+"&command_status="+enc(status)+"&error="+enc(error==null?"":error);httpPostForm(Config.BASE_URL+"/api/device_app_command_status.php",body);}catch(Exception ignored){ }},"app-command-status").start();
    }

    private boolean tryDirectInstall(File f,String pkg){
        try{String path=f.getAbsolutePath().replace("'","'\\''");Process p=Runtime.getRuntime().exec(new String[]{"su","-c","pm install -r '"+path+"'"});int rc=p.waitFor();if(rc==0&&isInstalled(pkg))return true;}catch(Exception ignored){}
        if(DeviceControl.isDeviceOwner(this)){try{Process p=Runtime.getRuntime().exec(new String[]{"sh","-c","pm install -r '"+f.getAbsolutePath().replace("'","'\\''")+"'"});int rc=p.waitFor();if(rc==0&&isInstalled(pkg))return true;}catch(Exception ignored){}}
        return false;
    }

    private boolean tryDirectUninstall(String pkg){
        try{Process p=Runtime.getRuntime().exec(new String[]{"su","-c","pm uninstall --user 0 "+pkg+" || pm uninstall "+pkg});int rc=p.waitFor();if(rc==0&&!isInstalled(pkg))return true;}catch(Exception ignored){}
        if(DeviceControl.isDeviceOwner(this)){try{Process p=Runtime.getRuntime().exec(new String[]{"sh","-c","pm uninstall "+pkg});int rc=p.waitFor();if(rc==0&&!isInstalled(pkg))return true;}catch(Exception ignored){}}
        return false;
    }

    private void installRemoteApk(long commandId,String url,String pkg,String name,String token){
        reportRemoteCommand(commandId,token,"downloading","");
        new Thread(()->{try{File f=new File(getExternalFilesDir(null),"remote_install_"+System.currentTimeMillis()+".apk");downloadToFile(url,f,pct->{});boolean installed=tryDirectInstall(f,pkg);runOnUiThread(()->{if(installed){lastInventorySyncAt=0L;reportRemoteCommand(commandId,token,"done","");Toast.makeText(this,name+" instalado.",Toast.LENGTH_SHORT).show();handler.postDelayed(this::syncLauncher,700L);return;}try{pendingRemoteCommandId=commandId;pendingRemotePackage=pkg;pendingRemoteAction="install";pendingRemoteToken=token;reportRemoteCommand(commandId,token,"awaiting_confirmation","");Uri uri=FileProvider.getUriForFile(this,getPackageName()+".provider",f);Intent i=new Intent(Intent.ACTION_INSTALL_PACKAGE);i.setData(uri);i.putExtra(Intent.EXTRA_RETURN_RESULT,true);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivityForResult(i,REQ_REMOTE_INSTALL);}catch(Exception e){reportRemoteCommand(commandId,token,"failed","Não foi possível abrir a confirmação de instalação: "+e.getMessage());Toast.makeText(this,"Não foi possível abrir o instalador.",Toast.LENGTH_LONG).show();}});}catch(Exception e){reportRemoteCommand(commandId,token,"failed","Falha ao baixar APK: "+e.getMessage());runOnUiThread(()->Toast.makeText(this,"Falha ao baixar APK: "+e.getMessage(),Toast.LENGTH_LONG).show());}},"remote-install").start();
    }

    private void uninstallRemotePackage(long commandId,String pkg,String token){
        new Thread(()->{boolean removed=tryDirectUninstall(pkg);runOnUiThread(()->{if(removed){lastInventorySyncAt=0L;reportRemoteCommand(commandId,token,"done","");Toast.makeText(this,"Aplicativo desinstalado.",Toast.LENGTH_SHORT).show();handler.postDelayed(this::syncLauncher,700L);return;}try{pendingRemoteCommandId=commandId;pendingRemotePackage=pkg;pendingRemoteAction="uninstall";pendingRemoteToken=token;reportRemoteCommand(commandId,token,"awaiting_confirmation","");Intent i=new Intent(Intent.ACTION_UNINSTALL_PACKAGE,Uri.parse("package:"+pkg));i.putExtra(Intent.EXTRA_RETURN_RESULT,true);startActivityForResult(i,REQ_REMOTE_UNINSTALL);}catch(Exception e){reportRemoteCommand(commandId,token,"failed","Android não permitiu abrir a confirmação de desinstalação.");Toast.makeText(this,"Este Android não permitiu abrir a desinstalação.",Toast.LENGTH_LONG).show();}});},"remote-uninstall").start();
    }

    private void finishRemotePackageConfirmation(int requestCode,int resultCode){
        long id=pendingRemoteCommandId;String pkg=pendingRemotePackage,action=pendingRemoteAction,token=pendingRemoteToken;
        pendingRemoteCommandId=0L;pendingRemotePackage="";pendingRemoteAction="";pendingRemoteToken="";
        boolean ok="install".equals(action)?isInstalled(pkg):(!isInstalled(pkg));
        if(ok){lastInventorySyncAt=0L;reportRemoteCommand(id,token,"done","");Toast.makeText(this,"install".equals(action)?"Aplicativo instalado.":"Aplicativo desinstalado.",Toast.LENGTH_SHORT).show();}
        else{reportRemoteCommand(id,token,"failed",resultCode==RESULT_CANCELED?"Confirmação cancelada na TV.":"Android não concluiu a operação.");Toast.makeText(this,"Operação não concluída.",Toast.LENGTH_LONG).show();}
        handler.postDelayed(this::syncLauncher,900L);
    }

    private void processPendingConfigCommand(JSONObject launcher){
        if(launcher==null||configApplying||!isOnline())return;
        JSONObject cmd=launcher.optJSONObject("pending_config_command");if(cmd==null)return;
        long commandId=cmd.optLong("id",0L);String action=cmd.optString("action","");String ackUrl=cmd.optString("ack_url","");String ackToken=cmd.optString("ack_token","");
        if(commandId<=0||!"delete_configs".equals(action)||ackUrl.isEmpty()||ackToken.isEmpty())return;
        long last=getSharedPreferences("launcher_config_delete",MODE_PRIVATE).getLong("last_done_id",0L);if(last==commandId)return;
        configApplying=true;
        new Thread(()->{
            ConfigDeleteResult result=deletePushedConfigsReal();
            boolean ok=result.remaining==0;String error=ok?"":("Ainda restam "+result.remaining+" arquivo(s) .config protegidos pelo Android.");
            try{
                String body="device_code="+enc(LauncherStore.getDeviceCode(this))+"&command_id="+commandId+"&token="+enc(ackToken)+"&ok="+(ok?"1":"0")+"&removed="+result.removed+"&remaining="+result.remaining+"&root_used="+(result.rootUsed?"1":"0")+"&error="+enc(error);
                String ack=httpPostForm(ackUrl,body);JSONObject a=new JSONObject(ack);if(!"ok".equalsIgnoreCase(a.optString("status")))throw new Exception(a.optString("mensagem","Falha ao confirmar limpeza."));
                if(ok)getSharedPreferences("launcher_config_delete",MODE_PRIVATE).edit().putLong("last_done_id",commandId).apply();
                runOnUiThread(()->Toast.makeText(this,ok?(result.removed>0?("Config apagada. "+result.removed+" arquivo(s) removido(s).") : "Nenhuma config encontrada nos 9 caminhos."):("Limpeza parcial: ainda restam "+result.remaining+" arquivo(s) protegidos."),Toast.LENGTH_LONG).show());
            }catch(Exception e){runOnUiThread(()->Toast.makeText(this,"A limpeza foi executada, mas o painel não recebeu a confirmação.",Toast.LENGTH_LONG).show());}
            finally{configApplying=false;handler.postDelayed(this::syncLauncher,1200L);}
        },"delete-config-remote").start();
    }

    private static final class ConfigDeleteResult{
        final int removed;final int remaining;final boolean rootUsed;
        ConfigDeleteResult(int removed,int remaining,boolean rootUsed){this.removed=removed;this.remaining=remaining;this.rootUsed=rootUsed;}
    }

    private ArrayList<File> pushedConfigPaths(){
        ArrayList<File> paths=new ArrayList<>();
        File appDir=getExternalFilesDir(null);if(appDir!=null)addUniqueConfigPath(paths,new File(appDir,Config.NOME_CONFIG_FINAL));
        addUniqueConfigPath(paths,new File("/storage/emulated/0/.config"));
        addUniqueConfigPath(paths,new File("/storage/emulated/0/Android/.config"));
        addUniqueConfigPath(paths,new File("/storage/emulated/0/Download/.config"));
        addUniqueConfigPath(paths,new File("/storage/emulated/0/Documents/.config"));
        addUniqueConfigPath(paths,new File("/sdcard/.config"));
        addUniqueConfigPath(paths,new File("/sdcard/Android/.config"));
        addUniqueConfigPath(paths,new File("/storage/self/primary/.config"));
        addUniqueConfigPath(paths,new File("/storage/self/primary/Android/.config"));
        return paths;
    }

    private ConfigDeleteResult deletePushedConfigsReal(){
        ArrayList<File> paths=pushedConfigPaths();int before=countExistingConfigPaths(paths);boolean rootUsed=false;
        for(int pass=0;pass<4;pass++){
            for(File f:paths){try{if(f!=null&&f.exists()&&f.isFile()){boolean done=f.delete();if(!done&&Build.VERSION.SDK_INT>=Build.VERSION_CODES.O){try{java.nio.file.Files.deleteIfExists(f.toPath());}catch(Throwable ignored){}}}}catch(Throwable ignored){}}
            try{Thread.sleep(160L);}catch(InterruptedException e){Thread.currentThread().interrupt();break;}
        }
        int rootBefore=0,rootAfter=-1;
        try{
            StringBuilder list=new StringBuilder();for(File f:paths)if(f!=null)list.append(' ').append(shellQuoteLocal(f.getAbsolutePath()));
            String script="BEFORE=0; AFTER=0; for P in"+list+"; do [ -f \"$P\" ] && BEFORE=$((BEFORE+1)); done; for PASS in 1 2 3 4; do for P in"+list+"; do [ -e \"$P\" ] || [ -L \"$P\" ] || continue; chmod 600 \"$P\" 2>/dev/null || true; rm -f -- \"$P\" 2>/dev/null || toybox rm -f -- \"$P\" 2>/dev/null || busybox rm -f -- \"$P\" 2>/dev/null || true; done; sync; sleep 0.15; done; for P in"+list+"; do [ -f \"$P\" ] && AFTER=$((AFTER+1)); done; echo CFG_BEFORE=$BEFORE; echo CFG_AFTER=$AFTER";
            Process proc=new ProcessBuilder("su","-c",script).redirectErrorStream(true).start();boolean done=proc.waitFor(22,TimeUnit.SECONDS);if(done){String out=readProcessText(proc);if(proc.exitValue()==0){rootUsed=true;rootBefore=markerInt(out,"CFG_BEFORE=");rootAfter=markerInt(out,"CFG_AFTER=");}}else{try{proc.destroy();}catch(Throwable ignored){}}
        }catch(Throwable ignored){}
        for(File f:paths){try{if(f!=null&&f.exists()&&f.isFile())f.delete();}catch(Throwable ignored){}}
        int javaAfter=countExistingConfigPaths(paths);int totalBefore=Math.max(before,rootBefore);int remaining=rootAfter>=0?Math.max(javaAfter,rootAfter):javaAfter;return new ConfigDeleteResult(Math.max(0,totalBefore-remaining),remaining,rootUsed);
    }

    private int countExistingConfigPaths(List<File> paths){int n=0;for(File f:paths){try{if(f!=null&&f.exists()&&f.isFile())n++;}catch(Throwable ignored){}}return n;}
    private String shellQuoteLocal(String s){return "'"+(s==null?"":s.replace("'","'\"'\"'"))+"'";}
    private String readProcessText(Process p){try{BufferedReader br=new BufferedReader(new InputStreamReader(p.getInputStream()));StringBuilder sb=new StringBuilder();String line;while((line=br.readLine())!=null)sb.append(line).append('\n');br.close();return sb.toString();}catch(Exception e){return "";}}
    private int markerInt(String text,String marker){try{int i=text.lastIndexOf(marker);if(i<0)return 0;i+=marker.length();int j=i;while(j<text.length()&&Character.isDigit(text.charAt(j)))j++;return j>i?Integer.parseInt(text.substring(i,j)):0;}catch(Exception e){return 0;}}

    private void processPendingConfig(JSONObject launcher){
        if(launcher==null||configApplying||!isOnline())return;
        JSONObject pc=launcher.optJSONObject("pending_config");if(pc==null)return;
        long pushId=pc.optLong("id",0L);String url=pc.optString("download_url","");String ackUrl=pc.optString("ack_url","");String ackToken=pc.optString("ack_token","");
        if(pushId<=0||url.isEmpty()||ackUrl.isEmpty()||ackToken.isEmpty())return;
        long last=getSharedPreferences("launcher_config_push",MODE_PRIVATE).getLong("last_applied_id",0L);if(last==pushId)return;
        configApplying=true;
        new Thread(()->{
            boolean applied=false;String error="";
            try{
                byte[] data=downloadBytes(url);if(data==null||data.length<8)throw new Exception("Config recebida está vazia.");
                int saved=savePushedConfig(data);if(saved<=0)throw new Exception("O Android não permitiu salvar a config nos caminhos da UniTV.");
                applied=true;
                String body="device_code="+enc(LauncherStore.getDeviceCode(this))+"&push_id="+pushId+"&token="+enc(ackToken)+"&ok=1";
                String ack=httpPostForm(ackUrl,body);JSONObject a=new JSONObject(ack);if(!"ok".equalsIgnoreCase(a.optString("status")))throw new Exception(a.optString("mensagem","Falha ao confirmar config."));
                getSharedPreferences("launcher_config_push",MODE_PRIVATE).edit().putLong("last_applied_id",pushId).apply();
                runOnUiThread(()->Toast.makeText(this,"Config enviada pelo revendedor aplicada com sucesso.",Toast.LENGTH_LONG).show());
            }catch(Exception e){
                error=e.getMessage()==null?e.getClass().getSimpleName():e.getMessage();
                if(!applied){
                    try{String body="device_code="+enc(LauncherStore.getDeviceCode(this))+"&push_id="+pushId+"&token="+enc(ackToken)+"&ok=0&error="+enc(error);httpPostForm(ackUrl,body);}catch(Exception ignored){}
                }
                String msg=error;runOnUiThread(()->Toast.makeText(this,"Falha ao aplicar config enviada: "+msg,Toast.LENGTH_LONG).show());
            }finally{
                configApplying=false;handler.postDelayed(this::syncLauncher,1200L);
            }
        },"push-config").start();
    }

    /**
     * Salva a config enviada pelo revendedor nos 9 destinos de compatibilidade do
     * Ativador. A config não fica temporária: permanece como .config no aparelho.
     */
    private int savePushedConfig(byte[] data){
        ArrayList<File> paths=pushedConfigPaths();

        int saved=0;
        for(File f:paths){
            try{
                File parent=f.getParentFile();if(parent!=null&&!parent.exists())parent.mkdirs();
                try(FileOutputStream out=new FileOutputStream(f,false)){out.write(data);out.flush();}
                if(f.isFile()&&f.length()==data.length)saved++;
            }catch(Exception ignored){}
        }
        return saved;
    }

    private void addUniqueConfigPath(List<File> list,File f){
        if(f==null)return;String path=f.getAbsolutePath();for(File x:list)if(x!=null&&x.getAbsolutePath().equals(path))return;list.add(f);
    }

    private void downloadAndInstall(String url,String name){
        if(url.isEmpty()){Toast.makeText(this,"APK indisponível.",Toast.LENGTH_LONG).show();return;}
        final ScrollView screen=baseScroll();final LinearLayout r=container(screen);title(r,"DOWNLOAD",name);
        final TextView st=info("Baixando... 0%",true);r.addView(st);
        final ProgressBar pb=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);pb.setMax(100);pb.setProgress(0);LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,dp(18));pp.setMargins(0,dp(14),0,0);r.addView(pb,pp);setContentView(screen);
        new Thread(()->{try{File f=new File(getExternalFilesDir(null),"launcher_app_"+System.currentTimeMillis()+".apk");downloadToFile(url,f,pct->runOnUiThread(()->{pb.setProgress(pct);st.setText("Baixando... "+pct+"%");}));runOnUiThread(()->{try{Uri uri=FileProvider.getUriForFile(this,getPackageName()+".provider",f);Intent i=new Intent(Intent.ACTION_VIEW);i.setDataAndType(uri,"application/vnd.android.package-archive");i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);}catch(Exception e){Toast.makeText(this,"Não foi possível abrir o instalador.",Toast.LENGTH_LONG).show();}handler.postDelayed(this::syncLauncher,1000);});}catch(Exception e){runOnUiThread(()->{Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();syncLauncher();});}},"download-app").start();
    }

    private interface DownloadProgress{void update(int pct);}
    private void downloadToFile(String url,File file,DownloadProgress progress)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(20000);c.setReadTimeout(120000);int total=c.getContentLength();try(InputStream is=c.getInputStream();FileOutputStream out=new FileOutputStream(file,false)){byte[] b=new byte[65536];int n;long done=0;int last=0;progress.update(0);while((n=is.read(b))>0){out.write(b,0,n);done+=n;if(total>0){int pct=(int)Math.min(99L,done*100L/total);if(pct>last){last=pct;progress.update(pct);}}}out.flush();}finally{c.disconnect();}progress.update(100);}

    private String currentVersionName(){try{PackageInfo p=getPackageManager().getPackageInfo(getPackageName(),0);return p.versionName==null?"":p.versionName;}catch(Exception e){return "";}}
    private long currentVersionCode(){try{PackageInfo p=getPackageManager().getPackageInfo(getPackageName(),0);return Build.VERSION.SDK_INT>=28?p.getLongVersionCode():p.versionCode;}catch(Exception e){return 0L;}}

    private void maybePromptSelfUpdate(JSONObject root){
        JSONObject u=root.optJSONObject("activator_update");if(u==null)return;long remote=u.optLong("version_code",0L);String url=u.optString("url","");if(remote<=currentVersionCode()||url.isEmpty()||remote==updatePromptedCode)return;updatePromptedCode=remote;
        String ver=u.optString("version_name",String.valueOf(remote));
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(26),dp(23),dp(26),dp(10));card.setBackground(border(Color.rgb(21,21,29),Color.rgb(58,38,44),20,1));
        TextView badge=info("NOVA ATUALIZAÇÃO",false);badge.setTextColor(Color.rgb(255,105,120));badge.setTypeface(Typeface.DEFAULT_BOLD);badge.setTextSize(isTv()?16:12);card.addView(badge,new LinearLayout.LayoutParams(-1,-2));
        TextView ttl=new TextView(this);ttl.setText("Ativador Launcher "+ver);ttl.setTextColor(TEXT);ttl.setTextSize(isTv()?30:24);ttl.setTypeface(Typeface.DEFAULT_BOLD);ttl.setGravity(Gravity.CENTER);LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2);tp.setMargins(0,dp(8),0,dp(7));card.addView(ttl,tp);
        TextView desc=info("Uma nova versão está pronta. O download acontece dentro da Launcher e suas configurações são mantidas.",false);card.addView(desc,new LinearLayout.LayoutParams(-1,-2));
        TextView flow=info("Versão "+currentVersionName()+"  →  "+ver+"\nDownload seguro • Validação • Confirmação pelo Android",true);LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,-2);fp.setMargins(0,dp(14),0,0);card.addView(flow,fp);
        AlertDialog dialog=new AlertDialog.Builder(this).setView(card).setNegativeButton("AGORA NÃO",null).setPositiveButton("ATUALIZAR AGORA",(d,w)->downloadSelfUpdate(url)).create();
        dialog.setOnShowListener(x->{Button ok=dialog.getButton(AlertDialog.BUTTON_POSITIVE);Button no=dialog.getButton(AlertDialog.BUTTON_NEGATIVE);if(ok!=null){ok.setTextColor(primary);ok.setTypeface(Typeface.DEFAULT_BOLD);}if(no!=null)no.setTextColor(MUTED);});dialog.show();
    }

    private void downloadSelfUpdate(String url){
        final ScrollView screen=baseScroll();final LinearLayout r=container(screen);title(r,"ATUALIZAÇÃO EM ANDAMENTO","Não desligue o aparelho durante o download.");final TextView st=info("Preparando... 0%",true);r.addView(st);final TextView hint=info("Ao concluir, o Android abrirá a confirmação de instalação.",false);r.addView(hint);final ProgressBar pb=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);pb.setMax(100);pb.setProgress(0);LinearLayout.LayoutParams pl=new LinearLayout.LayoutParams(-1,dp(18));pl.setMargins(0,dp(12),0,0);r.addView(pb,pl);setContentView(screen);
        new Thread(()->{try{File f=new File(getExternalFilesDir(null),"ativador_launcher_update.apk");downloadToFile(url,f,pct->runOnUiThread(()->{pb.setProgress(pct);st.setText(pct<100?"Baixando atualização... "+pct+"%":"Download concluído • verificando arquivo");}));if(!selfUpdateCompatible(f))throw new Exception("A atualização publicada não corresponde à base oficial instalada.");runOnUiThread(()->{st.setText("Atualização pronta");hint.setText("Abrindo a confirmação do Android...");handler.postDelayed(()->{try{Uri uri=FileProvider.getUriForFile(this,getPackageName()+".provider",f);Intent i=new Intent(Intent.ACTION_VIEW);i.setDataAndType(uri,"application/vnd.android.package-archive");i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);}catch(Exception e){Toast.makeText(this,"Falha ao abrir atualização.",Toast.LENGTH_LONG).show();}},450L);});}catch(Exception e){runOnUiThread(()->{Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();renderCachedOrLoading();});}},"self-update-launcher").start();
    }

    @SuppressWarnings("deprecation") private boolean selfUpdateCompatible(File apk){try{PackageManager pm=getPackageManager();PackageInfo cur=pm.getPackageInfo(getPackageName(),PackageManager.GET_SIGNATURES);PackageInfo next=pm.getPackageArchiveInfo(apk.getAbsolutePath(),PackageManager.GET_SIGNATURES);if(next==null||!getPackageName().equals(next.packageName))return false;Signature[] a=cur.signatures,b=next.signatures;return a!=null&&b!=null&&a.length>0&&b.length>0&&Arrays.equals(a[0].toByteArray(),b[0].toByteArray());}catch(Exception e){return false;}}


    private boolean isInstalled(String pkg){try{getPackageManager().getPackageInfo(pkg,0);return true;}catch(Exception e){return false;}}
    private void openPackage(String pkg){try{Intent i=getPackageManager().getLaunchIntentForPackage(pkg);if(i==null){Intent q=new Intent(Intent.ACTION_MAIN);q.addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);q.setPackage(pkg);List<ResolveInfo> rs=getPackageManager().queryIntentActivities(q,0);if(!rs.isEmpty()&&rs.get(0).activityInfo!=null){i=new Intent(Intent.ACTION_MAIN);i.addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);i.setComponent(new ComponentName(pkg,rs.get(0).activityInfo.name));}}if(i!=null){i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);}}catch(Exception ignored){}}
    private void openActivator(boolean force){Intent i=new Intent(this,MainActivity.class);if(force)i.putExtra("force_activation_ui",true);startActivity(i);}

    private ScrollView baseScroll(){ScrollView s=new ScrollView(this);s.setFillViewport(true);s.setBackgroundColor(BG);return s;}
    private LinearLayout container(ScrollView s){LinearLayout out=new LinearLayout(this);out.setOrientation(LinearLayout.VERTICAL);out.setGravity(Gravity.CENTER);out.setPadding(dp(18),dp(26),dp(18),dp(26));s.addView(out,new ScrollView.LayoutParams(-1,-1));LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setGravity(Gravity.CENTER_HORIZONTAL);r.setPadding(dp(28),dp(26),dp(28),dp(28));r.setBackground(border(Color.argb(225,18,18,25),Color.argb(110,255,255,255),22,1));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(isTv()?dp(820):-1,-2);lp.gravity=Gravity.CENTER;out.addView(r,lp);return r;}
    private boolean isTv(){int mode=getResources().getConfiguration().uiMode&android.content.res.Configuration.UI_MODE_TYPE_MASK;return mode==android.content.res.Configuration.UI_MODE_TYPE_TELEVISION||!getPackageManager().hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN);}
    private void title(LinearLayout r,String t,String sub){TextView a=new TextView(this);a.setText(t);a.setTextColor(TEXT);a.setTextSize(isTv()?30:24);a.setTypeface(Typeface.DEFAULT_BOLD);a.setGravity(Gravity.CENTER);r.addView(a,new LinearLayout.LayoutParams(-1,-2));TextView b=info(sub,false);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(8),0,dp(18));r.addView(b,lp);}
    private TextView section(String s){TextView t=new TextView(this);t.setText(s);t.setTextColor(TEXT);t.setTextSize(isTv()?21:17);t.setTypeface(Typeface.DEFAULT_BOLD);t.setPadding(0,dp(22),0,dp(8));return t;}
    private TextView info(String s,boolean box){TextView t=new TextView(this);t.setText(s);t.setTextColor(MUTED);t.setTextSize(isTv()?18:15);t.setGravity(Gravity.CENTER);t.setPadding(dp(14),dp(14),dp(14),dp(14));if(box)t.setBackground(border(Color.argb(110,30,30,40),Color.argb(100,255,255,255),14,1));return t;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(isTv()?19:16);b.setTypeface(Typeface.DEFAULT_BOLD);b.setAllCaps(false);b.setBackground(border(primary,primary,14,1));b.setFocusable(true);return b;}
    private Button buttonSecondary(String s){Button b=button(s);b.setBackground(border(Color.rgb(42,42,54),Color.argb(100,255,255,255),14,1));return b;}
    private EditText input(String hint,String value){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(Color.rgb(130,130,145));e.setTextColor(Color.WHITE);e.setText(value);e.setSingleLine(true);e.setTextSize(isTv()?18:16);e.setPadding(dp(15),dp(13),dp(15),dp(13));e.setBackground(border(Color.rgb(17,17,24),Color.rgb(65,65,82),12,1));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(isTv()?66:58));lp.setMargins(0,dp(7),0,dp(7));e.setLayoutParams(lp);return e;}
    private void configureDone(EditText a,View next){a.setImeOptions(EditorInfo.IME_ACTION_NEXT);a.setOnEditorActionListener((v,id,event)->{if(id==EditorInfo.IME_ACTION_NEXT||(event!=null&&event.getKeyCode()==KeyEvent.KEYCODE_ENTER)){next.requestFocus();return true;}return false;});}
    private void backButton(LinearLayout r,Runnable run){Button b=buttonSecondary("VOLTAR");LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(54));lp.setMargins(0,dp(16),0,0);r.addView(b,lp);b.setOnClickListener(v->run.run());}
    private GradientDrawable border(int bg,int stroke,int radius,int sw){GradientDrawable g=new GradientDrawable();g.setColor(bg);g.setCornerRadius(dp(radius));g.setStroke(dp(sw),stroke);return g;}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}

    private void loadImage(ImageView v,String url,String cacheName){new Thread(()->{try{File f=new File(getFilesDir(),cacheName);if(f.isFile()){Bitmap cached=BitmapFactory.decodeFile(f.getAbsolutePath());if(cached!=null)runOnUiThread(()->v.setImageBitmap(cached));}if(!isOnline()||url==null||url.isEmpty())return;HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(12000);Bitmap b=BitmapFactory.decodeStream(c.getInputStream());c.disconnect();if(b!=null){try(FileOutputStream out=new FileOutputStream(f)){b.compress(Bitmap.CompressFormat.PNG,92,out);}Bitmap finalB=b;runOnUiThread(()->v.setImageBitmap(finalB));}}catch(Exception ignored){}} ,"img").start();}
    private void loadBackground(ScrollView s,String url){new Thread(()->{try{File f=new File(getFilesDir(),"background.cache");if(f.isFile()){Bitmap cached=BitmapFactory.decodeFile(f.getAbsolutePath());if(cached!=null)runOnUiThread(()->s.setBackground(new CenterCropDrawable(cached)));}if(!isOnline()||url==null||url.isEmpty())return;HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setUseCaches(false);c.setRequestProperty("Cache-Control","no-cache");c.setConnectTimeout(5000);c.setReadTimeout(9000);Bitmap b=BitmapFactory.decodeStream(c.getInputStream());c.disconnect();if(b!=null){try(FileOutputStream out=new FileOutputStream(f)){b.compress(Bitmap.CompressFormat.JPEG,90,out);}Bitmap finalB=b;runOnUiThread(()->s.setBackground(new CenterCropDrawable(finalB)));}}catch(Exception ignored){}} ,"bg").start();}

    private static final class CenterCropDrawable extends Drawable{
        private final Bitmap bitmap;private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
        CenterCropDrawable(Bitmap b){bitmap=b;}
        @Override public void draw(Canvas canvas){if(bitmap==null)return;android.graphics.Rect bounds=getBounds();float sx=bounds.width()/(float)bitmap.getWidth(),sy=bounds.height()/(float)bitmap.getHeight(),scale=Math.max(sx,sy);float w=bitmap.getWidth()*scale,h=bitmap.getHeight()*scale;float left=bounds.left+(bounds.width()-w)/2f,top=bounds.top+(bounds.height()-h)/2f;canvas.drawBitmap(bitmap,null,new RectF(left,top,left+w,top+h),paint);}
        @Override public void setAlpha(int a){paint.setAlpha(a);invalidateSelf();}
        @Override public void setColorFilter(ColorFilter f){paint.setColorFilter(f);invalidateSelf();}
        @Override public int getOpacity(){return PixelFormat.OPAQUE;}
    }
    private String enc(String v)throws Exception{return URLEncoder.encode(v==null?"":v,"UTF-8");}
    private String httpGet(String url)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setUseCaches(false);c.setDefaultUseCaches(false);c.setRequestProperty("Cache-Control","no-cache, no-store, max-age=0");c.setRequestProperty("Pragma","no-cache");c.setRequestProperty("Connection","close");c.setConnectTimeout(5000);c.setReadTimeout(9000);c.setRequestMethod("GET");InputStream is=c.getResponseCode()>=400?c.getErrorStream():c.getInputStream();if(is==null)throw new Exception("Servidor não respondeu.");BufferedReader br=new BufferedReader(new InputStreamReader(is));StringBuilder sb=new StringBuilder();String l;while((l=br.readLine())!=null)sb.append(l);br.close();c.disconnect();return sb.toString();}
    private String httpPostForm(String url,String body)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(15000);c.setReadTimeout(30000);c.setRequestMethod("POST");c.setDoOutput(true);c.setRequestProperty("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");try(java.io.OutputStream os=c.getOutputStream()){os.write(body.getBytes("UTF-8"));}InputStream is=c.getResponseCode()>=400?c.getErrorStream():c.getInputStream();if(is==null)throw new Exception("Servidor não respondeu.");BufferedReader br=new BufferedReader(new InputStreamReader(is));StringBuilder sb=new StringBuilder();String l;while((l=br.readLine())!=null)sb.append(l);br.close();c.disconnect();return sb.toString();}
    private byte[] downloadBytes(String url)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(20000);c.setReadTimeout(60000);InputStream is=c.getInputStream();java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=is.read(b))>0)out.write(b,0,n);is.close();c.disconnect();return out.toByteArray();}
}
