SPOTNET ANDROID V60

Base restaurada exatamente da V53, última base anterior às alterações que afetaram login/conexão/player.

Alterações desta versão:
- LoginActivity restaurada da V53.
- Net.java restaurado da V53.
- Player e StreamResolver mantidos exatamente como na V53.
- Gradle, Manifest e dependências preservados.
- Apenas versionCode/versionName atualizados para 60.
