import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../provider/homeprovider.dart';
import '../utils/color.dart';
import '../utils/constant.dart';
import '../utils/sharedpre.dart';
import '../webservice/apiservices.dart';
import '../webservice/dioclient.dart';

class ProviderSelector extends StatefulWidget {
  const ProviderSelector({super.key});

  @override
  State<ProviderSelector> createState() => _ProviderSelectorState();
}

class _ProviderSelectorState extends State<ProviderSelector> {
  final SharedPre _prefs = SharedPre();
  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _providers = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final data = await ApiService().greenPlayGetProviders();
      final raw = (data['result'] ?? data['data'] ?? []) as List<dynamic>;
      _providers = raw.map((e) => Map<String, dynamic>.from(e as Map)).toList();
      if (Constant.providerId.isEmpty && _providers.isNotEmpty) {
        final active = _providers.firstWhere(
          (e) => (e['active'] ?? 0).toString() == '1',
          orElse: () => _providers.first,
        );
        Constant.providerId = (active['id'] ?? '').toString();
        Constant.providerName = (active['name'] ?? 'Provedor principal').toString();
      }
    } catch (e) {
      _error = 'Não foi possível carregar os provedores.';
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _select(Map<String, dynamic> provider) async {
    final id = (provider['id'] ?? '').toString();
    final name = (provider['name'] ?? 'Provedor').toString();
    if (id.isEmpty) return;
    Constant.providerId = id;
    Constant.providerName = name;
    await _prefs.save('greenplay_provider_id', id);
    await _prefs.save('greenplay_provider_name', name);
    DioClient.instance.setHeader('Provider-Id', id);
    if (!mounted) return;
    final home = Provider.of<HomeProvider>(context, listen: false);
    home.clearProvider();
    await home.getSectionType();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Provedor alterado para $name')),
    );
    Navigator.pop(context, name);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appBgColor,
      appBar: AppBar(
        backgroundColor: appBgColor,
        title: const Text('Provedor de conteúdo'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(child: Text(_error!, style: const TextStyle(color: Colors.white70)))
              : ListView.separated(
                  padding: const EdgeInsets.all(16),
                  itemCount: _providers.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (context, index) {
                    final p = _providers[index];
                    final id = (p['id'] ?? '').toString();
                    final selected = id == Constant.providerId;
                    return InkWell(
                      onTap: () => _select(p),
                      borderRadius: BorderRadius.circular(14),
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: selected ? colorPrimary.withValues(alpha: .16) : lightBlack,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: selected ? colorPrimary : Colors.white12,
                          ),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 42,
                              height: 42,
                              decoration: BoxDecoration(
                                color: Colors.white10,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: const Icon(Icons.dns_rounded, color: Colors.white),
                            ),
                            const SizedBox(width: 13),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    (p['name'] ?? 'Provedor').toString(),
                                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 16),
                                  ),
                                  const SizedBox(height: 3),
                                  Text(
                                    selected ? 'Em uso agora' : 'Toque para usar este provedor',
                                    style: const TextStyle(color: Colors.white54, fontSize: 12),
                                  ),
                                ],
                              ),
                            ),
                            Icon(selected ? Icons.check_circle_rounded : Icons.chevron_right_rounded, color: selected ? colorPrimary : Colors.white38),
                          ],
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}
