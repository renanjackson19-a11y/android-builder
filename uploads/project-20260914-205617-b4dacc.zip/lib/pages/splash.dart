import '../pages/bottombar.dart';
import '../pages/intro.dart';
import '../provider/connectivityprovider.dart';
import '../provider/generalprovider.dart';
import '../provider/homeprovider.dart';
import '../routes/routes_constant.dart';
import '../webpages/webhome.dart';
import '../utils/color.dart';
import '../utils/constant.dart';
import '../utils/utils.dart';
import '../widget/myimage.dart';
import '../utils/sharedpre.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

class Splash extends StatefulWidget {
  const Splash({super.key});

  @override
  State<Splash> createState() => SplashState();
}

class SplashState extends State<Splash> {
  late GeneralProvider generalProvider;
  late ConnectivityProvider connectivityProvider;
  late HomeProvider homeProvider;
  String? seen;
  SharedPre sharedPre = SharedPre();

  @override
  void initState() {
    super.initState();
    generalProvider = Provider.of<GeneralProvider>(context, listen: false);
    homeProvider = Provider.of<HomeProvider>(context, listen: false);
    connectivityProvider = Provider.of<ConnectivityProvider>(
      context,
      listen: false,
    );
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _getData();
    });
  }

  Future<void> _getData() async {
    if (connectivityProvider.isOnline) {
      await generalProvider.getGeneralsetting(context);
    }

    if (!mounted) return;
    isFirstCheck();
  }

  @override
  void dispose() {
    SystemChrome.setEnabledSystemUIMode(
      SystemUiMode.manual,
      overlays: SystemUiOverlay.values,
    );
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        alignment: Alignment.center,
        color: appBgColor,
        child: MyImage(
          imagePath: (kIsWeb || Constant.isTV) ? "appicon.png" : "splash.png",
          fit: (kIsWeb || Constant.isTV) ? BoxFit.contain : BoxFit.cover,
        ),
      ),
    );
  }

  Future<void> isFirstCheck() async {
    if (!mounted) return;

    await homeProvider.setLoading(true);

    final introScreenStatus = await Utils.configByStatus(
      status: Constant.introScreenStatus,
    );
    final seen = await sharedPre.read('seen') ?? "0";
    final hasIntroSlides =
        (generalProvider.introScreenModel.result != null) &&
        (generalProvider.introScreenModel.result?.isNotEmpty ?? false);

    printLog('introScreenStatus ==> $introScreenStatus');
    printLog('seen ==> $seen');
    printLog(
      'introScreenModel length ==> ${generalProvider.introScreenModel.result?.length ?? 0}',
    );

    if (kIsWeb || Constant.isTV) {
      return _navigate(
        const WebHome(
          newPage: RoutesConstant.homePage,
          oldPage: RoutesConstant.homePage,
          reqText: '',
        ),
      );
    }

    if (introScreenStatus != "1") {
      return _navigate(const Bottombar());
    }

    if (seen == "1") {
      return _navigate(const Bottombar());
    }

    return _navigate(hasIntroSlides ? const Intro() : const Bottombar());
  }

  void _navigate(Widget page) {
    if (!mounted) return;
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => page));
  }
}
