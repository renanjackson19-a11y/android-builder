pluginManagement {
    val flutterSdkPath = run {
        val fromEnv = System.getenv("FLUTTER_ROOT")
            ?: System.getenv("FLUTTER_HOME")

        if (!fromEnv.isNullOrBlank()) {
            fromEnv
        } else {
            val properties = java.util.Properties()
            val localFile = file("local.properties")
            if (localFile.isFile) {
                localFile.inputStream().use { properties.load(it) }
            }
            properties.getProperty("flutter.sdk")
                ?: error("Flutter SDK não encontrado. Defina FLUTTER_ROOT ou flutter.sdk em local.properties")
        }
    }

    includeBuild("$flutterSdkPath/packages/flutter_tools/gradle")

    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

plugins {
    id("dev.flutter.flutter-plugin-loader") version "1.0.0"
    id("com.android.application") version "8.11.1" apply false
    id("org.jetbrains.kotlin.android") version "2.2.20" apply false
    id("com.google.gms.google-services") version "4.4.2" apply false
    id("org.gradle.toolchains.foojay-resolver-convention") version "0.8.0" apply false
}

include(":app")
