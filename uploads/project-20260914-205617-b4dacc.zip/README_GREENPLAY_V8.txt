GreenPlay DTLive v8
Base: v6 build rapido (mesma configuracao Android/Gradle que ja compilava)
Alteracoes: somente correcao de leitura de datas no Dart para aceitar ano isolado como 2025.
Nenhum arquivo em android/ foi alterado em relacao a v6.
