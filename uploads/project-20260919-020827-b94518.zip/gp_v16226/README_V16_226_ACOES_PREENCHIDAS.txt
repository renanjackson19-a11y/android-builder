GreenPlay v16.226 - ações de Assistir/Baixar preenchidas corretamente

- Ajustado o modal de ações de filmes e episódios na TV.
- A área onde aparece Assistir e Baixar agora ocupa corretamente a largura do painel.
- Removido o espaço lateral incorreto à esquerda.
- Mantido o foco do controle remoto com destaque visual.
- Mantidas todas as correções anteriores.
