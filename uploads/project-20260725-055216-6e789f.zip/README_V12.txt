SPOTNET MUSIC V12 — ORGANIZAÇÃO DO PLAYER E PLAYLISTS

- Mini player simplificado: capa, título, play/pausa e próxima.
- Controles completos foram separados e ficam na aba Fila.
- Ao tocar em qualquer capa da tela inicial, abre uma página com várias músicas daquela seção.
- Tela de playlist possui Tocar, Aleatório e lista de faixas.
- Corrigido carregamento de banners quando o painel retorna caminho relativo.
- Mantidos API automática, fila e reprodução em segundo plano da V10.
