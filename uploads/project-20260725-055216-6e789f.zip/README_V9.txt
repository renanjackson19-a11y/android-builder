SPOTNET MUSIC V9 — MAIS CANTORES E CATEGORIAS

Base usada: V8, que já estava gerando e reproduzindo corretamente.

Melhorias:
- Mais de 25 seções automáticas.
- Sertanejo, forró, piseiro, arrocha, pagode, samba, funk, gospel, rap, trap, MPB, pop, rock, eletrônica, românticas e anos 80/90.
- Seções automáticas de vários cantores populares.
- Barra “Explore por categoria”; ao tocar, abre a busca daquele gênero.
- Sem cadastro manual de músicas.
- Mantém API automática, player em segundo plano e controles na notificação.
- Cache de 30 minutos para evitar demora e excesso de requisições.

Instalação:
1. Substitua o painel pela pasta panel do pacote completo.
2. Gere o projeto Android normalmente, do mesmo modo usado na V8.
3. Na primeira abertura, o painel pode levar mais tempo para montar o cache; depois fica rápido.
