package com.spotnet.music;

import androidx.annotation.NonNull;
import org.schabi.newpipe.extractor.downloader.Downloader;
import org.schabi.newpipe.extractor.downloader.Request;
import org.schabi.newpipe.extractor.downloader.Response;
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;

public final class SimpleDownloader extends Downloader {
    private static final SimpleDownloader INSTANCE = new SimpleDownloader();
    private final OkHttpClient client = new OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .followRedirects(true)
            .build();

    private SimpleDownloader() {}
    public static SimpleDownloader getInstance() { return INSTANCE; }

    @Override public Response execute(@NonNull Request request) throws IOException, ReCaptchaException {
        String method = request.httpMethod();
        byte[] data = request.dataToSend();
        RequestBody body = data == null ? null : RequestBody.create(data);
        okhttp3.Request.Builder builder = new okhttp3.Request.Builder()
                .url(request.url())
                .method(method, body)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/131 Mobile Safari/537.36");
        for (Map.Entry<String, List<String>> h : request.headers().entrySet()) {
            builder.removeHeader(h.getKey());
            for (String value : h.getValue()) builder.addHeader(h.getKey(), value);
        }
        try (okhttp3.Response r = client.newCall(builder.build()).execute()) {
            if (r.code() == 429) throw new ReCaptchaException("Limite temporário do provedor", request.url());
            String text = "";
            ResponseBody rb = r.body();
            if (rb != null) text = rb.string();
            return new Response(r.code(), r.message(), r.headers().toMultimap(), text, r.request().url().toString());
        }
    }
}
