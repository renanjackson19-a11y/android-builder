package com.spotnet.music;
import java.io.*;import java.net.*;import java.nio.charset.StandardCharsets;
public final class Net{
 public static String get(String url)throws Exception{return request("GET",url,null);}
 public static String post(String url,String body)throws Exception{return request("POST",url,body);}
 private static String request(String method,String url,String body)throws Exception{
   Exception last=null;
   for(int attempt=1;attempt<=3;attempt++){
     HttpURLConnection c=null;
     try{
       c=(HttpURLConnection)new URL(url).openConnection();c.setRequestMethod(method);c.setConnectTimeout(15000);c.setReadTimeout(30000);c.setUseCaches(false);c.setRequestProperty("User-Agent","SpotnetMusic/14.0");c.setRequestProperty("Accept","application/json");
       if(body!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/x-www-form-urlencoded");try(OutputStream o=c.getOutputStream()){o.write(body.getBytes(StandardCharsets.UTF_8));}}
       return read(c);
     }catch(UnknownHostException e){last=new IOException("Internet ou DNS indisponível. Verifique a conexão e tente novamente.",e);
     }catch(SocketTimeoutException e){last=new IOException("O servidor demorou para responder. Tentando novamente...",e);
     }catch(Exception e){last=e;}
     finally{if(c!=null)c.disconnect();}
     try{Thread.sleep(900L*attempt);}catch(InterruptedException ignored){Thread.currentThread().interrupt();}
   }
   throw last!=null?last:new IOException("Falha de conexão");
 }
 private static String read(HttpURLConnection c)throws Exception{int code=c.getResponseCode();InputStream in=code>=400?c.getErrorStream():c.getInputStream();if(in==null)throw new IOException("HTTP "+code);BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8));StringBuilder b=new StringBuilder();String s;while((s=r.readLine())!=null)b.append(s);String text=b.toString();if(code>=400)throw new IOException("HTTP "+code+": "+text);if(text.trim().startsWith("<"))throw new IOException("O servidor devolveu HTML em vez da API. Verifique os arquivos PHP do painel.");return text;}
}
