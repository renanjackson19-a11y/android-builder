package com.spotnet.music;

import org.schabi.newpipe.extractor.ServiceList;
import org.schabi.newpipe.extractor.stream.AudioStream;
import org.schabi.newpipe.extractor.stream.StreamInfo;
import java.util.List;

public final class StreamResolver {
    private StreamResolver() {}

    public static String resolveAudio(String videoId) throws Exception {
        String watchUrl = "https://www.youtube.com/watch?v=" + videoId;
        StreamInfo info = StreamInfo.getInfo(ServiceList.YouTube, watchUrl);
        List<AudioStream> streams = info.getAudioStreams();
        if (streams == null || streams.isEmpty()) throw new Exception("Nenhum áudio disponível para esta música.");
        AudioStream selected = null;
        for (AudioStream stream : streams) {
            if (stream != null && stream.getContent() != null && !stream.getContent().isEmpty()) selected = stream;
        }
        if (selected == null) throw new Exception("Não foi possível obter o áudio desta música.");
        return selected.getContent();
    }
}
