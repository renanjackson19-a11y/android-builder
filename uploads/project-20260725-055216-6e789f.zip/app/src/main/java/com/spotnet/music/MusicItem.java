package com.spotnet.music;
public class MusicItem{public final String id,type,title,subtitle,thumb,videoId;public MusicItem(String id,String type,String title,String subtitle,String thumb,String videoId){this.id=id;this.type=type;this.title=title;this.subtitle=subtitle;this.thumb=thumb;this.videoId=videoId;}}
