package com.spotnet.music;

import android.app.Application;
import org.schabi.newpipe.extractor.NewPipe;

public class SpotnetApp extends Application {
    @Override public void onCreate() {
        super.onCreate();
        NewPipe.init(SimpleDownloader.getInstance());
    }
}
