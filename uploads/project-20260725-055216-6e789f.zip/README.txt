SPOTNET MUSIC ANDROID V4

Este projeto já está apontado para:
https://spotnet.br232.shop

Carrega diretamente do painel:
- /api/banners.php
- /api/music/home.php
- /api/music/search.php
- /api/login.php

Envie este ZIP no seu compilador e selecione APK de teste (debug).
