SPOTNET MUSIC V10

- Baseada na V9 que já gera e toca.
- Catálogo automático atualizado a cada 10 minutos.
- Mais tocadas, lançamentos e músicas virais.
- Tocar seção inteira em sequência.
- Próxima e anterior no mini player.
- Fila visível com várias músicas.
- Modo aleatório.
- Ao tocar em resultado da busca, os demais entram na fila.
- Até 30 músicas resolvidas por fila para continuar tocando em segundo plano.
