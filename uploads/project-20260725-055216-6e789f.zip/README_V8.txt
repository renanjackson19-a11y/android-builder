SPOTNET MUSIC V8

Base utilizada: V6 API automática, a mesma versão que estava gerando e tocando corretamente.

Alterações seguras:
- Splash/abertura Spotnet Music.
- Login redesenhado.
- API automática preservada.
- Player nativo em segundo plano preservado.
- Estrutura Gradle, serviço de reprodução e tela principal da V6 preservados.

Domínio configurado:
https://spotnet.br232.shop
