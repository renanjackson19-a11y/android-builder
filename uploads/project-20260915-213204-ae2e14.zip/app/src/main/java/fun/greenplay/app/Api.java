package fun.greenplay.app;
import android.os.*;import org.json.*;import java.io.*;import java.net.*;import java.nio.charset.StandardCharsets;import java.util.*;
public class Api {
 static final String BASE="https://greenplay.fun/api/dtlive/";
 static String PROVIDER="";
 static final String TOKEN="454946ee403e82a9657eafc76091ccb6d8ccd4a8fadfca45";
 interface CB{void ok(JSONObject j);void err(String e);}
 static void post(String ep, Map<String,String> data, CB cb){new Thread(()->{try{String endpoint=BASE+ep+"/";if(PROVIDER!=null&&!PROVIDER.isEmpty())endpoint+="?provider_id="+URLEncoder.encode(PROVIDER,"UTF-8");URL u=new URL(endpoint);HttpURLConnection c=(HttpURLConnection)u.openConnection();c.setRequestMethod("POST");c.setConnectTimeout(15000);c.setReadTimeout(ep.equals("section_list")?65000:25000);c.setDoOutput(true);c.setRequestProperty("Api-Token",TOKEN);c.setRequestProperty("X-GreenPlay-Key",TOKEN);if(PROVIDER!=null&&!PROVIDER.isEmpty())c.setRequestProperty("Provider-Id",PROVIDER);c.setRequestProperty("Content-Type","application/json");JSONObject b=new JSONObject();for(String k:data.keySet())b.put(k,data.get(k));if(PROVIDER!=null&&!PROVIDER.isEmpty())b.put("provider_id",PROVIDER);try(OutputStream o=c.getOutputStream()){o.write(b.toString().getBytes(StandardCharsets.UTF_8));}InputStream in=(c.getResponseCode()<400?c.getInputStream():c.getErrorStream());String s=read(in);JSONObject j=new JSONObject(s);new Handler(Looper.getMainLooper()).post(()->cb.ok(j));}catch(Exception e){new Handler(Looper.getMainLooper()).post(()->cb.err(e.getMessage()));}}).start();}
 static String read(InputStream i)throws Exception{BufferedReader r=new BufferedReader(new InputStreamReader(i));StringBuilder s=new StringBuilder();String l;while((l=r.readLine())!=null)s.append(l);return s.toString();}
 static Map<String,String> m(String...x){Map<String,String>m=new HashMap<>();for(int i=0;i+1<x.length;i+=2)m.put(x[i],x[i+1]);return m;}
}
