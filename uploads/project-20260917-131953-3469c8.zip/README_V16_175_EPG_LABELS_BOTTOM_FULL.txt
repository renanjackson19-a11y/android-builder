GreenPlay v16.175

Base: v16.174

- Corrigidos os textos ATUAL e PRÓXIMO que estavam cortados.
- Labels e títulos usam altura automática e font padding desativado.
- Barra EPG aumentada para 152dp e colada ao rodapé.
- Barra ocupa toda a largura e o fundo chega até o final da tela embaixo.
- Cantos inferiores quadrados para não deixar sobras visuais no rodapé; apenas os cantos superiores ficam arredondados.
- Player e preenchimento lateral da v16.173/v16.174 não foram alterados.
