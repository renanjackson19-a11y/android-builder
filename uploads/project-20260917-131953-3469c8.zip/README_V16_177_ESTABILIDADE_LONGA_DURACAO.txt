GreenPlay v16.177

Base: v16.176

Sem mudança visual. Correções de estabilidade para uso prolongado:
- FLAG_KEEP_SCREEN_ON no modo TV para impedir suspensão/screensaver agressivo de alguns TV Box;
- proteção de callbacks de heartbeat e EPG contra execução após encerramento da Activity;
- limpeza de cache de imagens/detalhes em pressão de memória;
- liberação defensiva do player no onDestroy;
- largeHeap para dar mais margem em aparelhos/TV Box com pouca memória;
- mantém fullscreen, EPG e player exatamente como na v16.176.
