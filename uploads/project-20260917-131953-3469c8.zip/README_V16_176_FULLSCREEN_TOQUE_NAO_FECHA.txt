GreenPlay v16.176

- Corrigido: toque/clique no vídeo enquanto já está em tela cheia NÃO reduz mais a tela.
- Toque em tela cheia apenas exibe/reexibe o EPG temporário.
- A tela cheia só é fechada pelo botão Voltar/Back do controle da TV ou pelo Voltar do Android/celular.
- Mantidos os ajustes visuais e de EPG da v16.175.
