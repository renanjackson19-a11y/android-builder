package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private boolean phone;
    private TextView online, clock;
    private LinearLayout body;
    private final Handler handler = new Handler();
    private final Runnable clockTask = new Runnable() {
        @Override public void run() {
            if (clock != null) clock.setText(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()));
            handler.postDelayed(this, 30000);
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        if (!Session.isLogged(this)) { startActivity(new Intent(this, LoginActivity.class)); finish(); return; }
        phone = Ui.phone(this);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        Ui.immersive(this);
        setContentView(build());
        load();
        handler.post(clockTask);
    }

    @Override protected void onResume() { super.onResume(); Ui.immersive(this); }
    @Override protected void onDestroy() { handler.removeCallbacksAndMessages(null); super.onDestroy(); }

    private View build() {
        LinearLayout root = Ui.column(this);
        root.setBackground(Ui.diagonalGradient(Ui.BG_2, Ui.BG, 0, this));
        root.addView(header(), new LinearLayout.LayoutParams(-1, Ui.dp(this, phone ? 56 : 66)));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setVerticalScrollBarEnabled(false);
        body = Ui.column(this);
        body.setPadding(Ui.dp(this, phone ? 16 : 28), Ui.dp(this, 10), Ui.dp(this, phone ? 16 : 28), Ui.dp(this, 28));
        scroll.addView(Ui.centered(this, body, 1480), new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        return root;
    }

    private View header() {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(Ui.dp(this, phone ? 14 : 24), 0, Ui.dp(this, phone ? 14 : 24), 0);
        row.setBackgroundColor(Ui.GLASS_DARK);

        LinearLayout brandBox = new LinearLayout(this);
        brandBox.setGravity(Gravity.CENTER_VERTICAL);
        brandBox.setPadding(Ui.dp(this, 8), 0, Ui.dp(this, 16), 0);
        brandBox.setBackground(Ui.round(Color.argb(42,255,255,255), 22, this));
        TextView mark = Ui.text(this, "▶", phone ? 13 : 16, Color.WHITE, true);
        mark.setGravity(Gravity.CENTER);
        mark.setBackground(Ui.gradient(Ui.GREEN, Ui.GREEN_2, 10, this));
        brandBox.addView(mark, new LinearLayout.LayoutParams(Ui.dp(this, 38), Ui.dp(this, 38)));
        TextView brand = Ui.text(this, "DUBAI PLAY", phone ? 15 : 18, Ui.TEXT, true);
        LinearLayout.LayoutParams btp = new LinearLayout.LayoutParams(-2, Ui.dp(this, 40)); btp.leftMargin = Ui.dp(this, 10);
        brandBox.addView(brand, btp);
        row.addView(brandBox, new LinearLayout.LayoutParams(Ui.dp(this, phone ? 170 : 220), Ui.dp(this, 46)));

        row.addView(new View(this), new LinearLayout.LayoutParams(Ui.dp(this, phone ? 4 : 10), 1));
        addNav(row, "TV", false, () -> openTvAuto());
        addNav(row, "DESTAQUES", true, () -> {});
        addNav(row, "FILMES", false, () -> openCatalog("movie", "Filmes", "", ""));
        addNav(row, "SÉRIES", false, () -> openCatalog("series", "Séries", "", ""));
        addNav(row, "KIDS", false, () -> openDiscover("kids", "Kids"));
        addNav(row, "ANIME", false, () -> openDiscover("anime", "Anime"));
        addNav(row, "EXPLORAR", false, () -> openDiscover("all", "Explorar"));
        row.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1));

        TextView search = Ui.ghostButton(this, "⌕");
        search.setContentDescription("Buscar");
        search.setOnClickListener(v -> startActivity(new Intent(this, SearchActivity.class)));
        row.addView(search, new LinearLayout.LayoutParams(Ui.dp(this, 40), Ui.dp(this, 38)));
        TextView profile = Ui.ghostButton(this, "●");
        profile.setContentDescription("Perfil");
        profile.setOnClickListener(v -> startActivity(new Intent(this, ProfileActivity.class)));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(Ui.dp(this, 40), Ui.dp(this, 38)); pp.leftMargin = Ui.dp(this, 5);
        row.addView(profile, pp);
        online = Ui.text(this, "●", 10, Ui.MUTED, true); online.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(Ui.dp(this, 24), Ui.dp(this, 40)); op.leftMargin = Ui.dp(this, 5);
        row.addView(online, op);
        clock = Ui.text(this, "--:--", phone ? 10 : 12, Ui.TEXT, true); clock.setGravity(Gravity.CENTER);
        row.addView(clock, new LinearLayout.LayoutParams(Ui.dp(this, 58), Ui.dp(this, 40)));
        return row;
    }

    private void addNav(LinearLayout row, String label, boolean selected, Runnable action) {
        TextView n = Ui.nav(this, label, selected);
        n.setOnClickListener(v -> action.run());
        row.addView(n, new LinearLayout.LayoutParams(Ui.dp(this, phone ? 72 : 96), Ui.dp(this, 44)));
    }

    private void load() {
        body.removeAllViews();
        TextView loading = Ui.text(this, "Carregando sua programação...", 12, Ui.MUTED, false);
        loading.setGravity(Gravity.CENTER);
        body.addView(loading, new LinearLayout.LayoutParams(-1, Ui.dp(this, 180)));
        ApiClient.home(new ApiClient.Callback<ApiClient.HomeData>() {
            @Override public void ok(ApiClient.HomeData h) { runOnUiThread(() -> render(h)); }
            @Override public void error(String m) { runOnUiThread(() -> renderError(m)); }
        });
        ApiClient.status(new ApiClient.Callback<String>() {
            @Override public void ok(String s) { runOnUiThread(() -> online.setTextColor(Ui.GREEN)); }
            @Override public void error(String m) { runOnUiThread(() -> online.setTextColor(Ui.RED)); }
        });
    }

    private void render(ApiClient.HomeData h) {
        body.removeAllViews();
        online.setTextColor(Ui.GREEN);
        ApiClient.Item hero = h.hero != null ? h.hero : (!h.movies.isEmpty() ? h.movies.get(0) : (!h.series.isEmpty() ? h.series.get(0) : null));

        body.addView(buildEditorialMosaic(hero, h), new LinearLayout.LayoutParams(-1, Ui.dp(this, phone ? 285 : 365)));
        addContinueWatching();
        addShelf("Destaques para você", merge(h.movies, h.series), "", phone ? 170 : 210);
        addShelf("TV agora", h.live, "live", phone ? 125 : 150);
        addShelf("Filmes", h.movies, "movie", phone ? 175 : 215);
        addShelf("Séries", h.series, "series", phone ? 175 : 215);
    }

    private View buildEditorialMosaic(ApiClient.Item hero, ApiClient.HomeData h) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);

        FrameLayout main = imageTile(hero, clean(hero == null ? null : hero.name, "Dubai Play"), "DESTAQUE", true, () -> openItem(hero));
        row.addView(main, new LinearLayout.LayoutParams(0, -1, 2.15f));

        LinearLayout middle = Ui.column(this);
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(0, -1, 1.05f); mp.leftMargin = Ui.dp(this, 5);
        row.addView(middle, mp);
        ApiClient.Item m1 = h.movies.size() > 1 ? h.movies.get(1) : hero;
        ApiClient.Item m2 = h.series.isEmpty() ? hero : h.series.get(0);
        FrameLayout a = imageTile(m1, clean(m1 == null ? null : m1.name, "Lançamentos"), "FILMES", false, () -> openItem(m1));
        FrameLayout b = imageTile(m2, clean(m2 == null ? null : m2.name, "Séries"), "SÉRIES", false, () -> openItem(m2));
        middle.addView(a, new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, 0, 1); bp.topMargin = Ui.dp(this, 5); middle.addView(b, bp);

        LinearLayout right = Ui.column(this);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(0, -1, .98f); rp.leftMargin = Ui.dp(this, 5);
        row.addView(right, rp);
        ApiClient.Item r1 = h.series.size() > 1 ? h.series.get(1) : m2;
        ApiClient.Item r2 = h.live.isEmpty() ? hero : h.live.get(0);
        FrameLayout c = imageTile(r1, "KIDS + ANIME", "COLEÇÕES", false, () -> openDiscover("kids", "Kids"));
        FrameLayout d = imageTile(r2, "TV AO VIVO", "AGORA", false, () -> openTvAuto());
        right.addView(c, new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1, 0, 1); dp.topMargin = Ui.dp(this, 5); right.addView(d, dp);
        return row;
    }

    private FrameLayout imageTile(ApiClient.Item item, String title, String badge, boolean hero, Runnable action) {
        FrameLayout box = new FrameLayout(this);
        box.setFocusable(true); box.setClickable(true); box.setClipToOutline(true);
        Ui.focus(box, this, Ui.round(Ui.PANEL, 3, this), Ui.stroke(Ui.PANEL_2, Ui.GREEN, 3, this));
        ImageView img = new ImageView(this); img.setScaleType(ImageView.ScaleType.CENTER_CROP); img.setBackgroundColor(Ui.PANEL_2);
        box.addView(img, new FrameLayout.LayoutParams(-1, -1));
        if (item != null) ImageLoader.into(this, img, clean(item.backdrop, item.logo));

        View shade = new View(this); shade.setBackground(Ui.verticalGradient(Color.TRANSPARENT, Color.argb(218,0,0,0), 0, this));
        box.addView(shade, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout text = Ui.column(this); text.setPadding(Ui.dp(this, hero ? 24 : 14), Ui.dp(this, 10), Ui.dp(this, 14), Ui.dp(this, hero ? 18 : 12));
        TextView b = Ui.text(this, badge, hero ? 10 : 9, Ui.GREEN, true); text.addView(b, new LinearLayout.LayoutParams(-1, 0, 1));
        TextView t = Ui.text(this, title, hero ? (phone ? 20 : 28) : (phone ? 12 : 16), Ui.TEXT, true); t.setMaxLines(hero ? 2 : 1); text.addView(t, new LinearLayout.LayoutParams(-1, hero ? Ui.dp(this, 68) : Ui.dp(this, 32)));
        if (hero) {
            TextView sub = Ui.text(this, item == null ? "Explore sua programação" : clean(item.group, "Filmes • Séries • TV"), 10, Ui.MUTED, false);
            text.addView(sub, new LinearLayout.LayoutParams(-1, Ui.dp(this, 25)));
        }
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-1, hero ? Ui.dp(this, 135) : Ui.dp(this, 70), Gravity.BOTTOM);
        box.addView(text, tp);
        box.setOnClickListener(v -> action.run());
        return box;
    }

    private void addContinueWatching() {
        List<ApiClient.Item> hist = LocalStore.history(this);
        if (hist == null || hist.isEmpty()) return;
        addShelf("Continue assistindo", hist, "", phone ? 150 : 185);
    }

    private List<ApiClient.Item> merge(List<ApiClient.Item> a, List<ApiClient.Item> b) {
        java.util.ArrayList<ApiClient.Item> out = new java.util.ArrayList<>();
        if (a != null) out.addAll(a);
        if (b != null) out.addAll(b);
        return out;
    }

    private void addShelf(String title, List<ApiClient.Item> items, String type, int h) {
        if (items == null || items.isEmpty()) return;
        LinearLayout head = new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = Ui.text(this, title, phone ? 15 : 20, Ui.TEXT, false);
        head.addView(t, new LinearLayout.LayoutParams(0, Ui.dp(this, 44), 1));
        TextView more = Ui.text(this, "VER TODOS", 9, Ui.GREEN, true); more.setGravity(Gravity.CENTER); more.setFocusable(true);
        more.setOnClickListener(v -> {
            String openType = type;
            if (openType == null || openType.isEmpty()) openType = title.toLowerCase(Locale.US).contains("série") ? "series" : "movie";
            openCatalog(openType, title, "", "");
        });
        head.addView(more, new LinearLayout.LayoutParams(Ui.dp(this, 90), Ui.dp(this, 40)));
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, Ui.dp(this, 46)); hp.topMargin = Ui.dp(this, 6); body.addView(head, hp);

        HorizontalScrollView hsv = new HorizontalScrollView(this); hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.TOP);
        int max = Math.min(items.size(), 18);
        for (int i=0;i<max;i++) {
            ApiClient.Item item = items.get(i);
            View card = poster(item, h);
            int w = "live".equals(item.type) ? (phone ? 150 : 190) : (phone ? 118 : 150);
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(Ui.dp(this, w), Ui.dp(this, h)); cp.rightMargin = Ui.dp(this, 8);
            row.addView(card, cp);
        }
        hsv.addView(row); body.addView(hsv, new LinearLayout.LayoutParams(-1, Ui.dp(this, h)));
    }

    private View poster(ApiClient.Item item, int h) {
        FrameLayout card = new FrameLayout(this); card.setFocusable(true); card.setClickable(true); card.setClipToOutline(true);
        Ui.focus(card, this, Ui.round(Color.TRANSPARENT, 3, this), Ui.stroke(Color.argb(85,255,255,255), Ui.GREEN, 3, this));
        ImageView img = new ImageView(this); img.setScaleType("live".equals(item.type) ? ImageView.ScaleType.CENTER_INSIDE : ImageView.ScaleType.CENTER_CROP); img.setBackgroundColor(Ui.PANEL_2);
        card.addView(img, new FrameLayout.LayoutParams(-1, -1)); ImageLoader.into(this, img, item.logo);
        View shade = new View(this); shade.setBackground(Ui.verticalGradient(Color.TRANSPARENT, Color.argb(220,0,0,0), 0, this)); card.addView(shade, new FrameLayout.LayoutParams(-1,-1));
        TextView name = Ui.text(this, clean(item.name, "Sem nome"), phone ? 9 : 11, Ui.TEXT, true); name.setMaxLines(2); name.setPadding(Ui.dp(this,7),0,Ui.dp(this,7),Ui.dp(this,6));
        FrameLayout.LayoutParams np = new FrameLayout.LayoutParams(-1, Ui.dp(this, 44), Gravity.BOTTOM); card.addView(name, np);
        card.setOnClickListener(v -> openItem(item));
        return card;
    }

    private void openItem(ApiClient.Item i) {
        if (i == null) return;
        if ("series".equals(i.type)) {
            Intent in = new Intent(this, SeriesActivity.class); in.putExtra("title", clean(i.seriesTitle, i.name)); in.putExtra("name", i.name); in.putExtra("logo", i.logo); in.putExtra("backdrop", i.backdrop); startActivity(in);
        } else if ("movie".equals(i.type)) {
            Intent in = new Intent(this, DetailActivity.class); putItem(in, i); startActivity(in);
        } else {
            Intent in = new Intent(this, PlayerActivity.class); putItem(in, i); startActivity(in); LocalStore.addHistory(this, i);
        }
    }

    static void putItem(Intent in, ApiClient.Item i) {
        in.putExtra("id",i.id); in.putExtra("name",i.name); in.putExtra("logo",i.logo); in.putExtra("backdrop",i.backdrop); in.putExtra("group",i.group); in.putExtra("synopsis",i.synopsis); in.putExtra("type",i.type); in.putExtra("format",i.format); in.putExtra("year",i.year); in.putExtra("series_title",i.seriesTitle); in.putExtra("tmdb_id",i.tmdbId);
    }

    private void openCatalog(String type, String title, String category, String smart) {
        Intent in = new Intent(this, CatalogActivity.class); in.putExtra("type", type); in.putExtra("title", title); in.putExtra("category", category); in.putExtra("smart", smart); startActivity(in);
    }
    private void openTvAuto() {
        ApiClient.Item last = LocalStore.lastLive(this);
        if (last != null && last.id > 0) {
            Intent player = new Intent(this, PlayerActivity.class);
            putItem(player, last);
            startActivity(player);
            return;
        }
        Intent in = new Intent(this, CatalogActivity.class);
        in.putExtra("type", "live");
        in.putExtra("title", "TV");
        in.putExtra("autoplay", true);
        startActivity(in);
    }
    private void openDiscover(String smart, String title) { Intent in = new Intent(this, DiscoverActivity.class); in.putExtra("smart", smart); in.putExtra("title", title); startActivity(in); }

    private void renderError(String m) {
        body.removeAllViews();
        FrameLayout card = new FrameLayout(this); card.setBackground(Ui.diagonalGradient(Ui.PANEL_2, Ui.BG_2, 4, this));
        LinearLayout text = Ui.column(this); text.setPadding(Ui.dp(this,28),Ui.dp(this,24),Ui.dp(this,28),Ui.dp(this,20));
        text.addView(Ui.text(this,"Não foi possível atualizar o catálogo",phone?20:26,Ui.TEXT,true),new LinearLayout.LayoutParams(-1,Ui.dp(this,48)));
        text.addView(Ui.text(this,clean(m,"Falha de conexão"),11,Ui.MUTED,false),new LinearLayout.LayoutParams(-1,Ui.dp(this,48)));
        TextView retry=Ui.primaryButton(this,"TENTAR NOVAMENTE"); retry.setOnClickListener(v->load()); text.addView(retry,new LinearLayout.LayoutParams(Ui.dp(this,190),Ui.dp(this,42)));
        card.addView(text,new FrameLayout.LayoutParams(-1,-1)); body.addView(card,new LinearLayout.LayoutParams(-1,Ui.dp(this,180))); online.setTextColor(Ui.RED);
    }

    private String clean(String v, String fallback) { if (v == null) return fallback; String s = v.trim(); return s.isEmpty() || "null".equalsIgnoreCase(s) ? fallback : s; }
}
