package fun.greenplay.app;

import android.app.Activity;
import android.app.UiModeManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.os.Build;

/** Device classification kept deliberately independent from brand-specific UI code. */
public final class DeviceCompat {
 private DeviceCompat(){}

 public static boolean isTelevisionDevice(Context context){
  if(context==null)return false;
  try{
   if(context instanceof Activity){
    Intent in=((Activity)context).getIntent();
    if(in!=null&&in.hasCategory(Intent.CATEGORY_LEANBACK_LAUNCHER))return true;
   }
   UiModeManager ui=(UiModeManager)context.getSystemService(Context.UI_MODE_SERVICE);
   if(ui!=null&&ui.getCurrentModeType()==Configuration.UI_MODE_TYPE_TELEVISION)return true;

   PackageManager pm=context.getPackageManager();
   if(pm!=null){
    if(pm.hasSystemFeature(PackageManager.FEATURE_LEANBACK)
      ||pm.hasSystemFeature("android.software.leanback_only")
      ||pm.hasSystemFeature(PackageManager.FEATURE_TELEVISION)
      ||pm.hasSystemFeature("android.hardware.type.television")
      ||pm.hasSystemFeature("amazon.hardware.fire_tv"))return true;
   }

   Configuration cfg=context.getResources().getConfiguration();
   boolean noTouch=cfg.touchscreen==Configuration.TOUCHSCREEN_NOTOUCH;
   if(pm!=null&&!pm.hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN))noTouch=true;
   boolean dpad=cfg.navigation==Configuration.NAVIGATION_DPAD;
   boolean large=cfg.smallestScreenWidthDp>=600
     ||(cfg.screenLayout&Configuration.SCREENLAYOUT_SIZE_MASK)>=Configuration.SCREENLAYOUT_SIZE_LARGE;
   boolean hdmi=pm!=null&&(pm.hasSystemFeature("android.hardware.hdmi.cec")||pm.hasSystemFeature("android.hardware.hdmi.output"));
   if(hdmi&&dpad)return true;
   if(noTouch&&large&&(dpad||hdmi||cfg.smallestScreenWidthDp>=720))return true;

   String fingerprint=(Build.MANUFACTURER+" "+Build.BRAND+" "+Build.MODEL+" "+Build.PRODUCT+" "+Build.DEVICE).toLowerCase(java.util.Locale.ROOT);
   if(containsAny(fingerprint,"fire tv","firetv","android tv","google tv","bravia","shield android tv","mibox","mi box","tvbox","tv box","smart tv","smarttv")
      ||(noTouch&&containsAny(fingerprint,"x96","mxq","h96","tx3","tx6","tx9","hk1","onn. 4k","chromecast")))return true;
  }catch(Exception ignored){}
  return false;
 }

 private static boolean containsAny(String source,String... terms){
  if(source==null)return false;
  for(String term:terms)if(term!=null&&!term.isEmpty()&&source.contains(term))return true;
  return false;
 }
}
