package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;

final class YellowNav {
    private YellowNav(){}

    static View bar(Activity a,String active){
        boolean phone=Ui.phone(a);
        LinearLayout root=new LinearLayout(a);
        root.setGravity(Gravity.CENTER_VERTICAL);
        root.setPadding(Ui.dp(a,phone?14:28),0,Ui.dp(a,phone?14:26),0);
        root.setBackgroundColor(0xF8000502);

        // Logo geral controlada pelo painel. Quando houver PNG/WEBP remoto,
        // ele substitui o bloco fixo sem recompilar o APK.
        String remoteLogo=BrandConfig.logo(a);
        if(remoteLogo!=null&&!remoteLogo.trim().isEmpty()){
            ImageView brandLogo=new ImageView(a);
            brandLogo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            brandLogo.setPadding(Ui.dp(a,6),Ui.dp(a,5),Ui.dp(a,12),Ui.dp(a,5));
            ImageLoader.into(a,brandLogo,remoteLogo);
            root.addView(brandLogo,new LinearLayout.LayoutParams(Ui.dp(a,phone?150:205),-1));
        }else{
            LinearLayout brand=new LinearLayout(a);
            brand.setGravity(Gravity.CENTER_VERTICAL);
            brand.setPadding(Ui.dp(a,phone?8:12),0,Ui.dp(a,phone?16:22),0);
            TextView mark=Ui.text(a,"▶",phone?11:14,Color.BLACK,true);
            mark.setGravity(Gravity.CENTER);
            mark.setBackground(Ui.gradient(Ui.GREEN,Ui.GREEN_2,9,a));
            brand.addView(mark,new LinearLayout.LayoutParams(Ui.dp(a,phone?34:42),Ui.dp(a,phone?34:42)));
            TextView name=Ui.text(a,"DUBAI PLAY",phone?12:16,Color.WHITE,true);
            LinearLayout.LayoutParams nameLp=new LinearLayout.LayoutParams(-2,-1);nameLp.leftMargin=Ui.dp(a,10);brand.addView(name,nameLp);
            root.addView(brand,new LinearLayout.LayoutParams(Ui.dp(a,phone?150:190),-1));
        }

        LinearLayout tabs=new LinearLayout(a);
        tabs.setGravity(Gravity.CENTER);
        tab(a,tabs,"TV",active,()->openTop(a,LiveTvActivity.class));
        footballTab(a,tabs,active,()->openTop(a,FootballActivity.class));
        tab(a,tabs,"FILMES",active,()->openTop(a,MovieHomeActivity.class));
        tab(a,tabs,"SÉRIES",active,()->mediaTop(a,"series"));
        kidsTab(a,tabs,active,()->mediaTop(a,"kids"));
        animeTab(a,tabs,active,()->mediaTop(a,"anime"));
        if(Session.adultAccess(a)) hotTab(a,tabs,active,()->mediaTop(a,"hot"));
        root.addView(tabs,new LinearLayout.LayoutParams(0,-1,1));

        TextView search=roundAction(a,"⌕");
        search.setOnClickListener(v->open(a,SearchActivity.class));
        root.addView(search,new LinearLayout.LayoutParams(Ui.dp(a,phone?42:48),Ui.dp(a,phone?42:48)));

        TextView profile=roundAction(a,"♙");
        profile.setOnClickListener(v->open(a,ProfileActivity.class));
        LinearLayout.LayoutParams plp=new LinearLayout.LayoutParams(Ui.dp(a,phone?42:48),Ui.dp(a,phone?42:48));
        plp.leftMargin=Ui.dp(a,8);
        root.addView(profile,plp);
        return root;
    }

    private static TextView roundAction(Activity a,String s){
        TextView b=Ui.text(a,s,Ui.phone(a)?13:16,Color.WHITE,true);
        b.setGravity(Gravity.CENTER);b.setFocusable(true);b.setClickable(true);
        Ui.focus(b,a,Ui.round(0xFF202420,32,a),Ui.stroke(0xFF17241B,Ui.GREEN,32,a));
        return b;
    }

    private static void tab(Activity a,LinearLayout row,String label,String active,Runnable action){
        boolean selected=label.equalsIgnoreCase(active==null?"":active);
        FrameLayout box=new FrameLayout(a);
        box.setFocusable(true);box.setClickable(true);

        TextView t=Ui.text(a,label,Ui.phone(a)?11:16,selected?Ui.GREEN:0xFFD8DDD9,selected);
        t.setGravity(Gravity.CENTER);
        box.addView(t,new FrameLayout.LayoutParams(-1,-1));

        if(selected){
            View line=new View(a);line.setBackgroundColor(Ui.GREEN);
            FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(Ui.dp(a,30),Ui.dp(a,3),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
            lp.bottomMargin=Ui.dp(a,3);box.addView(line,lp);
        }

        Ui.focus(box,a,Ui.round(Color.TRANSPARENT,8,a),Ui.round(0x161CFF78,8,a));
        box.setOnClickListener(v->action.run());

        int w=("DESTAQUES".equals(label)||"EXPLORAR".equals(label)||"FUTEBOL".equals(label))?(Ui.phone(a)?88:118):(Ui.phone(a)?72:96);
        row.addView(box,new LinearLayout.LayoutParams(Ui.dp(a,w),Ui.dp(a,46)));
    }


    private static void kidsTab(Activity a,LinearLayout row,String active,Runnable action){
        boolean selected="KIDS".equalsIgnoreCase(active==null?"":active);
        FrameLayout box=new FrameLayout(a);
        box.setFocusable(true);box.setClickable(true);

        ImageView logo=new ImageView(a);
        logo.setImageResource(com.ativacao.app.R.drawable.kids_menu_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        logo.setAdjustViewBounds(true);
        int pad=Ui.dp(a,Ui.phone(a)?10:8);
        logo.setPadding(pad,pad,pad,pad);
        box.addView(logo,new FrameLayout.LayoutParams(-1,-1));

        if(selected){
            View line=new View(a);line.setBackgroundColor(Ui.GREEN);
            FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(Ui.dp(a,32),Ui.dp(a,3),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
            lp.bottomMargin=Ui.dp(a,1);box.addView(line,lp);
        }

        Ui.focus(box,a,Ui.round(Color.TRANSPARENT,8,a),Ui.round(0x161CFF78,8,a));
        box.setOnClickListener(v->action.run());
        row.addView(box,new LinearLayout.LayoutParams(Ui.dp(a,Ui.phone(a)?94:122),Ui.dp(a,46)));
    }

    private static void animeTab(Activity a,LinearLayout row,String active,Runnable action){
        boolean selected="ANIMES".equalsIgnoreCase(active==null?"":active) || "ANIME".equalsIgnoreCase(active==null?"":active);
        FrameLayout box=new FrameLayout(a);
        box.setFocusable(true);box.setClickable(true);

        ImageView logo=new ImageView(a);
        logo.setImageResource(com.ativacao.app.R.drawable.anime_menu_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        int pad=Ui.dp(a,Ui.phone(a)?10:8);
        logo.setPadding(pad,pad,pad,pad);
        box.addView(logo,new FrameLayout.LayoutParams(-1,-1));

        if(selected){
            View line=new View(a);line.setBackgroundColor(Ui.GREEN);
            FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(Ui.dp(a,32),Ui.dp(a,3),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
            lp.bottomMargin=Ui.dp(a,1);box.addView(line,lp);
        }
        Ui.focus(box,a,Ui.round(Color.TRANSPARENT,8,a),Ui.round(0x161CFF78,8,a));
        box.setOnClickListener(v->action.run());
        row.addView(box,new LinearLayout.LayoutParams(Ui.dp(a,Ui.phone(a)?94:122),Ui.dp(a,46)));
    }

    private static void hotTab(Activity a,LinearLayout row,String active,Runnable action){
        boolean selected="HOT".equalsIgnoreCase(active==null?"":active);
        FrameLayout box=new FrameLayout(a);
        box.setFocusable(true);box.setClickable(true);

        ImageView logo=new ImageView(a);
        logo.setImageResource(com.ativacao.app.R.drawable.hot_menu_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        logo.setAdjustViewBounds(true);

        // Mesmo padrão do Anime/Kids.
        int pad=Ui.dp(a,Ui.phone(a)?10:8);
        logo.setPadding(pad,pad,pad,pad);
        box.addView(logo,new FrameLayout.LayoutParams(-1,-1));

        if(selected){
            View line=new View(a);line.setBackgroundColor(Ui.GREEN);
            FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(
                    Ui.dp(a,32),Ui.dp(a,3),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
            lp.bottomMargin=Ui.dp(a,1);box.addView(line,lp);
        }

        Ui.focus(box,a,Ui.round(Color.TRANSPARENT,8,a),Ui.round(0x161CFF78,8,a));
        box.setOnClickListener(v->action.run());

        // EXATAMENTE a mesma caixa do Anime/Kids/Futebol.
        row.addView(box,new LinearLayout.LayoutParams(
                Ui.dp(a,Ui.phone(a)?94:122),Ui.dp(a,46)));
    }

    private static void footballTab(Activity a,LinearLayout row,String active,Runnable action){
        boolean selected="FUTEBOL".equalsIgnoreCase(active==null?"":active);
        FrameLayout box=new FrameLayout(a);
        box.setFocusable(true);box.setClickable(true);

        ImageView logo=new ImageView(a);
        logo.setImageResource(com.ativacao.app.R.drawable.football_menu_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        int pad=Ui.dp(a,Ui.phone(a)?6:4);
        logo.setPadding(pad,pad,pad,pad);
        box.addView(logo,new FrameLayout.LayoutParams(-1,-1));

        if(selected){
            View line=new View(a);line.setBackgroundColor(Ui.GREEN);
            FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(Ui.dp(a,34),Ui.dp(a,3),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
            lp.bottomMargin=Ui.dp(a,1);box.addView(line,lp);
        }
        Ui.focus(box,a,Ui.round(Color.TRANSPARENT,8,a),Ui.round(0x161CFF78,8,a));
        box.setOnClickListener(v->action.run());
        row.addView(box,new LinearLayout.LayoutParams(Ui.dp(a,Ui.phone(a)?94:122),Ui.dp(a,46)));
    }

    private static void open(Activity a,Class<?> c){a.startActivity(new Intent(a,c));}

    private static void openTop(Activity a,Class<?> c){
        if(a.getClass()==c)return;
        Intent i=new Intent(a,c);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        i.putExtra("top_level",true);
        a.startActivity(i);
        a.overridePendingTransition(0,0);
        a.finish();
    }

    private static void mediaTop(Activity a,String mode){
        Intent i=new Intent(a,MediaHomeActivity.class);
        i.putExtra("mode",mode);
        i.putExtra("top_level",true);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        a.startActivity(i);
        a.overridePendingTransition(0,0);
        a.finish();
    }

    private static void catalogTop(Activity a,String type,String title,String smart){
        Intent i=new Intent(a,CatalogActivity.class);
        i.putExtra("type",type);
        i.putExtra("title",title);
        i.putExtra("smart",smart);
        i.putExtra("top_level",true);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        a.startActivity(i);
        a.overridePendingTransition(0,0);
        a.finish();
    }

    private static void smartCatalogTop(Activity a,String mode){
        Intent i=new Intent(a,SmartCatalogActivity.class);
        i.putExtra("mode",mode);
        i.putExtra("top_level",true);
        // Kids e HOT compartilham a mesma Activity: nova instância antes de finalizar
        // evita o fechamento que já ocorreu em versões antigas.
        a.startActivity(i);
        a.overridePendingTransition(0,0);
        a.finish();
    }

    private static void discoverTop(Activity a,String smart,String title){
        Intent i=new Intent(a,DiscoverActivity.class);
        i.putExtra("smart",smart);
        i.putExtra("title",title);
        i.putExtra("top_level",true);

        /*
         * CORREÇÃO DO FECHAMENTO:
         * Kids / Anime / HOT usam a MESMA DiscoverActivity.
         * Antes, CLEAR_TOP + SINGLE_TOP reutilizava a própria Activity atual.
         * Logo depois o código chamava finish() nela, fechando a tela/app.
         *
         * Quando já estamos numa DiscoverActivity, abrimos uma nova instância
         * SEM SINGLE_TOP/CLEAR_TOP e só então encerramos a anterior.
         * Assim troca HOT -> ANIME -> KIDS normalmente, sem empilhar páginas.
         */
        if(a instanceof DiscoverActivity){
            a.startActivity(i);
            a.overridePendingTransition(0,0);
            a.finish();
            return;
        }

        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        a.startActivity(i);
        a.overridePendingTransition(0,0);
        a.finish();
    }
}
