package com.greenplay.tv

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.greenplay.tv.model.CatalogItem
import com.greenplay.tv.ui.GreenPlayViewModel

private val Bg = Color(0xFF07090B)
private val Panel = Color(0xFF111418)
private val Green = Color(0xFF22D968)
private val Muted = Color(0xFFB7BDC6)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { GreenPlayHome { openDetails(it) } } }
    }

    private fun openDetails(item: CatalogItem) {
        startActivity(
            Intent(this, DetailActivity::class.java)
                .putExtra("id", item.id)
                .putExtra("type", item.type)
                .putExtra("title", item.title)
                .putExtra("poster", item.poster)
        )
    }
}

@Composable
fun GreenPlayHome(vm: GreenPlayViewModel = viewModel(), onOpen: (CatalogItem) -> Unit) {
    val state by vm.home.collectAsState()
    val featured = remember(state.sections) { state.sections.firstOrNull()?.items?.firstOrNull() }

    Box(Modifier.fillMaxSize().background(Bg)) {
        when {
            state.loading -> CircularProgressIndicator(Modifier.align(Alignment.Center), color = Green)
            state.error != null -> Text("Erro ao carregar catálogo", color = Color.White, modifier = Modifier.align(Alignment.Center))
            else -> {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    item { Hero(featured, onOpen) }
                    items(state.sections) { sec ->
                        CatalogRow(sec.title, sec.items, onOpen)
                    }
                    item { Spacer(Modifier.height(48.dp)) }
                }
                TopBar(Modifier.align(Alignment.TopCenter))
            }
        }
    }
}

@Composable
private fun TopBar(modifier: Modifier = Modifier) {
    Row(
        modifier
            .fillMaxWidth()
            .height(72.dp)
            .background(Brush.verticalGradient(listOf(Color(0xF207090B), Color(0xA807090B), Color.Transparent)))
            .padding(horizontal = 48.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("GREEN", color = Green, fontSize = 28.sp, fontWeight = FontWeight.Black)
        Text("PLAY", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.width(44.dp))
        NavText("Início", true)
        Spacer(Modifier.width(30.dp))
        NavText("Filmes", false)
        Spacer(Modifier.width(30.dp))
        NavText("Séries", false)
        Spacer(Modifier.weight(1f))
        Text("Pesquisar", color = Muted, fontSize = 15.sp)
        Spacer(Modifier.width(28.dp))
        Text("Minha Lista", color = Muted, fontSize = 15.sp)
    }
}

@Composable
private fun NavText(text: String, active: Boolean) {
    Text(text, color = if (active) Color.White else Muted, fontSize = 16.sp, fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal)
}

@Composable
private fun Hero(item: CatalogItem?, onOpen: (CatalogItem) -> Unit) {
    Box(Modifier.fillMaxWidth().height(390.dp).background(Bg)) {
        if (item != null && item.poster.isNotBlank()) {
            AsyncImage(
                model = item.poster,
                contentDescription = item.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(.62f)
                    .align(Alignment.CenterEnd)
            )
            Box(
                Modifier.fillMaxSize().background(
                    Brush.horizontalGradient(
                        0f to Bg,
                        .38f to Bg,
                        .67f to Color(0xB807090B),
                        1f to Color(0x1507090B)
                    )
                )
            )
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent, Bg))
                )
            )
        }

        Column(
            Modifier
                .align(Alignment.CenterStart)
                .padding(start = 48.dp, top = 56.dp)
                .width(520.dp)
        ) {
            Text("GREENPLAY ORIGINAL", color = Green, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp)
            Spacer(Modifier.height(10.dp))
            Text(item?.title ?: "Seu entretenimento em um só lugar", color = Color.White, fontSize = 42.sp, lineHeight = 46.sp, fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (!item?.year.isNullOrBlank()) Text(item!!.year, color = Color.White, fontSize = 15.sp)
                if (!item?.rating.isNullOrBlank()) {
                    Spacer(Modifier.width(12.dp))
                    Text("★ ${item!!.rating}", color = Color(0xFFFFD45A), fontSize = 15.sp)
                }
                Spacer(Modifier.width(12.dp))
                Text(if (item?.type == "series") "Série" else "Filme", color = Muted, fontSize = 15.sp)
            }
            Spacer(Modifier.height(24.dp))
            if (item != null) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    HeroButton("▶  Assistir", primary = true) { onOpen(item) }
                    HeroButton("＋  Minha Lista", primary = false) { }
                }
            }
        }
    }
}

@Composable
private fun HeroButton(text: String, primary: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(6.dp)
    Box(
        Modifier
            .height(46.dp)
            .clip(shape)
            .background(if (primary) Color.White else Color(0xCC2A2E33))
            .then(if (focused) Modifier.border(3.dp, Green, shape) else Modifier)
            .onFocusChanged { focused = it.isFocused }
            .focusable()
            .clickable { onClick() }
            .padding(horizontal = 20.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (primary) Color.Black else Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun CatalogRow(title: String, list: List<CatalogItem>, onOpen: (CatalogItem) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(top = 2.dp, bottom = 8.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 48.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(12.dp))
            Text("›", color = Green, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        }
        LazyRow(
            contentPadding = PaddingValues(horizontal = 48.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(list, key = { "$title-${it.type}-${it.id}" }) { item -> PosterCard(item, onOpen) }
        }
    }
}

@Composable
fun PosterCard(item: CatalogItem, onOpen: (CatalogItem) -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(10.dp)
    Column(
        Modifier
            .width(154.dp)
            .graphicsLayer {
                scaleX = if (focused) 1.08f else 1f
                scaleY = if (focused) 1.08f else 1f
            }
            .onFocusChanged { focused = it.isFocused }
            .focusable()
            .clickable { onOpen(item) }
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(222.dp)
                .clip(shape)
                .background(Panel)
                .then(if (focused) Modifier.border(3.dp, Green, shape) else Modifier)
        ) {
            AsyncImage(
                model = item.poster,
                contentDescription = item.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            if (focused) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(64.dp)
                        .align(Alignment.BottomCenter)
                        .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xE6000000))))
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(item.title, color = if (focused) Color.White else Color(0xFFE1E4E8), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp, fontWeight = if (focused) FontWeight.SemiBold else FontWeight.Normal)
        if (focused) {
            val meta = listOf(item.year, if (item.type == "series") "Série" else "Filme").filter { it.isNotBlank() }.joinToString(" • ")
            Text(meta, color = Muted, fontSize = 11.sp, maxLines = 1)
        } else {
            Spacer(Modifier.height(14.dp))
        }
    }
}
