package com.greenplay.tv

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.greenplay.tv.player.PlayerActivity
import com.greenplay.tv.ui.GreenPlayViewModel
import kotlinx.coroutines.launch

private val DetailBg = Color(0xFF07090B)
private val DetailGreen = Color(0xFF22D968)

class DetailActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getStringExtra("id") ?: return finish()
        val type = intent.getStringExtra("type") ?: "movie"
        setContent {
            MaterialTheme {
                DetailScreen(type, id) { url, title ->
                    startActivity(Intent(this, PlayerActivity::class.java).putExtra("url", url).putExtra("title", title))
                }
            }
        }
    }
}

@Composable
fun DetailScreen(type: String, id: String, vm: GreenPlayViewModel = viewModel(), play: (String, String) -> Unit) {
    val state by vm.detail.collectAsState()
    val scope = rememberCoroutineScope()
    LaunchedEffect(type, id) { vm.loadDetails(type, id) }

    Box(Modifier.fillMaxSize().background(DetailBg)) {
        val d = state.item
        if (d != null) {
            AsyncImage(
                model = if (d.backdrop.isNotBlank()) d.backdrop else d.poster,
                contentDescription = d.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(DetailBg, Color(0xF207090B), Color(0xA607090B), Color.Transparent))))
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent, DetailBg))))

            Column(
                Modifier
                    .fillMaxHeight()
                    .width(690.dp)
                    .padding(start = 64.dp, top = 84.dp, bottom = 54.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Text("GREENPLAY", color = DetailGreen, fontSize = 14.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Spacer(Modifier.height(12.dp))
                Text(d.title, color = Color.White, fontSize = 46.sp, lineHeight = 50.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(16.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (d.rating.isNotBlank()) Text("★ ${d.rating}", color = Color(0xFFFFD45A), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    if (d.year.isNotBlank()) { Spacer(Modifier.width(16.dp)); Text(d.year, color = Color.White, fontSize = 16.sp) }
                    if (d.duration.isNotBlank()) { Spacer(Modifier.width(16.dp)); Text(d.duration, color = Color(0xFFCDD2D8), fontSize = 16.sp) }
                }
                if (d.genre.isNotBlank()) {
                    Spacer(Modifier.height(10.dp))
                    Text(d.genre, color = Color(0xFFB8BEC7), fontSize = 14.sp)
                }
                Spacer(Modifier.height(20.dp))
                Text(d.plot.ifBlank { "Sinopse não informada." }, color = Color(0xFFF0F1F3), fontSize = 17.sp, lineHeight = 25.sp, maxLines = 6)
                Spacer(Modifier.height(28.dp))

                val first = d.seasons.firstOrNull()?.episodes?.firstOrNull()
                DetailActionButton(
                    text = if (type == "movie") "▶  Assistir agora" else if (first != null) "▶  Assistir S${d.seasons.first().season} E${first.episode_num}" else "▶  Assistir",
                    primary = true
                ) {
                    scope.launch {
                        val episode = if (type == "series") 0 else null
                        runCatching { vm.getPlay(type, id, episode) }
                            .onSuccess { if (it.player_url.isNotBlank()) play(it.player_url, d.title) }
                    }
                }
                Spacer(Modifier.height(12.dp))
                DetailActionButton("＋  Minha Lista", primary = false) { }
            }
        } else if (state.loading) {
            Text("Carregando...", color = Color.White, modifier = Modifier.align(Alignment.Center))
        } else {
            Text(state.error ?: "Não encontrado", color = Color.White, modifier = Modifier.align(Alignment.Center))
        }
    }
}

@Composable
private fun DetailActionButton(text: String, primary: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(7.dp)
    Box(
        Modifier
            .width(235.dp)
            .height(48.dp)
            .clip(shape)
            .background(if (primary) Color.White else Color(0xD02B3035))
            .then(if (focused) Modifier.border(3.dp, DetailGreen, shape) else Modifier)
            .onFocusChanged { focused = it.isFocused }
            .focusable()
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (primary) Color.Black else Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }
}
