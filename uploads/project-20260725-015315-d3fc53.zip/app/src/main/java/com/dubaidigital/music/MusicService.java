package com.dubaidigital.music;
import androidx.media3.common.AudioAttributes; import androidx.media3.common.C;
import androidx.media3.exoplayer.ExoPlayer; import androidx.media3.session.MediaSession;
import androidx.media3.session.MediaSessionService;
public class MusicService extends MediaSessionService {
    private MediaSession session;
    @Override public void onCreate(){
        super.onCreate();
        ExoPlayer p=new ExoPlayer.Builder(this).build();
        p.setAudioAttributes(new AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(),true);
        session=new MediaSession.Builder(this,p).build();
    }
    @Override public MediaSession onGetSession(MediaSession.ControllerInfo info){return session;}
    @Override public void onDestroy(){
        if(session!=null){session.getPlayer().release();session.release();session=null;}
        super.onDestroy();
    }
}
