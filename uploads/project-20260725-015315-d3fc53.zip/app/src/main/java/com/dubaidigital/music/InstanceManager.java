package com.dubaidigital.music;
import org.json.*; import java.util.*; import java.net.URLEncoder;
public final class InstanceManager {
    private static final ArrayList<String> INSTANCES = new ArrayList<>(Arrays.asList(
        "https://pipedapi.adminforge.de",
        "https://pipedapi.reallyaweso.me",
        "https://pipedapi.r4fo.com",
        "https://pipedapi-libre.kavin.rocks",
        "https://pipedapi.kavin.rocks"
    ));
    private static int preferred = 0;

    public static JSONObject getJson(String path) throws Exception {
        Exception last=null;
        for(int offset=0; offset<INSTANCES.size(); offset++){
            int idx=(preferred+offset)%INSTANCES.size();
            String base=INSTANCES.get(idx);
            try{
                JSONObject j=new JSONObject(Net.get(base+path));
                preferred=idx;
                return j;
            }catch(Exception e){ last=e; }
        }
        throw new Exception(last==null?"Nenhum servidor disponível":last.getMessage());
    }

    public static JSONObject search(String query) throws Exception {
        return getJson("/search?q="+URLEncoder.encode(query,"UTF-8")+"&filter=music_songs");
    }

    public static void refreshInstances() {
        new Thread(() -> {
            try {
                String raw=Net.get("https://piped-instances.kavin.rocks/");
                JSONArray arr=new JSONArray(raw);
                ArrayList<String> found=new ArrayList<>();
                for(int i=0;i<arr.length();i++){
                    JSONObject x=arr.optJSONObject(i);
                    if(x==null)continue;
                    String api=x.optString("api_url","");
                    if(api.startsWith("https://")&&!found.contains(api))found.add(api);
                }
                if(!found.isEmpty()){
                    synchronized(INSTANCES){
                        INSTANCES.clear(); INSTANCES.addAll(found); preferred=0;
                    }
                }
            }catch(Exception ignored){}
        }).start();
    }
}
