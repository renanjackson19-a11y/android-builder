package com.dubaidigital.music;
import android.view.*; import android.widget.*; import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide; import java.util.*;
public class SongAdapter extends RecyclerView.Adapter<SongAdapter.H>{
    public interface Click{void onClick(int pos);}
    private final List<Song> data; private final Click click;
    public SongAdapter(List<Song>d,Click c){data=d;click=c;}
    public static class H extends RecyclerView.ViewHolder{
        TextView t,a; ImageView i;
        H(View v){super(v);t=v.findViewById(R.id.title);a=v.findViewById(R.id.artist);i=v.findViewById(R.id.thumb);}
    }
    @Override public H onCreateViewHolder(ViewGroup p,int v){
        return new H(LayoutInflater.from(p.getContext()).inflate(R.layout.item_song,p,false));
    }
    @Override public void onBindViewHolder(H h,int p){
        Song s=data.get(p); h.t.setText(s.title); h.a.setText(s.artist);
        Glide.with(h.i).load(s.thumb).centerCrop().into(h.i);
        h.itemView.setOnClickListener(v->{
            int pos=h.getBindingAdapterPosition();
            if(pos!=RecyclerView.NO_POSITION)click.onClick(pos);
        });
    }
    @Override public int getItemCount(){return data.size();}
}
