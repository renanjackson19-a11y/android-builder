package com.dubaidigital.music;
import android.content.*; import android.os.*; import android.view.*; import android.widget.*;
import androidx.appcompat.app.AppCompatActivity; import androidx.recyclerview.widget.*;
import androidx.media3.common.*; import androidx.media3.session.MediaController; import androidx.media3.session.SessionToken;
import com.google.common.util.concurrent.ListenableFuture; import com.bumptech.glide.Glide;
import org.json.*; import java.util.*;

public class MainActivity extends AppCompatActivity {
    private final ArrayList<Song> searchSongs=new ArrayList<>();
    private final ArrayList<Song> trending=new ArrayList<>();
    private final ArrayList<Song> sertanejo=new ArrayList<>();
    private final ArrayList<Song> discover=new ArrayList<>();
    private SongAdapter searchAdapter;
    private HomeSongAdapter trendingAdapter,sertanejoAdapter,discoverAdapter;
    private TextView homeView,searchView,libraryViewDummy;
    private View homeContainer,searchContainer,libraryContainer;
    private TextView homeMessage,searchMessage,nowTitle,nowArtist,navHome,navSearch,navLibrary;
    private EditText search;
    private Button play;
    private ImageView nowThumb;
    private ListenableFuture<MediaController> future;
    private MediaController controller;

    @Override public void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_main);
        bindViews(); setupLists(); setupNavigation(); setupActions(); connect();
        InstanceManager.refreshInstances();
        loadHome();
    }

    private void bindViews(){
        homeContainer=findViewById(R.id.homeView);
        searchContainer=findViewById(R.id.searchView);
        libraryContainer=findViewById(R.id.libraryView);
        homeMessage=findViewById(R.id.homeMessage);
        searchMessage=findViewById(R.id.searchMessage);
        search=findViewById(R.id.search);
        play=findViewById(R.id.playPause);
        nowTitle=findViewById(R.id.nowTitle);
        nowArtist=findViewById(R.id.nowArtist);
        nowThumb=findViewById(R.id.nowThumb);
        navHome=findViewById(R.id.navHome);
        navSearch=findViewById(R.id.navSearch);
        navLibrary=findViewById(R.id.navLibrary);
    }

    private void setupLists(){
        RecyclerView tr=findViewById(R.id.trendingList);
        RecyclerView se=findViewById(R.id.sertanejoList);
        RecyclerView di=findViewById(R.id.discoverList);
        RecyclerView sr=findViewById(R.id.searchList);
        tr.setLayoutManager(new LinearLayoutManager(this,RecyclerView.HORIZONTAL,false));
        se.setLayoutManager(new LinearLayoutManager(this,RecyclerView.HORIZONTAL,false));
        di.setLayoutManager(new LinearLayoutManager(this,RecyclerView.HORIZONTAL,false));
        sr.setLayoutManager(new LinearLayoutManager(this));
        trendingAdapter=new HomeSongAdapter(trending,p->prepareSong(trending,p));
        sertanejoAdapter=new HomeSongAdapter(sertanejo,p->prepareSong(sertanejo,p));
        discoverAdapter=new HomeSongAdapter(discover,p->prepareSong(discover,p));
        searchAdapter=new SongAdapter(searchSongs,p->prepareSong(searchSongs,p));
        tr.setAdapter(trendingAdapter); se.setAdapter(sertanejoAdapter);
        di.setAdapter(discoverAdapter); sr.setAdapter(searchAdapter);
    }

    private void setupNavigation(){
        navHome.setOnClickListener(v->showTab(0));
        navSearch.setOnClickListener(v->showTab(1));
        navLibrary.setOnClickListener(v->showTab(2));
        showTab(0);
    }

    private void showTab(int tab){
        homeContainer.setVisibility(tab==0?View.VISIBLE:View.GONE);
        searchContainer.setVisibility(tab==1?View.VISIBLE:View.GONE);
        libraryContainer.setVisibility(tab==2?View.VISIBLE:View.GONE);
        navHome.setTextColor(getColor(tab==0?R.color.green:R.color.muted));
        navSearch.setTextColor(getColor(tab==1?R.color.green:R.color.muted));
        navLibrary.setTextColor(getColor(tab==2?R.color.green:R.color.muted));
    }

    private void setupActions(){
        findViewById(R.id.logout).setOnClickListener(v->{
            getSharedPreferences("auth",MODE_PRIVATE).edit().clear().apply();
            startActivity(new Intent(this,LoginActivity.class)); finish();
        });
        findViewById(R.id.searchBtn).setOnClickListener(v->doSearch());
        findViewById(R.id.chipSertanejo).setOnClickListener(v->searchGenre("sertanejo 2026"));
        findViewById(R.id.chipGospel).setOnClickListener(v->searchGenre("gospel 2026"));
        findViewById(R.id.chipForro).setOnClickListener(v->searchGenre("forró 2026"));
        findViewById(R.id.chipPiseiro).setOnClickListener(v->searchGenre("piseiro 2026"));
        findViewById(R.id.chipFunk).setOnClickListener(v->searchGenre("funk 2026"));
        findViewById(R.id.chipRomantica).setOnClickListener(v->searchGenre("músicas românticas"));
        play.setOnClickListener(v->{if(controller==null)return;if(controller.isPlaying())controller.pause();else controller.play();updatePlay();});
        findViewById(R.id.next).setOnClickListener(v->{if(controller!=null)controller.seekToNextMediaItem();});
        findViewById(R.id.prev).setOnClickListener(v->{if(controller!=null)controller.seekToPreviousMediaItem();});
    }

    private void searchGenre(String q){showTab(1);search.setText(q);doSearch();}

    private void loadHome(){
        homeMessage.setText("Carregando destaques...");
        loadSection("músicas mais tocadas brasil 2026",trending,trendingAdapter);
        loadSection("sertanejo 2026",sertanejo,sertanejoAdapter);
        loadSection("lançamentos música brasileira 2026",discover,discoverAdapter);
    }

    private void loadSection(String q,ArrayList<Song> target,RecyclerView.Adapter<?> adapter){
        new Thread(()->{
            try{
                ArrayList<Song> found=parse(InstanceManager.search(q),12);
                runOnUiThread(()->{
                    target.clear();target.addAll(found);adapter.notifyDataSetChanged();
                    if(!trending.isEmpty()&&!sertanejo.isEmpty()&&!discover.isEmpty())
                        homeMessage.setText("Escolha uma música e aproveite.");
                });
            }catch(Exception e){
                runOnUiThread(()->homeMessage.setText("Alguns conteúdos não carregaram. Toque em um estilo ou use a busca."));
            }
        }).start();
    }

    private void doSearch(){
        String q=search.getText().toString().trim();
        if(q.isEmpty())return;
        searchMessage.setText("Buscando músicas...");
        new Thread(()->{
            try{
                ArrayList<Song> found=parse(InstanceManager.search(q),40);
                runOnUiThread(()->{
                    searchSongs.clear();searchSongs.addAll(found);searchAdapter.notifyDataSetChanged();
                    searchMessage.setText(found.isEmpty()?"Nenhum resultado encontrado.":found.size()+" músicas encontradas");
                });
            }catch(Exception e){
                runOnUiThread(()->searchMessage.setText("Servidores temporariamente indisponíveis. Tente novamente."));
            }
        }).start();
    }

    private ArrayList<Song> parse(JSONObject j,int limit){
        ArrayList<Song> found=new ArrayList<>();
        JSONArray a=j.optJSONArray("items");
        if(a==null)return found;
        for(int i=0;i<a.length()&&found.size()<limit;i++){
            JSONObject x=a.optJSONObject(i); if(x==null)continue;
            String id=x.optString("url");
            if(id.contains("v="))id=id.substring(id.indexOf("v=")+2);
            if(id.startsWith("/watch?v="))id=id.substring(9);
            if(id.isEmpty())continue;
            String artist=x.optString("uploaderName",x.optString("uploader","Artista"));
            found.add(new Song(id,x.optString("title","Música"),artist,x.optString("thumbnail","")));
        }
        return found;
    }

    private void connect(){
        SessionToken token=new SessionToken(this,new ComponentName(this,MusicService.class));
        future=new MediaController.Builder(this,token).buildAsync();
        future.addListener(()->{
            try{
                controller=future.get();
                controller.addListener(new Player.Listener(){
                    @Override public void onIsPlayingChanged(boolean p){runOnUiThread(()->updatePlay());}
                    @Override public void onMediaItemTransition(MediaItem item,int reason){runOnUiThread(()->showCurrent(item));}
                });
            }catch(Exception ignored){}
        },Runnable::run);
    }

    private void prepareSong(ArrayList<Song> source,int pos){
        if(controller==null||pos<0||pos>=source.size())return;
        Song selected=source.get(pos);
        nowTitle.setText(selected.title); nowArtist.setText("Preparando áudio...");
        Glide.with(nowThumb).load(selected.thumb).into(nowThumb);
        new Thread(()->{
            try{
                ArrayList<MediaItem> queue=new ArrayList<>();
                int max=Math.min(source.size(),pos+12);
                for(int i=pos;i<max;i++){
                    Song s=source.get(i);
                    String stream=resolve(s.id);
                    MediaMetadata md=new MediaMetadata.Builder().setTitle(s.title).setArtist(s.artist)
                        .setArtworkUri(s.thumb.isEmpty()?null:android.net.Uri.parse(s.thumb)).build();
                    queue.add(new MediaItem.Builder().setUri(stream).setMediaId(s.id).setMediaMetadata(md).build());
                }
                runOnUiThread(()->{
                    controller.setMediaItems(queue);controller.prepare();controller.play();
                    nowArtist.setText(selected.artist);
                });
            }catch(Exception e){
                runOnUiThread(()->nowArtist.setText("Não foi possível tocar agora."));
            }
        }).start();
    }

    private String resolve(String id)throws Exception{
        JSONObject j=InstanceManager.getJson("/streams/"+id);
        JSONArray a=j.optJSONArray("audioStreams");
        if(a==null||a.length()==0)throw new Exception("Áudio indisponível");
        JSONObject best=null;int rate=-1;
        for(int i=0;i<a.length();i++){
            JSONObject x=a.optJSONObject(i);if(x==null)continue;
            int b=x.optInt("bitrate",0);
            if(b>rate){rate=b;best=x;}
        }
        if(best==null)throw new Exception("Stream não encontrado");
        return best.getString("url");
    }

    private void showCurrent(MediaItem item){
        if(item==null)return;
        CharSequence t=item.mediaMetadata.title,a=item.mediaMetadata.artist;
        nowTitle.setText(t==null?"Música":t); nowArtist.setText(a==null?"":a);
        if(item.mediaMetadata.artworkUri!=null)Glide.with(nowThumb).load(item.mediaMetadata.artworkUri).into(nowThumb);
        updatePlay();
    }
    private void updatePlay(){play.setText(controller!=null&&controller.isPlaying()?"Ⅱ":"▶");}
    @Override protected void onDestroy(){if(future!=null)MediaController.releaseFuture(future);super.onDestroy();}
}
