package com.dubaidigital.music;
import android.content.*; import android.os.*; import android.provider.Settings; import android.widget.*;
import androidx.appcompat.app.AppCompatActivity; import org.json.JSONObject;
import java.net.URLEncoder; import java.nio.charset.StandardCharsets;
public class LoginActivity extends AppCompatActivity {
    EditText user,pass; TextView status; Button btn;
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        if(prefs().getBoolean("logged",false)){open();return;}
        setContentView(R.layout.activity_login);
        user=findViewById(R.id.user); pass=findViewById(R.id.pass);
        status=findViewById(R.id.status); btn=findViewById(R.id.loginBtn);
        btn.setOnClickListener(v->login());
    }
    private android.content.SharedPreferences prefs(){return getSharedPreferences("auth",MODE_PRIVATE);}
    private void login(){
        String u=user.getText().toString().trim(), p=pass.getText().toString();
        if(u.isEmpty()||p.isEmpty()){status.setText("Digite usuário e senha.");return;}
        btn.setEnabled(false); status.setText("Verificando acesso...");
        new Thread(()->{
            try{
                String device=Settings.Secure.getString(getContentResolver(),Settings.Secure.ANDROID_ID);
                String body="user="+enc(u)+"&pass="+enc(p)+"&device="+enc(device);
                String raw=Net.post(BuildConfig.PANEL_URL+"/api/login.php",body);
                JSONObject j=new JSONObject(raw);
                if(j.optBoolean("ok")){
                    prefs().edit().putBoolean("logged",true).putString("user",u)
                        .putString("token",j.optString("token")).apply();
                    runOnUiThread(this::open);
                }else runOnUiThread(()->{status.setText(j.optString("message","Acesso negado"));btn.setEnabled(true);});
            }catch(Exception e){
                runOnUiThread(()->{status.setText("Falha ao conectar ao painel: "+e.getMessage());btn.setEnabled(true);});
            }
        }).start();
    }
    private String enc(String s)throws Exception{return URLEncoder.encode(s, StandardCharsets.UTF_8.name());}
    private void open(){startActivity(new Intent(this,MainActivity.class));finish();}
}
