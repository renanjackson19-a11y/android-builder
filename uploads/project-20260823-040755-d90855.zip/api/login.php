<?php
require_once __DIR__.'/../includes/bootstrap.php';
require_once __DIR__.'/../includes/api_auth.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
api_require_auth($config);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok'=>false,'message'=>'Método não permitido'], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    exit;
}

$username=trim((string)($_POST['username']??''));
$password=(string)($_POST['password']??'');
$device=trim((string)($_POST['device']??''));
if($username===''||$password===''){
    http_response_code(400);
    echo json_encode(['ok'=>false,'message'=>'Informe usuário e senha.'],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    exit;
}

$st=$pdo->prepare("SELECT u.id,u.username,u.password_hash,u.status,u.expires_at,u.max_connections,p.name plan_name,r.name reseller_name FROM users u LEFT JOIN plans p ON p.id=u.plan_id LEFT JOIN resellers r ON r.id=u.reseller_id WHERE u.username=? LIMIT 1");
$st->execute([$username]);
$u=$st->fetch();
if(!$u||!password_verify($password,(string)$u['password_hash'])){
    http_response_code(401);
    echo json_encode(['ok'=>false,'message'=>'Usuário ou senha inválidos.'],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    exit;
}
if(($u['status']??'')!=='active'){
    http_response_code(403);
    echo json_encode(['ok'=>false,'message'=>'Este acesso está bloqueado ou expirado.'],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    exit;
}
if(!empty($u['expires_at']) && strtotime((string)$u['expires_at']) < time()){
    $pdo->prepare("UPDATE users SET status='expired' WHERE id=?")->execute([(int)$u['id']]);
    http_response_code(403);
    echo json_encode(['ok'=>false,'message'=>'Seu acesso venceu.'],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    exit;
}
try{
    $details='Usuário: '.$u['username'].($device!==''?' • aparelho: '.$device:'');
    $pdo->prepare("INSERT INTO logs(level,action,details) VALUES('info','login_app',?)")->execute([$details]);
}catch(Throwable $e){}

echo json_encode([
    'ok'=>true,
    'username'=>$u['username'],
    'expires_at'=>$u['expires_at']??'',
    'max_connections'=>(int)($u['max_connections']??1),
    'plan'=>$u['plan_name']??'',
    'reseller'=>$u['reseller_name']??''
],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
