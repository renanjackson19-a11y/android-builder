package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class ProfileActivity extends Activity {
    private boolean phone;
    @Override public void onCreate(Bundle b){super.onCreate(b);Ui.immersive(this);phone=Ui.phone(this);setContentView(build());}

    private View build(){
        LinearLayout page=Ui.column(this);
        page.setBackground(Ui.diagonalGradient(0xFF07160B,0xFF010402,0,this));
        page.addView(YellowNav.bar(this,""),new LinearLayout.LayoutParams(-1,Ui.dp(this,58)));

        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.HORIZONTAL);
        root.setPadding(Ui.dp(this,phone?16:28),Ui.dp(this,6),Ui.dp(this,phone?16:28),Ui.dp(this,6));

        // Coluna fixa da assinatura: tudo cabe dentro da altura útil da TV.
        LinearLayout left=Ui.column(this);
        left.setPadding(Ui.dp(this,13),Ui.dp(this,6),Ui.dp(this,13),Ui.dp(this,6));
        left.setBackground(Ui.stroke(0xEE080E09,0xFF203526,14,this));

        TextView avatar=Ui.text(this,"D",phone?22:28,Color.BLACK,true);
        avatar.setGravity(Gravity.CENTER);
        avatar.setBackground(Ui.gradient(Ui.GREEN,Ui.GREEN_2,60,this));
        LinearLayout.LayoutParams avp=new LinearLayout.LayoutParams(Ui.dp(this,58),Ui.dp(this,58));
        avp.gravity=Gravity.CENTER_HORIZONTAL;
        left.addView(avatar,avp);

        TextView user=Ui.text(this,clean(Session.user(this),"Usuário"),phone?13:16,Ui.TEXT,true);
        user.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams ulp=new LinearLayout.LayoutParams(-1,Ui.dp(this,25));
        ulp.topMargin=Ui.dp(this,4);left.addView(user,ulp);

        TextView premium=Ui.text(this,"★  PREMIUM",9,Color.BLACK,true);
        premium.setGravity(Gravity.CENTER);
        premium.setBackground(Ui.gradient(Ui.GREEN,Ui.GREEN_2,12,this));
        LinearLayout.LayoutParams pr=new LinearLayout.LayoutParams(Ui.dp(this,104),Ui.dp(this,17));
        pr.gravity=Gravity.CENTER_HORIZONTAL;left.addView(premium,pr);

        sectionCompact(left,"SUA ASSINATURA");
        infoCardCompact(left,"PLANO",clean(Session.plan(this),"Ativo"));
        infoCardCompact(left,"VALIDADE",clean(Session.expires(this),"não informada"));
        infoCardCompact(left,"USUÁRIO",clean(Session.user(this),"Usuário"));

        TextView switchAcc=smallButton("↻  TROCAR DE CONTA");
        switchAcc.setOnClickListener(v->startActivity(new Intent(this,LoginActivity.class)));
        addTop(left,switchAcc,8,40);

        TextView exit=smallButton("×  SAIR DA CONTA");
        exit.setOnClickListener(v->{Session.clear(this);startActivity(new Intent(this,LoginActivity.class));finishAffinity();});
        addTop(left,exit,7,40);

        LinearLayout.LayoutParams lpLeft=new LinearLayout.LayoutParams(Ui.dp(this,phone?225:300),-1);
        lpLeft.rightMargin=Ui.dp(this,15);root.addView(left,lpLeft);

        // Área principal fixa, sem rolagem.
        LinearLayout main=Ui.column(this);

        TextView banner=Ui.text(this,"DUBAI PLAY   •   SUA CENTRAL DE ENTRETENIMENTO",phone?15:20,Ui.TEXT,true);
        banner.setGravity(Gravity.CENTER);
        banner.setBackground(Ui.diagonalGradient(0xFF0C2513,0xFF061109,16,this));
        main.addView(banner,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?58:72)));

        TextView hello=Ui.text(this,"Olá, "+clean(Session.user(this),"Usuário")+" 👋\nSua assinatura está ativa — continue aproveitando.",phone?12:15,Ui.TEXT,true);
        hello.setGravity(Gravity.CENTER_VERTICAL);
        hello.setPadding(Ui.dp(this,15),0,Ui.dp(this,15),0);
        hello.setBackground(Ui.stroke(0xCC101712,0xFF203526,12,this));
        addTop(main,hello,8,phone?52:62);

        sectionCompact(main,"AÇÕES RÁPIDAS");
        LinearLayout quick=new LinearLayout(this);
        TextView parental=tile("♙\nCONTROLE PARENTAL",0xFF242B26);
        parental.setOnClickListener(v->startActivity(new Intent(this,ParentalSettingsActivity.class)));
        TextView mobile=tile("▦\nLOGAR NO CELULAR",0xFF123E20);
        mobile.setOnClickListener(v->Toast.makeText(this,"Login no celular em preparação.",Toast.LENGTH_SHORT).show());
        TextView events=tile("★\nCENTRO DE EVENTOS",0xFF164A27);
        events.setOnClickListener(v->Toast.makeText(this,"Nenhum evento novo.",Toast.LENGTH_SHORT).show());
        quick.addView(parental,new LinearLayout.LayoutParams(0,Ui.dp(this,phone?66:82),1));
        addTileFixed(quick,mobile,phone?66:82);addTileFixed(quick,events,phone?66:82);
        main.addView(quick,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?70:86)));

        sectionCompact(main,"CONFIGURAÇÕES");
        LinearLayout config=new LinearLayout(this);
        TextView cache=tile("⌫\nLIMPAR CACHE",0xFF252B27);cache.setOnClickListener(v->Toast.makeText(this,"Cache limpo.",Toast.LENGTH_SHORT).show());
        TextView update=tile("↻\nATUALIZAR",0xFF252B27);update.setOnClickListener(v->Toast.makeText(this,"Dubai Play atualizado.",Toast.LENGTH_SHORT).show());
        TextView about=tile("●\nSOBRE NÓS",0xFF252B27);about.setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class)));
        TextView fav=tile("★\nFAVORITOS",0xFF252B27);fav.setOnClickListener(v->{Intent i=new Intent(this,LibraryActivity.class);i.putExtra("mode","favorites");startActivity(i);});
        TextView notif=tile("♟\nNOTIFICAÇÕES",0xFF252B27);notif.setOnClickListener(v->Toast.makeText(this,"Sem novas notificações.",Toast.LENGTH_SHORT).show());
        int ch=phone?62:76;
        config.addView(cache,new LinearLayout.LayoutParams(0,Ui.dp(this,ch),1));
        addTileFixed(config,update,ch);addTileFixed(config,about,ch);addTileFixed(config,fav,ch);addTileFixed(config,notif,ch);
        main.addView(config,new LinearLayout.LayoutParams(-1,Ui.dp(this,ch+4)));

        root.addView(main,new LinearLayout.LayoutParams(0,-1,1));
        root.setPadding(root.getPaddingLeft(),root.getPaddingTop(),root.getPaddingRight(),Ui.dp(this,8));page.addView(root,new LinearLayout.LayoutParams(-1,0,1));
        parental.requestFocus();
        return page;
    }

    private void section(LinearLayout p,String s){sectionCompact(p,s);}
    private void sectionCompact(LinearLayout p,String s){TextView t=Ui.text(this,s,9,Ui.MUTED,true);LinearLayout.LayoutParams x=new LinearLayout.LayoutParams(-1,Ui.dp(this,25));x.topMargin=Ui.dp(this,6);p.addView(t,x);}
    private void infoCard(LinearLayout p,String label,String value){infoCardCompact(p,label,value);}
    private void infoCardCompact(LinearLayout p,String label,String value){TextView t=Ui.text(this,label+"\n"+value,9,Ui.TEXT,false);t.setGravity(Gravity.CENTER_VERTICAL);t.setPadding(Ui.dp(this,6),0,Ui.dp(this,6),0);t.setBackground(Ui.stroke(0xFF0B100C,0xFF1A271D,8,this));addTop(p,t,5,42);}
    private TextView smallButton(String s){TextView t=Ui.text(this,s,11,Ui.TEXT,true);t.setGravity(Gravity.CENTER);t.setFocusable(true);t.setClickable(true);Ui.focus(t,this,Ui.round(0xFF151B16,8,this),Ui.stroke(0xFF101511,Ui.GREEN,8,this));return t;}
    private TextView tile(String s,int fill){TextView t=Ui.text(this,s,phone?10:12,Ui.TEXT,true);t.setGravity(Gravity.CENTER);t.setFocusable(true);t.setClickable(true);Ui.focus(t,this,Ui.round(fill,12,this),Ui.stroke(fill,Ui.GREEN,12,this));return t;}
    private void addTileFixed(LinearLayout row,TextView t,int h){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,Ui.dp(this,h),1);p.leftMargin=Ui.dp(this,6);row.addView(t,p);}
    private void addTile(LinearLayout row,TextView t){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,Ui.dp(this,phone?76:96),1);p.leftMargin=Ui.dp(this,6);row.addView(t,p);}
    private void addTop(LinearLayout p,View v,int top,int h){LinearLayout.LayoutParams x=new LinearLayout.LayoutParams(-1,Ui.dp(this,h));x.topMargin=Ui.dp(this,top);p.addView(v,x);}
    private String clean(String v,String f){if(v==null)return f;String s=v.trim();return s.isEmpty()||"null".equalsIgnoreCase(s)?f:s;}
    @Override public void onWindowFocusChanged(boolean hasFocus){super.onWindowFocusChanged(hasFocus);if(hasFocus)Ui.immersive(this);}
    @Override protected void onResume(){super.onResume();Ui.immersive(this);}
}
