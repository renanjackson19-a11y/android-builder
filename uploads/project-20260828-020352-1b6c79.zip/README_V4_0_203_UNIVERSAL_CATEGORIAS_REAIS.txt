GREEN PLAY APP V4.0.203
- Modo universal agora tem TV, FILMES, SÉRIES, KIDS, ANIME e HOT.
- Categorias externas são lidas do próprio Xtream (get_*_categories).
- KIDS/ANIME/HOT são montados a partir dos nomes reais das categorias do servidor.
- Não depende de IDs fixos de uma fonte específica.
- Reprodução continua no Media3/ExoPlayer.
- No Green Play padrão, o catálogo continua vindo do painel; use junto com PAINEL V9.0.35 para respeitar bouquet.
