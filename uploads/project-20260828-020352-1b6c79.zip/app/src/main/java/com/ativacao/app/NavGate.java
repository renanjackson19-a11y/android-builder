package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.os.SystemClock;

final class NavGate {
    private static long lastAt=0;
    private NavGate(){}

    static boolean allow(){
        long now=SystemClock.elapsedRealtime();
        if(now-lastAt<320)return false;
        lastAt=now;
        return true;
    }

    static void top(Activity a,Intent i,boolean finishCurrent){
        if(a==null||i==null||!allow())return;
        a.startActivity(i);
        a.overridePendingTransition(0,0);
        if(finishCurrent){
            a.getWindow().getDecorView().postDelayed(()->{
                try{if(!a.isFinishing())a.finish();}catch(Throwable ignored){}
            },120);
        }
    }
}
