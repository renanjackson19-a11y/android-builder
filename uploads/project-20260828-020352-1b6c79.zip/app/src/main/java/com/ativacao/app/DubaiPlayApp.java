package com.ativacao.app;

import android.app.Application;

public class DubaiPlayApp extends Application {
    @Override public void onCreate() {
        super.onCreate();
        PersistentContentCache.init(this);
        CatalogPreloader.init(this);
        ApiClient.setUserToken(Session.token(this));
        if(Session.isLogged(this)){
            ApiClient.setXtreamServer(Session.xtreamHost(this),Session.xtreamUser(this),Session.xtreamPass(this));
        }
        ResumeRefreshManager.install(this);
    }
}
