package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.*;

public class UniversalSeriesActivity extends Activity {
    private LinearLayout list;
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);Ui.immersive(this);
        LinearLayout root=Ui.column(this);root.setPadding(Ui.dp(this,24),Ui.dp(this,18),Ui.dp(this,24),Ui.dp(this,18));root.setBackground(Ui.diagonalGradient(0xFF07160B,0xFF010402,0,this));
        TextView title=Ui.text(this,getIntent().getStringExtra("name"),24,Color.WHITE,true);root.addView(title,new LinearLayout.LayoutParams(-1,Ui.dp(this,48)));
        ScrollView sc=new ScrollView(this);list=Ui.column(this);sc.addView(list);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);load();
    }
    private void load(){list.removeAllViews();TextView l=Ui.text(this,"Carregando episódios...",13,Ui.MUTED,false);list.addView(l);
        int sid=getIntent().getIntExtra("series_id",0);
        UniversalXtream.seriesEpisodes(UniversalSession.host(this),UniversalSession.user(this),UniversalSession.pass(this),sid,new UniversalXtream.Callback<java.util.List<UniversalXtream.Episode>>(){
            public void ok(java.util.List<UniversalXtream.Episode> eps){runOnUiThread(()->{list.removeAllViews();for(UniversalXtream.Episode e:eps){
                TextView row=Ui.button(UniversalSeriesActivity.this,"T"+e.season+" • E"+e.number+"  "+e.title);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,Ui.dp(UniversalSeriesActivity.this,54));p.bottomMargin=Ui.dp(UniversalSeriesActivity.this,7);list.addView(row,p);
                row.setOnClickListener(v->{String u=UniversalXtream.stream(UniversalSession.host(UniversalSeriesActivity.this),UniversalSession.user(UniversalSeriesActivity.this),UniversalSession.pass(UniversalSeriesActivity.this),"series",e.id,e.ext);Intent i=new Intent(UniversalSeriesActivity.this,UniversalPlayerActivity.class);i.putExtra("url",u);startActivity(i);});
            }});}
            public void error(String m){runOnUiThread(()->{list.removeAllViews();list.addView(Ui.text(UniversalSeriesActivity.this,m,13,Ui.RED,true));});}
        });
    }
}
