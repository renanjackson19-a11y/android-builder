package com.ativacao.app;

import android.content.Context;

final class UniversalSession {
    private static final String PREF="green_play_universal";
    private UniversalSession(){}
    static void save(Context c,String name,String host,String user,String pass){
        c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit()
          .putBoolean("active",true).putString("name",name==null?"Servidor IPTV":name)
          .putString("host",host==null?"":host).putString("user",user==null?"":user)
          .putString("pass",pass==null?"":pass).apply();
    }
    static boolean active(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getBoolean("active",false);}
    static String name(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("name","Servidor IPTV");}
    static String host(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("host","");}
    static String user(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("user","");}
    static String pass(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("pass","");}
    static void clear(Context c){c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().clear().apply();}
}
