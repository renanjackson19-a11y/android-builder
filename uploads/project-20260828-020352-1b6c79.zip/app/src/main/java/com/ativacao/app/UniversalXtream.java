package com.ativacao.app;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class UniversalXtream {
    static final ExecutorService IO=Executors.newFixedThreadPool(4);
    interface Callback<T>{void ok(T v);void error(String m);}
    static class Entry{
        int id; String name="",logo="",category="",type="",ext=""; int seriesId=0;
        Entry(int i,String n,String l,String c,String t,String e){id=i;name=n;logo=l;category=c;type=t;ext=e;}
    }
    static class Episode{int id,season,number;String title="",ext="mp4";}
    private static String cleanHost(String h){
        h=h==null?"":h.trim();
        if(!h.startsWith("http://")&&!h.startsWith("https://"))h="http://"+h;
        while(h.endsWith("/"))h=h.substring(0,h.length()-1);
        return h;
    }
    static void login(String host,String user,String pass,Callback<String> cb){
        IO.execute(()->{try{
            JSONObject root=new JSONObject(get(api(host,user,pass,"")));
            JSONObject ui=root.optJSONObject("user_info");
            if(ui==null||!"Active".equalsIgnoreCase(ui.optString("status","Active"))||ui.optString("username","").isEmpty())
                throw new Exception("Usuário ou senha inválidos neste servidor");
            cb.ok(ui.optString("username",user));
        }catch(Exception e){cb.error(msg(e));}});
    }
    static void list(String host,String user,String pass,String type,Callback<List<Entry>> cb){
        IO.execute(()->{try{
            String action="live".equals(type)?"get_live_streams":"movie".equals(type)?"get_vod_streams":"get_series";
            String catAction="live".equals(type)?"get_live_categories":"movie".equals(type)?"get_vod_categories":"get_series_categories";
            java.util.HashMap<String,String> categoryNames=new java.util.HashMap<>();
            try{
                JSONArray ca=new JSONArray(get(api(host,user,pass,catAction)));
                for(int ci=0;ci<ca.length();ci++){
                    JSONObject co=ca.optJSONObject(ci);if(co==null)continue;
                    categoryNames.put(co.optString("category_id",""),co.optString("category_name",""));
                }
            }catch(Exception ignored){}
            JSONArray a=new JSONArray(get(api(host,user,pass,action)));
            List<Entry> out=new ArrayList<>();
            for(int i=0;i<a.length();i++){
                JSONObject o=a.optJSONObject(i);if(o==null)continue;
                int id="series".equals(type)?o.optInt("series_id",0):o.optInt("stream_id",0);
                if(id<=0)continue;
                String name=o.optString("name","Sem nome");
                String logo=o.optString("stream_icon",o.optString("cover",""));
                String catId=o.optString("category_id","");
                String cat=categoryNames.containsKey(catId)?categoryNames.get(catId):catId;
                String ext=o.optString("container_extension","movie".equals(type)?"mp4":"ts");
                Entry e=new Entry(id,name,logo,cat,type,ext);e.seriesId=id;out.add(e);
            }
            cb.ok(out);
        }catch(Exception e){cb.error(msg(e));}});
    }
    static void seriesEpisodes(String host,String user,String pass,int seriesId,Callback<List<Episode>> cb){
        IO.execute(()->{try{
            String u=api(host,user,pass,"get_series_info")+"&series_id="+seriesId;
            JSONObject root=new JSONObject(get(u));
            JSONObject eps=root.optJSONObject("episodes");
            List<Episode> out=new ArrayList<>();
            if(eps!=null){
                java.util.Iterator<String> keys=eps.keys();
                while(keys.hasNext()){
                    String sk=keys.next();JSONArray arr=eps.optJSONArray(sk);if(arr==null)continue;
                    for(int i=0;i<arr.length();i++){
                        JSONObject o=arr.optJSONObject(i);if(o==null)continue;
                        Episode e=new Episode();e.id=o.optInt("id",0);e.season=o.optInt("season",parseInt(sk));e.number=o.optInt("episode_num",i+1);
                        e.title=o.optString("title","Episódio "+e.number);e.ext=o.optString("container_extension","mp4");if(e.id>0)out.add(e);
                    }
                }
            }
            cb.ok(out);
        }catch(Exception e){cb.error(msg(e));}});
    }
    static String stream(String host,String user,String pass,String type,int id,String ext){
        String h=cleanHost(host);
        String p="live".equals(type)?"live":"movie".equals(type)?"movie":"series";
        String e=(ext==null||ext.trim().isEmpty())?("live".equals(type)?"ts":"mp4"):ext.trim();
        try{return h+"/"+p+"/"+URLEncoder.encode(user,"UTF-8")+"/"+URLEncoder.encode(pass,"UTF-8")+"/"+id+"."+e;}catch(Exception x){return "";}
    }
    private static String api(String host,String user,String pass,String action)throws Exception{
        String u=cleanHost(host)+"/player_api.php?username="+URLEncoder.encode(user,"UTF-8")+"&password="+URLEncoder.encode(pass,"UTF-8");
        if(action!=null&&!action.isEmpty())u+="&action="+URLEncoder.encode(action,"UTF-8");
        return u;
    }
    private static String get(String url)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
        c.setConnectTimeout(9000);c.setReadTimeout(20000);c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent","GreenPlay/4.0 Android");c.setRequestProperty("Accept","application/json");
        int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();
        BufferedReader br=new BufferedReader(new InputStreamReader(in,"UTF-8"));StringBuilder sb=new StringBuilder();String line;
        while((line=br.readLine())!=null)sb.append(line);br.close();c.disconnect();
        if(code<200||code>=300)throw new Exception("Servidor respondeu HTTP "+code);
        String t=sb.toString().trim();if(t.isEmpty())throw new Exception("Servidor respondeu vazio");return t;
    }
    private static int parseInt(String s){try{return Integer.parseInt(s);}catch(Exception e){return 0;}}
    private static String msg(Exception e){String m=e.getMessage();return m==null||m.trim().isEmpty()?"Falha de conexão":m;}
}
