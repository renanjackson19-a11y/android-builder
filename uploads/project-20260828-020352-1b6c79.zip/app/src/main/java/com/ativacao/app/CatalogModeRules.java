package com.ativacao.app;

import java.text.Normalizer;
import java.util.Locale;

/** Regras somente de CATEGORIA/FONTE. Nunca adivinha pelo nome do filme/série. */
final class CatalogModeRules {
    private CatalogModeRules(){}

    static boolean kidsCategory(String raw){
        String s=n(raw);
        if(s.isEmpty())return false;
        if(s.contains("anime")||s.contains("adult")||s.contains("xxx")||s.contains("+18")||s.contains("hot"))return false;
        return s.contains("kids")||s.contains("kid ")||s.contains("infantil")||s.contains("crianca")||s.contains("desenho")
                ||s.contains("cartoon")||s.contains("children")||s.contains("child")||s.contains("junior")
                ||s.contains("disney")||s.contains("nickelodeon")||s.contains("nick jr")
                ||s.contains("animacao e infantil")||s.contains("animacao infantil");
    }

    static boolean animeCategory(String raw){
        String s=n(raw);
        if(s.contains("adult")||s.contains("xxx")||s.contains("+18")||s.contains("hot"))return false;
        return s.contains("anime")||s.contains("animes")||s.contains("otaku")||s.contains("manga");
    }

    static boolean adultCategory(String raw){
        String s=n(raw);
        return s.contains("adult")||s.contains("xxx")||s.contains("+18")||s.contains("18+")
                ||s.contains("hot")||s.contains("onlyfans")||s.contains("porno");
    }

    static String n(String raw){
        if(raw==null)return "";
        String s=Normalizer.normalize(raw,Normalizer.Form.NFD).replaceAll("\\p{M}+","");
        return s.toLowerCase(Locale.ROOT).trim();
    }
}
