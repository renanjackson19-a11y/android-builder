package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicInteger;

public class UniversalHomeActivity extends Activity {
    private LinearLayout list,tabs;
    private TextView title,status;
    private String mode="live";

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        Ui.immersive(this);
        mode=getIntent().getStringExtra("mode");
        if(mode==null||mode.trim().isEmpty())mode="live";
        setContentView(build());
        load(mode);
    }

    private android.view.View build(){
        LinearLayout root=Ui.column(this);
        root.setBackground(Ui.diagonalGradient(0xFF07160B,0xFF010402,0,this));
        root.setPadding(Ui.dp(this,22),Ui.dp(this,10),Ui.dp(this,22),Ui.dp(this,12));

        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);
        title=Ui.text(this,"GREEN PLAY  •  "+UniversalSession.name(this),20,Color.WHITE,true);
        head.addView(title,new LinearLayout.LayoutParams(0,Ui.dp(this,52),1));
        TextView exit=Ui.button(this,"TROCAR SERVIDOR");
        head.addView(exit,new LinearLayout.LayoutParams(Ui.dp(this,180),Ui.dp(this,44)));
        exit.setOnClickListener(v->{UniversalSession.clear(this);Session.clear(this);startActivity(new Intent(this,LoginActivity.class));finish();});
        root.addView(head);

        tabs=new LinearLayout(this);tabs.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(tabs,new LinearLayout.LayoutParams(-1,Ui.dp(this,50)));
        renderTabs();

        status=Ui.text(this,"",12,Ui.MUTED,true);status.setGravity(Gravity.CENTER);
        root.addView(status,new LinearLayout.LayoutParams(-1,Ui.dp(this,30)));

        ScrollView sc=new ScrollView(this);list=Ui.column(this);sc.addView(list);
        root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        return root;
    }

    private void renderTabs(){
        tabs.removeAllViews();
        addTab("TV","live");
        addTab("FILMES","movie");
        addTab("SÉRIES","series");
        addTab("KIDS","kids");
        addTab("ANIME","anime");
        addTab("HOT","hot");
    }

    private void addTab(String label,String target){
        TextView v=target.equals(mode)?Ui.primaryButton(this,label):Ui.button(this,label);
        v.setTextSize(11);v.setGravity(Gravity.CENTER);v.setOnClickListener(x->{mode=target;renderTabs();load(target);});
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,Ui.dp(this,44),1);lp.leftMargin=Ui.dp(this,3);lp.rightMargin=Ui.dp(this,3);tabs.addView(v,lp);
    }

    private void load(String target){
        list.removeAllViews();
        status.setText("Carregando "+label(target)+" do servidor...");
        if("live".equals(target)||"movie".equals(target)||"series".equals(target)){
            loadOne(target,false,false,false);
            return;
        }

        // KIDS / ANIME / HOT: não dependem de nomes fixos no APK.
        // Lê filmes + séries e classifica pelas categorias REAIS retornadas pelo servidor.
        ArrayList<UniversalXtream.Entry> all=new ArrayList<>();
        AtomicInteger jobs=new AtomicInteger(2);
        UniversalXtream.Callback<List<UniversalXtream.Entry>> cb=new UniversalXtream.Callback<List<UniversalXtream.Entry>>(){
            public void ok(List<UniversalXtream.Entry> rows){synchronized(all){if(rows!=null)all.addAll(rows);}finishSmart(target,all,jobs);}
            public void error(String m){finishSmart(target,all,jobs);}
        };
        UniversalXtream.list(UniversalSession.host(this),UniversalSession.user(this),UniversalSession.pass(this),"movie",cb);
        UniversalXtream.list(UniversalSession.host(this),UniversalSession.user(this),UniversalSession.pass(this),"series",cb);
    }

    private void finishSmart(String target,ArrayList<UniversalXtream.Entry> all,AtomicInteger jobs){
        if(jobs.decrementAndGet()!=0)return;
        ArrayList<UniversalXtream.Entry> filtered=new ArrayList<>();
        synchronized(all){
            for(UniversalXtream.Entry e:all){
                String c=e==null?"":e.category;
                boolean ok="kids".equals(target)?CatalogModeRules.kidsCategory(c):
                           "anime".equals(target)?CatalogModeRules.animeCategory(c):
                           CatalogModeRules.adultCategory(c);
                if(ok)filtered.add(e);
            }
        }
        runOnUiThread(()->renderRows(filtered,target));
    }

    private void loadOne(String type,boolean a,boolean b,boolean c){
        UniversalXtream.list(UniversalSession.host(this),UniversalSession.user(this),UniversalSession.pass(this),type,new UniversalXtream.Callback<List<UniversalXtream.Entry>>(){
            public void ok(List<UniversalXtream.Entry> rows){runOnUiThread(()->renderRows(rows,type));}
            public void error(String m){runOnUiThread(()->{list.removeAllViews();status.setText(m);});}
        });
    }

    private void renderRows(List<UniversalXtream.Entry> rows,String target){
        list.removeAllViews();
        int count=rows==null?0:rows.size();
        status.setText(count+" "+label(target).toLowerCase(Locale.ROOT));
        if(count==0){
            TextView empty=Ui.text(this,"Nenhum conteúdo dessa seção foi encontrado nas categorias deste servidor.",13,Ui.MUTED,true);
            empty.setGravity(Gravity.CENTER);list.addView(empty,new LinearLayout.LayoutParams(-1,Ui.dp(this,110)));return;
        }
        for(UniversalXtream.Entry e:rows){
            if(e==null)continue;
            LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(Ui.dp(this,12),0,Ui.dp(this,12),0);
            row.setBackground(Ui.stroke(0xD9141921,0xFF253C2D,14,this));
            ImageView img=new ImageView(this);img.setScaleType(ImageView.ScaleType.CENTER_CROP);
            row.addView(img,new LinearLayout.LayoutParams(Ui.dp(this,54),Ui.dp(this,54)));
            if(e.logo!=null&&!e.logo.isEmpty())ImageLoader.into(this,img,e.logo);

            LinearLayout info=Ui.column(this);
            TextView n=Ui.text(this,e.name,14,Color.WHITE,true);
            TextView g=Ui.text(this,e.category==null?"":e.category,9,Ui.MUTED,false);
            info.addView(n,new LinearLayout.LayoutParams(-1,Ui.dp(this,34)));
            info.addView(g,new LinearLayout.LayoutParams(-1,Ui.dp(this,18)));
            LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(0,Ui.dp(this,58),1);ip.leftMargin=Ui.dp(this,12);row.addView(info,ip);

            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,Ui.dp(this,64));rp.bottomMargin=Ui.dp(this,7);list.addView(row,rp);
            row.setOnClickListener(v->open(e));
        }
    }

    private void open(UniversalXtream.Entry e){
        if("series".equals(e.type)){
            Intent i=new Intent(this,UniversalSeriesActivity.class);
            i.putExtra("series_id",e.seriesId);i.putExtra("name",e.name);startActivity(i);return;
        }
        String u=UniversalXtream.stream(UniversalSession.host(this),UniversalSession.user(this),UniversalSession.pass(this),e.type,e.id,e.ext);
        Intent i=new Intent(this,UniversalPlayerActivity.class);i.putExtra("url",u);startActivity(i);
    }

    private String label(String t){
        if("live".equals(t))return "TV";
        if("movie".equals(t))return "FILMES";
        if("series".equals(t))return "SÉRIES";
        if("kids".equals(t))return "KIDS";
        if("anime".equals(t))return "ANIME";
        return "HOT";
    }
}
