package com.ativacao.app;

import android.content.Context;

final class Session {
    private static final String PREF="dubai_play_session";
    private Session(){}
    static boolean isLogged(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getBoolean("logged",false);}
    static void save(Context c,String user,String expires){save(c,user,expires,"",false,"","");}
    static void save(Context c,String user,String expires,String plan){save(c,user,expires,plan,false,"","");}
    static void save(Context c,String user,String expires,String plan,boolean adultAccess,String bouquet,String token){
        c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit()
            .putBoolean("logged",true)
            .putString("user",user==null?"":user)
            .putString("expires",expires==null?"":expires)
            .putString("plan",plan==null?"":plan)
            .putBoolean("adult_access",adultAccess)
            .putString("bouquet",bouquet==null?"":bouquet)
            .putString("user_token",token==null?"":token)
            .apply();
    }
    static String user(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("user","");}
    static String expires(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("expires","");}
    static String plan(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("plan","");}
    static boolean adultAccess(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getBoolean("adult_access",false);}
    static String bouquet(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("bouquet","");}
    static String token(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("user_token","");}
    static void saveXtream(Context c,String host,String user,String pass){
        c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit()
            .putString("xtream_host",host==null?"":host)
            .putString("xtream_user",user==null?"":user)
            .putString("xtream_pass",pass==null?"":pass).apply();
    }
    static String xtreamHost(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("xtream_host","");}
    static String xtreamUser(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("xtream_user","");}
    static String xtreamPass(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("xtream_pass","");}
    static void clear(Context c){c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().clear().apply();}
}
