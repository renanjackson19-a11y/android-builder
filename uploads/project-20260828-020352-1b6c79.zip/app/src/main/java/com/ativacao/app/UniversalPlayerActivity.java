package com.ativacao.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.FrameLayout;
import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

public class UniversalPlayerActivity extends Activity {
    private ExoPlayer player;
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);Ui.immersive(this);
        String url=getIntent().getStringExtra("url");FrameLayout root=new FrameLayout(this);root.setBackgroundColor(0xFF000000);
        PlayerView pv=new PlayerView(this);root.addView(pv,new FrameLayout.LayoutParams(-1,-1));setContentView(root);
        player=new ExoPlayer.Builder(this).build();pv.setPlayer(player);player.setMediaItem(MediaItem.fromUri(url));player.prepare();player.play();
    }
    @Override protected void onStop(){super.onStop();if(player!=null){player.release();player=null;}}
}
