GreenPlay v16.155

Base: v16.154

Ajustes guiados pelo vídeo de referência enviado:
- TV inicia em layout dividido com menu/lista/player; após o canal ficar pronto entra automaticamente em modo assistir, escondendo menu e lista.
- No modo assistir, seta para a esquerda abre a gaveta/lista de canais sem sair do vídeo.
- Voltar fecha primeiro a gaveta; outro Voltar restaura o layout principal da TV.
- Incluída categoria TODOS antes das categorias reais da fonte.
- Filmes/Séries/Kids mantêm categorias à esquerda + grade à direita e agora exibem uma barra Pesquisar... que abre a busca do app.
- Mantidos: 1 OK/1 toque, autoplay, EPG real, logos reais, fullscreen sem crop, estabilidade v16.135 e retorno ao ao vivo.
