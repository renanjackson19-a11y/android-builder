GreenPlay v16.157

Base: v16.156

- Corrigido o modo TV para que a faixa de EPG fique DENTRO do player/canal, como overlay na parte inferior do vídeo.
- A faixa não fica mais fora do canal ocupando área separada abaixo do vídeo.
- Ajustados espaçamentos do texto ATUAL/PRÓXIMO.
