GreenPlay v16.159

Base funcional restaurada: v16.157.

- Remove a tentativa da v16.158 de tornar a superfície do PlayerView transparente.
- Corrige a tela cinza/vazia observada em alguns Android/TV Box.
- Mantém o EPG dentro do player.
- Não altera mais nenhuma parte nesta etapa.
