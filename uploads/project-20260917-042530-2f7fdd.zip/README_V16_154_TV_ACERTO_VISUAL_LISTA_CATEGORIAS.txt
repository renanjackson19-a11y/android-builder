GreenPlay v16.154

Base: v16.153

- Corrige a faixa de categorias para não cortar o primeiro item ao focar/selecionar o segundo.
- Cards dos canais agora preservam a borda completa em volta do número, logo, nome e EPG.
- O indicador ▶ e o bloco do número acompanham corretamente o canal ativo após autoplay/troca de canal.
- EPG inferior principal ficou mais compacto.
- Mantidas as correções anteriores de 1 OK, D-pad, autoplay, logos reais e fullscreen sem crop.
