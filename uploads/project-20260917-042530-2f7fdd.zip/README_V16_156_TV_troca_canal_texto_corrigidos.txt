GreenPlay v16.156
- Troca de canal no modo TV agora é direta no clique/OK do card.
- Textos da programação e overlay ampliados para não ficarem cortados.
