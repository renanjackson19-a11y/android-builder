package com.ativacao.app;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.LruCache;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class ImageLoader {
    private static final ExecutorService IMAGES = Executors.newFixedThreadPool(6);
    private static final Set<String> IN_FLIGHT = Collections.synchronizedSet(new HashSet<>());
    private static final int CACHE_KB = 24 * 1024;
    private static final LruCache<String, Bitmap> CACHE = new LruCache<String, Bitmap>(CACHE_KB) {
        @Override protected int sizeOf(String key, Bitmap value) {
            return Math.max(1, value.getByteCount() / 1024);
        }
    };

    private static File diskFile(Activity a,String url){
        try{ File d=new File(a.getFilesDir(),"image_cache"); if(!d.exists())d.mkdirs(); return new File(d,Integer.toHexString(url.hashCode())+".img"); }catch(Exception e){return null;}
    }
    private static Bitmap decodeFile(File f){
        try{ if(f==null||!f.isFile())return null; BitmapFactory.Options o=new BitmapFactory.Options();o.inPreferredConfig=Bitmap.Config.RGB_565;return BitmapFactory.decodeFile(f.getAbsolutePath(),o);}catch(Exception e){return null;}
    }

    static void into(Activity a, ImageView target, String url) {
        target.setImageDrawable(null);
        load(a,target,url);
    }

    static void intoPoster(Activity a, ImageView target, String url) {
        target.setImageResource(R.drawable.green_play_placeholder);
        load(a,target,url);
    }

    private static void load(Activity a, ImageView target, String url) {
        if (url == null || url.trim().isEmpty()) return;
        final String u = url.trim();
        target.setTag(u);
        Bitmap hit = CACHE.get(u);
        if (hit != null) {
            target.setImageBitmap(hit);
            return;
        }
        // V185: leitura/decodificação do disco sai da UI thread.
        // Isso elimina microtravadas ao rolar/trocar de categoria.
        if (!IN_FLIGHT.add(u)) return;

        IMAGES.execute(() -> {
            HttpURLConnection con = null;
            try {
                Bitmap disk=decodeFile(diskFile(a,u));
                if(disk!=null){
                    CACHE.put(u,disk);
                    final Bitmap ready=disk;
                    a.runOnUiThread(() -> {
                        Object tag=target.getTag();
                        if(tag!=null && u.equals(tag.toString())) target.setImageBitmap(ready);
                    });
                    return;
                }
                con = (HttpURLConnection) new URL(u).openConnection();
                con.setConnectTimeout(3000);
                con.setReadTimeout(7000);
                con.setInstanceFollowRedirects(true);
                con.setRequestProperty("User-Agent", "DubaiPlayTV/1.4 Android");
                con.setRequestProperty("Accept", "image/avif,image/webp,image/apng,image/*,*/*;q=0.8");
                int code = con.getResponseCode();
                if (code < 200 || code >= 300) return;
                InputStream in = con.getInputStream();
                ByteArrayOutputStream out = new ByteArrayOutputStream(96 * 1024);
                byte[] buf = new byte[16 * 1024];
                int n;
                int max = 3 * 1024 * 1024;
                while ((n = in.read(buf)) > 0 && out.size() < max) out.write(buf, 0, n);
                in.close();
                byte[] data = out.toByteArray();
                if (data.length == 0) return;
                try{File f=diskFile(a,u);if(f!=null)try(FileOutputStream fo=new FileOutputStream(f,false)){fo.write(data);}}catch(Exception ignored){}

                BitmapFactory.Options bounds = new BitmapFactory.Options();
                bounds.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(data, 0, data.length, bounds);
                int sample = 1;
                while (bounds.outWidth / sample > 720 || bounds.outHeight / sample > 960) sample *= 2;
                BitmapFactory.Options opts = new BitmapFactory.Options();
                opts.inSampleSize = Math.max(1, sample);
                opts.inPreferredConfig = Bitmap.Config.RGB_565;
                Bitmap bmp = BitmapFactory.decodeByteArray(data, 0, data.length, opts);
                if (bmp != null) {
                    CACHE.put(u, bmp);
                    a.runOnUiThread(() -> {
                        Object tag = target.getTag();
                        if (tag != null && u.equals(tag.toString())) target.setImageBitmap(bmp);
                    });
                }
            } catch (Exception ignored) {
            } finally {
                IN_FLIGHT.remove(u);
                if (con != null) con.disconnect();
            }
        });
    }


    static void intoBackground(Activity a, ImageView target, String url) {
        if (url == null || url.trim().isEmpty()) return;
        final String u = url.trim();
        final String key = u + "#login_bg_full";
        target.setTag(key);

        Bitmap hit = CACHE.get(key);
        if (hit != null) {
            target.setImageBitmap(hit);
            return;
        }

        File df = diskFile(a, u);
        try {
            if (df != null && df.isFile()) {
                BitmapFactory.Options bo = new BitmapFactory.Options();
                bo.inJustDecodeBounds = true;
                BitmapFactory.decodeFile(df.getAbsolutePath(), bo);
                int sample = 1;
                while (bo.outWidth / sample > 1920 || bo.outHeight / sample > 1080) sample *= 2;
                BitmapFactory.Options oo = new BitmapFactory.Options();
                oo.inSampleSize = Math.max(1, sample);
                oo.inPreferredConfig = Bitmap.Config.ARGB_8888;
                Bitmap disk = BitmapFactory.decodeFile(df.getAbsolutePath(), oo);
                if (disk != null) {
                    CACHE.put(key, disk);
                    target.setImageBitmap(disk);
                    return;
                }
            }
        } catch (Exception ignored) {}

        if (!IN_FLIGHT.add(key)) return;

        IMAGES.execute(() -> {
            HttpURLConnection con = null;
            try {
                con = (HttpURLConnection) new URL(u).openConnection();
                con.setConnectTimeout(6000);
                con.setReadTimeout(12000);
                con.setInstanceFollowRedirects(true);
                con.setRequestProperty("User-Agent", "DubaiPlayTV/1.4 Android");
                con.setRequestProperty("Accept", "image/avif,image/webp,image/apng,image/*,*/*;q=0.8");
                int code = con.getResponseCode();
                if (code < 200 || code >= 300) return;

                InputStream in = con.getInputStream();
                ByteArrayOutputStream out = new ByteArrayOutputStream(256 * 1024);
                byte[] buf = new byte[32 * 1024];
                int n;
                int max = 10 * 1024 * 1024;
                while ((n = in.read(buf)) > 0 && out.size() < max) out.write(buf, 0, n);
                in.close();

                byte[] data = out.toByteArray();
                if (data.length == 0) return;

                try {
                    File f = diskFile(a, u);
                    if (f != null) try (FileOutputStream fo = new FileOutputStream(f, false)) { fo.write(data); }
                } catch (Exception ignored) {}

                BitmapFactory.Options bounds = new BitmapFactory.Options();
                bounds.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(data, 0, data.length, bounds);
                int sample = 1;
                while (bounds.outWidth / sample > 1920 || bounds.outHeight / sample > 1080) sample *= 2;

                BitmapFactory.Options opts = new BitmapFactory.Options();
                opts.inSampleSize = Math.max(1, sample);
                opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
                Bitmap bmp = BitmapFactory.decodeByteArray(data, 0, data.length, opts);

                if (bmp != null) {
                    CACHE.put(key, bmp);
                    a.runOnUiThread(() -> {
                        Object tag = target.getTag();
                        if (tag != null && key.equals(tag.toString())) target.setImageBitmap(bmp);
                    });
                }
            } catch (Exception ignored) {
            } finally {
                IN_FLIGHT.remove(key);
                if (con != null) con.disconnect();
            }
        });
    }

    static void preload(Activity a, String url) {
        if (a == null || url == null || url.trim().isEmpty()) return;
        String u = url.trim();
        if (CACHE.get(u) != null || IN_FLIGHT.contains(u)) return;
        a.runOnUiThread(() -> into(a, new ImageView(a), u));
    }

    static void clear() { CACHE.evictAll(); }
}
