package com.ativacao.app;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TextView;

final class AppExit {
    private AppExit(){}

    static void confirm(Activity a){
        if(a==null || a.isFinishing()) return;

        final Dialog d = new Dialog(a);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setCancelable(true);

        LinearLayout box = Ui.column(a);
        box.setPadding(Ui.dp(a,28),Ui.dp(a,24),Ui.dp(a,28),Ui.dp(a,22));
        box.setBackground(Ui.stroke(0xF5121714,0xFF2B3A30,20,a));

        TextView icon = Ui.text(a,"⏻",26,Ui.GREEN,true);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(Ui.round(0x331CFF78,40,a));
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(Ui.dp(a,58),Ui.dp(a,58));
        ip.gravity=Gravity.CENTER_HORIZONTAL;
        box.addView(icon,ip);

        TextView title = Ui.text(a,"Sair do Green Play?",Ui.phone(a)?18:22,Color.WHITE,true);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1,Ui.dp(a,46));
        tp.topMargin=Ui.dp(a,8);
        box.addView(title,tp);

        TextView sub = Ui.text(a,"Deseja realmente fechar o aplicativo?",Ui.phone(a)?11:13,0xFFB9C3BC,false);
        sub.setGravity(Gravity.CENTER);
        box.addView(sub,new LinearLayout.LayoutParams(-1,Ui.dp(a,34)));

        LinearLayout actions = new LinearLayout(a);
        actions.setGravity(Gravity.CENTER);

        TextView cancel = Ui.button(a,"CANCELAR");
        cancel.setGravity(Gravity.CENTER);
        cancel.setOnClickListener(v->d.dismiss());
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0,Ui.dp(a,44),1);
        actions.addView(cancel,cp);

        TextView exit = Ui.primaryButton(a,"SAIR");
        exit.setGravity(Gravity.CENTER);
        exit.setOnClickListener(v->{
            d.dismiss();
            a.finishAffinity();
        });
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(0,Ui.dp(a,44),1);
        ep.leftMargin=Ui.dp(a,12);
        actions.addView(exit,ep);

        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1,Ui.dp(a,44));
        ap.topMargin=Ui.dp(a,16);
        box.addView(actions,ap);

        d.setContentView(box);
        Window w=d.getWindow();
        if(w!=null){
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setDimAmount(.72f);
            w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            android.view.WindowManager.LayoutParams lp=new android.view.WindowManager.LayoutParams();
            lp.copyFrom(w.getAttributes());
            lp.width=Ui.dp(a,Ui.phone(a)?360:500);
            lp.height=android.view.WindowManager.LayoutParams.WRAP_CONTENT;
            lp.gravity=Gravity.CENTER;
            w.setAttributes(lp);
        }
        d.show();
    }
}
