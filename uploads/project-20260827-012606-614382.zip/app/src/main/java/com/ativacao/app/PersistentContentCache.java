package com.ativacao.app;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Cache persistente por cliente. Mantém a primeira tela pronta entre aberturas do app. */
final class PersistentContentCache {
    private static Context app;
    private PersistentContentCache(){}
    static void init(Context c){ if(c!=null) app=c.getApplicationContext(); }
    private static File dir(){
        if(app==null)return null;
        File d=new File(app.getFilesDir(),"content_cache");
        if(!d.exists()) d.mkdirs();
        return d;
    }
    private static String safe(String s){ return Integer.toHexString((s==null?"":s).hashCode()); }
    private static File file(String kind,String key){ File d=dir(); return d==null?null:new File(d,kind+"_"+safe(key)+".json"); }
    private static String read(File f){
        if(f==null||!f.isFile())return "";
        try(BufferedReader r=new BufferedReader(new InputStreamReader(new FileInputStream(f),StandardCharsets.UTF_8))){
            StringBuilder b=new StringBuilder(); String line; while((line=r.readLine())!=null)b.append(line); return b.toString();
        }catch(Exception e){return "";}
    }
    private static void write(File f,String s){
        if(f==null)return;
        try(FileOutputStream o=new FileOutputStream(f,false)){o.write((s==null?"":s).getBytes(StandardCharsets.UTF_8));}catch(Exception ignored){}
    }
    static void putCatalog(String key, JSONObject root){ if(root!=null) write(file("catalog",key),root.toString()); }
    static void putSeries(String key, JSONObject root){ if(root!=null) write(file("series",key),root.toString()); }
    static JSONObject getSeries(String key){ try{String s=read(file("series",key)); return s.isEmpty()?null:new JSONObject(s);}catch(Exception e){return null;} }
    static JSONObject getCatalog(String key){ try{String s=read(file("catalog",key)); return s.isEmpty()?null:new JSONObject(s);}catch(Exception e){return null;} }
    static void removeCatalog(String key){ File f=file("catalog",key); if(f!=null&&f.isFile()) f.delete(); }
    static void putCategories(String key,List<String> list){
        JSONArray a=new JSONArray(); if(list!=null)for(String x:list)a.put(x); JSONObject o=new JSONObject(); try{o.put("categories",a);}catch(Exception ignored){} write(file("cats",key),o.toString());
    }
    static List<String> getCategories(String key){
        try{JSONObject o=new JSONObject(read(file("cats",key)));JSONArray a=o.optJSONArray("categories");if(a==null)return null;List<String> out=new ArrayList<>();for(int i=0;i<a.length();i++){String x=a.optString(i,"");if(!x.isEmpty())out.add(x);}return out;}catch(Exception e){return null;}
    }
    static void putHot(String key, JSONArray a){ JSONObject o=new JSONObject(); try{o.put("categories",a==null?new JSONArray():a);}catch(Exception ignored){} write(file("hot",key),o.toString()); }
    static JSONArray getHot(String key){ try{JSONObject o=new JSONObject(read(file("hot",key)));return o.optJSONArray("categories");}catch(Exception e){return null;} }
    static void clearAll(){ File d=dir(); if(d==null)return; File[] fs=d.listFiles(); if(fs!=null)for(File f:fs)if(f.isFile())f.delete(); }
}
