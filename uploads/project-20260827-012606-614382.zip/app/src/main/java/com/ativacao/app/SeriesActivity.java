package com.ativacao.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class SeriesActivity extends Activity {
    private final List<ApiClient.Item> episodes = new ArrayList<>();
    private ApiClient.SeriesData data;
    private TextView title, meta, synopsis, seasonSelector, episodeRange, episodeTitle, playEpisodeButton;
    private LinearLayout episodeRow;
    private ImageView preview;
    private String seriesTitle, initialLogo, initialBackdrop, initialSynopsis, initialGroup;
    private int initialYear;
    private int selectedSeasonIndex = 0;
    private int selectedEpisodeIndex = 0;
    private boolean phone;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        Ui.immersive(this);
        phone=Ui.phone(this);
        seriesTitle=clean(getIntent().getStringExtra("title"),clean(getIntent().getStringExtra("name"),"Série"));
        initialLogo=clean(getIntent().getStringExtra("logo"),"");
        initialBackdrop=clean(getIntent().getStringExtra("backdrop"),"");
        initialSynopsis=clean(getIntent().getStringExtra("synopsis"),"");
        initialGroup=clean(getIntent().getStringExtra("group"),"");
        initialYear=getIntent().getIntExtra("year",0);
        setContentView(build());
        load();
    }

    private View build(){
        LinearLayout root=Ui.column(this);
        root.setPadding(Ui.dp(this,22),Ui.dp(this,10),Ui.dp(this,22),Ui.dp(this,12));
        root.setBackground(Ui.diagonalGradient(0xFF061109,0xFF010402,0,this));

        title=Ui.text(this,seriesTitle,phone?22:28,Color.WHITE,true);
        title.setMaxLines(1);
        root.addView(title,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));

        LinearLayout hero=new LinearLayout(this);
        hero.setOrientation(LinearLayout.HORIZONTAL);
        hero.setPadding(Ui.dp(this,10),Ui.dp(this,10),Ui.dp(this,10),Ui.dp(this,10));
        hero.setGravity(Gravity.CENTER_VERTICAL);
        hero.setBackground(Ui.stroke(0xD90A0F0B,0xFF23392A,16,this));

        FrameLayout previewBox=new FrameLayout(this);
        previewBox.setBackground(Ui.round(0xFF0B120E,12,this));
        previewBox.setClipToOutline(true);

        preview=new ImageView(this);
        preview.setScaleType(ImageView.ScaleType.CENTER_CROP);
        preview.setBackgroundColor(0xFF101713);
        previewBox.addView(preview,new FrameLayout.LayoutParams(-1,-1));

        View previewShade=new View(this);
        previewShade.setBackground(Ui.gradient(0x22000000,0xA6000000,0,this));
        previewBox.addView(previewShade,new FrameLayout.LayoutParams(-1,-1));

        TextView playCircle=Ui.text(this,"▶",24,Color.WHITE,true);
        playCircle.setGravity(Gravity.CENTER);
        playCircle.setFocusable(true);
        playCircle.setClickable(true);
        playCircle.setBackground(Ui.round(0xD91CD968,40,this));
        playCircle.setOnClickListener(v->playSelectedEpisode());
        FrameLayout.LayoutParams pcp=new FrameLayout.LayoutParams(Ui.dp(this,58),Ui.dp(this,58),Gravity.CENTER);
        previewBox.addView(playCircle,pcp);

        episodeTitle=Ui.text(this,"",phone?10:12,Color.WHITE,true);
        episodeTitle.setMaxLines(1);
        episodeTitle.setPadding(Ui.dp(this,12),0,Ui.dp(this,12),0);
        episodeTitle.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
        episodeTitle.setBackground(Ui.round(0xB8000000,0,this));
        FrameLayout.LayoutParams etp=new FrameLayout.LayoutParams(-1,Ui.dp(this,36),Gravity.BOTTOM);
        previewBox.addView(episodeTitle,etp);

        LinearLayout.LayoutParams pv=new LinearLayout.LayoutParams(0,Ui.dp(this,phone?210:248),phone?0.48f:0.50f);
        hero.addView(previewBox,pv);

        LinearLayout info=Ui.column(this);
        info.setPadding(Ui.dp(this,18),Ui.dp(this,8),Ui.dp(this,8),Ui.dp(this,2));

        TextView badge=Ui.text(this,"SÉRIE  •  GREEN PLAY",9,Ui.GREEN,true);
        info.addView(badge,new LinearLayout.LayoutParams(-1,Ui.dp(this,22)));

        meta=Ui.text(this,"",phone?10:11,0xFFE5E9E6,true);
        meta.setMaxLines(1);
        info.addView(meta,new LinearLayout.LayoutParams(-1,Ui.dp(this,30)));

        synopsis=Ui.text(this,clean(initialSynopsis,"Carregando informações..."),phone?10:12,0xFFD2D7D4,false);
        synopsis.setMaxLines(phone?4:5);
        synopsis.setLineSpacing(0,1.08f);
        info.addView(synopsis,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout tools=new LinearLayout(this);
        tools.setGravity(Gravity.CENTER_VERTICAL);

        TextView full=miniButton("⛶  TELA CHEIA");
        full.setOnClickListener(v->playSelectedEpisode());
        tools.addView(full,new LinearLayout.LayoutParams(0,Ui.dp(this,38),1));

        TextView language=miniButton("▤  IDIOMA");
        language.setOnClickListener(v->showInfoDialog("Idioma e legendas","As opções de áudio e legenda aparecem no player durante a reprodução."));
        LinearLayout.LayoutParams ilp=new LinearLayout.LayoutParams(0,Ui.dp(this,38),1); ilp.leftMargin=Ui.dp(this,8);
        tools.addView(language,ilp);

        TextView quality=miniButton("⇆  RESOLUÇÃO");
        quality.setOnClickListener(v->showInfoDialog("Resolução","A qualidade pode ser alterada no player quando o stream oferecer mais de uma resolução."));
        LinearLayout.LayoutParams qlp=new LinearLayout.LayoutParams(0,Ui.dp(this,38),1); qlp.leftMargin=Ui.dp(this,8);
        tools.addView(quality,qlp);

        info.addView(tools,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));

        playEpisodeButton=Ui.primaryButton(this,"▶  REPRODUZIR");
        playEpisodeButton.setOnClickListener(v->playSelectedEpisode());
        LinearLayout.LayoutParams plp=new LinearLayout.LayoutParams(Ui.dp(this,210),Ui.dp(this,42)); plp.topMargin=Ui.dp(this,8);
        info.addView(playEpisodeButton,plp);

        hero.addView(info,new LinearLayout.LayoutParams(0,Ui.dp(this,phone?210:248),1));
        root.addView(hero,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?224:264)));

        LinearLayout selectorLine=new LinearLayout(this);
        selectorLine.setGravity(Gravity.CENTER_VERTICAL);
        selectorLine.setPadding(0,Ui.dp(this,10),0,0);

        seasonSelector=Ui.button(this,"TEMPORADA");
        seasonSelector.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
        seasonSelector.setPadding(Ui.dp(this,16),0,Ui.dp(this,12),0);
        seasonSelector.setOnClickListener(v->showSeasonDialog());
        selectorLine.addView(seasonSelector,new LinearLayout.LayoutParams(Ui.dp(this,phone?180:220),Ui.dp(this,42)));

        episodeRange=Ui.text(this,"",11,Ui.GREEN,true);
        episodeRange.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams erp=new LinearLayout.LayoutParams(Ui.dp(this,90),Ui.dp(this,42)); erp.leftMargin=Ui.dp(this,14);
        selectorLine.addView(episodeRange,erp);

        root.addView(selectorLine,new LinearLayout.LayoutParams(-1,Ui.dp(this,54)));

        HorizontalScrollView episodeScroll=new HorizontalScrollView(this);
        episodeScroll.setHorizontalScrollBarEnabled(false);
        episodeRow=new LinearLayout(this);
        episodeRow.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
        episodeScroll.addView(episodeRow,new HorizontalScrollView.LayoutParams(-2,-1));
        root.addView(episodeScroll,new LinearLayout.LayoutParams(-1,0,1));

        ImageLoader.into(this,preview,clean(initialBackdrop,initialLogo));
        meta.setText(buildMeta(initialGroup,initialYear,0,0));
        return AppBackground.wrap(this,root);
    }

    private TextView miniButton(String label){
        TextView b=Ui.button(this,label);
        b.setTextSize(phone?9:10);
        b.setGravity(Gravity.CENTER);
        b.setFocusable(true);
        return b;
    }

    private void load(){
        ApiClient.seriesPrepared(seriesTitle,new ApiClient.Callback<ApiClient.SeriesData>(){
            public void ok(ApiClient.SeriesData d){runOnUiThread(()->apply(d));}
            public void error(String m){runOnUiThread(()->{
                synopsis.setText(clean(initialSynopsis,"Não foi possível carregar os episódios."));
                playEpisodeButton.setVisibility(View.GONE);
            });}
        });
    }

    private void apply(ApiClient.SeriesData d){
        data=d;
        title.setText(clean(d.title,seriesTitle));
        synopsis.setText(clean(d.synopsis,clean(initialSynopsis,"Sinopse indisponível.")));

        int epTotal=0;
        for(ApiClient.Season s:d.seasons)epTotal+=s.episodes.size();
        meta.setText(buildMeta(clean(d.group,initialGroup),d.year>0?d.year:initialYear,d.seasons.size(),epTotal));

        if(d.seasons.isEmpty()){
            seasonSelector.setText("SEM TEMPORADAS");
            episodeRange.setText("0");
            playEpisodeButton.setVisibility(View.GONE);
            return;
        }

        showSeason(0);
        enrichSeriesFromTmdb(d);
    }

    private void showSeason(int index){
        if(data==null || index<0 || index>=data.seasons.size())return;
        selectedSeasonIndex=index;
        episodes.clear();
        episodes.addAll(data.seasons.get(index).episodes);

        ApiClient.Season s=data.seasons.get(index);
        int seasonNumber=s.number>0?s.number:(index+1);
        seasonSelector.setText("TEMPORADA "+seasonNumber+"   ▾");
        episodeRange.setText(episodes.isEmpty()?"0":"1–"+episodes.size());

        episodeRow.removeAllViews();
        for(int i=0;i<episodes.size();i++){
            final int idx=i;
            int n=episodes.get(i).episodeNumber>0?episodes.get(i).episodeNumber:(i+1);
            TextView chip=Ui.text(this,String.valueOf(n),12,Color.WHITE,true);
            chip.setGravity(Gravity.CENTER);
            chip.setFocusable(true);
            chip.setClickable(true);
            chip.setBackground(Ui.round(0xFF242B26,8,this));
            chip.setOnClickListener(v->selectEpisode(idx));
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(Ui.dp(this,phone?48:54),Ui.dp(this,44));
            cp.rightMargin=Ui.dp(this,8);
            episodeRow.addView(chip,cp);
        }

        selectEpisode(0);
    }

    private void selectEpisode(int index){
        if(episodes.isEmpty())return;
        selectedEpisodeIndex=Math.max(0,Math.min(index,episodes.size()-1));
        ApiClient.Item e=episodes.get(selectedEpisodeIndex);
        int ep=e.episodeNumber>0?e.episodeNumber:(selectedEpisodeIndex+1);

        episodeTitle.setText("EP "+ep+"  •  "+clean(e.name,"Episódio "+ep));
        String img=clean(e.logo,"");
        if(img.isEmpty() && data!=null) img=clean(data.backdrop,clean(data.logo,initialBackdrop));
        ImageLoader.into(this,preview,img);

        for(int i=0;i<episodeRow.getChildCount();i++){
            View v=episodeRow.getChildAt(i);
            if(v instanceof TextView){
                TextView t=(TextView)v;
                if(i==selectedEpisodeIndex){
                    t.setTextColor(0xFF041008);
                    t.setBackground(Ui.round(Ui.GREEN,8,this));
                }else{
                    t.setTextColor(Color.WHITE);
                    t.setBackground(Ui.round(0xFF242B26,8,this));
                }
            }
        }

        long saved=LocalStore.resumePosition(this,e.id);
        playEpisodeButton.setText(saved>=5000?"▶  CONTINUAR EPISÓDIO "+ep:"▶  REPRODUZIR EPISÓDIO "+ep);
        playEpisodeButton.setVisibility(View.VISIBLE);
    }

    private void showSeasonDialog(){
        if(data==null || data.seasons.isEmpty())return;

        Dialog d=new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout box=Ui.column(this);
        box.setPadding(Ui.dp(this,18),Ui.dp(this,16),Ui.dp(this,18),Ui.dp(this,16));
        box.setBackground(Ui.stroke(0xF5121714,0xFF2A3A2F,16,this));

        TextView h=Ui.text(this,"Selecionar temporada",18,Color.WHITE,true);
        box.addView(h,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));

        for(int i=0;i<data.seasons.size();i++){
            ApiClient.Season season=data.seasons.get(i);
            int number=season.number>0?season.number:(i+1);
            String label="Temporada "+number;
            if(i==selectedSeasonIndex)label+="   ✓";

            TextView row=Ui.button(this,label);
            row.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
            row.setPadding(Ui.dp(this,16),0,Ui.dp(this,12),0);
            final int idx=i;
            row.setOnClickListener(v->{d.dismiss();showSeason(idx);});
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,Ui.dp(this,44));
            rp.bottomMargin=Ui.dp(this,6);
            box.addView(row,rp);
        }

        d.setContentView(box);
        Window w=d.getWindow();
        if(w!=null){
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setDimAmount(.70f);
            w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            android.view.WindowManager.LayoutParams lp=new android.view.WindowManager.LayoutParams();
            lp.copyFrom(w.getAttributes());
            lp.width=Ui.dp(this,phone?330:420);
            lp.height=android.view.WindowManager.LayoutParams.WRAP_CONTENT;
            lp.gravity=Gravity.CENTER;
            w.setAttributes(lp);
        }
        d.show();
    }

    private void showInfoDialog(String heading,String message){
        Dialog d=new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box=Ui.column(this);
        box.setPadding(Ui.dp(this,22),Ui.dp(this,18),Ui.dp(this,22),Ui.dp(this,18));
        box.setBackground(Ui.stroke(0xF5121714,0xFF2A3A2F,16,this));
        TextView h=Ui.text(this,heading,18,Color.WHITE,true);
        box.addView(h,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));
        TextView m=Ui.text(this,message,12,0xFFCCD4CF,false);
        box.addView(m,new LinearLayout.LayoutParams(-1,Ui.dp(this,66)));
        TextView ok=Ui.primaryButton(this,"OK");
        ok.setOnClickListener(v->d.dismiss());
        box.addView(ok,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));
        d.setContentView(box);
        Window w=d.getWindow();
        if(w!=null){
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setDimAmount(.70f);
            w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            android.view.WindowManager.LayoutParams lp=new android.view.WindowManager.LayoutParams();
            lp.copyFrom(w.getAttributes());
            lp.width=Ui.dp(this,phone?360:480);
            lp.height=android.view.WindowManager.LayoutParams.WRAP_CONTENT;
            lp.gravity=Gravity.CENTER;
            w.setAttributes(lp);
        }
        d.show();
    }

    private void playSelectedEpisode(){
        if(episodes.isEmpty())return;
        ApiClient.Item e=episodes.get(Math.max(0,Math.min(selectedEpisodeIndex,episodes.size()-1)));
        long saved=LocalStore.resumePosition(this,e.id);
        playEpisode(e,saved>=5000?saved:0);
    }

    private void playEpisode(ApiClient.Item e,long resume){
        if(e==null)return;
        LocalStore.addHistory(this,e);
        Intent in=new Intent(this,PlayerActivity.class);
        in.putExtra("id",e.id);
        in.putExtra("name",e.name);
        in.putExtra("group",e.group);
        in.putExtra("type","series");
        in.putExtra("format",e.format);
        if(resume>0)in.putExtra("resume_pos",resume);
        startActivity(in);
    }

    @Override protected void onResume(){
        super.onResume();
        Ui.immersive(this);
        if(!episodes.isEmpty())selectEpisode(selectedEpisodeIndex);
    }

    private void enrichSeriesFromTmdb(ApiClient.SeriesData d){
        ApiClient.Item q=new ApiClient.Item();
        q.type="series";
        q.name=clean(d.title,seriesTitle);
        q.seriesTitle=q.name;
        q.year=d.year;
        q.logo=clean(d.logo,initialLogo);
        q.backdrop=clean(d.backdrop,initialBackdrop);
        q.synopsis=clean(d.synopsis,initialSynopsis);

        ApiClient.tmdbEnrich(q,new ApiClient.Callback<ApiClient.Item>(){
            public void ok(ApiClient.Item x){runOnUiThread(()->{
                synopsis.setText(clean(x.synopsis,clean(d.synopsis,clean(initialSynopsis,"Sinopse indisponível."))));
                if(x.year>0)d.year=x.year;
                if(!clean(x.backdrop,"").isEmpty())d.backdrop=x.backdrop;
                if(!clean(x.logo,"").isEmpty())d.logo=x.logo;
                int epTotal=0;
                for(ApiClient.Season s:d.seasons)epTotal+=s.episodes.size();
                meta.setText(buildMeta(clean(d.group,initialGroup),d.year,d.seasons.size(),epTotal));
                if(!episodes.isEmpty())selectEpisode(selectedEpisodeIndex);
            });}
            public void error(String m){}
        });
    }

    private String buildMeta(String group,int year,int seasons,int eps){
        StringBuilder s=new StringBuilder();
        if(!clean(group,"").isEmpty())s.append(clean(group,""));
        if(year>0){if(s.length()>0)s.append("  •  ");s.append(year);}
        if(seasons>0){if(s.length()>0)s.append("  •  ");s.append(seasons).append(seasons==1?" temporada":" temporadas");}
        if(eps>0){if(s.length()>0)s.append("  •  ");s.append(eps).append(" episódios");}
        return s.toString();
    }

    private String clean(String v,String fallback){
        if(v==null)return fallback;
        String s=v.trim();
        return s.isEmpty()||"null".equalsIgnoreCase(s)?fallback:s;
    }
}
