package com.ativacao.app;

import android.app.Application;

public class DubaiPlayApp extends Application {
    @Override public void onCreate() {
        super.onCreate();
        PersistentContentCache.init(this);
        CatalogPreloader.init(this);
        ApiClient.setUserToken(Session.token(this));
        ResumeRefreshManager.install(this);
    }
}
