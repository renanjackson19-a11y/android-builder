package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class CategoriesActivity extends Activity {
    private final List<ApiClient.Section> sections = new ArrayList<>();
    private GridView grid;
    private Adapter adapter;
    private TextView status;
    private boolean phone;

    @Override public void onCreate(Bundle b){
        super.onCreate(b); immersive(); phone=Ui.phone(this); setContentView(build()); load();
    }

    private View build(){
        LinearLayout root=Ui.column(this); root.setBackgroundColor(Ui.BG);
        LinearLayout content=Ui.column(this); content.setPadding(Ui.dp(this,phone?14:24),Ui.dp(this,12),Ui.dp(this,phone?14:24),Ui.dp(this,12));
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=Ui.text(this,"Categorias",phone?20:25,Ui.TEXT,true); LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,Ui.dp(this,44),1);top.addView(title,tp); content.addView(top,new LinearLayout.LayoutParams(-1,Ui.dp(this,48)));
        status=Ui.text(this,"CARREGANDO",10,0xFFE9F7EE,true); status.setGravity(Gravity.CENTER);status.setLetterSpacing(0.08f);status.setBackground(Ui.round(0x520A1510,16,this)); LinearLayout.LayoutParams csp=new LinearLayout.LayoutParams(Ui.dp(this,170),Ui.dp(this,32));csp.gravity=Gravity.CENTER_HORIZONTAL;content.addView(status,csp);
        grid=new GridView(this); int sw=Ui.sw(this); int cols=phone?(sw<720?3:4):(sw<1000?4:5); grid.setNumColumns(cols);grid.setHorizontalSpacing(Ui.dp(this,10));grid.setVerticalSpacing(Ui.dp(this,10));grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);grid.setSelector(android.R.color.transparent);adapter=new Adapter();grid.setAdapter(adapter);content.addView(grid,new LinearLayout.LayoutParams(-1,0,1));
        FrameLayout centered=Ui.centered(this,content,1260);root.addView(centered,new LinearLayout.LayoutParams(-1,-1));grid.requestFocus();return root;
    }

    private void load(){
        ApiClient.sections(new ApiClient.Callback<List<ApiClient.Section>>(){
            public void ok(List<ApiClient.Section> data){runOnUiThread(()->{sections.clear();sections.addAll(data);adapter.notifyDataSetChanged();status.setText(sections.size()+" categorias disponíveis");if(!sections.isEmpty())grid.requestFocus();});}
            public void error(String m){runOnUiThread(()->status.setText("Não foi possível carregar • "+m));}
        });
    }

    private class Adapter extends BaseAdapter{
        public int getCount(){return sections.size();} public Object getItem(int p){return sections.get(p);} public long getItemId(int p){return p;}
        public View getView(int p,View convert,android.view.ViewGroup parent){
            LinearLayout card;TextView icon,title,sub,count;
            if(convert==null){card=Ui.column(CategoriesActivity.this);card.setPadding(Ui.dp(CategoriesActivity.this,16),Ui.dp(CategoriesActivity.this,14),Ui.dp(CategoriesActivity.this,16),Ui.dp(CategoriesActivity.this,12));card.setFocusable(true);card.setClickable(true);Ui.focus(card,CategoriesActivity.this);
                icon=Ui.text(CategoriesActivity.this,"◈",20,Ui.PURPLE,true);icon.setId(301);card.addView(icon,new LinearLayout.LayoutParams(-1,Ui.dp(CategoriesActivity.this,30)));
                title=Ui.text(CategoriesActivity.this,"",phone?14:16,Ui.TEXT,true);title.setId(302);title.setMaxLines(1);card.addView(title,new LinearLayout.LayoutParams(-1,Ui.dp(CategoriesActivity.this,30)));
                sub=Ui.text(CategoriesActivity.this,"",10,Ui.MUTED,false);sub.setId(303);sub.setMaxLines(2);card.addView(sub,new LinearLayout.LayoutParams(-1,0,1));
                count=Ui.text(CategoriesActivity.this,"",10,Ui.GREEN,true);count.setId(304);card.addView(count,new LinearLayout.LayoutParams(-1,Ui.dp(CategoriesActivity.this,24)));convert=card;
            }else card=(LinearLayout)convert;
            icon=convert.findViewById(301);title=convert.findViewById(302);sub=convert.findViewById(303);count=convert.findViewById(304);
            ApiClient.Section s=sections.get(p);title.setText(s.title);sub.setText(s.subtitle);count.setText(s.count>0?s.count+" itens":"Abrir");
            if("football".equals(s.action)){icon.setText("⚽");icon.setTextColor(Ui.GREEN);}else if("movie".equals(s.type)){icon.setText("▶");icon.setTextColor(Ui.PURPLE);}else if("series".equals(s.type)){icon.setText("▤");icon.setTextColor(Ui.GREEN);}else{icon.setText("▣");icon.setTextColor(Ui.BLUE);}
            card.setOnClickListener(v->{if("football".equals(s.action)){startActivity(new Intent(CategoriesActivity.this,FootballActivity.class));return;}Intent in=new Intent(CategoriesActivity.this,CatalogActivity.class);in.putExtra("type",s.type);in.putExtra("title",s.title);in.putExtra("category",s.category);in.putExtra("smart",s.smart);startActivity(in);});return convert;
        }
    }

    private void immersive(){getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);}
}
