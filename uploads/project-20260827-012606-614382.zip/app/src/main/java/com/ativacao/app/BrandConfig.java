package com.ativacao.app;

import android.content.Context;
import android.content.SharedPreferences;

final class BrandConfig {
    private static final String PREF="dubai_brand";
    static void save(Context c,String logo){
        if(c==null)return;
        c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putString("logo",logo==null?"":logo.trim()).apply();
    }

    static void saveInternalBackground(Context c,String url){
        if(c==null)return;
        c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit()
                .putString("internal_background",url==null?"":url.trim()).apply();
    }

    static String internalBackground(Context c){
        if(c==null)return "";
        return c.getSharedPreferences(PREF,Context.MODE_PRIVATE)
                .getString("internal_background","");
    }
    static String logo(Context c){
        if(c==null)return "";
        return c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("logo","");
    }
}
