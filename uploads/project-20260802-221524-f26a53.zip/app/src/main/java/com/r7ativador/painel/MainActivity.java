package com.r7ativador.painel;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.app.KeyguardManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.hardware.biometrics.BiometricPrompt;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Environment;
import android.provider.Settings;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.SslErrorHandler;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.concurrent.Executor;

public class MainActivity extends Activity {
    private static final String PANEL_URL = "https://painel.br232uni.shop/";
    private static final int FILE_CHOOSER_REQUEST = 701;
    private static final int DEVICE_CREDENTIAL_REQUEST = 702;
    private static final int STORAGE_PERMISSION_REQUEST = 703;
    private static final long AUTO_LOCK_MS = 120000L;

    private WebView webView;
    private ProgressBar progressBar;
    private ValueCallback<Uri[]> fileCallback;
    private CancellationSignal cancellationSignal;
    private boolean unlocked = false;
    private long backgroundAt = 0L;
    private String currentUrl = PANEL_URL;

    private String pendingUrl;
    private String pendingAgent;
    private String pendingDisposition;
    private String pendingMime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.parseColor("#07080C"));
        getWindow().setNavigationBarColor(Color.parseColor("#07080C"));
        showLockScreen(true);
    }

    private void showLockScreen(boolean openPrompt) {
        unlocked = false;
        destroyWebView();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(28), dp(24), dp(24));
        root.setBackgroundColor(Color.parseColor("#07080C"));

        root.addView(new Space(this), new LinearLayout.LayoutParams(1, 0, 1f));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        root.addView(logo, new LinearLayout.LayoutParams(dp(128), dp(128)));

        TextView badge = new TextView(this);
        badge.setText("ACESSO PROTEGIDO");
        badge.setTextColor(Color.WHITE);
        badge.setTextSize(12);
        badge.setGravity(Gravity.CENTER);
        badge.setTypeface(null, android.graphics.Typeface.BOLD);
        badge.setBackgroundResource(R.drawable.bg_badge);
        LinearLayout.LayoutParams badgeParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        badgeParams.topMargin = dp(18);
        root.addView(badge, badgeParams);

        TextView title = new TextView(this);
        title.setText("Painel R7 Ativador");
        title.setTextColor(Color.WHITE);
        title.setTextSize(29);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        titleParams.topMargin = dp(22);
        root.addView(title, titleParams);

        TextView subtitle = new TextView(this);
        subtitle.setText("Use sua biometria para acessar o painel");
        subtitle.setTextColor(Color.parseColor("#B5BAC5"));
        subtitle.setTextSize(16);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subtitleParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        subtitleParams.topMargin = dp(8);
        root.addView(subtitle, subtitleParams);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(dp(22), dp(22), dp(22), dp(22));
        card.setBackgroundResource(R.drawable.bg_security_card);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        cardParams.topMargin = dp(28);
        root.addView(card, cardParams);

        TextView message = new TextView(this);
        message.setText("Confirme sua identidade para continuar. A biometria é validada pelo próprio Android.");
        message.setTextColor(Color.parseColor("#C4C7CE"));
        message.setTextSize(15);
        message.setGravity(Gravity.CENTER);
        card.addView(message, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        Button biometric = createButton("ENTRAR COM BIOMETRIA", true);
        biometric.setOnClickListener(v -> requestAuthentication());
        LinearLayout.LayoutParams bioParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(58));
        bioParams.topMargin = dp(22);
        card.addView(biometric, bioParams);

        Button pin = createButton("USAR SENHA OU PIN", false);
        pin.setOnClickListener(v -> openDeviceCredential());
        LinearLayout.LayoutParams pinParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(54));
        pinParams.topMargin = dp(12);
        card.addView(pin, pinParams);

        root.addView(new Space(this), new LinearLayout.LayoutParams(1, 0, 1f));

        TextView footer = new TextView(this);
        footer.setText("R7 ATIVADOR - CONEXAO SEGURA");
        footer.setTextColor(Color.parseColor("#6D717B"));
        footer.setTextSize(11);
        footer.setGravity(Gravity.CENTER);
        root.addView(footer, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        setContentView(root);
        if (openPrompt) root.postDelayed(this::requestAuthentication, 450);
    }

    private Button createButton(String text, boolean active) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setTextSize(14);
        button.setTypeface(null, android.graphics.Typeface.BOLD);
        button.setAllCaps(false);
        button.setGravity(Gravity.CENTER);
        button.setBackgroundResource(active ? R.drawable.bg_button_active : R.drawable.bg_button_inactive);
        return button;
    }

    private void requestAuthentication() {
        cancelPrompt();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            showBiometricPrompt();
        } else {
            openDeviceCredential();
        }
    }

    private void showBiometricPrompt() {
        Executor executor = command -> runOnUiThread(command);
        cancellationSignal = new CancellationSignal();
        BiometricPrompt prompt = new BiometricPrompt.Builder(this)
                .setTitle("Painel R7 Ativador")
                .setSubtitle("Confirme sua biometria")
                .setNegativeButton("Usar senha ou PIN", executor, (dialog, which) -> openDeviceCredential())
                .build();

        prompt.authenticate(cancellationSignal, executor, new BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                super.onAuthenticationSucceeded(result);
                unlockApp();
            }

            @Override
            public void onAuthenticationFailed() {
                super.onAuthenticationFailed();
                Toast.makeText(MainActivity.this, "Biometria nao reconhecida.", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAuthenticationError(int errorCode, CharSequence errString) {
                super.onAuthenticationError(errorCode, errString);
                if (errString != null && errString.length() > 0) {
                    Toast.makeText(MainActivity.this, errString, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void openDeviceCredential() {
        cancelPrompt();
        KeyguardManager manager = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
        if (manager != null && manager.isKeyguardSecure()) {
            Intent intent = manager.createConfirmDeviceCredentialIntent(
                    "Painel R7 Ativador",
                    "Confirme a senha, o PIN ou o padrao do aparelho");
            if (intent != null) {
                startActivityForResult(intent, DEVICE_CREDENTIAL_REQUEST);
                return;
            }
        }

        new AlertDialog.Builder(this)
                .setTitle("Protecao nao configurada")
                .setMessage("Configure biometria, PIN, senha ou padrao nas configuracoes do Android.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Abrir configuracoes", (dialog, which) -> {
                    try {
                        startActivity(new Intent(Settings.ACTION_SECURITY_SETTINGS));
                    } catch (Exception e) {
                        Toast.makeText(this, "Abra as configuracoes de seguranca do aparelho.", Toast.LENGTH_LONG).show();
                    }
                })
                .show();
    }

    private void unlockApp() {
        cancelPrompt();
        unlocked = true;
        backgroundAt = 0L;
        buildMainInterface();
        configureWebView();
        loadUrl(currentUrl == null ? PANEL_URL : currentUrl);
    }

    private void buildMainInterface() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#07080C"));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(14), dp(9), dp(10), dp(9));
        header.setBackgroundResource(R.drawable.bg_header);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(dp(48), dp(48));
        logoParams.rightMargin = dp(11);
        header.addView(logo, logoParams);

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView title = new TextView(this);
        title.setText("R7 ATIVADOR");
        title.setTextColor(Color.WHITE);
        title.setTextSize(19);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        TextView subtitle = new TextView(this);
        subtitle.setText("Painel protegido");
        subtitle.setTextColor(Color.parseColor("#FF766B"));
        subtitle.setTextSize(12);
        titles.addView(title);
        titles.addView(subtitle);
        header.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button lockButton = createButton("BLOQUEAR", false);
        lockButton.setTextSize(11);
        lockButton.setOnClickListener(v -> showLockScreen(true));
        header.addView(lockButton, new LinearLayout.LayoutParams(dp(98), dp(44)));
        root.addView(header, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        FrameLayout content = new FrameLayout(this);
        webView = new WebView(this);
        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            progressBar.setProgressTintList(android.content.res.ColorStateList.valueOf(Color.parseColor("#E50914")));
            progressBar.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.parseColor("#311015")));
        }
        content.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        FrameLayout.LayoutParams progressParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(3));
        progressParams.gravity = Gravity.TOP;
        content.addView(progressBar, progressParams);
        root.addView(content, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(8), dp(8), dp(8), dp(8));
        nav.setBackgroundResource(R.drawable.bg_nav);
        Button home = createButton("INICIO", true);
        Button reload = createButton("ATUALIZAR", false);
        Button lock = createButton("BLOQUEAR", false);
        home.setTextSize(12);
        reload.setTextSize(12);
        lock.setTextSize(12);
        home.setOnClickListener(v -> loadUrl(PANEL_URL));
        reload.setOnClickListener(v -> webView.reload());
        lock.setOnClickListener(v -> showLockScreen(true));
        LinearLayout.LayoutParams navParams = new LinearLayout.LayoutParams(0, dp(48), 1f);
        navParams.setMargins(dp(4), 0, dp(4), 0);
        nav.addView(home, navParams);
        nav.addView(reload, navParams);
        nav.addView(lock, navParams);
        root.addView(nav, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        setContentView(root);
    }

    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        }
        settings.setUserAgentString(settings.getUserAgentString() + " R7PainelApp/1.0.1");

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            cookies.setAcceptThirdPartyCookies(webView, true);
        }

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                progressBar.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), FILE_CHOOSER_REQUEST);
                    return true;
                } catch (ActivityNotFoundException e) {
                    fileCallback = null;
                    Toast.makeText(MainActivity.this, "Nenhum seletor de arquivo disponivel.", Toast.LENGTH_LONG).show();
                    return false;
                }
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                currentUrl = url;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                currentUrl = url;
                CookieManager.getInstance().flush();
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl().toString());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(url);
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, android.net.http.SslError error) {
                handler.cancel();
                Toast.makeText(MainActivity.this, "Nao foi possivel validar a seguranca deste endereco.", Toast.LENGTH_LONG).show();
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && request.isForMainFrame()) showOfflinePage();
            }
        });

        webView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimeType, long contentLength) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                        && Build.VERSION.SDK_INT <= Build.VERSION_CODES.P
                        && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    pendingUrl = url;
                    pendingAgent = userAgent;
                    pendingDisposition = contentDisposition;
                    pendingMime = mimeType;
                    requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, STORAGE_PERMISSION_REQUEST);
                } else {
                    startDownload(url, userAgent, contentDisposition, mimeType);
                }
            }
        });
    }

    private boolean handleUrl(String url) {
        if (url == null || url.trim().isEmpty()) return true;
        Uri uri = Uri.parse(url);
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
        if (scheme.equals("http") || scheme.equals("https")) {
            webView.loadUrl(url);
            return true;
        }
        if (scheme.equals("tel") || scheme.equals("mailto") || scheme.equals("sms")
                || scheme.equals("whatsapp") || scheme.equals("intent") || scheme.equals("market")) {
            openExternal(url);
            return true;
        }
        return false;
    }

    private void openExternal(String url) {
        try {
            Intent intent = url.startsWith("intent://")
                    ? Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
                    : new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Nao foi possivel abrir este link.", Toast.LENGTH_SHORT).show();
        }
    }

    private void startDownload(String url, String userAgent, String contentDisposition, String mimeType) {
        try {
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            if (userAgent != null) request.addRequestHeader("User-Agent", userAgent);
            String cookie = CookieManager.getInstance().getCookie(url);
            if (cookie != null) request.addRequestHeader("Cookie", cookie);
            if (mimeType != null) request.setMimeType(mimeType);
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(
                    Environment.DIRECTORY_DOWNLOADS,
                    guessFileName(url, contentDisposition));
            DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            manager.enqueue(request);
            Toast.makeText(this, "Download iniciado.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            openExternal(url);
        }
    }

    private void loadUrl(String url) {
        if (!hasInternet()) {
            showOfflinePage();
            return;
        }
        currentUrl = url;
        webView.loadUrl(url);
    }

    private void showOfflinePage() {
        String html = "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>" +
                "<style>body{margin:0;background:#07080c;color:#fff;font-family:Arial;display:flex;min-height:100vh;align-items:center;justify-content:center;text-align:center;padding:26px;box-sizing:border-box}.card{max-width:480px;background:#11131a;border:1px solid #402027;border-radius:22px;padding:30px}h2{color:#ff4a32}button{border:0;border-radius:14px;padding:15px 24px;background:#e50914;color:#fff;font-weight:700;font-size:16px}</style></head>" +
                "<body><div class='card'><h2>Sem conexao</h2><p>Verifique sua internet e tente novamente.</p><button onclick=\"location.href='" + PANEL_URL + "'\">TENTAR NOVAMENTE</button></div></body></html>";
        webView.loadDataWithBaseURL(PANEL_URL, html, "text/html", "UTF-8", null);
    }

    private boolean hasInternet() {
        ConnectivityManager manager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (manager == null) return true;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            android.net.Network network = manager.getActiveNetwork();
            if (network == null) return false;
            NetworkCapabilities caps = manager.getNetworkCapabilities(network);
            return caps != null && (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                    || caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
                    || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
                    || caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN));
        }
        android.net.NetworkInfo info = manager.getActiveNetworkInfo();
        return info != null && info.isConnected();
    }

    private String guessFileName(String url, String contentDisposition) {
        String name = android.webkit.URLUtil.guessFileName(url, contentDisposition, null);
        try {
            return URLDecoder.decode(name, StandardCharsets.UTF_8.name());
        } catch (Exception ignored) {
            return name;
        }
    }

    private void cancelPrompt() {
        if (cancellationSignal != null) {
            try {
                cancellationSignal.cancel();
            } catch (Exception ignored) {
            }
            cancellationSignal = null;
        }
    }

    private void destroyWebView() {
        if (webView != null) {
            try {
                webView.stopLoading();
                webView.setWebChromeClient(null);
                webView.setWebViewClient(null);
                webView.destroy();
            } catch (Exception ignored) {
            }
            webView = null;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && fileCallback != null) {
            Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        } else if (requestCode == DEVICE_CREDENTIAL_REQUEST) {
            if (resultCode == RESULT_OK) unlockApp();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == STORAGE_PERMISSION_REQUEST && pendingUrl != null) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startDownload(pendingUrl, pendingAgent, pendingDisposition, pendingMime);
            } else {
                Toast.makeText(this, "Permissao necessaria para salvar o arquivo.", Toast.LENGTH_LONG).show();
            }
            pendingUrl = null;
            pendingAgent = null;
            pendingDisposition = null;
            pendingMime = null;
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (unlocked && !isChangingConfigurations()) backgroundAt = System.currentTimeMillis();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (unlocked && backgroundAt > 0 && System.currentTimeMillis() - backgroundAt >= AUTO_LOCK_MS) {
            showLockScreen(true);
        }
        backgroundAt = 0L;
    }

    @Override
    public void onBackPressed() {
        if (unlocked && webView != null && webView.canGoBack()) {
            webView.goBack();
        } else if (unlocked) {
            new AlertDialog.Builder(this)
                    .setTitle("Sair do aplicativo?")
                    .setMessage("Deseja fechar o Painel R7 Ativador?")
                    .setNegativeButton("Cancelar", null)
                    .setNeutralButton("Bloquear", (dialog, which) -> showLockScreen(true))
                    .setPositiveButton("Sair", (dialog, which) -> finish())
                    .show();
        } else {
            finish();
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && unlocked && webView != null && webView.canGoBack()) {
            webView.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onDestroy() {
        cancelPrompt();
        destroyWebView();
        super.onDestroy();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
