package com.ativacao.app;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

public final class DeviceControl {
    private DeviceControl() {}

    public static ComponentName admin(Context c) { return new ComponentName(c, AdminReceiver.class); }

    public static boolean isSupported(Context c) {
        return c.getPackageManager().hasSystemFeature(PackageManager.FEATURE_DEVICE_ADMIN);
    }

    public static boolean isDeviceOwner(Context c) {
        try {
            DevicePolicyManager dpm = (DevicePolicyManager)c.getSystemService(Context.DEVICE_POLICY_SERVICE);
            return dpm != null && dpm.isDeviceOwnerApp(c.getPackageName());
        } catch (Throwable e) { return false; }
    }

    public static boolean protectActivator(Context c) {
        if (!isDeviceOwner(c)) return false;
        try {
            DevicePolicyManager dpm = (DevicePolicyManager)c.getSystemService(Context.DEVICE_POLICY_SERVICE);
            dpm.setUninstallBlocked(admin(c), c.getPackageName(), true);
            return true;
        } catch (Throwable e) { return false; }
    }

    public static boolean setAsPersistentHome(Context c) {
        if (!isDeviceOwner(c) || !LauncherStore.isTvBoxMode(c)) return false;
        try {
            DevicePolicyManager dpm = (DevicePolicyManager)c.getSystemService(Context.DEVICE_POLICY_SERVICE);
            Intent filterIntent = new Intent(Intent.ACTION_MAIN);
            android.content.IntentFilter filter = new android.content.IntentFilter(filterIntent.getAction());
            filter.addCategory(Intent.CATEGORY_HOME);
            filter.addCategory(Intent.CATEGORY_DEFAULT);
            ComponentName activity = new ComponentName(c, LauncherActivity.class);
            dpm.addPersistentPreferredActivity(admin(c), filter, activity);
            return true;
        } catch (Throwable e) { return false; }
    }

    public static boolean clearPersistentHome(Context c) {
        if (!isDeviceOwner(c)) return false;
        try {
            DevicePolicyManager dpm = (DevicePolicyManager)c.getSystemService(Context.DEVICE_POLICY_SERVICE);
            dpm.clearPackagePersistentPreferredActivities(admin(c), c.getPackageName());
            return true;
        } catch (Throwable e) { return false; }
    }

    public static boolean enforceManagedState(Context c) {
        if (!isDeviceOwner(c)) return false;
        boolean home;
        if (LauncherStore.isTvBoxMode(c)) home = setAsPersistentHome(c);
        else { clearPersistentHome(c); home = true; }
        boolean uninstall = protectActivator(c);
        reapplyLastUnitvPolicy(c);
        return home && uninstall;
    }

    public static boolean isUninstallProtectionActive(Context c) {
        if (!isDeviceOwner(c)) return false;
        try {
            DevicePolicyManager dpm = (DevicePolicyManager)c.getSystemService(Context.DEVICE_POLICY_SERVICE);
            return dpm != null && dpm.isUninstallBlocked(admin(c), c.getPackageName());
        } catch (Throwable e) { return false; }
    }

    public static boolean setPackageBlocked(Context c, String packageName, boolean blocked) {
        if (packageName == null || packageName.trim().isEmpty() || !isDeviceOwner(c)) return false;
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false;
        try {
            DevicePolicyManager dpm = (DevicePolicyManager)c.getSystemService(Context.DEVICE_POLICY_SERVICE);
            String[] failed = dpm.setPackagesSuspended(admin(c), new String[]{packageName.trim()}, blocked);
            return failed == null || failed.length == 0;
        } catch (Throwable e) { return false; }
    }

    /**
     * Aplica a política nova de forma segura e grava o último estado confirmado.
     * Se o package do UniTV mudou, libera o package antigo antes de aplicar o novo.
     */
    public static boolean applyUnitvPolicy(Context c, String packageName, boolean blocked, String message) {
        String pkg = packageName == null ? "" : packageName.trim();
        String old = PolicyStore.getLastUnitvPackage(c).trim();
        boolean ok = true;

        if (isDeviceOwner(c)) {
            if (!old.isEmpty() && !old.equals(pkg)) {
                ok = setPackageBlocked(c, old, false) && ok;
            }
            if (!pkg.isEmpty()) {
                ok = setPackageBlocked(c, pkg, blocked) && ok;
            }
        }

        PolicyStore.setLastPolicy(c, blocked, pkg, message);
        return ok;
    }

    /** Reaplica imediatamente o último bloqueio/liberação conhecido, inclusive no boot. */
    public static boolean reapplyLastUnitvPolicy(Context c) {
        String pkg = PolicyStore.getLastUnitvPackage(c).trim();
        if (pkg.isEmpty()) return true;
        if (!isDeviceOwner(c)) return false;
        return setPackageBlocked(c, pkg, PolicyStore.isLastBlocked(c));
    }

    /**
     * Traz a Launcher para frente depois do boot/reinício. Em Device Owner, o Home
     * persistente já foi aplicado antes desta chamada.
     */
    public static void launchHomeNow(Context c) {
        if (!LauncherStore.isActivationComplete(c) || !LauncherStore.isTvBoxMode(c)) return;
        try {
            Intent i = new Intent(c, LauncherActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            c.startActivity(i);
        } catch (Throwable ignored) {}
    }
}
