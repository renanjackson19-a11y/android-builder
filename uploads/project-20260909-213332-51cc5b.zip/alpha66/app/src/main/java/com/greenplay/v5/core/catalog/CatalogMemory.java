package com.greenplay.v5.core.catalog;

import com.greenplay.v5.data.model.movie.Movie;
import com.greenplay.v5.data.model.movie.MovieCategory;
import com.greenplay.v5.data.model.series.SeriesItem;
import com.greenplay.v5.data.model.series.SeriesCategory;
import com.greenplay.v5.data.model.tv.TvChannel;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * In-process catalog snapshots.
 *
 * V5.0.147: UI reads are lock-free. Previous versions used one synchronized
 * monitor for every read, set and merge. A background HOT/KIDS/ANIME merge over
 * thousands of rows could therefore park the Android main thread long enough to
 * trigger an ANR even while the login screen was visible. Heavy copying/merging
 * now happens before a tiny publication lock; readers only copy volatile
 * snapshots and never wait for a catalog writer.
 */
public final class CatalogMemory {
    private static volatile List<TvChannel> channels = Collections.emptyList();
    private static volatile List<MovieCategory> movieCategories = Collections.emptyList();
    private static volatile List<Movie> movies = Collections.emptyList();
    private static volatile List<SeriesItem> series = Collections.emptyList();
    private static volatile List<SeriesCategory> seriesCategories = Collections.emptyList();
    private static volatile long updatedAt = 0L;

    private static final Object MOVIE_CAT_WRITE = new Object();
    private static final Object SERIES_CAT_WRITE = new Object();
    private static final Object MOVIE_WRITE = new Object();
    private static final Object SERIES_WRITE = new Object();

    private CatalogMemory() {}

    public static void clear() {
        channels = Collections.emptyList();
        movieCategories = Collections.emptyList();
        movies = Collections.emptyList();
        series = Collections.emptyList();
        seriesCategories = Collections.emptyList();
        updatedAt = 0L;
        SpecialCatalogIndex.clear();
    }

    public static void setChannels(List<TvChannel> rows) {
        channels = copy(rows);
        touch();
    }

    public static void setMovieCategories(List<MovieCategory> rows) {
        List<MovieCategory> fresh = copy(rows);
        synchronized (MOVIE_CAT_WRITE) { movieCategories = fresh; }
        touch();
    }

    public static void setMovies(List<Movie> rows) {
        List<Movie> fresh = copy(rows);
        synchronized (MOVIE_WRITE) { movies = fresh; }
        touch();
    }

    public static void setSeries(List<SeriesItem> rows) {
        List<SeriesItem> fresh = copy(rows);
        synchronized (SERIES_WRITE) { series = fresh; }
        touch();
    }

    public static void setSeriesCategories(List<SeriesCategory> rows) {
        List<SeriesCategory> fresh = copy(rows);
        synchronized (SERIES_CAT_WRITE) { seriesCategories = fresh; }
        touch();
    }

    /** Mescla sem manter lock durante a construção do mapa. */
    public static void mergeMovieCategories(List<MovieCategory> rows) {
        if (rows == null || rows.isEmpty()) return;
        while (true) {
            List<MovieCategory> base = movieCategories;
            java.util.LinkedHashMap<String,MovieCategory> map = new java.util.LinkedHashMap<>();
            for (MovieCategory c : base) if (c != null) map.put(c.id == null ? "" : c.id, c);
            for (MovieCategory c : rows) if (c != null) map.put(c.id == null ? "" : c.id, c);
            List<MovieCategory> fresh = new ArrayList<>(map.values());
            synchronized (MOVIE_CAT_WRITE) {
                if (movieCategories != base) continue;
                movieCategories = fresh;
                break;
            }
        }
        touch();
    }

    public static void mergeSeriesCategories(List<SeriesCategory> rows) {
        if (rows == null || rows.isEmpty()) return;
        while (true) {
            List<SeriesCategory> base = seriesCategories;
            java.util.LinkedHashMap<String,SeriesCategory> map = new java.util.LinkedHashMap<>();
            for (SeriesCategory c : base) if (c != null) map.put(c.id == null ? "" : c.id, c);
            for (SeriesCategory c : rows) if (c != null) map.put(c.id == null ? "" : c.id, c);
            List<SeriesCategory> fresh = new ArrayList<>(map.values());
            synchronized (SERIES_CAT_WRITE) {
                if (seriesCategories != base) continue;
                seriesCategories = fresh;
                break;
            }
        }
        touch();
    }

    public static void mergeMovies(List<Movie> rows) {
        if (rows == null || rows.isEmpty()) return;
        while (true) {
            List<Movie> base = movies;
            java.util.LinkedHashMap<Long,Movie> map = new java.util.LinkedHashMap<>();
            for (Movie m : base) if (m != null && m.id > 0) map.put(m.id, m);
            for (Movie incoming : rows) {
                if (incoming == null || incoming.id <= 0) continue;
                Movie current = map.get(incoming.id);
                if (current == null) { map.put(incoming.id, incoming); continue; }
                current.allCategoryIds = mergeIds(current.allCategoryIds, incoming.allCategoryIds, incoming.categoryId);
                if (blank(current.categoryId)) current.categoryId = incoming.categoryId;
                if (blank(current.poster)) current.poster = incoming.poster;
                if (blank(current.year)) current.year = incoming.year;
                if (blank(current.rating)) current.rating = incoming.rating;
                if (blank(current.contentRating)) current.contentRating = incoming.contentRating;
                if (blank(current.genre)) current.genre = incoming.genre;
                if (blank(current.plot)) current.plot = incoming.plot;
                if (blank(current.originalLanguage)) current.originalLanguage = incoming.originalLanguage;
                if (blank(current.country)) current.country = incoming.country;
                if (blank(current.mediaType)) current.mediaType = incoming.mediaType;
                if (blank(current.vodType)) current.vodType = incoming.vodType;
                if (blank(current.filterType)) current.filterType = incoming.filterType;
                current.isAdult = current.isAdult || incoming.isAdult;
            }
            List<Movie> fresh = new ArrayList<>(map.values());
            synchronized (MOVIE_WRITE) {
                if (movies != base) continue;
                movies = fresh;
                break;
            }
        }
        touch();
    }

    public static void mergeSeries(List<SeriesItem> rows) {
        if (rows == null || rows.isEmpty()) return;
        while (true) {
            List<SeriesItem> base = series;
            java.util.LinkedHashMap<Long,SeriesItem> map = new java.util.LinkedHashMap<>();
            for (SeriesItem x : base) if (x != null && x.id > 0) map.put(x.id, x);
            for (SeriesItem incoming : rows) {
                if (incoming == null || incoming.id <= 0) continue;
                SeriesItem current = map.get(incoming.id);
                if (current == null) { map.put(incoming.id, incoming); continue; }
                current.allCategoryIds = mergeIds(current.allCategoryIds, incoming.allCategoryIds, incoming.categoryId);
                if (blank(current.categoryId)) current.categoryId = incoming.categoryId;
                if (blank(current.cover)) current.cover = incoming.cover;
                if (blank(current.year)) current.year = incoming.year;
                if (blank(current.rating)) current.rating = incoming.rating;
                if (blank(current.contentRating)) current.contentRating = incoming.contentRating;
                if (blank(current.genre)) current.genre = incoming.genre;
                if (blank(current.plot)) current.plot = incoming.plot;
                if (blank(current.mediaType)) current.mediaType = incoming.mediaType;
                if (blank(current.vodType)) current.vodType = incoming.vodType;
                if (blank(current.filterType)) current.filterType = incoming.filterType;
                current.isAdult = current.isAdult || incoming.isAdult;
            }
            List<SeriesItem> fresh = new ArrayList<>(map.values());
            synchronized (SERIES_WRITE) {
                if (series != base) continue;
                series = fresh;
                break;
            }
        }
        touch();
    }

    private static boolean blank(String s) { return s == null || s.trim().isEmpty(); }

    private static String mergeIds(String... values) {
        java.util.LinkedHashSet<String> ids = new java.util.LinkedHashSet<>();
        if (values != null) for (String value : values) {
            if (value == null) continue;
            for (String part : value.split("[|,;]+")) {
                String id = part == null ? "" : part.trim();
                if (!id.isEmpty()) ids.add(id);
            }
        }
        return android.text.TextUtils.join("|", ids);
    }

    public static List<TvChannel> channels() { return new ArrayList<>(channels); }
    public static List<MovieCategory> movieCategories() { return new ArrayList<>(movieCategories); }
    public static List<Movie> movies() { return new ArrayList<>(movies); }
    public static List<SeriesItem> series() { return new ArrayList<>(series); }
    public static List<SeriesCategory> seriesCategories() { return new ArrayList<>(seriesCategories); }
    public static long updatedAt() { return updatedAt; }

    public static List<Movie> moviesForIds(java.util.Set<Long> ids) {
        ArrayList<Movie> out = new ArrayList<>();
        if (ids == null || ids.isEmpty()) return out;
        List<Movie> snapshot = movies;
        for (Movie x : snapshot) if (x != null && ids.contains(x.id)) out.add(x);
        return out;
    }

    public static List<SeriesItem> seriesForIds(java.util.Set<Long> ids) {
        ArrayList<SeriesItem> out = new ArrayList<>();
        if (ids == null || ids.isEmpty()) return out;
        List<SeriesItem> snapshot = series;
        for (SeriesItem x : snapshot) if (x != null && ids.contains(x.id)) out.add(x);
        return out;
    }

    private static void touch() { updatedAt = android.os.SystemClock.elapsedRealtime(); }
    private static <T> List<T> copy(List<T> rows) { return rows == null ? new ArrayList<>() : new ArrayList<>(rows); }
}
