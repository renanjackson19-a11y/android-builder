package com.greenplay.v5.core.catalog;

import com.greenplay.v5.core.ui.SpecialSections;
import com.greenplay.v5.data.model.movie.Movie;
import com.greenplay.v5.data.model.movie.MovieCategory;
import com.greenplay.v5.data.model.series.SeriesCategory;
import com.greenplay.v5.data.model.series.SeriesItem;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * V5.0.90 — Central special-catalog index.
 *
 * Velox-style behavior: KIDS / ANIME / HOT are resolved once into explicit media
 * indexes. The UI no longer re-guesses the catalog on every screen switch.
 *
 * Xtream does not expose a universal media_type=KIDS/ANIME field, so this class
 * converts the data available at login into a stable local type index. Explicit
 * server categories always win. Mixed generic series categories are admitted
 * only when the series metadata itself is strong enough to classify the item.
 */
public final class SpecialCatalogIndex {
    public static final class CategoryRow {
        public final String id;
        public final String name;
        public CategoryRow(String id, String name) {
            this.id = id == null ? "" : id;
            this.name = name == null ? "" : name;
        }
    }

    public static final class Scope {
        public final String mode;
        public final Set<Long> movieIds;
        public final Set<Long> seriesIds;
        public final List<CategoryRow> movieCategories;
        public final List<CategoryRow> seriesCategories;
        public final List<Movie> moviePreview;
        public final List<SeriesItem> seriesPreview;

        private Scope(String mode, Set<Long> movieIds, Set<Long> seriesIds,
                      List<CategoryRow> movieCategories, List<CategoryRow> seriesCategories,
                      List<Movie> moviePreview, List<SeriesItem> seriesPreview) {
            this.mode = mode;
            this.movieIds = Collections.unmodifiableSet(new HashSet<>(movieIds));
            this.seriesIds = Collections.unmodifiableSet(new HashSet<>(seriesIds));
            this.movieCategories = Collections.unmodifiableList(new ArrayList<>(movieCategories));
            this.seriesCategories = Collections.unmodifiableList(new ArrayList<>(seriesCategories));
            this.moviePreview = Collections.unmodifiableList(new ArrayList<>(moviePreview));
            this.seriesPreview = Collections.unmodifiableList(new ArrayList<>(seriesPreview));
        }
    }

    private static long builtFrom = Long.MIN_VALUE;
    private static final Map<String, Scope> SCOPES = new HashMap<>();

    private SpecialCatalogIndex() {}

    public static synchronized void clear() {
        SCOPES.clear();
        builtFrom = Long.MIN_VALUE;
    }

    public static synchronized void rebuild() {
        long source = CatalogMemory.updatedAt();
        List<MovieCategory> movieCategories = CatalogMemory.movieCategories();
        List<Movie> movies = CatalogMemory.movies();
        List<SeriesCategory> seriesCategories = CatalogMemory.seriesCategories();
        List<SeriesItem> series = CatalogMemory.series();
        SCOPES.put(SpecialSections.KIDS, buildScope(SpecialSections.KIDS, movieCategories, movies, seriesCategories, series));
        SCOPES.put(SpecialSections.ANIME, buildScope(SpecialSections.ANIME, movieCategories, movies, seriesCategories, series));
        SCOPES.put(SpecialSections.HOT, buildScope(SpecialSections.HOT, movieCategories, movies, seriesCategories, series));
        builtFrom = source;
    }


    /**
     * V5.0.104: acesso rápido ao índice já montado no login.
     * Não reconstrói o catálogo na thread da tela.
     */
    public static synchronized Scope cachedScope(String mode) {
        Scope s = SCOPES.get(mode);
        if (s != null) return s;
        return new Scope(mode, Collections.emptySet(), Collections.emptySet(),
                Collections.singletonList(new CategoryRow("", "TODOS")),
                Collections.singletonList(new CategoryRow("", "TODOS")),
                Collections.emptyList(), Collections.emptyList());
    }

    public static synchronized Scope scope(String mode) {
        long source = CatalogMemory.updatedAt();
        if (SCOPES.isEmpty() || builtFrom != source) rebuild();
        Scope s = SCOPES.get(mode);
        if (s != null) return s;
        return new Scope(mode, Collections.emptySet(), Collections.emptySet(),
                Collections.singletonList(new CategoryRow("", "TODOS")),
                Collections.singletonList(new CategoryRow("", "TODOS")),
                Collections.emptyList(), Collections.emptyList());
    }

    /** Public builder is also used by HOT after its adult-inclusive catalog is fetched. */
    public static Scope buildScope(String mode,
                                   List<MovieCategory> movieCategories,
                                   List<Movie> movies,
                                   List<SeriesCategory> seriesCategories,
                                   List<SeriesItem> series) {
        LinkedHashMap<String,String> movieNames = new LinkedHashMap<>();
        LinkedHashMap<String,String> seriesNames = new LinkedHashMap<>();
        Set<String> explicitMovieCats = new HashSet<>();
        Set<String> explicitSeriesCats = new HashSet<>();

        if (movieCategories != null) {
            for (MovieCategory c : movieCategories) {
                if (c == null || blank(c.id)) continue;
                movieNames.put(c.id, safe(c.name));
                if (SpecialSections.matches(mode, c.name) || (SpecialSections.HOT.equals(mode) && c.isAdult)) explicitMovieCats.add(c.id);
            }
        }
        if (seriesCategories != null) {
            for (SeriesCategory c : seriesCategories) {
                if (c == null || blank(c.id)) continue;
                seriesNames.put(c.id, safe(c.name));
                if (SpecialSections.matches(mode, c.name) || (SpecialSections.HOT.equals(mode) && c.isAdult)) explicitSeriesCats.add(c.id);
            }
        }

        Set<Long> movieIds = new HashSet<>();
        Set<Long> seriesIds = new HashSet<>();
        Set<String> visibleMovieCats = new HashSet<>();
        Set<String> visibleSeriesCats = new HashSet<>();
        ArrayList<Movie> moviePreview = new ArrayList<>();
        ArrayList<SeriesItem> seriesPreview = new ArrayList<>();

        if (movies != null) {
            for (Movie m : movies) {
                if (m == null || m.id <= 0) continue;
                String tag = specialTag(m.mediaType, m.vodType, m.filterType);
                boolean match;
                if (!tag.isEmpty()) {
                    // When the backend explicitly tags an asset, that tag is authoritative.
                    match = mode.equals(tag);
                } else {
                    match = explicitMovieCats.contains(safe(m.categoryId));
                    // HOT is category/flag driven. Never classify by movie title text.
                    if (SpecialSections.HOT.equals(mode) && (m.isAdult || strongAdultMetadata(m.mediaType, m.vodType, m.filterType))) match = true;
                }
                if (!match) continue;
                movieIds.add(m.id);
                if (moviePreview.size() < 12) moviePreview.add(m);
                if (!blank(m.categoryId)) visibleMovieCats.add(m.categoryId);
            }
        }

        if (series != null) {
            for (SeriesItem item : series) {
                if (item == null || item.id <= 0) continue;
                String cat = safe(item.categoryId);
                String tag = specialTag(item.mediaType, item.vodType, item.filterType);
                boolean match;
                if (!tag.isEmpty()) {
                    match = mode.equals(tag);
                } else {
                    boolean explicit = explicitSeriesCats.contains(cat);
                    if (SpecialSections.KIDS.equals(mode)) {
                        match = explicit || strictKids(item);
                    } else if (SpecialSections.ANIME.equals(mode)) {
                        match = explicit || strictAnime(item);
                    } else {
                        // HOT is category/flag driven. Never classify by series title/plot/genre words.
                        match = explicit || item.isAdult || strongAdultMetadata(item.mediaType, item.vodType, item.filterType);
                    }
                }
                if (!match) continue;
                seriesIds.add(item.id);
                if (seriesPreview.size() < 12) seriesPreview.add(item);
                if (!blank(cat)) visibleSeriesCats.add(cat);
            }
        }

        // An explicit category may legitimately be empty at the moment; keep it visible.
        visibleMovieCats.addAll(explicitMovieCats);
        visibleSeriesCats.addAll(explicitSeriesCats);

        List<CategoryRow> movieRows = rows(movieNames, visibleMovieCats);
        List<CategoryRow> seriesRows = rows(seriesNames, visibleSeriesCats);
        return new Scope(mode, movieIds, seriesIds, movieRows, seriesRows, moviePreview, seriesPreview);
    }

    private static String specialTag(String mediaType, String vodType, String filterType) {
        String n = " " + normalize(safe(mediaType) + " " + safe(vodType) + " " + safe(filterType)) + " ";
        if (hasAny(n, " kids ", " kid ", " infantil ", " infantis ", " children ", " child ")) return SpecialSections.KIDS;
        if (hasAny(n, " anime ", " animes ", " otaku ", " manga ")) return SpecialSections.ANIME;
        if (hasAny(n, " adult_vod ", " adult ", " adulto ", " adultos ", " hot ", " xxx ", " 18+ ", " +18 ")) return SpecialSections.HOT;
        return "";
    }


    /**
     * Fallback somente para METADADOS estruturais do backend (media_type/vod_type/filter_type).
     * Não olha título, sinopse ou gênero, para um filme comum com palavra sexual no nome
     * nunca entrar no HOT por engano.
     */
    private static boolean strongAdultMetadata(String... values) {
        StringBuilder raw = new StringBuilder();
        if (values != null) for (String v : values) raw.append(' ').append(safe(v));
        String original = raw.toString().toLowerCase(Locale.ROOT);
        if (original.contains("🔞") || original.contains("+18") || original.contains("18+")) return true;
        String n = " " + normalize(original) + " ";
        return hasAny(n,
                " adult_vod ", " adult_content ", " adult ", " adults ",
                " adulto ", " adultos ", " xxx ", " hot ");
    }

    private static List<CategoryRow> rows(LinkedHashMap<String,String> names, Set<String> allowed) {
        ArrayList<CategoryRow> out = new ArrayList<>();
        out.add(new CategoryRow("", "TODOS"));
        for (Map.Entry<String,String> e : names.entrySet()) {
            if (!allowed.contains(e.getKey())) continue;
            out.add(new CategoryRow(e.getKey(), cleanDisplay(e.getValue())));
        }
        return out;
    }

    /**
     * Strict KIDS rule for mixed provider categories.
     * Family alone is intentionally NOT enough: that was the source of normal series leaking into KIDS.
     */
    private static boolean strictKids(SeriesItem item) {
        if (item.isAdult) return false;
        String genre = " " + normalize(item.genre) + " ";
        String title = " " + normalize(item.name) + " ";
        if (genre.trim().isEmpty()) return false;

        boolean directKids = hasAny(genre,
                " kids ", " kid ", " children ", " childrens ", " child ",
                " infantil ", " infantis ", " preschool ", " pre school ");
        boolean animation = hasAny(genre,
                " animation ", " animacao ", " animated ", " cartoon ", " cartoons ");
        boolean family = hasAny(genre, " family ", " familia ");

        // Only explicit kids metadata OR Animation+Family. Family by itself is not accepted.
        if (!directKids && !(animation && family)) return false;

        // Anime belongs in ANIMES, not KIDS, unless the server explicitly classified the category as KIDS.
        if (hasAny(genre, " anime ", " manga ", " shonen ", " shoujo ", " seinen ", " isekai ")) return false;

        String mature = genre + title;
        return !hasAny(mature,
                " adult ", " adulto ", " adultos ", " erotic ", " erotico ", " porn ",
                " horror ", " terror ", " thriller ", " crime ", " slasher ", " gore ",
                " family guy ", " south park ", " rick and morty ", " american dad ",
                " bojack horseman ", " big mouth ", " paradise pd ", " brickleberry ",
                " archer ", " solar opposites ");
    }

    private static boolean strictAnime(SeriesItem item) {
        if (item.isAdult) return false;
        String genre = " " + normalize(item.genre) + " ";
        return hasAny(genre,
                " anime ", " manga ", " shonen ", " shoujo ", " shojo ", " seinen ",
                " isekai ", " japanese animation ", " animacao japonesa ");
    }

    private static String cleanDisplay(String raw) {
        String s = safe(raw).replace("\\/", "/").replace("\n", " ").replace("\r", " ").trim();
        s = s.replaceAll("(?i)^(filmes|series|séries)\\s*[-|:]\\s*", "").trim();
        return s.isEmpty() ? "Categoria" : s;
    }

    private static boolean hasAny(String source, String... terms) {
        for (String t : terms) if (source.contains(t)) return true;
        return false;
    }

    private static String normalize(String raw) {
        if (raw == null) return "";
        String s = Normalizer.normalize(raw, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        return s.toLowerCase(Locale.ROOT)
                .replace('|', ' ').replace('/', ' ').replace(',', ' ').replace(';', ' ')
                .replaceAll("\\s+", " ").trim();
    }

    private static String safe(String s) { return s == null ? "" : s.trim(); }
    private static boolean blank(String s) { return s == null || s.trim().isEmpty(); }
}
