SPOTNET MUSIC V31
- Corrige logo configurada no painel.
- Usa /api/branding.php sem cache.
- Atualiza login, splash e cabeçalho automaticamente.
- Base compatível com o mesmo gerador das versões anteriores.
