package com.spotnet.music;

import android.content.Intent;import android.os.Handler;import android.os.Looper;import org.json.JSONObject;import java.net.URLEncoder;
import androidx.annotation.Nullable;
import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.session.MediaSession;
import androidx.media3.session.MediaSessionService;

public class PlaybackService extends MediaSessionService {
    private MediaSession mediaSession;private final Handler planHandler=new Handler(Looper.getMainLooper());private final Runnable planCheck=new Runnable(){public void run(){checkPlan();planHandler.postDelayed(this,60000);}};

    @Override public void onCreate() {
        super.onCreate();
        AudioAttributes attrs = new AudioAttributes.Builder()
                .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                .setUsage(C.USAGE_MEDIA)
                .build();
        ExoPlayer player = new ExoPlayer.Builder(this).build();
        player.setAudioAttributes(attrs, true);
        player.setHandleAudioBecomingNoisy(true);
        mediaSession = new MediaSession.Builder(this, player).build();planHandler.postDelayed(planCheck,15000);
    }

    private void checkPlan(){String user=getSharedPreferences("auth",MODE_PRIVATE).getString("user","");if(user.isEmpty())return;new Thread(()->{try{JSONObject j=new JSONObject(Net.get(BuildConfig.PANEL_URL+"/api/client_profile.php?user="+URLEncoder.encode(user,"UTF-8")));boolean active=j.optBoolean("ok")&&(j.optString("status").equalsIgnoreCase("active")||j.optString("status").equalsIgnoreCase("ativo"))&&j.optInt("days_remaining",0)>0;if(!active)planHandler.post(()->{if(mediaSession!=null){mediaSession.getPlayer().stop();mediaSession.getPlayer().clearMediaItems();}stopSelf();});}catch(Exception ignored){}}).start();}

    @Nullable @Override public MediaSession onGetSession(MediaSession.ControllerInfo controllerInfo) {
        return mediaSession;
    }

    @Override public void onTaskRemoved(@Nullable Intent rootIntent) {
        // Mantém a música tocando mesmo quando a tela do aplicativo é removida dos recentes.
        if (mediaSession != null && mediaSession.getPlayer().isPlaying()) return;
        stopSelf();
    }

    @Override public void onDestroy() {
        planHandler.removeCallbacks(planCheck);
        if (mediaSession != null) {
            mediaSession.getPlayer().release();
            mediaSession.release();
            mediaSession = null;
        }
        super.onDestroy();
    }
}
