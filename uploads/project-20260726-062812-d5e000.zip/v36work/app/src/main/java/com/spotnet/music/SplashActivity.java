package com.spotnet.music;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.bumptech.glide.Glide;
import org.json.JSONObject;

public class SplashActivity extends AppCompatActivity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean finished=false;
    private long duration=1500;

    @Override protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);setContentView(R.layout.activity_splash);
        ImageView media=findViewById(R.id.splashMedia),logo=findViewById(R.id.splashLogo);
        LinearLayout brand=findViewById(R.id.splashBrand);TextView title=findViewById(R.id.splashTitle);
        android.content.SharedPreferences cache=getSharedPreferences("ui_cache",MODE_PRIVATE);
        String cachedMedia=cache.getString("splash_media_url","");String cachedLogo=cache.getString("app_logo_url","");
        boolean showBrand=cache.getBoolean("splash_show_branding",true);String name=cache.getString("site_name","Spotnet Music");
        duration=Math.max(1000,Math.min(5000,cache.getLong("splash_duration_ms",1500)));
        title.setText(name.toUpperCase());brand.setVisibility(showBrand?View.VISIBLE:View.GONE);
        if(!cachedMedia.isEmpty())Glide.with(this).load(cachedMedia).centerCrop().into(media);else media.setImageResource(R.drawable.splash_gradient);
        if(!cachedLogo.isEmpty())Glide.with(this).load(cachedLogo).fitCenter().into(logo);else logo.setImageResource(R.drawable.brand_logo);

        final boolean[] brandingDone={false};
        new Thread(()->{
            try{
                JSONObject response=new JSONObject(Net.getFast(BuildConfig.PANEL_URL+"/api/branding.php?t="+System.currentTimeMillis()));
                JSONObject cfg=response.optJSONObject("branding");if(cfg==null)throw new Exception("branding vazio");
                String rawLogo=absolute(cfg.optString("logo_url",""));String rawMedia=absolute(cfg.optString("splash_url",""));
                boolean sb=cfg.optBoolean("splash_show_branding",true);String appName=cfg.optString("site_name","Spotnet Music");
                duration=Math.max(1000,Math.min(5000,cfg.optLong("splash_duration_ms",1500)));
                cache.edit().putString("app_logo_url",rawLogo).putString("splash_media_url",rawMedia).putBoolean("splash_show_branding",sb).putString("site_name",appName).putLong("splash_duration_ms",duration).apply();
                runOnUiThread(()->{title.setText(appName.toUpperCase());brand.setVisibility(sb?View.VISIBLE:View.GONE);if(!rawMedia.isEmpty())Glide.with(this).load(rawMedia).centerCrop().into(media);if(!rawLogo.isEmpty())Glide.with(this).load(rawLogo).fitCenter().into(logo);brandingDone[0]=true;handler.postDelayed(this::openApp,duration);});
            }catch(Exception e){runOnUiThread(()->{brandingDone[0]=true;handler.postDelayed(this::openApp,duration);});}
        }).start();
        handler.postDelayed(()->{if(!brandingDone[0])openApp();},3500);
    }
    private String absolute(String u){if(u==null||u.isEmpty())return "";if(u.startsWith("http"))return u;if(!u.startsWith("/"))u="/"+u;return BuildConfig.PANEL_URL+u;}
    private void openApp(){if(finished)return;finished=true;String user=getSharedPreferences("auth",MODE_PRIVATE).getString("user","");startActivity(new Intent(this,user.isEmpty()?LoginActivity.class:MainActivity.class));overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);finish();}
    @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);super.onDestroy();}
}
