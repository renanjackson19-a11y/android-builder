V42: Online detalhado no painel, heartbeat com música/tela/dispositivo e otimizações para celulares com pouca memória. Mantém a mesma base Gradle/Manifest da V41.
