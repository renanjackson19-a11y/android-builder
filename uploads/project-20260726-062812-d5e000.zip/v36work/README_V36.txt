V36 - mesma base V35/V32
- Home refinada conforme referência
- Banner hero com texto e botão sobre imagem do painel
- Categorias e cards menores
- Mini player e navegação compactos
- Splash força busca da logo do painel na primeira abertura
