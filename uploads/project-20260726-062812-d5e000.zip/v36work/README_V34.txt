V34 - HOME REFEITA SOBRE A BASE V32 ORIGINAL
- Mantém Gradle, Manifest, Java base e estrutura compatível com o gerador.
- Home refeita para ficar próxima da imagem de referência.
- Categorias em cards, seções com Ver todas, cards menores e mini player com progresso.
