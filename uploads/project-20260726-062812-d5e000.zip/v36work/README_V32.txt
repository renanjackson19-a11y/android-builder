V32: entrada profissional, sem logo no cabeçalho após login, marca Spotnet Music unida e mensagem de acesso liberado.
