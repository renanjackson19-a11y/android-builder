SPOTNET ANDROID V46 - AJUSTES DE LAYOUT E SEGURANÇA

- Busca com atalhos sem quebra de texto.
- Biblioteca com estado vazio organizado e player menor.
- Conta com código de indicação sem corte e cards responsivos.
- Botão Google com ícone e espaçamento correto.
- Cadastro e recuperação compactos.
- Tráfego HTTP desativado e serviço de mídia não exportado.
- applicationId debug separado para evitar conflito com versão de produção.

PLAY PROTECT:
O alerta pode continuar em APK debug ou assinado com chave desconhecida. Para distribuição, compile como RELEASE e assine sempre com a mesma chave privada. Não é possível eliminar legitimamente o alerta apenas mudando o layout/código.
