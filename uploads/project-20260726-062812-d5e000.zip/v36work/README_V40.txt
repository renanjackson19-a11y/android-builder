SPOTNET MUSIC V40 - mesma base V39
- Histórico de pesquisas local + sincronizado
- Favoritos e Biblioteca
- Cadastro pelo app
- Recuperação de senha enviada ao painel
- Olho para mostrar/ocultar senha
- Google/Apple ocultos até configuração real
- Player interrompido quando plano vence, inclusive em segundo plano
- Link de indicação mantido pelo perfil do cliente
Instale primeiro os arquivos do painel e depois gere o Android.
