V35: Home refeita na mesma base V34/V32, sem alterar Gradle, Manifesto ou dependências. Ajustes de proporção, cards, banner, player e navegação.
