SPOTNET MUSIC V26 — VISUAL PREMIUM

Base: V25 (API automática, player em segundo plano, renovação nativa e cache mantidos).

Principais mudanças:
- Nova identidade verde neon em todas as telas.
- Conta premium com plano, validade, renovação e indicação.
- Busca profissional com atalhos por gênero.
- Fila organizada com controles separados.
- Mini player moderno com capa, play/pausa e próxima.
- Splash profissional e compatível com foto/GIF configurado no painel.
- Fundo dinâmico pela capa da música mantido.
- Todas as IDs e integrações da V25 foram preservadas.

Domínio do painel: confira PANEL_URL em app/build.gradle antes de gerar.
