SPOTNET MUSIC V29
- Base compatível com o gerador das versões anteriores.
- Logo configurável pelo painel.
- Login redesenhado próximo ao modelo enviado.
- A mesma logo aparece no login, splash e cabeçalho.
- Configuração: Admin > Site / App > Logo do aplicativo.
