package com.spotnet.music;

import android.Manifest;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.Player;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionToken;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.google.common.util.concurrent.ListenableFuture;
import org.json.*;
import java.net.URLEncoder;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    LinearLayout bannerBox, sectionsBox;
    View homeTab, searchTab;
    TextView homeStatus, searchStatus, nowTitle, nowSub, navHome, navSearch;
    EditText searchInput;
    ImageView nowThumb;
    Button playPause;
    final ArrayList<MusicItem> searchItems = new ArrayList<>();
    SearchAdapter adapter;
    ListenableFuture<MediaController> controllerFuture;
    MediaController controller;

    private final ActivityResultLauncher<String> notificationPermission = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(), granted -> {});

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        bannerBox=findViewById(R.id.bannerBox); sectionsBox=findViewById(R.id.sectionsBox);
        homeTab=findViewById(R.id.homeTab); searchTab=findViewById(R.id.searchTab);
        homeStatus=findViewById(R.id.homeStatus); searchStatus=findViewById(R.id.searchStatus);
        nowTitle=findViewById(R.id.nowTitle); nowSub=findViewById(R.id.nowSub); nowThumb=findViewById(R.id.nowThumb);
        navHome=findViewById(R.id.navHome); navSearch=findViewById(R.id.navSearch);
        searchInput=findViewById(R.id.searchInput); playPause=findViewById(R.id.playPause);
        RecyclerView list=findViewById(R.id.searchList); list.setLayoutManager(new LinearLayoutManager(this));
        adapter=new SearchAdapter(searchItems,this::play); list.setAdapter(adapter);
        navHome.setOnClickListener(v->tab(true)); navSearch.setOnClickListener(v->tab(false));
        findViewById(R.id.searchBtn).setOnClickListener(v->search());
        findViewById(R.id.logout).setOnClickListener(v->{getSharedPreferences("auth",MODE_PRIVATE).edit().clear().apply();startActivity(new Intent(this,LoginActivity.class));finish();});
        playPause.setOnClickListener(v->toggle());
        requestNotificationPermission(); connectPlayer(); loadBanners(); loadHome();
    }

    private void requestNotificationPermission(){
        if(android.os.Build.VERSION.SDK_INT>=33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS);
    }

    private void connectPlayer(){
        SessionToken token=new SessionToken(this,new ComponentName(this,PlaybackService.class));
        controllerFuture=new MediaController.Builder(this,token).buildAsync();
        controllerFuture.addListener(()->{
            try{
                controller=controllerFuture.get();
                controller.addListener(new Player.Listener(){
                    @Override public void onIsPlayingChanged(boolean isPlaying){ runOnUiThread(()->playPause.setText(isPlaying?"Ⅱ":"▶")); }
                    @Override public void onMediaMetadataChanged(MediaMetadata m){
                        runOnUiThread(()->{
                            if(m.title!=null)nowTitle.setText(m.title);
                            if(m.artist!=null)nowSub.setText(m.artist);
                            if(m.artworkUri!=null)Glide.with(MainActivity.this).load(m.artworkUri).into(nowThumb);
                        });
                    }
                });
                MediaMetadata m=controller.getMediaMetadata();
                if(m.title!=null)nowTitle.setText(m.title);
                playPause.setText(controller.isPlaying()?"Ⅱ":"▶");
            }catch(Exception e){ Toast.makeText(this,"Falha ao iniciar o player",Toast.LENGTH_SHORT).show(); }
        },ContextCompat.getMainExecutor(this));
    }

    void tab(boolean home){homeTab.setVisibility(home?View.VISIBLE:View.GONE);searchTab.setVisibility(home?View.GONE:View.VISIBLE);navHome.setTextColor(getColor(home?R.color.green:R.color.muted));navSearch.setTextColor(getColor(home?R.color.muted:R.color.green));}

    void loadBanners(){new Thread(()->{try{JSONArray a=new JSONObject(Net.get(BuildConfig.PANEL_URL+"/api/banners.php")).optJSONArray("banners");if(a==null)return;runOnUiThread(()->{bannerBox.removeAllViews();for(int i=0;i<a.length();i++){JSONObject b=a.optJSONObject(i);if(b==null)continue;LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(10,10,10,10);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(310),dp(175));cp.setMargins(5,0,5,0);card.setLayoutParams(cp);card.setBackgroundResource(R.drawable.card);ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);card.addView(im,new LinearLayout.LayoutParams(-1,dp(125)));Glide.with(this).load(b.optString("image")).into(im);TextView t=new TextView(this);t.setText(b.optString("title"));t.setTextColor(Color.WHITE);t.setTextSize(17);t.setTypeface(null,1);t.setPadding(8,8,8,0);card.addView(t);bannerBox.addView(card);}});}catch(Exception ignored){}}).start();}

    void loadHome(){homeStatus.setText("Carregando músicas...");new Thread(()->{try{JSONObject j=new JSONObject(Net.get(BuildConfig.PANEL_URL+"/api/music/home.php"));JSONArray secs=j.optJSONArray("sections");runOnUiThread(()->renderSections(secs,j.optJSONArray("items")));}catch(Exception e){runOnUiThread(()->homeStatus.setText("Falha ao carregar a API: "+e.getMessage()));}}).start();}

    void renderSections(JSONArray secs,JSONArray fallback){sectionsBox.removeAllViews();int made=0;if(secs!=null)for(int i=0;i<secs.length();i++){JSONObject s=secs.optJSONObject(i);if(s==null)continue;JSONArray items=s.optJSONArray("items");if(items==null||items.length()==0)continue;addSection(s.optString("title","Músicas"),items);made++;}if(made==0&&fallback!=null&&fallback.length()>0){addSection("Músicas",fallback);made++;}homeStatus.setText(made>0?"":"Nenhuma música cadastrada no painel.");}

    void addSection(String title,JSONArray arr){TextView h=new TextView(this);h.setText(title);h.setTextColor(Color.WHITE);h.setTextSize(22);h.setTypeface(null,1);h.setPadding(dp(16),dp(23),dp(8),dp(10));sectionsBox.addView(h);HorizontalScrollView sv=new HorizontalScrollView(this);sv.setHorizontalScrollBarEnabled(false);LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setPadding(dp(9),0,dp(9),0);sv.addView(row);int max=Math.min(arr.length(),18);for(int i=0;i<max;i++){JSONObject x=arr.optJSONObject(i);if(x==null)continue;MusicItem item=parse(x);LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(7),dp(4),dp(7),dp(4));ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);card.addView(im,new LinearLayout.LayoutParams(dp(140),dp(140)));Glide.with(this).load(item.thumb).into(im);TextView t=new TextView(this);t.setText(item.title);t.setTextColor(Color.WHITE);t.setTypeface(null,1);t.setMaxLines(1);card.addView(t,new LinearLayout.LayoutParams(dp(140),-2));TextView sub=new TextView(this);sub.setText(item.subtitle);sub.setTextColor(getColor(R.color.muted));sub.setMaxLines(1);card.addView(sub,new LinearLayout.LayoutParams(dp(140),-2));card.setOnClickListener(v->play(item));row.addView(card,new LinearLayout.LayoutParams(dp(154),dp(205)));}sectionsBox.addView(sv,new LinearLayout.LayoutParams(-1,dp(210)));}

    MusicItem parse(JSONObject x){return new MusicItem(x.optString("id"),x.optString("type","song"),x.optString("title"),x.optString("subtitle",x.optString("artist")),x.optString("thumbnail"),x.optString("video_id"));}

    void search(){String q=searchInput.getText().toString().trim();if(q.isEmpty())return;searchStatus.setText("Buscando...");new Thread(()->{try{JSONObject j=new JSONObject(Net.get(BuildConfig.PANEL_URL+"/api/music/search.php?q="+URLEncoder.encode(q,"UTF-8")));JSONArray a=j.optJSONArray("items");ArrayList<MusicItem> n=new ArrayList<>();if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null)n.add(parse(x));}runOnUiThread(()->{searchItems.clear();searchItems.addAll(n);adapter.notifyDataSetChanged();searchStatus.setText(n.size()+" resultado(s)");});}catch(Exception e){runOnUiThread(()->searchStatus.setText("Erro: "+e.getMessage()));}}).start();}

    void play(MusicItem x){
        if(controller==null){Toast.makeText(this,"Player iniciando. Toque novamente.",Toast.LENGTH_SHORT).show();return;}
        nowTitle.setText(x.title); nowSub.setText(x.subtitle); Glide.with(this).load(x.thumb).into(nowThumb);
        new Thread(()->{try{
            JSONObject src=new JSONObject(Net.get(BuildConfig.PANEL_URL+"/api/music/source.php?id="+URLEncoder.encode(x.id,"UTF-8")));
            String url=src.optString("stream_url");
            if(url.isEmpty())throw new Exception(src.optString("message","Esta música não possui áudio configurado no painel."));
            MediaMetadata metadata=new MediaMetadata.Builder().setTitle(x.title).setArtist(x.subtitle).setArtworkUri(x.thumb.isEmpty()?null:Uri.parse(x.thumb)).build();
            MediaItem mediaItem=new MediaItem.Builder().setUri(url).setMediaId(x.id).setMediaMetadata(metadata).build();
            runOnUiThread(()->{controller.setMediaItem(mediaItem);controller.prepare();controller.play();});
        }catch(Exception e){runOnUiThread(()->Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show());}}).start();
    }

    void toggle(){if(controller==null)return;if(controller.isPlaying())controller.pause();else controller.play();}
    int dp(int v){return (int)(v*getResources().getDisplayMetrics().density);}

    @Override protected void onDestroy(){
        if(controllerFuture!=null)MediaController.releaseFuture(controllerFuture);
        super.onDestroy();
    }
}
