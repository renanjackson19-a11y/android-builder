package com.ativacao.app;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class FreeFootballSource {
    private static final ExecutorService IO=Executors.newSingleThreadExecutor();
    private static final String BASE="https://worldcup26.ir";
    private static final String[] DEFAULT_LEAGUES={
        "eng.1","eng.2","eng.fa","eng.league_cup",
        "esp.1","esp.2","esp.copa_del_rey","uefa.champions"
    };

    static void load(ApiClient.Callback<List<ApiClient.FootballMatch>> cb){
        IO.execute(()->{
            try{
                String dayApi=new SimpleDateFormat("yyyyMMdd",Locale.US).format(new Date());
                String today=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());
                ArrayList<ApiClient.FootballMatch> out=new ArrayList<>();
                ArrayList<String> leagues=loadAvailableLeagues();
                if(leagues.isEmpty())Collections.addAll(leagues,DEFAULT_LEAGUES);

                for(String league:leagues){
                    try{parseScoreboard(get(BASE+"/get/soccer/"+league+"/scoreboard?dates="+dayApi),out,today,league);}catch(Exception ignored){}
                }
                if(out.isEmpty()){
                    for(String league:leagues){
                        try{parseFixtures(get(BASE+"/get/soccer/"+league+"/fixtures?status=all&from="+dayApi+"&to="+dayApi+"&limit=100"),out,today,league);}catch(Exception ignored){}
                    }
                }

                Map<String,String> logos=loadClubLogos(leagues);
                applyLogos(out,logos);
                if(out.isEmpty())loadOpenFootball(out,today,logos);

                dedupe(out);
                Collections.sort(out,new Comparator<ApiClient.FootballMatch>(){
                    public int compare(ApiClient.FootballMatch a,ApiClient.FootballMatch b){return safe(a.clock).compareTo(safe(b.clock));}
                });
                cb.ok(out);
            }catch(Exception e){cb.error(e.getMessage()==null?"erro de rede":e.getMessage());}
        });
    }

    private static ArrayList<String> loadAvailableLeagues(){
        ArrayList<String> out=new ArrayList<>();
        try{
            Object root=new JSONTokener(get(BASE+"/get/soccer/leagues?kind=club&available=true")).nextValue();
            JSONArray a=findArray(root,"leagues","data","items","results");
            if(a!=null)for(int i=0;i<a.length();i++){
                JSONObject o=a.optJSONObject(i);if(o==null)continue;
                String slug=first(o,"slug","league_slug","id","code");
                if(!slug.isEmpty()&&!out.contains(slug))out.add(slug);
            }
        }catch(Exception ignored){}
        return out;
    }

    private static void parseScoreboard(String raw,List<ApiClient.FootballMatch> out,String today,String leagueSlug)throws Exception{
        Object parsed=new JSONTokener(raw).nextValue();
        JSONArray events=findArray(parsed,"events","matches","data","items","results");if(events==null)return;
        String leagueName=leagueSlug;
        if(parsed instanceof JSONObject){
            JSONObject root=(JSONObject)parsed;
            JSONArray lgs=root.optJSONArray("leagues");
            if(lgs!=null&&lgs.length()>0){JSONObject l=lgs.optJSONObject(0);String n=first(l,"name","displayName","abbreviation","slug");if(!n.isEmpty())leagueName=n;}
        }
        for(int i=0;i<events.length();i++){
            JSONObject ev=events.optJSONObject(i);if(ev==null)continue;
            String rawDate=first(ev,"date","startDate","kickoff","start_time");
            if(!rawDate.isEmpty()&&rawDate.length()>=10&&!today.equals(rawDate.substring(0,10)))continue;
            JSONObject home=null,away=null;
            JSONArray comps=ev.optJSONArray("competitions");
            if(comps!=null&&comps.length()>0){
                JSONObject comp=comps.optJSONObject(0);JSONArray teams=comp==null?null:comp.optJSONArray("competitors");
                if(teams!=null)for(int j=0;j<teams.length();j++){
                    JSONObject c=teams.optJSONObject(j);if(c==null)continue;
                    if("home".equalsIgnoreCase(c.optString("homeAway")))home=c;else if("away".equalsIgnoreCase(c.optString("homeAway")))away=c;
                }
            }
            ApiClient.FootballMatch m=new ApiClient.FootballMatch();m.league=leagueName;m.date=today;
            if(home!=null&&away!=null){
                m.home=teamName(home);m.away=teamName(away);m.homeLogo=teamLogo(home);m.awayLogo=teamLogo(away);
                String hs=home.optString("score","");String as=away.optString("score","");if(!hs.isEmpty()&&!as.isEmpty())m.score=hs+" - "+as;
            }else{
                JSONObject h=object(ev,"home","homeTeam","home_team","team1");JSONObject a=object(ev,"away","awayTeam","away_team","team2");
                m.home=h==null?stringTeam(ev,"home","home_name","team1"):first(h,"displayName","name","shortDisplayName");
                m.away=a==null?stringTeam(ev,"away","away_name","team2"):first(a,"displayName","name","shortDisplayName");
                if(h!=null)m.homeLogo=first(h,"logo","image","crest","badge");if(a!=null)m.awayLogo=first(a,"logo","image","crest","badge");
            }
            if(empty(m.home)||empty(m.away))continue;
            JSONObject st=ev.optJSONObject("status");JSONObject typ=st==null?null:st.optJSONObject("type");
            m.status=typ==null?first(ev,"status","statusText","state"):first(typ,"shortDetail","description","detail","state");
            if(empty(m.status))m.status="Hoje";m.clock=eventTime(ev,st);out.add(m);
        }
    }

    private static void parseFixtures(String raw,List<ApiClient.FootballMatch> out,String today,String leagueSlug)throws Exception{
        Object parsed=new JSONTokener(raw).nextValue();JSONArray a=findArray(parsed,"fixtures","matches","events","data","items","results");if(a==null)return;
        for(int i=0;i<a.length();i++){
            JSONObject ev=a.optJSONObject(i);if(ev==null)continue;String rawDate=first(ev,"date","startDate","kickoff","start_time","start");
            if(!rawDate.isEmpty()&&rawDate.length()>=10&&!today.equals(rawDate.substring(0,10)))continue;
            ApiClient.FootballMatch m=new ApiClient.FootballMatch();m.league=leagueSlug;m.date=today;
            JSONObject lg=object(ev,"league","competition","tournament");if(lg!=null){String n=first(lg,"name","displayName","abbreviation","slug");if(!n.isEmpty())m.league=n;}
            JSONObject h=object(ev,"home","homeTeam","home_team","team1");JSONObject aw=object(ev,"away","awayTeam","away_team","team2");
            if(h!=null){m.home=first(h,"displayName","name","shortDisplayName","abbreviation");m.homeLogo=first(h,"logo","image","crest","badge");}else m.home=stringTeam(ev,"home","home_name","team1");
            if(aw!=null){m.away=first(aw,"displayName","name","shortDisplayName","abbreviation");m.awayLogo=first(aw,"logo","image","crest","badge");}else m.away=stringTeam(ev,"away","away_name","team2");
            if(empty(m.home)||empty(m.away))continue;m.clock=clockFromDate(rawDate);m.status=first(ev,"status","statusText","state");if(empty(m.status))m.status="Agendado";out.add(m);
        }
    }

    private static Map<String,String> loadClubLogos(List<String> leagues){
        Map<String,String> map=new HashMap<>();
        for(String league:leagues)try{
            Object parsed=new JSONTokener(get(BASE+"/get/soccer/"+league+"/clubs")).nextValue();
            JSONArray clubs=findArray(parsed,"clubs","data","items","results","teams");if(clubs==null)continue;
            for(int i=0;i<clubs.length();i++){
                JSONObject c=clubs.optJSONObject(i);if(c==null)continue;
                String name=first(c,"display_name","displayName","name","short_display_name","shortDisplayName");String logo=first(c,"logo","image","crest","badge");
                if(logo.isEmpty()){JSONArray la=c.optJSONArray("logos");if(la!=null&&la.length()>0){Object one=la.opt(0);if(one instanceof JSONObject)logo=first((JSONObject)one,"href","url","logo");else if(one instanceof String)logo=(String)one;}}
                if(!name.isEmpty()&&!logo.isEmpty()){map.put(norm(name),logo);String sh=first(c,"short_display_name","shortDisplayName","abbreviation");if(!sh.isEmpty())map.put(norm(sh),logo);}
            }
        }catch(Exception ignored){}
        return map;
    }

    private static void loadOpenFootball(List<ApiClient.FootballMatch> out,String today,Map<String,String> logos){
        String[] seasons={"2026-27","2025-26"};String[] files={"en.1.json","en.2.json","es.1.json","es.2.json","de.1.json","it.1.json","fr.1.json","pt.1.json"};
        for(String season:seasons){for(String file:files)try{parseOpenFootball(get("https://raw.githubusercontent.com/openfootball/football.json/master/"+season+"/"+file),out,today,logos);}catch(Exception ignored){}if(!out.isEmpty())break;}
    }

    private static void parseOpenFootball(String raw,List<ApiClient.FootballMatch> out,String today,Map<String,String> logos)throws Exception{
        JSONObject root=new JSONObject(raw);JSONArray a=root.optJSONArray("matches");if(a==null)return;String league=root.optString("name","Futebol");
        for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null||!today.equals(o.optString("date","")))continue;ApiClient.FootballMatch m=new ApiClient.FootballMatch();m.league=league;m.date=today;m.home=team(o.opt("team1"));m.away=team(o.opt("team2"));m.clock=o.optString("time","");m.status="Agendado";m.homeLogo=findLogo(logos,m.home);m.awayLogo=findLogo(logos,m.away);out.add(m);}
    }

    private static void applyLogos(List<ApiClient.FootballMatch> list,Map<String,String> logos){for(ApiClient.FootballMatch m:list){if(empty(m.homeLogo))m.homeLogo=findLogo(logos,m.home);if(empty(m.awayLogo))m.awayLogo=findLogo(logos,m.away);}}
    private static String findLogo(Map<String,String> logos,String name){String n=norm(name);String x=logos.get(n);if(x!=null)return x;for(Map.Entry<String,String> e:logos.entrySet()){String k=e.getKey();if(k.length()>3&&(n.contains(k)||k.contains(n)))return e.getValue();}return "";}
    private static JSONArray findArray(Object root,String... keys){if(root instanceof JSONArray)return (JSONArray)root;if(!(root instanceof JSONObject))return null;JSONObject o=(JSONObject)root;for(String k:keys){JSONArray a=o.optJSONArray(k);if(a!=null)return a;JSONObject n=o.optJSONObject(k);if(n!=null){JSONArray r=findArray(n,keys);if(r!=null)return r;}}return null;}
    private static JSONObject object(JSONObject o,String... keys){for(String k:keys){JSONObject v=o.optJSONObject(k);if(v!=null)return v;}return null;}
    private static String first(JSONObject o,String... keys){if(o==null)return "";for(String k:keys){Object v=o.opt(k);if(v instanceof String&&!((String)v).trim().isEmpty())return ((String)v).trim();if(v instanceof Number)return String.valueOf(v);}return "";}
    private static String stringTeam(JSONObject o,String... keys){for(String k:keys){Object v=o.opt(k);if(v instanceof String&&!((String)v).trim().isEmpty())return ((String)v).trim();}return "";}
    private static String eventTime(JSONObject ev,JSONObject st){JSONObject typ=st==null?null:st.optJSONObject("type");String state=typ==null?"":typ.optString("state","");String detail=st==null?"":st.optString("displayClock","");if("in".equals(state)||"post".equals(state))return detail;return clockFromDate(first(ev,"date","startDate","kickoff","start_time"));}
    private static String clockFromDate(String iso){if(iso==null||iso.isEmpty())return "";try{SimpleDateFormat in=new SimpleDateFormat("yyyy-MM-dd'T'HH:mmX",Locale.US);SimpleDateFormat out=new SimpleDateFormat("HH:mm",Locale.getDefault());Date d=in.parse(iso);if(d!=null)return out.format(d);}catch(Exception ignored){}try{if(iso.length()>=16)return iso.substring(11,16);}catch(Exception ignored){}return "";}
    private static String teamName(JSONObject c){JSONObject t=c.optJSONObject("team");if(t==null)t=c;return first(t,"displayName","name","shortDisplayName","abbreviation");}
    private static String teamLogo(JSONObject c){JSONObject t=c.optJSONObject("team");if(t==null)t=c;String logo=first(t,"logo","image","crest","badge");if(!logo.isEmpty())return logo;JSONArray a=t.optJSONArray("logos");if(a!=null&&a.length()>0){Object one=a.opt(0);if(one instanceof JSONObject)return first((JSONObject)one,"href","url","logo");if(one instanceof String)return (String)one;}return "";}
    private static void dedupe(List<ApiClient.FootballMatch> list){HashSet<String> seen=new HashSet<>();for(int i=list.size()-1;i>=0;i--){ApiClient.FootballMatch m=list.get(i);String k=norm(m.home)+"|"+norm(m.away)+"|"+safe(m.date);if(seen.contains(k))list.remove(i);else seen.add(k);}}
    private static String norm(String s){String x=safe(s).toLowerCase(Locale.ROOT);x=java.text.Normalizer.normalize(x,java.text.Normalizer.Form.NFD).replaceAll("\\p{M}","");return x.replaceAll("[^a-z0-9]","");}
    private static String team(Object x){if(x instanceof String)return (String)x;if(x instanceof JSONObject)return first((JSONObject)x,"name","displayName");return "Time";}
    private static String safe(String s){return s==null?"":s;}
    private static boolean empty(String s){return s==null||s.trim().isEmpty();}
    private static String get(String u)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(6000);c.setReadTimeout(8000);c.setRequestProperty("User-Agent","DubaiPlayTV/4.0.18");c.setRequestProperty("Accept","application/json");int code=c.getResponseCode();if(code<200||code>=300)throw new Exception("HTTP "+code);BufferedReader b=new BufferedReader(new InputStreamReader(c.getInputStream()));StringBuilder s=new StringBuilder();String l;while((l=b.readLine())!=null)s.append(l);b.close();return s.toString();}
}
