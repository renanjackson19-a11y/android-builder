package com.ativacao.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        final Context app = context.getApplicationContext();

        // 1) Antes de depender da internet, reaplica o último estado confirmado.
        // Isso evita que um UniTV já bloqueado volte a abrir durante a inicialização.
        if (DeviceControl.isDeviceOwner(app)) {
            DeviceControl.enforceManagedState(app);
            DeviceControl.reapplyLastUnitvPolicy(app);
        } else if (LauncherStore.isTvBoxMode(app)) {
            // Fallback para projetores AOSP que ignoram a seleção visual de HOME.
            DeviceControl.trySetHomeWithRoot(app);
        }

        PolicyScheduler.schedule(app);

        // 2) Em TV Box já ativada, tenta trazer a Home gerenciada para frente.
        if (LauncherStore.isActivationComplete(app) && LauncherStore.isTvBoxMode(app)) {
            DeviceControl.launchHomeNow(app);
        }

        // 3) Atualiza a política assim que houver rede. goAsync evita travar o boot.
        final PendingResult pending = goAsync();
        new Thread(() -> {
            try {
                PolicySync.sync(app);
                if (DeviceControl.isDeviceOwner(app)) {
                    DeviceControl.enforceManagedState(app);
                    DeviceControl.reapplyLastUnitvPolicy(app);
                }
            } catch (Throwable ignored) {
            } finally {
                try { pending.finish(); } catch (Throwable ignored) {}
            }
        }, "boot-policy-sync").start();
    }
}
