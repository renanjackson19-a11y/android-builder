package com.ativacao.app;

public class Config {
    public static final String BASE_URL = "https://unitvbrasil.online";
    public static final String[] BASE_URLS = new String[] {
            "https://unitvbrasil.online",
            "https://unitvativador.br232.shop",
            "https://painel.br232uni.shop",
            "https://painel.br232ativa.shop"
    };
    public static final String API_ATIVAR = BASE_URL + "/api/ativar.php";
    public static final String API_APP_CONFIG = BASE_URL + "/api/app_config.php";
    public static final String API_SUPORTE = BASE_URL + "/api/suporte_app.php";
    public static final String PASTA_ALTERNATIVA = "Android/data/online.unitvbrasil.ativadorlauncher/files";
    public static final String NOME_CONFIG_FINAL = ".config";
    public static final String NOME_PROPERTIES_FINAL = ".properties";
    public static final String NOME_APK_FINAL = "unitvfree.apk";
    public static final String NOME_APK_ANDROID = "unitv_android_celular.apk";
    public static final String NOME_APK_TV_BOX = "unitv_tvbox_firestick_mxq.apk";
}
