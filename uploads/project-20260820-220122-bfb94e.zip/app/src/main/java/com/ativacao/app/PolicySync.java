package com.ativacao.app;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.os.Build;
import android.provider.Settings;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public final class PolicySync {
    private PolicySync() {}

    public static void sync(Context context) {
        String base = PolicyStore.getControlUrl(context);
        String license = PolicyStore.getLicense(context);
        if (base.isEmpty() || license.isEmpty()) return;
        HttpURLConnection conn = null;
        try {
            String deviceId = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
            String model = Build.MANUFACTURER + " " + Build.MODEL;
            String version = currentVersion(context);
            String url = base + "/api/device_sync.php?license=" + enc(license)
                    + "&device_id=" + enc(deviceId == null ? "" : deviceId)
                    + "&model=" + enc(model)
                    + "&android=" + enc(String.valueOf(Build.VERSION.SDK_INT))
                    + "&app_version=" + enc(version)
                    + "&device_owner=" + (DeviceControl.isDeviceOwner(context) ? "1" : "0")
                    + "&control_supported=" + (DeviceControl.isSupported(context) ? "1" : "0")
                    + "&_ts=" + System.currentTimeMillis();
            conn = (HttpURLConnection)new URL(url).openConnection();
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(20000);
            conn.setUseCaches(false);
            conn.setRequestProperty("Cache-Control", "no-cache, no-store, must-revalidate");
            conn.setRequestProperty("Pragma", "no-cache");
            conn.setRequestMethod("GET");
            InputStream is = conn.getResponseCode() >= 400 ? conn.getErrorStream() : conn.getInputStream();
            if (is == null) return;
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            StringBuilder sb = new StringBuilder(); String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();
            JSONObject obj = new JSONObject(sb.toString());
            if (!"ok".equalsIgnoreCase(obj.optString("status", ""))) return;
            String packageName = obj.optString("unitv_package", "").trim();
            boolean blocked = obj.optBoolean("block_unitv", false);
            String message = obj.optString("message", "");
            int minutes = Math.max(15, obj.optInt("sync_minutes", 15));
            PolicyStore.setSyncMinutes(context, minutes);
            DeviceControl.applyUnitvPolicy(context, packageName, blocked, message);
            if (DeviceControl.isDeviceOwner(context)) DeviceControl.enforceManagedState(context);
        } catch (Throwable ignored) {
        } finally { if (conn != null) conn.disconnect(); }
    }

    private static String currentVersion(Context context) {
        try {
            PackageInfo p = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            return p.versionName == null ? "" : p.versionName;
        } catch (Throwable ignored) {
            return "";
        }
    }

    private static String enc(String s) throws Exception { return URLEncoder.encode(s, "UTF-8"); }
}
