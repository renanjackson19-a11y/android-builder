package com.ativacao.app;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.UserManager;
import java.util.concurrent.TimeUnit;

public final class DeviceControl {
    private DeviceControl() {}

    public static ComponentName admin(Context c) { return new ComponentName(c, AdminReceiver.class); }

    public static boolean isSupported(Context c) {
        return c.getPackageManager().hasSystemFeature(PackageManager.FEATURE_DEVICE_ADMIN);
    }

    public static boolean isDeviceOwner(Context c) {
        try {
            DevicePolicyManager dpm = (DevicePolicyManager)c.getSystemService(Context.DEVICE_POLICY_SERVICE);
            return dpm != null && dpm.isDeviceOwnerApp(c.getPackageName());
        } catch (Throwable e) { return false; }
    }

    public static boolean protectActivator(Context c) {
        if (!isDeviceOwner(c)) return false;
        try {
            DevicePolicyManager dpm = (DevicePolicyManager)c.getSystemService(Context.DEVICE_POLICY_SERVICE);
            dpm.setUninstallBlocked(admin(c), c.getPackageName(), true);
            return true;
        } catch (Throwable e) { return false; }
    }

    /**
     * Bloqueia o gerenciamento/desinstalacao de aplicativos no Android.
     * Isso impede que o cliente contorne o PIN abrindo a tela Apps por outra rota
     * das Configuracoes. Requer Device Owner, como toda protecao forte do Android.
     */
    public static boolean protectAppManagement(Context c) {
        if (!isDeviceOwner(c)) return false;
        try {
            DevicePolicyManager dpm = (DevicePolicyManager)c.getSystemService(Context.DEVICE_POLICY_SERVICE);
            if (dpm == null) return false;
            dpm.addUserRestriction(admin(c), UserManager.DISALLOW_APPS_CONTROL);
            dpm.addUserRestriction(admin(c), UserManager.DISALLOW_UNINSTALL_APPS);
            return true;
        } catch (Throwable e) { return false; }
    }

    /** Libera temporariamente a area Apps depois que o PIN correto foi informado. */
    public static boolean allowAppManagementTemporarily(Context c) {
        if (!isDeviceOwner(c)) return false;
        try {
            DevicePolicyManager dpm = (DevicePolicyManager)c.getSystemService(Context.DEVICE_POLICY_SERVICE);
            if (dpm == null) return false;
            dpm.clearUserRestriction(admin(c), UserManager.DISALLOW_APPS_CONTROL);
            dpm.clearUserRestriction(admin(c), UserManager.DISALLOW_UNINSTALL_APPS);
            return true;
        } catch (Throwable e) { return false; }
    }

    public static boolean setAsPersistentHome(Context c) {
        if (!isDeviceOwner(c) || !LauncherStore.isTvBoxMode(c)) return false;
        try {
            DevicePolicyManager dpm = (DevicePolicyManager)c.getSystemService(Context.DEVICE_POLICY_SERVICE);
            Intent filterIntent = new Intent(Intent.ACTION_MAIN);
            android.content.IntentFilter filter = new android.content.IntentFilter(filterIntent.getAction());
            filter.addCategory(Intent.CATEGORY_HOME);
            filter.addCategory(Intent.CATEGORY_DEFAULT);
            ComponentName activity = new ComponentName(c, LauncherActivity.class);
            dpm.addPersistentPreferredActivity(admin(c), filter, activity);
            return true;
        } catch (Throwable e) { return false; }
    }


    /**
     * Fallback privilegiado para Android TV/TV Box/projetores que escondem a tela de HOME.
     * Os comandos variam entre versões do Android; por isso tentamos as sintaxes conhecidas
     * sem desativar nem apagar a Launcher original do fabricante.
     */
    public static boolean trySetHomeWithRoot(Context c) {
        if (!LauncherStore.isTvBoxMode(c)) return false;
        Process p = null;
        try {
            String component = c.getPackageName() + "/" + LauncherActivity.class.getName();
            String pkg = c.getPackageName();
            String cmd =
                    "ok=1; " +
                    "cmd package set-home-activity --user 0 " + component + " >/dev/null 2>&1 && ok=0; " +
                    "if [ $ok -ne 0 ]; then cmd package set-home-activity " + component + " >/dev/null 2>&1 && ok=0; fi; " +
                    "if [ $ok -ne 0 ]; then pm set-home-activity --user 0 " + component + " >/dev/null 2>&1 && ok=0; fi; " +
                    "if [ $ok -ne 0 ]; then pm set-home-activity " + component + " >/dev/null 2>&1 && ok=0; fi; " +
                    "if [ $ok -ne 0 ]; then cmd role add-role-holder --user 0 android.app.role.HOME " + pkg + " >/dev/null 2>&1 && ok=0; fi; " +
                    "if [ $ok -ne 0 ]; then cmd role add-role-holder android.app.role.HOME " + pkg + " >/dev/null 2>&1 && ok=0; fi; " +
                    "if [ $ok -eq 0 ]; then am start --user 0 -n " + component + " >/dev/null 2>&1; exit 0; fi; exit 1";
            p = new ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start();
            boolean done = p.waitFor(8, TimeUnit.SECONDS);
            if (!done) {
                try { p.destroy(); } catch (Throwable ignored) {}
                return false;
            }
            return p.exitValue() == 0;
        } catch (Throwable e) {
            try { if (p != null) p.destroy(); } catch (Throwable ignored) {}
            return false;
        }
    }

    /** Reaplica a HOME pelo melhor caminho privilegiado disponível. */
    public static boolean enforceHomeBestEffort(Context c) {
        if (!LauncherStore.isTvBoxMode(c)) return false;
        if (isDeviceOwner(c)) return setAsPersistentHome(c);
        return trySetHomeWithRoot(c);
    }

    public static boolean clearPersistentHome(Context c) {
        if (!isDeviceOwner(c)) return false;
        try {
            DevicePolicyManager dpm = (DevicePolicyManager)c.getSystemService(Context.DEVICE_POLICY_SERVICE);
            dpm.clearPackagePersistentPreferredActivities(admin(c), c.getPackageName());
            return true;
        } catch (Throwable e) { return false; }
    }

    public static boolean enforceManagedState(Context c) {
        if (!isDeviceOwner(c)) return false;
        boolean home;
        if (LauncherStore.isTvBoxMode(c)) home = setAsPersistentHome(c);
        else { clearPersistentHome(c); home = true; }
        boolean uninstall = protectActivator(c);
        boolean appsControl = protectAppManagement(c);
        reapplyLastUnitvPolicy(c);
        return home && uninstall && appsControl;
    }

    public static boolean isUninstallProtectionActive(Context c) {
        if (!isDeviceOwner(c)) return false;
        try {
            DevicePolicyManager dpm = (DevicePolicyManager)c.getSystemService(Context.DEVICE_POLICY_SERVICE);
            return dpm != null && dpm.isUninstallBlocked(admin(c), c.getPackageName());
        } catch (Throwable e) { return false; }
    }

    public static boolean setPackageBlocked(Context c, String packageName, boolean blocked) {
        if (packageName == null || packageName.trim().isEmpty() || !isDeviceOwner(c)) return false;
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false;
        try {
            DevicePolicyManager dpm = (DevicePolicyManager)c.getSystemService(Context.DEVICE_POLICY_SERVICE);
            String[] failed = dpm.setPackagesSuspended(admin(c), new String[]{packageName.trim()}, blocked);
            return failed == null || failed.length == 0;
        } catch (Throwable e) { return false; }
    }

    /**
     * Aplica a política nova de forma segura e grava o último estado confirmado.
     * Se o package do UniTV mudou, libera o package antigo antes de aplicar o novo.
     */
    public static boolean applyUnitvPolicy(Context c, String packageName, boolean blocked, String message) {
        String pkg = packageName == null ? "" : packageName.trim();
        String old = PolicyStore.getLastUnitvPackage(c).trim();
        boolean ok = true;

        if (isDeviceOwner(c)) {
            if (!old.isEmpty() && !old.equals(pkg)) {
                ok = setPackageBlocked(c, old, false) && ok;
            }
            if (!pkg.isEmpty()) {
                ok = setPackageBlocked(c, pkg, blocked) && ok;
            }
        }

        PolicyStore.setLastPolicy(c, blocked, pkg, message);
        return ok;
    }

    /** Reaplica imediatamente o último bloqueio/liberação conhecido, inclusive no boot. */
    public static boolean reapplyLastUnitvPolicy(Context c) {
        String pkg = PolicyStore.getLastUnitvPackage(c).trim();
        if (pkg.isEmpty()) return true;
        if (!isDeviceOwner(c)) return false;
        return setPackageBlocked(c, pkg, PolicyStore.isLastBlocked(c));
    }

    /**
     * Traz a Launcher para frente depois do boot/reinício. Em Device Owner, o Home
     * persistente já foi aplicado antes desta chamada.
     */
    public static void launchHomeNow(Context c) {
        if (!LauncherStore.isActivationComplete(c) || !LauncherStore.isTvBoxMode(c)) return;
        try {
            Intent i = new Intent(c, LauncherActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            c.startActivity(i);
        } catch (Throwable ignored) {}
    }
}
