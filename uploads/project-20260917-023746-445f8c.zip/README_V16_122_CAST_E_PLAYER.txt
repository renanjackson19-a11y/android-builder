GreenPlay Android Nativo v16.122
Base: v16.121, derivada da base oficial v16.117.

Alterações desta versão:
- Cast/Transmitir deixou de ser overlay flutuante sobre a busca.
- Ícone Cast agora fica alinhado na mesma linha da busca na Home e na TV ao vivo, sem sobreposição.
- Cast continua oculto em Android TV/TV Box.
- Player de filmes/séries migrado de VideoView para Media3/ExoPlayer.
- Vídeo centralizado com resize FIT, evitando imagem presa a um lado em telas/proporções diferentes.
- Fullscreen imersivo, escondendo barras de sistema durante a reprodução.
- Avançar/retroceder 10s usa posição real do ExoPlayer.
- Barra de progresso faz seek proporcional à duração real e permite chegar ao meio/fim corretamente.
- D-pad/controle remoto: botões de reprodução e seek reforçados.
- Removido botão Cast de dentro do player; transmissão permanece como ação do cabeçalho em celular/tablet.

Não alterados: painel, Api.java, banco, TMDB, provedores, planos e pagamento.
