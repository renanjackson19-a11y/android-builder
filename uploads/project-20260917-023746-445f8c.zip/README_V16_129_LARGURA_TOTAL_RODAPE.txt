GreenPlay v16.129

Base: v16.128.

Ajuste visual solicitado:
- menu inferior ocupa 100% da largura, de uma lateral à outra;
- remove qualquer recuo lateral do rodapé;
- mantém a barra inferior reta, sem cartão flutuante e sem caixa na aba ativa;
- aba ativa continua indicada apenas por ícone/texto verde;
- conteúdo comum mantém margens internas de leitura, independentes do rodapé;
- TV ao vivo continua com área própria em largura total;
- reduz o espaço morto inferior sem encostar conteúdo no menu.

Não altera painel, banco, TMDB, provedores, planos ou pagamento.
