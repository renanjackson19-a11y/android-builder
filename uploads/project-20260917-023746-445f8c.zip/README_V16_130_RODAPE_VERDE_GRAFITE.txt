GreenPlay v16.130

Base: v16.129.

Ajuste visual:
- rodapé inferior clareado de preto para verde-grafite (#102018), harmonizando com os cards;
- itens inativos do menu com contraste um pouco melhor;
- aba ativa permanece no verde principal do aplicativo;
- largura total e estrutura do rodapé da v16.129 preservadas;
- nenhuma alteração em painel, banco, TMDB, provedores, planos, pagamento ou player.

VersionCode: 152
VersionName: 1.16.130.0
