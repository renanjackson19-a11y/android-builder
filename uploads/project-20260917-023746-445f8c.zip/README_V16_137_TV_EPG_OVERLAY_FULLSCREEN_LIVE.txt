GreenPlay Android Nativo v16.137
Base: v16.136

TV ao vivo - ajuste focado, sem alterar as demais áreas:
- mantém o fullscreen da v16.136 em FILL, preenchendo a tela sem ZOOM/CROP e sem cortar logos/bordas do canal;
- fullscreen passa a colocar o mesmo PlayerView diretamente sobre a área de conteúdo, removendo visualmente resíduos/listas inferiores durante a tela cheia e restaurando o layout original ao sair;
- EPG deixa de ficar fixo cobrindo o vídeo: aparece como overlay temporário ao abrir/trocar canal, ao entrar/sair da tela cheia e ao interagir com o player/controles; some sozinho após alguns segundos;
- quando a fonte não retorna EPG, o app não inventa programação nem exibe títulos fictícios;
- busca de EPG passa a enviar e comparar identificadores reais disponíveis no canal: tvg-id/tvg_id, epg id, nome, stream_name e aliases;
- quando o EPG retorna horários reais, o overlay mostra programa atual e próximo com faixa/horário;
- logos continuam sendo lidas da própria fonte (stream_icon/tvg_logo e fallbacks já existentes);
- preservadas as rotinas da v16.135: buffer equilibrado, decoder fallback, watchdog de buffering/travamento e recuperação automática;
- ao sair e voltar ao aplicativo, qualquer canal ativo é reaberto pela fonte atual para retornar ao ponto ao vivo, inclusive quando o player não estava em estado isPlaying no exato instante do background;
- interação por toque e por controle remoto/D-pad foi mantida; o D-pad apenas revela temporariamente o EPG sem consumir a navegação.

Não altera painel, banco, TMDB, provedores, planos, pagamento, Home, Filmes ou Séries.
