GreenPlay Android Nativo v16.127

Base: v16.126.

Ajuste visual do rodape a partir das fotos de referencia enviadas:
- menu inferior mais compacto e refinado, sem o bloco preto excessivamente alto;
- estado selecionado com destaque discreto e consistente;
- rodape aproxima-se da area segura inferior sem alterar a proporcao geral das telas;
- Home, Perfil, Favoritos e Downloads recebem respiro de scroll suficiente para o ultimo conteudo nao ficar espremido no menu;
- TV ao vivo mantém categorias e canais com scroll independente, reduzindo espaco morto no fim das colunas;
- nenhuma alteracao em painel, banco, TMDB, provedores, planos ou pagamento.

A proporcao visual permanece unica entre celular, Android TV e TV Box; diferencas de TV continuam limitadas a foco/controle remoto e compatibilidade.
