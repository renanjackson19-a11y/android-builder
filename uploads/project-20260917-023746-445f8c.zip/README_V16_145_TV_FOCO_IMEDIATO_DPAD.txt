GreenPlay v16.145
Base: v16.144

Correções de controle remoto / D-pad em modo TV:
- Removido atraso de 120 ms ao transferir foco; foco agora é imediato.
- Fallback de foco reduzido para 24 ms apenas quando necessário.
- OK/Enter ignora repetição automática do controle, evitando clique duplicado.
- Categorias da TV ao vivo agora exibem foco visual próprio com borda verde forte.
- Setas esquerda/direita percorrem categorias de forma determinística e o trilho acompanha o foco sem voltar ao início.
- Selecionar categoria com OK atualiza o destaque e carrega a lista correspondente.

Mantidas as correções anteriores de player, EPG, fullscreen sem crop, logos da fonte e retorno ao ao vivo.
