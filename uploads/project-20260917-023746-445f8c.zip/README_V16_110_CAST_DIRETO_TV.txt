GreenPlay Android v16.110

Base: v16.109.

Ajuste principal: transmissão direta para TV (Google Cast), sem espelhamento de tela.

- "Espelhar na TV" foi substituído por "Transmitir na TV" em filmes e episódios.
- O app usa Google Cast / Chromecast / TVs com Google Cast integrado.
- A TV recebe a URL do conteúdo e reproduz diretamente; o celular vira controle e a tela pode ser bloqueada/apagada.
- O Player ganhou botão "TV" para transmitir o conteúdo que já está sendo reproduzido, inclusive canais ao vivo compatíveis.
- Ao iniciar o Cast, o player local pausa para evitar reprodução duplicada.
- Mantido o espelhamento fora do fluxo principal; Miracast continua sendo espelhamento e exige o celular ativo.
- Mantida a tela TV ao vivo organizada da v16.109 e toda a lógica existente de categorias, favoritos e navegação.
- Não altera painel, TMDB, provedores, banco, MisticPay ou configurações existentes.

Compatibilidade:
- Funciona com Chromecast, Google TV e Smart TVs com Google Cast integrado.
- Smart TVs sem Google Cast integrado podem não aparecer no seletor. Para esses aparelhos, é necessário suporte DLNA específico ou app receptor próprio.
- O stream precisa ser acessível diretamente pela TV/receptor.
