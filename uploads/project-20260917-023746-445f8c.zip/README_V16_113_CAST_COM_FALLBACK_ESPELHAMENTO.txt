GreenPlay v16.113

Correção cirúrgica do compartilhamento para Smart TV:
- tenta Google Cast direto quando o aparelho suporta;
- se Google Cast não estiver disponível, abre automaticamente o espelhamento nativo do Android, como na versão que funcionava antes;
- remove a mensagem sem saída "Google Cast não está disponível neste aparelho";
- nenhuma alteração no painel, catálogo, pagamento, TMDB, provedores ou banco.
