GreenPlay Android v16.107

Base direta: v16.106.

Correção cirúrgica:
- TV ao vivo continua visível quando o provedor realmente possui canais, mesmo com teste/plano vencido.
- A capacidade de TV vem do provedor, não do status da assinatura.
- O bootstrap não zera a capacidade de TV só porque a conta vencida recebeu live_channels vazio.
- O cliente pode navegar pela TV; ao tentar reproduzir um canal, aplica o mesmo bloqueio de assinatura usado em Filmes/Séries.
- Não altera painel, pagamento, TMDB, logo, banco, catálogo ou provedores.
