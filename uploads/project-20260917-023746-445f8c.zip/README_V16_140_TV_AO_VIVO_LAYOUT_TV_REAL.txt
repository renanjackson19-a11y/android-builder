GreenPlay Android Nativo v16.140
Base: v16.139

ALTERACOES DESTA VERSAO
- Mantido o aplicativo movel sem alteracao de layout.
- Modo TV/Android TV/TV Box continua automatico em TVs e pode ser forçado no Perfil para teste no celular.
- Tela TV ao vivo em modo TV reorganizada para uso real em 16:9:
  * lista/categorias de canais à esquerda;
  * player grande à direita;
  * margens de segurança para TVs/overscan;
  * identidade visual GreenPlay preservada;
  * PlayerView em FIT no modo embutido, sem zoom/crop da imagem;
  * fullscreen continua preservando a imagem sem crop, conforme base v16.136+;
  * foco D-pad mais previsível entre lista, player, Som e Tela cheia.
- Barras do sistema passam a ficar ocultas no Modo TV, inclusive quando o modo é forçado no celular para visualização/teste.
- Ao sair do fullscreen, margens e composição da tela TV são restauradas corretamente.

PRESERVADO
- Recuperação automática/buffer/watchdog e retorno ao ao vivo da v16.135.
- Fullscreen sem crop da v16.136.
- EPG real e temporário da v16.137.
- Detecção ampliada de Android TV/TV Box e interface sem zoom da v16.138.
- Opção Modo TV / Android TV Box no Perfil da v16.139.
- Logos dos canais provenientes da fonte.
- Painel, banco, TMDB, provedores, planos e pagamento não foram alterados.
