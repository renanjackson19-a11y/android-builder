GreenPlay Android v16.109

- Base direta: v16.108.
- Tela TV ao vivo reorganizada no padrão profissional da referência: busca, preview, abas, categorias à esquerda e canais à direita.
- Mantém categorias e canais reais do provedor; nenhuma mudança no catálogo/backend.
- "Espelhar na TV" deixou de ser botão falso: agora abre o recurso nativo de Cast/Miracast do próprio Android para conexão real com Smart TVs compatíveis.
- O espelhamento depende do celular/TV suportarem Cast ou Miracast e estarem na mesma rede quando exigido pelo aparelho.
- Painel não alterado.
