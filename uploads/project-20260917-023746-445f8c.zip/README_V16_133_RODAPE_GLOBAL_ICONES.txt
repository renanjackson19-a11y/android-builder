GreenPlay Android Nativo v16.133

Correção focada no rodapé global e nos ícones de navegação.

- Corrige regressão que fazia o rodapé ganhar margens laterais depois de abrir/fechar detalhes.
- Rodapé global permanece de ponta a ponta em Home, Favoritos, TV, Downloads e Perfil.
- Mantém sempre as cinco posições do menu no celular para evitar alternância visual durante o carregamento da capacidade de TV ao vivo.
- Substitui símbolos de texto do rodapé por ícones vetoriais consistentes (Início, Favoritos, TV, Downloads e Perfil).
- Aba ativa usa ícone/texto verde e peso de fonte maior; abas inativas usam cinza claro consistente.
- Reforça o padrão do rodapé ao retornar do player/app e ao fechar detalhes.
- Não altera painel, banco, TMDB, provedores, planos ou pagamento.
