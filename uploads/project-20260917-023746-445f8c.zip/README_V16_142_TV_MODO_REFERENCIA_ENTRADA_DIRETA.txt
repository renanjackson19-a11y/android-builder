GreenPlay v16.142

Base: v16.141

Ajustes desta entrega:
- Modo TV agora entra direto na tela TV ao vivo quando o provedor possui canais, ficando mais próximo da referência enviada.
- Home no modo TV não pode mais abrir lá embaixo: scroll fixado no topo e foco inicial mantido no cabeçalho quando o usuário entra na Home.
- Tela TV ao vivo ajustada para ficar mais próxima do conceito de lista fixa à esquerda e player dominante à direita.
- Lista de canais ganhou badge de numeração quando disponível e foco inicial no primeiro canal.
- Mantidas as correções anteriores: fullscreen sem crop/zoom, EPG overlay temporário, logos reais, estabilidade do player, retorno ao ao vivo.
