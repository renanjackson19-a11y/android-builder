GreenPlay Android Nativo v16.120

Base oficial: v16.117.
Continuação direta dos ajustes isolados iniciados na TV ao vivo.

Alterações desta versão:
- A busca da TV mantém o mesmo visual da busca da Home.
- O topo da TV agora respeita a área segura real do Android (status bar e recorte/notch), evitando sobreposição com relógio, Wi-Fi e bateria.
- O comando de transmitir para TV passa a ser geral no menu inferior do aplicativo, em vez de aparecer repetido nas ações de Filmes, Séries e dentro do player embutido da TV.
- Quando uma TV já está conectada, ao escolher um filme, episódio ou canal ao vivo o conteúdo é enviado diretamente para a sessão Cast.
- O player de vídeo completo mantém seu controle de TV porque a barra geral do aplicativo não fica visível durante a reprodução em tela dedicada.

Não alterado:
- painel
- planos / pagamento
- TMDB
- provedores
- banco
- regras de catálogo
