GreenPlay Android v16.116

Correção focada na TV ao vivo, sobre a v16.115.

- O player embutido de TV deixou de usar VideoView/MediaPlayer e passou a usar AndroidX Media3 ExoPlayer.
- Buffer de live ajustado para reduzir congelamentos e rebuffer frequente em streams Xtream/TS/HLS.
- A fonte não é reiniciada quando ocorre buffering; permanece no mesmo stream e o player tenta se recuperar.
- As chaves video_320/video_480/video_720/video_1080 do backend apontam para a mesma URL do canal; por isso a antiga troca automática de "qualidade" foi removida.
- User-Agent do player de TV ajustado para perfil de player IPTV, sem Referer/Origin do site na fonte Xtream direta.
- Tela cheia reutiliza a mesma instância do player: não cria outro player e não chama a URL novamente.
- Rotação de tela cheia fixada em landscape determinístico e PlayerView usa zoom apenas na tela cheia.
- Ao sair da tela cheia, o mesmo canal continua tocando e a lista volta à posição anterior.
- Categorias/canais e demais telas mantidos da v16.115.
- Nenhuma alteração no painel/backend.

Validações locais:
- verificação de sintaxe Java orientada a parser: sem erros de parsing;
- integridade do ZIP: unzip -t.
A compilação Android completa deve ser feita no workflow Android/GitHub do projeto.
