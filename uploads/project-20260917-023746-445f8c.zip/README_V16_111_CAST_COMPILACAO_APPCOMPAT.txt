GreenPlay Android v16.111

Correção cirúrgica sobre a v16.110:
- Corrige a falha de compilação do CastHelper mostrada no GitHub Actions.
- Adiciona explicitamente androidx.appcompat:appcompat:1.7.0, dependência exigida pelo MediaRouteChooserDialog usado no seletor Google Cast.
- Mantém intactas as demais alterações da v16.110.
- Não altera painel, TMDB, provedores, banco, MisticPay ou regras de assinatura.

Erro corrigido:
class file for androidx.appcompat.app.AppCompatDialog not found
