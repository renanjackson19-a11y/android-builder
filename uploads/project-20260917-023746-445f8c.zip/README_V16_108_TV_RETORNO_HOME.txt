GreenPlay Android v16.108

Base: v16.107.

Correção cirúrgica de navegação da TV:
- Ao abrir TV pela barra inferior ou pelo card Canais ao vivo da Home, a tela passa a usar sempre host transitório.
- A Home permanente não é mais limpa ao abrir TV pelo card da Home.
- Botão Início e seta Voltar da TV restauram a Home já carregada, sem recarregar catálogo.
- Nenhuma alteração na lógica de categorias/canais, pagamento, painel, TMDB, provedores ou assinatura.
