GreenPlay Android v16.102

Base: v16.101.

TV ao vivo:
- restaurada a logica funcional usada antes das alteracoes recentes;
- categorias reais do provedor continuam na coluna esquerda;
- ao selecionar uma categoria, carrega somente os canais daquela categoria;
- get_category volta a ser a fonte direta de categorias quando elas nao estao na memoria;
- get_channel volta a ser a fonte direta dos canais por categoria quando o snapshot completo nao esta disponivel;
- nenhum catalogo de TV e persistido em disco;
- menu TV e regras de plano/provedor das versoes atuais foram preservados.

Demais correcoes de navegacao, perfil, pagamentos e provedores da v16.101 foram mantidas.
