GreenPlay Android Nativo v16.123

Base: v16.122 (continuidade da base oficial v16.117).

Ajustes desta versão:
- Player de Filmes/Séries continua em Media3/ExoPlayer.
- Buffer inicial reduzido para iniciar a reprodução mais rápido.
- Timeouts de conexão/leitura definidos para evitar espera excessiva em fontes ruins.
- Ao sair/minimizar o aplicativo, o player pausa imediatamente e não continua reproduzindo em segundo plano.
- O player da TV ao vivo também pausa quando o aplicativo vai para segundo plano.
- Adicionado controle de enquadramento no player: Ajustar (FIT), Zoom (preenche preservando proporção com corte) e Preencher (ocupa toda a tela).
- O modo de tela escolhido fica salvo para a próxima reprodução.
- Barra de progresso agora faz o seek ao soltar o dedo, evitando dezenas de seeks durante o arraste.
- Avanço/retrocesso de 10 segundos mantidos e compatíveis com controle remoto.
- Nenhuma alteração em painel, banco, TMDB, provedores, planos ou pagamento.
