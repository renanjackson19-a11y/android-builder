GreenPlay Android v16.121
Base: v16.120, derivada da base oficial v16.117.

Objetivo desta versão: compatibilidade real de navegação em Android TV e TV Box, sem alterar painel/API/banco/provedores/pagamento/TMDB.

Ajustes principais:
- botão Transmitir removido da barra inferior; a barra volta a ter somente Início, Favoritos, TV, Downloads e Perfil;
- Transmitir fica como ação global apenas em celular/tablet e é ocultado em Android TV/TV Box/Fire TV;
- detecção de TV/Box reforçada, inclusive para aparelhos baratos que não se anunciam corretamente como Leanback/Android TV;
- cadastro refeito com ScrollView, ajuste ao teclado, foco por D-pad e sequência Nome -> E-mail -> WhatsApp -> Senha -> Criar conta;
- teclas Next/Done/Enter do teclado de TV avançam o formulário e fecham o teclado ao chegar ao botão;
- login, seleção de servidor, busca, menus, cards, abas, detalhes e perfil seguem o modo de foco do controle remoto;
- navegação horizontal explícita no menu inferior, abas da Home, menu inferior dos detalhes e controles do player;
- player em TV/Box não exibe Cast e recebe navegação determinística por D-pad, além de teclas Play/Pause/Avançar/Voltar;
- TV ao vivo mantém player embutido, tela cheia sem trocar a instância e ganha navegação por controle entre busca, abas, categorias, canais e controles;
- carrossel automático da Home fica parado em TV/Box para não mover o conteúdo enquanto o usuário navega pelo controle;
- câmera/troca de foto do perfil, que depende de galeria de celular, fica oculta em TV/Box;
- suporte externo foi protegido para não fechar o app quando a TV/Box não tiver navegador/WhatsApp compatível;
- manifesto mantém launcher normal e Leanback, touchscreen opcional, adiciona banner de TV e adjustResize para o teclado;
- compatibilidade mínima ampliada para Android API 24.

Transmissão:
- no celular/tablet, o botão global usa Google Cast e faz busca ativa por receptores Cast na mesma rede;
- pressionar e segurar o botão abre o espelhamento do sistema quando o aparelho oferece essa função;
- em Android TV/TV Box o botão não é exibido, pois o próprio aparelho é o dispositivo de reprodução.

Validações desta entrega:
- parser Java sem erros de sintaxe nos arquivos alterados;
- XML do manifesto/recursos validado;
- banner TV validado em 320x180;
- ZIP testado com verificação de integridade;
- comparação com v16.120 confirma alterações somente no app Android e nos recursos de compatibilidade TV/controle.

Observação: este ambiente não possui Android SDK/Gradle completo para gerar e executar um APK em hardware real. A validação final de comportamento deve ser feita instalando o build em pelo menos uma Android TV e uma TV Box com controle D-pad.
