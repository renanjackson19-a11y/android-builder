GreenPlay Android v16.106

- Base direta: v16.105.
- Correção cirúrgica no bootstrap do provedor.
- Restaurada exatamente a condição de aceitação do snapshot usada na v16.92.
- Filmes/Séries não ficam mais bloqueados esperando a parte de TV.
- Nenhuma alteração na lógica da TV, navegação, Perfil, Planos, pagamento, TMDB, logo, banco ou painel.
- Painel permanece v72.14.
