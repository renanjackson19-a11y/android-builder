GreenPlay Android Nativo v16.131

Base: v16.130.

Ajuste focado no cabeçalho da TV ao vivo:
- removido o símbolo quadrado ▣ que funcionava como voltar e parecia um ícone solto;
- a TV usa a mesma logo/identidade visual da Home;
- busca da TV agora usa a mesma largura, altura, raio, padding e espaçamentos da Home;
- Cast permanece alinhado à direita em celular/tablet;
- tocar na logo da TV retorna ao Início;
- mantida navegação por controle remoto em Android TV/TV Box;
- nenhuma alteração em painel, banco, TMDB, provedores, planos ou pagamento.
