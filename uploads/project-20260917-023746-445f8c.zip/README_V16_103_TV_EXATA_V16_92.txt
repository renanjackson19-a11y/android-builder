GreenPlay Android v16.103

- Base: v16.102.
- TV ao vivo restaurada EXATAMENTE com a lógica da v16.92.
- Categorias reais na coluna esquerda.
- Canais da categoria selecionada na coluna direita.
- Removidos os fallbacks experimentais adicionados depois da v16.92.
- Mantidas as correções atuais de navegação, perfil, planos, pagamento e provedores.
