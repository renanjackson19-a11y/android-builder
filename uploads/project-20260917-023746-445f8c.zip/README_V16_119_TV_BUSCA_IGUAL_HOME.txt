GreenPlay Android Nativo v16.119

Base: v16.117 oficial, continuando os ajustes isolados da TV ao vivo.

Alteração desta versão:
- Somente a barra de pesquisa da tela TV ao vivo.
- Visual igual ao campo de busca da Home: 38dp de altura, raio 21dp, mesma cor e borda, padding equivalente, texto 14sp e ícone branco à direita.
- A busca continua funcional e filtra apenas os canais da TV.

Não alterado:
- Home
- Filmes
- Séries
- Planos / pagamento
- TMDB
- Provedores
- Banco
- Painel
