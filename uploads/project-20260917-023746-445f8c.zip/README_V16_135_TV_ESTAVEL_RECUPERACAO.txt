GreenPlay Android v16.135

Base: v16.134.

TV ao vivo - estabilidade:
- removido o seek forçado para o ponto live durante READY/retorno; alguns streams MPEG-TS/HLS podiam entrar no meio de um GOP e exibir macroblocos antes de congelar;
- ao voltar ao app ou tocar novamente no mesmo canal, a fonte é reaberta do zero para pegar o ponto ao vivo atual com um fluxo limpo;
- buffer de live reequilibrado (mais tolerância a jitter sem voltar ao atraso excessivo);
- removida a configuração de live ultrabaixa de 1,2s da v16.134; o ExoPlayer passa a respeitar a janela natural da fonte;
- decoder fallback habilitado;
- watchdog verifica buffering prolongado e reprodução que parou de avançar, reiniciando o canal automaticamente;
- em erro, tenta recuperar a mesma fonte antes de passar para outra URL de qualidade;
- tela cheia continua preenchendo as laterais com ZOOM sem reiniciar o player;
- logos e EPG da v16.134 foram preservados.

Não altera painel, banco, TMDB, provedores, planos ou pagamento.
