GreenPlay Android Nativo v16.136
Base: v16.135

Correção pontual na TV ao vivo:
- Tela cheia não usa mais ZOOM/CROP.
- O quadro inteiro do canal permanece visível, inclusive logos nas bordas.
- O vídeo preenche a área lateral do fullscreen usando FILL, sem recortar esquerda/direita ou topo/baixo.
- Ao sair da tela cheia, o player volta ao modo FIT normal.

Nenhuma alteração em painel, banco, TMDB, provedores, planos ou pagamento.
