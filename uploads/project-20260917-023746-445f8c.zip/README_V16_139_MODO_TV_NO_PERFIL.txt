GreenPlay v16.139 - Modo TV / Android TV Box no Perfil

Base: v16.138. Mantidas as correcoes anteriores de TV, EPG, fullscreen, buffer e retorno ao vivo.

Alteracoes desta versao:
- Adicionada no Perfil a opcao "Modo TV / Android TV Box".
- No celular/tablet, a opcao permite forcar a interface 16:9 de TV para revisar/testar exatamente o layout de TV no mesmo aparelho.
- O modo de teste fica salvo ate ser desligado pelo usuario.
- Ao ativar, a Activity e recriada e entra em landscape com a composicao de TV.
- Ao desligar, retorna ao layout normal de celular/tablet e orientacao correspondente.
- Em Android TV/Google TV/TV Box detectados de forma nativa, o Modo TV continua automatico e nao pode ser desligado acidentalmente pelo Perfil.
- Nenhuma mudanca em painel, banco, TMDB, provedores, planos ou pagamento.

Versao interna: 1.16.139.0 (versionCode 161).
