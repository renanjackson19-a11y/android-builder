GreenPlay Android Nativo v16.124

Base: v16.123.

Ajustes desta versão:
- Android TV/TV Box recebe escala visual adaptativa própria, sem alterar celular/tablet.
- Cards, textos, botões, cabeçalhos, detalhes e navegação ficam maiores conforme a resolução da TV.
- A interface continua usando toda a largura disponível, com scroll e foco por controle preservados.
- Player em Android TV/TV Box inicia em modo Zoom por padrão para aproveitar melhor a tela.
- Ajustar / Zoom / Preencher continuam disponíveis e a escolha da TV é salva separadamente do celular.
- Nenhuma alteração em painel, banco, TMDB, provedores, planos ou pagamento.
