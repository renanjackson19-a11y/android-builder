GreenPlay v16.143

Base: v16.142

Principais ajustes:
- Modo TV volta a iniciar em Destaques/Home; não depende da existência de canais ao vivo para abrir uma tela útil.
- Home de TV sempre tem um bloco visível de acesso a Filmes, Séries e Favoritos; TV ao vivo aparece apenas quando a fonte realmente possui canais.
- Cabeçalho de TV foi refeito em duas faixas: marca e ações em cima, navegação abaixo, mais próximo da referência enviada.
- TV ao vivo foi simplificada: lista à esquerda sem cartões pesados, player dominante à direita, busca e favoritos compactos e categorias discretas.
- Mantidas as correções anteriores do player, EPG, logos e fullscreen sem crop.
