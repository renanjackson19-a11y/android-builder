GreenPlay Android Nativo v16.114

Base: v16.113.

Alterações desta versão:
- Tela TV ao vivo reorganizada seguindo o fluxo do vídeo de referência.
- Busca compacta no topo.
- Player de canal embutido na própria tela de TV.
- Estado inicial "Escolha um canal".
- Ao tocar em um canal, a reprodução começa no player superior sem sair da tela.
- Abas Canais / Favoritos preservadas.
- Categorias reais permanecem na coluna esquerda e canais na direita.
- Canal em reprodução fica destacado.
- Controle de som e botão Tela cheia no player.
- Tela cheia usa o PlayerActivity existente; ao voltar, a tela de TV e a seleção permanecem e o canal volta ao player embutido.
- Mantido o bloqueio de assinatura/limite de telas antes da reprodução.
- Sessão do player embutido mantém heartbeat e é liberada ao sair da TV.
- Mensagem de fallback do Cast alterada para:
  "Google Cast indisponível neste dispositivo. Iniciando espelhamento de tela..."

Não altera painel, TMDB, provedores, MisticPay, banco de dados ou configurações existentes.
