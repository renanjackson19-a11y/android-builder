GreenPlay Android v16.105

Base: v16.104.

Correção TV ao vivo sem alteração no painel:
- restaura o estado real de TV da v16.92;
- a aba TV só aparece após o snapshot atual do provedor trazer canais ao vivo;
- não usa mais capacidade antiga salva para abrir uma TV vazia;
- categorias/canais voltam a usar a lógica funcional da v16.92;
- se o provedor informa TV, o bootstrap aguarda o bloco live_channels antes de abrir a Home;
- nenhuma alteração em MisticPay, planos, TMDB, banco, logo ou provedores.

Painel: continuar usando v72.14. Não aplicar v72.15 para esta correção.
