GreenPlay Android Nativo v16.132

Base: v16.131.

Ajuste principal: layout responsivo dedicado para Android TV e TV Box, sem ampliar o layout de celular.

- Celular/tablet preservam a interface atual.
- Android TV/TV Box usam navegação superior própria para tela grande.
- Home em TV exibe mais conteúdo por linha, com cards proporcionais e sem zoom geral.
- TV ao vivo em TV/Box usa lista de canais à esquerda e player à direita, no padrão de aplicativo de sala.
- Filmes, Séries, Favoritos, Downloads e Perfil usam largura e espaçamento adaptados à tela grande.
- Navegação por D-pad/controle remoto continua ativa.
- Cast continua oculto no próprio Android TV/TV Box.
- O modo de TV é aplicado a qualquer dispositivo identificado como TV/Box, independentemente da densidade configurada pelo fabricante.
- Painel, banco, TMDB, provedores, planos e pagamento não foram alterados.
