GreenPlay v16.141 — Modo TV referência + início no topo

Base: v16.140. Nenhuma correção anterior foi revertida.

Correções desta versão:
- Modo TV/TV Box abre sempre no topo da Home, com foco inicial no menu.
- Trilhos de Destaques e listas carregadas de forma assíncrona não roubam mais o foco e não puxam a tela para baixo.
- Ao ativar/desativar "Modo TV / Android TV Box" no Perfil, o scroll da Home é zerado antes de recriar a tela.
- TV ao vivo em modo TV foi refeita para ficar mais próxima da referência: lista única de canais à esquerda e player grande à direita.
- Categorias permanecem disponíveis numa faixa horizontal compacta acima da lista, sem ocupar uma segunda coluna.
- Identidade visual continua GreenPlay (fundo escuro + verde).
- Player continua RESIZE_MODE_FIT no modo normal e preserva a imagem sem crop.
- Mantidas as correções de EPG real/temporário, logos da fonte, estabilidade do player e retorno ao ao vivo.

Não alterado: painel, banco, TMDB, provedores, planos, pagamento, regras de catálogo e layout móvel.
