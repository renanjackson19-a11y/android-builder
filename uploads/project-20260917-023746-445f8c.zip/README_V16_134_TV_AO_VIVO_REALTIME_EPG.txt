GreenPlay Android v16.134

Base: v16.133.

TV ao vivo:
- logos dos canais agora leem stream_icon e aliases reais da fonte, com thumbnail/logo/icon como fallback;
- player ao vivo é pré-aquecido e a sessão de reprodução é validada em segundo plano para reduzir o atraso ao clicar no canal;
- buffer inicial e alvo de latência foram reduzidos para aproximar a reprodução do ponto ao vivo;
- ao voltar ao aplicativo, o canal é reposicionado/reaberto no ponto ao vivo em vez de continuar do instante em que foi pausado;
- clicar novamente no mesmo canal também força retorno ao ao-vivo;
- EPG atual/próximo é lido dos campos retornados pela fonte e há consulta não bloqueante aos endpoints get_short_epg/get_epg quando disponíveis;
- tela cheia da TV ao vivo usa ZOOM para preencher as laterais preservando a proporção do vídeo;
- o mesmo ExoPlayer é mantido durante a troca para tela cheia;
- transições de orientação não são tratadas como saída real do aplicativo.

Não altera painel, banco, TMDB, provedores, planos ou pagamento.
