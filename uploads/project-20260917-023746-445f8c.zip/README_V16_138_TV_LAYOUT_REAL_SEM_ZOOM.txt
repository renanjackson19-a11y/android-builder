GreenPlay v16.138 - TV/TV Box com layout proprio sem zoom

Base: v16.137. Nenhuma regressao intencional de player/EPG/fullscreen.

Alteracoes desta versao:
- Celular/tablet preservados: o novo dimensionamento so entra quando o aparelho e classificado como TV/TV Box.
- Deteccao ampliada para Android TV, Google TV, Fire TV e TV Boxes genericas que nao anunciam LEANBACK corretamente.
- TV usa escala logica baseada na resolucao real 16:9, independente da densidade errada reportada por algumas boxes. Isso evita a aparencia de app de celular ampliado/zoomado.
- Tipografia de TV usa a mesma escala logica da composicao; nao herda scaledDensity exagerada do firmware.
- Header de TV horizontal e mais compacto, mantendo a identidade/cores GreenPlay.
- TV ao vivo no estilo de sala: lista a esquerda e player grande a direita; player continua FIT fora do fullscreen e FILL sem crop no fullscreen conforme a v16.136/v16.137.
- Foco D-pad visivel por contorno verde, sem zoom/scale do componente.
- Navegacao da lista de canais para o player/controles reforcada para controle remoto.
- EPG temporario, logos da fonte e recuperacao do live da v16.137 preservados.

Nao alterado:
- painel, banco, TMDB, provedores, planos e pagamento;
- fluxos de Home/Filmes/Series no celular;
- integracoes de backend.
