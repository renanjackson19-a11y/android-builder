GreenPlay Android Nativo v16.125

Correção sobre a v16.124:
- removido o aumento global de escala aplicado por engano em Android TV/TV Box;
- interface de TV/Box volta às proporções normais;
- player volta a abrir em Ajustar por padrão;
- Zoom e Preencher continuam disponíveis apenas como opções do player;
- demais correções da v16.123/v16.124 preservadas.

Sem alterações em painel, banco, TMDB, provedores, planos ou pagamento.
