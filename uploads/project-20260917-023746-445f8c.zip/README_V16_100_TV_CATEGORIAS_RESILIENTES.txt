GreenPlay Android v16.100

- Base: v16.99.
- TV preserva todas as categorias reais do provedor.
- Primeiro usa o snapshot live já carregado na sessão.
- Se necessário, busca TV-only via bootstrap_home direto da Xtream.
- get_category/get_channel ficam como fallback com repetição curta.
- Canais continuam filtrados pela categoria selecionada.
- Nenhum cache persistente de catálogo foi adicionado.
- Incluído botão Tentar novamente quando a fonte não responde.
