GreenPlay Android v16.115

Correções focadas somente na TV ao vivo:
- Tela cheia usa o MESMO VideoView da tela de TV; não abre outro player e não reinicia o stream.
- Modo tela cheia imersivo remove barras/insets laterais e ocupa a tela.
- Voltar sai da tela cheia e retorna à lista mantendo o mesmo canal em reprodução.
- Categorias e canais agora possuem rolagem vertical independente.
- Em rede móvel a TV ao vivo inicia em qualidade mais leve e reduz automaticamente a qualidade se houver buffering repetido.
- Nenhuma alteração no painel/backend, pagamentos, TMDB ou provedores.
