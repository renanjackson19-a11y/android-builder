GreenPlay Android v16.118

Base oficial: v16.117.

Alterações restritas à tela TV ao vivo:
- TV passa a usar largura total útil, sem apertar player/listas pelas margens globais do app.
- Busca compacta no topo no padrão do vídeo: ícone dentro do campo à esquerda e texto “Pesquisar canal...”.
- Player embutido em proporção 16:9, usando toda a largura útil.
- Categorias e canais seguem em colunas separadas, com rolagem vertical independente e espaço inferior para alcançar o último item.
- Visual das categorias/lista aproximado da referência, preservando a cor/identidade configurada do GreenPlay.
- Botão “TV”/Cast visível nos controles do player quando o canal está pronto.
- Tela cheia reutiliza a MESMA instância do ExoPlayer/PlayerView e não recarrega a URL do canal.
- Tela cheia mantém resize proporcional (FIT) e, ao sair, restaura o mesmo player 16:9 e a lista.
- Home, Filmes, Séries, planos, pagamento, TMDB, provedores, banco e painel/backend não foram alterados.
