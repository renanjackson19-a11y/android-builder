GreenPlay Android v16.104

- Base: v16.103.
- Mantém o layout da TV da v16.92.
- Se get_category vier vazio, pagina get_channel e reconstrói TODAS as categorias reais por category_id/category_name.
- Continua exibindo categorias à esquerda e canais da categoria à direita.
- Sem cache persistente de catálogo no app.
- Compatível com patch painel v72.15 para fallback direto da Xtream.
