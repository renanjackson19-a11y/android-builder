GreenPlay Android Nativo v16.126

Base: v16.125.

Objetivo desta versão:
- um único padrão de proporção visual para celular, tablet, Android TV e TV Box;
- removidas larguras/margens especiais que alteravam a composição de login, cadastro e seleção de servidor em TV/Box;
- preview da TV ao vivo passa a usar a mesma regra proporcional em qualquer aparelho;
- foco por controle remoto continua funcionando, mas sem aumentar/encolher os componentes;
- player mantém Ajustar / Zoom / Preencher como opções de conteúdo, sem zoom global da interface;
- diferenças de TV/Box ficam limitadas a controle remoto, orientação apropriada e recursos incompatíveis com TV (ex.: Cast como origem).

Sem alterações em painel, banco, TMDB, provedores, planos ou pagamento.
