GreenPlay v16.144

Base: v16.143

Correções exclusivas do modo Android TV / Google TV / TV Box:
- OK/Enter passa a executar a opção focada em um único acionamento.
- Navegação horizontal das categorias da TV ao vivo foi travada explicitamente em esquerda/direita para não escapar nem voltar ao início.
- A faixa de categorias acompanha o foco com rolagem horizontal.
- Seta para baixo nas categorias entra na lista de canais; seta para cima retorna à busca.
- Cabeçalho do modo TV compactado.
- Removido o banner grande de Destaques; catálogo começa logo abaixo do menu.
- Cards de Destaques ligeiramente menores e com melhor quantidade visível em 16:9.
- Mantido o layout de celular/tablet sem alteração.
- Mantidas estabilidade do player, EPG real temporário, logos da fonte, retorno ao ao vivo e fullscreen sem crop.
