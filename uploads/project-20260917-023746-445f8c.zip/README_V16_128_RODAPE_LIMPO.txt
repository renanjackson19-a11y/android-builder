GreenPlay v16.128

Base: v16.127.

Correção do rodapé/menu inferior:
- remove o efeito de cartão flutuante introduzido na v16.127;
- remove borda, cantos arredondados e elevação do menu inferior;
- remove o bloco/caixa em volta da aba selecionada;
- aba ativa volta a ser indicada apenas por ícone/texto verde;
- restaura altura e espaçamento natural do menu;
- restaura o respiro normal entre conteúdo e rodapé;
- mantém as correções anteriores de TV, TV Box, Cast e player.

Não altera painel, banco, TMDB, provedores, planos ou pagamento.
