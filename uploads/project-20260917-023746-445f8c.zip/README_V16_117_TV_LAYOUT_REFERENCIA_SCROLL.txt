GreenPlay Android v16.117

- Tela TV ao vivo refeita para preencher o espaço útil como a referência.
- Busca voltou ao mesmo padrão visual da Home: campo único arredondado com ícone dentro.
- Removido ScrollView pai da tela TV; categorias e canais agora têm rolagem vertical independente real.
- Painel de categorias/canais usa todo o espaço restante até a navegação inferior, sem altura fixa de 490dp.
- Player continua embutido e é o mesmo ao entrar/sair da tela cheia.
- Buffer do ExoPlayer para TV ao vivo ajustado para recuperação mais rápida de pequenas oscilações, sem reiniciar a URL.
- Nenhuma alteração no painel/backend, TMDB, provedores, planos ou pagamento.
