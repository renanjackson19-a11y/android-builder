GreenPlay v16.146

Base: v16.145

Correções no modo Android TV / Google TV / TV Box:
- Setas esquerda/direita apenas MOVEM o foco nas categorias de canais, uma categoria por toque.
- A lista de canais só muda quando o usuário confirma a categoria com OK/Enter.
- OK/Enter é consumido e executado uma única vez, evitando ativação dupla.
- Repetição automática do D-pad não pula várias categorias.
- Categoria selecionada permanece destacada mesmo quando o foco vai para outra categoria.
- A faixa acompanha o foco de forma determinística e não volta para o início sozinha.
- Se as categorias forem recarregadas, a seleção atual é preservada quando ainda existir.
- Mantidas todas as correções da v16.145 e anteriores.
