package com.ativacao.app;

import android.app.Application;

public class DubaiPlayApp extends Application {
    @Override public void onCreate() {
        super.onCreate();
        PersistentContentCache.init(this);
        CatalogPreloader.init(this);
        ApiClient.setUserToken(Session.token(this));
        ApiClient.setXtreamCredentials(Session.user(this),Session.xtreamPassword(this));
        ResumeRefreshManager.install(this);
    }
}
