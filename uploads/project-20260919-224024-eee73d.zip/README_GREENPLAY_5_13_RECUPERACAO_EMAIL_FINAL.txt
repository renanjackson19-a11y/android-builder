GreenPlay 5.13 - Recuperação de senha por e-mail

- Trabalha em conjunto com o painel v108.
- Primeiro tenta a recuperação pela mesma rota /api/dtlive/login/ usada no login normal.
- Mantém fallback /forgot_password.php e /forgot_password/.
- Exibe as mensagens reais do painel/SMTP.
- Corrige o espaço da mensagem no modal para não cortar textos maiores.
- Não altera canais, logos, filmes, séries, player ou atualizador.
