GreenPlay 5.1

Correções desta versão:
- primeira sincronização volta a preparar as logos dos canais antes de abrir a TV;
- variantes HD/FHD/SD reaproveitam a mesma família de logo para reduzir tempo sem perder cobertura;
- sessões com catálogo salvo recuperam em segundo plano apenas logos realmente ausentes;
- timeouts de logo restaurados para tolerar servidores de imagem mais lentos;
- nome do canal não fica mais cortado: removido o padding padrão do TextView dentro da área fixa;
- EPG mantém área própria sem esmagar o nome do canal;
- preservados cache persistente, menu superior sem ANR e estabilidade da v16.237.

Versão visível: 5.1
versionCode: 249
