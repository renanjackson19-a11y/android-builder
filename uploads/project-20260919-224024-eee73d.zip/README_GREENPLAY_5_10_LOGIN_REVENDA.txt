GreenPlay 5.10

- Login por usuário, e-mail ou código de acesso + senha.
- Cadastro com usuário próprio do aplicativo.
- Olho da senha menor.
- Código da revenda ocupa espaço fixo no login e não desloca o formulário.
- Recuperação de senha por e-mail via painel.
- Mantém as demais correções da 5.9.
