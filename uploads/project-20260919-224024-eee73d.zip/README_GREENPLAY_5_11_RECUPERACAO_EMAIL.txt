GreenPlay 5.11

- Corrige o envio de redefinição de senha.
- Usa o fluxo nativo do painel: token de 60 minutos + e-mail SMTP + página web para criar nova senha.
- Modal de recuperação compacto e centralizado.
- Baseado na 5.10 sem alterar canais, logos, filmes/séries ou player.
