GreenPlay 5.5

Esta versão mantém o funcionamento da 5.4 e adiciona somente metadados de atualização dentro do APK.

O APK passa a carregar automaticamente:
- versionName
- versionCode
- package/applicationId base
- novidades/correções da versão

O painel v94 usa esses dados no botão "Detectar versão" e preenche tudo antes da publicação.
As correções da versão são mantidas em app/RELEASE_NOTES.txt e incorporadas ao APK durante a compilação.
