GREENPLAY ANDROID 5.14

Ajuste desta versão:
- Recuperação de senha continua aceitando usuário, e-mail ou código de acesso.
- Erros internos de SMTP/servidor não são mais exibidos ao cliente.
- Em falhas internas, o aplicativo mostra uma mensagem curta e segura para tentar novamente.
- Erros do próprio cadastro (conta não encontrada/e-mail inválido) continuam aparecendo normalmente.
- Nenhuma alteração em canais, logos, filmes, séries, player ou atualizador.

Compatível com o patch do painel GreenPlay v109.
VersionName: 5.14
VersionCode: 51400
