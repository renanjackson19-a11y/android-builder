GreenPlay 5.6

- Atualizador centralizado vertical e horizontalmente.
- Card compacto/profissional com barra de progresso no mesmo painel.
- Botão Início sempre retorna ao topo da Home.
- Restante da base 5.5 preservado.
