GreenPlay 5.20 — Modo TV / TV Box corrigido
=============================================

Correções:
- corrige o bug em que, ao ativar Modo TV no celular/tablet, o app ficava em landscape usando partes do layout mobile;
- a barra inferior do celular não permanece mais no Modo TV;
- a troca de modo passa a reabrir a MainActivity sem animação, já na orientação final, evitando mistura entre os dois shells;
- ao voltar ao modo celular, o app volta a montar o shell mobile completo em portrait;
- mantém a tela em que o usuário estava (ex.: Perfil) após a troca;
- Android TV/TV Box nativo continua entrando automaticamente no modo TV;
- sem tela de carregamento de 100% e sem avisos flutuantes de troca de visual;
- mantém as correções de EPG da 5.18/5.19.
