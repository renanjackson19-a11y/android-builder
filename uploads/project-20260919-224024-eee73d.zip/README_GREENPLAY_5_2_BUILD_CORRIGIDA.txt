GREENPLAY 5.2 — BUILD CORRIGIDA

Correção desta entrega:
- Removida a reescrita desnecessária do AppUpdater introduzida na primeira 5.2.
- O atualizador volta a usar general_setting, que continua suportado pelo Painel v91.
- Mantida a correção de largura/layout ao trocar TV, Destaque, Futebol, Filmes, Séries, Kids e Favoritos.
- BuildConfig foi habilitado explicitamente no Gradle, pois o atualizador usa VERSION_NAME e VERSION_CODE.
- versionName: 5.2
- versionCode interno: 50201

Mantidas as correções da 5.1:
- canais/logos completos;
- cache persistente;
- estabilidade e redução de travamentos;
- atualizador interno sem navegador.
