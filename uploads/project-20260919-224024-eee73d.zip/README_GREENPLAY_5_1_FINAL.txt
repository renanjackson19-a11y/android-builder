GreenPlay 5.1 — pacote completo

Base
- Continuação da v16.237, preservando cache persistente, estabilidade, menu superior sem ANR,
  canais completos e correções do modo TV.

Correções desta versão
- Restaura a preparação das logos de canais no PRIMEIRO carregamento.
- Agrupa variantes HD/FHD/SD do mesmo canal para baixar uma logo válida por família e
  reutilizar o fallback, reduzindo tempo e evitando quadrados vazios.
- O carregamento inicial tenta preparar todos os grupos de logos antes de abrir e possui
  limite de espera para uma URL quebrada não prender o aplicativo por minutos.
- Nas próximas aberturas usa catálogo e imagens persistentes; após 72h sem uso faz a
  sincronização completa novamente, conforme solicitado.
- Mantém limites de memória e pools de imagens da v16.237 para reduzir travamento/fechamento.
- Mantém largura estável dos cards/menu de canais e o menu superior sem liberação pesada
  do ExoPlayer durante a navegação.

Atualizador interno
- Versão visível: 5.1
- versionCode: 50100
- Consulta os dados de atualização enviados pelo painel.
- Exibe atualização dentro do GreenPlay, com novidades, progresso, porcentagem e velocidade.
- Baixa o APK sem Chrome, valida SHA-256 e chama diretamente o instalador do Android.
- Na primeira atualização, Android 8+ pode pedir permissão para o GreenPlay instalar apps.
- Para instalar por cima: mesmo applicationId, mesma assinatura e versionCode maior.

Painel
- Aplicar o PATCH Painel v89 para publicar versão, versionCode, APK e novidades.
