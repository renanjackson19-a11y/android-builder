GreenPlay 5.18 — TV Box + EPG atual
=====================================

- restaurada a opção Modo TV / Android TV Box no Perfil;
- aparelhos Android TV/TV Box continuam entrando automaticamente no layout TV;
- em celular/tablet a chave permite ativar/desativar manualmente o layout TV;
- EPG antigo nos cards é descartado e substituído por consulta atual;
- cache de EPG vencido é invalidado na virada do programa;
- get_short_epg usa get_epg como fallback;
- sem alterações em canais, logos, filmes/séries, player e atualizador.
