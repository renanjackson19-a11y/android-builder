GreenPlay v16.236 — menu superior TV sem ANR

BASE
- Continuação direta da v16.235.
- Mantém canais completos e logos corrigidas da v16.235.

CORREÇÕES
- A troca TV / Destaque / Futebol / Filmes / Séries / Kids / Favoritos não chama mais ExoPlayer.release() no caminho da interface.
- Ao sair da TV, o player é pausado e a Surface é desanexada; a mesma instância é reaproveitada ao voltar.
- O ExoPlayer só é destruído definitivamente no encerramento da Activity.
- Proteção contra acionamento repetido do mesmo item do topo por tecla ENTER/DPAD pressionada/repetida.
- A ação do menu é executada no próximo frame para o foco terminar de desenhar antes da troca da página.
- O foco do menu superior não usa mais escala/translationZ nem redesenha a barra toda a cada seta, reduzindo tremida e microtravadas.

OBJETIVO
- Eliminar o aviso “GreenPlay não está respondendo” ao navegar/trocar as seções do topo em TV/TV Box.
