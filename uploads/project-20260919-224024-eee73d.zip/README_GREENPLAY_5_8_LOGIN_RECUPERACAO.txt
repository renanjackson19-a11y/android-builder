GreenPlay 5.8
- Ajuste visual do atualizador em TV/celular.
- Login mais compacto; olho da senha reduzido.
- Código da revenda troca no mesmo espaço, sem alterar o centro do formulário.
- Login por e-mail, nome ou código de acesso + senha.
- Recuperação de senha por e-mail via painel SMTP.
