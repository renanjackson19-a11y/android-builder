GreenPlay 5.9
- Cadastro solicita um usuário único separado do nome.
- Login aceita usuário, e-mail ou código de acesso + senha.
- Recuperação por e-mail permanece integrada ao SMTP do painel.
- Botão de visualizar senha reduzido e layout do código da revenda mantido centralizado.
- Compatível com o painel v100 para entrega profissional de acessos, teste rápido e criação opcional de sub-revendedores.
