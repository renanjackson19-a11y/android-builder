GreenPlay 5.17 — EPG atual nos canais
=====================================

Correção focada no problema em que o banner do canal mostrava a programação atual, mas os cards da lista exibiam horários/programas antigos.

- descarta EPG local com faixa de horário já vencida;
- consulta get_short_epg e usa get_epg apenas como fallback;
- cache curto também vale no celular;
- atualiza o card do canal quando chega EPG novo;
- primeiros canais visíveis atualizam a programação mesmo quando o bootstrap veio enriquecido;
- não altera reprodução, logos, categorias, filmes/séries nem atualizador.
