GreenPlay v16.235 — canais e logos completos na abertura

BASE
- Continuação da v16.234 (base limpa v16.228; v16.233 permanece descartada).

CORREÇÕES
- O loading inicial confere a lista completa de canais antes de liberar o aplicativo.
- O app mantém o snapshot completo e acrescenta qualquer canal encontrado na paginação do get_channel que não veio no bootstrap.
- Nenhum corte por quantidade de canais no aplicativo.
- Todas as logos são realmente baixadas/decodificadas no loading inicial; não há timeout curto que libere a tela antes do cache terminar.
- Para cada canal, o cache tenta provider_icon/stream_icon, EPG, tvg_logo e demais alternativas até encontrar uma imagem válida.
- Canais irmãos (ex.: HD/FHD/SD do mesmo nome) compartilham logos como fallback quando uma variante vem sem imagem.
- Na tela TV, a logo sai do cache já preparado; se necessário, ainda existe fallback rápido em segundo plano.
- Mantidas as correções de topo da categoria e navegação TV sem consultas EPG a cada toque.

PAINEL
- Usar junto com patch v88: remove filtros antigos H265/HEVC que podiam esconder canais, incluindo o regex incorreto [H265].
