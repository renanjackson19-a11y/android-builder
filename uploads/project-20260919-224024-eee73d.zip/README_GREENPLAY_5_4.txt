GREENPLAY 5.4

Alteracoes desta versao:
- Logos de canais: cada canal usa primeiro a logo real da propria fonte/painel.
- Removido reaproveitamento de logo por familia HD/FHD/SD/4K que podia colocar imagem errada.
- Se a logo da fonte falhar, o app tenta somente alternativas do mesmo canal (thumbnail/EPG).
- Na sincronizacao inicial, as logos sao preparadas canal por canal antes de liberar a TV.
- Fila de logos visiveis separada e prioritaria; pre-carregamento usa pool proprio.
- Tela do atualizador redesenhada em estilo mais compacto, inspirada na referencia enviada.
- APK inclui assets/greenplay_build.properties para o painel identificar versao/package como fallback seguro.

Versao: 5.4
VersionCode: 50400
Package: fun.greenplay.app
