GreenPlay 5.19 — troca de modo TV limpa

Correções:
- o seletor Modo TV / Android TV Box continua disponível no Perfil;
- aparelhos Android TV / TV Box continuam detectados automaticamente;
- ao alternar manualmente no celular/tablet, não aparece mais Toast de troca de visual;
- não aparece mais a tela “Carregando / 100% / Tudo pronto” durante a troca;
- a tela atual é mantida enquanto a orientação muda e o novo layout é montado logo em seguida;
- mantém integralmente as correções de EPG da 5.18.
