GreenPlay v16.237

- Catálogo persistente comprimido por usuário + servidor.
- Reaberturas normais usam o catálogo salvo e não repetem a sincronização completa.
- Sincronização completa obrigatória somente sem cache, após troca de conta/servidor ou mais de 72h sem usar o app.
- Enquanto o app é usado com frequência, o catálogo pode ser renovado silenciosamente em background após 12h, sem tela de espera.
- Primeira sincronização não espera indefinidamente todas as logos remotas; prepara as principais por até 18s e continua o restante em background.
- Removida conferência duplicada da lista de canais quando bootstrap_home já declara catálogo completo.
- Detalhes de filmes/séries não bloqueiam mais a abertura.
- Logos de canais decodificadas em tamanho menor para reduzir RAM e risco de fechamento em celulares.
- Fila de logos limitada a 4 workers, sem milhares de tarefas simultâneas.
- Menu/lista de canais em TV mantém largura estável: borda ativa/inativa com a mesma espessura.
- Removida troca automática para segundo layout/cinema quando o canal fica pronto; TV permanece em um único layout.
- Mantidas as correções da v16.236 e v16.235.
