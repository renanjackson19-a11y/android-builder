GREENPLAY ANDROID 5.16 - RECUPERACAO DE SENHA SEM DUPLICIDADE

- Recuperacao faz somente UMA chamada para /api/dtlive/forgot_password.php.
- Remove o encadeamento antigo login -> forgot_password.php -> forgot_password que podia disparar e-mail duplicado quando uma resposta chegava malformada/atrasada.
- Timeout da recuperacao reduzido para 10 segundos.
- Mantem login por usuario, e-mail ou codigo de acesso + senha.
- Mantem a remocao do codigo da revenda da tela de login/cadastro.
- Nao altera canais, logos, filmes/series, player ou atualizador.
