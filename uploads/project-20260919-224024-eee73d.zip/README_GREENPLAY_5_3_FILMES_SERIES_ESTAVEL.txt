GreenPlay 5.3 - estabilidade Filmes/Séries

- Corrige travamento que começava ao entrar em Filmes/Séries e permanecia ao trocar para outras áreas.
- O catálogo completo já sincronizado é reutilizado sem refazer dezenas de chamadas de páginas por categoria.
- Chamadas paginadas de uma categoria antiga são interrompidas quando o usuário muda de categoria/tela.
- Grid de Filmes/Séries passa a materializar cards sob demanda conforme a rolagem, em vez de criar a categoria inteira de uma vez.
- Capas do catálogo usam fila separada, cancelável e bitmaps menores, evitando acumular memória e derrubar o app.
- As logos visíveis dos canais usam uma fila separada da preparação em massa, para aparecerem na tela sem esperar centenas de logos do carregamento inicial.
- Mantidas as correções anteriores de canais, atualização e layout.

VersionName: 5.3
VersionCode: 50300
