GreenPlay 5.7 — Final Perfil e Conta

Base: GreenPlay 5.6.
Esta versão preserva canais, logos, filmes/séries e atualizador e finaliza Perfil/Conta, PIN adulto, dispositivos, suporte por revendedor, exclusão de conta e carregamento visual.
Requer o patch do painel v95 para os novos endpoints de conta/dispositivos/PIN/suporte.
