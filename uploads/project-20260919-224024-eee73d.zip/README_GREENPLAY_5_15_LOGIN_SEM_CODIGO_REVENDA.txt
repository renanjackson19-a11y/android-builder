GREENPLAY 5.15 — LOGIN SEM CÓDIGO DE REVENDA

- Remove o campo/botão de código da revenda do login.
- Login fica somente: usuário, e-mail ou código de acesso + senha.
- A revenda responsável é recuperada automaticamente na resposta do login.
- Cadastro no aplicativo não pede código da revenda; mantém nome, usuário próprio, e-mail, WhatsApp opcional e senha.
- Mantidos canais, logos, filmes/séries, player e atualizador sem alterações.
