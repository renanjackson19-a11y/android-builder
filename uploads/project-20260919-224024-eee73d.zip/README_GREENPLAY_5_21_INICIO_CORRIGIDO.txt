GreenPlay 5.21 — Início corrigido após troca de Modo TV
=========================================================

Correções:
- corrige o botão Início que podia parar de funcionar depois de alternar entre celular e TV/TV Box;
- Perfil, Favoritos e Downloads restaurados após a troca de modo agora usam um host temporário e não sobrescrevem a Home;
- se a Home ainda não tiver sido montada após a troca, o primeiro toque em Início monta a Home normalmente;
- mantém a troca limpa de modo da 5.20, sem loading de 100% e sem avisos flutuantes;
- mantém Modo TV / Android TV Box, EPG corrigido e demais funções anteriores.
