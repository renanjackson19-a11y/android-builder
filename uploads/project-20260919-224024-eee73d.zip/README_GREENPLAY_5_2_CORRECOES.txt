GREENPLAY 5.2

Correções desta versão:
- Corrigido o bug visual no modo TV em que a tela encolhia/crescia nas laterais ao confirmar TV, Destaque, Futebol, Filmes, Séries, Kids ou Favoritos.
- O container principal não herda mais o padding/largura da tela anterior.
- Destaque, páginas transitórias e páginas padrão usam o mesmo inset lateral no modo TV; não alternam mais entre layout centralizado e layout largo.
- Mantidas as correções de canais, logos, cache persistente, estabilidade e navegação da versão 5.1.
- Atualizador consulta o endpoint dedicado app_update do painel e mantém general_setting como fallback.
- Checagem de atualização ocorre na abertura e também ao retomar o app, com proteção contra chamadas repetidas.
- Compatível com o painel que detecta versionName/versionCode automaticamente do APK enviado.
- versionName: 5.2
- versionCode: 50200
