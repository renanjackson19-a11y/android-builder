package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class GamesActivity extends Activity {
    static class PlayGame {
        String name,url,genre,controls;
        PlayGame(String n,String u,String g,String c){name=n;url=u;genre=g;controls=c;}
    }

    private boolean phone;
    private GridView grid;
    private TextView status,title;
    private EditText search;
    private String mode="play";
    private final List<PlayGame> playableAll=new ArrayList<>(),playable=new ArrayList<>();
    private final List<OpenGameCatalog.Game> catalogAll=new ArrayList<>(),catalog=new ArrayList<>();
    private BaseAdapter adapter;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);Ui.immersive(this);phone=Ui.phone(this);
        seedPlayable();
        String m=getIntent().getStringExtra("mode");if(m!=null&&!m.isEmpty())mode=m;
        setContentView(build());load();
    }

    private LinearLayout build(){
        LinearLayout root=Ui.column(this);root.setBackgroundColor(Ui.BG);
        root.addView(YellowNav.bar(this,"GAMES"),new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?56:64)));

        LinearLayout body=Ui.column(this);body.setPadding(Ui.dp(this,24),Ui.dp(this,10),Ui.dp(this,24),Ui.dp(this,14));
        LinearLayout tabs=new LinearLayout(this);tabs.setGravity(Gravity.CENTER_VERTICAL);
        String[][] ts={{"JOGÁVEIS","play"},{"RETRO CATÁLOGO","retro"},{"PS2","ps2"},{"NINTENDO DS","ds"},{"3DS","3ds"},{"FUTEBOL","football"}};
        for(int i=0;i<ts.length;i++){
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,Ui.dp(this,46),1);
            if(i>0)lp.leftMargin=Ui.dp(this,7);
            tabs.addView(tab(ts[i][0],ts[i][1]),lp);
        }
        body.addView(tabs,new LinearLayout.LayoutParams(-1,Ui.dp(this,50)));

        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);
        title=Ui.text(this,"JOGOS JOGÁVEIS",phone?21:28,Ui.TEXT,true);
        head.addView(title,new LinearLayout.LayoutParams(0,Ui.dp(this,48),1));
        search=new EditText(this);search.setSingleLine(true);search.setHint("Pesquisar jogo...");
        search.setHintTextColor(Ui.MUTED);search.setTextColor(Color.WHITE);search.setTextSize(12);
        search.setPadding(Ui.dp(this,14),0,Ui.dp(this,14),0);search.setBackground(round(0xff121512,16,0xff303630));
        search.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b,int c){filter(s.toString());}
            public void afterTextChanged(Editable e){}
        });
        head.addView(search,new LinearLayout.LayoutParams(Ui.dp(this,320),Ui.dp(this,40)));
        body.addView(head);

        status=Ui.text(this,"",10,Ui.MUTED,false);body.addView(status,new LinearLayout.LayoutParams(-1,Ui.dp(this,28)));

        grid=new GridView(this);grid.setNumColumns(phone?4:6);grid.setHorizontalSpacing(Ui.dp(this,14));
        grid.setVerticalSpacing(Ui.dp(this,16));grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setSelector(android.R.color.transparent);
        body.addView(grid,new LinearLayout.LayoutParams(-1,0,1));

        root.addView(Ui.centered(this,body,1480),new LinearLayout.LayoutParams(-1,0,1));
        return root;
    }

    private GradientDrawable round(int color,int radius,int stroke){
        GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(Ui.dp(this,radius));
        if(stroke!=0)g.setStroke(Ui.dp(this,1),stroke);return g;
    }

    private TextView tab(String label,String target){
        TextView v=Ui.button(this,label);
        v.setOnClickListener(x->{
            if("football".equals(target)){startActivity(new Intent(this,FootballActivity.class));return;}
            mode=target;search.setText("");load();
        });
        return v;
    }

    private void seedPlayable(){
        String base="https://prateek121.github.io/90s-games/games/";
        playableAll.add(new PlayGame("Asteroids",base+"asteroids.html","Arcade","Setas + OK"));
        playableAll.add(new PlayGame("Tetris",base+"tetris.html","Puzzle","Setas + OK"));
        playableAll.add(new PlayGame("Snake",base+"snake.html","Arcade","Setas"));
        playableAll.add(new PlayGame("Pac-Man",base+"pacman.html","Arcade","Setas"));
        playableAll.add(new PlayGame("Space Invaders",base+"space-invaders.html","Arcade","Setas + OK"));
        playableAll.add(new PlayGame("2048",base+"2048.html","Puzzle","Setas"));
        playableAll.add(new PlayGame("Minesweeper",base+"minesweeper.html","Puzzle","Setas/OK conforme jogo"));
        playableAll.add(new PlayGame("Sokoban",base+"sokoban.html","Puzzle","Setas"));
        playableAll.add(new PlayGame("Bullet Hell",base+"bullet-hell.html","Arcade","Setas + OK"));
        playableAll.add(new PlayGame("Vaporwave Escape",base+"vaporwave-escape.html","Arcade","Setas + OK"));
    }

    private void load(){
        if("play".equals(mode)){
            title.setText("JOGOS JOGÁVEIS");
            adapter=new PlayAdapter();grid.setAdapter(adapter);
            filter(search.getText().toString());
            status.setText(playableAll.size()+" jogos open-source • OK para jogar");
            if(!playable.isEmpty())grid.requestFocus();
            return;
        }

        title.setText("retro".equals(mode)?"RETRO • CATÁLOGO":("ps2".equals(mode)?"PLAYSTATION 2":("ds".equals(mode)?"NINTENDO DS":"NINTENDO 3DS")));
        adapter=new CatalogAdapter();grid.setAdapter(adapter);
        catalogAll.clear();catalog.clear();
        status.setText("Carregando catálogo...");
        OpenGameCatalog.load(mode,new OpenGameCatalog.Callback(){
            public void ok(List<OpenGameCatalog.Game>d){runOnUiThread(()->{
                catalogAll.clear();catalogAll.addAll(d);filter(search.getText().toString());
                status.setText(catalogAll.size()+" itens de catálogo • ROM não incluída");
                if(!catalog.isEmpty())grid.requestFocus();
            });}
            public void error(String m){runOnUiThread(()->status.setText(m));}
        });
    }

    private void filter(String q){
        String x=q==null?"":q.trim().toLowerCase(Locale.ROOT);
        if("play".equals(mode)){
            playable.clear();
            for(PlayGame g:playableAll)if(x.isEmpty()||g.name.toLowerCase(Locale.ROOT).contains(x)||g.genre.toLowerCase(Locale.ROOT).contains(x))playable.add(g);
        }else{
            catalog.clear();
            for(OpenGameCatalog.Game g:catalogAll)if(x.isEmpty()||g.name.toLowerCase(Locale.ROOT).contains(x)||g.platform.toLowerCase(Locale.ROOT).contains(x))catalog.add(g);
        }
        if(adapter!=null)adapter.notifyDataSetChanged();
    }

    private void play(PlayGame g){
        Intent in=new Intent(this,GamePlayerActivity.class);
        in.putExtra("name",g.name);in.putExtra("url",g.url);in.putExtra("controls",g.controls);
        startActivity(in);
    }

    private void details(OpenGameCatalog.Game g){
        Intent in=new Intent(this,GameDetailActivity.class);
        in.putExtra("name",g.name);in.putExtra("platform",g.platform);
        in.putExtra("cover_res",g.coverRes);in.putExtra("synopsis",g.synopsis);
        startActivity(in);
    }

    private LinearLayout cardBase(){
        LinearLayout card=Ui.column(this);card.setFocusable(true);card.setClickable(true);Ui.focus(card,this);
        return card;
    }

    private class PlayAdapter extends BaseAdapter{
        public int getCount(){return playable.size();}public Object getItem(int p){return playable.get(p);}public long getItemId(int p){return p;}
        public android.view.View getView(int p,android.view.View cv,android.view.ViewGroup parent){
            LinearLayout card;TextView icon,name,meta,action;
            if(cv==null){
                card=cardBase();
                icon=Ui.text(GamesActivity.this,"▶",32,Ui.GREEN,true);icon.setId(951);icon.setGravity(Gravity.CENTER);
                card.addView(icon,new LinearLayout.LayoutParams(-1,0,1));
                meta=Ui.text(GamesActivity.this,"",9,Ui.GREEN,true);meta.setId(952);meta.setPadding(Ui.dp(GamesActivity.this,9),0,Ui.dp(GamesActivity.this,9),0);
                card.addView(meta,new LinearLayout.LayoutParams(-1,Ui.dp(GamesActivity.this,22)));
                name=Ui.text(GamesActivity.this,"",12,Color.WHITE,true);name.setId(953);name.setMaxLines(2);name.setPadding(Ui.dp(GamesActivity.this,9),0,Ui.dp(GamesActivity.this,9),0);
                card.addView(name,new LinearLayout.LayoutParams(-1,Ui.dp(GamesActivity.this,38)));
                action=Ui.text(GamesActivity.this,"OK • JOGAR",9,Ui.MUTED,true);action.setId(954);action.setPadding(Ui.dp(GamesActivity.this,9),0,0,Ui.dp(GamesActivity.this,5));
                card.addView(action,new LinearLayout.LayoutParams(-1,Ui.dp(GamesActivity.this,24)));
                cv=card;
            }else card=(LinearLayout)cv;
            meta=cv.findViewById(952);name=cv.findViewById(953);action=cv.findViewById(954);
            PlayGame g=playable.get(p);meta.setText(g.genre);name.setText(g.name);action.setText("OK • JOGAR");
            card.setOnClickListener(v->play(g));return cv;
        }
    }

    private class CatalogAdapter extends BaseAdapter{
        public int getCount(){return catalog.size();}public Object getItem(int p){return catalog.get(p);}public long getItemId(int p){return p;}
        public android.view.View getView(int p,android.view.View cv,android.view.ViewGroup parent){
            LinearLayout card;ImageView cover;TextView badge,name;
            if(cv==null){
                card=cardBase();
                cover=new ImageView(GamesActivity.this);cover.setId(901);cover.setScaleType(ImageView.ScaleType.CENTER_CROP);
                card.addView(cover,new LinearLayout.LayoutParams(-1,0,1));
                badge=Ui.text(GamesActivity.this,"",9,Ui.GREEN,true);badge.setId(902);badge.setPadding(Ui.dp(GamesActivity.this,8),Ui.dp(GamesActivity.this,5),Ui.dp(GamesActivity.this,8),0);
                card.addView(badge,new LinearLayout.LayoutParams(-1,Ui.dp(GamesActivity.this,24)));
                name=Ui.text(GamesActivity.this,"",phone?10:12,Color.WHITE,true);name.setId(903);name.setMaxLines(2);name.setPadding(Ui.dp(GamesActivity.this,8),0,Ui.dp(GamesActivity.this,8),Ui.dp(GamesActivity.this,7));
                card.addView(name,new LinearLayout.LayoutParams(-1,Ui.dp(GamesActivity.this,42)));cv=card;
            }else card=(LinearLayout)cv;
            cover=cv.findViewById(901);badge=cv.findViewById(902);name=cv.findViewById(903);
            OpenGameCatalog.Game g=catalog.get(p);
            int rid=getResources().getIdentifier(g.coverRes,"drawable",getPackageName());if(rid!=0)cover.setImageResource(rid);
            badge.setText(g.platform);name.setText(g.name);card.setOnClickListener(v->details(g));return cv;
        }
    }

    @Override protected void onResume(){super.onResume();Ui.immersive(this);}
}
