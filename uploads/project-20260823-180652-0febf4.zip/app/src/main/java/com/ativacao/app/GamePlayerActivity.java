package com.ativacao.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.Gravity;

public class GamePlayerActivity extends Activity {
    private WebView web;
    private String name,url,controls;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);Ui.immersive(this);
        name=getIntent().getStringExtra("name");url=getIntent().getStringExtra("url");controls=getIntent().getStringExtra("controls");
        setContentView(build());
        if(url!=null&&!url.isEmpty())web.loadUrl(url);
    }

    private View build(){
        FrameLayout root=new FrameLayout(this);root.setBackgroundColor(Color.BLACK);

        web=new WebView(this);web.setBackgroundColor(Color.BLACK);web.setFocusable(true);web.setFocusableInTouchMode(true);
        WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadWithOverviewMode(true);s.setUseWideViewPort(true);s.setBuiltInZoomControls(false);s.setDisplayZoomControls(false);
        web.setWebViewClient(new WebViewClient());web.setWebChromeClient(new WebChromeClient());
        root.addView(web,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout bar=Ui.column(this);bar.setPadding(Ui.dp(this,16),Ui.dp(this,8),Ui.dp(this,16),Ui.dp(this,8));bar.setBackgroundColor(0xB8000000);
        TextView t=Ui.text(this,(name==null?"JOGO":name)+"  •  "+(controls==null?"Setas + OK":controls),10,Color.WHITE,true);
        bar.addView(t,new LinearLayout.LayoutParams(-1,Ui.dp(this,28)));
        TextView h=Ui.text(this,"VOLTAR sai do jogo",8,Ui.GREEN,true);bar.addView(h,new LinearLayout.LayoutParams(-1,Ui.dp(this,20)));
        FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(-1,Ui.dp(this,56),Gravity.TOP);
        root.addView(bar,bp);

        web.requestFocus();
        return root;
    }

    private String jsKey(String key,boolean down){
        String type=down?"keydown":"keyup";
        return "(function(){var e=new KeyboardEvent('"+type+"',{key:'"+key+"',code:'"+key+"',bubbles:true});document.dispatchEvent(e);if(document.activeElement)document.activeElement.dispatchEvent(e);})();";
    }

    private boolean send(String key,boolean down){
        if(web==null)return false;
        web.evaluateJavascript(jsKey(key,down),null);
        return true;
    }

    @Override public boolean onKeyDown(int keyCode,KeyEvent event){
        switch(keyCode){
            case KeyEvent.KEYCODE_DPAD_UP:return send("ArrowUp",true);
            case KeyEvent.KEYCODE_DPAD_DOWN:return send("ArrowDown",true);
            case KeyEvent.KEYCODE_DPAD_LEFT:return send("ArrowLeft",true);
            case KeyEvent.KEYCODE_DPAD_RIGHT:return send("ArrowRight",true);
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_BUTTON_A:
                send("Enter",true);send(" ",true);return true;
            case KeyEvent.KEYCODE_BACK:finish();return true;
        }
        return super.onKeyDown(keyCode,event);
    }

    @Override public boolean onKeyUp(int keyCode,KeyEvent event){
        switch(keyCode){
            case KeyEvent.KEYCODE_DPAD_UP:return send("ArrowUp",false);
            case KeyEvent.KEYCODE_DPAD_DOWN:return send("ArrowDown",false);
            case KeyEvent.KEYCODE_DPAD_LEFT:return send("ArrowLeft",false);
            case KeyEvent.KEYCODE_DPAD_RIGHT:return send("ArrowRight",false);
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_BUTTON_A:
                send("Enter",false);send(" ",false);return true;
        }
        return super.onKeyUp(keyCode,event);
    }

    @Override protected void onResume(){super.onResume();Ui.immersive(this);if(web!=null)web.onResume();}
    @Override protected void onPause(){if(web!=null)web.onPause();super.onPause();}
    @Override protected void onDestroy(){if(web!=null){web.stopLoading();web.destroy();web=null;}super.onDestroy();}
}
