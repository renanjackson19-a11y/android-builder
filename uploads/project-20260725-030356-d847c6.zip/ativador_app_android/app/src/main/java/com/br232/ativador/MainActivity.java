package com.br232.ativador;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputFilter;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.core.content.FileProvider;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

public class MainActivity extends Activity {
    private EditText inputLicenca;
    private TextView status;
    private ProgressBar progress;
    private Button btnAtivar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        montarTela();
    }

    private void montarTela() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(36, 48, 36, 36);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        scroll.addView(root);

        TextView titulo = new TextView(this);
        titulo.setText("Ativador BR232");
        titulo.setTextSize(28);
        titulo.setGravity(Gravity.CENTER);
        titulo.setPadding(0, 0, 0, 16);
        root.addView(titulo, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitulo = new TextView(this);
        subtitulo.setText("Digite sua licença de 11 dígitos para ativar.");
        subtitulo.setTextSize(16);
        subtitulo.setGravity(Gravity.CENTER);
        subtitulo.setPadding(0, 0, 0, 24);
        root.addView(subtitulo, new LinearLayout.LayoutParams(-1, -2));

        inputLicenca = new EditText(this);
        inputLicenca.setHint("Licença de 11 dígitos");
        inputLicenca.setTextSize(20);
        inputLicenca.setGravity(Gravity.CENTER);
        inputLicenca.setSingleLine(true);
        inputLicenca.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        inputLicenca.setFilters(new InputFilter[]{new InputFilter.LengthFilter(11)});
        root.addView(inputLicenca, new LinearLayout.LayoutParams(-1, -2));

        btnAtivar = new Button(this);
        btnAtivar.setText("ATIVAR");
        btnAtivar.setTextSize(18);
        LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(-1, -2);
        btnParams.setMargins(0, 24, 0, 12);
        root.addView(btnAtivar, btnParams);

        progress = new ProgressBar(this);
        progress.setVisibility(View.GONE);
        root.addView(progress, new LinearLayout.LayoutParams(-2, -2));

        status = new TextView(this);
        status.setText("Aguardando licença...");
        status.setTextSize(15);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, 20, 0, 0);
        root.addView(status, new LinearLayout.LayoutParams(-1, -2));

        btnAtivar.setOnClickListener(v -> confirmarAtivacao());
        setContentView(scroll);
    }

    private void confirmarAtivacao() {
        String licenca = inputLicenca.getText().toString().trim();
        if (!licenca.matches("\\d{11}")) {
            mensagem("Licença inválida", "Digite exatamente 11 números.");
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Confirmar ativação")
                .setMessage("Deseja ativar esta licença neste aparelho? Depois de ativada, ela poderá ficar vinculada a este dispositivo.")
                .setPositiveButton("Ativar", (d, w) -> ativar(licenca))
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void ativar(String licenca) {
        btnAtivar.setEnabled(false);
        progress.setVisibility(View.VISIBLE);
        status.setText("Consultando painel...");

        new Thread(() -> {
            try {
                String resposta = postAtivacao(licenca);
                JSONObject json = new JSONObject(resposta);
                String st = json.optString("status", "erro");
                String msg = json.optString("mensagem", "Resposta recebida.");

                if (!"ok".equalsIgnoreCase(st)) {
                    runOnUiThread(() -> erro(msg));
                    return;
                }

                String configUrl = json.optString("config_url", "");
                String apkUrl = json.optString("apk_url", "");
                String configNome = json.optString("config_filename", Config.CONFIG_PADRAO);

                if (!configUrl.isEmpty()) {
                    runOnUiThread(() -> status.setText("Baixando config..."));
                    File configFile = baixar(configUrl, configNome, Config.PASTA_CONFIG);
                    runOnUiThread(() -> status.setText("Config salva: " + configFile.getAbsolutePath()));
                }

                File apkFile = null;
                if (!apkUrl.isEmpty()) {
                    runOnUiThread(() -> status.setText("Baixando aplicativo..."));
                    apkFile = baixar(apkUrl, "aplicativo_principal.apk", "Apps");
                }

                File finalApkFile = apkFile;
                runOnUiThread(() -> {
                    progress.setVisibility(View.GONE);
                    btnAtivar.setEnabled(true);
                    status.setText("Licença ativada com sucesso.");
                    if (finalApkFile != null) abrirInstalador(finalApkFile);
                    else mensagem("Sucesso", "Licença ativada e config baixada com sucesso.");
                });
            } catch (Exception e) {
                runOnUiThread(() -> erro("Erro: " + e.getMessage()));
            }
        }).start();
    }

    private String postAtivacao(String licenca) throws Exception {
        String deviceId = getDeviceId();
        String params = "licenca=" + enc(licenca)
                + "&device_id=" + enc(deviceId)
                + "&modelo=" + enc(Build.MODEL)
                + "&fabricante=" + enc(Build.MANUFACTURER)
                + "&android=" + enc(Build.VERSION.RELEASE);

        URL url = new URL(Config.API_ATIVAR);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(20000);
        conn.setReadTimeout(30000);
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");

        try (OutputStream os = conn.getOutputStream()) {
            os.write(params.getBytes(StandardCharsets.UTF_8));
        }

        int code = conn.getResponseCode();
        BufferedInputStream in = new BufferedInputStream(code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream());
        byte[] data = readAll(in);
        return new String(data, StandardCharsets.UTF_8);
    }

    private File baixar(String link, String nomeArquivo, String pasta) throws Exception {
        File dir = new File(getExternalFilesDir(null), pasta);
        if (!dir.exists() && !dir.mkdirs()) throw new Exception("Não foi possível criar pasta: " + pasta);
        File outFile = new File(dir, nomeArquivo.replaceAll("[^a-zA-Z0-9._-]", "_"));

        HttpURLConnection conn = (HttpURLConnection) new URL(link).openConnection();
        conn.setConnectTimeout(20000);
        conn.setReadTimeout(60000);
        conn.connect();
        if (conn.getResponseCode() < 200 || conn.getResponseCode() >= 300) {
            throw new Exception("Falha no download: HTTP " + conn.getResponseCode());
        }

        try (BufferedInputStream in = new BufferedInputStream(conn.getInputStream());
             BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(outFile))) {
            byte[] buffer = new byte[8192];
            int read;
            while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
        }
        return outFile;
    }

    private void abrirInstalador(File apkFile) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !getPackageManager().canRequestPackageInstalls()) {
                mensagem("Permissão necessária", "Ative a permissão para instalar apps desconhecidos e tente novamente.");
                startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName())));
                return;
            }
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".provider", apkFile);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, "application/vnd.android.package-archive");
            intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            mensagem("APK baixado", "O APK foi baixado, mas não foi possível abrir o instalador automaticamente.");
        } catch (Exception e) {
            mensagem("Erro ao instalar", e.getMessage());
        }
    }

    private String getDeviceId() {
        String saved = getPreferences(MODE_PRIVATE).getString("device_id", null);
        if (saved != null) return saved;
        String id = UUID.randomUUID().toString();
        getPreferences(MODE_PRIVATE).edit().putString("device_id", id).apply();
        return id;
    }

    private String enc(String s) throws Exception { return URLEncoder.encode(s == null ? "" : s, "UTF-8"); }

    private byte[] readAll(BufferedInputStream in) throws Exception {
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        return out.toByteArray();
    }

    private void erro(String msg) {
        progress.setVisibility(View.GONE);
        btnAtivar.setEnabled(true);
        status.setText(msg);
        mensagem("Aviso", msg);
    }

    private void mensagem(String titulo, String msg) {
        new AlertDialog.Builder(this).setTitle(titulo).setMessage(msg).setPositiveButton("OK", null).show();
    }
}
