package com.br232.ativador;

public class Config {
    // Troque pelo endpoint do seu painel quando a API estiver pronta.
    // O app envia POST: licenca, device_id, modelo, fabricante, android
    public static final String API_ATIVAR = "https://unitvativador.br232.shop/api/ativar.php";

    // Pasta onde o app salva os arquivos baixados dentro do Android/TV Box.
    // Caminho usado: Android/data/com.br232.ativador/files/UnitvConfigs/
    public static final String PASTA_CONFIG = "UnitvConfigs";

    // Nome padrão caso a API não envie config_filename.
    public static final String CONFIG_PADRAO = "licenca.config.xml";
}
