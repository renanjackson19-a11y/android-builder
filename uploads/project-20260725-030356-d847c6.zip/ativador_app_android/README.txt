ATIVADOR BR232 - PROJETO ANDROID

O que este app faz:
1. Cliente digita uma licença de 11 dígitos.
2. O app envia a licença para o painel PHP.
3. O painel deve responder em JSON com config_url e, opcionalmente, apk_url.
4. O app baixa a config.
5. Se vier apk_url, o app baixa o APK e abre a tela de instalação.

Arquivo principal para configurar:
app/src/main/java/com/br232/ativador/Config.java

Altere a linha:
public static final String API_ATIVAR = "https://unitvativador.br232.shop/api/ativar.php";

Resposta esperada da API:
{
  "status": "ok",
  "mensagem": "Licença liberada",
  "config_url": "https://seudominio.com/configs/arquivo.config.xml",
  "config_filename": "arquivo.config.xml",
  "apk_url": "https://seudominio.com/apps/aplicativo.apk"
}

Resposta de erro:
{
  "status": "erro",
  "mensagem": "Licença inválida ou já usada"
}

Como gerar APK:
1. Abra a pasta no Android Studio.
2. Aguarde sincronizar o Gradle.
3. Clique em Build > Build Bundle(s) / APK(s) > Build APK(s).
4. O APK será gerado na pasta app/build/outputs/apk/debug/.

Observação importante:
O Android normalmente não permite instalar outro app totalmente em silêncio.
O ativador baixa o APK e abre a tela para o cliente confirmar a instalação.
