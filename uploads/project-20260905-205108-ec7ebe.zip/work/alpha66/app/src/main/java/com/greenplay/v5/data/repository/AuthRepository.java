package com.greenplay.v5.data.repository;

import android.content.Context;
import android.os.Build;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.greenplay.v5.core.config.BrandingStore;
import com.greenplay.v5.core.config.ServerDirectoryStore;
import com.greenplay.v5.core.network.HostNormalizer;
import com.greenplay.v5.core.network.NetworkProvider;
import com.greenplay.v5.core.session.SessionStore;
import com.greenplay.v5.data.model.AppConfigResponse;
import com.greenplay.v5.data.model.LoginResponse;
import com.greenplay.v5.data.model.DeviceResponse;
import java.text.SimpleDateFormat;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.net.NetworkInterface;
import java.util.Collections;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/** Login universal: painel do app entrega DNS; usuário/senha são validados direto no Xtream. */
public final class AuthRepository {
    public interface Result {
        void success(LoginResponse login);
        void error(String message);
        default void accountEnded(String message) { error(message); }
    }

    private static final class AttemptState {
        boolean sawExpired;
        boolean sawInactive;
        boolean sawRejected;
        boolean sawNetworkFailure;
        String terminalMessage = "";
    }

    private final Context context;
    private final SessionStore session;
    private final ServerDirectoryStore directory;

    // V5.0.118: qualquer trabalho local que possa tocar disco/rede do sistema
    // fica fora da main thread. Em alguns Android/TV Box, consultar as interfaces
    // de rede para descobrir o MAC pode bloquear o Binder/netd por vários segundos
    // e causar o ANR durante "Validando servidor atual...".
    private static final ExecutorService AUTH_IO = Executors.newSingleThreadExecutor();

    public AuthRepository(Context context) {
        this.context = context.getApplicationContext();
        this.session = new SessionStore(this.context);
        this.directory = new ServerDirectoryStore(this.context);
    }

    public void login(String user, String pass, String deviceId, Result result) {
        // Retrofit continua assíncrono. O tratamento da configuração/cache também
        // é deslocado para AUTH_IO para a Activity nunca ficar presa na validação.
        NetworkProvider.panel().appConfig().enqueue(new Callback<AppConfigResponse>() {
            @Override public void onResponse(Call<AppConfigResponse> call, Response<AppConfigResponse> response) {
                AUTH_IO.execute(() -> {
                    AppConfigResponse cfg = response.body();
                    List<AppConfigResponse.Server> servers = new ArrayList<>();
                    if (response.isSuccessful() && cfg != null && cfg.ok) {
                        if (cfg.branding != null) new BrandingStore(context).save(cfg.branding);
                        if (cfg.universal != null && cfg.universal.servers != null) {
                            servers.addAll(cfg.universal.servers);
                            directory.save(servers);
                        }
                    }
                    if (servers.isEmpty()) servers.addAll(directory.load());
                    tryServers(servers, 0, user, pass, deviceId, new AttemptState(), result);
                });
            }

            @Override public void onFailure(Call<AppConfigResponse> call, Throwable t) {
                AUTH_IO.execute(() -> tryServers(directory.load(), 0, user, pass, deviceId, new AttemptState(), result));
            }
        });
    }

    private void tryServers(List<AppConfigResponse.Server> servers, int index, String user, String pass, String deviceId, AttemptState state, Result result) {
        if (servers == null || servers.isEmpty()) {
            result.error("Nenhum servidor IPTV ativo no painel do aplicativo");
            return;
        }
        if (index >= servers.size()) {
            if (state.sawExpired || state.sawInactive) {
                String message = state.terminalMessage == null || state.terminalMessage.trim().isEmpty()
                        ? "Sua lista venceu. Entre com outra conta."
                        : state.terminalMessage;
                result.accountEnded(message);
                return;
            }
            if (state.sawRejected) {
                result.error("Usuário ou senha inválidos nos servidores disponíveis");
                return;
            }
            if (state.sawNetworkFailure) {
                result.error("Não foi possível validar sua conta agora. Verifique a internet ou o servidor e tente novamente.");
                return;
            }
            result.error("Usuário ou senha inválidos nos servidores disponíveis");
            return;
        }
        AppConfigResponse.Server server = servers.get(index);
        if (server == null || server.host == null || server.host.trim().isEmpty() || (server.type != null && !server.type.isEmpty() && !"xtream".equalsIgnoreCase(server.type))) {
            tryServers(servers, index + 1, user, pass, deviceId, state, result);
            return;
        }
        String host = HostNormalizer.normalize(server.host);
        NetworkProvider.xtream(host).authenticate(user, pass).enqueue(new Callback<JsonObject>() {
            @Override public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (!response.isSuccessful()) {
                    if (response.code() == 401 || response.code() == 403) state.sawRejected = true;
                    else state.sawNetworkFailure = true;
                    tryServers(servers, index + 1, user, pass, deviceId, state, result);
                    return;
                }
                if (response.body() == null) {
                    state.sawNetworkFailure = true;
                    tryServers(servers, index + 1, user, pass, deviceId, state, result);
                    return;
                }

                JsonObject root = response.body();
                JsonObject ui = object(root, "user_info");
                String terminal = terminalAccountMessage(ui);
                if (!terminal.isEmpty()) {
                    String normalized = normalize(str(ui, "status"));
                    boolean expiredNow = isExpiredStatus(normalized) || expiredByDate(ui);
                    if (expiredNow) {
                        state.sawExpired = true;
                        state.terminalMessage = terminal;
                    } else {
                        state.sawInactive = true;
                        if (!state.sawExpired && state.terminalMessage.isEmpty()) state.terminalMessage = terminal;
                    }
                    // A mesma combinação de usuário/senha pode existir em outro DNS.
                    // Só encerra como vencida se nenhum servidor ativo aceitar a conta.
                    tryServers(servers, index + 1, user, pass, deviceId, state, result);
                    return;
                }

                if (!isAuthorized(root)) {
                    state.sawRejected = true;
                    tryServers(servers, index + 1, user, pass, deviceId, state, result);
                    return;
                }

                LoginResponse out = new LoginResponse();
                out.ok = true;
                out.username = first(str(ui, "username"), user);
                out.xtreamPassword = pass;
                out.xtreamHost = host;
                out.expiresAt = expiry(str(ui, "exp_date"));
                out.plan = first(str(ui, "status"), "Active");
                out.maxConnections = intVal(ui, "max_connections");
                // Compatible panels publish adult_access explicitly. Generic Xtream
                // servers usually omit it, so absence means "unknown/allowed locally"
                // rather than silently disabling the HOT section.
                out.adultAccess = !ui.has("adult_access") || boolVal(ui, "adult_access");
                out.adultPin = str(ui, "adult_pin");
                out.userToken = "";
                registerDeviceAndFinish(deviceId, out.username, pass, host, out, result);
            }

            @Override public void onFailure(Call<JsonObject> call, Throwable t) {
                state.sawNetworkFailure = true;
                tryServers(servers, index + 1, user, pass, deviceId, state, result);
            }
        });
    }


    private void registerDeviceAndFinish(String deviceId, String user, String pass, String host, LoginResponse out, Result result) {
        String id = deviceId == null ? "" : deviceId.trim();
        if (id.isEmpty()) {
            session.save(host, out.username, pass, out.expiresAt, out.plan, out.adultAccess, "");
            result.success(out);
            return;
        }

        // IMPORTANTE: resolveMac() consulta NetworkInterface/netd. Nunca executar
        // isso no callback principal do Retrofit. O Android pode ficar sem responder
        // justamente na tela "Validando servidor atual...".
        AUTH_IO.execute(() -> {
            final String mac = resolveMac();
            NetworkProvider.panel().registerDevice(
                    id,
                    mac,
                    user,
                    pass,
                    host,
                    Build.MANUFACTURER == null ? "" : Build.MANUFACTURER,
                    Build.MODEL == null ? "" : Build.MODEL,
                    Build.VERSION.RELEASE == null ? "" : Build.VERSION.RELEASE,
                    com.greenplay.v5.BuildConfig.VERSION_NAME
            ).enqueue(new Callback<DeviceResponse>() {
                @Override public void onResponse(Call<DeviceResponse> call, Response<DeviceResponse> response) {
                    DeviceResponse d = response.body();
                    if (response.isSuccessful() && d != null && (d.blocked || !d.allowed)) {
                        session.clear();
                        result.error(d.message == null || d.message.trim().isEmpty() ? "Este aparelho foi bloqueado no painel" : d.message);
                        return;
                    }
                    session.save(host, out.username, pass, out.expiresAt, out.plan, out.adultAccess, "");
                    result.success(out);
                }
                @Override public void onFailure(Call<DeviceResponse> call, Throwable t) {
                    // O painel de controle não deve impedir uma autenticação IPTV válida se estiver momentaneamente offline.
                    session.save(host, out.username, pass, out.expiresAt, out.plan, out.adultAccess, "");
                    result.success(out);
                }
            });
        });
    }

    private static String resolveMac() {
        try {
            for (NetworkInterface nif : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                byte[] mac = nif.getHardwareAddress();
                if (mac == null || mac.length == 0) continue;
                String name = nif.getName() == null ? "" : nif.getName().toLowerCase(Locale.ROOT);
                if (!(name.startsWith("wlan") || name.startsWith("eth") || name.startsWith("en"))) continue;
                StringBuilder out = new StringBuilder();
                for (byte b : mac) {
                    if (out.length() > 0) out.append(':');
                    out.append(String.format(Locale.US, "%02X", b));
                }
                String value = out.toString();
                if (!value.isEmpty() && !"02:00:00:00:00:00".equals(value)) return value;
            }
        } catch (Exception ignored) { }
        return "";
    }

    private static boolean isAuthorized(JsonObject root) {
        JsonObject ui = object(root, "user_info");
        if (!terminalAccountMessage(ui).isEmpty()) return false;
        String auth = str(ui, "auth");
        String status = str(ui, "status");
        return "1".equals(auth) || "true".equalsIgnoreCase(auth) || "active".equalsIgnoreCase(status);
    }

    private static String terminalAccountMessage(JsonObject ui) {
        String status = normalize(str(ui, "status"));
        if (expiredByDate(ui) || isExpiredStatus(status)) {
            return "Sua lista venceu. Entre com outra conta.";
        }
        if (containsAny(status, "disabled", "desativado", "inactive", "inativo")) {
            return "Sua conta está desativada. Entre com outra conta.";
        }
        if (containsAny(status, "banned", "banido", "blocked", "bloqueado")) {
            return "Sua conta está bloqueada. Entre com outra conta.";
        }
        return "";
    }

    private static boolean expiredByDate(JsonObject ui) {
        String raw = str(ui, "exp_date");
        if (raw.isEmpty() || "null".equalsIgnoreCase(raw)) return false;
        try {
            long sec = Long.parseLong(raw);
            return sec > 0 && sec <= (System.currentTimeMillis() / 1000L);
        } catch (Exception ignored) {
            return false;
        }
    }

    private static boolean isExpiredStatus(String normalizedStatus) {
        return containsAny(normalizedStatus, "expired", "expirado", "expirada", "vencido", "vencida");
    }

    private static boolean containsAny(String value, String... terms) {
        String v = value == null ? "" : value;
        for (String term : terms) if (v.contains(term)) return true;
        return false;
    }

    private static String normalize(String value) {
        if (value == null) return "";
        try {
            return Normalizer.normalize(value, Normalizer.Form.NFD)
                    .replaceAll("\\p{M}+", "")
                    .trim()
                    .toLowerCase(Locale.ROOT);
        } catch (Exception e) {
            return value.trim().toLowerCase(Locale.ROOT);
        }
    }

    private static JsonObject object(JsonObject root, String key) {
        try { JsonElement e = root.get(key); return e != null && e.isJsonObject() ? e.getAsJsonObject() : new JsonObject(); }
        catch (Exception e) { return new JsonObject(); }
    }
    private static String str(JsonObject o, String key) {
        try { JsonElement e = o.get(key); return e == null || e.isJsonNull() ? "" : e.getAsString().trim(); }
        catch (Exception e) { return ""; }
    }
    private static int intVal(JsonObject o, String key) { try { return Integer.parseInt(str(o,key)); } catch(Exception e){ return 0; } }
    private static boolean boolVal(JsonObject o, String key) {
        String v = str(o, key);
        return "1".equals(v) || "true".equalsIgnoreCase(v) || "yes".equalsIgnoreCase(v) || "sim".equalsIgnoreCase(v);
    }
    private static String first(String a, String b) { return a != null && !a.trim().isEmpty() ? a.trim() : (b == null ? "" : b.trim()); }
    private static String expiry(String unix) {
        try {
            long sec = Long.parseLong(unix);
            if (sec <= 0) return "";
            return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date(sec * 1000L));
        } catch (Exception e) { return unix == null ? "" : unix; }
    }
}
