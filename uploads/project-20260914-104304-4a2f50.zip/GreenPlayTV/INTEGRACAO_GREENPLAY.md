# Integração usada

API GreenPlay v24:
- GET home?limit=24
- GET details?type=movie|series&id=ID
- GET play?type=movie&id=ID
- GET play?type=series&id=ID&episode=INDICE

Header enviado automaticamente:
`X-GreenPlay-Key`.

O aplicativo não consulta diretamente o provedor IPTV para montar o catálogo. O painel GreenPlay continua sendo a fonte de dados.
