package com.greenplay.tv.api

import com.greenplay.tv.BuildConfig
import com.greenplay.tv.model.*
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.http.GET
import retrofit2.http.Query
import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import okhttp3.MediaType.Companion.toMediaType

interface GreenPlayApi {
    @GET("home") suspend fun home(@Query("limit") limit:Int=20): HomeResponse
    @GET("details") suspend fun details(@Query("type") type:String, @Query("id") id:String): DetailResponse
    @GET("play") suspend fun play(@Query("type") type:String, @Query("id") id:String, @Query("episode") episode:Int?=null): PlayResponse
    @GET("search") suspend fun search(@Query("q") q:String): SearchResponse
}

object ApiClient {
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }
    private val client = OkHttpClient.Builder().addInterceptor { chain ->
        val req = chain.request().newBuilder().header("X-GreenPlay-Key", BuildConfig.GREENPLAY_API_KEY).build()
        chain.proceed(req)
    }.build()
    val api: GreenPlayApi = Retrofit.Builder()
        .baseUrl(BuildConfig.GREENPLAY_BASE_URL)
        .client(client)
        .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
        .build().create(GreenPlayApi::class.java)
}
