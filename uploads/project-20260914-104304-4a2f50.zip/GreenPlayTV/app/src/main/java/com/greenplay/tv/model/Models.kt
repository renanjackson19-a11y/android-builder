package com.greenplay.tv.model

import kotlinx.serialization.Serializable

@Serializable data class CatalogItem(
    val id: String = "", val type: String = "movie", val title: String = "",
    val poster: String = "", val year: String = "", val category_id: String = "",
    val rating: String = "", val container_extension: String = ""
)
@Serializable data class HomeSection(val id:String="", val type:String="movie", val title:String="", val category_id:String="", val items:List<CatalogItem> = emptyList())
@Serializable data class HomeResponse(val status:String="", val app:String="", val version:Int=1, val sections:List<HomeSection> = emptyList())
@Serializable data class DetailResponse(val status:String="", val item:DetailItem?=null, val message:String?=null)
@Serializable data class DetailItem(
    val id:String="", val type:String="movie", val title:String="", val poster:String="", val backdrop:String="",
    val plot:String="", val year:String="", val duration:String="", val rating:String="", val genre:String="",
    val container_extension:String="", val seasons:List<Season> = emptyList()
)
@Serializable data class Season(val season:Int=0, val episodes:List<Episode> = emptyList())
@Serializable data class Episode(val id:String="", val episode_num:Int=0, val title:String="", val container_extension:String="mp4")
@Serializable data class PlayResponse(val status:String="", val type:String="", val id:String="", val player_url:String="", val container_extension:String="", val message:String?=null)
@Serializable data class SearchResponse(val status:String="", val query:String="", val items:List<CatalogItem> = emptyList())
