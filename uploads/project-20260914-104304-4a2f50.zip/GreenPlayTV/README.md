# GreenPlay TV

Aplicativo Android TV inicial para o painel GreenPlay v24.

## O que já está ligado
- Home em fileiras estilo Netflix/NuvioTV.
- Catálogo vindo de `/api/v1/home`.
- Tela de detalhes de filmes e séries.
- Reprodução nativa com Media3/ExoPlayer usando `/api/v1/play`.
- Navegação adequada a Android TV/TV Box.
- Identidade GreenPlay.

## Configuração
A URL e a chave da API estão em `app/build.gradle.kts`, campos `GREENPLAY_BASE_URL` e `GREENPLAY_API_KEY`.
O padrão já aponta para `https://greenplay.fun/api/v1/` e para a chave criada na v24.

## Compilar
Abra a pasta no Android Studio (JDK 17+) e use **Build > Build APK(s)**.
Ou, com Android SDK/Gradle disponíveis:

`./gradlew :app:assembleDebug`

## Próximas telas
Busca, Minha Lista, histórico/continuar assistindo, perfis e login podem ser ligados aos endpoints do painel em versões seguintes.

## Segurança
Uma chave estática dentro de APK pode ser extraída. Para distribuição pública, substitua depois por autenticação de usuário/token de sessão e rotacione a chave da API.
