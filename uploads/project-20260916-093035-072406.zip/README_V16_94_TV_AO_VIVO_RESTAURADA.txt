GreenPlay Android v16.94

- Base direta: v16.93.
- Corrigida a regra da TV ao vivo: o menu TV depende somente da existência real de canais no provedor.
- O benefício do plano não remove mais o menu TV por engano.
- Se o plano não incluir TV ao vivo, o acesso é bloqueado somente ao tentar reproduzir um canal.
- Mantidas navegação, layout dos servidores, pagamento, TMDB, logo, banco e configurações existentes.
