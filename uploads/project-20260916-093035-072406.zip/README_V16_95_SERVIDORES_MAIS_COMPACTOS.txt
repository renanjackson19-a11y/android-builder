GreenPlay Android v16.95

- Base direta: v16.94.
- Tela de seleção de servidores subida levemente, mantendo o botão X na posição segura atual.
- Logo, título e lista usam melhor o espaço vertical para comportar mais provedores.
- Cards de servidor ficaram discretamente mais compactos, sem alterar nomes ou capacidades.
- Filmes, Séries e TV ao vivo continuam sendo exibidos conforme a capacidade real de cada provedor.
- Nenhuma alteração em pagamento, painel, TMDB, logo dinâmica, banco ou configurações existentes.
