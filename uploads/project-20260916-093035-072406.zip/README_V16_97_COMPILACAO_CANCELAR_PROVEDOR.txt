GreenPlay Android v16.97

- Base direta: v16.96.
- Corrigido erro de compilação Java da v16.96 nas lambdas dos cards de provedores.
- Ao abrir Trocar de Servidor e cancelar/fechar, volta ao Perfil sem sobrescrever a Home permanente.
- O menu Início continua ligado à Home real e já carregada.
- Capacidades Filmes / Séries / TV ao vivo por provedor preservadas.
- Sem alterações em pagamento, TMDB, logo, banco, painel ou configurações.
