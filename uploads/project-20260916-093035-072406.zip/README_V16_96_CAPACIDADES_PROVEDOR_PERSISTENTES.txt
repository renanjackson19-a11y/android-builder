GreenPlay Android v16.96

- Base direta: v16.95.
- Corrige desaparecimento intermitente do rótulo TV ao vivo na seleção de servidores.
- Capacidades Filmes / Séries / TV ao vivo agora são memorizadas individualmente por provedor após uma resposta válida.
- Falha temporária ou resposta incompleta de get_providers não apaga mais a capacidade já detectada.
- TV ao vivo continua aparecendo somente em provedores que realmente foram identificados com canais.
- Layout, pagamento, TMDB, logo, banco e painel preservados.
