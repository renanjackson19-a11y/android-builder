GreenPlay Android v16.98

- Base direta: v16.97.
- Corrige a aba TV na Home para provedores já confirmados com canais.
- O bootstrap não apaga mais a capacidade de TV quando uma consulta transitória retorna vazia.
- A Home usa a melhor evidência válida do provedor atual para exibir TV.
- TV continua aparecendo somente para provedores confirmados com canais.
- Demais fluxos preservados.
