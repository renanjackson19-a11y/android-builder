GreenPlay Android v16.99

- Base direta: v16.98.
- Corrige TV ao vivo quando o snapshot da Home informa que existe TV, mas vem sem live_categories/live_channels.
- Snapshot vazio não é mais considerado resposta definitiva.
- A tela TV busca categorias e canais diretamente do provedor atual.
- Se o provedor devolver canais sem categorias, mostra "Todos os canais" e exibe a grade.
- Mantidos navegação, pagamento, planos, TMDB, logo, provedores e demais ajustes anteriores.
