GreenPlay Android v16.91

Base: v16.90.
- X da seleção de servidor reposicionado abaixo da barra de status e com área de toque maior.
- Capacidades dos servidores enriquecidas pelo backend: Filmes, Séries e TV ao vivo somente quando a fonte realmente possui canais.
- Bloqueio de teste/plano vencido ocorre antes de abrir opções de reprodução.
- Aviso de acesso vencido ficou mais estreito e centralizado.
- Pagamento, painel, TMDB, logo, catálogo e configurações existentes preservados.
