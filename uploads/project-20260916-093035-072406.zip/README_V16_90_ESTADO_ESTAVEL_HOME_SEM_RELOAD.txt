GreenPlay Android v16.90

- Base direta: v16.89.
- Perfil usa o último access_status validado já no primeiro frame: aviso de teste/plano vencido não pisca nem some enquanto a conta continuar inativa.
- O status é atualizado em segundo plano sem esconder o aviso durante a consulta.
- Botão Início restaura a Home já montada, preservando conteúdo e posição, sem recarregar o catálogo.
- Voltar de Favoritos, Downloads e TV também reutiliza a Home existente.
- Confirmação de saída aparece diretamente centralizada, sem animação lateral do Dialog.
- Pagamento, painel, TMDB, provedores e catálogo permanecem inalterados.
