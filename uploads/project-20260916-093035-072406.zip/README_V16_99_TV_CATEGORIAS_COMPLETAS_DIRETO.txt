GreenPlay Android v16.99

- Base direta: v16.98.
- TV ao vivo volta a exibir todas as categorias do provedor na coluna esquerda.
- Selecionar uma categoria carrega apenas os canais daquela categoria.
- A TV consulta get_category/get_channel diretamente; snapshot da Home não é tratado como catálogo completo da TV.
- Se get_category vier vazio temporariamente, as categorias são reconstruídas a partir dos canais do próprio provedor, mantendo a navegação por categorias.
- Não usa fallback visual de lista única “Todos os canais”.
- Pagamento, perfil, TMDB, logo, provedores e painel não foram alterados.
