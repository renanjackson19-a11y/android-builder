GreenPlay Android v16.93

- Base direta: v16.92.
- Ajuste exclusivamente visual na seleção de servidores.
- O botão X mantém a posição segura atual.
- Logo, título, subtítulo e cartões dos servidores foram elevados para remover o excesso de espaço no topo.
- Capacidades Filmes / Séries / TV ao vivo preservadas; TV ao vivo continua aparecendo somente quando o provedor realmente tem canais.
- Navegação Home da v16.92 preservada.
- Pagamento, painel, TMDB, provedores, banco e configurações não foram alterados.
