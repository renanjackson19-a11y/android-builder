GreenPlay Android v16.89

- Base direta: v16.88.
- Corrigido o espaçamento vertical das telas internas.
- Favoritos, Downloads, Perfil, Planos, Resumo, TV e Detalhes passam a usar exatamente o mesmo recuo estrutural da Home.
- Removido o padding extra que persistia no container e empurrava telas seguintes para baixo.
- Seleção de servidor e detalhes usam o mesmo top padding estrutural do shell principal.
- Nenhuma alteração em pagamento, catálogo, TMDB, provedores, logo ou backend.
