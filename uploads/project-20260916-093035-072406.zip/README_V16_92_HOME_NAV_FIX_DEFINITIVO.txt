GreenPlay Android v16.92

- Base direta: v16.91.
- Corrige de forma estrutural Início e seta Voltar nas telas internas.
- A Home agora possui host permanente e não pode ser sobrescrita por TV/Favoritos/Downloads/Perfil.
- Início restaura a Home já carregada e preserva posição, sem recarregar catálogo.
- A seta superior da TV/Favoritos/Downloads volta para a mesma Home permanente.
- O diálogo Sair só aparece quando a Home real estiver efetivamente visível.
- Mantidos pagamento, painel, TMDB, provedores e catálogo direto da Xtream.
