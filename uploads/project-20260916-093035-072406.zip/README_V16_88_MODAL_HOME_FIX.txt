GreenPlay Android v16.88

- Base direta: v16.87.
- Corrigido aviso de teste/plano vencido: overlay central, largura limitada e visual GreenPlay, sem cortar para a direita.
- Corrigido botão Início: agora reconstrói a Home de forma segura e sempre sai de Perfil/Favoritos/Downloads/Detalhes.
- Back de telas internas também retorna corretamente para a Home.
- Pagamento, painel, catálogo, TMDB, logo e provedores preservados.
