SPOTNET MUSIC ANDROID V56

Base: V55 enviada pelo cliente.

Correção principal:
- Removido o escape Java inválido replace("\/", "/") que fazia a compilação falhar.
- Mantidas as correções de reprodução da V55: redirecionamentos HTTP, timeout, User-Agent, nova tentativa de stream e seleção do áudio.
- versionCode atualizado para 56.

Observação: JSONObject já converte barras escapadas do JSON automaticamente; não é necessário tratar \/ manualmente.
