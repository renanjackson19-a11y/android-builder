package com.ativacao.app;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInstaller;
import android.os.Build;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class AppCommandReceiver extends BroadcastReceiver {
    public static final String ACTION = "online.unitvbrasil.ativadorlauncher.APP_COMMAND_RESULT";

    public static PendingIntent statusIntent(Context c,int commandId,String deviceCode,String token,String ackUrl,String action,String pkg){
        Intent i=new Intent(c,AppCommandReceiver.class);
        i.setAction(ACTION);
        i.putExtra("command_id",commandId);
        i.putExtra("device_code",deviceCode==null?"":deviceCode);
        i.putExtra("token",token==null?"":token);
        i.putExtra("ack_url",ackUrl==null?"":ackUrl);
        i.putExtra("command_action",action==null?"":action);
        i.putExtra("package_name",pkg==null?"":pkg);
        int flags=PendingIntent.FLAG_UPDATE_CURRENT;
        if(Build.VERSION.SDK_INT>=31)flags|=PendingIntent.FLAG_MUTABLE;
        return PendingIntent.getBroadcast(c,20000+(commandId%10000),i,flags);
    }

    @Override public void onReceive(Context context,Intent intent){
        if(intent==null)return;
        int status=intent.getIntExtra(PackageInstaller.EXTRA_STATUS,PackageInstaller.STATUS_FAILURE);
        if(status==PackageInstaller.STATUS_PENDING_USER_ACTION){
            try{
                Intent confirm;
                if(Build.VERSION.SDK_INT>=33)confirm=intent.getParcelableExtra(Intent.EXTRA_INTENT,Intent.class);
                else confirm=(Intent)intent.getParcelableExtra(Intent.EXTRA_INTENT);
                if(confirm!=null){confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);context.startActivity(confirm);return;}
            }catch(Throwable ignored){}
        }
        int id=intent.getIntExtra("command_id",0);
        String code=intent.getStringExtra("device_code");
        String token=intent.getStringExtra("token");
        String ack=intent.getStringExtra("ack_url");
        String msg=intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE);
        boolean ok=status==PackageInstaller.STATUS_SUCCESS;
        if(msg==null)msg=ok?"":"Android não concluiu a operação.";
        clearRunning(context,id);
        try{context.getSharedPreferences("launcher_inventory",Context.MODE_PRIVATE).edit().putLong("sent_at",0L).apply();}catch(Throwable ignored){}
        ackAsync(context,ack,code,id,token,ok,msg);
    }

    public static void clearRunning(Context c,int id){
        try{
            android.content.SharedPreferences p=c.getSharedPreferences("launcher_app_commands",Context.MODE_PRIVATE);
            if(p.getInt("active_id",0)==id)p.edit().remove("active_id").remove("active_at").apply();
        }catch(Throwable ignored){}
    }

    public static void ackAsync(Context c,String ackUrl,String code,int id,String token,boolean ok,String error){
        new Thread(()->{
            HttpURLConnection conn=null;
            try{
                if(ackUrl==null||ackUrl.trim().isEmpty()||id<=0)return;
                String body="device_code="+enc(code)+"&command_id="+id+"&token="+enc(token)+"&ok="+(ok?"1":"0")+"&error="+enc(error);
                conn=(HttpURLConnection)new URL(ackUrl).openConnection();
                conn.setConnectTimeout(15000);conn.setReadTimeout(25000);conn.setRequestMethod("POST");conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");
                try(java.io.OutputStream os=conn.getOutputStream()){os.write(body.getBytes("UTF-8"));}
                InputStream is=conn.getResponseCode()>=400?conn.getErrorStream():conn.getInputStream();
                if(is!=null){BufferedReader br=new BufferedReader(new InputStreamReader(is));while(br.readLine()!=null){}br.close();}
            }catch(Throwable ignored){}finally{if(conn!=null)conn.disconnect();}
        },"app-command-ack").start();
    }

    private static String enc(String s)throws Exception{return URLEncoder.encode(s==null?"":s,"UTF-8");}
}
