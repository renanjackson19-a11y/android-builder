package com.greenplay.v5.core.catalog;

import android.content.Context;
import com.greenplay.v5.data.model.movie.Movie;
import com.greenplay.v5.data.model.movie.MovieCategory;
import com.greenplay.v5.data.model.series.SeriesItem;
import com.greenplay.v5.data.repository.MovieRepository;
import com.greenplay.v5.data.repository.SeriesWarmRepository;
import java.util.ArrayList;
import java.util.List;

/**
 * Non-blocking universal-app warmup. While the user is watching TV, Filmes and
 * Séries are prepared in memory and their artwork starts filling Picasso's disk
 * cache. Nothing here delays TV or login.
 */
public final class CatalogBackgroundPrime {
    private static String activeKey = "";
    private static boolean moviesRunning = false;
    private static boolean seriesRunning = false;

    private CatalogBackgroundPrime() {}

    public static synchronized void start(Context context, String host, String user, String pass) {
        String key = (host == null ? "" : host.trim()) + "|" + (user == null ? "" : user.trim());
        if (!key.equals(activeKey)) {
            activeKey = key;
            moviesRunning = false;
            seriesRunning = false;
        }

        if (CatalogMemory.movies().isEmpty() && !moviesRunning) {
            moviesRunning = true;
            MovieRepository movieRepo = new MovieRepository(host, user, pass);
            if (CatalogMemory.movieCategories().isEmpty()) {
                movieRepo.categories(new MovieRepository.CategoriesResult() {
                    @Override public void success(List<MovieCategory> rows) { CatalogMemory.setMovieCategories(rows); }
                    @Override public void error(String message) { }
                });
            }
            movieRepo.movies("", new MovieRepository.MoviesResult() {
                @Override public void success(List<Movie> rows) {
                    synchronized (CatalogBackgroundPrime.class) { moviesRunning = false; }
                    CatalogMemory.setMovies(rows);
                    ArrayList<String> art = new ArrayList<>();
                    if (rows != null) for (Movie m : rows) if (m != null && m.poster != null && !m.poster.trim().isEmpty()) art.add(m.poster);
                    CatalogCoverWarmer.enqueue(art);
                }
                @Override public void error(String message) {
                    synchronized (CatalogBackgroundPrime.class) { moviesRunning = false; }
                }
            });
        }

        if (CatalogMemory.series().isEmpty() && !seriesRunning) {
            seriesRunning = true;
            SeriesWarmRepository seriesRepo = new SeriesWarmRepository(host, user, pass);
            seriesRepo.series(new SeriesWarmRepository.Result() {
                @Override public void success(List<SeriesItem> rows) {
                    synchronized (CatalogBackgroundPrime.class) { seriesRunning = false; }
                    CatalogMemory.setSeries(rows);
                    ArrayList<String> art = new ArrayList<>();
                    if (rows != null) for (SeriesItem x : rows) if (x != null && x.cover != null && !x.cover.trim().isEmpty()) art.add(x.cover);
                    CatalogCoverWarmer.enqueue(art);
                }
                @Override public void error(String message) {
                    synchronized (CatalogBackgroundPrime.class) { seriesRunning = false; }
                }
            });
        }
    }
}
