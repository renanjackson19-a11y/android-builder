package com.greenplay.tv

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import coil.compose.AsyncImage
import com.greenplay.tv.player.PlayerActivity
import com.greenplay.tv.ui.GreenPlayViewModel
import kotlinx.coroutines.launch

class DetailActivity: ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id=intent.getStringExtra("id")?:return finish()
        val type=intent.getStringExtra("type")?:"movie"
        setContent { MaterialTheme { DetailScreen(type,id) { url, title -> startActivity(Intent(this,PlayerActivity::class.java).putExtra("url",url).putExtra("title",title)) } } }
    }
}

@Composable fun DetailScreen(type:String,id:String, vm:GreenPlayViewModel= viewModel(), play:(String,String)->Unit) {
    val state by vm.detail.collectAsState(); val scope=rememberCoroutineScope()
    LaunchedEffect(type,id){ vm.loadDetails(type,id) }
    Box(Modifier.fillMaxSize().background(Color(0xFF090B0D))) {
        val d=state.item
        if(d!=null) {
            AsyncImage(model=if(d.backdrop.isNotBlank()) d.backdrop else d.poster, contentDescription=d.title, contentScale=ContentScale.Crop, modifier=Modifier.fillMaxSize())
            Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0xEE090B0D),Color(0xAA090B0D),Color.Transparent))))
            Column(Modifier.fillMaxHeight().width(650.dp).padding(start=60.dp,top=70.dp,bottom=48.dp), verticalArrangement=Arrangement.Center) {
                Text(d.title,color=Color.White,fontSize=42.sp,fontWeight=FontWeight.Bold)
                Spacer(Modifier.height(14.dp)); Text(listOf(d.year,d.duration,d.rating).filter{it.isNotBlank()}.joinToString("  •  "),color=Color.LightGray,fontSize=17.sp)
                Spacer(Modifier.height(18.dp)); Text(d.plot.ifBlank{"Sinopse não informada."},color=Color.White,fontSize=18.sp,maxLines=6)
                Spacer(Modifier.height(26.dp))
                if(type=="movie") Button(onClick={ scope.launch { runCatching{vm.getPlay(type,id)}.onSuccess{ if(it.player_url.isNotBlank()) play(it.player_url,d.title) } } }) { Text("▶  Assistir") }
                else {
                    val first=d.seasons.firstOrNull()?.episodes?.firstOrNull()
                    if(first!=null) Button(onClick={ scope.launch { runCatching{vm.getPlay("series",id,0)}.onSuccess{ if(it.player_url.isNotBlank()) play(it.player_url,d.title) } } }) { Text("▶  Assistir S${d.seasons.first().season} E${first.episode_num}") }
                }
            }
        } else if(state.loading) Text("Carregando...",color=Color.White,modifier=Modifier.align(Alignment.Center))
        else Text(state.error?:"Não encontrado",color=Color.White,modifier=Modifier.align(Alignment.Center))
    }
}
