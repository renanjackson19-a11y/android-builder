package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private TextView server;
    private TextView liveCount;
    private TextView movieCount;
    private TextView seriesCount;
    private TextView heroTitle;
    private TextView heroMeta;
    private TextView heroText;
    private ImageView heroImage;
    private TextView heroPlay;
    private LinearLayout featuredRow;
    private ApiClient.Item heroItem;
    private boolean phone;
    private boolean portrait;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        phone = Ui.phone(this);
        portrait = Ui.portrait(this);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        immersive();
        setContentView(build());
        refresh();
    }

    @Override protected void onResume() { super.onResume(); immersive(); }

    private View build() {
        LinearLayout root = Ui.column(this);
        root.setBackgroundColor(Ui.BG);

        if (phone) buildPhoneHeader(root); else buildTvHeader(root);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);

        LinearLayout content = Ui.column(this);
        int side = phone ? 16 : 28;
        content.setPadding(Ui.dp(this,side), Ui.dp(this,phone?16:20), Ui.dp(this,side), Ui.dp(this,28));

        FrameLayout hero = new FrameLayout(this);
        hero.setBackground(Ui.stroke(Ui.PANEL,Ui.BORDER,20,this));
        hero.setClipToOutline(true);
        heroImage = new ImageView(this);
        heroImage.setScaleType(ImageView.ScaleType.CENTER_CROP);
        heroImage.setAlpha(.46f);
        heroImage.setBackgroundColor(Color.rgb(18,26,43));
        hero.addView(heroImage,new FrameLayout.LayoutParams(-1,-1));
        View shade = new View(this);
        shade.setBackground(new ColorDrawable(0x66000000));
        hero.addView(shade,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout heroInfo = Ui.column(this);
        int hp = phone ? 20 : 32;
        heroInfo.setPadding(Ui.dp(this,hp),Ui.dp(this,phone?18:24),Ui.dp(this,hp),Ui.dp(this,20));
        TextView badge = Ui.text(this,"DUBAI PLAY • DESTAQUE",phone?10:12,Color.rgb(197,183,255),true);
        heroInfo.addView(badge,new LinearLayout.LayoutParams(-1,Ui.dp(this,28)));
        heroTitle = Ui.text(this,"Sua TV. Seus filmes. Suas séries.",phone?24:30,Color.WHITE,true);
        heroTitle.setMaxLines(phone?2:1);
        heroInfo.addView(heroTitle,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?62:52)));
        heroMeta = Ui.text(this,"Conteúdo carregado diretamente do seu painel",phone?12:13,Color.rgb(214,220,233),true);
        heroMeta.setMaxLines(1);
        heroInfo.addView(heroMeta,new LinearLayout.LayoutParams(-1,Ui.dp(this,28)));
        heroText = Ui.text(this,"Uma experiência feita para Android TV, TV Box e celular.",phone?12:14,Color.rgb(200,208,223),false);
        heroText.setMaxLines(2);
        heroInfo.addView(heroText,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?48:52)));

        LinearLayout heroActions = new LinearLayout(this);
        heroActions.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
        heroActions.setPadding(0,Ui.dp(this,8),0,0);
        heroPlay = Ui.primaryButton(this,"▶  ASSISTIR");
        heroPlay.setOnClickListener(v->playHero());
        TextView movies = Ui.button(this,"FILMES");
        movies.setOnClickListener(v->open("movie","Filmes"));
        int playW = phone ? 150 : 185;
        int movieW = phone ? 110 : 145;
        heroActions.addView(heroPlay,new LinearLayout.LayoutParams(Ui.dp(this,playW),Ui.dp(this,46)));
        LinearLayout.LayoutParams mvP = new LinearLayout.LayoutParams(Ui.dp(this,movieW),Ui.dp(this,46));
        mvP.leftMargin=Ui.dp(this,8);
        heroActions.addView(movies,mvP);
        heroInfo.addView(heroActions);
        hero.addView(heroInfo,new FrameLayout.LayoutParams(-1,-1));
        content.addView(hero,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?(portrait?250:220):238)));

        if (phone) {
            HorizontalScrollView statsScroll = new HorizontalScrollView(this);
            statsScroll.setHorizontalScrollBarEnabled(false);
            statsScroll.setFillViewport(false);
            LinearLayout stats = new LinearLayout(this);
            stats.setPadding(0,Ui.dp(this,14),0,0);
            liveCount=statCardFixed(stats,"AO VIVO","0",Ui.BLUE,"live");
            movieCount=statCardFixed(stats,"FILMES","0",Ui.PURPLE,"movie");
            seriesCount=statCardFixed(stats,"SÉRIES","0",Ui.GREEN,"series");
            statsScroll.addView(stats);
            content.addView(statsScroll,new LinearLayout.LayoutParams(-1,Ui.dp(this,118)));
        } else {
            LinearLayout stats = new LinearLayout(this);
            stats.setPadding(0,Ui.dp(this,16),0,0);
            liveCount=statCardWeighted(stats,"AO VIVO","0",Ui.BLUE,"live");
            movieCount=statCardWeighted(stats,"FILMES","0",Ui.PURPLE,"movie");
            seriesCount=statCardWeighted(stats,"SÉRIES","0",Ui.GREEN,"series");
            content.addView(stats,new LinearLayout.LayoutParams(-1,Ui.dp(this,112)));
        }

        TextView section = Ui.text(this,"Destaques para você",phone?18:20,Ui.TEXT,true);
        LinearLayout.LayoutParams secP = new LinearLayout.LayoutParams(-1,Ui.dp(this,44));
        secP.topMargin=Ui.dp(this,10);
        content.addView(section,secP);

        HorizontalScrollView h = new HorizontalScrollView(this);
        h.setHorizontalScrollBarEnabled(false);
        featuredRow = new LinearLayout(this);
        featuredRow.setOrientation(LinearLayout.HORIZONTAL);
        h.addView(featuredRow);
        content.addView(h,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?235:215)));

        FrameLayout centered = Ui.centered(this,content,1180);
        scroll.addView(centered,new ScrollView.LayoutParams(-1,-2));
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        return root;
    }

    private void buildPhoneHeader(LinearLayout root){
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(Ui.dp(this,14),Ui.dp(this,8),Ui.dp(this,14),Ui.dp(this,6));
        top.setBackgroundColor(Ui.BG_2);
        TextView logo = Ui.text(this,"▶",15,Color.WHITE,true);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(Ui.gradient(Ui.PURPLE,Ui.BLUE,11,this));
        top.addView(logo,new LinearLayout.LayoutParams(Ui.dp(this,38),Ui.dp(this,38)));
        TextView brand = Ui.text(this,"DUBAI PLAY",18,Ui.TEXT,true);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0,Ui.dp(this,42),1);bp.leftMargin=Ui.dp(this,10);top.addView(brand,bp);
        server=Ui.text(this,"● ...",10,Ui.MUTED,true);server.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);top.addView(server,new LinearLayout.LayoutParams(Ui.dp(this,100),Ui.dp(this,38)));
        TextView settings=Ui.button(this,"⚙");settings.setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class)));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(Ui.dp(this,46),Ui.dp(this,38));sp.leftMargin=Ui.dp(this,6);top.addView(settings,sp);
        root.addView(top,new LinearLayout.LayoutParams(-1,Ui.dp(this,54)));

        HorizontalScrollView navScroll = new HorizontalScrollView(this);
        navScroll.setHorizontalScrollBarEnabled(false);
        navScroll.setBackgroundColor(Ui.BG_2);
        LinearLayout navRow = new LinearLayout(this);
        navRow.setPadding(Ui.dp(this,10),0,Ui.dp(this,10),Ui.dp(this,6));
        TextView home=nav("INÍCIO"), live=nav("AO VIVO"), movie=nav("FILMES"), series=nav("SÉRIES");
        live.setOnClickListener(v->open("live","Canais ao Vivo"));movie.setOnClickListener(v->open("movie","Filmes"));series.setOnClickListener(v->open("series","Séries"));
        for(TextView n:new TextView[]{home,live,movie,series}){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(Ui.dp(this,92),Ui.dp(this,38));p.rightMargin=Ui.dp(this,4);navRow.addView(n,p);}navScroll.addView(navRow);root.addView(navScroll,new LinearLayout.LayoutParams(-1,Ui.dp(this,44)));
        home.requestFocus();
    }

    private void buildTvHeader(LinearLayout root){
        LinearLayout inner = new LinearLayout(this);
        inner.setGravity(Gravity.CENTER_VERTICAL);
        inner.setPadding(Ui.dp(this,18),Ui.dp(this,8),Ui.dp(this,18),Ui.dp(this,8));
        TextView logo = Ui.text(this,"▶",17,Color.WHITE,true);logo.setGravity(Gravity.CENTER);logo.setBackground(Ui.gradient(Ui.PURPLE,Ui.BLUE,12,this));inner.addView(logo,new LinearLayout.LayoutParams(Ui.dp(this,42),Ui.dp(this,42)));
        TextView brand=Ui.text(this,"DUBAI PLAY",21,Ui.TEXT,true);LinearLayout.LayoutParams brandP=new LinearLayout.LayoutParams(Ui.dp(this,190),Ui.dp(this,44));brandP.leftMargin=Ui.dp(this,12);inner.addView(brand,brandP);
        TextView home=nav("INÍCIO"),live=nav("AO VIVO"),movie=nav("FILMES"),series=nav("SÉRIES");live.setOnClickListener(v->open("live","Canais ao Vivo"));movie.setOnClickListener(v->open("movie","Filmes"));series.setOnClickListener(v->open("series","Séries"));
        inner.addView(home,new LinearLayout.LayoutParams(Ui.dp(this,90),Ui.dp(this,40)));inner.addView(live,new LinearLayout.LayoutParams(Ui.dp(this,95),Ui.dp(this,40)));inner.addView(movie,new LinearLayout.LayoutParams(Ui.dp(this,90),Ui.dp(this,40)));inner.addView(series,new LinearLayout.LayoutParams(Ui.dp(this,90),Ui.dp(this,40)));
        View spacer=new View(this);inner.addView(spacer,new LinearLayout.LayoutParams(0,1,1));server=Ui.text(this,"● CONECTANDO",11,Ui.MUTED,true);server.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);inner.addView(server,new LinearLayout.LayoutParams(Ui.dp(this,170),Ui.dp(this,40)));
        TextView settings=Ui.button(this,"⚙");settings.setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class)));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(Ui.dp(this,50),Ui.dp(this,40));sp.leftMargin=Ui.dp(this,8);inner.addView(settings,sp);
        FrameLayout shell=Ui.centered(this,inner,1260);shell.setBackgroundColor(Ui.BG_2);root.addView(shell,new LinearLayout.LayoutParams(-1,Ui.dp(this,60)));home.requestFocus();
    }

    private TextView nav(String label){TextView t=Ui.text(this,label,11,Ui.MUTED,true);t.setGravity(Gravity.CENTER);t.setFocusable(true);t.setClickable(true);Ui.focus(t,this,Ui.round(Color.TRANSPARENT,10,this),Ui.stroke(Ui.PANEL_2,Ui.PURPLE,10,this));return t;}

    private TextView statCardFixed(LinearLayout row,String title,String value,int accent,String type){
        LinearLayout card=makeStat(title,value,accent,type);TextView count=(TextView)card.getChildAt(1);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(Ui.dp(this,155),Ui.dp(this,98));p.rightMargin=Ui.dp(this,10);row.addView(card,p);return count;
    }
    private TextView statCardWeighted(LinearLayout row,String title,String value,int accent,String type){
        LinearLayout card=makeStat(title,value,accent,type);TextView count=(TextView)card.getChildAt(1);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,Ui.dp(this,96),1);p.rightMargin=Ui.dp(this,12);row.addView(card,p);return count;
    }
    private LinearLayout makeStat(String title,String value,int accent,String type){
        LinearLayout card=Ui.column(this);card.setPadding(Ui.dp(this,18),Ui.dp(this,14),Ui.dp(this,18),Ui.dp(this,10));card.setFocusable(true);card.setClickable(true);Ui.focus(card,this);card.setOnClickListener(v->open(type,titleFor(type)));
        TextView t=Ui.text(this,title,11,accent,true);card.addView(t,new LinearLayout.LayoutParams(-1,Ui.dp(this,23)));
        TextView count=Ui.text(this,value,phone?24:27,Ui.TEXT,true);card.addView(count,new LinearLayout.LayoutParams(-1,Ui.dp(this,38)));
        TextView sub=Ui.text(this,"no catálogo",10,Ui.MUTED,false);card.addView(sub,new LinearLayout.LayoutParams(-1,Ui.dp(this,20)));return card;
    }

    private void refresh(){
        ApiClient.status(new ApiClient.Callback<String>(){public void ok(String s){runOnUiThread(()->{server.setText(phone?"● ONLINE":"● SERVIDOR ONLINE");server.setTextColor(Ui.GREEN);});}public void error(String m){runOnUiThread(()->{server.setText(phone?"● OFFLINE":"● SERVIDOR OFFLINE");server.setTextColor(Ui.RED);});}});
        ApiClient.home(new ApiClient.Callback<ApiClient.HomeData>(){public void ok(ApiClient.HomeData h){runOnUiThread(()->applyHome(h));}public void error(String m){runOnUiThread(()->{server.setText("● ERRO");server.setTextColor(Ui.RED);heroTitle.setText("Não foi possível carregar");heroMeta.setText(m);heroText.setText("Confira a conexão do painel e tente novamente.");});}});
    }

    private void applyHome(ApiClient.HomeData h){
        liveCount.setText(String.valueOf(h.liveCount));movieCount.setText(String.valueOf(h.movieCount));seriesCount.setText(String.valueOf(h.seriesCount));heroItem=h.hero;
        if(h.hero!=null){heroTitle.setText(clean(h.hero.name,"Destaque Dubai Play"));String meta=clean(h.hero.group,"Destaque Dubai Play");if(h.hero.year>0)meta+=" • "+h.hero.year;heroMeta.setText(meta);heroText.setText(clean(h.hero.synopsis,"Assista agora no Dubai Play."));String img=clean(h.hero.backdrop,"");if(img.isEmpty())img=clean(h.hero.logo,"");ImageLoader.into(this,heroImage,img);heroPlay.setVisibility(View.VISIBLE);}else{heroTitle.setText("Dubai Play");heroMeta.setText("Seu catálogo está conectado");heroText.setText("Adicione capas e destaques no painel para deixar esta tela ainda mais completa.");heroPlay.setVisibility(View.GONE);}
        List<ApiClient.Item> mix=new ArrayList<>();mix.addAll(h.movies);mix.addAll(h.series);mix.addAll(h.live);renderFeatured(mix);
    }

    private void renderFeatured(List<ApiClient.Item> items){featuredRow.removeAllViews();int max=Math.min(items.size(),18);for(int i=0;i<max;i++){ApiClient.Item item=items.get(i);LinearLayout card=Ui.column(this);card.setFocusable(true);card.setClickable(true);card.setPadding(Ui.dp(this,7),Ui.dp(this,7),Ui.dp(this,7),Ui.dp(this,7));Ui.focus(card,this);ImageView image=new ImageView(this);boolean live="live".equals(item.type);image.setScaleType(live?ImageView.ScaleType.CENTER_INSIDE:ImageView.ScaleType.CENTER_CROP);image.setBackgroundColor(Ui.PANEL_2);int cardW=phone?150:172;int imageH=phone?165:145;card.addView(image,new LinearLayout.LayoutParams(-1,Ui.dp(this,imageH)));TextView n=Ui.text(this,clean(item.name,"Sem nome"),11,Ui.TEXT,true);n.setMaxLines(1);card.addView(n,new LinearLayout.LayoutParams(-1,Ui.dp(this,29)));TextView g=Ui.text(this,clean(item.group,live?"Ao vivo":"Dubai Play"),9,Ui.MUTED,false);g.setMaxLines(1);card.addView(g,new LinearLayout.LayoutParams(-1,Ui.dp(this,20)));ImageLoader.into(this,image,item.logo);card.setOnClickListener(v->openPlayer(item));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(Ui.dp(this,cardW),Ui.dp(this,phone?224:204));p.rightMargin=Ui.dp(this,10);featuredRow.addView(card,p);}}

    private void openPlayer(ApiClient.Item item){
        String t=item.type==null||item.type.isEmpty()?"movie":item.type;
        if("series".equals(t)){
            Intent in=new Intent(this,SeriesActivity.class);
            in.putExtra("title",clean(item.seriesTitle,item.name));
            in.putExtra("name",item.name);
            in.putExtra("logo",item.logo);
            in.putExtra("backdrop",item.backdrop);
            startActivity(in);
            return;
        }
        Intent in=new Intent(this,PlayerActivity.class);
        in.putExtra("id",item.id);in.putExtra("name",item.name);in.putExtra("group",item.group);in.putExtra("type",t);in.putExtra("format",item.format);in.putExtra("synopsis",item.synopsis);startActivity(in);
    }
    private void playHero(){if(heroItem!=null)openPlayer(heroItem);}
    private void open(String type,String title){Intent i=new Intent(this,CatalogActivity.class);i.putExtra("type",type);i.putExtra("title",title);startActivity(i);}
    private String titleFor(String type){if("live".equals(type))return "Canais ao Vivo";if("movie".equals(type))return "Filmes";return "Séries";}
    private String clean(String v,String fallback){if(v==null)return fallback;String s=v.trim();return s.isEmpty()||"null".equalsIgnoreCase(s)?fallback:s;}
    private void immersive(){getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);}
}
