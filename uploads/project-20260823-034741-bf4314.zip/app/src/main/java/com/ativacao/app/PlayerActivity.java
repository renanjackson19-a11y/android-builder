package com.ativacao.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.PlayerView;

public class PlayerActivity extends Activity {
    private PlayerView playerView;
    private ExoPlayer player;
    private ProgressBar loading;
    private TextView epgNow, epgNext, playPause, elapsed, durationText, errorText;
    private SeekBar seek;
    private LinearLayout controls;
    private final Handler handler = new Handler();
    private boolean live, dragging=false;
    private long resumePos=0;
    private int retryCount=0;
    private String format="auto";

    private final Runnable progressTask=new Runnable(){
        @Override public void run(){
            if(player!=null && !live && !dragging){
                long pos=Math.max(0,player.getCurrentPosition()); long dur=player.getDuration();
                if(dur>0 && dur<Integer.MAX_VALUE){seek.setMax((int)dur);seek.setProgress((int)Math.min(pos,dur));elapsed.setText(time(pos));durationText.setText(time(dur));}
            }
            handler.postDelayed(this,750);
        }
    };
    private final Runnable hideTask=()->{if(player!=null&&player.isPlaying()&&controls!=null)controls.setVisibility(View.GONE);};

    @Override public void onCreate(Bundle b){
        super.onCreate(b); immersive();
        if(b!=null)resumePos=b.getLong("pos",0);
        live="live".equals(getIntent().getStringExtra("type"));
        String f=getIntent().getStringExtra("format"); if(f!=null&&!f.trim().isEmpty())format=f;
        setContentView(build()); startPlayer();
    }

    private View build(){
        FrameLayout root=new FrameLayout(this); root.setBackgroundColor(Color.BLACK); root.setFocusable(true); root.setClickable(true);
        playerView=new PlayerView(this); playerView.setUseController(false); playerView.setKeepScreenOn(true); playerView.setBackgroundColor(Color.BLACK); root.addView(playerView,new FrameLayout.LayoutParams(-1,-1));
        loading=new ProgressBar(this); root.addView(loading,new FrameLayout.LayoutParams(Ui.dp(this,42),Ui.dp(this,42),Gravity.CENTER));
        errorText=Ui.text(this,"",12,Color.WHITE,true); errorText.setGravity(Gravity.CENTER); errorText.setPadding(Ui.dp(this,20),Ui.dp(this,12),Ui.dp(this,20),Ui.dp(this,12)); errorText.setBackgroundColor(0xCC1A1118); errorText.setVisibility(View.GONE); FrameLayout.LayoutParams erp=new FrameLayout.LayoutParams(Ui.dp(this,520),Ui.dp(this,70),Gravity.CENTER); root.addView(errorText,erp);

        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setPadding(Ui.dp(this,18),0,Ui.dp(this,18),0); top.setBackgroundColor(0x8F040911);
        TextView name=Ui.text(this,clean(getIntent().getStringExtra("name"),"Dubai Play"),Ui.phone(this)?12:15,Color.WHITE,true); name.setMaxLines(1); top.addView(name,new LinearLayout.LayoutParams(0,Ui.dp(this,48),1));
        TextView brand=Ui.text(this,"DUBAI PLAY",11,Color.rgb(205,193,255),true); brand.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); top.addView(brand,new LinearLayout.LayoutParams(Ui.dp(this,125),Ui.dp(this,48))); root.addView(top,new FrameLayout.LayoutParams(-1,Ui.dp(this,48),Gravity.TOP));

        controls=new LinearLayout(this); controls.setGravity(Gravity.CENTER_VERTICAL); controls.setPadding(Ui.dp(this,12),Ui.dp(this,7),Ui.dp(this,12),Ui.dp(this,7)); controls.setBackground(Ui.stroke(0xE6111825,0x663C4F6C,14,this));
        TextView back=Ui.button(this,"‹"); back.setOnClickListener(v->finish()); controls.addView(back,new LinearLayout.LayoutParams(Ui.dp(this,48),Ui.dp(this,42)));
        if(!live){TextView prev=Ui.button(this,"−10");prev.setOnClickListener(v->seekBy(-10000));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(Ui.dp(this,58),Ui.dp(this,42));p.leftMargin=Ui.dp(this,7);controls.addView(prev,p);}
        playPause=Ui.primaryButton(this,"❚❚"); playPause.setOnClickListener(v->togglePlayback()); LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(Ui.dp(this,64),Ui.dp(this,42)); pp.leftMargin=Ui.dp(this,7); controls.addView(playPause,pp);
        if(!live){TextView next=Ui.button(this,"+10");next.setOnClickListener(v->seekBy(10000));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(Ui.dp(this,58),Ui.dp(this,42));p.leftMargin=Ui.dp(this,7);controls.addView(next,p);}

        if(!live){
            elapsed=Ui.text(this,"00:00",10,Ui.MUTED,true);elapsed.setGravity(Gravity.CENTER);LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(Ui.dp(this,54),Ui.dp(this,42));ep.leftMargin=Ui.dp(this,8);controls.addView(elapsed,ep);
            seek=new SeekBar(this);seek.setFocusable(true);seek.setMax(1);LinearLayout.LayoutParams sk=new LinearLayout.LayoutParams(0,Ui.dp(this,42),1);sk.leftMargin=Ui.dp(this,5);sk.rightMargin=Ui.dp(this,5);controls.addView(seek,sk);
            durationText=Ui.text(this,"00:00",10,Ui.MUTED,true);durationText.setGravity(Gravity.CENTER);controls.addView(durationText,new LinearLayout.LayoutParams(Ui.dp(this,54),Ui.dp(this,42)));
            seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean from){if(from&&elapsed!=null)elapsed.setText(time(p));}public void onStartTrackingTouch(SeekBar s){dragging=true;showControls();}public void onStopTrackingTouch(SeekBar s){dragging=false;if(player!=null)player.seekTo(s.getProgress());scheduleHide();}});
        }else{
            TextView badge=Ui.text(this,"● AO VIVO",11,Ui.GREEN,true);badge.setGravity(Gravity.CENTER);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,Ui.dp(this,42),1);bp.leftMargin=Ui.dp(this,10);controls.addView(badge,bp);
        }
        FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(-1,Ui.dp(this,58),Gravity.BOTTOM);cp.leftMargin=Ui.dp(this,18);cp.rightMargin=Ui.dp(this,18);cp.bottomMargin=Ui.dp(this,live?82:14);root.addView(controls,cp);

        if(live){
            LinearLayout guide=Ui.column(this);guide.setPadding(Ui.dp(this,16),Ui.dp(this,8),Ui.dp(this,16),Ui.dp(this,8));guide.setBackground(Ui.stroke(0xDD091321,0x553C4F6C,14,this));
            epgNow=Ui.text(this,"AGORA  Carregando programação...",11,Color.WHITE,true);epgNext=Ui.text(this,"A SEGUIR  —",10,Ui.MUTED,false);epgNow.setMaxLines(1);epgNext.setMaxLines(1);guide.addView(epgNow,new LinearLayout.LayoutParams(-1,Ui.dp(this,23)));guide.addView(epgNext,new LinearLayout.LayoutParams(-1,Ui.dp(this,21)));
            FrameLayout.LayoutParams gp=new FrameLayout.LayoutParams(-1,Ui.dp(this,56),Gravity.BOTTOM);gp.leftMargin=Ui.dp(this,18);gp.rightMargin=Ui.dp(this,18);gp.bottomMargin=Ui.dp(this,14);root.addView(guide,gp);
        }
        root.setOnClickListener(v->{if(controls.getVisibility()==View.VISIBLE)controls.setVisibility(View.GONE);else showControls();}); showControls(); back.requestFocus(); return root;
    }

    private void startPlayer(){
        long id=getIntent().getLongExtra("id",0); String url=ApiClient.streamUrl(id);
        DefaultHttpDataSource.Factory http=new DefaultHttpDataSource.Factory().setUserAgent("DubaiPlayTV/1.4").setConnectTimeoutMs(7000).setReadTimeoutMs(18000).setAllowCrossProtocolRedirects(true);
        DefaultLoadControl load=new DefaultLoadControl.Builder().setBufferDurationsMs(live?7000:12000,live?28000:45000,live?900:1200,live?1800:2200).build();
        DefaultMediaSourceFactory mediaFactory=new DefaultMediaSourceFactory(this).setDataSourceFactory(http);
        player=new ExoPlayer.Builder(this).setLoadControl(load).setMediaSourceFactory(mediaFactory).build();
        playerView.setPlayer(player);
        player.addListener(new Player.Listener(){
            @Override public void onPlaybackStateChanged(int state){
                if(state==Player.STATE_BUFFERING){loading.setVisibility(View.VISIBLE);}
                else if(state==Player.STATE_READY){loading.setVisibility(View.GONE);errorText.setVisibility(View.GONE);playPause.setText(player.isPlaying()?"❚❚":"▶");if(resumePos>0&&!live&&player.getCurrentPosition()<1000){player.seekTo(resumePos);resumePos=0;}scheduleHide();}
                else if(state==Player.STATE_ENDED){loading.setVisibility(View.GONE);playPause.setText("▶");showControls();}
            }
            @Override public void onIsPlayingChanged(boolean playing){playPause.setText(playing?"❚❚":"▶");if(playing)scheduleHide();else showControls();}
            @Override public void onPlayerError(PlaybackException error){
                loading.setVisibility(View.GONE);
                if(retryCount<1){retryCount++;errorText.setText("Reconectando ao stream...");errorText.setVisibility(View.VISIBLE);handler.postDelayed(()->{if(player!=null){player.prepare();player.play();}},900);}
                else{errorText.setText("Não foi possível abrir este stream.\nCódigo: "+error.getErrorCodeName());errorText.setVisibility(View.VISIBLE);Toast.makeText(PlayerActivity.this,"Falha no player: "+error.getErrorCodeName(),Toast.LENGTH_LONG).show();}
            }
        });
        MediaItem.Builder mb=new MediaItem.Builder().setUri(url);
        if("hls".equalsIgnoreCase(format)||"m3u8".equalsIgnoreCase(format))mb.setMimeType(MimeTypes.APPLICATION_M3U8);
        else if("ts".equalsIgnoreCase(format))mb.setMimeType(MimeTypes.VIDEO_MP2T);
        else if("mp4".equalsIgnoreCase(format))mb.setMimeType(MimeTypes.VIDEO_MP4);
        player.setMediaItem(mb.build()); player.setPlayWhenReady(true); player.prepare(); handler.post(progressTask); if(live)loadEpg(id);
    }

    private void togglePlayback(){if(player==null)return;if(player.isPlaying())player.pause();else player.play();}
    private void seekBy(long delta){if(player==null||live)return;long dur=player.getDuration();long max=dur>0?dur:Long.MAX_VALUE;player.seekTo(Math.max(0,Math.min(max,player.getCurrentPosition()+delta)));showControls();scheduleHide();}
    private void showControls(){handler.removeCallbacks(hideTask);controls.setVisibility(View.VISIBLE);}
    private void scheduleHide(){handler.removeCallbacks(hideTask);handler.postDelayed(hideTask,3500);}

    @Override public boolean onKeyDown(int keyCode,KeyEvent event){
        if(keyCode==KeyEvent.KEYCODE_DPAD_CENTER||keyCode==KeyEvent.KEYCODE_ENTER||keyCode==KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE){togglePlayback();return true;}
        if(!live&&keyCode==KeyEvent.KEYCODE_DPAD_LEFT){seekBy(-10000);return true;}
        if(!live&&keyCode==KeyEvent.KEYCODE_DPAD_RIGHT){seekBy(10000);return true;}
        showControls();return super.onKeyDown(keyCode,event);
    }

    private void loadEpg(long id){ApiClient.epg(id,new ApiClient.Callback<ApiClient.EpgInfo>(){public void ok(ApiClient.EpgInfo i){runOnUiThread(()->{if(epgNow!=null)epgNow.setText(clean(i.nowTitle,"").isEmpty()?"AGORA  Programação não disponível":"AGORA  "+i.nowTitle);if(epgNext!=null)epgNext.setText(clean(i.nextTitle,"").isEmpty()?"A SEGUIR  —":"A SEGUIR  "+i.nextTitle);});}public void error(String m){runOnUiThread(()->{if(epgNow!=null)epgNow.setText("AGORA  Programação não disponível");if(epgNext!=null)epgNext.setText("A SEGUIR  —");});}});}

    @Override protected void onSaveInstanceState(Bundle out){if(player!=null&&!live)out.putLong("pos",player.getCurrentPosition());super.onSaveInstanceState(out);}
    @Override protected void onStop(){handler.removeCallbacksAndMessages(null);if(player!=null){player.release();player=null;}super.onStop();}
    private String clean(String v,String fallback){if(v==null)return fallback;String s=v.trim();return s.isEmpty()||"null".equalsIgnoreCase(s)?fallback:s;}
    private String time(long ms){long sec=Math.max(0,ms/1000),m=sec/60,s=sec%60,h=m/60;m%=60;return h>0?String.format(java.util.Locale.US,"%d:%02d:%02d",h,m,s):String.format(java.util.Locale.US,"%02d:%02d",m,s);}
    private void immersive(){getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);}
}
