# GREEN PLAY V5 — Alpha 15 TV Fullscreen estilo referência V4

Esta versão mantém a base V5 nova e usa o V4 apenas como referência de comportamento visual.

## TV — fullscreen refeito
- O mesmo PlayerView/stream do preview é movido para fullscreen; não recria URL nem dá prepare novamente ao abrir/fechar.
- Fullscreen normal: vídeo + painel inferior fixo com logo, número/nome, AO VIVO, EPG atual/próximo e progresso.
- OK/toque no fullscreen: abre a lista lateral de canais sobre o vídeo, no formato da referência antiga.
- Lista lateral: trilho estreito com busca/recentes/favoritos/todos + lista de canais.
- Selecionar outro canal pela lista lateral troca o canal e volta ao fullscreen normal.
- VOLTAR com lista aberta: fecha somente a lista.
- VOLTAR no fullscreen normal: retorna para a tela principal de TV.
- Mesmo applicationId/assinatura das Alphas anteriores para atualização por cima.

VersionCode: 5015


## Alpha 16 – ajustes TV
- Painel EPG fullscreen na altura proporcional à referência (~25% da tela).
- EPG cacheado aparece imediatamente ao entrar em tela cheia.
- Ao voltar do segundo plano, mantém o mesmo canal mas reconecta no ponto AO VIVO.
- Indicador de consumo/velocidade de rede no canto superior direito em tela cheia.
- Removido RECENTES da barra lateral fullscreen; permanecem busca, favoritos e todos.
