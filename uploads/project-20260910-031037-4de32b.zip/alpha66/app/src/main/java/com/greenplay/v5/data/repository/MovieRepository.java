package com.greenplay.v5.data.repository;

import android.os.Handler;
import android.os.Looper;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.stream.JsonReader;
import com.greenplay.v5.core.network.HostNormalizer;
import com.greenplay.v5.core.network.NetworkProvider;
import com.greenplay.v5.core.network.XtreamApi;
import com.greenplay.v5.data.model.movie.Movie;
import com.greenplay.v5.data.model.movie.MovieCategory;
import com.greenplay.v5.data.model.movie.MovieDetails;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import okhttp3.HttpUrl;
import okhttp3.Request;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Movies use only the public Xtream contract exposed by the current panel.
 * Large catalog normalization is done off the UI thread to avoid ANR.
 */
public final class MovieRepository {
    public interface CategoriesResult { void success(List<MovieCategory> rows); void error(String message); }
    public interface MoviesResult { void success(List<Movie> rows); void error(String message); }
    public interface ProgressiveMoviesResult {
        void partial(List<Movie> rows);
        void success(List<Movie> rows);
        void error(String message);
    }
    public interface DetailResult { void success(MovieDetails detail); void error(String message); }

    private static final ExecutorService PARSER = Executors.newFixedThreadPool(2);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private final XtreamApi api;
    private final XtreamApi detailApi;
    private final String host;
    private final String user;
    private final String pass;
    private final boolean includeAdult;

    public MovieRepository(String host, String user, String pass) {
        this(host, user, pass, false);
    }

    public MovieRepository(String host, String user, String pass, boolean includeAdult) {
        this.host = HostNormalizer.normalize(host);
        this.api = NetworkProvider.xtream(host);
        this.detailApi = NetworkProvider.xtreamDetails(host);
        this.user = user;
        this.pass = pass;
        this.includeAdult = includeAdult;
    }

    public void categories(CategoriesResult result) {
        api.list(user, pass, "get_vod_categories").enqueue(new Callback<JsonArray>() {
            @Override public void onResponse(Call<JsonArray> call, Response<JsonArray> response) {
                final JsonArray body = response.body();
                if (!response.isSuccessful() || body == null) {
                    result.error("Categorias de filmes indisponíveis");
                    return;
                }
                PARSER.execute(() -> {
                    List<MovieCategory> out = new ArrayList<>();
                    out.add(new MovieCategory("", "TODOS"));
                    // V5.0.116: category_id é a identidade real no Xtream.
                    // Dois IDs diferentes podem ter exatamente o mesmo nome. Deduplicar
                    // por nome descartava categorias inteiras e fazia FILMES sumirem de
                    // KIDS/ANIMES/HOT enquanto as séries continuavam aparecendo.
                    Set<String> seenCategoryIds = new HashSet<>();
                    for (JsonElement e : body) {
                        if (!e.isJsonObject()) continue;
                        JsonObject o = e.getAsJsonObject();
                        String id = first(str(o, "category_id"), str(o, "id"), str(o, "cat_id"), str(o, "categoryId")).trim();
                        String name = cleanCategoryName(first(str(o, "category_name"), str(o, "name"), str(o, "title"), str(o, "category")));
                        if (id.isEmpty() || name.isEmpty() || !seenCategoryIds.add(id)) continue;
                        out.add(new MovieCategory(id, name, adultFlag(o)));
                    }
                    MAIN.post(() -> result.success(out));
                });
            }
            @Override public void onFailure(Call<JsonArray> call, Throwable t) {
                result.error("Falha ao carregar categorias de filmes");
            }
        });
    }

    public void movies(String categoryId, MoviesResult result) {
        Call<JsonArray> call = categoryId == null || categoryId.trim().isEmpty()
                ? api.list(user, pass, "get_vod_streams")
                : api.listByCategory(user, pass, "get_vod_streams", categoryId.trim());
        call.enqueue(new Callback<JsonArray>() {
            @Override public void onResponse(Call<JsonArray> c, Response<JsonArray> response) {
                final JsonArray body = response.body();
                if (!response.isSuccessful() || body == null) {
                    result.error("Filmes indisponíveis");
                    return;
                }
                PARSER.execute(() -> {
                    List<Movie> out = new ArrayList<>();
                    java.util.Map<Long,Movie> byId = new java.util.HashMap<>();
                    java.util.Map<String,Movie> posterOwners = new java.util.HashMap<>();
                    java.util.Map<String,Movie> titleOwners = new java.util.HashMap<>();
                    java.util.Map<String,Movie> titleYearOwners = new java.util.HashMap<>();
                    java.util.Map<String,Movie> keyOwners = new java.util.HashMap<>();
                    java.util.Map<String,Set<String>> seenYears = new java.util.HashMap<>();
                    for (JsonElement e : body) {
                        if (!e.isJsonObject()) continue;
                        JsonObject o = e.getAsJsonObject();
                        if (!includeAdult && adultFlag(o)) continue;
                        long id = longVal(o, "stream_id");
                        if (id <= 0) continue;
                        Movie m = new Movie();
                        m.id = id;
                        m.name = cleanMovieName(first(str(o, "name"), str(o, "title"), "Filme"));
                        m.poster = normalizeImage(str(o, "stream_icon"));
                        m.categoryId = str(o, "category_id").trim();
                        m.allCategoryIds = m.categoryId;
                        m.extension = first(str(o, "container_extension"), "mp4");
                        m.year = str(o, "year").trim();
                        m.rating = str(o, "rating").trim();
                        m.contentRating = contentRating(o);
                        m.genre = first(str(o, "genre"), str(o, "genres"));
                        m.plot = first(str(o, "plot"), str(o, "description"));
                        m.originalLanguage = first(str(o, "original_language"), str(o, "originalLanguage"), str(o, "language"));
                        m.country = first(str(o, "country"), str(o, "origin_country"), str(o, "originCountry"));
                        m.directSource = normalizeDirect(str(o, "direct_source"));
                        m.isAdult = adultFlag(o);
                        m.mediaType = first(str(o, "media_type"), str(o, "mediaType"));
                        m.vodType = first(str(o, "vod_type"), str(o, "vodType"));
                        m.filterType = first(str(o, "filter_type"), str(o, "filterType"));

                        Movie duplicate = byId.get(id);
                        if (duplicate != null) {
                            mergeMovieDuplicate(duplicate, m);
                            continue;
                        }

                        String variant = movieVariant(m.name);
                        String canonical = canonicalMovieName(m.name);
                        String titleKey = canonical + "|" + variant;
                        String posterKey = normalizedPoster(m.poster);
                        String posterCompound = posterKey.isEmpty() ? "" : posterKey + "|" + variant;
                        duplicate = posterCompound.isEmpty() ? null : posterOwners.get(posterCompound);
                        if (duplicate != null) {
                            mergeMovieDuplicate(duplicate, m);
                            byId.put(id, duplicate);
                            continue;
                        }

                        String y = m.year == null ? "" : m.year.trim();
                        if ("0".equals(y) || "0000".equals(y)) y = "";
                        if (!canonical.isEmpty()) {
                            Set<String> years = seenYears.computeIfAbsent(titleKey, k -> new HashSet<>());
                            if (y.isEmpty() && !years.isEmpty()) {
                                duplicate = titleOwners.get(titleKey);
                            } else if (!y.isEmpty() && (years.contains(y) || years.contains(""))) {
                                duplicate = titleYearOwners.get(titleKey + "|" + y);
                                if (duplicate == null) duplicate = titleOwners.get(titleKey);
                            }
                            if (duplicate != null) {
                                mergeMovieDuplicate(duplicate, m);
                                byId.put(id, duplicate);
                                continue;
                            }
                        }

                        String key = dedupeMovieKey(m.name, y, m.directSource, m.poster);
                        duplicate = key.isEmpty() ? null : keyOwners.get(key);
                        if (duplicate != null) {
                            mergeMovieDuplicate(duplicate, m);
                            byId.put(id, duplicate);
                            continue;
                        }

                        out.add(m);
                        byId.put(id, m);
                        if (!posterCompound.isEmpty()) posterOwners.put(posterCompound, m);
                        if (!canonical.isEmpty()) {
                            Set<String> years = seenYears.computeIfAbsent(titleKey, k -> new HashSet<>());
                            years.add(y);
                            titleOwners.putIfAbsent(titleKey, m);
                            titleYearOwners.put(titleKey + "|" + y, m);
                        }
                        if (!key.isEmpty()) keyOwners.put(key, m);
                    }
                    MAIN.post(() -> result.success(out));
                });
            }
            @Override public void onFailure(Call<JsonArray> c, Throwable t) {
                result.error("Falha ao carregar filmes");
            }
        });
    }


    /**
     * Reads the Xtream VOD array as a stream. Retrofit/Gson normally waits for
     * the whole (sometimes very large) JSON before returning anything. Here the
     * first accepted rows are emitted while the response is still arriving, so
     * the movie grid can show covers instead of keeping a full-screen spinner.
     */
    public void moviesProgressive(String categoryId, int previewStep, int previewLimit, ProgressiveMoviesResult result) {
        final int step = Math.max(24, previewStep);
        final int limit = Math.max(step, previewLimit);
        try {
            HttpUrl base = HttpUrl.get(host + "/player_api.php");
            HttpUrl.Builder ub = base.newBuilder()
                    .addQueryParameter("username", user)
                    .addQueryParameter("password", pass)
                    .addQueryParameter("action", "get_vod_streams");
            if (categoryId != null && !categoryId.trim().isEmpty()) {
                ub.addQueryParameter("category_id", categoryId.trim());
            }
            Request request = new Request.Builder().url(ub.build()).get().build();
            NetworkProvider.xtreamHttp().newCall(request).enqueue(new okhttp3.Callback() {
                @Override public void onFailure(okhttp3.Call call, java.io.IOException e) {
                    MAIN.post(() -> result.error("Falha ao carregar filmes"));
                }

                @Override public void onResponse(okhttp3.Call call, okhttp3.Response response) {
                    final ResponseBody body = response.body();
                    if (!response.isSuccessful() || body == null) {
                        if (body != null) body.close();
                        response.close();
                        MAIN.post(() -> result.error("Filmes indisponíveis"));
                        return;
                    }
                    PARSER.execute(() -> {
                        List<Movie> out = new ArrayList<>();
                        java.util.Map<Long,Movie> byId = new java.util.HashMap<>();
                        java.util.Map<String,Movie> posterOwners = new java.util.HashMap<>();
                        java.util.Map<String,Movie> titleOwners = new java.util.HashMap<>();
                        java.util.Map<String,Movie> titleYearOwners = new java.util.HashMap<>();
                        java.util.Map<String,Movie> keyOwners = new java.util.HashMap<>();
                        java.util.Map<String,Set<String>> seenYears = new java.util.HashMap<>();
                        int nextEmit = step;
                        try (ResponseBody ignored = body;
                             JsonReader reader = new JsonReader(new InputStreamReader(body.byteStream(), StandardCharsets.UTF_8))) {
                            reader.beginArray();
                            while (reader.hasNext()) {
                                JsonElement parsed = JsonParser.parseReader(reader);
                                if (parsed == null || !parsed.isJsonObject()) continue;
                                JsonObject o = parsed.getAsJsonObject();
                                if (!includeAdult && adultFlag(o)) continue;
                                long id = longVal(o, "stream_id");
                                if (id <= 0) continue;
                                Movie m = new Movie();
                                m.id = id;
                                m.name = cleanMovieName(first(str(o, "name"), str(o, "title"), "Filme"));
                                m.poster = normalizeImage(str(o, "stream_icon"));
                                m.categoryId = str(o, "category_id").trim();
                                m.allCategoryIds = m.categoryId;
                                m.extension = first(str(o, "container_extension"), "mp4");
                                m.year = str(o, "year").trim();
                                m.rating = str(o, "rating").trim();
                                m.contentRating = contentRating(o);
                                m.genre = first(str(o, "genre"), str(o, "genres"));
                                m.plot = first(str(o, "plot"), str(o, "description"));
                                m.originalLanguage = first(str(o, "original_language"), str(o, "originalLanguage"), str(o, "language"));
                                m.country = first(str(o, "country"), str(o, "origin_country"), str(o, "originCountry"));
                                m.directSource = normalizeDirect(str(o, "direct_source"));
                                m.isAdult = adultFlag(o);
                                m.mediaType = first(str(o, "media_type"), str(o, "mediaType"));
                                m.vodType = first(str(o, "vod_type"), str(o, "vodType"));
                                m.filterType = first(str(o, "filter_type"), str(o, "filterType"));

                                Movie duplicate = byId.get(id);
                                if (duplicate != null) {
                                    mergeMovieDuplicate(duplicate, m);
                                    continue;
                                }

                                String variant = movieVariant(m.name);
                                String canonical = canonicalMovieName(m.name);
                                String titleKey = canonical + "|" + variant;
                                String posterKey = normalizedPoster(m.poster);
                                String posterCompound = posterKey.isEmpty() ? "" : posterKey + "|" + variant;
                                duplicate = posterCompound.isEmpty() ? null : posterOwners.get(posterCompound);
                                if (duplicate != null) {
                                    mergeMovieDuplicate(duplicate, m);
                                    byId.put(id, duplicate);
                                    continue;
                                }

                                String y = m.year == null ? "" : m.year.trim();
                                if ("0".equals(y) || "0000".equals(y)) y = "";
                                if (!canonical.isEmpty()) {
                                    Set<String> years = seenYears.computeIfAbsent(titleKey, k -> new HashSet<>());
                                    if (y.isEmpty() && !years.isEmpty()) {
                                        duplicate = titleOwners.get(titleKey);
                                    } else if (!y.isEmpty() && (years.contains(y) || years.contains(""))) {
                                        duplicate = titleYearOwners.get(titleKey + "|" + y);
                                        if (duplicate == null) duplicate = titleOwners.get(titleKey);
                                    }
                                    if (duplicate != null) {
                                        mergeMovieDuplicate(duplicate, m);
                                        byId.put(id, duplicate);
                                        continue;
                                    }
                                }

                                String key = dedupeMovieKey(m.name, y, m.directSource, m.poster);
                                duplicate = key.isEmpty() ? null : keyOwners.get(key);
                                if (duplicate != null) {
                                    mergeMovieDuplicate(duplicate, m);
                                    byId.put(id, duplicate);
                                    continue;
                                }

                                out.add(m);
                                byId.put(id, m);
                                if (!posterCompound.isEmpty()) posterOwners.put(posterCompound, m);
                                if (!canonical.isEmpty()) {
                                    Set<String> years = seenYears.computeIfAbsent(titleKey, k -> new HashSet<>());
                                    years.add(y);
                                    titleOwners.putIfAbsent(titleKey, m);
                                    titleYearOwners.put(titleKey + "|" + y, m);
                                }
                                if (!key.isEmpty()) keyOwners.put(key, m);

                                if (out.size() >= nextEmit && nextEmit <= limit) {
                                    List<Movie> snapshot = new ArrayList<>(out);
                                    MAIN.post(() -> result.partial(snapshot));
                                    nextEmit += step;
                                }
                            }
                            reader.endArray();
                            List<Movie> complete = new ArrayList<>(out);
                            MAIN.post(() -> result.success(complete));
                        } catch (Exception e) {
                            MAIN.post(() -> result.error("Não foi possível ler o catálogo de filmes"));
                        } finally {
                            response.close();
                        }
                    });
                }
            });
        } catch (Exception e) {
            MAIN.post(() -> result.error("Falha ao preparar catálogo de filmes"));
        }
    }


    /** V5.0.155: scans the full VOD response off the UI thread but keeps ONLY adult rows.
     * This is the safe fallback for panels that mark items as adult while their category
     * objects use generic/opaque names. It avoids materializing the entire catalog. */
    public void adultMovies(MoviesResult result) {
        try {
            HttpUrl base = HttpUrl.get(host + "/player_api.php");
            HttpUrl url = base.newBuilder()
                    .addQueryParameter("username", user)
                    .addQueryParameter("password", pass)
                    .addQueryParameter("action", "get_vod_streams")
                    .build();
            Request request = new Request.Builder().url(url).get().build();
            NetworkProvider.xtreamHttp().newCall(request).enqueue(new okhttp3.Callback() {
                @Override public void onFailure(okhttp3.Call call, java.io.IOException e) {
                    MAIN.post(() -> result.error("Falha ao carregar conteúdo HOT"));
                }
                @Override public void onResponse(okhttp3.Call call, okhttp3.Response response) {
                    final ResponseBody body = response.body();
                    if (!response.isSuccessful() || body == null) {
                        if (body != null) body.close();
                        response.close();
                        MAIN.post(() -> result.error("Conteúdo HOT indisponível"));
                        return;
                    }
                    PARSER.execute(() -> {
                        // V5.0.156: fallback HOT é CPU-intensivo em listas enormes.
                        // Mantém prioridade baixa e cede CPU periodicamente para o Looper/UI.
                        try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND); } catch (Exception ignoredPriority) { }
                        List<Movie> out = new ArrayList<>();
                        Set<Long> seen = new HashSet<>();
                        int scanned = 0;
                        try (ResponseBody ignored = body;
                             JsonReader reader = new JsonReader(new InputStreamReader(body.byteStream(), StandardCharsets.UTF_8))) {
                            reader.beginArray();
                            while (reader.hasNext()) {
                                JsonElement parsed = JsonParser.parseReader(reader);
                                if ((++scanned & 127) == 0) { try { Thread.sleep(1L); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); break; } }
                                if (parsed == null || !parsed.isJsonObject()) continue;
                                JsonObject o = parsed.getAsJsonObject();
                                if (!adultFlag(o)) continue;
                                long id = longVal(o, "stream_id");
                                if (id <= 0 || !seen.add(id)) continue;
                                Movie x = new Movie();
                                x.id = id;
                                x.name = cleanMovieName(first(str(o,"name"), str(o,"title"), "Filme"));
                                x.poster = normalizeImage(str(o,"stream_icon"));
                                x.categoryId = str(o,"category_id").trim();
                                x.allCategoryIds = x.categoryId;
                                x.extension = first(str(o,"container_extension"), "mp4");
                                x.year = str(o,"year").trim();
                                x.rating = str(o,"rating").trim();
                                x.contentRating = contentRating(o);
                                x.genre = first(str(o,"genre"), str(o,"genres"));
                                x.plot = first(str(o,"plot"), str(o,"description"));
                                x.originalLanguage = first(str(o,"original_language"), str(o,"originalLanguage"), str(o,"language"));
                                x.country = first(str(o,"country"), str(o,"origin_country"), str(o,"originCountry"));
                                x.directSource = normalizeDirect(str(o,"direct_source"));
                                x.isAdult = true;
                                x.mediaType = first(str(o,"media_type"), str(o,"mediaType"));
                                x.vodType = first(str(o,"vod_type"), str(o,"vodType"));
                                x.filterType = first(str(o,"filter_type"), str(o,"filterType"));
                                out.add(x);
                            }
                            reader.endArray();
                            MAIN.post(() -> result.success(out));
                        } catch (Exception e) {
                            MAIN.post(() -> result.error("Não foi possível ler o conteúdo HOT"));
                        } finally {
                            response.close();
                        }
                    });
                }
            });
        } catch (Exception e) {
            MAIN.post(() -> result.error("Falha ao preparar conteúdo HOT"));
        }
    }

    public void detail(long movieId, DetailResult result) {
        detailApi.vodInfo(user, pass, "get_vod_info", movieId).enqueue(new Callback<JsonObject>() {
            @Override public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (!response.isSuccessful() || response.body() == null) {
                    result.error("Detalhes do filme indisponíveis");
                    return;
                }
                try {
                    JsonObject root = response.body();
                    JsonObject info = object(root, "info");
                    JsonObject data = object(root, "movie_data");
                    MovieDetails d = new MovieDetails();
                    d.id = movieId;
                    d.name = cleanMovieName(first(str(info, "name"), str(data, "name"), str(data, "title"), "Filme"));
                    d.poster = normalizeImage(first(str(info, "cover_big"), str(info, "movie_image"), str(data, "stream_icon"), str(data, "movie_image")));
                    d.backdrop = normalizeImage(firstBackdrop(info.get("backdrop_path")));
                    d.plot = first(str(info, "plot"), str(info, "description"));
                    d.year = first(str(data, "year"), yearFromDate(first(str(info, "release_date"), str(info, "releasedate"))));
                    d.genre = cleanLabel(str(info, "genre"));
                    d.duration = first(str(info, "duration"), runtimeText(str(info, "runtime")));
                    d.director = cleanLabel(str(info, "director"));
                    d.cast = cleanLabel(first(str(info, "cast"), str(info, "actors")));
                    d.country = cleanLabel(str(info, "country"));
                    d.releaseDate = first(str(info, "release_date"), str(info, "releasedate"));
                    d.rating = str(info, "rating");
                    d.extension = first(str(data, "container_extension"), "mp4");
                    d.directSource = normalizeDirect(str(data, "direct_source"));
                    result.success(d);
                } catch (Exception e) {
                    result.error("Não foi possível ler os detalhes do filme");
                }
            }
            @Override public void onFailure(Call<JsonObject> call, Throwable t) {
                result.error("Falha ao carregar detalhes do filme");
            }
        });
    }

    private String normalizeImage(String raw) {
        if (raw == null) return "";
        String u = raw.trim().replace("\\/", "/").replace(" ", "%20");
        if (u.isEmpty()) return "";
        if (u.startsWith("//")) return (host.startsWith("https://") ? "https:" : "http:") + u;
        if (u.startsWith("http://") || u.startsWith("https://")) return u;
        if (u.startsWith("/")) return host + u;
        return host + "/" + u;
    }

    private String normalizeDirect(String raw) {
        if (raw == null) return "";
        String u = raw.trim().replace("\\/", "/").replace(" ", "%20");
        if (u.isEmpty()) return "";
        if (u.startsWith("//")) return (host.startsWith("https://") ? "https:" : "http:") + u;
        if (u.startsWith("http://") || u.startsWith("https://")) return u;
        if (u.startsWith("/")) return host + u;
        return host + "/" + u;
    }

    private static JsonObject object(JsonObject root, String key) {
        try { JsonElement e = root.get(key); return e != null && e.isJsonObject() ? e.getAsJsonObject() : new JsonObject(); }
        catch (Exception e) { return new JsonObject(); }
    }

    private static String firstBackdrop(JsonElement e) {
        try {
            if (e == null || e.isJsonNull()) return "";
            if (e.isJsonArray()) {
                JsonArray a = e.getAsJsonArray();
                return a.size() > 0 && !a.get(0).isJsonNull() ? a.get(0).getAsString() : "";
            }
            return e.getAsString();
        } catch (Exception ex) { return ""; }
    }

    private static String cleanCategoryName(String raw) {
        String name = cleanCommonLabel(raw);
        return "all".equalsIgnoreCase(name) ? "TODOS" : name;
    }

    private static String cleanMovieName(String raw) {
        String cleaned = cleanCommonLabel(raw);
        return cleaned.isEmpty() ? "Filme" : cleaned;
    }

    private static String cleanLabel(String raw) { return cleanCommonLabel(raw); }

    private static String cleanCommonLabel(String raw) {
        if (raw == null) return "";
        String s = raw.replace("\\/", "/").replace("\n", " ").replace("\r", " ").trim();
        s = s.replaceAll("^[^\\p{L}\\p{N}(]+", "");
        return s.replaceAll("\\s{2,}", " ").trim();
    }

    /**
     * V5.0.128 — quando o painel repete o mesmo filme em mais de uma pasta,
     * mantém um único card, mas agrega todos os category_id.
     */
    private static void mergeMovieDuplicate(Movie current, Movie incoming) {
        if (current == null || incoming == null) return;
        current.allCategoryIds = mergeCategoryIds(
                current.allCategoryIds == null || current.allCategoryIds.trim().isEmpty() ? current.categoryId : current.allCategoryIds,
                incoming.allCategoryIds == null || incoming.allCategoryIds.trim().isEmpty() ? incoming.categoryId : incoming.allCategoryIds);
        if ((current.poster == null || current.poster.trim().isEmpty()) && incoming.poster != null) current.poster = incoming.poster;
        if ((current.rating == null || current.rating.trim().isEmpty()) && incoming.rating != null) current.rating = incoming.rating;
        if ((current.year == null || current.year.trim().isEmpty()) && incoming.year != null) current.year = incoming.year;
        if ((current.contentRating == null || current.contentRating.trim().isEmpty()) && incoming.contentRating != null) current.contentRating = incoming.contentRating;
        if ((current.genre == null || current.genre.trim().isEmpty()) && incoming.genre != null) current.genre = incoming.genre;
        if ((current.plot == null || current.plot.trim().isEmpty()) && incoming.plot != null) current.plot = incoming.plot;
        if ((current.originalLanguage == null || current.originalLanguage.trim().isEmpty()) && incoming.originalLanguage != null) current.originalLanguage = incoming.originalLanguage;
        if ((current.country == null || current.country.trim().isEmpty()) && incoming.country != null) current.country = incoming.country;
        current.isAdult = current.isAdult || incoming.isAdult;
        if ((current.mediaType == null || current.mediaType.trim().isEmpty()) && incoming.mediaType != null) current.mediaType = incoming.mediaType;
        if ((current.vodType == null || current.vodType.trim().isEmpty()) && incoming.vodType != null) current.vodType = incoming.vodType;
        if ((current.filterType == null || current.filterType.trim().isEmpty()) && incoming.filterType != null) current.filterType = incoming.filterType;
    }

    private static String mergeCategoryIds(String a, String b) {
        java.util.LinkedHashSet<String> ids = new java.util.LinkedHashSet<>();
        if (a != null) for (String x : a.split("[|,;]+")) if (x != null && !x.trim().isEmpty()) ids.add(x.trim());
        if (b != null) for (String x : b.split("[|,;]+")) if (x != null && !x.trim().isEmpty()) ids.add(x.trim());
        StringBuilder joined = new StringBuilder();
        for (String id : ids) {
            if (joined.length() > 0) joined.append('|');
            joined.append(id);
        }
        return joined.toString();
    }

    private static String dedupeMovieKey(String name, String year, String directSource, String poster) {
        String base = keyName(name);
        String y = year == null ? "" : year.trim();
        if (!base.isEmpty()) return y.isEmpty() ? "name|" + base : "name|" + base + "|" + y;
        String direct = directSource == null ? "" : directSource.trim().toLowerCase(Locale.ROOT);
        if (!direct.isEmpty()) return "direct|" + direct;
        if (poster != null && !poster.trim().isEmpty()) return "poster|" + poster.trim().toLowerCase(Locale.ROOT);
        return "";
    }

    private static String canonicalMovieName(String value) {
        if (value == null) return "";
        String s=value.toLowerCase(Locale.ROOT)
                .replaceAll("\\b(?:2160p|1080p|720p|480p|4k|uhd|fhd|full\\s*hd|hd|h\\.?265|hevc|h\\.?264|x265|x264|web[- .]?dl|webrip|bluray|brrip|hdr|sdr)\\b", " ")
                .replaceAll("[\\s._-]*(?:\\(|\\[)?(?:19|20)\\d{2}(?:\\)|\\])?\\s*$", "")
                .replaceAll("\\s+", " ").trim();
        return s.replaceAll("[^\\p{L}\\p{N}]+", "").trim();
    }

    private static String movieVariant(String value) {
        if (value == null) return "padrao";
        String s=value.toLowerCase(Locale.ROOT);
        if (s.matches(".*(?:\\[|\\(|\\b)(?:leg|legendado|legendada|sub|subtitled|l)(?:\\]|\\)|\\b).*$")) return "legendado";
        if (s.matches(".*(?:\\[|\\(|\\b)(?:dub|dublado|dublada|dual|d)(?:\\]|\\)|\\b).*$")) return "dublado";
        return "padrao";
    }

    private static String normalizedPoster(String value) {
        if (value == null) return "";
        String s=value.trim().toLowerCase(Locale.ROOT);
        int q=s.indexOf('?'); if(q>0)s=s.substring(0,q);
        return s;
    }

    private static String keyName(String value) {
        return canonicalMovieName(value);
    }

    private static String runtimeText(String raw) {
        try {
            long sec = Long.parseLong(raw == null ? "" : raw.trim());
            if (sec <= 0) return "";
            long h = sec / 3600;
            long m = (sec % 3600) / 60;
            return h > 0 ? h + "h " + m + "min" : m + "min";
        } catch (Exception e) { return ""; }
    }

    private static String yearFromDate(String raw) {
        if (raw == null) return "";
        String s = raw.trim();
        return s.length() >= 4 ? s.substring(0, 4) : "";
    }

    private static String first(String... values) {
        if (values == null) return "";
        for (String v : values) if (v != null && !v.trim().isEmpty()) return v.trim();
        return "";
    }

    private static String str(JsonObject o, String k) {
        try { JsonElement e = o.get(k); return e == null || e.isJsonNull() ? "" : e.getAsString(); }
        catch (Exception e) { return ""; }
    }

    private static long longVal(JsonObject o, String k) {
        try { return o.get(k).getAsLong(); } catch (Exception e) { return 0L; }
    }

    /**
     * Age/content classification when a provider exposes it. This never treats
     * the normal 0-10 popularity score in "rating" as an age classification.
     */
    private static String contentRating(JsonObject o) {
        return first(
                str(o, "content_rating"), str(o, "contentRating"),
                str(o, "age_rating"), str(o, "ageRating"),
                str(o, "parental_rating"), str(o, "parentalRating"),
                str(o, "certification"), str(o, "certificate"),
                str(o, "mpaa_rating"), str(o, "rating_label"), str(o, "ratingLabel"));
    }

    private static boolean adultFlag(JsonObject o) {
        if (o == null) return false;
        if (boolVal(o, "is_adult") || boolVal(o, "adult") || boolVal(o, "adult_content")
                || boolVal(o, "adult_vod") || boolVal(o, "isAdult") || boolVal(o, "is_xxx")
                || boolVal(o, "xxx")) return true;
        String type = (str(o, "media_type") + " " + str(o, "vod_type") + " " + str(o, "filter_type")
                + " " + str(o, "category_name") + " " + str(o, "category")
                + " " + str(o, "group_title") + " " + str(o, "group") + " " + str(o, "bouquet")
                + " " + str(o, "section") + " " + str(o, "type") + " " + str(o, "content_type"))
                .toLowerCase(java.util.Locale.ROOT);
        // V5.0.157: só sinais estruturais inequívocos de +18. Não classifica
        // conteúdo pelo título/tema (ex.: um filme chamado "Adult Material").
        if (type.contains("adult_vod") || type.contains("adult_content")
                || type.matches(".*(^|[^a-z0-9])(xxx|porn|porno|pornografia|pornographic|pornography|hentai)([^a-z0-9]|$).*")
                || type.contains("18+") || type.contains("+18") || type.contains("🔞")) return true;
        return false;
    }

    private static boolean boolVal(JsonObject o, String k) {
        try {
            JsonElement e = o.get(k);
            if (e == null || e.isJsonNull()) return false;
            if (e.getAsJsonPrimitive().isBoolean()) return e.getAsBoolean();
            String s = e.getAsString().trim();
            return "1".equals(s) || "true".equalsIgnoreCase(s) || "yes".equalsIgnoreCase(s);
        } catch (Exception e) { return false; }
    }
}
