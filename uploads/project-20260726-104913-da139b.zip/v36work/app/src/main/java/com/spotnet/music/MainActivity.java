package com.spotnet.music;

import android.Manifest;
import android.content.ComponentName;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.app.AlertDialog;
import android.app.ActivityManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.*;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.Player;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionToken;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.google.common.util.concurrent.ListenableFuture;
import org.json.*;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.ConcurrentHashMap;

public class MainActivity extends AppCompatActivity {
    LinearLayout bannerBox, sectionsBox, recentSearches;
    FrameLayout appRoot;
    ImageView dynamicBackground;
    View homeTab, searchTab, queueTab, detailTab, accountTab;
    TextView homeStatus, searchStatus, queueStatus, nowTitle, nowSub, navHome, navSearch, navQueue, navAccount, detailTitle, detailStatus, planName, planExpiry, accountName, accountUser, accountStatus, accountReferral, accountAvatar, planBadge;
    ProgressBar planProgress;
    EditText searchInput;
    ImageView nowThumb;
    Button playPause, previousBtn, nextBtn, shuffleBtn, queuePlayPause, queueNextBtn, detailPlay, detailShuffle, renewBtn, miniPreviousBtn;
    TextView inviteBtn;
    final ArrayList<MusicItem> searchItems = new ArrayList<>();
    final ArrayList<MusicItem> queueItems = new ArrayList<>();
    final ArrayList<MusicItem> detailItems = new ArrayList<>();
    SearchAdapter searchAdapter, queueAdapter, detailAdapter;
    ListenableFuture<MediaController> controllerFuture;
    MediaController controller;
    final AtomicInteger queueGeneration = new AtomicInteger(0);
    boolean shuffleEnabled = false;
    boolean coverBackgroundEnabled = true;
    boolean playRequestPending = false; boolean subscriptionActive=true; boolean lowRamMode=false; int currentTab=0;
    String configuredBackground = "";
    String referralLink = "";
    final ConcurrentHashMap<String,CachedMedia> mediaCache = new ConcurrentHashMap<>();
    static final class CachedMedia { final MediaItem item; final long expiresAt; CachedMedia(MediaItem i,long e){item=i;expiresAt=e;} }
    final Handler heartbeatHandler = new Handler(Looper.getMainLooper());
    final Runnable heartbeatTask = new Runnable(){@Override public void run(){sendHeartbeat();heartbeatHandler.postDelayed(this,60000);}};

    private final ActivityResultLauncher<String> notificationPermission = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(), granted -> {});

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        ActivityManager am=(ActivityManager)getSystemService(Context.ACTIVITY_SERVICE); lowRamMode=am!=null&&(am.isLowRamDevice()||am.getMemoryClass()<160);
        appRoot=findViewById(R.id.appRoot); recentSearches=findViewById(R.id.recentSearches); dynamicBackground=findViewById(R.id.dynamicBackground); bannerBox=findViewById(R.id.bannerBox); sectionsBox=findViewById(R.id.sectionsBox);
        homeTab=findViewById(R.id.homeTab); searchTab=findViewById(R.id.searchTab); queueTab=findViewById(R.id.queueTab); detailTab=findViewById(R.id.detailTab); accountTab=findViewById(R.id.accountTab);
        homeStatus=findViewById(R.id.homeStatus); searchStatus=findViewById(R.id.searchStatus); queueStatus=findViewById(R.id.queueStatus);
        nowTitle=findViewById(R.id.nowTitle); nowSub=findViewById(R.id.nowSub); nowThumb=findViewById(R.id.nowThumb);
        planName=findViewById(R.id.planName); planExpiry=findViewById(R.id.planExpiry); renewBtn=findViewById(R.id.renewBtn); accountName=findViewById(R.id.accountName); accountUser=findViewById(R.id.accountUser); accountStatus=findViewById(R.id.accountStatus); accountReferral=findViewById(R.id.accountReferral); accountAvatar=findViewById(R.id.accountAvatar); planBadge=findViewById(R.id.planBadge); planProgress=findViewById(R.id.planProgress);
        navHome=findViewById(R.id.navHome); navSearch=findViewById(R.id.navSearch); navQueue=findViewById(R.id.navQueue); navAccount=findViewById(R.id.navAccount); detailTitle=findViewById(R.id.detailTitle); detailStatus=findViewById(R.id.detailStatus);
        searchInput=findViewById(R.id.searchInput); playPause=findViewById(R.id.playPause); miniPreviousBtn=findViewById(R.id.miniPreviousBtn); inviteBtn=findViewById(R.id.inviteBtn);
        previousBtn=findViewById(R.id.previousBtn); nextBtn=findViewById(R.id.nextBtn); shuffleBtn=findViewById(R.id.shuffleBtn); queuePlayPause=findViewById(R.id.queuePlayPause); queueNextBtn=findViewById(R.id.queueNextBtn); detailPlay=findViewById(R.id.detailPlay); detailShuffle=findViewById(R.id.detailShuffle);

        RecyclerView searchList=findViewById(R.id.searchList); searchList.setLayoutManager(new LinearLayoutManager(this));
        searchAdapter=new SearchAdapter(searchItems,x->playQueue(new ArrayList<>(searchItems), Math.max(0,searchItems.indexOf(x))),favoriteHandler()); searchList.setAdapter(searchAdapter);
        RecyclerView queueList=findViewById(R.id.queueList); queueList.setLayoutManager(new LinearLayoutManager(this));
        queueAdapter=new SearchAdapter(queueItems,x->jumpToQueueItem(Math.max(0,queueItems.indexOf(x))),favoriteHandler()); queueList.setAdapter(queueAdapter);
        RecyclerView detailList=findViewById(R.id.detailList); detailList.setLayoutManager(new LinearLayoutManager(this));
        detailAdapter=new SearchAdapter(detailItems,x->playQueue(new ArrayList<>(detailItems),Math.max(0,detailItems.indexOf(x))),favoriteHandler()); detailList.setAdapter(detailAdapter);

        navHome.setOnClickListener(v->tab(0)); navSearch.setOnClickListener(v->tab(1)); navQueue.setOnClickListener(v->{tab(2);showLibrary();}); navAccount.setOnClickListener(v->{tab(4);loadProfile();});
        findViewById(R.id.homeSearchCard).setOnClickListener(v->tab(1));
        findViewById(R.id.searchBtn).setOnClickListener(v->search());
        searchInput.setOnEditorActionListener((v,action,event)->{if(action==EditorInfo.IME_ACTION_SEARCH){search();return true;}return false;});
        int[] quick={R.id.quickSertanejo,R.id.quickForro,R.id.quickPagode,R.id.quickGospel,R.id.quickFunk}; String[] qq={"Sertanejo lançamentos","Forró mais tocadas","Pagode sucessos","Gospel atual","Funk viral"}; for(int i=0;i<quick.length;i++){final String q=qq[i];findViewById(quick[i]).setOnClickListener(v->{searchInput.setText(q);search();});}
        findViewById(R.id.clearSearchHistory).setOnClickListener(v->{getSharedPreferences("search_history",MODE_PRIVATE).edit().clear().apply();renderSearchHistory();});renderSearchHistory();
        findViewById(R.id.logout).setOnClickListener(v->{getSharedPreferences("auth",MODE_PRIVATE).edit().clear().apply();startActivity(new Intent(this,LoginActivity.class));finish();});
        playPause.setOnClickListener(v->toggle());
        miniPreviousBtn.setOnClickListener(v->{if(controller!=null){if(controller.getCurrentPosition()>5000)controller.seekTo(0);else if(controller.hasPreviousMediaItem())controller.seekToPreviousMediaItem();}});
        inviteBtn.setOnClickListener(v->shareReferral());
        previousBtn.setOnClickListener(v->{if(controller!=null&&controller.hasPreviousMediaItem())controller.seekToPreviousMediaItem();});
        nextBtn.setOnClickListener(v->{if(controller!=null&&controller.hasNextMediaItem())controller.seekToNextMediaItem();});
        queuePlayPause.setOnClickListener(v->toggle()); queueNextBtn.setOnClickListener(v->{if(controller!=null&&controller.hasNextMediaItem())controller.seekToNextMediaItem();});
        findViewById(R.id.detailBack).setOnClickListener(v->tab(0));
        detailPlay.setOnClickListener(v->playQueue(new ArrayList<>(detailItems),0));
        detailShuffle.setOnClickListener(v->{boolean old=shuffleEnabled;shuffleEnabled=true;playQueue(new ArrayList<>(detailItems),0);shuffleEnabled=old;});
        shuffleBtn.setOnClickListener(v->toggleShuffle());
        findViewById(R.id.miniPlayer).setOnClickListener(v->tab(2));
        requestNotificationPermission(); connectPlayer(); loadAppConfig(); loadBanners(); loadHome(); loadProfile(); heartbeatHandler.post(heartbeatTask);
    }


    void loadAppConfig(){
        android.content.SharedPreferences cache=getSharedPreferences("ui_cache",MODE_PRIVATE);
        configuredBackground=cache.getString("app_background_url","");
        coverBackgroundEnabled=cache.getBoolean("cover_background_enabled",true);
        boolean cachedDefault=cache.getBoolean("use_default_background",configuredBackground.isEmpty());
        applyConfiguredBackground(cachedDefault);
        new Thread(()->{
            try{
                JSONObject j=new JSONObject(Net.getFast(BuildConfig.PANEL_URL+"/api/branding.php?t="+System.currentTimeMillis()));
                JSONObject cfg=j.optJSONObject("branding"); if(cfg==null)return;
                String logo=cfg.optString("logo_url",""); if(!logo.isEmpty()&&!logo.startsWith("http")){if(!logo.startsWith("/"))logo="/"+logo;logo=BuildConfig.PANEL_URL+logo;} final String appLogo=logo;
                String bg=cfg.optString("background_url","");
                if(!bg.isEmpty()&&!bg.startsWith("http")){if(!bg.startsWith("/"))bg="/"+bg;bg=BuildConfig.PANEL_URL+bg;}
                configuredBackground=bg;
                coverBackgroundEnabled=cfg.optBoolean("cover_background_enabled",true);
                boolean useDefault=cfg.optBoolean("use_default_background",configuredBackground.isEmpty());
                cache.edit().putString("app_logo_url",appLogo).putString("app_background_url",configuredBackground).putBoolean("cover_background_enabled",coverBackgroundEnabled).putBoolean("use_default_background",useDefault).apply();
                runOnUiThread(()->applyConfiguredBackground(useDefault));
            }catch(Exception ignored){}
        }).start();
    }

    void applyConfiguredBackground(boolean useDefault){
        if(lowRamMode){dynamicBackground.setVisibility(View.GONE);return;}
        if(!useDefault&&!configuredBackground.isEmpty()){
            dynamicBackground.setVisibility(View.VISIBLE); dynamicBackground.setAlpha(.42f);
            Glide.with(this).load(configuredBackground).centerCrop().dontAnimate().into(dynamicBackground);
        } else if(controller==null || controller.getMediaMetadata().artworkUri==null) dynamicBackground.setVisibility(View.GONE);
    }

    private void requestNotificationPermission(){
        if(android.os.Build.VERSION.SDK_INT>=33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS);
    }

    private void connectPlayer(){
        SessionToken token=new SessionToken(this,new ComponentName(this,PlaybackService.class));
        controllerFuture=new MediaController.Builder(this,token).buildAsync();
        controllerFuture.addListener(()->{
            try{
                controller=controllerFuture.get();
                controller.addListener(new Player.Listener(){
                    @Override public void onIsPlayingChanged(boolean isPlaying){runOnUiThread(()->{playPause.setText(isPlaying?"❚❚":"▶"); queuePlayPause.setText(isPlaying?"❚❚":"▶");sendHeartbeat();});}
                    @Override public void onMediaMetadataChanged(MediaMetadata m){runOnUiThread(()->updateNowPlaying(m));}
                    @Override public void onMediaItemTransition(MediaItem item,int reason){runOnUiThread(()->{updateQueueStatus();sendHeartbeat();});}
                    @Override public void onPlaybackStateChanged(int state){runOnUiThread(()->updateQueueStatus());}
                });
                updateNowPlaying(controller.getMediaMetadata());
                playPause.setText(controller.isPlaying()?"❚❚":"▶"); queuePlayPause.setText(controller.isPlaying()?"❚❚":"▶");
                updateQueueStatus();
            }catch(Exception e){Toast.makeText(this,"Falha ao iniciar o player",Toast.LENGTH_SHORT).show();}
        },ContextCompat.getMainExecutor(this));
    }

    void updateNowPlaying(MediaMetadata m){
        if(m.title!=null)nowTitle.setText(m.title);
        if(m.artist!=null)nowSub.setText(m.artist);
        if(m.artworkUri!=null){
            Glide.with(this).load(m.artworkUri).centerCrop().dontAnimate().into(nowThumb);
            getSharedPreferences("ui_cache",MODE_PRIVATE).edit().putString("last_cover",m.artworkUri.toString()).apply();
            if(coverBackgroundEnabled&&!lowRamMode){
                dynamicBackground.setVisibility(View.VISIBLE);
                Glide.with(this).load(m.artworkUri).centerCrop().dontAnimate().into(dynamicBackground);
                dynamicBackground.animate().alpha(.38f).setDuration(180).start();
            }
        }
        playRequestPending=false; playPause.setEnabled(true); playPause.setText(controller!=null&&controller.isPlaying()?"❚❚":"▶");
    }

    void updateQueueStatus(){
        if(controller==null){queueStatus.setText("Player iniciando...");return;}
        int total=controller.getMediaItemCount(); int current=controller.getCurrentMediaItemIndex();
        queueStatus.setText(total==0?"A fila está vazia.":total+" músicas na fila • tocando "+(current+1)+(shuffleEnabled?" • aleatório":""));
    }

    void tab(int selected){
        currentTab=selected;
        homeTab.setVisibility(selected==0?View.VISIBLE:View.GONE);
        searchTab.setVisibility(selected==1?View.VISIBLE:View.GONE);
        queueTab.setVisibility(selected==2?View.VISIBLE:View.GONE);
        detailTab.setVisibility(selected==3?View.VISIBLE:View.GONE);
        accountTab.setVisibility(selected==4?View.VISIBLE:View.GONE);
        navHome.setTextColor(getColor(selected==0?R.color.green:R.color.muted));
        navSearch.setTextColor(getColor(selected==1?R.color.green:R.color.muted));
        navQueue.setTextColor(getColor(selected==2?R.color.green:R.color.muted));
        navAccount.setTextColor(getColor(selected==4?R.color.green:R.color.muted));
        navHome.setBackgroundResource(android.R.color.transparent);
        navSearch.setBackgroundResource(android.R.color.transparent);
        navQueue.setBackgroundResource(android.R.color.transparent);
        navAccount.setBackgroundResource(android.R.color.transparent);
        if(selected==2)updateQueueStatus();
    }

    void loadBanners(){
        String cached=getSharedPreferences("ui_cache",MODE_PRIVATE).getString("banners_json","");
        if(!cached.isEmpty())try{renderBanners(new JSONObject(cached).optJSONArray("banners"));}catch(Exception ignored){}
        new Thread(()->{try{String raw=Net.get(BuildConfig.PANEL_URL+"/api/banners.php");getSharedPreferences("ui_cache",MODE_PRIVATE).edit().putString("banners_json",raw).apply();JSONArray a=new JSONObject(raw).optJSONArray("banners");runOnUiThread(()->renderBanners(a));}catch(Exception ignored){}}).start();
    }
    void renderBanners(JSONArray a){
        if(a==null||a.length()==0)return;
        bannerBox.removeAllViews();
        JSONObject b=a.optJSONObject(0); if(b==null)return;
        FrameLayout hero=new FrameLayout(this);
        int w=getResources().getDisplayMetrics().widthPixels-dp(36);
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(w,dp(166));
        hp.setMargins(dp(6),0,dp(6),0);
        hero.setLayoutParams(hp);
        hero.setBackgroundResource(R.drawable.hero_card);
        ImageView im=new ImageView(this);
        im.setScaleType(ImageView.ScaleType.CENTER_CROP);
        hero.addView(im,new FrameLayout.LayoutParams(-1,-1));
        String image=b.optString("image");
        if(!image.startsWith("http")){if(!image.startsWith("/"))image="/"+image;image=BuildConfig.PANEL_URL+image;}
        Glide.with(this).load(image).centerCrop().into(im);
        hero.setOnClickListener(v->{android.widget.ScrollView sv=findViewById(R.id.homeTab);sv.smoothScrollTo(0,dp(360));});
        bannerBox.addView(hero);
    }

    void loadHome(){
        homeStatus.setVisibility(View.GONE);
        String cached=getSharedPreferences("ui_cache",MODE_PRIVATE).getString("home_json","");
        if(!cached.isEmpty())try{JSONObject j=new JSONObject(cached);renderSections(j.optJSONArray("sections"),j.optJSONArray("items"),j.optJSONArray("categories"));}catch(Exception ignored){}
        new Thread(()->{try{String raw=Net.get(BuildConfig.PANEL_URL+"/api/music/home.php?refresh="+(System.currentTimeMillis()/600000));getSharedPreferences("ui_cache",MODE_PRIVATE).edit().putString("home_json",raw).apply();JSONObject j=new JSONObject(raw);JSONArray secs=j.optJSONArray("sections");runOnUiThread(()->renderSections(secs,j.optJSONArray("items"),j.optJSONArray("categories")));}catch(Exception e){if(cached.isEmpty())runOnUiThread(()->{homeStatus.setVisibility(View.VISIBLE);homeStatus.setText("Não foi possível atualizar agora.");});}}).start();
    }

    void renderSections(JSONArray secs,JSONArray fallback,JSONArray categories){sectionsBox.removeAllViews();addCategoryBar(categories);int made=0;if(secs!=null)for(int i=0;i<secs.length() && i<(lowRamMode?6:12);i++){JSONObject s=secs.optJSONObject(i);if(s==null)continue;JSONArray items=s.optJSONArray("items");if(items==null||items.length()==0)continue;addSection(s.optString("title","Músicas"),items);made++;}if(made==0&&fallback!=null&&fallback.length()>0){addSection("Músicas",fallback);made++;}homeStatus.setVisibility(View.GONE);}

    void addCategoryBar(JSONArray categories){
        if(categories==null||categories.length()==0)return;
        TextView h=new TextView(this);h.setText("Explore por categoria");h.setTextColor(Color.WHITE);h.setTextSize(18);h.setTypeface(null,1);h.setPadding(dp(18),dp(24),dp(8),dp(12));sectionsBox.addView(h);
        HorizontalScrollView sv=new HorizontalScrollView(this);sv.setHorizontalScrollBarEnabled(false);
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setPadding(dp(16),0,dp(16),dp(10));sv.addView(row);
        int max=Math.min(categories.length(),10);
        for(int i=0;i<max;i++){
            String name=categories.optString(i);if(name.isEmpty())continue;
            LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setGravity(android.view.Gravity.CENTER);card.setPadding(dp(10),dp(10),dp(10),dp(8));card.setBackgroundResource(R.drawable.neon_card);
            TextView icon=new TextView(this);icon.setGravity(android.view.Gravity.CENTER);icon.setText(categoryIcon(name));icon.setTextSize(24);icon.setTextColor(categoryColor(name));card.addView(icon,new LinearLayout.LayoutParams(-1,dp(34)));
            TextView title=new TextView(this);title.setGravity(android.view.Gravity.CENTER);title.setText(shortCategory(name));title.setTextColor(Color.WHITE);title.setTextSize(12);title.setTypeface(null,1);title.setMaxLines(2);card.addView(title,new LinearLayout.LayoutParams(-1,dp(34)));
            TextView sub=new TextView(this);sub.setGravity(android.view.Gravity.CENTER);sub.setText(categorySubtitle(name));sub.setTextColor(getColor(R.color.muted));sub.setTextSize(10);sub.setMaxLines(1);card.addView(sub,new LinearLayout.LayoutParams(-1,dp(18)));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(110),dp(102));lp.setMargins(dp(5),0,dp(5),0);card.setLayoutParams(lp);
            card.setOnClickListener(v->{tab(1);searchInput.setText(name);search();});row.addView(card);
        }
        sectionsBox.addView(sv,new LinearLayout.LayoutParams(-1,dp(114)));
    }

    String categoryIcon(String n){String x=n.toLowerCase();if(x.contains("lança"))return "☆";if(x.contains("sert"))return "♨";if(x.contains("românt"))return "♡";if(x.contains("eletr"))return "♬";if(x.contains("gospel"))return "♢";if(x.contains("forró")||x.contains("piseiro"))return "▥";if(x.contains("pagode")||x.contains("samba"))return "♩";return "♫";}
    int categoryColor(String n){String x=n.toLowerCase();if(x.contains("lança"))return Color.parseColor("#9B5CFF");if(x.contains("sert"))return Color.parseColor("#FF4B55");if(x.contains("românt"))return Color.parseColor("#41A9FF");if(x.contains("eletr"))return Color.parseColor("#FF9E38");return getColor(R.color.green);}
    String shortCategory(String n){if(n.length()>22)return n.substring(0,22);return n;}
    String categorySubtitle(String n){String x=n.toLowerCase();if(x.contains("lança"))return "da semana";if(x.contains("mais toc"))return "Brasil";if(x.contains("sert"))return "As melhores";if(x.contains("românt"))return "Apaixonado";if(x.contains("eletr"))return "Energia pura";return "Ouça agora";}

    void addSection(String title,JSONArray arr){
        ArrayList<MusicItem> playlist=new ArrayList<>();
        for(int i=0;i<arr.length();i++){JSONObject x=arr.optJSONObject(i);if(x!=null){MusicItem item=parse(x);if(!item.videoId.isEmpty()||!item.id.isEmpty())playlist.add(item);}}
        if(playlist.isEmpty())return;
        LinearLayout heading=new LinearLayout(this);heading.setOrientation(LinearLayout.HORIZONTAL);heading.setGravity(android.view.Gravity.CENTER_VERTICAL);heading.setPadding(dp(18),dp(22),dp(18),dp(8));
        TextView h=new TextView(this);h.setText(title);h.setTextColor(Color.WHITE);h.setTextSize(19);h.setTypeface(null,1);heading.addView(h,new LinearLayout.LayoutParams(0,-2,1));
        TextView all=new TextView(this);all.setText("Ver todas  ›");all.setTextColor(getColor(R.color.green));all.setTextSize(13);all.setGravity(android.view.Gravity.CENTER);all.setPadding(dp(8),dp(8),dp(4),dp(8));all.setOnClickListener(v->showPlaylist(title,new ArrayList<>(playlist)));heading.addView(all,new LinearLayout.LayoutParams(-2,dp(42)));sectionsBox.addView(heading);
        HorizontalScrollView sv=new HorizontalScrollView(this);sv.setHorizontalScrollBarEnabled(false);LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setPadding(dp(16),0,dp(16),0);sv.addView(row);
        int max=Math.min(playlist.size(),lowRamMode?8:14);
        for(int i=0;i<max;i++){
            MusicItem item=playlist.get(i);final int index=i;
            LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(0,0,dp(8),0);
            FrameLayout cover=new FrameLayout(this);ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);cover.addView(im,new FrameLayout.LayoutParams(-1,-1));Glide.with(this).load(item.thumb).override(dp(lowRamMode?120:220)).centerCrop().dontAnimate().into(im);card.addView(cover,new LinearLayout.LayoutParams(dp(108),dp(112)));
            TextView t=new TextView(this);t.setText(item.title);t.setTextColor(Color.WHITE);t.setTypeface(null,1);t.setTextSize(12);t.setMaxLines(2);card.addView(t,new LinearLayout.LayoutParams(dp(108),dp(34)));
            TextView sub=new TextView(this);sub.setText(item.subtitle);sub.setTextColor(getColor(R.color.muted));sub.setTextSize(11);sub.setMaxLines(1);card.addView(sub,new LinearLayout.LayoutParams(dp(108),dp(20)));
            card.setOnClickListener(v->playQueue(new ArrayList<>(playlist),index));card.setOnLongClickListener(v->{showPlaylist(title,new ArrayList<>(playlist));return true;});
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(116),dp(166));lp.setMargins(0,0,dp(8),0);row.addView(card,lp);
        }
        sectionsBox.addView(sv,new LinearLayout.LayoutParams(-1,dp(170)));
    }

    void loadExpandedPlaylist(String title){
        detailTitle.setText(title); detailStatus.setText("Carregando até 100 músicas..."); detailItems.clear(); detailAdapter.notifyDataSetChanged(); tab(3);
        new Thread(()->{try{JSONObject j=new JSONObject(Net.get(BuildConfig.PANEL_URL+"/api/music/search.php?q="+URLEncoder.encode(title+" músicas artistas sucessos","UTF-8")+"&limit=100&expanded=1"));JSONArray a=j.optJSONArray("items");ArrayList<MusicItem> n=new ArrayList<>();if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null){MusicItem item=parse(x);if(!item.videoId.isEmpty())n.add(item);}}runOnUiThread(()->{detailItems.clear();detailItems.addAll(n);detailAdapter.notifyDataSetChanged();detailStatus.setText(n.size()+" músicas • toque em uma faixa para começar");});}catch(Exception e){runOnUiThread(()->detailStatus.setText("Falha ao carregar músicas: "+e.getMessage()));}}).start();
    }

    void showPlaylist(String title, ArrayList<MusicItem> items){
        detailItems.clear(); detailItems.addAll(items); detailAdapter.notifyDataSetChanged();
        detailTitle.setText(title); detailStatus.setText(items.size()+" músicas • toque em uma faixa para começar");
        tab(3);
    }

    String cleanMusicSubtitle(String raw){
        if(raw==null)return "";
        String value=raw.trim();
        if(value.isEmpty())return "";
        String[] parts=value.split("[•·]");
        ArrayList<String> useful=new ArrayList<>();
        for(String part:parts){
            String v=part.trim();
            String lower=v.toLowerCase();
            if(v.isEmpty())continue;
            if(lower.equals("música")||lower.equals("musica")||lower.equals("vídeo")||lower.equals("video")||lower.equals("episódio")||lower.equals("episodio")||lower.equals("playlist")||lower.equals("álbum")||lower.equals("album"))continue;
            if(lower.matches(".*\\b[0-9]+([.,][0-9]+)?\\s*(mil|mi|milhões|milhoes|views|visualizações|visualizacoes)\\b.*"))continue;
            if(lower.matches(".*\\b[0-9]{1,2}\\s+de\\s+[a-zç]{3,}\\.?$"))continue;
            useful.add(v);
        }
        if(!useful.isEmpty())return useful.get(0);
        return "Música";
    }

    MusicItem parse(JSONObject x){String id=x.optString("id",x.optString("video_id"));String subtitle=cleanMusicSubtitle(x.optString("subtitle",x.optString("artist")));return new MusicItem(id,x.optString("type","song"),x.optString("title"),subtitle,x.optString("thumbnail"),x.optString("video_id",id));}

    void search(){String q=searchInput.getText().toString().trim();if(q.isEmpty())return;saveSearchHistory(q);searchStatus.setText("Buscando músicas, artistas, álbuns e playlists...");new Thread(()->{try{JSONObject j=new JSONObject(Net.get(BuildConfig.PANEL_URL+"/api/music/search.php?q="+URLEncoder.encode(q,"UTF-8")+"&limit=50"));JSONArray a=j.optJSONArray("items");ArrayList<MusicItem> n=new ArrayList<>();if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null){MusicItem item=parse(x);if(!item.videoId.isEmpty())n.add(item);}}runOnUiThread(()->{searchItems.clear();searchItems.addAll(n);searchAdapter.notifyDataSetChanged();searchStatus.setText(n.size()+" músicas encontradas • toque em uma para tocar todas em sequência");});}catch(Exception e){runOnUiThread(()->searchStatus.setText("Erro: "+e.getMessage()));}}).start();}

    void playQueue(ArrayList<MusicItem> source,int startIndex){
        if(!subscriptionActive){Toast.makeText(this,"Seu plano está vencido. Renove para continuar ouvindo.",Toast.LENGTH_LONG).show();tab(4);return;}if(controller==null){Toast.makeText(this,"Player iniciando...",Toast.LENGTH_SHORT).show();return;}
        if(source.isEmpty())return;
        int selected=Math.max(0,Math.min(startIndex,source.size()-1));
        ArrayList<MusicItem> ordered=new ArrayList<>();
        MusicItem chosen=source.get(selected); ordered.add(chosen);
        ArrayList<MusicItem> rest=new ArrayList<>();
        for(int i=selected+1;i<source.size();i++)rest.add(source.get(i));
        for(int i=0;i<selected;i++)rest.add(source.get(i));
        if(shuffleEnabled)Collections.shuffle(rest); ordered.addAll(rest);
        if(ordered.size()>100)ordered=new ArrayList<>(ordered.subList(0,100));
        queueItems.clear();queueItems.addAll(ordered);queueAdapter.notifyDataSetChanged();
        int generation=queueGeneration.incrementAndGet();
        playRequestPending=true; playPause.setEnabled(false); playPause.setText("…"); queuePlayPause.setText("…");
        nowTitle.setText(chosen.title); nowSub.setText("Preparando áudio...");
        if(!chosen.thumb.isEmpty()){Glide.with(this).load(chosen.thumb).centerCrop().into(nowThumb);if(coverBackgroundEnabled&&!lowRamMode){dynamicBackground.setVisibility(View.VISIBLE);Glide.with(this).load(chosen.thumb).centerCrop().dontAnimate().into(dynamicBackground);dynamicBackground.setAlpha(.38f);}}
        queueStatus.setText("Abrindo "+chosen.title+"...");
        final ArrayList<MusicItem> finalOrdered=ordered;
        new Thread(()->{
            MediaItem first=resolveMediaItem(chosen);
            if(first==null){runOnUiThread(()->{playRequestPending=false;playPause.setEnabled(true);playPause.setText("▶");queuePlayPause.setText("▶");nowSub.setText("Não foi possível tocar. Tente novamente.");Toast.makeText(this,"Falha ao abrir esta música",Toast.LENGTH_SHORT).show();});return;}
            runOnUiThread(()->{if(queueGeneration.get()!=generation)return;controller.setMediaItem(first);controller.prepare();controller.play();playPause.setEnabled(true);playPause.setText("❚❚");queuePlayPause.setText("❚❚");queueStatus.setText("Tocando agora • preparando próximas músicas...");});
            for(int i=1;i<finalOrdered.size();i++){
                if(queueGeneration.get()!=generation)return;
                MediaItem item=resolveMediaItem(finalOrdered.get(i));
                if(item!=null)runOnUiThread(()->{if(queueGeneration.get()==generation){controller.addMediaItem(item);updateQueueStatus();}});
            }
            runOnUiThread(()->{if(queueGeneration.get()==generation)updateQueueStatus();});
        }).start();
    }

    MediaItem resolveMediaItem(MusicItem x){
        try{
            String id=x.videoId.isEmpty()?x.id:x.videoId;
            CachedMedia cached=mediaCache.get(id);
            if(cached!=null&&cached.expiresAt>System.currentTimeMillis())return cached.item;
            String url="";String videoId=id;
            try{JSONObject src=new JSONObject(Net.getStream(BuildConfig.PANEL_URL+"/api/music/source.php?id="+URLEncoder.encode(id,"UTF-8")));url=src.optString("stream_url");videoId=src.optString("video_id",id);}catch(Exception ignored){}
            if(url.isEmpty())url=StreamResolver.resolveAudio(videoId);
            if(url==null||url.isEmpty())return null;
            MediaMetadata metadata=new MediaMetadata.Builder().setTitle(x.title).setArtist(x.subtitle).setArtworkUri(x.thumb.isEmpty()?null:Uri.parse(x.thumb)).build();
            MediaItem built=new MediaItem.Builder().setUri(url).setMediaId(x.id).setMediaMetadata(metadata).build(); mediaCache.put(id,new CachedMedia(built,System.currentTimeMillis()+8*60*1000L)); return built;
        }catch(Exception e){return null;}
    }



    String currentScreenName(){switch(currentTab){case 1:return "Buscar";case 2:return "Biblioteca";case 3:return "Lista";case 4:return "Conta";default:return "Início";}}
    void sendHeartbeat(){
        String user=getSharedPreferences("auth",MODE_PRIVATE).getString("user","");
        String device=getSharedPreferences("auth",MODE_PRIVATE).getString("device","");
        String token=getSharedPreferences("auth",MODE_PRIVATE).getString("token","");
        if(user.isEmpty()||device.isEmpty()||token.isEmpty())return;
        String title="",artist="",cover="",state="idle";long pos=0,dur=0;
        if(controller!=null){MediaMetadata m=controller.getMediaMetadata();title=m.title==null?"":m.title.toString();artist=m.artist==null?"":m.artist.toString();cover=m.artworkUri==null?"":m.artworkUri.toString();state=controller.isPlaying()?"playing":(controller.getPlaybackState()==Player.STATE_READY?"paused":"idle");pos=Math.max(0,controller.getCurrentPosition());dur=Math.max(0,controller.getDuration());}
        final String body;
        try{body="user="+URLEncoder.encode(user,"UTF-8")+"&device="+URLEncoder.encode(device,"UTF-8")+"&token="+URLEncoder.encode(token,"UTF-8")+"&device_name="+URLEncoder.encode(Build.MANUFACTURER+" "+Build.MODEL,"UTF-8")+"&platform=Android&app_version="+URLEncoder.encode(BuildConfig.VERSION_NAME,"UTF-8")+"&screen="+URLEncoder.encode(currentScreenName(),"UTF-8")+"&playback_state="+URLEncoder.encode(state,"UTF-8")+"&track_title="+URLEncoder.encode(title,"UTF-8")+"&track_artist="+URLEncoder.encode(artist,"UTF-8")+"&track_cover="+URLEncoder.encode(cover,"UTF-8")+"&position_ms="+pos+"&duration_ms="+dur;}catch(Exception e){return;}
        new Thread(()->{try{String raw=Net.post(BuildConfig.PANEL_URL+"/api/status.php",body);JSONObject st=new JSONObject(raw);if(!st.optBoolean("ok"))runOnUiThread(()->lockExpiredPlan());}catch(Exception ignored){}}).start();
    }

    void loadProfile(){
        String user=getSharedPreferences("auth",MODE_PRIVATE).getString("user","");
        if(user.isEmpty())return;
        new Thread(()->{try{JSONObject j=new JSONObject(Net.get(BuildConfig.PANEL_URL+"/api/client_profile.php?user="+URLEncoder.encode(user,"UTF-8")));if(!j.optBoolean("ok"))return;String plan=j.optString("plan","Sem plano");int days=j.optInt("days_remaining",0);String exp=j.optString("expires","");String renew=j.optString("renew_url",BuildConfig.PANEL_URL);String name=j.optString("name",user);String status=j.optString("status","");String ref=j.optString("referral_code","");String refUrl=j.optString("referral_link",j.optString("referral_url",""));int bonus=j.optInt("referral_bonus_days",0);if(refUrl.isEmpty()&&!ref.isEmpty())refUrl=BuildConfig.PANEL_URL+"/indicar.php?ref="+ref;final String finalRefUrl=refUrl;runOnUiThread(()->{planName.setText(plan); planExpiry.setText(days+" dias restantes • vence em "+exp); accountName.setText(name); accountUser.setText("@"+user); accountAvatar.setText(name.isEmpty()?"S":name.substring(0,1).toUpperCase()); boolean active=(status.equalsIgnoreCase("active")||status.equalsIgnoreCase("ativo"))&&days>0; subscriptionActive=active; if(!active)lockExpiredPlan(); planBadge.setText(active?"ATIVA":"INATIVA"); planBadge.setTextColor(Color.parseColor(active?"#7BF5A6":"#FF9CA9")); int max=Math.max(30,days); planProgress.setMax(max); planProgress.setProgress(Math.max(0,days)); accountStatus.setText("Assinatura "+(active?"ativa":"inativa")+"\nVencimento: "+exp+"\nRenovação disponível pelo próprio aplicativo"); accountReferral.setText("Seu código: "+ref+"\nBônus acumulado: "+bonus+" dias"); referralLink=finalRefUrl; inviteBtn.setVisibility(referralLink.isEmpty()?View.GONE:View.VISIBLE); renewBtn.setOnClickListener(v->openRenewal());});}catch(Exception ignored){}}).start();
    }

    void shareReferral(){
        if(referralLink==null||referralLink.trim().isEmpty()){Toast.makeText(this,"Link de indicação ainda não disponível",Toast.LENGTH_SHORT).show();return;}
        String code=accountReferral.getText().toString();
        Intent share=new Intent(Intent.ACTION_SEND);share.setType("text/plain");
        share.putExtra(Intent.EXTRA_TEXT, "Venha ouvir música no Spotnet Music e ganhe acesso pelo meu convite:\n" + referralLink + "\n\n" + code);
        startActivity(Intent.createChooser(share,"Compartilhar convite"));
    }

    void openRenewal(){
        new Thread(()->{try{JSONObject j=new JSONObject(Net.get(BuildConfig.PANEL_URL+"/api/plans.php"));JSONArray a=j.optJSONArray("plans");runOnUiThread(()->showPlanDialog(a));}catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Falha ao carregar planos: "+e.getMessage(),Toast.LENGTH_LONG).show());}}).start();
    }
    void showPlanDialog(JSONArray plans){
        if(plans==null||plans.length()==0){Toast.makeText(this,"Nenhum plano disponível",Toast.LENGTH_SHORT).show();return;}
        String[] labels=new String[plans.length()];for(int i=0;i<plans.length();i++){JSONObject p=plans.optJSONObject(i);labels[i]=p.optString("name")+" • R$ "+p.optString("price")+" • "+p.optInt("days")+" dias";}
        new AlertDialog.Builder(this).setTitle("Renovar assinatura").setSingleChoiceItems(labels,0,null).setPositiveButton("Continuar",(d,w)->{int pos=((AlertDialog)d).getListView().getCheckedItemPosition();JSONObject p=plans.optJSONObject(Math.max(0,pos));showGatewayDialog(p);}).setNegativeButton("Cancelar",null).show();
    }
    void showGatewayDialog(JSONObject plan){
        String[] gateways={"Mercado Pago • PIX","MisticPay • PIX"};
        new AlertDialog.Builder(this).setTitle(plan.optString("name")+" — R$ "+plan.optString("price")).setSingleChoiceItems(gateways,0,null).setPositiveButton("Gerar PIX",(d,w)->{int pos=((AlertDialog)d).getListView().getCheckedItemPosition();askPayerData(plan,pos==0?"mercadopago":"misticpay");}).setNegativeButton("Voltar",null).show();
    }
    void askPayerData(JSONObject plan,String gateway){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(20),dp(8),dp(20),0);
        EditText email=new EditText(this);email.setHint("E-mail");email.setInputType(android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);email.setText(getSharedPreferences("payer",MODE_PRIVATE).getString("email",""));box.addView(email);
        EditText doc=new EditText(this);doc.setHint("CPF ou CNPJ");doc.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);doc.setText(getSharedPreferences("payer",MODE_PRIVATE).getString("doc",""));box.addView(doc);
        new AlertDialog.Builder(this).setTitle("Dados para o PIX").setView(box).setPositiveButton("Gerar cobrança",(d,w)->createPix(plan,gateway,email.getText().toString().trim(),doc.getText().toString().trim())).setNegativeButton("Cancelar",null).show();
    }
    void createPix(JSONObject plan,String gateway,String email,String doc){
        String user=getSharedPreferences("auth",MODE_PRIVATE).getString("user","");String name=accountName.getText().toString();
        getSharedPreferences("payer",MODE_PRIVATE).edit().putString("email",email).putString("doc",doc).apply();
        Toast.makeText(this,"Gerando PIX...",Toast.LENGTH_SHORT).show();
        new Thread(()->{try{String body="user="+URLEncoder.encode(user,"UTF-8")+"&plan_id="+URLEncoder.encode(plan.optString("id"),"UTF-8")+"&gateway="+gateway+"&payer_name="+URLEncoder.encode(name,"UTF-8")+"&email="+URLEncoder.encode(email,"UTF-8")+"&document="+URLEncoder.encode(doc,"UTF-8");JSONObject j=new JSONObject(Net.post(BuildConfig.PANEL_URL+"/api/payment_create.php",body));if(!j.optBoolean("ok"))throw new Exception(j.optString("message"));runOnUiThread(()->showPixDialog(j));}catch(Exception e){runOnUiThread(()->new AlertDialog.Builder(this).setTitle("Não foi possível gerar o PIX").setMessage(e.getMessage()).setPositiveButton("OK",null).show());}}).start();
    }
    void showPixDialog(JSONObject payment){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(22),dp(8),dp(22),0);
        TextView amount=new TextView(this);amount.setText(payment.optString("plan")+"\nR$ "+payment.optString("amount"));amount.setTextColor(Color.WHITE);amount.setTextSize(22);amount.setTypeface(null,1);box.addView(amount);
        EditText code=new EditText(this);code.setText(payment.optString("pix_code"));code.setTextColor(Color.WHITE);code.setMinLines(4);code.setSelectAllOnFocus(true);box.addView(code);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("PIX gerado dentro do aplicativo").setView(box).setPositiveButton("Copiar código",null).setNeutralButton("Verificar pagamento",null).setNegativeButton("Fechar",null).create();
        dialog.setOnShowListener(x->{dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{ClipboardManager cm=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);cm.setPrimaryClip(ClipData.newPlainText("PIX",code.getText()));Toast.makeText(this,"Código PIX copiado",Toast.LENGTH_SHORT).show();});dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v->checkPayment(payment.optString("payment_id"),dialog));});dialog.show();
    }
    void checkPayment(String id,AlertDialog dialog){String user=getSharedPreferences("auth",MODE_PRIVATE).getString("user","");new Thread(()->{try{JSONObject j=new JSONObject(Net.get(BuildConfig.PANEL_URL+"/api/payment_status.php?id="+URLEncoder.encode(id,"UTF-8")+"&user="+URLEncoder.encode(user,"UTF-8")));runOnUiThread(()->{if(j.optBoolean("approved")){Toast.makeText(this,"Pagamento aprovado. Plano renovado!",Toast.LENGTH_LONG).show();dialog.dismiss();loadProfile();}else Toast.makeText(this,"Pagamento ainda pendente",Toast.LENGTH_SHORT).show();});}catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Falha ao verificar pagamento",Toast.LENGTH_SHORT).show());}}).start();}

    void jumpToQueueItem(int index){if(controller!=null&&index>=0&&index<controller.getMediaItemCount()){controller.seekToDefaultPosition(index);controller.play();}}
    void toggleShuffle(){shuffleEnabled=!shuffleEnabled;shuffleBtn.setText(shuffleEnabled?"🔀 ON":"🔀");shuffleBtn.setAlpha(shuffleEnabled?1f:.65f);updateQueueStatus();}
    void toggle(){if(!subscriptionActive){tab(4);Toast.makeText(this,"Plano vencido. Renove para voltar a ouvir.",Toast.LENGTH_LONG).show();return;}if(controller==null||playRequestPending)return;if(controller.isPlaying()){controller.pause();playPause.setText("▶");queuePlayPause.setText("▶");}else{playPause.setText("…");queuePlayPause.setText("…");controller.play();}}
    int dp(int v){return (int)(v*getResources().getDisplayMetrics().density);}


    SearchAdapter.Favorite favoriteHandler(){return new SearchAdapter.Favorite(){public boolean isFavorite(MusicItem x){return getSharedPreferences("favorites",MODE_PRIVATE).contains(x.id);}public void toggle(MusicItem x){android.content.SharedPreferences p=getSharedPreferences("favorites",MODE_PRIVATE);if(p.contains(x.id))p.edit().remove(x.id).apply();else{try{JSONObject j=new JSONObject();j.put("id",x.id);j.put("video_id",x.videoId);j.put("type",x.type);j.put("title",x.title);j.put("subtitle",x.subtitle);j.put("thumbnail",x.thumb);p.edit().putString(x.id,j.toString()).apply();}catch(Exception ignored){}}syncLibrary(x);}};}
    void syncLibrary(MusicItem x){String user=getSharedPreferences("auth",MODE_PRIVATE).getString("user","");boolean add=getSharedPreferences("favorites",MODE_PRIVATE).contains(x.id);new Thread(()->{try{String body="user="+URLEncoder.encode(user,"UTF-8")+"&action="+(add?"add":"remove")+"&item="+URLEncoder.encode(new JSONObject().put("id",x.id).put("video_id",x.videoId).put("title",x.title).put("subtitle",x.subtitle).put("thumbnail",x.thumb).toString(),"UTF-8");Net.post(BuildConfig.PANEL_URL+"/api/user_library.php",body);}catch(Exception ignored){}}).start();}
    void showLibrary(){queueItems.clear();android.content.SharedPreferences p=getSharedPreferences("favorites",MODE_PRIVATE);for(String key:p.getAll().keySet())try{JSONObject x=new JSONObject(p.getString(key,"{}"));queueItems.add(parse(x));}catch(Exception ignored){}queueAdapter.notifyDataSetChanged();queueStatus.setText(queueItems.isEmpty()?"Você ainda não curtiu nenhuma música.":queueItems.size()+" músicas curtidas • toque para ouvir");}
    void saveSearchHistory(String q){android.content.SharedPreferences p=getSharedPreferences("search_history",MODE_PRIVATE);long now=System.currentTimeMillis();p.edit().putLong(q,now).apply();renderSearchHistory();String user=getSharedPreferences("auth",MODE_PRIVATE).getString("user","");new Thread(()->{try{Net.post(BuildConfig.PANEL_URL+"/api/user_library.php","user="+URLEncoder.encode(user,"UTF-8")+"&action=search&query="+URLEncoder.encode(q,"UTF-8"));}catch(Exception ignored){}}).start();}
    void renderSearchHistory(){if(recentSearches==null)return;recentSearches.removeAllViews();Map<String,?> all=getSharedPreferences("search_history",MODE_PRIVATE).getAll();ArrayList<String> keys=new ArrayList<>(all.keySet());Collections.sort(keys,(a,b)->Long.compare((Long)all.get(b),(Long)all.get(a)));for(int i=0;i<Math.min(8,keys.size());i++){String q=keys.get(i);TextView chip=new TextView(this);chip.setText("  "+q+"  ");chip.setTextColor(getColor(R.color.white));chip.setGravity(android.view.Gravity.CENTER);chip.setBackgroundResource(R.drawable.outline_button);chip.setOnClickListener(v->{searchInput.setText(q);search();});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,dp(40));lp.setMargins(0,0,dp(8),0);recentSearches.addView(chip,lp);}}
    void lockExpiredPlan(){subscriptionActive=false;if(controller!=null){controller.pause();controller.clearMediaItems();}stopService(new Intent(this,PlaybackService.class));nowTitle.setText("Plano vencido");nowSub.setText("Renove sua assinatura para continuar");playPause.setText("▶");tab(4);}
    @Override protected void onResume(){super.onResume();loadProfile();renderSearchHistory();sendHeartbeat();}
    @Override protected void onDestroy(){heartbeatHandler.removeCallbacks(heartbeatTask);if(controllerFuture!=null)MediaController.releaseFuture(controllerFuture);super.onDestroy();}
}
