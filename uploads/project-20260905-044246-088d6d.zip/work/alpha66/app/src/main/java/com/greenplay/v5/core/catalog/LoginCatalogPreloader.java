package com.greenplay.v5.core.catalog;

import android.content.Context;
import com.greenplay.v5.data.model.movie.Movie;
import com.greenplay.v5.data.model.movie.MovieCategory;
import com.greenplay.v5.data.model.series.SeriesCategory;
import com.greenplay.v5.data.model.series.SeriesItem;
import com.greenplay.v5.data.model.tv.TvChannel;
import com.greenplay.v5.data.repository.MovieRepository;
import com.greenplay.v5.data.repository.SeriesRepository;
import com.greenplay.v5.data.repository.TvRepository;
import com.greenplay.v5.ui.movies.MovieCacheStore;
import com.greenplay.v5.ui.series.SeriesCacheStore;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Loads the three complete Xtream catalogs before the first app screen opens. */
public final class LoginCatalogPreloader {
    public interface Listener { void status(String text); void success(); void error(String message); }
    private final Context app; private final String host,user,pass; private final Listener listener;
    private boolean tvDone=false,moviesDone=false,seriesDone=false,movieCategoriesDone=false,seriesCategoriesDone=false,failed=false,finishing=false;
    private static final ExecutorService CACHE_IO = Executors.newSingleThreadExecutor();
    private static final ExecutorService INDEX_IO = Executors.newSingleThreadExecutor();

    public LoginCatalogPreloader(Context context,String host,String user,String pass,Listener listener){this.app=context.getApplicationContext();this.host=host;this.user=user;this.pass=pass;this.listener=listener;}

    public void start(){
        CatalogMemory.clear(); CatalogBackgroundPrime.reset();
        listener.status("Carregando canais...");
        loadTv(); loadMovies(); loadSeries();
    }

    private void loadTv(){new TvRepository(host,user,pass).channels("",new TvRepository.ChannelsResult(){
        @Override public void success(List<TvChannel> rows){synchronized(LoginCatalogPreloader.this){if(failed)return;if(rows==null||rows.isEmpty()){fail("Nenhum canal recebido do servidor");return;}CatalogMemory.setChannels(rows);tvDone=true;progress();}}
        @Override public void error(String message){fail(message);}
    });}

    private void loadMovies(){MovieRepository repo=new MovieRepository(host,user,pass);MovieCacheStore cache=new MovieCacheStore(app,host,user);
        repo.categories(new MovieRepository.CategoriesResult(){@Override public void success(List<MovieCategory> rows){synchronized(LoginCatalogPreloader.this){if(failed)return;CatalogMemory.setMovieCategories(rows);movieCategoriesDone=true;progress();CACHE_IO.execute(() -> cache.saveCategories(rows));}}@Override public void error(String message){fail(message);}});
        repo.moviesProgressive("",48,240,new MovieRepository.ProgressiveMoviesResult(){
            @Override public void partial(List<Movie> rows){}
            @Override public void success(List<Movie> rows){synchronized(LoginCatalogPreloader.this){if(failed)return;if(rows==null){fail("Filmes indisponíveis");return;}CatalogMemory.setMovies(rows);moviesDone=true;progress();CACHE_IO.execute(() -> cache.saveMovies(rows));}}
            @Override public void error(String message){fail(message);}
        });
    }

    private void loadSeries(){SeriesRepository repo=new SeriesRepository(host,user,pass);SeriesCacheStore cache=new SeriesCacheStore(app,host,user);
        repo.categories(new SeriesRepository.CategoriesResult(){@Override public void success(List<SeriesCategory> rows){synchronized(LoginCatalogPreloader.this){if(failed)return;CatalogMemory.setSeriesCategories(rows);seriesCategoriesDone=true;progress();CACHE_IO.execute(() -> cache.saveCategories(rows));}}@Override public void error(String message){fail(message);}});
        repo.seriesProgressive("",48,240,new SeriesRepository.ProgressiveSeriesResult(){
            @Override public void partial(List<SeriesItem> rows){}
            @Override public void success(List<SeriesItem> rows){synchronized(LoginCatalogPreloader.this){if(failed)return;if(rows==null){fail("Séries indisponíveis");return;}CatalogMemory.setSeries(rows);seriesDone=true;progress();CACHE_IO.execute(() -> cache.saveSeries(rows));}}
            @Override public void error(String message){fail(message);}
        });
    }

    private void progress(){
        if(failed)return;
        if(tvDone&&moviesDone&&seriesDone&&movieCategoriesDone&&seriesCategoriesDone){
            if(finishing)return;
            finishing=true;
            listener.status("Organizando catálogo...");
            INDEX_IO.execute(() -> {
                try { SpecialCatalogIndex.rebuild(); }
                catch (Exception ignored) { }
                synchronized (LoginCatalogPreloader.this) {
                    if (failed) return;
                }
                listener.status("Tudo carregado. Entrando...");
                listener.success();
            });
            return;
        }
        if(!tvDone)listener.status("Carregando canais...");
        else if(!moviesDone&&!seriesDone)listener.status("Canais carregados • carregando filmes e séries...");
        else if(!moviesDone)listener.status("Canais e séries carregados • carregando filmes...");
        else if(!seriesDone)listener.status("Canais e filmes carregados • carregando séries...");
    }

    private synchronized void fail(String message){if(failed)return;failed=true;CatalogMemory.clear();listener.error(message==null||message.trim().isEmpty()?"Falha ao preparar o catálogo":message);}
}
