GreenPlay 5.28.27

- Filmes, Séries e GreenShorts passam a ser preparados como um snapshot atômico antes da Home.
- Nada de categorias/cards aparecendo aos poucos enquanto a tela já está aberta.
- A sincronização completa usa até 12 categorias em paralelo e o snapshot fica salvo por servidor.
- Reels Shorts/GreenShorts abre o player em pé (portrait) no celular.
- Em Android TV/TV Box o player continua landscape.
- Mantida a filtragem que impede filmes/shorts de entrarem na aba TV.
