package com.greenplay.v5.ui.home;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.greenplay.v5.databinding.ActivityHomeBinding;

public final class HomeActivity extends AppCompatActivity {
    private ActivityHomeBinding b;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        b = ActivityHomeBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        bindNav();
    }
    private void bindNav() {
        b.navTv.setOnClickListener(v -> select("TV"));
        b.navFootball.setOnClickListener(v -> select("FUTEBOL"));
        b.navMovies.setOnClickListener(v -> select("FILMES"));
        b.navSeries.setOnClickListener(v -> select("SÉRIES"));
        b.navKids.setOnClickListener(v -> select("KIDS"));
        b.navAnime.setOnClickListener(v -> select("ANIME"));
        b.navHot.setOnClickListener(v -> select("HOT"));
    }
    private void select(String name) {
        b.screenTitle.setText(name);
        Toast.makeText(this, name + " — módulo V5 isolado", Toast.LENGTH_SHORT).show();
    }
}
