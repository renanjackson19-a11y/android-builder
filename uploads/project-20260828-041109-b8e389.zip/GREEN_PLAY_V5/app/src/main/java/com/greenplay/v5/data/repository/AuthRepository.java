package com.greenplay.v5.data.repository;

import android.content.Context;
import com.greenplay.v5.core.network.NetworkProvider;
import com.greenplay.v5.core.session.SessionStore;
import com.greenplay.v5.data.model.LoginResponse;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public final class AuthRepository {
    public interface Result { void success(LoginResponse login); void error(String message); }
    private final Context appContext;
    private final SessionStore session;

    public AuthRepository(Context context) {
        appContext = context.getApplicationContext();
        session = new SessionStore(appContext);
    }

    public void login(String user, String pass, String deviceId, Result result) {
        NetworkProvider.panel().login(user, pass, deviceId).enqueue(new Callback<LoginResponse>() {
            @Override public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                LoginResponse body = response.body();
                if (!response.isSuccessful() || body == null) { result.error("Falha ao consultar o painel"); return; }
                if (!body.ok) { result.error(body.message == null ? "Acesso negado" : body.message); return; }
                String xtreamPass = body.xtreamPassword == null || body.xtreamPassword.isEmpty() ? pass : body.xtreamPassword;
                // Host será preenchido pela resposta do painel ou por configuração oficial na etapa de integração.
                String host = body.xtreamHost == null ? "" : body.xtreamHost;
                session.save(host, body.username, xtreamPass, body.expiresAt, body.plan, body.adultAccess, body.userToken);
                result.success(body);
            }
            @Override public void onFailure(Call<LoginResponse> call, Throwable t) { result.error("Sem conexão com o painel"); }
        });
    }
}
