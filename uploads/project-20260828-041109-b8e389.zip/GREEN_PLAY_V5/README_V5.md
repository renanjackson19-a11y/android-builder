# GREEN PLAY V5 — BASE NOVA

Esta pasta é um projeto novo. Nenhuma Activity, Adapter, cache, player ou classe do V4 foi copiada.

## Objetivo da arquitetura
- Painel existente tratado como contrato externo, sem alterações destrutivas.
- Xtream separado da API do painel.
- Sessão isolada.
- Catálogos isolados por domínio: TV, Filmes, Séries, Kids, Anime, HOT.
- Player independente usando Media3.
- Navegação pensada para controle remoto/TV Box.
- Cada módulo pode falhar sem derrubar os demais.

## Estado desta primeira base
1. Projeto Android V5 criado com namespace novo `com.greenplay.v5`.
2. `applicationId` mantido como o app anterior apenas para permitir continuidade futura; assinatura NÃO foi copiada.
3. Cliente do painel criado apenas para `status.php`, `login.php` e `trial.php`.
4. Cliente Xtream criado para autenticação, listas, detalhes de VOD/séries e EPG curto.
5. `StreamUrlFactory` novo para live/movie/series.
6. Sessão V5 nova e independente.
7. Login e shell visual inicial criados do zero, inspirados apenas nas imagens de referência.
8. Player V5 mínimo criado do zero.

## Próxima etapa técnica
Conectar o contrato real do painel sem guardar chaves dentro do código-fonte, validar resposta de login e então implementar TV completa (categorias + lista + preview + EPG) como primeiro módulo funcional.
