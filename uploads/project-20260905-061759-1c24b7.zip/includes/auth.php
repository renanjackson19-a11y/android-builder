<?php
function gp_app_auth(){global $config;$got=trim((string)($_SERVER['HTTP_X_APP_TOKEN']??($_GET['app_token']??'')));$dedicated='CTAdcb_S0Y7Sjnpx7w3F8c-v7rW6sA9lxkhkcvVAWuQ';$admin=(string)($config['security']['api_key']??'');return ($got!==''&&hash_equals($dedicated,$got))||($admin!==''&&hash_equals($admin,$got));}
function gp_require_app(){if(!gp_app_auth())gp_json(['ok'=>false,'message'=>'App não autorizado'],401);}
function gp_user_from_token(PDO $pdo){$token=trim((string)($_SERVER['HTTP_X_USER_TOKEN']??($_GET['user_token']??'')));if($token==='')return null;$hash=hash('sha256',$token);try{$st=$pdo->prepare("SELECT u.id user_id,u.username,u.reseller_id,u.plan_id,u.bouquet_id,u.status,u.expires_at,u.max_connections FROM user_api_sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>NOW() AND u.status='active' AND (u.expires_at IS NULL OR u.expires_at>NOW()) LIMIT 1");$st->execute([$hash]);$u=$st->fetch();if(!$u)return null;$adult=0;$name='';if(!empty($u['bouquet_id'])){$b=$pdo->prepare('SELECT name,adult_access FROM bouquets WHERE id=? AND active=1 LIMIT 1');$b->execute([(int)$u['bouquet_id']]);$r=$b->fetch();if($r){$adult=(int)$r['adult_access'];$name=$r['name'];}}elseif(!empty($u['plan_id'])){$b=$pdo->prepare('SELECT b.name,b.adult_access,b.id FROM plans p LEFT JOIN bouquets b ON b.id=p.bouquet_id WHERE p.id=? LIMIT 1');$b->execute([(int)$u['plan_id']]);$r=$b->fetch();if($r){$adult=(int)$r['adult_access'];$name=(string)$r['name'];$u['bouquet_id']=(int)$r['id'];}}$u['adult_access']=$adult;$u['bouquet_name']=$name;return $u;}catch(Throwable $e){return null;}}
function gp_require_user(PDO $pdo){$u=gp_user_from_token($pdo);if(!$u)gp_json(['ok'=>false,'message'=>'Sessão expirada'],401);return $u;}
function gp_new_user_token(PDO $pdo,$uid){$raw=bin2hex(random_bytes(32));$hash=hash('sha256',$raw);$pdo->prepare('DELETE FROM user_api_sessions WHERE user_id=? OR expires_at<=NOW()')->execute([$uid]);$pdo->prepare('INSERT INTO user_api_sessions(user_id,token_hash,expires_at) VALUES(?,?,DATE_ADD(NOW(),INTERVAL 30 DAY))')->execute([$uid,$hash]);return $raw;}


function gp_catalog_revision(PDO $pdo): int {
  try{$q=$pdo->prepare("SELECT value FROM settings WHERE `key`='catalog_revision' LIMIT 1");$q->execute();$v=(int)($q->fetchColumn()?:1);return max(1,$v);}catch(Throwable $e){return 1;}
}
function gp_bump_catalog_revision(PDO $pdo): int {
  try{
    $pdo->exec("CREATE TABLE IF NOT EXISTS settings(`key` VARCHAR(100) PRIMARY KEY,value LONGTEXT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $r=gp_catalog_revision($pdo)+1;
    $q=$pdo->prepare("INSERT INTO settings(`key`,value) VALUES('catalog_revision',?) ON DUPLICATE KEY UPDATE value=VALUES(value)");$q->execute([(string)$r]);return $r;
  }catch(Throwable $e){return (int)time();}
}

function gp_user_allowed_category_ids(PDO $pdo,array $u):array{
  $bid=(int)($u['bouquet_id']??0);
  if($bid<=0)return [];
  try{
    $q=$pdo->prepare('SELECT DISTINCT bc.category_id FROM bouquet_categories bc JOIN bouquets b ON b.id=bc.bouquet_id AND b.active=1 JOIN gp_categories c ON c.id=bc.category_id AND c.enabled=1 JOIN gp_sources s ON s.id=c.source_id AND s.active=1 WHERE bc.bouquet_id=?');
    $q->execute([$bid]);
    $ids=array_values(array_unique(array_map('intval',$q->fetchAll(PDO::FETCH_COLUMN))));

    // V9.0.93: "Permitir conteúdo +18" funciona como uma permissão real de HOT.
    // Não exige que o administrador marque manualmente uma a uma as categorias adultas.
    // Por segurança, só amplia FILMES/SÉRIES adultas das mesmas fontes que já fazem
    // parte do bouquet; canais LIVE continuam obedecendo a seleção explícita.
    if((int)($u['adult_access']??0)===1 && $ids){
      $ph=implode(',',array_fill(0,count($ids),'?'));
      $src=$pdo->prepare("SELECT DISTINCT source_id FROM gp_categories WHERE id IN ($ph)");
      $src->execute($ids);
      $sourceIds=array_values(array_filter(array_unique(array_map('intval',$src->fetchAll(PDO::FETCH_COLUMN)))));
      if($sourceIds){
        $sph=implode(',',array_fill(0,count($sourceIds),'?'));
        $qa=$pdo->prepare("SELECT c.id,c.name,c.source_name,c.is_adult FROM gp_categories c JOIN gp_sources s ON s.id=c.source_id AND s.active=1 WHERE c.enabled=1 AND c.type IN ('movie','series') AND c.source_id IN ($sph)");
        $qa->execute($sourceIds);
        $adultIds=[];
        foreach($qa->fetchAll() as $c){
          $flag=(int)($c['is_adult']??0)===1;
          $label=trim((string)($c['source_name']??''));if($label==='')$label=(string)($c['name']??'');
          if(!$flag && function_exists('gp_is_adult_name'))$flag=gp_is_adult_name($label);
          if($flag)$adultIds[]=(int)$c['id'];
        }
        $ids=array_values(array_unique(array_merge($ids,$adultIds)));
      }
    }
    return $ids;
  }catch(Throwable $e){return [];}
}
function gp_sql_in_ids(array $ids):string{return $ids?implode(',',array_fill(0,count($ids),'?')):'NULL';}
