<?php
require_once __DIR__.'/bootstrap.php';
function gp_xtream_bouquet_adult_access(PDO $pdo,int $bouquetId): int {
  if($bouquetId<=0)return 0;
  try{
    $q=$pdo->prepare('SELECT adult_access FROM bouquets WHERE id=? AND active=1');$q->execute([$bouquetId]);
    if((int)($q->fetchColumn()?:0)===1)return 1;
    // Compatibilidade: bouquets antigos podem já conter categoria adulta mas terem
    // sido criados antes do campo adult_access ser usado corretamente.
    $q=$pdo->prepare("SELECT c.name,c.source_name,c.is_adult FROM bouquet_categories bc JOIN gp_categories c ON c.id=bc.category_id AND c.enabled=1 WHERE bc.bouquet_id=? AND c.type IN ('movie','series')");
    $q->execute([$bouquetId]);
    foreach($q->fetchAll() as $c){
      if((int)($c['is_adult']??0)===1)return 1;
      $label=trim((string)($c['source_name']??''));if($label==='')$label=(string)($c['name']??'');
      if(function_exists('gp_is_adult_name') && gp_is_adult_name($label))return 1;
    }
  }catch(Throwable $e){}
  return 0;
}

function gp_xtream_auth(PDO $pdo,$username,$password){
  $st=$pdo->prepare("SELECT u.*,p.name plan_name,p.bouquet_id plan_bouquet FROM users u LEFT JOIN plans p ON p.id=u.plan_id WHERE u.username=? LIMIT 1");
  $st->execute([trim((string)$username)]); $u=$st->fetch();
  if(!$u || !password_verify((string)$password,(string)$u['password_hash'])) return null;
  if(($u['status']??'')!=='active') return null;
  if(!empty($u['expires_at']) && strtotime($u['expires_at'])<time()) return null;
  if(empty($u['bouquet_id'])&&!empty($u['plan_bouquet']))$u['bouquet_id']=$u['plan_bouquet'];
  $u['adult_access']=0;
  if(!empty($u['bouquet_id'])){$u['adult_access']=gp_xtream_bouquet_adult_access($pdo,(int)$u['bouquet_id']);}
  return $u;
}

function gp_xtream_auth_reference(PDO $pdo,$username,$password){
  $st=$pdo->prepare("SELECT u.*,p.name plan_name,p.bouquet_id plan_bouquet FROM users u LEFT JOIN plans p ON p.id=u.plan_id WHERE u.username=? LIMIT 1");
  $st->execute([trim((string)$username)]);$u=$st->fetch();
  if(!$u || !password_verify((string)$password,(string)$u['password_hash']))return null;
  if(empty($u['bouquet_id'])&&!empty($u['plan_bouquet']))$u['bouquet_id']=$u['plan_bouquet'];
  $u['adult_access']=0;
  if(!empty($u['bouquet_id'])){
    $u['adult_access']=gp_xtream_bouquet_adult_access($pdo,(int)$u['bouquet_id']);
  }
  return $u;
}

function gp_xtream_source(PDO $pdo,$sourceId){
  $q=$pdo->prepare('SELECT * FROM gp_sources WHERE id=? AND active=1 LIMIT 1');$q->execute([(int)$sourceId]);$s=$q->fetch();if(!$s)return null;
  // Instalações anteriores podem ter importado uma get.php como Xtream sem persistir a conversão.
  if(($s['source_type']??'')!=='xtream' && !empty($s['m3u_url'])){
    $parts=@parse_url((string)$s['m3u_url']);$qq=[];parse_str((string)($parts['query']??''),$qq);
    $u=(string)($qq['username']??$qq['user']??'');$p=(string)($qq['password']??$qq['pass']??'');
    if($parts && !empty($parts['scheme']) && !empty($parts['host']) && $u!=='' && $p!==''){
      $host=$parts['scheme'].'://'.$parts['host'];if(!empty($parts['port']))$host.=':'.$parts['port'];
      $epg=$host.'/xmltv.php?username='.rawurlencode($u).'&password='.rawurlencode($p);
      $s['source_type']='xtream';$s['host']=$host;$s['username']=$u;$s['password']=$p;$s['epg_url']=$s['epg_url']?:$epg;
      try{$pdo->prepare("UPDATE gp_sources SET source_type='xtream',host=?,username=?,password=?,epg_url=? WHERE id=?")->execute([$host,$u,$p,$s['epg_url'],(int)$sourceId]);}catch(Throwable $e){}
    }
  }
  return $s;
}
function gp_xtream_root(){global $config;return function_exists('gp_request_public_base_url')?rtrim(gp_request_public_base_url(),'/'):rtrim((string)($config['app']['base_url']??''),'/');}
function gp_reference_stream_host(array $src){
  $base=rtrim((string)($src['host']??''),'/');
  $host=(string)(parse_url($base,PHP_URL_HOST)??'');
  if($host==='')return $base;
  // O painel de referência reconstrói Live/VOD em HTTP no domínio da fonte.
  return 'http://'.$host;
}
function gp_parse_original_stream_url($url){
  $p=@parse_url(trim((string)$url));
  if(!$p || empty($p['host']) || empty($p['path'])) return null;
  $parts=explode('/',trim((string)$p['path'],'/'));
  $user='';$pass='';$file='';
  // Same rule used by server 15-11 processarUrl():
  // /live/user/pass/123.ts OR /user/pass/123.ts
  if(count($parts)>=4){
    $user=(string)($parts[1]??'');
    $pass=(string)($parts[2]??'');
    $file=(string)($parts[3]??'');
  }elseif(count($parts)>=3){
    $user=(string)($parts[0]??'');
    $pass=(string)($parts[1]??'');
    $file=(string)($parts[2]??'');
  }else return null;
  $id=pathinfo($file,PATHINFO_FILENAME);
  if($id==='' || !ctype_digit((string)$id)) return null;
  $scheme=strtolower((string)($p['scheme']??'http'));
  if(!in_array($scheme,['http','https'],true))$scheme='http';
  $port=isset($p['port'])?(':'.(int)$p['port']):'';
  return [
    'scheme'=>$scheme,
    'host'=>(string)$p['host'].$port,
    'username'=>$user,
    'password'=>$pass,
    'id'=>$id
  ];
}
function gp_reference_candidates_from_direct($direct,$kind,$requestedExt){
  $d=gp_parse_original_stream_url($direct);
  if(!$d)return [];
  $ext=preg_replace('/[^a-zA-Z0-9]/','',(string)$requestedExt);
  if($ext==='')$ext=($kind==='live'?'ts':'mp4');
  $host=preg_replace('/:\\d+$/','',(string)$d['host']);
  $url='http://'.$host.'/'.$kind.'/'.rawurlencode($d['username']).'/'.rawurlencode($d['password']).'/'.rawurlencode($d['id']).'.'.$ext;
  return [$url];
}


function gp_extract_redirect_from_html($html,$baseUrl=''){
  $html=(string)$html;
  if($html==='')return '';

  $candidates=[];

  // meta refresh
  if(preg_match('~<meta[^>]+http-equiv=["\']?refresh["\']?[^>]+content=["\'][^"\']*url\s*=\s*([^"\'>]+)~i',$html,$m)){
    $candidates[]=trim(html_entity_decode($m[1],ENT_QUOTES|ENT_HTML5,'UTF-8'));
  }

  // window.location / location.href / location.replace(...)
  $patterns=[
    '~(?:window\.)?location(?:\.href)?\s*=\s*["\']([^"\']+)["\']~i',
    '~(?:window\.)?location\.replace\(\s*["\']([^"\']+)["\']\s*\)~i',
    '~(?:window\.)?location\.assign\(\s*["\']([^"\']+)["\']\s*\)~i'
  ];
  foreach($patterns as $p){
    if(preg_match_all($p,$html,$mm)){
      foreach($mm[1] as $u)$candidates[]=trim(html_entity_decode($u,ENT_QUOTES|ENT_HTML5,'UTF-8'));
    }
  }

  // Any absolute URL containing a token is preferred.
  if(preg_match_all('~https?://[^\s"\'<>\\\\]+~i',$html,$mm)){
    foreach($mm[0] as $u){
      $u=str_replace('\\/','/',$u);
      $candidates[]=trim(html_entity_decode($u,ENT_QUOTES|ENT_HTML5,'UTF-8'));
    }
  }

  // de-duplicate
  $seen=[];$clean=[];
  foreach($candidates as $u){
    $u=str_replace('\\/','/',$u);
    if($u===''||isset($seen[$u]))continue;
    $seen[$u]=1;$clean[]=$u;
  }

  foreach($clean as $u){
    if(strpos($u,'token=')!==false && preg_match('~^https?://~i',$u))return $u;
  }
  foreach($clean as $u){
    if(preg_match('~^https?://~i',$u))return $u;
  }

  return '';
}

function gp_probe_html_redirect($url){
  if(!function_exists('curl_init'))return '';
  $headers=[];
  $body='';
  $ch=curl_init($url);
  curl_setopt_array($ch,[
    CURLOPT_RETURNTRANSFER=>true,
    CURLOPT_FOLLOWLOCATION=>false,
    CURLOPT_CONNECTTIMEOUT=>10,
    CURLOPT_TIMEOUT=>20,
    CURLOPT_USERAGENT=>'XCIPTV',
    CURLOPT_HTTPHEADER=>[
      'Accept: */*',
      'Connection: keep-alive'
    ],
    CURLOPT_RANGE=>'0-131071',
    CURLOPT_SSL_VERIFYPEER=>true,
    CURLOPT_SSL_VERIFYHOST=>2
  ]);
  $body=@curl_exec($ch);
  $code=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);
  $ctype=(string)curl_getinfo($ch,CURLINFO_CONTENT_TYPE);
  curl_close($ch);

  if($code===200 && stripos($ctype,'text/html')!==false && is_string($body)){
    return gp_extract_redirect_from_html(substr($body,0,131072),$url);
  }
  return '';
}


function gp_resolve_provider_redirect($url){
  // 1) Primeiro: comportamento do server 15-11.
  $options=[
    'http'=>[
      'method'=>'GET',
      'header'=>"User-Agent: XCIPTV\r\n",
      'timeout'=>15,
      'ignore_errors'=>true
    ]
  ];
  $context=stream_context_create($options);
  $headers=@get_headers($url,1,$context);

  if($headers!==false){
    $locations=[];
    if(isset($headers['Location'])){
      $locations=is_array($headers['Location'])?$headers['Location']:[$headers['Location']];
    }elseif(isset($headers['location'])){
      $locations=is_array($headers['location'])?$headers['location']:[$headers['location']];
    }

    // getHeadersAsJson() da referência filtra Location com token=.
    foreach($locations as $location){
      $location=trim((string)$location);
      if($location!=='' && strpos($location,'token=')!==false)return $location;
    }
    if(!empty($locations)){
      $first=trim((string)$locations[0]);
      if($first!=='')return $first;
    }

    $status=(string)($headers[0]??'');
    $ctype='';
    if(isset($headers['Content-Type']))$ctype=is_array($headers['Content-Type'])?end($headers['Content-Type']):$headers['Content-Type'];
    elseif(isset($headers['content-type']))$ctype=is_array($headers['content-type'])?end($headers['content-type']):$headers['content-type'];

    // 2) Compatibilidade adicional: a fonte atual às vezes responde 200 HTML.
    // Nesse caso, não tratamos HTML como vídeo; procuramos o destino real no corpo.
    if(preg_match('~\s200\s~',$status) && stripos((string)$ctype,'text/html')!==false){
      $htmlRedirect=gp_probe_html_redirect($url);
      if($htmlRedirect!=='')return $htmlRedirect;
      return '';
    }

    if(preg_match('~\s2\d\d\s~',$status))return $url;
  }

  // Último fallback VOD: cURL mínimo para descobrir URL efetiva.
  if(function_exists('curl_init')){
    $ch=curl_init($url);
    curl_setopt_array($ch,[
      CURLOPT_RETURNTRANSFER=>true,
      CURLOPT_FOLLOWLOCATION=>true,
      CURLOPT_MAXREDIRS=>8,
      CURLOPT_CONNECTTIMEOUT=>10,
      CURLOPT_TIMEOUT=>20,
      CURLOPT_USERAGENT=>'XCIPTV',
      CURLOPT_RANGE=>'0-1',
      CURLOPT_HTTPHEADER=>['Accept: */*','Connection: keep-alive'],
      CURLOPT_SSL_VERIFYPEER=>true,
      CURLOPT_SSL_VERIFYHOST=>2
    ]);
    @curl_exec($ch);
    $code=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);
    $ctype=(string)curl_getinfo($ch,CURLINFO_CONTENT_TYPE);
    $effective=(string)curl_getinfo($ch,CURLINFO_EFFECTIVE_URL);
    curl_close($ch);

    if($code>=200 && $code<400 && stripos($ctype,'text/html')===false && $effective!=='')return $effective;
  }

  return '';
}
function gp_try_stream_origins(array $origins){
  $seen=[];
  foreach($origins as $origin){
    $origin=trim((string)$origin);if($origin===''||isset($seen[$origin]))continue;$seen[$origin]=1;
    $r=gp_resolve_provider_redirect($origin);if($r!=='')return $r;
  }
  foreach(array_keys($seen) as $origin)return $origin;
  return '';
}
function gp_redirect_source(PDO $pdo,$kind,$internalId,$ext){
  if($kind==='series'){
    $q=$pdo->prepare('SELECT e.*,s.source_id FROM gp_episodes e JOIN gp_series s ON s.id=e.series_id WHERE e.id=? AND e.active=1 LIMIT 1');
    $q->execute([(int)$internalId]);$row=$q->fetch();
  }else{
    $q=$pdo->prepare('SELECT * FROM gp_items WHERE id=? AND type=? AND active=1 LIMIT 1');
    $q->execute([(int)$internalId,$kind]);$row=$q->fetch();
  }
  if(!$row)return '';

  $src=gp_xtream_source($pdo,(int)$row['source_id']);if(!$src)return '';
  $pid=(string)($row['provider_id']??'');
  $direct=trim((string)($row['direct_url']??''));

  /*
   * V9.0.82 — LIVE M3U DIRETO
   *
   * Uma entrada M3U comum pode nao ter provider_id numerico. O importador
   * guarda o link real em gp_items.direct_url e usa provider_key como hash.
   * Antes desta correcao, a reproducao abortava aqui quando provider_id era
   * vazio, antes mesmo de consultar direct_url. Resultado: o canal aparecia
   * no player_api/bouquet, mas /live/... devolvia 404.
   *
   * Para fontes M3U (inclusive arquivo enviado), direct_url e a origem real
   * e deve ser preservado byte-a-byte no que importa para a URL: protocolo,
   * porta, path e query/token. O app universal recebe o redirect e segue a
   * origem, enquanto a URL publica do cliente continua sendo /live/... do GP.
   *
   * Fontes Xtream NAO passam por este atalho e continuam no resolver antigo.
   */
  if($kind==='live' && $direct!==''){
    $sourceType=strtolower(trim((string)($src['source_type']??'')));
    if($sourceType==='m3u' || $pid===''){
      $direct=html_entity_decode(str_replace('\/','/',$direct),ENT_QUOTES|ENT_HTML5,'UTF-8');
      $direct=str_replace(["\r","\n"],'',trim($direct));
      if(preg_match('~^https?://~i',$direct))return $direct;
    }
  }

  // provider_id so e obrigatorio quando nao existe um direct_url M3U utilizavel.
  if($pid==='')return '';

  $requestedExt=preg_replace('/[^a-zA-Z0-9]/','',(string)$ext);
  $storedExt=preg_replace('/[^a-zA-Z0-9]/','',(string)($row['container_ext']??''));
  if($requestedExt==='')$requestedExt=($kind==='live'?'ts':'mp4');
  if($storedExt==='')$storedExt=($kind==='live'?'ts':'mp4');

  $origins=[];

  if($kind==='movie'){
    /*
     * V9.0.7 — usa os DOIS comportamentos existentes no server 15-11:
     *
     * PADRAO (com proteção):
     *   streams.link -> processarUrl() -> /movie/... -> getHeadersAsJson()
     *
     * PADRAO2 / LINK_DIRETO (sem proteção):
     *   header("Location: ".$location)
     *
     * O diagnóstico da fonte atual provou que o caminho protegido às vezes
     * recebe HTTP 200 text/html. Quando isso ocorrer, não entregamos HTML
     * ao player: usamos o próprio link original, igual padrao2/link_direto
     * da referência.
     */
    $location=trim((string)($row['direct_url']??''));

    if($location!==''){
      $dados=gp_parse_original_stream_url($location);

      if($dados){
        $host=preg_replace('/:\d+$/','',(string)$dados['host']);
        $url='http://'.$host.'/movie/'.
             rawurlencode((string)$dados['username']).'/'.
             rawurlencode((string)$dados['password']).'/'.
             rawurlencode((string)$dados['id']).'.'.$requestedExt;

        // Primeiro tenta o modo "padrao" do server 15-11.
        $resolved=gp_resolve_provider_redirect($url);
        if($resolved!=='')return $resolved;

        /*
         * Se a resolução protegida falhou (por exemplo 200 text/html),
         * cai no comportamento "padrao2/link_direto" da própria referência:
         * entrega o streams.link original ao aplicativo.
         */
        return $location;
      }

      // Link que não entra no processarUrl(): comportamento link_direto.
      return $location;
    }

    // Registro legado sem link original: último fallback.
    return gp_source_url($src,'movie',$pid,$storedExt);
  }

  if($kind==='live'){
    // V9.0.80: restaurado EXATAMENTE o caminho de Live da versão comprovadamente
    // funcional em aplicativos universais. Não alterar sem um teste isolado.
    if(!empty($row['direct_url'])){
      foreach(gp_reference_candidates_from_direct((string)$row['direct_url'],$kind,$requestedExt) as $u)$origins[]=$u;
      if($storedExt!==$requestedExt){
        foreach(gp_reference_candidates_from_direct((string)$row['direct_url'],$kind,$storedExt) as $u)$origins[]=$u;
      }
      $origins[]=(string)$row['direct_url'];
    }
    if(empty($row['direct_url'])){
      foreach(array_values(array_unique([$requestedExt,$storedExt])) as $useExt){
        $origins[]=gp_source_url($src,$kind,$pid,$useExt);
      }
    }
    return gp_try_stream_origins($origins);
  }

  // NÃO ALTERAR: Séries já estão funcionando.
  $origins[]=gp_source_url($src,$kind,$pid,$storedExt);
  return gp_try_stream_origins($origins);
}
