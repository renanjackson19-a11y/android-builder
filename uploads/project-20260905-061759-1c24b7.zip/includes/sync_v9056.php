<?php require_once __DIR__.'/media.php';
require_once __DIR__.'/epg.php';
function gp_upsert_cat(PDO $pdo,$sid,$pid,$type,$name,$adultHint=0){
    $pid=(string)$pid;$name=trim((string)$name);if($name==='')$name='Sem categoria';
    $norm=gp_category_norm_key($name,$pid);$adult=(gp_is_adult_name($name) || (int)$adultHint===1)?1:0;
    static $schemaReady=false;
    if(!$schemaReady){
        try{$pdo->exec("ALTER TABLE gp_categories ADD COLUMN IF NOT EXISTS source_name VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL");}catch(Throwable $e){}
        try{$pdo->exec("ALTER TABLE gp_categories ADD COLUMN IF NOT EXISTS name_customized TINYINT(1) NOT NULL DEFAULT 0");}catch(Throwable $e){}
        try{$pdo->exec("ALTER TABLE gp_categories MODIFY COLUMN name VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL");}catch(Throwable $e){}
        try{$pdo->exec("UPDATE gp_categories SET source_name=name WHERE source_name IS NULL OR source_name=''");}catch(Throwable $e){}
        $schemaReady=true;
    }
    // Primeiro procura pelo ID ORIGINAL da categoria da fonte. Isso atualiza instalações antigas
    // sem criar categoria duplicada quando a chave normalizada passou a incluir o provider_id.
    $row=null;
    if($pid!==''){$q=$pdo->prepare('SELECT id,name_customized FROM gp_categories WHERE source_id=? AND type=? AND provider_id=? ORDER BY id LIMIT 1');$q->execute([$sid,$type,$pid]);$row=$q->fetch();}
    if(!$row && $pid===''){$q=$pdo->prepare('SELECT id,name_customized FROM gp_categories WHERE source_id=? AND type=? AND normalized_name=? ORDER BY id LIMIT 1');$q->execute([$sid,$type,$norm]);$row=$q->fetch();}
    if($row){
        $id=(int)$row['id'];
        if((int)($row['name_customized']??0)===1){$u=$pdo->prepare('UPDATE gp_categories SET provider_id=?,source_name=?,is_adult=GREATEST(is_adult,?),enabled=1 WHERE id=?');$u->execute([$pid,$name,$adult,$id]);}
        else{$u=$pdo->prepare('UPDATE gp_categories SET provider_id=?,name=?,source_name=?,normalized_name=?,is_adult=GREATEST(is_adult,?),enabled=1 WHERE id=?');$u->execute([$pid,$name,$name,$norm,$adult,$id]);}
        return $id;
    }
    try{$st=$pdo->prepare('INSERT INTO gp_categories(source_id,provider_id,type,name,source_name,normalized_name,is_adult,enabled,name_customized,sort_order) VALUES(?,?,?,?,?,?,?,1,0,2147483647)');$st->execute([$sid,$pid,$type,$name,$name,$norm,$adult]);return (int)$pdo->lastInsertId();}
    catch(Throwable $e){
        if($pid!==''){$q=$pdo->prepare('SELECT id FROM gp_categories WHERE source_id=? AND type=? AND provider_id=? ORDER BY id LIMIT 1');$q->execute([$sid,$type,$pid]);$id=(int)$q->fetchColumn();if($id>0)return $id;}
        throw $e;
    }
}

function gp_update_source_connections(PDO $pdo,int $sourceId,array $apiResponse): array {
    $u=is_array($apiResponse['user_info']??null)?$apiResponse['user_info']:[];
    $maxRaw=$u['max_connections']??$u['max_cons']??null;
    $activeRaw=$u['active_cons']??$u['active_connections']??null;

    $max=($maxRaw!==null && $maxRaw!=='')?(int)$maxRaw:null;
    $active=($activeRaw!==null && $activeRaw!=='')?(int)$activeRaw:null;

    try{
        $st=$pdo->prepare("UPDATE gp_sources SET max_connections=?,active_connections=?,connections_checked_at=NOW() WHERE id=?");
        $st->execute([$max,$active,$sourceId]);
    }catch(Throwable $e){}
    return ['max'=>$max,'active'=>$active];
}

function gp_sync_notify($step,$percent,$label,$message,$count=null){
    if(isset($GLOBALS['gp_sync_progress_callback']) && is_callable($GLOBALS['gp_sync_progress_callback'])){
        try{ call_user_func($GLOBALS['gp_sync_progress_callback'],$step,$percent,$label,$message,$count); }catch(Throwable $e){}
    }
}
function gp_xtream_catalog(PDO $pdo,array $s,string $kind,string $action,array $categoryRows){
    try{
        $all=gp_xtream_api($s,$action);
        if(is_array($all)) return $all;
    }catch(Throwable $bulkErr){
        $merged=[];$seen=[];$errors=0;
        foreach($categoryRows as $c){
            $cid=(string)($c['category_id']??'');
            if($cid==='')continue;
            try{
                $part=gp_xtream_api($s,$action,['category_id'=>$cid]);
                if(!is_array($part))continue;
                foreach($part as $x){
                    if(!is_array($x))continue;
                    $key=(string)($x['stream_id']??$x['series_id']??sha1(json_encode($x)));
                    if(isset($seen[$key]))continue;
                    $seen[$key]=1;$merged[]=$x;
                }
            }catch(Throwable $e){$errors++;}
        }
        if($merged)return $merged;
        throw new RuntimeException('Falha ao importar '.$kind.' em lote e por categoria. '.$bulkErr->getMessage().($errors?' | categorias com erro: '.$errors:''));
    }
    return [];
}
function gp_sync_ensure_vod_metadata_schema(PDO $pdo):void{
    static $done=false;if($done)return;$done=true;
    $defs=[
      'release_date'=>"VARCHAR(40) NULL",'genre'=>"VARCHAR(255) NULL",'duration'=>"VARCHAR(40) NULL",
      'rating'=>"VARCHAR(20) NULL",'rating_5based'=>"DECIMAL(5,2) NULL",'director'=>"TEXT NULL",
      'actors'=>"TEXT NULL",'country'=>"VARCHAR(255) NULL",'youtube_trailer'=>"TEXT NULL",
      'episode_run_time'=>"VARCHAR(40) NULL",'bitrate'=>"INT NULL",'metadata_synced_at'=>"DATETIME NULL"
    ];
    try{$cols=$pdo->query("SHOW COLUMNS FROM gp_items")->fetchAll(PDO::FETCH_COLUMN);}catch(Throwable $e){$cols=[];}
    foreach($defs as $name=>$def){
      if(!in_array($name,$cols,true)){try{$pdo->exec("ALTER TABLE gp_items ADD COLUMN `$name` $def");}catch(Throwable $e){}}
    }
}

/* V9.0.49 — limpa triggers legados de gp_items antes de importar VOD.
 * O projeto atual não usa triggers nesta tabela. Bases antigas podem ter ficado
 * com trigger de filme incompatível com o schema atual, causando MySQL 1136
 * mesmo quando o INSERT principal usa SET corretamente.
 */
function gp_sync_remove_legacy_item_triggers(PDO $pdo,int $sourceId=0): array {
    $removed=[];
    try{
        $rows=$pdo->query("SHOW TRIGGERS")->fetchAll(PDO::FETCH_ASSOC);
        foreach($rows as $tr){
            $table=(string)($tr['Table']??$tr['table']??'');
            if(strtolower($table)!=='gp_items') continue;
            $name=(string)($tr['Trigger']??$tr['trigger']??'');
            if($name==='') continue;
            // Guarda evidência no log antes da remoção; falha do log não interrompe.
            try{
                $stmt=(string)($tr['Statement']??$tr['statement']??'');
                $pdo->prepare("INSERT INTO gp_sync_log(source_id,kind,status,message) VALUES(?,'migration','ok',?)")
                    ->execute([$sourceId,'V9.0.49 removeu trigger legado de gp_items: '.$name.' | '.substr($stmt,0,700)]);
            }catch(Throwable $e){}
            $safe=str_replace('`','``',$name);
            $pdo->exec("DROP TRIGGER IF EXISTS `{$safe}`");
            $removed[]=$name;
        }
    }catch(Throwable $e){
        // Sem permissão para SHOW/DROP TRIGGER: não aborta aqui; o erro real do filme
        // será enriquecido abaixo com a identificação da etapa.
    }
    return $removed;
}


/* GREEN PLAY V9.0.35 — publicação validada.
 * Primeira carga: testa streams antes de publicar.
 * Sincronizações seguintes: testa somente IDs novos; os já aprovados não são retestados.
 */
function gp_probe_stream_batch(array $urls,int $parallel=18,int $timeout=7,$progressCb=null): array {
    $out=[];$urls=array_values(array_unique(array_filter($urls)));$total=count($urls);$done=0;
    foreach(array_chunk($urls,max(1,$parallel)) as $chunk){
        $mh=curl_multi_init();$handles=[];
        foreach($chunk as $url){
            $ch=curl_init($url);
            curl_setopt_array($ch,[
                CURLOPT_RETURNTRANSFER=>false,CURLOPT_FOLLOWLOCATION=>true,
                CURLOPT_CONNECTTIMEOUT=>3,CURLOPT_TIMEOUT=>$timeout,
                CURLOPT_USERAGENT=>'VLC/3.0 GreenPlay-Probe',
                CURLOPT_HTTPHEADER=>['Range: bytes=0-65535','Accept: */*','Connection: close'],
                CURLOPT_WRITEFUNCTION=>function($ch,$data){$n=strlen($data);return $n>0?0:$n;}
            ]);
            curl_multi_add_handle($mh,$ch);$handles[(int)$ch]=[$ch,$url];
        }
        $running=null;
        do{
            do{$mrc=curl_multi_exec($mh,$running);}while($mrc===CURLM_CALL_MULTI_PERFORM);
            while($info=curl_multi_info_read($mh)){
                $ch=$info['handle'];$key=(int)$ch;
                if(!isset($handles[$key]))continue;
                [$h,$url]=$handles[$key];
                $code=(int)curl_getinfo($h,CURLINFO_RESPONSE_CODE);
                $ctype=strtolower((string)curl_getinfo($h,CURLINFO_CONTENT_TYPE));
                $errno=curl_errno($h);
                $ok=($code>=200 && $code<400 && ($errno===0 || $errno===23) && strpos($ctype,'text/html')===false);
                $out[$url]=$ok;$done++;
                curl_multi_remove_handle($mh,$h);curl_close($h);unset($handles[$key]);
                if(is_callable($progressCb)){try{call_user_func($progressCb,$done,$total,$out);}catch(Throwable $e){}}
            }
            if($running){$sel=curl_multi_select($mh,0.20);if($sel===-1)usleep(100000);}
        }while($running && $mrc===CURLM_OK);
        // segurança: fecha qualquer handle que não tenha emitido CURLMSG_DONE
        foreach($handles as [$h,$url]){
            $code=(int)curl_getinfo($h,CURLINFO_RESPONSE_CODE);$ctype=strtolower((string)curl_getinfo($h,CURLINFO_CONTENT_TYPE));$errno=curl_errno($h);
            $ok=($code>=200 && $code<400 && ($errno===0 || $errno===23) && strpos($ctype,'text/html')===false);
            $out[$url]=$ok;$done++;curl_multi_remove_handle($mh,$h);curl_close($h);
            if(is_callable($progressCb)){try{call_user_func($progressCb,$done,$total,$out);}catch(Throwable $e){}}
        }
        curl_multi_close($mh);
    }
    return $out;
}
function gp_existing_provider_keys(PDO $pdo,int $sid,string $table,string $type=''): array {
    if($table==='gp_items'){$st=$pdo->prepare('SELECT provider_key FROM gp_items WHERE source_id=? AND type=?');$st->execute([$sid,$type]);}
    else{$st=$pdo->prepare('SELECT provider_key FROM '.$table.' WHERE source_id=?');$st->execute([$sid]);}
    $r=[];foreach($st->fetchAll(PDO::FETCH_COLUMN) as $x)$r[(string)$x]=1;return $r;
}
function gp_candidate_url(array $s,string $kind,array $x): string {
    $direct=trim((string)($x['direct_source']??$x['direct_url']??''));if($direct!=='')return $direct;
    $id=(string)($x['stream_id']??$x['id']??'');$ext=(string)($x['container_extension']??($kind==='live'?'ts':'mp4'));
    return $id!==''?gp_source_url($s,$kind,$id,$ext):'';
}
function gp_filter_new_working(PDO $pdo,array $s,string $type,array $rows): array {
    // V9.0.56: não testa milhares de streams dentro da sincronização principal.
    // Itens novos entram como pendentes (active=0) e são validados em blocos curtos
    // pelo worker de checkpoint. Itens já publicados nunca somem durante a atualização.
    return $rows;
}
function gp_catalog_dedupe(PDO $pdo,int $sid): array {
    $result=['movie'=>0,'series'=>0];
    $canon=function($name){
        $n=mb_strtolower(htmlspecialchars_decode((string)$name),'UTF-8');
        $n=preg_replace('/\b(?:2160p|1080p|720p|480p|4k|uhd|fhd|full\s*hd|hd|h\.?265|hevc|h\.?264|x265|x264|web[- .]?dl|webrip|bluray|brrip|hdr|sdr)\b/iu',' ',$n);
        $n=preg_replace('/[\s._-]*(?:\(|\[)?(?:19|20)\d{2}(?:\)|\])?\s*$/u','',$n);
        $n=preg_replace('/\s+/u',' ',trim($n));
        return gp_norm($n);
    };
    $variant=function($name){$n=mb_strtolower((string)$name,'UTF-8');if(preg_match('/(?:\[|\(|\b)(?:leg|legendado|legendada|sub|subtitled|l)(?:\]|\)|\b)/u',$n))return 'legendado';if(preg_match('/(?:\[|\(|\b)(?:dub|dublado|dublada|dual|d)(?:\]|\)|\b)/u',$n))return 'dublado';return 'padrao';};

    // Dentro da mesma fonte, elimina cópias técnicas sem apagar versões realmente diferentes de idioma.
    $st=$pdo->prepare("SELECT id,name,normalized_name,COALESCE(release_year,0) release_year,tmdb_id,logo,synopsis,direct_url
        FROM gp_items WHERE source_id=? AND type='movie' AND active=1 ORDER BY id DESC");
    $st->execute([$sid]);$keep=[];$drop=[];
    foreach($st->fetchAll() as $r){
        $name=$canon($r['name']??$r['normalized_name']??'');if($name==='')continue;$v=$variant($r['name']??'');$year=(int)$r['release_year'];$tmdb=(int)$r['tmdb_id'];
        $key=$tmdb>0?'tmdb|'.$tmdb.'|'.$v:'name|'.$name.'|'.($year>0?$year:'any').'|'.$v;
        $score=($tmdb>0?16:0)+($year>0?8:0)+(trim((string)$r['logo'])!==''?4:0)+(trim((string)$r['synopsis'])!==''?2:0)+(trim((string)$r['direct_url'])!==''?1:0);
        // Se já existe mesmo título com ano conhecido, a cópia sem ano entra no mesmo grupo.
        if($tmdb<=0 && $year===0){foreach($keep as $kk=>$kv){if(strpos($kk,'name|'.$name.'|')===0 && substr($kk,-strlen('|'.$v))==='|'.$v){$key=$kk;break;}}}
        if(!isset($keep[$key])){$keep[$key]=['id'=>(int)$r['id'],'score'=>$score];continue;}
        if($score>$keep[$key]['score']){$drop[]=$keep[$key]['id'];$keep[$key]=['id'=>(int)$r['id'],'score'=>$score];}else{$drop[]=(int)$r['id'];}
    }
    $result['movie']=gp_disable_ids($pdo,'gp_items',$drop);

    $st=$pdo->prepare("SELECT s.id,s.name,s.normalized_name,COALESCE(s.release_year,0) release_year,s.tmdb_id,s.logo,s.synopsis,
        (SELECT COUNT(*) FROM gp_episodes e WHERE e.series_id=s.id AND e.active=1) episode_count FROM gp_series s WHERE s.source_id=? AND s.active=1 ORDER BY s.id DESC");
    $st->execute([$sid]);$keep=[];$drop=[];
    foreach($st->fetchAll() as $r){
        $name=$canon($r['name']??$r['normalized_name']??'');if($name==='')continue;$year=(int)$r['release_year'];$tmdb=(int)$r['tmdb_id'];
        $key=$tmdb>0?'tmdb|'.$tmdb:'name|'.$name.'|'.($year>0?$year:'any');
        $score=((int)$r['episode_count']*100)+($tmdb>0?16:0)+($year>0?8:0)+(trim((string)$r['logo'])!==''?4:0)+(trim((string)$r['synopsis'])!==''?2:0);
        if($tmdb<=0 && $year===0){foreach($keep as $kk=>$kv){if(strpos($kk,'name|'.$name.'|')===0){$key=$kk;break;}}}
        if(!isset($keep[$key])){$keep[$key]=['id'=>(int)$r['id'],'score'=>$score];continue;}
        if($score>$keep[$key]['score']){$drop[]=$keep[$key]['id'];$keep[$key]=['id'=>(int)$r['id'],'score'=>$score];}else{$drop[]=(int)$r['id'];}
    }
    $result['series']=gp_disable_ids($pdo,'gp_series',$drop);
    if($result['movie']||$result['series']){try{$pdo->prepare("INSERT INTO gp_sync_log(source_id,kind,status,message) VALUES(?,'dedupe','ok',?)")->execute([$sid,'Duplicados ocultados V9.0.85 — filmes: '.$result['movie'].', séries: '.$result['series']]);}catch(Throwable $e){}}
    return $result;
}

function gp_sync_xtream(PDO $pdo,array $s){
    gp_sync_ensure_vod_metadata_schema($pdo);
    $sid=(int)$s['id'];
    $GLOBALS['gp_sync_force_first_full_probe']=empty($s['last_sync']);
    $legacyTriggers=gp_sync_remove_legacy_item_triggers($pdo,$sid);
    if($legacyTriggers){gp_sync_notify('connect',4,'OK','Compatibilidade VOD corrigida: trigger legado removido.');}$counts=['live'=>0,'movie'=>0,'series'=>0];
    $seriesExisting=!empty($GLOBALS['gp_sync_force_first_full_probe'])?[]:gp_existing_provider_keys($pdo,$sid,'gp_series');
    gp_sync_notify('connect',3,'conectando','Autenticando na fonte...');
    $baseInfo=gp_xtream_api($s,'');
    $conn=gp_update_source_connections($pdo,$sid,$baseInfo);
    $connMsg='Fonte autenticada.';
    if($conn['max']!==null){
        $connMsg.=' Conexões: '.($conn['active']!==null?$conn['active'].' / ':'').$conn['max'].'.';
    }
    gp_sync_notify('connect',6,'OK',$connMsg,'OK');

    // V9.0.56: publicação sem interrupção. NÃO desativa o catálogo atual no início.
    // Canais/filmes/séries que já estavam aprovados continuam disponíveis durante toda a sincronização.
    // Apenas itens novos são testados antes de entrar; itens offline só são desativados no teste online/offline.

    // V9.0.53: preserva o mapa de categorias já conhecido. Alguns servidores Xtream
    // retornam uma lista parcial de categorias em chamadas isoladas; isso não deve
    // desmontar as categorias existentes nem jogar séries para categoria nula.
    $cats=[];$catRows=['live'=>[],'movie'=>[],'series'=>[]];
    try{
        $qExistingCats=$pdo->prepare("SELECT id,provider_id,type FROM gp_categories WHERE source_id=? AND enabled=1 AND type IN ('live','movie','series')");
        $qExistingCats->execute([$sid]);
        foreach($qExistingCats->fetchAll() as $ec){
            $cats[(string)$ec['type'].'|'.(string)$ec['provider_id']]=(int)$ec['id'];
        }
    }catch(Throwable $e){}
    $catActions=['live'=>'get_live_categories','movie'=>'get_vod_categories','series'=>'get_series_categories'];
    $stepMap=['live'=>'livecat','movie'=>'moviecat','series'=>'seriescat'];
    $pctMap=['live'=>10,'movie'=>42,'series'=>72];

    foreach($catActions as $type=>$action){
        gp_sync_notify($stepMap[$type],$pctMap[$type],'importando','Buscando categorias...');
        $rows=gp_xtream_api($s,$action);
        if(!is_array($rows))$rows=[];
        // V9.0.56: alguns Xtream respondem categorias parciais de forma intermitente.
        // Se vier uma queda brusca, tenta novamente antes de aceitar a resposta.
        $knownBefore=0;foreach($cats as $ck=>$cv){if(strpos($ck,$type.'|')===0)$knownBefore++;}
        if(($knownBefore>=10 && count($rows)<max(5,(int)floor($knownBefore*0.60))) || ($type==='series' && count($rows)>0 && count($rows)<10)){
            for($retry=0;$retry<2;$retry++){
                usleep(250000);
                try{$again=gp_xtream_api($s,$action);if(is_array($again) && count($again)>count($rows))$rows=$again;}catch(Throwable $e){}
            }
        }
        $catRows[$type]=$rows;
        foreach($rows as $c){
            $pid=(string)($c['category_id']??'');
            $name=trim((string)($c['category_name']??'Sem categoria'));
            $adultHint=(int)($c['is_adult']??$c['adult']??0);
            $cats[$type.'|'.$pid]=gp_upsert_cat($pdo,$sid,$pid,$type,$name,$adultHint);
        }
        $available=0;foreach($cats as $ck=>$cv){if(strpos($ck,$type.'|')===0)$available++;}
        $received=count($rows);
        $msg='Categorias disponíveis: '.$available;
        if($received!==$available)$msg.=' • recebidas agora: '.$received.' • anteriores preservadas';
        gp_sync_notify($stepMap[$type],$pctMap[$type]+3,'OK',$msg,$available);
    }

    gp_sync_notify('live',18,'importando','Importando canais...');
    $liveRows=gp_xtream_catalog($pdo,$s,'canais','get_live_streams',$catRows['live']);
    $liveRows=gp_filter_new_working($pdo,$s,'live',$liveRows);
    $liveExisting=gp_existing_provider_keys($pdo,$sid,'gp_items','live');
    $st=$pdo->prepare("INSERT INTO gp_items(source_id,provider_key,provider_id,type,category_id,name,normalized_name,tvg_id,logo,container_ext,direct_url,active) VALUES(?,?,?,'live',?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE provider_id=VALUES(provider_id),category_id=VALUES(category_id),name=VALUES(name),normalized_name=VALUES(normalized_name),tvg_id=VALUES(tvg_id),logo=VALUES(logo),container_ext=VALUES(container_ext),direct_url=VALUES(direct_url)");
    foreach($liveRows as $x){
        $pid=(string)($x['stream_id']??'');if($pid==='')continue;
        $cid=$cats['live|'.(string)($x['category_id']??'')]??null;
        $name=(string)($x['name']??'Canal');
        $isNew=!isset($liveExisting[$pid]);
        $st->execute([$sid,$pid,$pid,$cid,$name,gp_norm($name),(string)($x['epg_channel_id']??''),(string)($x['stream_icon']??''),(string)($x['container_extension']??'ts'),(string)($x['direct_source']??''),$isNew?0:1]);
        $counts['live']++;
        if(($counts['live']%500)===0)gp_sync_notify('live',min(38,18+(int)($counts['live']/500)),'importando','Canais gravados: '.$counts['live'],$counts['live']);
    }
    gp_sync_notify('live',38,'OK','Canais importados: '.$counts['live'],$counts['live']);

    gp_sync_notify('movie',48,'importando','Importando filmes...');
    try{$movieRows=gp_xtream_catalog($pdo,$s,'filmes','get_vod_streams',$catRows['movie']);}
    catch(Throwable $e){throw new RuntimeException('ETAPA FILMES / catálogo: '.$e->getMessage(),0,$e);}
    try{$movieRows=gp_filter_new_working($pdo,$s,'movie',$movieRows);}
    catch(Throwable $e){throw new RuntimeException('ETAPA FILMES / teste dos novos: '.$e->getMessage(),0,$e);}
    // V9.0.49: caminho de gravação isolado e compatível com bases atualizadas por versões antigas.
    // Metadados opcionais são atualizados em uma segunda instrução. Isso evita o erro MySQL 1136
    // em instalações que foram atualizadas por várias versões do painel.
    // V9.0.47: evita por completo INSERT ... VALUES no catálogo de filmes.
    // Primeiro tenta UPDATE pelo identificador único; se ainda não existir, usa INSERT ... SET.
    // Assim não há possibilidade de erro 1136 por diferença entre lista de colunas e lista de valores.
    $stMovieExists=$pdo->prepare("SELECT id FROM gp_items WHERE source_id=? AND type='movie' AND provider_key=? LIMIT 1");
    $stMovieUpdate=$pdo->prepare("UPDATE gp_items SET provider_id=?,category_id=?,name=?,normalized_name=?,logo=?,release_year=?,tmdb_id=?,container_ext=?,direct_url=? WHERE source_id=? AND type='movie' AND provider_key=? LIMIT 1");
    // INSERT SET não depende de contagem entre lista de colunas e VALUES.
    $stMovieInsert=$pdo->prepare("INSERT INTO gp_items SET source_id=?,provider_key=?,provider_id=?,type='movie',category_id=?,name=?,normalized_name=?,logo=?,release_year=?,tmdb_id=?,container_ext=?,direct_url=?,active=0");
    $stMovieSynopsis=$pdo->prepare("UPDATE gp_items SET synopsis=CASE WHEN ?<>'' THEN ? ELSE synopsis END WHERE source_id=? AND type='movie' AND provider_key=? LIMIT 1");
    foreach($movieRows as $x){
        $pid=(string)($x['stream_id']??'');if($pid==='')continue;
        $cid=$cats['movie|'.(string)($x['category_id']??'')]??null;
        if($cid && !empty($x['is_adult'])){try{$pdo->prepare('UPDATE gp_categories SET is_adult=1 WHERE id=?')->execute([(int)$cid]);}catch(Throwable $e){}}
        $name=(string)($x['name']??'Filme');
        $norm=gp_norm($name);
        $logo=(string)($x['stream_icon']??'');
        $year=(int)($x['year']??0);
        $tmdb=(int)($x['tmdb']??0);
        $ext=(string)($x['container_extension']??'mp4');
        $direct=(string)($x['direct_source']??'');
        $rating=(string)($x['rating']??'');
        $rating5=(float)($x['rating_5based']??0);
        if($rating5<=0 && is_numeric($rating) && (float)$rating>0)$rating5=((float)$rating)/2;
        try{
            $stMovieExists->execute([$sid,$pid]);
            $movieId=$stMovieExists->fetchColumn();
            if($movieId){
                $stMovieUpdate->execute([$pid,$cid,$name,$norm,$logo,$year,$tmdb,$ext,$direct,$sid,$pid]);
            }else{
                $stMovieInsert->execute([$sid,$pid,$pid,$cid,$name,$norm,$logo,$year,$tmdb,$ext,$direct]);
            }
        }catch(Throwable $movieErr){
            throw new RuntimeException('V9.0.49 / FILME ID '.$pid.' / '.$name.' / gravação: '.$movieErr->getMessage(),0,$movieErr);
        }
        $synopsis=(string)($x['plot']??$x['description']??'');
        try{$stMovieSynopsis->execute([$synopsis,$synopsis,$sid,$pid]);}catch(Throwable $metaErr){}
        $counts['movie']++;
        if(($counts['movie']%1000)===0)gp_sync_notify('movie',min(68,48+(int)($counts['movie']/1000)),'importando','Filmes gravados: '.$counts['movie'],$counts['movie']);
    }
    gp_sync_notify('movie',68,'OK','Filmes importados: '.$counts['movie'],$counts['movie']);

    gp_sync_notify('series',78,'importando','Importando séries...');
    $seriesRows=gp_xtream_catalog($pdo,$s,'séries','get_series',$catRows['series']);
    $newSeriesProviderIds=[];
    $st=$pdo->prepare("INSERT INTO gp_series(source_id,provider_key,provider_id,category_id,name,normalized_name,logo,backdrop_url,synopsis,release_year,tmdb_id,active) VALUES(?,?,?,?,?,?,?,?,?,?,?,0) ON DUPLICATE KEY UPDATE provider_id=VALUES(provider_id),category_id=VALUES(category_id),name=VALUES(name),normalized_name=VALUES(normalized_name),logo=VALUES(logo),backdrop_url=VALUES(backdrop_url),synopsis=VALUES(synopsis),release_year=VALUES(release_year),tmdb_id=VALUES(tmdb_id)");
    foreach($seriesRows as $x){
        $pid=(string)($x['series_id']??'');if($pid==='')continue;
        if(!isset($seriesExisting[$pid]))$newSeriesProviderIds[]=$pid;
        $cid=$cats['series|'.(string)($x['category_id']??'')]??null;
        if($cid && !empty($x['is_adult'])){try{$pdo->prepare('UPDATE gp_categories SET is_adult=1 WHERE id=?')->execute([(int)$cid]);}catch(Throwable $e){}}
        $name=(string)($x['name']??'Série');
        $st->execute([$sid,$pid,$pid,$cid,$name,gp_norm($name),(string)($x['cover']??''),(string)($x['backdrop_path'][0]??''),(string)($x['plot']??''),(int)($x['year']??0),(int)($x['tmdb']??0)]);
        $counts['series']++;
        if(($counts['series']%500)===0)gp_sync_notify('series',min(92,78+(int)($counts['series']/500)),'importando','Séries gravadas: '.$counts['series'],$counts['series']);
    }
    gp_sync_notify('series',92,'OK','Séries importadas: '.$counts['series'],$counts['series']);

    // Episódios: apenas séries novas em cada sincronização. Cada episódio novo é testado antes de ficar ativo.
    if($newSeriesProviderIds){
        $qNew=$pdo->prepare("SELECT * FROM gp_series WHERE source_id=? AND provider_id=? LIMIT 1");$doneSeries=0;
        foreach($newSeriesProviderIds as $spid){
            $qNew->execute([$sid,$spid]);$ser=$qNew->fetch();if(!$ser)continue;
            try{gp_sync_series_episodes($pdo,$ser,true);}catch(Throwable $e){}
            $doneSeries++;if(($doneSeries%25)===0)gp_sync_notify('series',94,'testando','Episódios das séries novas: '.$doneSeries.' / '.count($newSeriesProviderIds),$doneSeries);
        }
    }


    // Remove duplicados do catálogo publicado sem tocar nos canais.
    $dedupe=gp_catalog_dedupe($pdo,$sid);
    gp_sync_notify('dedupe',96,'OK','Duplicados removidos — filmes: '.(int)$dedupe['movie'].', séries: '.(int)$dedupe['series'],(int)$dedupe['movie']+(int)$dedupe['series']);

    $epgUrl=trim((string)$s['epg_url']);
    if($epgUrl==='')$epgUrl=rtrim((string)$s['host'],'/').'/xmltv.php?username='.rawurlencode((string)$s['username']).'&password='.rawurlencode((string)$s['password']);
    $pdo->prepare('UPDATE gp_sources SET epg_url=? WHERE id=?')->execute([$epgUrl,$sid]);
    $epgCount=0;gp_sync_notify('epg',97,'importando','Buscando EPG automático da própria fonte...');
    try{$epgCount=gp_sync_epg($pdo,$sid);gp_sync_notify('epg',99,'OK','EPG automático importado: '.$epgCount,$epgCount);}catch(Throwable $epgErr){
        gp_sync_notify('epg',99,'OK','EPG não importado: '.$epgErr->getMessage(),0);
        try{$pdo->prepare("INSERT INTO gp_sync_log(source_id,kind,status,message) VALUES(?,'epg','error',?)")->execute([$sid,$epgErr->getMessage()]);}catch(Throwable $e){}
    }
    $counts['epg']=$epgCount;
    $pdo->prepare('UPDATE gp_sources SET last_sync=NOW(),last_error=NULL WHERE id=?')->execute([$sid]);
    $pdo->prepare("INSERT INTO gp_sync_log(source_id,kind,status,message) VALUES(?,'catalog','ok',?)")->execute([$sid,json_encode($counts)]);
    gp_sync_notify('done',100,'concluído','Sincronização concluída.',array_sum($counts));
    return $counts;
}

function gp_validate_catalog_type(PDO $pdo,array $s,string $kind): array {
    $sid=(int)$s['id'];$tested=0;$online=0;$offline=0;$lastId=0;$table=$kind==='series'?'gp_episodes':'gp_items';
    $label=$kind==='live'?'canais':($kind==='movie'?'filmes':'episódios');
    if($kind==='series'){$ct=$pdo->prepare("SELECT COUNT(*) FROM gp_episodes WHERE source_id=? AND active=1");$ct->execute([$sid]);}
    else{$ct=$pdo->prepare("SELECT COUNT(*) FROM gp_items WHERE source_id=? AND type=? AND active=1");$ct->execute([$sid,$kind]);}
    $total=(int)$ct->fetchColumn();
    while(true){
        if($kind==='series'){
            $q=$pdo->prepare("SELECT id,provider_id,container_ext,direct_url FROM gp_episodes WHERE source_id=? AND active=1 AND id>? ORDER BY id LIMIT 400");$q->execute([$sid,$lastId]);
        }else{
            $q=$pdo->prepare("SELECT id,provider_id,container_ext,direct_url FROM gp_items WHERE source_id=? AND type=? AND active=1 AND id>? ORDER BY id LIMIT 400");$q->execute([$sid,$kind,$lastId]);
        }
        $rows=$q->fetchAll();if(!$rows)break;$urls=[];$byUrl=[];
        foreach($rows as $r){$lastId=max($lastId,(int)$r['id']);$u=trim((string)($r['direct_url']??''));if($u==='')$u=gp_source_url($s,$kind,(string)$r['provider_id'],(string)($r['container_ext']?:($kind==='live'?'ts':'mp4')));if($u===''){$offline++;$tested++;$pdo->prepare("UPDATE {$table} SET active=0 WHERE id=?")->execute([(int)$r['id']]);continue;}$urls[]=$u;$byUrl[$u][]=(int)$r['id'];}
        $chunkStart=$tested;
        $probe=gp_probe_stream_batch($urls,36,5,function($done,$urlTotal,$snapshot=[]) use($kind,$label,$total,$chunkStart,$online,$offline){
            $seen=min($total,$chunkStart+$done);
            $chunkOn=0;$chunkOff=0;foreach($snapshot as $ok){if($ok)$chunkOn++;else$chunkOff++;}
            $on=$online+$chunkOn;$off=$offline+$chunkOff;
            $base=$kind==='live'?93:($kind==='movie'?95:97);
            $countText=$seen.' / '.$total.' • ON '.$on.' • OFF '.$off;
            gp_sync_notify('probe_'.$kind,$base,'testando','Verificando '.$label.': '.$countText.' • continua em segundo plano',$countText);
        });
        foreach($byUrl as $url=>$ids){$ok=!empty($probe[$url]);foreach($ids as $rid){$tested++;if($ok)$online++;else{$offline++;$pdo->prepare("UPDATE {$table} SET active=0 WHERE id=?")->execute([$rid]);}}}
        gp_sync_notify('probe_'.$kind,$kind==='live'?93:($kind==='movie'?95:97),'testando','Verificados '.$tested.' / '.$total.' '.$label.' — online '.$online.' / offline '.$offline,$tested.' / '.$total);
    }
    if($kind==='series'){
        $pdo->prepare("UPDATE gp_series s SET active=0 WHERE source_id=? AND NOT EXISTS(SELECT 1 FROM gp_episodes e WHERE e.series_id=s.id AND e.active=1)")->execute([$sid]);
    }
    return ['tested'=>$tested,'total'=>$total,'online'=>$online,'offline'=>$offline];
}
function gp_validate_published_catalog(PDO $pdo,int $sourceId): array {
    $q=$pdo->prepare('SELECT * FROM gp_sources WHERE id=? AND active=1');$q->execute([$sourceId]);$s=$q->fetch();if(!$s)throw new RuntimeException('Fonte inválida para teste.');
    if(($s['source_type']??'')!=='xtream'){return ['live'=>['tested'=>0,'online'=>0,'offline'=>0],'movie'=>['tested'=>0,'online'=>0,'offline'=>0],'series'=>['tested'=>0,'online'=>0,'offline'=>0]];}
    $out=[];
    gp_sync_notify('probe_live',93,'testando','Testando canais online/offline...');$out['live']=gp_validate_catalog_type($pdo,$s,'live');
    gp_sync_notify('probe_movie',95,'testando','Testando filmes online/offline...');$out['movie']=gp_validate_catalog_type($pdo,$s,'movie');
    gp_sync_notify('probe_series',97,'testando','Testando episódios de séries online/offline...');$out['series']=gp_validate_catalog_type($pdo,$s,'series');
    try{$pdo->prepare("INSERT INTO gp_sync_log(source_id,kind,status,message) VALUES(?,'full_probe','ok',?)")->execute([$sourceId,json_encode($out,JSON_UNESCAPED_UNICODE)]);}catch(Throwable $e){}
    return $out;
}

function gp_parse_episode_name($name){$name=trim((string)$name);$season=0;$episode=0;$series=$name;if(preg_match('/^(.*?)[\s._-]+S(\d{1,2})E(\d{1,3})\b/i',$name,$m)){$series=trim($m[1]);$season=(int)$m[2];$episode=(int)$m[3];}elseif(preg_match('/^(.*?)[\s._-]+T(\d{1,2})[\s._-]*E(\d{1,3})\b/i',$name,$m)){$series=trim($m[1]);$season=(int)$m[2];$episode=(int)$m[3];}return [$series?:$name,$season,$episode];}
function gp_sync_m3u(PDO $pdo,array $s){
    @set_time_limit(0);
    @ini_set('max_execution_time','0');
    @ini_set('memory_limit','512M');
    $url=trim((string)($s['m3u_url']??''));
    if($url==='') throw new RuntimeException('URL M3U vazia');

    // URL remota ou arquivo M3U enviado ao painel.
    $tmp=tempnam(sys_get_temp_dir(),'gp_m3u_');
    if(!$tmp) throw new RuntimeException('Não foi possível criar arquivo temporário para a lista.');

    if(strpos($url,'local:')===0){
        $rel=ltrim(substr($url,6),'/');
        $candidate=realpath(__DIR__.'/../'.$rel);
        $base=realpath(__DIR__.'/../storage/source_uploads');
        if(!$candidate||!$base||strpos($candidate,$base)!==0||!is_file($candidate)){
            @unlink($tmp);throw new RuntimeException('Arquivo M3U enviado não encontrado.');
        }
        if(!@copy($candidate,$tmp)){@unlink($tmp);throw new RuntimeException('Não foi possível preparar o arquivo M3U enviado.');}
    }else{
        $fp=fopen($tmp,'wb');
        if(!$fp){@unlink($tmp);throw new RuntimeException('Não foi possível abrir arquivo temporário.');}
        $ch=curl_init($url);
        curl_setopt_array($ch,[
            CURLOPT_FILE=>$fp,
            CURLOPT_FOLLOWLOCATION=>true,
            CURLOPT_CONNECTTIMEOUT=>15,
            CURLOPT_TIMEOUT=>0,
            CURLOPT_LOW_SPEED_LIMIT=>256,
            CURLOPT_LOW_SPEED_TIME=>120,
            CURLOPT_USERAGENT=>'XCIPTV',
            CURLOPT_HTTPHEADER=>['Accept: */*','Connection: keep-alive']
        ]);
        $ok=curl_exec($ch);$code=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);$err=curl_error($ch);curl_close($ch);fclose($fp);
        if(!$ok||$code>=400||$code===0){$sz=@filesize($tmp)?:0;@unlink($tmp);throw new RuntimeException('Falha ao baixar M3U (HTTP '.$code.', '.round($sz/1048576,1).' MB recebidos). '.$err);}
    }

    $sid=(int)$s['id'];
    $pdo->prepare('UPDATE gp_items SET active=0 WHERE source_id=?')->execute([$sid]);
    $pdo->prepare('UPDATE gp_series SET active=0 WHERE source_id=?')->execute([$sid]);
    $fh=fopen($tmp,'rb');
    if(!$fh){@unlink($tmp);throw new RuntimeException('Falha ao ler lista M3U baixada.');}
    $meta=null;$n=['live'=>0,'movie'=>0,'series'=>0,'episodes'=>0];$lineNo=0;
    try{
      while(($line=fgets($fh))!==false){
        $lineNo++; $line=trim($line); if($line==='')continue;
        if(strpos($line,'#EXTINF:')===0){
          preg_match('/group-title="([^"]*)"/i',$line,$g);preg_match('/tvg-logo="([^"]*)"/i',$line,$l);preg_match('/tvg-id="([^"]*)"/i',$line,$t);
          $comma=strrpos($line,',');$name=$comma!==false?trim(substr($line,$comma+1)):'Conteúdo';
          $meta=['group'=>$g[1]??'Sem categoria','logo'=>$l[1]??'','tvg'=>$t[1]??'','name'=>$name];continue;
        }
        if($meta&&preg_match('~^https?://~i',$line)){
          $type=preg_match('~/movie/~i',$line)?'movie':(preg_match('~/series/~i',$line)?'series':'live');$pid='';
          if(preg_match('~/(?:live|movie|series)/[^/]+/[^/]+/(\d+)(?:\.([a-z0-9]+))?~i',$line,$m)){$pid=$m[1];$ext=$m[2]??($type==='live'?'ts':'mp4');}
          else{$pid=sha1($type.'|'.gp_norm($meta['group']).'|'.gp_norm($meta['name']));$ext=pathinfo(parse_url($line,PHP_URL_PATH)??'',PATHINFO_EXTENSION)?:($type==='live'?'ts':'mp4');}
          if($type==='series'){
            list($seriesName,$season,$episode)=gp_parse_episode_name($meta['name']);$cat=gp_upsert_cat($pdo,$sid,'','series',$meta['group']);$seriesKey=sha1(gp_norm($meta['group']).'|'.gp_norm($seriesName));
            $st=$pdo->prepare("INSERT INTO gp_series(source_id,provider_key,provider_id,category_id,name,normalized_name,logo,active) VALUES(?,?,NULL,?,?,?,?,1) ON DUPLICATE KEY UPDATE category_id=VALUES(category_id),name=VALUES(name),normalized_name=VALUES(normalized_name),logo=VALUES(logo),active=1");$st->execute([$sid,$seriesKey,$cat,$seriesName,gp_norm($seriesName),$meta['logo']]);
            $q=$pdo->prepare('SELECT id FROM gp_series WHERE source_id=? AND provider_key=?');$q->execute([$sid,$seriesKey]);$seriesId=(int)$q->fetchColumn();$epKey=ctype_digit($pid)?$pid:sha1($line);
            $ep=$pdo->prepare("INSERT INTO gp_episodes(series_id,source_id,provider_key,provider_id,season_number,episode_number,name,container_ext,direct_url,logo,active) VALUES(?,?,?,?,?,?,?,?,?,?,1) ON DUPLICATE KEY UPDATE series_id=VALUES(series_id),season_number=VALUES(season_number),episode_number=VALUES(episode_number),name=VALUES(name),container_ext=VALUES(container_ext),direct_url=VALUES(direct_url),logo=VALUES(logo),active=1");$ep->execute([$seriesId,$sid,$epKey,ctype_digit($pid)?$pid:null,$season,$episode,$meta['name'],$ext,$line,$meta['logo']]);$n['episodes']++;$n['series']++;
          }else{
            $cat=gp_upsert_cat($pdo,$sid,'',$type,$meta['group']);
            $st=$pdo->prepare("INSERT INTO gp_items(source_id,provider_key,provider_id,type,category_id,name,normalized_name,tvg_id,logo,container_ext,direct_url,active) VALUES(?,?,?,?,?,?,?,?,?,?,?,1) ON DUPLICATE KEY UPDATE category_id=VALUES(category_id),name=VALUES(name),normalized_name=VALUES(normalized_name),tvg_id=VALUES(tvg_id),logo=VALUES(logo),container_ext=VALUES(container_ext),direct_url=VALUES(direct_url),active=1");$st->execute([$sid,$pid,ctype_digit($pid)?$pid:null,$type,$cat,$meta['name'],gp_norm($meta['name']),$meta['tvg'],$meta['logo'],$ext,$line]);$n[$type]++;
          }
          $meta=null;
        }
      }
    } finally { fclose($fh); @unlink($tmp); }
    // Remove duplicados de filmes/séries após a importação M3U. Canais não são alterados.
    $dedupe=gp_catalog_dedupe($pdo,$sid);
    $n['dedupe_movie']=(int)$dedupe['movie'];$n['dedupe_series']=(int)$dedupe['series'];
    $pdo->prepare('UPDATE gp_sources SET last_sync=NOW(),last_error=NULL WHERE id=?')->execute([$sid]);
    $pdo->prepare("INSERT INTO gp_sync_log(source_id,kind,status,message) VALUES(?,'catalog','ok',?)")->execute([$sid,json_encode($n)]);
    return $n;
}

function gp_repair_direct_links_from_m3u(PDO $pdo,array $s){
    @set_time_limit(0);
    @ini_set('max_execution_time','0');
    @ini_set('memory_limit','384M');
    $url=trim((string)($s['m3u_url']??''));
    if($url==='') throw new RuntimeException('Esta fonte não possui a URL M3U original salva.');

    $tmp=tempnam(sys_get_temp_dir(),'gp_links_');
    if(!$tmp) throw new RuntimeException('Não foi possível criar arquivo temporário.');
    $fp=fopen($tmp,'wb');
    if(!$fp){@unlink($tmp);throw new RuntimeException('Não foi possível abrir arquivo temporário.');}

    $ch=curl_init($url);
    curl_setopt_array($ch,[
        CURLOPT_FILE=>$fp,
        CURLOPT_FOLLOWLOCATION=>true,
        CURLOPT_CONNECTTIMEOUT=>15,
        CURLOPT_TIMEOUT=>0,
        CURLOPT_LOW_SPEED_LIMIT=>128,
        CURLOPT_LOW_SPEED_TIME=>180,
        CURLOPT_USERAGENT=>'XCIPTV',
        CURLOPT_ENCODING=>'',
        CURLOPT_HTTPHEADER=>['Accept: */*','Connection: keep-alive']
    ]);
    $ok=curl_exec($ch);
    $code=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);
    $err=curl_error($ch);
    curl_close($ch); fclose($fp);
    if(!$ok||$code>=400||$code===0){
        $sz=@filesize($tmp)?:0; @unlink($tmp);
        throw new RuntimeException('Falha ao baixar a M3U original (HTTP '.$code.', '.round($sz/1048576,1).' MB). '.$err);
    }

    $sid=(int)$s['id'];
    $byId=$pdo->prepare("UPDATE gp_items SET direct_url=?,container_ext=CASE WHEN ?<>'' THEN ? ELSE container_ext END WHERE source_id=? AND BINARY type=BINARY ? AND BINARY provider_id=BINARY ?");
    $byName=$pdo->prepare("UPDATE gp_items SET direct_url=?,container_ext=CASE WHEN ?<>'' THEN ? ELSE container_ext END WHERE source_id=? AND BINARY type=BINARY ? AND BINARY normalized_name=BINARY ?");
    $fh=fopen($tmp,'rb');
    if(!$fh){@unlink($tmp);throw new RuntimeException('Não foi possível ler a M3U baixada.');}

    $meta=null;$seen=0;$linked=0;$live=0;$movie=0;$unmatched=0;
    try{
        while(($line=fgets($fh))!==false){
            $line=trim($line);
            if($line==='')continue;
            if(stripos($line,'#EXTINF:')===0){
                $comma=strrpos($line,',');
                $name=$comma!==false?trim(substr($line,$comma+1)):'';
                $meta=['name'=>$name];
                continue;
            }
            if(!$meta || !preg_match('~^https?://~i',$line))continue;

            $type=null;
            if(preg_match('~/live/~i',$line))$type='live';
            elseif(preg_match('~/movie/~i',$line))$type='movie';
            // Não mexer em séries: já estão funcionando.
            if(!$type){$meta=null;continue;}

            $seen++;
            $path=(string)(parse_url($line,PHP_URL_PATH)??'');
            $ext=pathinfo($path,PATHINFO_EXTENSION);
            $pid='';
            if(preg_match('~/(?:live|movie)/[^/]+/[^/]+/([^/?]+)~i',$line,$m)){
                $pid=pathinfo($m[1],PATHINFO_FILENAME);
            }

            $affected=0;
            if($pid!=='' && ctype_digit((string)$pid)){
                $byId->execute([$line,$ext,$ext,$sid,$type,$pid]);
                $affected=$byId->rowCount();
            }
            if($affected===0 && !empty($meta['name'])){
                $norm=gp_norm($meta['name']);
                if($norm!==''){
                    $byName->execute([$line,$ext,$ext,$sid,$type,$norm]);
                    $affected=$byName->rowCount();
                }
            }
            if($affected>0){
                $linked += $affected;
                if($type==='live')$live += $affected; else $movie += $affected;
            }else{$unmatched++;}
            $meta=null;
        }
    } finally {
        fclose($fh);
        @unlink($tmp);
    }

    try{
        $pdo->prepare("INSERT INTO gp_sync_log(source_id,kind,status,message) VALUES(?,'links','ok',?)")
            ->execute([$sid,json_encode(['seen'=>$seen,'linked'=>$linked,'live'=>$live,'movie'=>$movie,'unmatched'=>$unmatched],JSON_UNESCAPED_UNICODE)]);
    }catch(Throwable $e){}

    return ['seen'=>$seen,'linked'=>$linked,'live'=>$live,'movie'=>$movie,'unmatched'=>$unmatched];
}

function gp_m3u_extract_xtream(array $s){
    $url=trim((string)($s['m3u_url']??''));
    if($url==='') return null;
    $parts=@parse_url($url); if(!$parts || empty($parts['scheme']) || empty($parts['host'])) return null;
    parse_str((string)($parts['query']??''),$q);
    $u=(string)($q['username']??$q['user']??'');
    $p=(string)($q['password']??$q['pass']??'');
    if($u===''||$p==='') return null;
    $path=strtolower((string)($parts['path']??''));
    if(strpos($path,'get.php')===false && strpos($path,'playlist')===false && strpos($path,'m3u')===false) return null;
    $host=$parts['scheme'].'://'.$parts['host'];
    if(!empty($parts['port'])) $host.=':'.$parts['port'];
    $x=$s; $x['source_type']='xtream'; $x['host']=$host; $x['username']=$u; $x['password']=$p;
    if(trim((string)($x['epg_url']??''))==='') $x['epg_url']=$host.'/xmltv.php?username='.rawurlencode($u).'&password='.rawurlencode($p);
    return $x;
}
function gp_sync_source(PDO $pdo,$id){
    @set_time_limit(0); @ini_set('max_execution_time','0');
    $st=$pdo->prepare('SELECT * FROM gp_sources WHERE id=? AND active=1');$st->execute([$id]);$s=$st->fetch();if(!$s)throw new RuntimeException('Fonte inválida');
    try{
        if($s['source_type']==='xtream') return gp_sync_xtream($pdo,$s);
        // URLs get.php do Xtream são detectadas automaticamente. Evita baixar M3U gigante.
        $x=gp_m3u_extract_xtream($s);
        if($x){
            // Persistir a conversão M3U -> Xtream. O catálogo já era importado via API,
            // mas sem salvar host/usuário/senha as rotas /live, /movie, /series e episódios falhavam depois.
            $pdo->prepare("UPDATE gp_sources SET source_type='xtream',host=?,username=?,password=?,epg_url=?,last_error=NULL WHERE id=?")
                ->execute([$x['host'],$x['username'],$x['password'],$x['epg_url']??'',(int)$s['id']]);
            $x['source_type']='xtream';
            $r=gp_sync_xtream($pdo,$x);
            try{
                $links=gp_repair_direct_links_from_m3u($pdo,$s);
                $r['links_live']=(int)($links['live']??0);
                $r['links_movie']=(int)($links['movie']??0);
            }catch(Throwable $linkErr){
                try{$pdo->prepare("INSERT INTO gp_sync_log(source_id,kind,status,message) VALUES(?,'links','error',?)")->execute([(int)$s['id'],$linkErr->getMessage()]);}catch(Throwable $e){}
            }
            $pdo->prepare("UPDATE gp_sources SET last_error=NULL,last_sync=NOW() WHERE id=?")->execute([(int)$s['id']]);
            return $r + ['mode'=>'xtream-auto'];
        }
        return gp_sync_m3u($pdo,$s);
    }catch(Throwable $e){$pdo->prepare('UPDATE gp_sources SET last_error=? WHERE id=?')->execute([$e->getMessage(),$id]);throw $e;}
}
function gp_sync_series_episodes(PDO $pdo,array $ser,bool $validateNew=false){
    $src=$pdo->prepare('SELECT * FROM gp_sources WHERE id=?');
    $src->execute([(int)$ser['source_id']]);
    $s=$src->fetch();
    if(!$s)return;
    // Compatibilidade com fontes antigas salvas como M3U, mas que na verdade são Xtream get.php.
    if(($s['source_type']??'')!=='xtream'){
        $x=gp_m3u_extract_xtream($s);
        if(!$x)return;
        $pdo->prepare("UPDATE gp_sources SET source_type='xtream',host=?,username=?,password=?,epg_url=? WHERE id=?")
            ->execute([$x['host'],$x['username'],$x['password'],$x['epg_url']??'',(int)$s['id']]);
        $s=$x;
    }
    $info=gp_xtream_api($s,'get_series_info',['series_id'=>$ser['provider_id']]);
    $existing=[];$qe=$pdo->prepare('SELECT provider_key FROM gp_episodes WHERE series_id=?');$qe->execute([(int)$ser['id']]);foreach($qe->fetchAll(PDO::FETCH_COLUMN) as $k)$existing[(string)$k]=1;
    $episodeRows=[];
    foreach(($info['episodes']??[]) as $season=>$eps){
        if(!is_array($eps))continue;
        foreach($eps as $e){
            if(!is_array($e))continue;
            $pid=(string)($e['id']??'');if($pid==='')continue;
            $num=(int)($e['episode_num']??$e['episode_number']??0);
            $sn=(int)($e['season']??$season??0);
            $ext=(string)($e['container_extension']??'mp4');
            $title=(string)($e['title']??$e['name']??('Episódio '.$num));
            $infoE=is_array($e['info']??null)?$e['info']:[];
            $episodeRows[]=['pid'=>$pid,'sn'=>$sn,'num'=>$num,'title'=>$title,'ext'=>$ext,'logo'=>(string)($infoE['movie_image']??$e['movie_image']??''),'plot'=>(string)($infoE['plot']??$e['plot']??'')];
        }
    }
    // Sincronização principal publica os episódios recebidos; validação offline é feita separadamente.
    $st=$pdo->prepare("INSERT INTO gp_episodes(series_id,source_id,provider_key,provider_id,season_number,episode_number,name,container_ext,logo,synopsis,active) VALUES(?,?,?,?,?,?,?,?,?,?,1) ON DUPLICATE KEY UPDATE series_id=VALUES(series_id),season_number=VALUES(season_number),episode_number=VALUES(episode_number),name=VALUES(name),container_ext=VALUES(container_ext),logo=VALUES(logo),synopsis=VALUES(synopsis),active=1");
    foreach($episodeRows as $er){
        $st->execute([(int)$ser['id'],(int)$ser['source_id'],$er['pid'],$er['pid'],$er['sn'],$er['num'],$er['title'],$er['ext'],$er['logo'],$er['plot']]);
    }
    $pdo->prepare('UPDATE gp_series SET episodes_synced_at=NOW() WHERE id=?')->execute([(int)$ser['id']]);
}
