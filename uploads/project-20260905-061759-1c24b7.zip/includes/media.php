<?php
function gp_norm($s){$s=mb_strtolower(trim((string)$s),'UTF-8');$s=preg_replace('/[\x{1F000}-\x{1FAFF}\x{2600}-\x{27BF}]/u','',$s);$s=preg_replace('/[^\pL\pN]+/u',' ',$s);return trim(preg_replace('/\s+/u',' ',$s));}
function gp_category_norm_key($name,$providerId=''){
    $base=gp_norm($name);
    $pid=trim((string)$providerId);
    if($pid==='')return $base;
    // Categorias Xtream podem ter o mesmo texto e diferir apenas por emoji/símbolo.
    // O provider_id faz parte da chave interna para que elas não sejam mescladas.
    $base=mb_substr($base,0,220,'UTF-8');
    $pid=preg_replace('/[^a-zA-Z0-9_-]/','',$pid);
    return trim($base.' #'.$pid);
}
function gp_is_adult_name($s){$n=gp_norm($s);foreach(['adult','adulto','adultos','18','hot','onlyfans','only fans','xxx','porn','porno','sexo','sex','privacy','sexy','erotico','erotica','playboy','brazzers','penthouse','hustler','redlight','dorcel','private','prive','privê'] as $k){if(mb_strpos($n,$k,0,'UTF-8')!==false)return true;}return false;}

function gp_xtream_normalize_source(array $s): array {
  $raw=trim(html_entity_decode((string)($s['host']??''),ENT_QUOTES|ENT_HTML5,'UTF-8'));
  $raw=preg_replace('/[\x00-\x20]+/u','',$raw);
  if($raw==='') throw new RuntimeException('Servidor/DNS da fonte está vazio.');
  if(strpos($raw,'//')===0)$raw='http:'.$raw;
  if(!preg_match('~^https?://~i',$raw))$raw='http://'.$raw;

  $parts=@parse_url($raw);
  if(!$parts || empty($parts['host'])){
    throw new RuntimeException('DNS/Host inválido: informe domínio ou IP, com porta se necessário. Ex.: http://servidor:8080');
  }
  $scheme=strtolower((string)($parts['scheme']??'http'));
  if(!in_array($scheme,['http','https'],true))$scheme='http';
  $host=$scheme.'://'.(string)$parts['host'];
  if(isset($parts['port']))$host.=':'.(int)$parts['port'];

  // Aceita também player_api.php/get.php/xmltv.php completos no campo DNS.
  // Mantém subpasta real do painel, removendo apenas o endpoint conhecido.
  $path=trim((string)($parts['path']??''));
  $path=preg_replace('~/(?:player_api\.php|get\.php|xmltv\.php)/?$~i','',$path);
  $path=rtrim($path,'/');
  if($path!=='' && $path!=='/')$host.='/'.ltrim($path,'/');

  $q=[];parse_str((string)($parts['query']??''),$q);
  $u=trim((string)($s['username']??''));
  $pw=(string)($s['password']??'');
  if($u==='')$u=trim((string)($q['username']??$q['user']??''));
  if($pw==='')$pw=(string)($q['password']??$q['pass']??'');

  $s['host']=rtrim($host,'/');
  $s['username']=$u;
  $s['password']=$pw;
  return $s;
}
function gp_url_normalize_http(string $url): string {
  $url=trim(html_entity_decode($url,ENT_QUOTES|ENT_HTML5,'UTF-8'));
  if($url==='')return '';
  $url=preg_replace('/[\x00-\x20]+/u','',$url);
  if(strpos($url,'//')===0)$url='http:'.$url;
  if(!preg_match('~^https?://~i',$url))$url='http://'.$url;
  return $url;
}
function gp_source_url($src,$kind,$providerId,$ext='ts'){
  $host=rtrim((string)($src['_stream_host']??$src['host']??''),'/');
  $u=rawurlencode((string)$src['username']);$p=rawurlencode((string)$src['password']);
  $id=rawurlencode((string)$providerId);$ext=preg_replace('/[^a-z0-9]/i','',(string)$ext)?:'ts';
  if($kind==='live')return "$host/live/$u/$p/$id.$ext";
  if($kind==='movie')return "$host/movie/$u/$p/$id.$ext";
  return "$host/series/$u/$p/$id.$ext";
}
function gp_http_json($url,$timeout=25){
  $body='';
  $jsonReady=false;

  $ch=curl_init($url);
  curl_setopt_array($ch,[
    CURLOPT_RETURNTRANSFER=>false,
    CURLOPT_FOLLOWLOCATION=>true,
    CURLOPT_CONNECTTIMEOUT=>8,
    CURLOPT_TIMEOUT=>$timeout,
    CURLOPT_USERAGENT=>'XCIPTV',
    CURLOPT_ENCODING=>'',
    CURLOPT_HTTPHEADER=>[
      'Accept: application/json, text/plain, */*',
      'Connection: close'
    ]
  ]);

  /*
   * Alguns painéis Xtream retornam o JSON completo, mas não encerram
   * corretamente a conexão. Antes o cURL esperava até o timeout e o
   * Green Play tratava a fonte como erro, mesmo tendo recebido dados.
   *
   * Agora acumulamos os chunks e encerramos de propósito assim que
   * json_decode() confirma que o JSON está completo.
   */
  curl_setopt($ch,CURLOPT_WRITEFUNCTION,function($ch,$chunk) use (&$body,&$jsonReady){
    $body.=$chunk;

    if(strlen($body)>0){
      $probe=json_decode($body,true);
      if(is_array($probe) && json_last_error()===JSON_ERROR_NONE){
        $jsonReady=true;
        return 0; // interrupção intencional: JSON completo já recebido
      }
    }

    return strlen($chunk);
  });

  $ok=curl_exec($ch);
  $code=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);
  $errno=curl_errno($ch);
  $err=curl_error($ch);
  curl_close($ch);

  // Se paramos porque o JSON já estava completo, isso é sucesso.
  if($jsonReady){
    $j=json_decode($body,true);
    if(is_array($j)) return $j;
  }

  // Alguns servidores fecham normalmente antes de o callback marcar.
  if($body!==''){
    $j=json_decode($body,true);
    if(is_array($j) && json_last_error()===JSON_ERROR_NONE) return $j;
  }

  if($ok===false || $code>=400){
    $extra=$body!=='' ? ' ('.strlen($body).' bytes recebidos)' : '';
    throw new RuntimeException('HTTP '.$code.' '.$err.$extra);
  }

  throw new RuntimeException('JSON Xtream incompleto ou inválido ('.strlen($body).' bytes recebidos).');
}

function gp_xtream_api_url(array $s,$action='',$extra=[],$forceHost=null){
  $s=gp_xtream_normalize_source($s);
  $host=rtrim((string)($forceHost!==null?$forceHost:($s['host']??'')),'/');
  $url=$host.'/player_api.php?username='.rawurlencode((string)($s['username']??'')).'&password='.rawurlencode((string)($s['password']??''));
  if($action!=='') $url.='&action='.rawurlencode($action);
  foreach($extra as $k=>$v) $url.='&'.rawurlencode((string)$k).'='.rawurlencode((string)$v);
  return $url;
}
function gp_xtream_api($s,$action,$extra=[]){
  $s=gp_xtream_normalize_source((array)$s);
  if(trim((string)($s['username']??''))==='' || (string)($s['password']??'')==='') throw new RuntimeException('Fonte Xtream sem usuário/senha.');
  $primary=gp_xtream_api_url($s,$action,$extra);

  // Login/base costuma ser pequeno. Catálogos Xtream podem ser enormes e lentos.
  // Não podemos matar get_live_streams/get_vod_streams/get_series em 35 segundos.
  $catalogActions=[
    'get_live_categories','get_vod_categories','get_series_categories',
    'get_live_streams','get_vod_streams','get_series',
    'get_short_epg','get_simple_data_table'
  ];
  $timeout=in_array((string)$action,$catalogActions,true) ? 90 : 45;

  try{
    return gp_http_json($primary,$timeout);
  }catch(Throwable $e){
    $host=(string)($s['host']??'');
    $msg=$e->getMessage();
    $isTimeout=(stripos($msg,'timed out')!==false || stripos($msg,'JSON Xtream incompleto')!==false);
    $alternate='';
    if(stripos($host,'http://')===0)$alternate='https://'.substr($host,7);
    elseif(stripos($host,'https://')===0)$alternate='http://'.substr($host,8);
    if($alternate!=='' && !$isTimeout){
      try{
        return gp_http_json(gp_xtream_api_url($s,$action,$extra,$alternate),$timeout);
      }catch(Throwable $e2){
        throw new RuntimeException('API Xtream falhou nos dois protocolos. Principal: '.$e->getMessage().' | Alternativo: '.$e2->getMessage());
      }
    }
    throw $e;
  }
}
function gp_category_allowed(PDO $pdo,$u,$catId){if(!$catId)return true;$st=$pdo->prepare('SELECT is_adult,enabled FROM gp_categories WHERE id=? LIMIT 1');$st->execute([$catId]);$c=$st->fetch();if(!$c||!(int)$c['enabled'])return false;if((int)$c['is_adult'] && !(int)($u['adult_access']??0))return false;return true;}
function gp_public_id($kind,$id){$code=$kind==='episode'?3:($kind==='series'?2:1);return ((int)$id)*10+$code;}
function gp_decode_id($public){$public=(int)$public;$code=$public%10;$id=(int)(($public-$code)/10);return [$code,$id];}
function gp_item_json($r){return ['id'=>gp_public_id('item',(int)$r['id']),'type'=>$r['type'],'name'=>$r['name'],'logo'=>gp_abs($r['logo']??''),'backdrop'=>gp_abs($r['backdrop_url']??''),'synopsis'=>$r['synopsis']??'','release_year'=>(int)($r['release_year']??0),'tmdb_id'=>(int)($r['tmdb_id']??0),'group_title'=>$r['category_name']??'','source_id'=>(int)$r['source_id'],'source_name'=>$r['source_name']??'','stream_format'=>$r['container_ext']??'auto','is_adult'=>(bool)($r['is_adult']??0)];}
