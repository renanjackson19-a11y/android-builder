<?php
// V9.0.93 HOT: adult flags explicit + bouquet adult VOD resolved in includes/auth.php.
require __DIR__.'/includes/xtream.php';
require_once __DIR__.'/includes/epg.php';
header('Content-Type: application/json; charset=utf-8');
header('Connection: close');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');
header('Access-Control-Allow-Origin: *');
date_default_timezone_set('America/Sao_Paulo');

$username=$_GET['username']??$_POST['username']??null;
$password=$_GET['password']??$_POST['password']??null;
$action=$_GET['action']??$_POST['action']??null;
$series_id=$_GET['series_id']??$_POST['series_id']??null;
$vod_id=$_GET['vod_id']??$_POST['vod_id']??null;
$category_id=$_GET['category_id']??$_POST['category_id']??null;
$stream_id=$_GET['stream_id']??$_POST['stream_id']??$_GET['id']??$_POST['id']??null;
if($category_id==='*')$category_id=null;

$map=['200'=>'get_vod_categories','201'=>'get_live_categories','202'=>'get_live_streams','203'=>'get_vod_streams','204'=>'get_series_info','205'=>'get_short_epg','206'=>'get_series_categories','207'=>'get_simple_data_table','208'=>'get_series','209'=>'get_vod_info'];
if(is_numeric($action)&&isset($map[(string)$action]))$action=$map[(string)$action];

if(!$username||!$password){http_response_code(401);echo json_encode(['user_info'=>['auth'=>0,'msg'=>'username e password necessario!']]);exit;}
$u=gp_xtream_auth_reference($pdo,$username,$password);
if(!$u){http_response_code(401);echo json_encode(['user_info'=>['auth'=>0],'green_play'=>gp_app_notice_payload($pdo,'invalid_credentials')],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;}

$expired=!empty($u['expires_at'])&&strtotime($u['expires_at'])<time();
$blocked=isset($u['status'])&&$u['status']!=='active';
$gpNoticeState=$expired?'expired':($blocked?'blocked':'');
$gpUniversalNotice=($gpNoticeState!=='' && gp_app_notice_enabled($pdo,$gpNoticeState));
// Em modo universal o login continua aceito e o catálogo REAL permanece visível.
// O aviso só substitui a reprodução quando o cliente abre Canal, Filme ou Episódio.
$auth=$gpUniversalNotice?'1':((!$expired&&!$blocked)?'1':'0');
$status=$gpUniversalNotice?'Active':($expired?'Expired':($blocked?'Disabled':'Active'));
$adult=(int)($u['adult_access']??0);
$bouquet=(int)($u['bouquet_id']??0);

$allowed=gp_user_allowed_category_ids($pdo,$u);
$isTrial='0';try{$qt=$pdo->prepare('SELECT 1 FROM gp_trials WHERE user_id=? LIMIT 1');$qt->execute([(int)$u['id']]);if($qt->fetchColumn())$isTrial='1';}catch(Throwable $e){if(strpos((string)$u['username'],'TESTE-')===0)$isTrial='1';}

$gp_public_host=preg_replace('/:\d+$/','',(string)($_SERVER['HTTP_HOST']??parse_url(gp_xtream_root(),PHP_URL_HOST)));
function gp_vod_own_http_direct($host,$username,$password,$id){
  return 'http://'.$host.'/movie/'.rawurlencode((string)$username).'/'.rawurlencode((string)$password).'/'.(int)$id.'.mp4';
}

// V50 - COMPATIBILIDADE ADITIVA: alguns apps Xtream validam a conta com action=get_user_info.
// Este bloco e NOVO e independente. O login antigo sem action e todas as demais actions abaixo permanecem intactos.
if($action==='get_user_info'){
 $activeCons=function_exists('gp_stream_user_session_count')?gp_stream_user_session_count($pdo,(int)$u['id']):0;
 $maxCons=max(1,(int)($u['max_connections']??1));
 $gpState=$expired?'expired':($blocked?'blocked':'active');
 $exp=!empty($u['expires_at'])?strtotime($u['expires_at']):0;
 $created=!empty($u['created_at'])?strtotime($u['created_at']):time();
 $scheme=(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')?'https':'http';
 $host=$_SERVER['HTTP_HOST']??parse_url(gp_xtream_root(),PHP_URL_HOST);
 $hostOnly=preg_replace('/:\d+$/','',$host);
 $port=(string)($_SERVER['SERVER_PORT']??($scheme==='https'?'443':'80'));
 echo json_encode([
  'user_info'=>[
   'username'=>(string)$u['username'],
   'password'=>(string)$password,
   'message'=>$auth==='1'?'BEM-VINDOS!':gp_app_notice_message($pdo,$gpState),
   'auth'=>(int)$auth,
   'status'=>$status,
   'exp_date'=>(int)($gpUniversalNotice?(time()+86400):$exp),
   'is_trial'=>$isTrial,
   'active_cons'=>(int)$activeCons,
   'created_at'=>(string)$created,
   'max_connections'=>(string)($u['max_connections']??1),
   'allowed_output_formats'=>['m3u8','ts','rtmp'],
   'adult_access'=>(int)$adult,
   'adult_pin'=>(string)($u['adult_pin']??'0000')
  ],
  'server_info'=>[
   'painel'=>'XTREAM API','version'=>'0.0.1','revision'=>gp_catalog_revision($pdo),'url'=>$hostOnly,'port'=>$port,'https_port'=>'443',
   'server_protocol'=>$scheme,'rtmp_port'=>'8880','timestamp_now'=>time(),'time_now'=>date('Y-m-d H:i:s'),'timezone'=>date_default_timezone_get()
  ],
  'green_play'=>array_merge(gp_app_notice_payload($pdo,$gpState),['limit_reached'=>$activeCons>=$maxCons,'app_status_url'=>gp_abs('app_status.php')]),
  'app_notice'=>gp_app_notice_payload($pdo,$gpState)
 ],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
 exit;
}


if(!$action){
 $activeCons=function_exists('gp_stream_user_session_count')?gp_stream_user_session_count($pdo,(int)$u['id']):0;$maxCons=max(1,(int)($u['max_connections']??1));$gpState=$expired?'expired':($blocked?'blocked':'active');
 $exp=!empty($u['expires_at'])?strtotime($u['expires_at']):0;
 $created=!empty($u['created_at'])?strtotime($u['created_at']):time();
 $scheme=(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')?'https':'http';
 $host=$_SERVER['HTTP_HOST']??parse_url(gp_xtream_root(),PHP_URL_HOST);
 $hostOnly=preg_replace('/:\d+$/','',$host);
 $port=(string)($_SERVER['SERVER_PORT']??($scheme==='https'?'443':'80'));
 echo json_encode([
  'user_info'=>[
   'username'=>(string)$u['username'],'password'=>(string)$password,'message'=>$auth==='1'?'BEM-VINDOS!':gp_app_notice_message($pdo,$gpState),'auth'=>$auth,'status'=>$status,
   'exp_date'=>(string)($gpUniversalNotice?(time()+86400):$exp),'is_trial'=>$isTrial,'active_cons'=>$activeCons,
   'created_at'=>(string)$created,'max_connections'=>(string)($u['max_connections']??1),
   'allowed_output_formats'=>['m3u8','ts','rtmp'],
   'adult_access'=>(int)$adult,
   'adult_pin'=>(string)($u['adult_pin']??'0000')
  ],
  'server_info'=>[
   'painel'=>'XTREAM API','version'=>'0.0.1','revision'=>gp_catalog_revision($pdo),'url'=>$hostOnly,'port'=>$port,'https_port'=>'443',
   'server_protocol'=>$scheme,'rtmp_port'=>'8880','timestamp_now'=>time(),'time_now'=>date('Y-m-d H:i:s'),'timezone'=>date_default_timezone_get()
  ],
  'green_play'=>array_merge(gp_app_notice_payload($pdo,$gpState),['limit_reached'=>$activeCons>=$maxCons,'app_status_url'=>gp_abs('app_status.php')]),
  'app_notice'=>gp_app_notice_payload($pdo,$gpState)
 ],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;
}
if($auth!=='1'){gp_app_notice_json_error($pdo,$expired?'expired':'blocked',401);}
// Não troca categorias/itens por AVISO. O catálogo normal é mantido.

if(in_array($action,['get_live_categories','get_vod_categories','get_series_categories'],true)){
 $type=$action==='get_live_categories'?'live':($action==='get_vod_categories'?'movie':'series');
 $sql='SELECT c.id,c.name,c.is_adult FROM gp_categories c JOIN gp_sources gs ON gs.id=c.source_id AND gs.active=1 WHERE c.type=? AND c.enabled=1';$pa=[$type];
 if(!$adult)$sql.=' AND COALESCE(c.is_adult,0)=0';
 if($bouquet<=0 || !$allowed){echo json_encode([],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;} $ph=implode(',',array_fill(0,count($allowed),'?'));$sql.=" AND c.id IN ($ph)";$pa=array_merge($pa,$allowed);
 $sql.=' ORDER BY c.sort_order,c.id';$q=$pdo->prepare($sql);$q->execute($pa);$out=[];
 foreach($q as $r)$out[]=['category_id'=>(string)$r['id'],'category_name'=>$r['name'],'parent_id'=>0,'is_adult'=>(string)($r['is_adult']??0)];
 echo json_encode($out,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;
}

function gp_public_vod_variant(string $name): string {
 $n=mb_strtolower(htmlspecialchars_decode($name),'UTF-8');
 if(preg_match('/(?:\[|\(|\b)(?:leg|legendado|legendada|sub|subtitled|l)(?:\]|\)|\b)/u',$n))return 'legendado';
 if(preg_match('/(?:\[|\(|\b)(?:dub|dublado|dublada|dual|d)(?:\]|\)|\b)/u',$n))return 'dublado';
 return 'padrao';
}
function gp_public_vod_canonical(string $name): string {
 $n=mb_strtolower(htmlspecialchars_decode($name),'UTF-8');
 // Conserva a edição de idioma, mas remove rótulos puramente técnicos que geram cópias visuais.
 $n=preg_replace('/\b(?:2160p|1080p|720p|480p|4k|uhd|fhd|full\s*hd|hd|h\.?265|hevc|h\.?264|x265|x264|web[- .]?dl|webrip|bluray|brrip|hdr|sdr)\b/iu',' ',$n);
 $n=preg_replace('/[\s._-]*(?:\(|\[)?(?:19|20)\d{2}(?:\)|\])?\s*$/u','',$n);
 $n=preg_replace('/(?:^|\s)[\-_–—]+(?:\s|$)/u',' ',$n);
 $n=preg_replace('/\s+/u',' ',trim($n));
 return gp_norm($n);
}
function gp_public_vod_poster_key(string $url): string {
 $u=trim(mb_strtolower($url,'UTF-8'));if($u==='')return '';
 $q=strpos($u,'?');if($q!==false)$u=substr($u,0,$q);
 return $u;
}

if(in_array($action,['get_live_streams','get_vod_streams'],true)){
 $type=$action==='get_live_streams'?'live':'movie';
 $sql='SELECT i.*,c.is_adult FROM gp_items i JOIN gp_categories c ON c.id=i.category_id AND c.source_id=i.source_id JOIN gp_sources gs ON gs.id=i.source_id AND gs.active=1 WHERE i.type=? AND i.active=1 AND c.enabled=1';$pa=[$type];
 if(!$adult)$sql.=' AND COALESCE(c.is_adult,0)=0';
 if($bouquet<=0 || !$allowed){echo json_encode([],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;} $ph=implode(',',array_fill(0,count($allowed),'?'));$sql.=" AND i.category_id IN ($ph)";$pa=array_merge($pa,$allowed);
 if($category_id!==null&&$category_id!==''&&is_numeric($category_id)){$sql.=' AND i.category_id=?';$pa[]=(int)$category_id;}
 $sql.=' ORDER BY i.name ASC,COALESCE(i.release_year,0) DESC,i.id DESC';$q=$pdo->prepare($sql);$q->execute($pa);$out=[];$num=0;$seenMovieYears=[];$seenMovieTmdb=[];$seenMoviePoster=[];
 foreach($q as $r){
  if($type==='movie'){
   // V9.0.75 patch: remove repeticoes na saida publica inclusive quando o mesmo titulo vem de fontes diferentes.
   // Nao desativa registros no banco; o filtro respeita primeiro bouquet/categoria/adulto do cliente.
   $rawName=htmlspecialchars_decode((string)($r['name']??''));
   $variant=gp_public_vod_variant($rawName);
   $norm=gp_public_vod_canonical($rawName);
   if($norm==='')$norm=trim((string)($r['normalized_name']??''));
   $year=(int)($r['release_year']??0);
   $tmdb=(int)($r['tmdb_id']??0);
   $posterKey=gp_public_vod_poster_key((string)($r['logo']??''));
   $group=$norm.'|'.$variant;
   if($tmdb>0){$tk=$tmdb.'|'.$variant;if(isset($seenMovieTmdb[$tk]))continue;$seenMovieTmdb[$tk]=true;}
   if($posterKey!=='' && $norm!==''){$pk=$posterKey.'|'.$variant;if(isset($seenMoviePoster[$pk]))continue;$seenMoviePoster[$pk]=true;}
   if($norm!==''){
    // Ano ausente não cria uma segunda cópia quando o mesmo título já apareceu com ano válido.
    if($year===0 && !empty($seenMovieYears[$group]))continue;
    if($year>0 && (isset($seenMovieYears[$group][$year]) || isset($seenMovieYears[$group][0])))continue;
    if(!isset($seenMovieYears[$group]))$seenMovieYears[$group]=[];
    $seenMovieYears[$group][$year]=true;
   }
  }
  $num++;
  if($type==='live'){
   $epgChannelId=gp_epg_channel_id_for_item($pdo,$r);
   $out[]=['num'=>$num,'name'=>htmlspecialchars_decode((string)$r['name']),'stream_type'=>'live','stream_id'=>(int)$r['id'],'stream_icon'=>$r['logo']??'','epg_channel_id'=>$epgChannelId,'added'=>'','is_adult'=>(string)($r['is_adult']??0),'custom_sid'=>'','tv_archive'=>0,'direct_source'=>'','tv_archive_duration'=>0,'category_id'=>(string)($r['category_id']??''),'category_ids'=>[(int)($r['category_id']??0)],'thumbnail'=>''];
  }
  else $out[]=[
    'num'=>$num,
    'name'=>htmlspecialchars_decode((string)$r['name']),
    'title'=>htmlspecialchars_decode((string)$r['name']),
    'year'=>(string)($r['release_year']??''),
    'stream_type'=>'movie',
    'stream_id'=>(int)$r['id'],
    'stream_icon'=>(string)($r['logo']??''),
    'rating'=>(string)($r['rating']??'0'),
    'rating_5based'=>(float)($r['rating_5based']??0),
    'added'=>(string)($r['created_at']??''),
    'is_adult'=>(string)($r['is_adult']??0),
    'category_id'=>(string)($r['category_id']??''),
    'container_extension'=>'mp4',
    'custom_sid'=>'',
    'direct_source'=>gp_vod_own_http_direct($gp_public_host,$username,$password,$r['id'])
  ];
 }
 echo json_encode($out,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;
}

if($action==='get_series'){
 $sql='SELECT s.*,c.is_adult FROM gp_series s JOIN gp_categories c ON c.id=s.category_id AND c.source_id=s.source_id JOIN gp_sources gs ON gs.id=s.source_id AND gs.active=1 WHERE s.active=1 AND c.enabled=1';$pa=[];
 if(!$adult)$sql.=' AND COALESCE(c.is_adult,0)=0';
 if($bouquet<=0 || !$allowed){echo json_encode([],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;} $ph=implode(',',array_fill(0,count($allowed),'?'));$sql.=" AND s.category_id IN ($ph)";$pa=array_merge($pa,$allowed);
 if($category_id!==null&&$category_id!==''&&is_numeric($category_id)){$sql.=' AND s.category_id=?';$pa[]=(int)$category_id;}
 $sql.=' ORDER BY s.name ASC,COALESCE(s.release_year,0) DESC,s.id DESC';$q=$pdo->prepare($sql);$q->execute($pa);$out=[];$num=0;$seenSeries=[];
 foreach($q as $r){$sn=gp_public_vod_canonical((string)($r['name']??''));$sy=(int)($r['release_year']??0);if($sn!==''){if($sy===0&&!empty($seenSeries[$sn]))continue;if($sy>0&&(isset($seenSeries[$sn][$sy])||isset($seenSeries[$sn][0])))continue;if(!isset($seenSeries[$sn]))$seenSeries[$sn]=[];$seenSeries[$sn][$sy]=true;}$num++;$out[]=['num'=>$num,'name'=>htmlspecialchars_decode((string)$r['name']),'title'=>htmlspecialchars_decode((string)$r['name']),'year'=>(string)($r['release_year']??''),'stream_type'=>'series','series_id'=>(int)$r['id'],'cover'=>$r['logo']??'','plot'=>$r['synopsis']??'','cast'=>null,'director'=>null,'genre'=>'','release_date'=>'','releaseDate'=>'','last_modified'=>'','rating'=>'0','rating_5based'=>0,'backdrop_path'=>array_values(array_filter([$r['backdrop_url']??''])),'youtube_trailer'=>null,'episode_run_time'=>'0','category_id'=>(string)($r['category_id']??''),'category_ids'=>[(int)($r['category_id']??0)],'is_adult'=>(string)($r['is_adult']??0)];}
 echo json_encode($out,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;
}


function gp_vod_metadata_columns(PDO $pdo):void{
 static $done=false;if($done)return;$done=true;
 try{
  $cols=$pdo->query("SHOW COLUMNS FROM gp_items")->fetchAll(PDO::FETCH_COLUMN);
  $defs=[
   'release_date'=>"VARCHAR(40) NULL",
   'genre'=>"VARCHAR(255) NULL",
   'duration'=>"VARCHAR(40) NULL",
   'rating'=>"VARCHAR(20) NULL",
   'rating_5based'=>"DECIMAL(5,2) NULL",
   'director'=>"TEXT NULL",
   'actors'=>"TEXT NULL",
   'country'=>"VARCHAR(255) NULL",
   'youtube_trailer'=>"TEXT NULL",
   'episode_run_time'=>"VARCHAR(40) NULL",
   'bitrate'=>"INT NULL",
   'metadata_synced_at'=>"DATETIME NULL"
  ];
  foreach($defs as $name=>$def){
   if(!in_array($name,$cols,true)){
    try{$pdo->exec("ALTER TABLE gp_items ADD COLUMN `$name` $def");}catch(Throwable $e){}
   }
  }
 }catch(Throwable $e){}
}

function gp_vod_first_nonempty(array $sources,array $keys,$default=''){
 foreach($sources as $src){
  if(!is_array($src))continue;
  foreach($keys as $k){
   if(array_key_exists($k,$src)){
    $v=$src[$k];
    if(is_array($v)){
     foreach($v as $vv){if(is_string($vv)&&trim($vv)!=='')return trim($vv);}
    }elseif($v!==null && trim((string)$v)!=='')return trim((string)$v);
   }
  }
 }
 return $default;
}

function gp_refresh_vod_metadata(PDO $pdo,array $movie):array{
 gp_vod_metadata_columns($pdo);
 $last=(string)($movie['metadata_synced_at']??'');
 $hasUseful=trim((string)($movie['genre']??''))!=='' ||
            trim((string)($movie['release_date']??''))!=='' ||
            trim((string)($movie['synopsis']??''))!=='' ||
            ((float)($movie['rating']??0)>0);
 if($last!=='' && strtotime($last)>time()-2592000 && $hasUseful)return $movie;

 try{
  $src=gp_xtream_source($pdo,(int)$movie['source_id']);
  if(!$src || ($src['source_type']??'')!=='xtream')return $movie;
  $providerId=(string)($movie['provider_id']??'');
  if($providerId==='')return $movie;

  $remote=gp_xtream_api($src,'get_vod_info',['vod_id'=>$providerId]);
  if(!is_array($remote))return $movie;
  $info=is_array($remote['info']??null)?$remote['info']:[];
  $md=is_array($remote['movie_data']??null)?$remote['movie_data']:[];
  $sources=[$info,$md];

  $cover=gp_vod_first_nonempty($sources,['movie_image','cover_big','stream_icon','cover'],(string)($movie['logo']??''));
  $backdrop=gp_vod_first_nonempty($sources,['backdrop_path','backdrop','backdrop_url'],(string)($movie['backdrop_url']??''));
  $plot=gp_vod_first_nonempty($sources,['plot','description','overview','synopsis'],(string)($movie['synopsis']??''));
  $release=gp_vod_first_nonempty($sources,['release_date','releasedate','releaseDate'],(string)($movie['release_date']??''));
  $genre=gp_vod_first_nonempty($sources,['genre'],(string)($movie['genre']??''));
  $duration=gp_vod_first_nonempty($sources,['duration'],(string)($movie['duration']??''));
  $rating=gp_vod_first_nonempty($sources,['rating'],(string)($movie['rating']??'0'));
  $rating5=(float)gp_vod_first_nonempty($sources,['rating_5based'],'0');
  if($rating5<=0 && is_numeric($rating) && (float)$rating>0)$rating5=((float)$rating)/2;
  $director=gp_vod_first_nonempty($sources,['director'],(string)($movie['director']??''));
  $actors=gp_vod_first_nonempty($sources,['actors','cast'],(string)($movie['actors']??''));
  $country=gp_vod_first_nonempty($sources,['country'],(string)($movie['country']??''));
  $trailer=gp_vod_first_nonempty($sources,['youtube_trailer','youtubeTrailer'],(string)($movie['youtube_trailer']??''));
  $runtime=gp_vod_first_nonempty($sources,['episode_run_time','runtime'],(string)($movie['episode_run_time']??''));
  $bitrate=(int)gp_vod_first_nonempty($sources,['bitrate'],(string)($movie['bitrate']??0));
  $year=(int)gp_vod_first_nonempty($sources,['year'],(string)($movie['release_year']??0));
  $tmdb=(int)gp_vod_first_nonempty($sources,['tmdb_id','tmdb'],(string)($movie['tmdb_id']??0));

  $q=$pdo->prepare("UPDATE gp_items SET logo=?,backdrop_url=?,synopsis=?,release_date=?,genre=?,duration=?,rating=?,rating_5based=?,director=?,actors=?,country=?,youtube_trailer=?,episode_run_time=?,bitrate=?,release_year=CASE WHEN ?>0 THEN ? ELSE release_year END,tmdb_id=CASE WHEN ?>0 THEN ? ELSE tmdb_id END,metadata_synced_at=NOW() WHERE id=?");
  $q->execute([$cover,$backdrop,$plot,$release,$genre,$duration,$rating,$rating5,$director,$actors,$country,$trailer,$runtime,$bitrate,$year,$year,$tmdb,$tmdb,(int)$movie['id']]);

  $q=$pdo->prepare("SELECT * FROM gp_items WHERE id=?");
  $q->execute([(int)$movie['id']]);
  $fresh=$q->fetch();
  return $fresh?:$movie;
 }catch(Throwable $e){
  // Metadados não podem derrubar o filme. Reprodução continua mesmo se a fonte não responder.
  return $movie;
 }
}

if($action==='get_vod_info'){
 $id=(int)$vod_id;
 gp_vod_metadata_columns($pdo);
 if($bouquet<=0 || !$allowed){echo json_encode(['info'=>[],'movie_data'=>[]]);exit;}
 $ph=implode(',',array_fill(0,count($allowed),'?'));
 $sql="SELECT i.* FROM gp_items i JOIN gp_categories c ON c.id=i.category_id AND c.source_id=i.source_id JOIN gp_sources gs ON gs.id=i.source_id AND gs.active=1 WHERE i.id=? AND i.type='movie' AND i.active=1 AND c.enabled=1 AND i.category_id IN ($ph)";
 $pa=array_merge([$id],$allowed);
 if(!$adult)$sql.=' AND COALESCE(c.is_adult,0)=0';
 $q=$pdo->prepare($sql);$q->execute($pa);$r=$q->fetch();
 if(!$r){echo json_encode(['info'=>[],'movie_data'=>[]]);exit;}
 $r=gp_refresh_vod_metadata($pdo,$r);

 // O server 15-11 devolve um bloco VOD completo. Mantemos os mesmos nomes.
 $duration=(string)($r['duration']??'00:00:00');
 $durationSecs=0;
 if(preg_match('/^(\d+):(\d+):(\d+)/',$duration,$dm)){
   $durationSecs=((int)$dm[1]*3600)+((int)$dm[2]*60)+(int)$dm[3];
 }elseif(preg_match('/^(\d+):(\d+)/',$duration,$dm)){
   $durationSecs=((int)$dm[1]*60)+(int)$dm[2];
 }elseif(ctype_digit(trim($duration))){
   $durationSecs=(int)$duration;
 }elseif(is_numeric((string)($r['episode_run_time']??''))){
   $durationSecs=((int)$r['episode_run_time'])*60;
 }

 $cover=(string)($r['logo']??'');
 $backdrop=(string)($r['backdrop_url']??'');
 $plot=(string)($r['synopsis']??'');
 $year=(int)($r['release_year']??0);

 $info=[
   'kinopoisk_url'=>'',
   'tmdb_id'=>(string)($r['tmdb_id']??''),
   'name'=>htmlspecialchars_decode((string)$r['name']),
   'o_name'=>htmlspecialchars_decode((string)$r['name']),
   'cover_big'=>$cover,
   'movie_image'=>$cover,
   'release_date'=>(string)($r['release_date']??''),
   'releasedate'=>(string)($r['release_date']??''),
   'episode_run_time'=>(string)($r['episode_run_time']??''),
   'youtube_trailer'=>(string)($r['youtube_trailer']??''),
   'director'=>(string)($r['director']??''),
   'actors'=>(string)($r['actors']??''),
   'cast'=>(string)($r['actors']??''),
   'description'=>$plot,
   'plot'=>$plot,
   'age'=>'',
   'mpaa_rating'=>'',
   'rating_count_kinopoisk'=>0,
   'country'=>(string)($r['country']??''),
   'genre'=>(string)($r['genre']??''),
   'backdrop_path'=>$backdrop!==''?[$backdrop]:[],
   'duration_secs'=>$durationSecs,
   'duration'=>$duration,
   'runtime'=>$durationSecs,
   'bitrate'=>(int)($r['bitrate']??0),
   'rating'=>(string)($r['rating']??'0'),
   'subtitles'=>[],
   'video'=>[],
   'audio'=>[]
 ];

 $movie_data=[
   'name'=>htmlspecialchars_decode((string)$r['name']),
   'title'=>htmlspecialchars_decode((string)$r['name']),
   'year'=>$year,
   'added'=>(string)($r['created_at']??''),
   'stream_id'=>(int)$r['id'],
   'category_id'=>(int)($r['category_id']??0),
   'category_ids'=>[(int)($r['category_id']??0)],
   'container_extension'=>'mp4',
   'custom_sid'=>'',
   'direct_source'=>gp_vod_own_http_direct($gp_public_host,$username,$password,$r['id']),
   // extras tolerated by universal clients
   'stream_icon'=>$cover,
   'movie_image'=>$cover
 ];

 echo json_encode(['info'=>$info,'movie_data'=>$movie_data],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
 exit;
}

if($action==='get_series_info'){
 $sid=(int)$series_id;
 if($bouquet<=0 || !$allowed){http_response_code(404);echo json_encode([]);exit;}
 $ph=implode(',',array_fill(0,count($allowed),'?'));
 $sql="SELECT se.* FROM gp_series se JOIN gp_categories c ON c.id=se.category_id AND c.source_id=se.source_id JOIN gp_sources gs ON gs.id=se.source_id AND gs.active=1 WHERE se.id=? AND se.active=1 AND c.enabled=1 AND se.category_id IN ($ph)";
 $pa=array_merge([$sid],$allowed);if(!$adult)$sql.=' AND COALESCE(c.is_adult,0)=0';
 $q=$pdo->prepare($sql);$q->execute($pa);$s=$q->fetch();
 if(!$s){http_response_code(404);echo json_encode([]);exit;}
 require_once __DIR__.'/includes/sync.php';
 if(empty($s['episodes_synced_at'])||strtotime($s['episodes_synced_at'])<time()-21600){try{gp_sync_series_episodes($pdo,$s);}catch(Throwable $e){}}
 $eq=$pdo->prepare('SELECT * FROM gp_episodes WHERE series_id=? AND active=1 ORDER BY season_number,episode_number');$eq->execute([$sid]);
 $episodes=[];$seasons=[];
 foreach($eq as $e){$sn=(int)$e['season_number'];if(!isset($seasons[$sn]))$seasons[$sn]=['air_date'=>'','episode_count'=>0,'id'=>$sn,'name'=>'Temporada '.$sn,'overview'=>'','season_number'=>$sn,'cover'=>$s['logo']??'','cover_big'=>$s['logo']??''];$seasons[$sn]['episode_count']++;$episodes[(string)$sn][]=['id'=>(string)$e['id'],'episode_num'=>(string)$e['episode_number'],'title'=>htmlspecialchars_decode((string)$e['name']),'container_extension'=>$e['container_ext']?:'mp4','info'=>['cover_big'=>$e['logo']??'','movie_image'=>$e['logo']??'','plot'=>$e['synopsis']??''],'subtitles'=>[],'custom_sid'=>'','added'=>'','season'=>$sn,'direct_source'=>''];}
 $info=['name'=>htmlspecialchars_decode((string)$s['name']),'title'=>htmlspecialchars_decode((string)$s['name']),'cover'=>$s['logo']??'','year'=>(string)($s['release_year']??''),'plot'=>$s['synopsis']??'','cast'=>'','director'=>'','genre'=>'','release_date'=>'','last_modified'=>[],'rating'=>'0','rating_5based'=>0,'backdrop_path'=>array_values(array_filter([$s['backdrop_url']??''])),'youtube_trailer'=>'','episode_run_time'=>'','category_id'=>(string)($s['category_id']??''),'category_ids'=>[(int)($s['category_id']??0)]];
 echo json_encode(['seasons'=>array_values($seasons),'info'=>$info,'episodes'=>$episodes],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;
}

if($action==='get_short_epg'||$action==='get_simple_data_table'){
 $id=(int)$stream_id;$out=[];$r=false;
 if($bouquet>0 && $allowed){$ph=implode(',',array_fill(0,count($allowed),'?'));$q=$pdo->prepare("SELECT i.id,i.source_id,i.provider_id,i.tvg_id,i.name,i.normalized_name FROM gp_items i JOIN gp_categories c ON c.id=i.category_id AND c.source_id=i.source_id JOIN gp_sources gs ON gs.id=i.source_id AND gs.active=1 WHERE i.id=? AND i.type='live' AND i.active=1 AND c.enabled=1 AND i.category_id IN ($ph)");$q->execute(array_merge([$id],$allowed));$r=$q->fetch();}
 if($r){$programs=gp_epg_programs_for_item($pdo,$r,50);$n=0;foreach($programs as $x){$n++;$out[]=['id'=>(string)$n,'title'=>base64_encode((string)($x['title']??'')),'start'=>(string)($x['start_time']??''),'end'=>(string)($x['stop_time']??''),'description'=>base64_encode((string)($x['description']??'')),'start_timestamp'=>(string)strtotime((string)($x['start_time']??'')),'stop_timestamp'=>(string)strtotime((string)($x['stop_time']??''))];}}
 echo json_encode(['epg_listings'=>$out],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;
}

http_response_code(401);echo json_encode(['user_info'=>['auth'=>0]]);
