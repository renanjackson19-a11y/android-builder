<?php require __DIR__.'/../includes/bootstrap.php'; require __DIR__.'/../includes/admin_ui.php'; gp_require_admin(); gp_admin_migrate($pdo); $msg='';$err='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 try{
  $a=$_POST['action']??'';
  if($a==='save'){
   $id=(int)($_POST['id']??0);$name=trim($_POST['name']??'');$adult=isset($_POST['adult_access'])?1:0;
   if($name==='')throw new RuntimeException('Informe o nome do bouquet.');
   $requested=array_values(array_unique(array_filter(array_map('intval',(array)($_POST['categories']??[])),fn($v)=>$v>0)));
   $valid=[];
   if($requested){$ph=implode(',',array_fill(0,count($requested),'?'));$st=$pdo->prepare("SELECT c.id FROM gp_categories c JOIN gp_sources s ON s.id=c.source_id AND s.active=1 WHERE c.enabled=1 AND c.id IN ($ph)");$st->execute($requested);$valid=array_map('intval',$st->fetchAll(PDO::FETCH_COLUMN));}
   // V9.0.93: ao liberar +18, inclui automaticamente filmes/séries adultas das mesmas fontes escolhidas.
   if($adult && $valid){
     $ph=implode(',',array_fill(0,count($valid),'?'));$qs=$pdo->prepare("SELECT DISTINCT source_id FROM gp_categories WHERE id IN ($ph)");$qs->execute($valid);$srcIds=array_values(array_filter(array_unique(array_map('intval',$qs->fetchAll(PDO::FETCH_COLUMN)))));
     if($srcIds){$sph=implode(',',array_fill(0,count($srcIds),'?'));$qa=$pdo->prepare("SELECT c.id FROM gp_categories c JOIN gp_sources s ON s.id=c.source_id AND s.active=1 WHERE c.enabled=1 AND c.is_adult=1 AND c.type IN ('movie','series') AND c.source_id IN ($sph)");$qa->execute($srcIds);$valid=array_values(array_unique(array_merge($valid,array_map('intval',$qa->fetchAll(PDO::FETCH_COLUMN)))));}
   }
   $pdo->beginTransaction();
   try{
    if($id){$pdo->prepare('UPDATE bouquets SET name=?,adult_access=?,active=1 WHERE id=?')->execute([$name,$adult,$id]);}
    else{$pdo->prepare('INSERT INTO bouquets(name,adult_access,active) VALUES(?,?,1)')->execute([$name,$adult]);$id=(int)$pdo->lastInsertId();}
    $pdo->prepare('DELETE FROM bouquet_categories WHERE bouquet_id=?')->execute([$id]);
    $ins=$pdo->prepare('INSERT IGNORE INTO bouquet_categories(bouquet_id,category_id) VALUES(?,?)');foreach($valid as $cid)$ins->execute([$id,$cid]);
    $pdo->commit();
   }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
   gp_bump_catalog_revision($pdo);gp_admin_audit($pdo,'bouquet.save',"$id $name categorias=".count($valid));$msg='Bouquet salvo. Canais, filmes e séries já estão valendo na próxima consulta do aplicativo.';
  }elseif($a==='delete'){
   $id=(int)$_POST['id'];$pdo->beginTransaction();try{$pdo->prepare('DELETE FROM bouquet_categories WHERE bouquet_id=?')->execute([$id]);$pdo->prepare('DELETE FROM bouquets WHERE id=?')->execute([$id]);$pdo->commit();gp_bump_catalog_revision($pdo);}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}$msg='Bouquet excluído.';
  }
 }catch(Throwable $e){$err=$e->getMessage();}
}
$edit=(int)($_GET['edit']??0);$b=null;$selected=[];if($edit){$s=$pdo->prepare('SELECT * FROM bouquets WHERE id=?');$s->execute([$edit]);$b=$s->fetch();$s=$pdo->prepare('SELECT category_id FROM bouquet_categories WHERE bouquet_id=?');$s->execute([$edit]);$selected=array_map('intval',$s->fetchAll(PDO::FETCH_COLUMN));}
$cats=$pdo->query("SELECT c.*,gs.name source_name,gs.id source_id,
CASE c.type
 WHEN 'live' THEN (SELECT COUNT(*) FROM gp_items i WHERE i.category_id=c.id AND i.type='live' AND i.active=1)
 WHEN 'movie' THEN (SELECT COUNT(*) FROM gp_items i WHERE i.category_id=c.id AND i.type='movie' AND i.active=1)
 ELSE (SELECT COUNT(*) FROM gp_series s WHERE s.category_id=c.id AND s.active=1)
END content_count
FROM gp_categories c
LEFT JOIN gp_sources gs ON gs.id=c.source_id
WHERE c.enabled=1 AND gs.active=1
ORDER BY FIELD(c.type,'live','movie','series'),gs.name,c.sort_order,c.name")->fetchAll();$bouquets=$pdo->query("SELECT b.*,(SELECT COUNT(*) FROM bouquet_categories bc WHERE bc.bouquet_id=b.id) cat_count,(SELECT COUNT(*) FROM users u WHERE u.bouquet_id=b.id) user_count FROM bouquets b ORDER BY b.id")->fetchAll();
gp_admin_header('Bouquets / Pacotes'); if($msg)echo '<div class="ok">'.gp_h($msg).'</div>';if($err)echo '<div class="err">'.gp_h($err).'</div>'; ?>
<?php if($msg)echo '<div class="ok">'.gp_h($msg).'</div>';if($err)echo '<div class="err">'.gp_h($err).'</div>'; ?>
<div class="section-head">
  <div><h2>Bouquets / Pacotes</h2><p>Escolha Canais, Filmes e Séries separadamente, organizados por fonte.</p></div>
  <div class="actions"><a class="btn2 btn" href="clientes.php">Clientes</a></div>
</div>

<div class="card">
<form method="post" id="bouquetForm">
<input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?=intval($b['id']??0)?>">
<div class="form-grid">
  <label>Nome do pacote<input name="name" value="<?=gp_h($b['name']??'')?>" placeholder="Ex.: Completo, Família, Premium" required></label>
  <label class="checkline"><input type="checkbox" name="adult_access" value="1" <?=!empty($b['adult_access'])?'checked':''?>> Permitir conteúdo +18</label>
</div>


<div class="gp-toolbar">
  <input type="search" id="catSearch" placeholder="Buscar categoria ou fonte...">
  <span id="totalSel" class="gp-selected-count"></span>
</div>

<div class="gp-type-tabs" role="tablist">
  <button type="button" class="gp-type-tab active" data-type="live">📺 Canais</button>
  <button type="button" class="gp-type-tab" data-type="movie">🎬 Filmes</button>
  <button type="button" class="gp-type-tab" data-type="series">📺 Séries</button>
</div>

<?php foreach(['live'=>'📺 Canais','movie'=>'🎬 Filmes','series'=>'📺 Séries'] as $type=>$label):
$typeCats=array_values(array_filter($cats,fn($c)=>$c['type']===$type));
$bySource=[];
foreach($typeCats as $c){
  $sourceId=(int)$c['source_id'];
  if(!isset($bySource[$sourceId]))$bySource[$sourceId]=['name'=>(string)($c['source_name']?:('Fonte #'.$sourceId)),'cats'=>[]];
  $bySource[$sourceId]['cats'][]=$c;
}
?>
<section class="gp-type-panel <?=$type==='live'?'active':''?>" data-panel="<?=$type?>">
  <div class="gp-type-title">
    <div>
      <h3><?=$label?></h3>
      <span class="gp-selected-count"><?=count($typeCats)?> categorias</span>
    </div>
    <div class="actions">
      <button type="button" class="gp-mini-btn" onclick="markType('<?=$type?>',true)">Selecionar todos <?=$label?></button>
      <button type="button" class="gp-mini-btn" onclick="markType('<?=$type?>',false)">Desmarcar <?=$label?></button>
    </div>
  </div>

  <?php if(!$bySource): ?>
    <div class="muted" style="padding:12px 0">Nenhuma categoria deste tipo.</div>
  <?php endif; ?>

  <?php foreach($bySource as $sourceId=>$sourceGroup): $sourceName=$sourceGroup['name'];$sourceCats=$sourceGroup['cats']; ?>
  <div class="gp-source-group" data-source-id="<?=intval($sourceId)?>" data-source="<?=gp_h(mb_strtolower($sourceName))?>">
    <div class="gp-source-head">
      <div>
        <b><?=gp_h($sourceName)?> <small style="color:#6f8b79">#<?=intval($sourceId)?></small></b>
        <span><?=count($sourceCats)?> categorias · fonte separada</span>
      </div>
      <div class="actions">
        <button type="button" class="gp-mini-btn" onclick="useOnlySource(this)">Usar só esta fonte</button>
        <button type="button" class="gp-mini-btn" onclick="markSource(this,true)">Adicionar fonte</button>
        <button type="button" class="gp-mini-btn" onclick="markSource(this,false)">Remover fonte</button>
      </div>
    </div>
    <div class="gp-cat-wrap">
    <?php foreach($sourceCats as $c): $checked=in_array((int)$c['id'],$selected,true); ?>
      <label class="gp-cat-item" data-name="<?=gp_h(mb_strtolower(($c['name']??'').' '.($sourceName??'')))?>">
        <input class="cat-check" data-type="<?=$type?>" type="checkbox" name="categories[]" value="<?=intval($c['id'])?>" <?=$checked?'checked':''?>>
        <span class="gp-cat-text">
          <div class="gp-cat-name"><?=gp_h($c['name'])?></div>
          <div class="gp-cat-meta"><?=number_format((int)$c['content_count'],0,',','.')?> itens<?=!empty($c['is_adult'])?' · +18':''?></div>
        </span>
      </label>
    <?php endforeach; ?>
    </div>
  </div>
  <?php endforeach; ?>
</section>
<?php endforeach; ?>

<style>
.gp-type-tabs{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin:16px 0}
.gp-type-tab{background:#0d2116;color:#a9bcae;border:1px solid #244732;box-shadow:none}
.gp-type-tab.active{background:linear-gradient(180deg,#43ef7d,#2bd569);color:#06140a;border-color:transparent}
.gp-type-panel{display:none}.gp-type-panel.active{display:block}
.gp-type-title{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:16px 0 10px}
.gp-type-title>div:first-child{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.gp-type-title h3{margin:0}
.gp-source-group{border:1px solid #1c3a27;border-radius:14px;background:#0a160f;margin:12px 0;padding:12px}
.gp-source-head{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:10px;padding-bottom:9px;border-bottom:1px solid #17311f}
.gp-source-head b{display:block}.gp-source-head span{display:block;color:#7f9586;font-size:12px;margin-top:2px}
@media(max-width:720px){.gp-type-tabs{grid-template-columns:1fr}.gp-type-title,.gp-source-head{align-items:flex-start;flex-direction:column}}
</style>

<div style="margin-top:16px"><button class="btn" type="submit"><?=$b?'Salvar alterações':'Criar bouquet'?></button>
<?php if($b): ?><a class="btn2 btn" href="bouquets.php">Cancelar edição</a><?php endif; ?></div>
</form>
</div>

<div class="card" style="margin-top:14px">
<div class="section-head"><div><h2>Pacotes cadastrados</h2><p>Edite ou remova sem rolagem horizontal no celular.</p></div><div><b><?=count($bouquets)?></b> pacotes</div></div>
<?php if(!$bouquets): ?><div class="muted">Nenhum bouquet cadastrado.</div><?php else: ?>
<div class="gp-pack-cards">
<?php foreach($bouquets as $row): ?>
<div class="gp-pack">
 <div class="gp-pack-head"><div><div class="gp-pack-name"><?=gp_h($row['name'])?></div>
 <div class="gp-pack-meta"><?=intval($row['cat_count'])?> categorias · <?=intval($row['user_count'])?> clientes · <?=$row['adult_access']?'Com +18':'Sem +18'?></div></div>
 <span class="badge"><?=$row['active']?'Ativo':'Inativo'?></span></div>
 <div class="gp-pack-actions"><a class="btn2 btn" href="?edit=<?=intval($row['id'])?>">Editar</a>
 <form method="post" onsubmit="return confirm('Excluir este bouquet?')"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=intval($row['id'])?>"><button class="danger btn" type="submit">Excluir</button></form></div>
</div>
<?php endforeach; ?>
</div><?php endif; ?>
</div>

<script>
const checks=()=>[...document.querySelectorAll('.cat-check')];
function updateCount(){
  const all=checks(), sel=all.filter(x=>x.checked);
  const by={live:0,movie:0,series:0};
  sel.forEach(x=>{if(by[x.dataset.type]!==undefined)by[x.dataset.type]++});
  document.getElementById('totalSel').textContent=`${sel.length} selecionadas · Canais ${by.live} · Filmes ${by.movie} · Séries ${by.series}`;
}
function markType(type,v){
  document.querySelectorAll(`.cat-check[data-type="${type}"]`).forEach(x=>x.checked=v);
  updateCount();
}
function markSource(btn,v){
  const group=btn.closest('.gp-source-group');
  group.querySelectorAll('.cat-check').forEach(x=>x.checked=v);
  updateCount();
}
function useOnlySource(btn){
  const group=btn.closest('.gp-source-group');
  const panel=group.closest('.gp-type-panel');
  panel.querySelectorAll('.cat-check').forEach(x=>x.checked=false);
  group.querySelectorAll('.cat-check').forEach(x=>x.checked=true);
  updateCount();
}
document.querySelectorAll('.gp-type-tab').forEach(btn=>{
  btn.addEventListener('click',()=>{
    document.querySelectorAll('.gp-type-tab').forEach(x=>x.classList.remove('active'));
    document.querySelectorAll('.gp-type-panel').forEach(x=>x.classList.remove('active'));
    btn.classList.add('active');
    document.querySelector(`.gp-type-panel[data-panel="${btn.dataset.type}"]`).classList.add('active');
  });
});
document.getElementById('catSearch').addEventListener('input',e=>{
  const q=e.target.value.toLowerCase().trim();
  document.querySelectorAll('.gp-source-group').forEach(group=>{
    let visible=0;
    group.querySelectorAll('.gp-cat-item').forEach(el=>{
      const show=!q||el.dataset.name.includes(q);
      el.style.display=show?'flex':'none';
      if(show)visible++;
    });
    group.style.display=visible?'block':'none';
  });
});
checks().forEach(x=>x.addEventListener('change',updateCount));
updateCount();
</script>
<?php gp_admin_footer(); ?>
