package com.ativacao.app;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.zip.GZIPInputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class ApiClient {
    static final ExecutorService IO = Executors.newFixedThreadPool(6);
    private static final Map<String,CatalogPage> CATALOG_CACHE = new HashMap<>();

    interface Callback<T> { void ok(T value); void error(String message); }

    static class Item {
        long id;
        String name = "";
        String logo = "";
        String backdrop = "";
        String group = "";
        String synopsis = "";
        String type = "";
        String format = "auto";
        String seriesTitle = "";
        int year = 0;
        int episodeCount = 0;
        int seasonCount = 0;
        int seasonNumber = 0;
        int episodeNumber = 0;
        int tmdbId = 0;
    }

    static class HomeData {
        String name = "Dubai Play";
        int liveCount;
        int movieCount;
        int seriesCount;
        Item hero;
        final List<Item> live = new ArrayList<>();
        final List<Item> movies = new ArrayList<>();
        final List<Item> series = new ArrayList<>();
    }

    static class CatalogPage {
        int page = 1;
        int pages = 1;
        int total = 0;
        final List<Item> items = new ArrayList<>();
        final List<String> categories = new ArrayList<>();
    }

    static class SeriesData {
        String title = "";
        String logo = "";
        String backdrop = "";
        String synopsis = "";
        String group = "";
        int year = 0;
        final List<Season> seasons = new ArrayList<>();
    }

    static class Season {
        int number;
        final List<Item> episodes = new ArrayList<>();
    }

    static class EpgInfo {
        String nowTitle = "";
        String nowStart = "";
        String nowStop = "";
        String nextTitle = "";
        String nextStart = "";
    }

    static class Section {
        String title = "";
        String subtitle = "";
        String type = "live";
        String category = "";
        String smart = "";
        String action = "catalog";
        int count = 0;
    }

    static class FootballMatch {
        String league = "";
        String home = "";
        String away = "";
        String homeLogo = "";
        String awayLogo = "";
        String status = "";
        String clock = "";
        String score = "";
        String date = "";
        String channel = "";
        String leagueLogo = "";
    }


    static class LoginResult {
        String username = "";
        String expiresAt = "";
        String plan = "";
        int maxConnections = 1;
    }

    static class StreamProbe {
        String format = "auto";
        String contentType = "";
        int httpCode = 0;
        String userAgent = "";
    }

    static class ResolvedStream {
        String url = "";
        String contentType = "";
        int httpCode = 0;
    }



    private static String catalogCacheKey(String type,int page,String search,String category,String smart){
        return clean(type,"")+"|"+Math.max(1,page)+"|"+clean(search,"")+"|"+clean(category,"")+"|"+clean(smart,"");
    }

    static synchronized CatalogPage cachedCatalog(String type,int page,String search,String category,String smart){
        CatalogPage src=CATALOG_CACHE.get(catalogCacheKey(type,page,search,category,smart));
        return copyCatalogPage(src);
    }

    private static synchronized void cacheCatalog(String type,int page,String search,String category,String smart,CatalogPage src){
        if(src!=null) CATALOG_CACHE.put(catalogCacheKey(type,page,search,category,smart),copyCatalogPage(src));
    }

    private static CatalogPage copyCatalogPage(CatalogPage src){
        if(src==null)return null;
        CatalogPage out=new CatalogPage();out.page=src.page;out.pages=src.pages;out.total=src.total;
        out.items.addAll(src.items);out.categories.addAll(src.categories);return out;
    }

    static void preloadCatalogs(){
        Callback<CatalogPage> noop=new Callback<CatalogPage>(){public void ok(CatalogPage p){} public void error(String m){}};
        catalog("live",1,72,"","","",noop);
        catalog("movie",1,48,"","","",noop);
        catalog("series",1,36,"","","",noop);
        catalog("movie",1,36,"","","kids",noop);
        catalog("series",1,36,"","","kids",noop);
        catalog("movie",1,36,"","","anime",noop);
        catalog("series",1,36,"","","anime",noop);
    }

    static void login(String username, String password, String device, Callback<LoginResult> cb) {
        IO.execute(() -> {
            try {
                String body = "username=" + URLEncoder.encode(username, "UTF-8")
                        + "&password=" + URLEncoder.encode(password, "UTF-8")
                        + "&device=" + URLEncoder.encode(device == null ? "" : device, "UTF-8");
                JSONObject root = new JSONObject(post(Config.API_BASE_URL + "login.php", body));
                if (!root.optBoolean("ok", false)) throw new Exception(clean(root.optString("message", "Acesso negado"), "Acesso negado"));
                LoginResult r = new LoginResult();
                r.username = clean(root.optString("username", username), username);
                r.expiresAt = clean(root.optString("expires_at", ""), "");
                r.plan = clean(root.optString("plan", ""), "");
                r.maxConnections = root.optInt("max_connections", 1);
                cb.ok(r);
            } catch (Exception e) { cb.error(message(e)); }
        });
    }

    static void status(Callback<String> cb) {
        IO.execute(() -> {
            try {
                JSONObject o = new JSONObject(request(Config.API_BASE_URL + "status.php", false));
                cb.ok(o.optString("name", "Dubai Play"));
            } catch (Exception e) { cb.error(message(e)); }
        });
    }

    static void home(Callback<HomeData> cb) {
        IO.execute(() -> {
            try {
                JSONObject root = new JSONObject(request(Config.API_BASE_URL + "home.php", true));
                HomeData h = new HomeData();
                h.name = root.optString("name", "Dubai Play");
                JSONObject c = root.optJSONObject("counts");
                if (c != null) {
                    h.liveCount = c.optInt("live", 0);
                    h.movieCount = c.optInt("movie", 0);
                    h.seriesCount = c.optInt("series", 0);
                }
                h.hero = parseItem(root.optJSONObject("hero"));
                JSONObject featured = root.optJSONObject("featured");
                if (featured != null) {
                    parseArray(featured.optJSONArray("live"), h.live, "live");
                    parseArray(featured.optJSONArray("movie"), h.movies, "movie");
                    parseArray(featured.optJSONArray("series"), h.series, "series");
                }
                if (h.hero != null && (h.hero.type == null || h.hero.type.isEmpty())) {
                    ApiClient.Item match = findSame(h.hero, h.movies);
                    if (match == null) match = findSame(h.hero, h.series);
                    if (match != null) {
                        h.hero.type = match.type;
                        if (h.hero.seriesTitle == null || h.hero.seriesTitle.isEmpty()) h.hero.seriesTitle = match.seriesTitle;
                        if (h.hero.synopsis == null || h.hero.synopsis.isEmpty()) h.hero.synopsis = match.synopsis;
                        if (h.hero.backdrop == null || h.hero.backdrop.isEmpty()) h.hero.backdrop = match.backdrop;
                        if (h.hero.logo == null || h.hero.logo.isEmpty()) h.hero.logo = match.logo;
                        if (h.hero.year <= 0) h.hero.year = match.year;
                        if (h.hero.tmdbId <= 0) h.hero.tmdbId = match.tmdbId;
                    }
                }
                cb.ok(h);
            } catch (Exception e) { cb.error(message(e)); }
        });
    }

    static void catalog(String type, int page, int limit, String search, Callback<CatalogPage> cb) {
        catalog(type, page, limit, search, "", "", cb);
    }

    static void catalog(String type, int page, int limit, String search, String category, String smart, Callback<CatalogPage> cb) {
        IO.execute(() -> {
            try {
                StringBuilder url = new StringBuilder(Config.API_BASE_URL)
                        .append("catalog.php?type=").append(URLEncoder.encode(type, "UTF-8"))
                        .append("&page=").append(Math.max(1, page))
                        .append("&limit=").append(Math.max(12, Math.min(72, limit)))
                        .append("&no_categories=1");
                if (search != null && !search.trim().isEmpty()) url.append("&search=").append(URLEncoder.encode(search.trim(), "UTF-8"));
                if (category != null && !category.trim().isEmpty()) url.append("&category=").append(URLEncoder.encode(category.trim(), "UTF-8"));
                if (smart != null && !smart.trim().isEmpty()) url.append("&smart=").append(URLEncoder.encode(smart.trim(), "UTF-8"));
                JSONObject root = new JSONObject(request(url.toString(), true));
                CatalogPage out = new CatalogPage();
                out.page = root.optInt("page", 1);
                out.pages = root.optInt("pages", 1);
                out.total = root.optInt("total", 0);
                parseArray(root.optJSONArray("items"), out.items, root.optString("type", ""));
                JSONArray cats = root.optJSONArray("categories");
                if (cats != null) for (int i=0;i<cats.length();i++) out.categories.add(cats.optString(i, ""));
                cacheCatalog(type,page,search,category,smart,out);
                cb.ok(out);
            } catch (Exception e) { cb.error(message(e)); }
        });
    }

    static void categories(String type, Callback<List<String>> cb) {
        IO.execute(() -> {
            try {
                String url = Config.API_BASE_URL + "categories.php?type=" + URLEncoder.encode(type, "UTF-8");
                JSONObject root = new JSONObject(request(url, true));
                JSONArray a = root.optJSONArray("categories");
                List<String> out = new ArrayList<>();
                if (a != null) for (int i=0;i<a.length();i++) {
                    String v = clean(a.optString(i, ""), "");
                    if (!v.isEmpty()) out.add(v);
                }
                cb.ok(out);
            } catch (Exception e) { cb.error(message(e)); }
        });
    }

    static void sections(Callback<List<Section>> cb) {
        IO.execute(() -> {
            try {
                JSONObject root = new JSONObject(request(Config.API_BASE_URL + "sections.php", true));
                JSONArray a = root.optJSONArray("sections");
                List<Section> out = new ArrayList<>();
                if (a != null) for (int i=0;i<a.length();i++) {
                    JSONObject o = a.optJSONObject(i); if (o == null) continue;
                    Section s = new Section();
                    s.title = clean(o.optString("title", ""), "Categoria");
                    s.subtitle = clean(o.optString("subtitle", ""), "");
                    s.type = clean(o.optString("type", "live"), "live");
                    s.category = clean(o.optString("category", ""), "");
                    s.smart = clean(o.optString("smart", ""), "");
                    s.action = clean(o.optString("action", "catalog"), "catalog");
                    s.count = o.optInt("count", 0);
                    out.add(s);
                }
                cb.ok(out);
            } catch (Exception e) { cb.error(message(e)); }
        });
    }

    static void football(Callback<List<FootballMatch>> cb) {
        IO.execute(() -> {
            try {
                JSONObject root = new JSONObject(request(Config.API_BASE_URL + "football.php", true));
                JSONArray a = root.optJSONArray("matches");
                List<FootballMatch> out = new ArrayList<>();
                if (a != null) for (int i=0;i<a.length();i++) {
                    JSONObject o = a.optJSONObject(i); if (o == null) continue;
                    FootballMatch m = new FootballMatch();
                    m.league = clean(o.optString("league", ""), "Futebol");
                    m.home = clean(o.optString("home", ""), "Casa");
                    m.away = clean(o.optString("away", ""), "Fora");
                    m.homeLogo = clean(o.optString("home_logo", ""), "");
                    m.awayLogo = clean(o.optString("away_logo", ""), "");
                    m.status = clean(o.optString("status", ""), "Agendado");
                    m.clock = clean(o.optString("clock", ""), "");
                    m.score = clean(o.optString("score", ""), "");
                    m.date = clean(o.optString("date", ""), "");
                    out.add(m);
                }
                cb.ok(out);
            } catch (Exception e) { cb.error(message(e)); }
        });
    }

    static void series(String title, Callback<SeriesData> cb) {
        IO.execute(() -> {
            try {
                String url = Config.API_BASE_URL + "series.php?title=" + URLEncoder.encode(title, "UTF-8");
                JSONObject root = new JSONObject(request(url, true));
                SeriesData out = new SeriesData();
                out.title = clean(root.optString("title", title), title);
                out.logo = clean(root.optString("logo", ""), "");
                out.backdrop = clean(root.optString("backdrop", ""), "");
                out.synopsis = clean(root.optString("synopsis", ""), "");
                out.group = clean(root.optString("group_title", ""), "");
                out.year = root.optInt("release_year", 0);
                JSONArray seasons = root.optJSONArray("seasons");
                if (seasons != null) {
                    for (int i=0;i<seasons.length();i++) {
                        JSONObject s = seasons.optJSONObject(i); if (s == null) continue;
                        Season season = new Season();
                        season.number = s.optInt("season", 0);
                        parseArray(s.optJSONArray("episodes"), season.episodes, "series");
                        out.seasons.add(season);
                    }
                }
                cb.ok(out);
            } catch (Exception e) { cb.error(message(e)); }
        });
    }

    static void details(long id, Callback<Item> cb) {
        IO.execute(() -> {
            try {
                JSONObject root = new JSONObject(request(Config.API_BASE_URL + "detail.php?id=" + id, true));
                JSONObject obj = root.optJSONObject("item");
                Item item = parseItem(obj != null ? obj : root);
                if (item == null || item.id <= 0) throw new Exception("Detalhes indisponíveis");
                cb.ok(item);
            } catch (Exception e) { cb.error(message(e)); }
        });
    }

    static void epg(long streamId, Callback<EpgInfo> cb) {
        IO.execute(() -> {
            try {
                JSONObject root = new JSONObject(request(Config.API_BASE_URL + "epg.php?stream_id=" + streamId + "&limit=12", true));
                EpgInfo info = new EpgInfo();
                JSONObject now = root.optJSONObject("now"); JSONObject next = root.optJSONObject("next");
                if (now != null) { info.nowTitle = now.optString("title", ""); info.nowStart = now.optString("start_time", ""); info.nowStop = now.optString("stop_time", ""); }
                if (next != null) { info.nextTitle = next.optString("title", ""); info.nextStart = next.optString("start_time", ""); }
                cb.ok(info);
            } catch (Exception e) { cb.error(message(e)); }
        });
    }

    static void probeStream(long streamId, Callback<StreamProbe> cb) {
        IO.execute(() -> {
            try {
                JSONObject root = new JSONObject(request(Config.API_BASE_URL + "stream_probe.php?id=" + streamId, true));
                StreamProbe p = new StreamProbe();
                p.format = clean(root.optString("format", "auto"), "auto");
                p.contentType = clean(root.optString("content_type", ""), "");
                p.httpCode = root.optInt("http_code", 0);
                p.userAgent = clean(root.optString("user_agent", ""), "");
                cb.ok(p);
            } catch (Exception e) { cb.error(message(e)); }
        });
    }

    static void resolveStream(long id, Callback<ResolvedStream> cb) {
        IO.execute(() -> {
            HttpURLConnection con = null;
            try {
                String current = streamUrl(id);
                String contentType = "";
                int code = 0;
                for (int hop=0; hop<6; hop++) {
                    URL u = new URL(current);
                    con = (HttpURLConnection) u.openConnection();
                    con.setInstanceFollowRedirects(false);
                    con.setConnectTimeout(8000); con.setReadTimeout(10000);
                    con.setRequestMethod("GET");
                    con.setRequestProperty("User-Agent", "DubaiPlayTV/2.2 Android");
                    con.setRequestProperty("Accept", "*/*");
                    con.setRequestProperty("Accept-Encoding", "identity");
                    con.setRequestProperty("Range", "bytes=0-1");
                    code = con.getResponseCode();
                    contentType = clean(con.getContentType(), "");
                    if (code>=300 && code<400) {
                        String loc = con.getHeaderField("Location");
                        con.disconnect(); con=null;
                        if (loc==null || loc.trim().isEmpty()) break;
                        current = new URL(u, loc).toString();
                        continue;
                    }
                    if (con!=null) { con.disconnect(); con=null; }
                    break;
                }
                ResolvedStream r = new ResolvedStream(); r.url=current; r.contentType=contentType; r.httpCode=code; cb.ok(r);
            } catch (Exception e) { if(con!=null)con.disconnect(); cb.error(message(e)); }
        });
    }

    static String streamUrl(long id) {
        try { return Config.API_BASE_URL + "stream.php?id=" + id + "&app_token=" + URLEncoder.encode(Config.APP_TOKEN, "UTF-8"); }
        catch (Exception e) { return ""; }
    }

    private static Item parseItem(JSONObject o) {
        if (o == null) return null;
        Item item = new Item();
        item.id = o.optLong("id"); item.name = clean(o.optString("name", ""), "Sem nome");
        item.logo = clean(o.optString("logo", ""), ""); item.backdrop = clean(o.optString("backdrop", o.optString("backdrop_url", "")), "");
        item.group = clean(o.optString("group_title", ""), ""); item.synopsis = clean(o.optString("synopsis", ""), "");
        item.type = clean(o.optString("type", ""), ""); item.format = clean(o.optString("stream_format", "auto"), "auto");
        item.seriesTitle = clean(o.optString("series_title", ""), ""); item.year = o.optInt("release_year", 0);
        item.episodeCount = o.optInt("episode_count", 0); item.seasonCount = o.optInt("season_count", 0);
        item.seasonNumber = o.optInt("season_number", 0); item.episodeNumber = o.optInt("episode_number", 0);
        item.tmdbId = o.optInt("tmdb_id", 0);
        return item;
    }

    private static Item findSame(Item hero, List<Item> list) {
        if (hero == null || list == null) return null;
        for (Item i : list) {
            if (i == null) continue;
            if (hero.id > 0 && i.id == hero.id) return i;
            if (hero.name != null && i.name != null && hero.name.equalsIgnoreCase(i.name)) return i;
        }
        return null;
    }

    private static void parseArray(JSONArray a, List<Item> out, String type) {
        if (a == null) return;
        for (int i=0;i<a.length();i++) { Item item = parseItem(a.optJSONObject(i)); if (item != null) { if (item.type == null || item.type.isEmpty()) item.type = type; out.add(item); } }
    }


    private static String post(String url, String body) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
        con.setConnectTimeout(8000); con.setReadTimeout(20000); con.setInstanceFollowRedirects(true);
        con.setRequestMethod("POST"); con.setDoOutput(true);
        con.setRequestProperty("Accept", "application/json");
        con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
        con.setRequestProperty("X-App-Token", Config.APP_TOKEN);
        con.setRequestProperty("User-Agent", "DubaiPlayTV/2.2 Android");
        byte[] data = body.getBytes("UTF-8");
        con.setFixedLengthStreamingMode(data.length);
        java.io.OutputStream out = con.getOutputStream(); out.write(data); out.flush(); out.close();
        int code = con.getResponseCode(); InputStream in = code >= 200 && code < 300 ? con.getInputStream() : con.getErrorStream();
        String bodyText = readBody(con, in);
        con.disconnect();
        if (code == 401) throw new Exception("Usuário ou senha inválidos");
        if (code == 403) throw new Exception(!bodyText.isEmpty() ? new JSONObject(bodyText).optString("message", "Acesso bloqueado") : "Acesso bloqueado");
        if (code < 200 || code >= 300) throw new Exception("Servidor respondeu HTTP " + code);
        return bodyText;
    }

    private static String request(String url, boolean authenticated) throws Exception {
        Exception last = null;
        for (int attempt=0; attempt<2; attempt++) {
            HttpURLConnection con = null;
            try {
                con = (HttpURLConnection) new URL(url).openConnection();
                con.setConnectTimeout(attempt==0?6500:9500); con.setReadTimeout(attempt==0?14000:22000); con.setInstanceFollowRedirects(true);
                con.setUseCaches(true);
                con.setRequestProperty("Accept", "application/json"); con.setRequestProperty("Accept-Encoding", "identity"); con.setRequestProperty("Connection", "keep-alive");
                con.setRequestProperty("User-Agent", "DubaiPlayTV/2.2 Android"); if (authenticated) con.setRequestProperty("X-App-Token", Config.APP_TOKEN);
                int code = con.getResponseCode(); InputStream in = code >= 200 && code < 300 ? con.getInputStream() : con.getErrorStream();
                String bodyText = readBody(con, in);
                if (code == 401) throw new Exception("Aplicativo não autorizado no painel");
                if (code >= 500 && attempt == 0) { try { Thread.sleep(350); } catch (InterruptedException ignored) {} continue; }
                if (code < 200 || code >= 300) throw new Exception("Servidor respondeu HTTP " + code);
                if (bodyText == null || bodyText.trim().isEmpty()) throw new Exception("Servidor respondeu vazio");
                return bodyText;
            } catch (java.net.SocketTimeoutException e) {
                last = new Exception(attempt==0 ? "Servidor demorou para responder" : "Timeout do servidor");
                if (attempt==0) { try { Thread.sleep(300); } catch (InterruptedException ignored) {} continue; }
            } catch (Exception e) { last=e; if(attempt==0 && (e instanceof java.io.IOException)){ try { Thread.sleep(300); } catch (InterruptedException ignored) {} continue; } break; }
            finally { if(con!=null) con.disconnect(); }
        }
        throw last == null ? new Exception("Falha de conexão") : last;
    }

    private static String readBody(HttpURLConnection con, InputStream in) throws Exception {
        if (in == null) return "";
        String enc = con.getHeaderField("Content-Encoding");
        InputStream decoded = in;
        if (enc != null && enc.toLowerCase(java.util.Locale.US).contains("gzip")) decoded = new GZIPInputStream(in);
        BufferedReader br = new BufferedReader(new InputStreamReader(decoded, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        String text = sb.toString().trim();
        // Alguns proxies devolvem BOM antes do JSON.
        if (text.startsWith("\uFEFF")) text = text.substring(1);
        return text;
    }

    private static String clean(String value, String fallback) { if (value == null) return fallback; String s = value.trim(); return s.isEmpty() || "null".equalsIgnoreCase(s) ? fallback : s; }
    private static String message(Exception e) { String m = e.getMessage(); return m == null || m.trim().isEmpty() ? "Falha de conexão" : m; }
}
