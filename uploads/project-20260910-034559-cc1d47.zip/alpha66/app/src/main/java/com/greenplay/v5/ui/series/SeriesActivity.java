package com.greenplay.v5.ui.series;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.greenplay.v5.core.catalog.CatalogCoverWarmer;
import com.greenplay.v5.core.catalog.CatalogMemory;
import com.greenplay.v5.core.config.AppControlStore;
import com.greenplay.v5.core.config.NavConfigUi;
import com.greenplay.v5.core.config.AppNoticeUi;
import com.greenplay.v5.core.config.AppControlSync;
import com.greenplay.v5.core.config.BrandingStore;
import com.greenplay.v5.core.config.BrandingUi;
import com.greenplay.v5.core.session.SessionStore;
import com.greenplay.v5.data.model.series.SeriesCategory;
import com.greenplay.v5.data.model.series.SeriesItem;
import com.greenplay.v5.data.repository.SeriesRepository;
import com.greenplay.v5.databinding.ActivitySeriesBinding;
import com.greenplay.v5.ui.movies.MovieActivity;
import com.greenplay.v5.ui.settings.SettingsActivity;
import com.greenplay.v5.ui.tv.TvActivity;
import com.squareup.picasso.Target;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class SeriesActivity extends AppCompatActivity {
    private static final int PAGE_SIZE = 180;
    private static final int PREFETCH = 36;

    private ActivitySeriesBinding b;
    private SessionStore session;
    private BrandingStore branding;
    private AppControlStore control;
    private Target backgroundTarget;
    private SeriesRepository repo;
    private SeriesCacheStore cache;
    private SeriesCategoryAdapter categories;
    private SeriesAdapter adapter;
    private GridLayoutManager grid;

    private volatile List<SeriesItem> all = Collections.emptyList();
    private final List<SeriesItem> filtered = new ArrayList<>();
    private String categoryId = "";
    private String query = "";
    private String specialMode = "";
    private final Set<String> allowedCategoryIds = new HashSet<>();
    private final Map<String,String> categoryNamesById = new HashMap<>();
    private int rendered = 0;
    private int generation = 0;
    private int requestGeneration = 0;
    private boolean loading = false;
    private boolean networkCatalogComplete = false;
    private boolean usingNetworkPreview = false;

    private final ExecutorService filter = Executors.newSingleThreadExecutor();
    private final ExecutorService cacheExecutor = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Runnable delayedSearch = this::rebuild;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        b = ActivitySeriesBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        com.greenplay.v5.core.ui.UniversalUi.apply(this, b.getRoot());
        session = new SessionStore(this);
        if (!session.isLogged() || session.host().trim().isEmpty()) { finish(); return; }

        branding = new BrandingStore(this);
        control = new AppControlStore(this);
        specialMode = normalizeSpecialMode(getIntent().getStringExtra(com.greenplay.v5.core.ui.SpecialSections.EXTRA_MODE));
        repo = new SeriesRepository(session.host(), session.user(), session.pass(), com.greenplay.v5.core.ui.SpecialSections.HOT.equals(specialMode));
        cache = new SeriesCacheStore(this, session.host(), session.user());

        applyBranding();
        setup();
        bindNav();
        configureSpecialModeUi();
        AppNoticeUi.show(this, control);
        AppControlSync.refresh(this, ok -> runOnUiThread(() -> {
            if (ok && !isFinishing()) {
                branding = new BrandingStore(this);
                control = new AppControlStore(this);
                applyBranding();
                applySectionVisibility();
                AppNoticeUi.show(this, control);
            }
        }));

        boolean preloaded = showPreloadedSeries();
        // Categorias já foram preparadas no bootstrap da sessão.
        List<SeriesCategory> preparedCategories = CatalogMemory.seriesCategories();
        if (!preparedCategories.isEmpty()) applyCategoryScope(preparedCategories);
        // V5.0.159: SÉRIES não recarrega rede ao entrar na tela. Só há fallback
        // quando o bootstrap/cache ainda não forneceu nenhum catálogo utilizável.
        if (!preloaded) {
            loadCachedCategoriesOnly();
            loadCachedSeries();
            loadCategories();
            loadSeries(true);
        }
    }

    private void applyBranding() {
        BrandingUi.applyHeaderBrand(b.brandNameSeries, b.brandLogoSeries, branding);
        backgroundTarget = BrandingUi.applyBackground(b.getRoot(), branding);
        if (adapter != null) {
            String fallback = branding.seriesCover();
            if (fallback == null || fallback.trim().isEmpty()) fallback = branding.fallback();
            adapter.setFallback(branding.absolute(fallback));
        }
    }

    private void setup() {
        categories = new SeriesCategoryAdapter(c -> {
            categoryId = c.id == null ? "" : c.id;
            categories.select(categoryId);
            rebuild();
        });
        b.seriesCategories.setLayoutManager(new LinearLayoutManager(this));
        b.seriesCategories.setAdapter(categories);
        b.seriesCategories.setItemAnimator(null);

        adapter = new SeriesAdapter(this::openDetail);
        String seriesFallback = branding.seriesCover();
        if (seriesFallback == null || seriesFallback.trim().isEmpty()) seriesFallback = branding.fallback();
        adapter.setFallback(branding.absolute(seriesFallback));

        grid = new GridLayoutManager(this, com.greenplay.v5.core.ui.UniversalUi.catalogSpanCount(this));
        b.seriesGrid.setLayoutManager(grid);
        b.seriesGrid.setAdapter(adapter);
        b.seriesGrid.setItemAnimator(null);
        b.seriesGrid.setHasFixedSize(true);
        b.seriesGrid.setItemViewCacheSize(18);
        b.seriesGrid.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override public void onScrolled(RecyclerView rv, int dx, int dy) {
                if (dy > 0 && rendered < filtered.size() && grid.findLastVisibleItemPosition() >= adapter.getItemCount() - PREFETCH) append();
            }
        });

        b.seriesSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int st, int before, int count) {
                query = s == null ? "" : s.toString().trim();
                main.removeCallbacks(delayedSearch);
                main.postDelayed(delayedSearch, 180L);
            }
            @Override public void afterTextChanged(Editable e) {}
        });
    }

    private void bindNav() {
        b.navTv.setOnClickListener(v -> com.greenplay.v5.core.ui.TopNavRouter.open(this, TvActivity.class));
        b.navMovies.setOnClickListener(v -> com.greenplay.v5.core.ui.TopNavRouter.open(this, MovieActivity.class));
        b.navSeries.setOnClickListener(v -> {
            if (specialMode.isEmpty()) b.seriesSearch.requestFocus();
            else { Intent normal = new Intent(this, SeriesActivity.class); normal.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION); startActivity(normal); overridePendingTransition(0,0); }
        });
        b.navFootball.setOnClickListener(v -> com.greenplay.v5.core.ui.TopNavRouter.open(this, com.greenplay.v5.ui.games.GamesActivity.class));
        b.navKids.setOnClickListener(v -> com.greenplay.v5.core.ui.SpecialSections.open(this, com.greenplay.v5.core.ui.SpecialSections.KIDS));
        b.navAnime.setOnClickListener(v -> com.greenplay.v5.core.ui.SpecialSections.open(this, com.greenplay.v5.core.ui.SpecialSections.ANIME));
        b.navHot.setOnClickListener(v -> com.greenplay.v5.core.ui.SpecialSections.open(this, com.greenplay.v5.core.ui.SpecialSections.HOT));
        b.seriesSettings.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        applySectionVisibility();
    }

    private void applySectionVisibility() {
        NavConfigUi.apply(control,
                NavConfigUi.e("tv", b.navTv, 10), NavConfigUi.e("football", b.navFootball, 20),
                NavConfigUi.e("movies", b.navMovies, 30), NavConfigUi.e("series", b.navSeries, 40),
                NavConfigUi.e("kids", b.navKids, 50), NavConfigUi.e("anime", b.navAnime, 60),
                NavConfigUi.e("hot", b.navHot, 70));
    }

    private boolean showPreloadedSeries() {
        if (com.greenplay.v5.core.ui.SpecialSections.HOT.equals(specialMode)) return false;
        List<SeriesItem> prepared = CatalogMemory.series();
        if (prepared.isEmpty()) return false;
        all = prepared;
        b.seriesLoading.setVisibility(View.GONE);
        b.seriesError.setText("");
        rebuild();
        warmSeriesArtwork(prepared, true);
        return true;
    }


    private void loadCachedCategoriesOnly() {
        cacheAsync(() -> {
            final List<SeriesCategory> cachedCategories = cache.categories();
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed() || cachedCategories.isEmpty()) return;
                CatalogMemory.setSeriesCategories(cachedCategories);
                applyCategoryScope(cachedCategories);
            });
        });
    }

    private void loadCachedSeries() {
        if (com.greenplay.v5.core.ui.SpecialSections.HOT.equals(specialMode)) return;
        cacheAsync(() -> {
            final List<SeriesCategory> cachedCategories = cache.categories();
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed() || networkCatalogComplete) return;
                if (!cachedCategories.isEmpty()) { CatalogMemory.setSeriesCategories(cachedCategories); applyCategoryScope(cachedCategories); }
            });

            // Reading/parsing the cached catalog is much heavier than reading
            // its small category list. Publish categories immediately instead
            // of making the sidebar wait for the entire series cache.
            final List<SeriesItem> cachedSeries = cache.series();
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed() || networkCatalogComplete) return;
                if (!cachedSeries.isEmpty() && (all.isEmpty() || usingNetworkPreview || cachedSeries.size() > all.size())) {
                    usingNetworkPreview = false;
                    all = cachedSeries;
                    if (specialMode.isEmpty()) CatalogMemory.setSeries(cachedSeries);
                    b.seriesLoading.setVisibility(View.GONE);
                    b.seriesError.setText("");
                    rebuild();
                    warmSeriesArtwork(cachedSeries, false);
                }
            });
        });
    }

    private void loadCategories() {
        repo.categories(new SeriesRepository.CategoriesResult() {
            @Override public void success(List<SeriesCategory> rows) {
                runOnUiThread(() -> { CatalogMemory.setSeriesCategories(rows); applyCategoryScope(rows); });
                cacheAsync(() -> cache.saveCategories(rows));
            }
            @Override public void error(String m) { }
        });
    }

    private void loadSeries(boolean showSpinner) {
        final int request = ++requestGeneration;
        loading = true;
        networkCatalogComplete = false;
        if (showSpinner && all.isEmpty()) {
            b.seriesLoading.setVisibility(View.GONE);
            main.postDelayed(() -> {
                if (loading && all.isEmpty() && !isFinishing() && !isDestroyed()) b.seriesLoading.setVisibility(View.VISIBLE);
            }, 350L);
        }
        b.seriesError.setText("");

        repo.seriesProgressive("", 24, 240, new SeriesRepository.ProgressiveSeriesResult() {
            @Override public void partial(List<SeriesItem> rows) {
                if (request != requestGeneration || rows == null || rows.isEmpty()) return;
                if (all.isEmpty() || usingNetworkPreview) {
                    usingNetworkPreview = true;
                    all = rows;
                    if (specialMode.isEmpty()) CatalogMemory.setSeries(rows);
                    b.seriesLoading.setVisibility(View.GONE);
                    rebuild();
                    warmSeriesArtwork(rows, true);
                }
            }

            @Override public void success(List<SeriesItem> rows) {
                if (request != requestGeneration) return;
                loading = false;
                networkCatalogComplete = true;
                usingNetworkPreview = false;
                b.seriesLoading.setVisibility(View.GONE);
                all = rows == null ? Collections.emptyList() : rows;
                if (specialMode.isEmpty()) CatalogMemory.setSeries(all);
                rebuild();
                final List<SeriesItem> saveRows = all;
                if (specialMode.isEmpty()) cacheAsync(() -> cache.saveSeries(saveRows));
                warmSeriesArtwork(all, false);
            }

            @Override public void error(String m) {
                if (request != requestGeneration) return;
                loading = false;
                b.seriesLoading.setVisibility(View.GONE);
                if (all.isEmpty()) b.seriesError.setText(m);
            }
        });
    }

    private void rebuild() {
        final int g = ++generation;
        final List<SeriesItem> snap = all;
        final String cat = categoryId;
        final String q = query.toLowerCase(Locale.ROOT);
        final boolean scoped = !specialMode.isEmpty();
        final Set<String> allowedIds = scoped ? new HashSet<>(allowedCategoryIds) : Collections.emptySet();
        final Map<String,String> categoryNames = scoped ? new HashMap<>(categoryNamesById) : Collections.emptyMap();
        // V5.0.134 — the precomputed SpecialCatalogIndex is authoritative.
        // Previously a broad category match (e.g. Família/Disney+) could bypass
        // the item-level KIDS decision and reinsert adult/general series in this
        // internal grid even though the landing catalog had already filtered them.
        final Set<Long> authoritativeSeriesIds;
        if (scoped) {
            com.greenplay.v5.core.catalog.SpecialCatalogIndex.Scope resolved =
                    com.greenplay.v5.core.catalog.SpecialCatalogIndex.cachedScope(specialMode);
            authoritativeSeriesIds = resolved != null && resolved.seriesIds != null
                    ? new HashSet<>(resolved.seriesIds) : Collections.emptySet();
        } else authoritativeSeriesIds = Collections.emptySet();
        filter.execute(() -> {
            ArrayList<SeriesItem> out = new ArrayList<>();
            for (SeriesItem x : snap) {
                if (x == null) continue;
                if (scoped) {
                    if (!authoritativeSeriesIds.isEmpty()) {
                        // Never allow the category name alone to override the resolved
                        // KIDS/ANIME/HOT scope. Accept primary or alternate duplicate id.
                        if (!isSeriesAllowedByScope(x, authoritativeSeriesIds)) continue;
                    } else {
                        // Startup fallback only: if the login index is not ready yet,
                        // keep the old generic behavior so the screen does not go blank.
                        String categoryName = categoryNames.get(x.categoryId == null ? "" : x.categoryId);
                        boolean categoryMatch = matchesAnyCategoryId(x, allowedIds);
                        boolean itemMatch = com.greenplay.v5.core.ui.SpecialSections.matchesSeriesItem(specialMode, categoryName, x);
                        if (!categoryMatch && !itemMatch) continue;
                    }
                }
                if (cat != null && !cat.isEmpty() && !hasCategoryId(x, cat)) continue;
                if (!q.isEmpty() && (x.name == null || !x.name.toLowerCase(Locale.ROOT).contains(q))) continue;
                out.add(x);
            }
            runOnUiThread(() -> {
                if (g != generation || isFinishing() || isDestroyed()) return;
                filtered.clear();
                filtered.addAll(out);
                rendered = Math.min(PAGE_SIZE, filtered.size());
                adapter.submit(rendered == 0 ? Collections.emptyList() : new ArrayList<>(filtered.subList(0, rendered)));
                b.seriesEmpty.setVisibility(filtered.isEmpty() && !loading ? View.VISIBLE : View.GONE);
                if (grid != null) grid.scrollToPosition(0);
            });
        });
    }

    private void append() {
        int end = Math.min(filtered.size(), rendered + PAGE_SIZE);
        if (end <= rendered) return;
        rendered = end;
        adapter.submit(new ArrayList<>(filtered.subList(0, rendered)));
    }

    private void warmSeriesArtwork(List<SeriesItem> rows, boolean priorityOnly) {
        if (rows == null || rows.isEmpty()) return;
        ArrayList<String> urls = new ArrayList<>();
        int max = priorityOnly ? Math.min(48, rows.size()) : Math.min(180, rows.size());
        for (int i = 0; i < max; i++) {
            SeriesItem x = rows.get(i);
            if (x != null && x.cover != null && !x.cover.trim().isEmpty()) urls.add(x.cover);
        }
        if (urls.isEmpty()) return;
        if (priorityOnly) CatalogCoverWarmer.warmPriority(urls, 48, null);
        else CatalogCoverWarmer.enqueue(urls);
    }

    private void cacheAsync(Runnable task) {
        try {
            if (!cacheExecutor.isShutdown()) cacheExecutor.execute(task);
        } catch (RuntimeException ignored) { }
    }

    private void openDetail(SeriesItem x) {
        Intent i = new Intent(this, SeriesDetailActivity.class);
        i.putExtra("id", x.id);
        i.putExtra("name", x.name);
        i.putExtra("cover", x.cover);
        i.putExtra("year", x.year);
        i.putExtra("rating", x.rating);
        if (x.alternateIds != null && !x.alternateIds.isEmpty()) {
            long[] ids = new long[x.alternateIds.size()];
            for (int p = 0; p < ids.length; p++) ids[p] = x.alternateIds.get(p);
            i.putExtra("alternate_ids", ids);
        }
        startActivity(i);
    }

    private void configureSpecialModeUi() {
        b.navSeries.setSelected(specialMode.isEmpty());
        b.navKids.setSelected(com.greenplay.v5.core.ui.SpecialSections.KIDS.equals(specialMode));
        b.navAnime.setSelected(com.greenplay.v5.core.ui.SpecialSections.ANIME.equals(specialMode));
        b.navHot.setSelected(com.greenplay.v5.core.ui.SpecialSections.HOT.equals(specialMode));
        if (specialMode.isEmpty()) {
            b.seriesSectionLabel.setText("SÉRIES");
            b.specialModeChooser.setVisibility(View.GONE);
            return;
        }
        String label = com.greenplay.v5.core.ui.SpecialSections.label(specialMode);
        b.seriesSectionLabel.setText(label);
        b.specialModeChooser.setVisibility(View.VISIBLE);
        b.specialMoviesChoice.setSelected(false);
        b.specialSeriesChoice.setSelected(true);
        b.specialMoviesChoice.setOnClickListener(v -> {
            Intent i = new Intent(this, MovieActivity.class);
            i.putExtra(com.greenplay.v5.core.ui.SpecialSections.EXTRA_MODE, specialMode);
            i.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_NO_ANIMATION);
            startActivity(i);
            overridePendingTransition(0, 0);
        });
        b.specialSeriesChoice.setOnClickListener(v -> {
            // Já estamos em Séries; mantém a seleção e evita recarregar a tela.
            b.specialMoviesChoice.setSelected(false);
            b.specialSeriesChoice.setSelected(true);
        });
    }

    private void applyCategoryScope(List<SeriesCategory> rows) {
        ArrayList<SeriesCategory> visible = new ArrayList<>();
        SeriesCategory allCategory = new SeriesCategory();
        allCategory.id = ""; allCategory.name = "TODOS";
        visible.add(allCategory);

        HashSet<String> nextAllowed = new HashSet<>();
        categoryNamesById.clear();
        if (rows != null) {
            for (SeriesCategory c : rows) {
                if (c != null && c.id != null) categoryNamesById.put(c.id, c.name == null ? "" : c.name);
                if (c == null || c.id == null || c.id.trim().isEmpty()) continue;
                if (!specialMode.isEmpty() && !com.greenplay.v5.core.ui.SpecialSections.matches(specialMode, c.name)) continue;
                visible.add(c);
                if (!specialMode.isEmpty()) nextAllowed.add(c.id);
            }
        }

        if (specialMode.isEmpty()) {
            visible.clear();
            if (rows != null) visible.addAll(rows);
        } else if (nextAllowed.isEmpty() && !allowedCategoryIds.isEmpty()) {
            // Never let a slow/empty refresh erase a scope that was already
            // resolved from the login cache. Keep the last good sidebar/content.
            return;
        } else {
            allowedCategoryIds.clear();
            allowedCategoryIds.addAll(nextAllowed);
        }

        boolean selectedStillAllowed = categoryId.isEmpty();
        for (SeriesCategory c : visible) if (categoryId.equals(c.id)) { selectedStillAllowed = true; break; }
        if (!selectedStillAllowed) categoryId = "";
        categories.submit(visible, categoryId);
        rebuild();
    }

    private static boolean isSeriesAllowedByScope(SeriesItem item, Set<Long> allowed) {
        if (item == null || allowed == null || allowed.isEmpty()) return false;
        if (allowed.contains(item.id)) return true;
        if (item.alternateIds != null) {
            for (Long id : item.alternateIds) if (id != null && allowed.contains(id)) return true;
        }
        return false;
    }

    private static boolean matchesAnyCategoryId(SeriesItem item, Set<String> allowed) {
        if (item == null || allowed == null || allowed.isEmpty()) return false;
        if (hasCategoryId(item, item.categoryId) && allowed.contains(item.categoryId)) return true;
        String allIds = item.allCategoryIds == null ? "" : item.allCategoryIds;
        for (String raw : allIds.split("[|,;]+")) {
            String id = raw == null ? "" : raw.trim();
            if (!id.isEmpty() && allowed.contains(id)) return true;
        }
        return false;
    }

    private static boolean hasCategoryId(SeriesItem item, String wanted) {
        if (item == null || wanted == null || wanted.trim().isEmpty()) return false;
        String target = wanted.trim();
        if (target.equals(item.categoryId == null ? "" : item.categoryId.trim())) return true;
        String allIds = item.allCategoryIds == null ? "" : item.allCategoryIds;
        for (String raw : allIds.split("[|,;]+")) {
            if (target.equals(raw == null ? "" : raw.trim())) return true;
        }
        return false;
    }

    private static String normalizeSpecialMode(String raw) {
        String m = raw == null ? "" : raw.trim().toLowerCase(Locale.ROOT);
        return com.greenplay.v5.core.ui.SpecialSections.valid(m) ? m : "";
    }

    @Override protected void onDestroy() {
        main.removeCallbacksAndMessages(null);
        generation++;
        requestGeneration++;
        filter.shutdownNow();
        cacheExecutor.shutdownNow();
        super.onDestroy();
    }
}
