package com.greenplay.v5.ui.special;

import android.content.Context;
import com.google.gson.Gson;
import com.greenplay.v5.data.model.movie.Movie;
import com.greenplay.v5.data.model.movie.MovieCategory;
import com.greenplay.v5.data.model.series.SeriesCategory;
import com.greenplay.v5.data.model.series.SeriesItem;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Cache separado do HOT para conteúdo adulto nunca vazar no catálogo normal. */
public final class HotCatalogCacheStore {
    public static final long MAX_AGE_MS = 12L * 60L * 60L * 1000L;

    public static final class Snapshot {
        public long savedAt = 0L;
        public List<MovieCategory> movieCategories = new ArrayList<>();
        public List<Movie> movies = new ArrayList<>();
        public List<SeriesCategory> seriesCategories = new ArrayList<>();
        public List<SeriesItem> series = new ArrayList<>();

        public boolean usable() {
            return (movies != null && !movies.isEmpty()) || (series != null && !series.isEmpty());
        }

        public boolean fresh() {
            long age = System.currentTimeMillis() - savedAt;
            return savedAt > 0L && age >= 0L && age < MAX_AGE_MS;
        }
    }

    private final File file;
    private final Gson gson = new Gson();

    public HotCatalogCacheStore(Context context, String host, String user) {
        File dir = new File(context.getFilesDir(), "green_play_hot_cache_v159");
        if (!dir.exists()) dir.mkdirs();
        String key = Integer.toHexString(((host == null ? "" : host.trim()) + "|" + (user == null ? "" : user.trim())).hashCode());
        file = new File(dir, "hot_" + key + ".json");
    }


    /** Remove somente o cache HOT desta conta/servidor. */
    public void clear() {
        try { if (file.isFile()) file.delete(); } catch (Exception ignored) { }
        try {
            File tmp = new File(file.getParentFile(), file.getName() + ".tmp");
            if (tmp.isFile()) tmp.delete();
        } catch (Exception ignored) { }
    }

    public Snapshot read() {
        if (!file.isFile() || file.length() <= 2L) return new Snapshot();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            Snapshot s = gson.fromJson(r, Snapshot.class);
            if (s == null) return new Snapshot();
            if (s.movieCategories == null) s.movieCategories = new ArrayList<>();
            if (s.movies == null) s.movies = new ArrayList<>();
            if (s.seriesCategories == null) s.seriesCategories = new ArrayList<>();
            if (s.series == null) s.series = new ArrayList<>();
            return s;
        } catch (Exception ignored) {
            return new Snapshot();
        }
    }

    public void save(List<MovieCategory> movieCategories, List<Movie> movies,
                     List<SeriesCategory> seriesCategories, List<SeriesItem> series) {
        Snapshot s = new Snapshot();
        s.savedAt = System.currentTimeMillis();
        if (movieCategories != null) s.movieCategories = new ArrayList<>(movieCategories);
        if (movies != null) s.movies = new ArrayList<>(movies);
        if (seriesCategories != null) s.seriesCategories = new ArrayList<>(seriesCategories);
        if (series != null) s.series = new ArrayList<>(series);
        if (!s.usable()) return;

        File tmp = new File(file.getParentFile(), file.getName() + ".tmp");
        try (BufferedWriter w = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(tmp), StandardCharsets.UTF_8))) {
            gson.toJson(s, w);
            w.flush();
            if (file.exists() && !file.delete()) return;
            if (!tmp.renameTo(file)) {
                try (BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8))) {
                    gson.toJson(s, out);
                }
                tmp.delete();
            }
        } catch (Exception ignored) {
            tmp.delete();
        }
    }
}
