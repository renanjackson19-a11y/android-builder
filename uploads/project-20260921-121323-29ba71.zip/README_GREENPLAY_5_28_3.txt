GreenPlay Android Nativo 5.28.3 — versionCode 52803

Correção principal:
- o app NÃO apaga mais capas/metadados TMDB já preparados pelo painel/VPS;
- o snapshot do servidor passa a ser a fonte da verdade para as capas;
- content_enrich fica somente como contingência para itens ainda pendentes;
- schema local alterado para catalog52803, descartando snapshots antigos que tiveram as capas zeradas.

Entrega: projeto Android completo.
