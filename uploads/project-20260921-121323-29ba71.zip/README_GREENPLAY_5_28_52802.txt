GreenPlay Android Nativo 5.28.2 (52802)

Correção TMDB de capas:
- Nenhuma capa de filme/série é aceita diretamente da fonte.
- A tela inicial de sincronização resolve no TMDB os primeiros cards de cada categoria.
- As capas resolvidas são pré-carregadas antes de abrir a Home.
- Se algum card ainda estiver sem capa, o próprio card consulta o TMDB e atualiza a imagem automaticamente.

Projeto completo.
