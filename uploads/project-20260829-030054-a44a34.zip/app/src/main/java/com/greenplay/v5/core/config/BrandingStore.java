package com.greenplay.v5.core.config;

import android.content.Context;
import android.content.SharedPreferences;
import com.greenplay.v5.data.model.AppConfigResponse;

public final class BrandingStore {
    private static final String PREF="green_play_v5_branding";
    private final SharedPreferences p;
    public BrandingStore(Context c){p=c.getSharedPreferences(PREF,Context.MODE_PRIVATE);}
    public void save(AppConfigResponse.Branding b){
        if(b==null)return;
        p.edit()
          .putString("app_name",nz(b.appName)).putString("support",nz(b.supportWhatsapp))
          .putString("accent",nz(b.accentColor)).putString("logo",nz(b.logo))
          .putString("background",nz(b.background)).putString("banner",nz(b.banner))
          .putString("fallback",nz(b.fallbackCover)).putString("account_title",nz(b.accountTitle))
          .putString("about",nz(b.aboutText)).putBoolean("show_parental",b.showParental)
          .putBoolean("show_favorites",b.showFavorites).putBoolean("show_update",b.showUpdate)
          .putBoolean("show_clear_cache",b.showClearCache).putBoolean("show_support",b.showSupport)
          .putBoolean("show_about",b.showAbout).apply();
    }
    public boolean showFavorites(){return p.getBoolean("show_favorites",true);}
    public String support(){return p.getString("support","");}
    public String accountTitle(){return p.getString("account_title","GREEN PLAY • SUA CENTRAL DE ENTRETENIMENTO");}
    public String background(){return p.getString("background","");}
    public String banner(){return p.getString("banner","");}
    public String fallback(){return p.getString("fallback","");}
    private static String nz(String s){return s==null?"":s;}
}
