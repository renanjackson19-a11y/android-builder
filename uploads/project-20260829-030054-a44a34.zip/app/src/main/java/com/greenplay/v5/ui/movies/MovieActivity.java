package com.greenplay.v5.ui.movies;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.greenplay.v5.core.config.BrandingStore;
import com.greenplay.v5.core.session.SessionStore;
import com.greenplay.v5.data.model.movie.Movie;
import com.greenplay.v5.data.model.movie.MovieCategory;
import com.greenplay.v5.data.repository.MovieRepository;
import com.greenplay.v5.databinding.ActivityMoviesBinding;
import java.util.ArrayList;
import java.util.List;

public final class MovieActivity extends AppCompatActivity {
    private static final long AUTO_REFRESH_MS = 60_000L;

    private ActivityMoviesBinding b;
    private SessionStore session;
    private MovieRepository repo;
    private MovieFavoritesStore favorites;
    private MovieCategoryAdapter categoryAdapter;
    private MovieAdapter movieAdapter;
    private final List<MovieCategory> rawCategories = new ArrayList<>();
    private final List<Movie> currentMovies = new ArrayList<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private String categoryId = "";
    private String categoryName = "TODOS";
    private boolean favoriteMode = false;
    private boolean loading = false;
    private long lastRefreshAt = 0L;
    private int movieRequestGeneration = 0;

    private final Runnable autoRefresh = new Runnable() {
        @Override public void run() {
            refresh(false);
            handler.postDelayed(this, AUTO_REFRESH_MS);
        }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        b = ActivityMoviesBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        session = new SessionStore(this);
        if (!session.isLogged() || session.host().trim().isEmpty()) { finish(); return; }
        repo = new MovieRepository(session.host(), session.user(), session.pass());
        favorites = new MovieFavoritesStore(this, session.host(), session.user());
        setupLists();
        setupSearch();
        bindTopNav();
        b.navMovies.setSelected(true);
        if (!new BrandingStore(this).showFavorites()) b.movieFavorites.setVisibility(View.GONE);
        refresh(true);
        handler.postDelayed(autoRefresh, AUTO_REFRESH_MS);
    }

    private void setupLists() {
        categoryAdapter = new MovieCategoryAdapter(category -> {
            categoryId = category.id;
            categoryName = category.name;
            favoriteMode = false;
            b.movieFavorites.setSelected(false);
            b.movieFavorites.setText("☆ FAVORITOS");
            categoryAdapter.select(categoryId);
            currentMovies.clear();
            movieAdapter.submit(currentMovies);
            loadMovies(categoryId, true);
        });
        b.movieCategories.setLayoutManager(new LinearLayoutManager(this));
        b.movieCategories.setAdapter(categoryAdapter);

        movieAdapter = new MovieAdapter(new MovieAdapter.Listener() {
            @Override public void onOpen(Movie movie) { openDetails(movie); }
            @Override public void onFavorite(Movie movie) {
                favorites.toggle(movie.id);
                movieAdapter.refreshFavorite(movie.id);
            }
            @Override public boolean isFavorite(Movie movie) { return favorites.isFavorite(movie.id); }
        });
        b.movieGrid.setLayoutManager(new GridLayoutManager(this, 5));
        b.movieGrid.setAdapter(movieAdapter);
    }

    private void setupSearch() {
        b.movieSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                movieAdapter.search(s == null ? "" : s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });
    }

    private void bindTopNav() {
        b.navTv.setOnClickListener(v -> finish());
        b.navFootball.setOnClickListener(v -> pending("FUTEBOL"));
        b.navMovies.setOnClickListener(v -> b.movieSearch.requestFocus());
        b.navSeries.setOnClickListener(v -> pending("SÉRIES"));
        b.navKids.setOnClickListener(v -> pending("KIDS"));
        b.navAnime.setOnClickListener(v -> pending("ANIME"));
        b.navHot.setOnClickListener(v -> pending("HOT"));
        b.movieFavorites.setOnClickListener(v -> {
            favoriteMode = !favoriteMode;
            b.movieFavorites.setSelected(favoriteMode);
            b.movieFavorites.setText(favoriteMode ? "★ FAVORITOS" : "☆ FAVORITOS");
            movieAdapter.favoritesOnly(favoriteMode);
            if (favoriteMode) {
                categoryId = "";
                categoryName = "FAVORITOS";
                categoryAdapter.select("");
                ensureAllForFavorites();
            }
        });
    }

    private void refresh(boolean showSpinner) {
        if (loading) return;
        loadCategories();
        loadMovies(categoryId, showSpinner);
    }

    private void loadCategories() {
        repo.categories(new MovieRepository.CategoriesResult() {
            @Override public void success(List<MovieCategory> rows) {
                rawCategories.clear();
                rawCategories.addAll(rows);
                boolean selectedStillAllowed = categoryId.isEmpty();
                for (MovieCategory c : rows) if (categoryId.equals(c.id)) { selectedStillAllowed = true; break; }
                if (!selectedStillAllowed) {
                    categoryId = "";
                    categoryName = "TODOS";
                    favoriteMode = false;
                    b.movieFavorites.setSelected(false);
                    b.movieFavorites.setText("☆ FAVORITOS");
                    applyCategories(rows, null);
                    // A categoria/fonte foi retirada do bouquet enquanto o app estava aberto.
                    // Esta nova requisição invalida a antiga e já traz o catálogo atual.
                    loadMovies("", true);
                    return;
                }
                applyCategories(rows, null);
            }
            @Override public void error(String message) {
                if (rawCategories.isEmpty()) b.movieError.setText(message);
            }
        });
    }

    private void loadMovies(String requestedCategory, boolean showSpinner) {
        final int generation = ++movieRequestGeneration;
        loading = true;
        if (showSpinner) b.movieLoading.setVisibility(View.VISIBLE);
        b.movieError.setText("");
        repo.movies(requestedCategory, new MovieRepository.MoviesResult() {
            @Override public void success(List<Movie> rows) {
                if (generation != movieRequestGeneration) return;
                loading = false;
                b.movieLoading.setVisibility(View.GONE);
                lastRefreshAt = android.os.SystemClock.elapsedRealtime();
                currentMovies.clear();
                currentMovies.addAll(rows);
                movieAdapter.submit(rows);
                movieAdapter.favoritesOnly(favoriteMode);
                b.movieEmpty.setVisibility(movieAdapter.getItemCount() == 0 ? View.VISIBLE : View.GONE);
                if (requestedCategory == null || requestedCategory.isEmpty()) {
                    applyCategories(rawCategories, rows);
                }
            }
            @Override public void error(String message) {
                if (generation != movieRequestGeneration) return;
                loading = false;
                b.movieLoading.setVisibility(View.GONE);
                if (currentMovies.isEmpty()) b.movieError.setText(message);
            }
        });
    }

    private void applyCategories(List<MovieCategory> categories, List<Movie> allMovies) {
        if (categories == null || categories.isEmpty()) {
            categoryAdapter.submit(new ArrayList<>(), categoryId);
            return;
        }
        categoryAdapter.submit(categories, categoryId);
    }

    private void ensureAllForFavorites() {
        currentMovies.clear();
        movieAdapter.submit(currentMovies);
        movieAdapter.favoritesOnly(true);
        loadMovies("", true);
    }

    private void openDetails(Movie movie) {
        Intent i = new Intent(this, MovieDetailActivity.class);
        i.putExtra("id", movie.id);
        i.putExtra("name", movie.name);
        i.putExtra("poster", movie.poster);
        i.putExtra("year", movie.year);
        i.putExtra("rating", movie.rating);
        i.putExtra("extension", movie.extension);
        i.putExtra("direct_source", movie.directSource);
        startActivity(i);
    }

    private void pending(String label) {
        Toast.makeText(this, label + " será criado na próxima etapa", Toast.LENGTH_SHORT).show();
    }

    @Override protected void onResume() {
        super.onResume();
        if (movieAdapter != null) {
            movieAdapter.favoritesOnly(favoriteMode);
            if (!loading && lastRefreshAt > 0) refresh(false);
        }
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (favoriteMode) {
                favoriteMode = false;
                b.movieFavorites.setSelected(false);
                b.movieFavorites.setText("☆ FAVORITOS");
                movieAdapter.favoritesOnly(false);
                return true;
            }
            if (b.movieSearch.getText() != null && b.movieSearch.getText().length() > 0) {
                b.movieSearch.setText("");
                hideKeyboard();
                b.movieGrid.requestFocus();
                return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(b.movieSearch.getWindowToken(), 0);
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
