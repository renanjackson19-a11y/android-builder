package com.greenplay.v5.ui.player;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.OptIn;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.Tracks;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.TrackSelectionDialogBuilder;
import com.greenplay.v5.core.player.GreenPlayerFactory;
import com.greenplay.v5.databinding.ActivityPlayerBinding;

/**
 * Shared transport player. TV playback behavior is kept intact.
 * Track controls are exposed only when media_type=vod (Filmes/Séries).
 */
@OptIn(markerClass = UnstableApi.class)
public final class PlayerActivity extends AppCompatActivity {
    private ActivityPlayerBinding b;
    private ExoPlayer player;
    private String fallbackUrl;
    private boolean fallbackTried;
    private boolean vodMode;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        b = ActivityPlayerBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        String url = getIntent().getStringExtra("url");
        fallbackUrl = getIntent().getStringExtra("fallback_url");
        vodMode = "vod".equalsIgnoreCase(getIntent().getStringExtra("media_type"));
        if (url == null || url.trim().isEmpty()) { finish(); return; }

        player = GreenPlayerFactory.create(this);
        b.playerView.setPlayer(player);
        b.vodTrackControls.setVisibility(vodMode ? View.VISIBLE : View.GONE);
        if (vodMode) {
            b.playerAudio.setOnClickListener(v -> openTracks(C.TRACK_TYPE_AUDIO, "Idioma / Áudio"));
            b.playerSubtitles.setOnClickListener(v -> openTracks(C.TRACK_TYPE_TEXT, "Legendas"));
        }

        player.addListener(new Player.Listener(){
            @Override public void onPlayerError(@NonNull PlaybackException error){
                if(!fallbackTried && fallbackUrl!=null && !fallbackUrl.trim().isEmpty()){
                    fallbackTried=true;
                    startUrl(fallbackUrl);
                }
            }

            @Override public void onTracksChanged(@NonNull Tracks tracks) {
                if (!vodMode) return;
                b.playerAudio.setAlpha(tracks.containsType(C.TRACK_TYPE_AUDIO) ? 1f : 0.45f);
                b.playerSubtitles.setAlpha(tracks.containsType(C.TRACK_TYPE_TEXT) ? 1f : 0.45f);
            }
        });
        startUrl(url);
    }

    private void openTracks(int trackType, String title) {
        if (player == null) return;
        Tracks tracks = player.getCurrentTracks();
        if (!tracks.containsType(trackType)) {
            Toast.makeText(this,
                    trackType == C.TRACK_TYPE_TEXT ? "Este conteúdo não possui legendas na fonte" : "Este conteúdo possui apenas o áudio disponível na fonte",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        new TrackSelectionDialogBuilder(this, title, player, trackType)
                .setAllowAdaptiveSelections(false)
                .setAllowMultipleOverrides(false)
                .setShowDisableOption(trackType == C.TRACK_TYPE_TEXT)
                .build()
                .show();
    }

    private void startUrl(String url){
        if(player==null)return;
        MediaItem.Builder item=new MediaItem.Builder().setUri(Uri.parse(url));
        String lower=url.toLowerCase(java.util.Locale.US);
        if(lower.contains(".m3u8")) item.setMimeType(MimeTypes.APPLICATION_M3U8);
        else if(lower.contains(".ts")) item.setMimeType(MimeTypes.VIDEO_MP2T);
        player.setMediaItem(item.build());
        player.setPlayWhenReady(true);
        player.prepare();
    }

    @Override protected void onStop() { super.onStop(); if (player != null) player.pause(); }
    @Override protected void onStart() { super.onStart(); if(player!=null && player.getMediaItemCount()>0) player.play(); }
    @Override protected void onDestroy() { if(player!=null){player.release();player=null;} super.onDestroy(); }
}
