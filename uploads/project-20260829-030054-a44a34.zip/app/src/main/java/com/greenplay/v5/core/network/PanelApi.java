package com.greenplay.v5.core.network;

import com.greenplay.v5.data.model.LoginResponse;
import com.greenplay.v5.data.model.StatusResponse;
import com.greenplay.v5.data.model.TrialStatusResponse;
import com.greenplay.v5.data.model.AppConfigResponse;
import com.greenplay.v5.data.model.DiagnosticsResponse;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface PanelApi {
    @GET("status.php") Call<StatusResponse> status();
    @GET("app_config.php") Call<AppConfigResponse> appConfig();
    @GET("diagnostics.php") Call<DiagnosticsResponse> diagnostics();

    @FormUrlEncoded
    @POST("login.php")
    Call<LoginResponse> login(
            @Field("username") String username,
            @Field("password") String password,
            @Field("device") String device
    );

    @FormUrlEncoded
    @POST("trial_status.php")
    Call<TrialStatusResponse> trialStatus(@Field("device") String device);

    @FormUrlEncoded
    @POST("trial.php")
    Call<LoginResponse> trial(@Field("device") String device);
}
