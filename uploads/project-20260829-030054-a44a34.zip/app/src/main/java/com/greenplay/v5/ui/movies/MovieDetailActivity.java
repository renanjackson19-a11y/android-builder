package com.greenplay.v5.ui.movies;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.greenplay.v5.core.network.StreamUrlFactory;
import com.greenplay.v5.core.session.SessionStore;
import com.greenplay.v5.data.model.movie.MovieDetails;
import com.greenplay.v5.data.repository.MovieRepository;
import com.greenplay.v5.databinding.ActivityMovieDetailBinding;
import com.greenplay.v5.ui.player.PlayerActivity;
import com.squareup.picasso.Picasso;

public final class MovieDetailActivity extends AppCompatActivity {
    private ActivityMovieDetailBinding b;
    private SessionStore session;
    private MovieRepository repo;
    private MovieFavoritesStore favorites;
    private long movieId;
    private String name;
    private String poster;
    private String year;
    private String rating;
    private String extension;
    private String directSource;
    private MovieDetails loaded;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        b = ActivityMovieDetailBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        session = new SessionStore(this);
        if (!session.isLogged()) { finish(); return; }
        movieId = getIntent().getLongExtra("id", 0L);
        if (movieId <= 0) { finish(); return; }
        name = safe(getIntent().getStringExtra("name"));
        poster = safe(getIntent().getStringExtra("poster"));
        year = safe(getIntent().getStringExtra("year"));
        rating = safe(getIntent().getStringExtra("rating"));
        extension = safe(getIntent().getStringExtra("extension"));
        directSource = safe(getIntent().getStringExtra("direct_source"));
        if (extension.isEmpty()) extension = "mp4";
        repo = new MovieRepository(session.host(), session.user(), session.pass());
        favorites = new MovieFavoritesStore(this, session.host(), session.user());
        renderBase();
        b.movieDetailPlay.setOnClickListener(v -> play());
        b.movieDetailFavorite.setOnClickListener(v -> {
            favorites.toggle(movieId);
            updateFavorite();
        });
        b.movieDetailBack.setOnClickListener(v -> finish());
        loadDetails();
    }

    private void renderBase() {
        b.movieDetailTitle.setText(name.isEmpty() ? "FILME" : name);
        b.movieDetailMeta.setText(meta(year, rating, ""));
        if (!poster.isEmpty()) Picasso.get().load(poster).fit().centerCrop().noFade().into(b.movieDetailPoster);
        updateFavorite();
    }

    private void loadDetails() {
        b.movieDetailLoading.setVisibility(View.VISIBLE);
        repo.detail(movieId, new MovieRepository.DetailResult() {
            @Override public void success(MovieDetails detail) {
                loaded = detail;
                b.movieDetailLoading.setVisibility(View.GONE);
                if (!detail.name.isEmpty()) name = detail.name;
                if (!detail.poster.isEmpty()) poster = detail.poster;
                if (!detail.year.isEmpty()) year = detail.year;
                if (!detail.rating.isEmpty()) rating = detail.rating;
                if (!detail.extension.isEmpty()) extension = detail.extension;
                if (!detail.directSource.isEmpty()) directSource = detail.directSource;
                b.movieDetailTitle.setText(name);
                b.movieDetailPlot.setText(detail.plot.isEmpty() ? "Sinopse não informada." : detail.plot);
                b.movieDetailMeta.setText(meta(year, rating, detail.duration));
                b.movieDetailGenre.setText(line("Gênero", detail.genre));
                b.movieDetailRelease.setText(line("Lançamento", detail.releaseDate));
                b.movieDetailDirector.setText(line("Direção", detail.director));
                b.movieDetailCast.setText(line("Elenco", detail.cast));
                b.movieDetailCountry.setText(line("País", detail.country));
                if (!poster.isEmpty()) Picasso.get().load(poster).fit().centerCrop().noFade().into(b.movieDetailPoster);
                if (!detail.backdrop.isEmpty()) {
                    Picasso.get().load(detail.backdrop).fit().centerCrop().noFade().into(b.movieDetailBackdrop);
                }
            }
            @Override public void error(String message) {
                b.movieDetailLoading.setVisibility(View.GONE);
                b.movieDetailPlot.setText("Detalhes completos indisponíveis. O filme ainda pode ser reproduzido.");
            }
        });
    }

    private void play() {
        String constructed = StreamUrlFactory.movie(session.host(), session.user(), session.pass(), movieId, extension);
        String primary = directSource.isEmpty() ? constructed : directSource;
        String fallback = primary.equals(constructed) ? "" : constructed;
        Intent i = new Intent(this, PlayerActivity.class);
        i.putExtra("url", primary);
        i.putExtra("fallback_url", fallback);
        i.putExtra("title", name);
        i.putExtra("media_type", "vod");
        startActivity(i);
    }

    private void updateFavorite() {
        boolean fav = favorites.isFavorite(movieId);
        b.movieDetailFavorite.setText(fav ? "★ FAVORITO" : "☆ FAVORITAR");
        b.movieDetailFavorite.setSelected(fav);
    }

    private static String meta(String year, String rating, String duration) {
        StringBuilder s = new StringBuilder();
        if (year != null && !year.trim().isEmpty()) s.append(year.trim());
        if (rating != null && !rating.trim().isEmpty() && !"0".equals(rating.trim()) && !"0.0".equals(rating.trim())) {
            if (s.length() > 0) s.append("   •   ");
            s.append("★ ").append(rating.trim());
        }
        if (duration != null && !duration.trim().isEmpty() && !"00:00:00".equals(duration.trim())) {
            if (s.length() > 0) s.append("   •   ");
            s.append(duration.trim());
        }
        return s.toString();
    }

    private static String line(String label, String value) {
        return value == null || value.trim().isEmpty() ? "" : label + ":  " + value.trim();
    }

    private static String safe(String v) { return v == null ? "" : v.trim(); }
}
