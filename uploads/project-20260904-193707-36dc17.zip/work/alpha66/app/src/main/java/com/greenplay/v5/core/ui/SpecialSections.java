package com.greenplay.v5.core.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.text.InputType;
import android.widget.EditText;
import android.widget.Toast;
import com.greenplay.v5.core.session.SessionStore;
import com.greenplay.v5.ui.movies.MovieActivity;
import java.text.Normalizer;
import java.util.Locale;

/** Shared navigation/filter rules for the dedicated KIDS, ANIME and HOT sections. */
public final class SpecialSections {
    public static final String EXTRA_MODE = "special_mode";
    public static final String KIDS = "kids";
    public static final String ANIME = "anime";
    public static final String HOT = "hot";

    private SpecialSections() {}

    public static boolean valid(String mode) {
        return KIDS.equals(mode) || ANIME.equals(mode) || HOT.equals(mode);
    }

    public static String label(String mode) {
        if (KIDS.equals(mode)) return "KIDS";
        if (ANIME.equals(mode)) return "ANIMES";
        if (HOT.equals(mode)) return "HOT";
        return "";
    }

    public static boolean matches(String mode, String categoryName) {
        if (!valid(mode)) return true;
        String n = normalize(categoryName);
        if (n.isEmpty() || "todos".equals(n)) return false;
        if (KIDS.equals(mode)) {
            // KIDS must be strict. Generic provider names such as "Disney Plus" or
            // "Discovery Plus" carry normal/adult catalog too and must not be
            // classified as children's content just because of the brand name.
            return has(n,
                    "kids", "kid ", " kid", "infantil", "infantis", "crianca", "criancas",
                    "desenho", "desenhos", "cartoon", "cartoons", "baby", "bebe",
                    "discovery kids", "cartoon network", "disney junior", "disney channel kids",
                    "nickelodeon", "nick jr", "nick junior", "gloob", "gloobinho",
                    "boomerang", "tooncast", "cartoonito", "pbs kids", "family kids",
                    "animacao infantil", "animation kids");
        }
        if (ANIME.equals(mode)) {
            // Some Xtream servers organize anime by provider instead of using the
            // word ANIME in the category name (e.g. "Series | Crunchyroll").
            return has(n,
                    "anime", "animes", "otaku", "manga", "japan", "japao", "japones",
                    "japonesa", "japoneses", "japonesas", "animacao japonesa", "animation japan",
                    "crunchyroll", "funimation", "hidive", "anime onegai", "retrocrush");
        }
        return has(n,
                "hot", "adult", "adulto", "adultos", "adulta", "adultas", "xxx",
                "+18", "18+", "18 anos", "maiores de 18", "erotico", "erotica",
                "eroticos", "eroticas", "porno", "porn", "sexy", "sex", "playboy");
    }

    public static void open(Activity activity, String mode) {
        if (activity == null || !valid(mode)) return;
        if (HOT.equals(mode)) {
            SessionStore session = new SessionStore(activity);
            if (!session.adult()) {
                Toast.makeText(activity, "Conteúdo HOT não está liberado para esta conta", Toast.LENGTH_SHORT).show();
                return;
            }
            String saved = activity.getSharedPreferences("green_play_parental", Activity.MODE_PRIVATE).getString("pin", "");
            if (saved != null && !saved.trim().isEmpty()) {
                EditText input = new EditText(activity);
                input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
                input.setHint("PIN de 4 dígitos");
                input.setSingleLine(true);
                new AlertDialog.Builder(activity)
                        .setTitle("Conteúdo HOT")
                        .setMessage("Digite o PIN configurado neste aparelho.")
                        .setView(input)
                        .setPositiveButton("ENTRAR", (d, w) -> {
                            if (saved.equals(input.getText().toString().trim())) launch(activity, mode);
                            else Toast.makeText(activity, "PIN incorreto", Toast.LENGTH_SHORT).show();
                        })
                        .setNegativeButton("CANCELAR", null)
                        .show();
                return;
            }
        }
        launch(activity, mode);
    }

    private static void launch(Activity activity, String mode) {
        Intent i = new Intent(activity, MovieActivity.class);
        i.putExtra(EXTRA_MODE, mode);
        activity.startActivity(i);
    }

    private static boolean has(String source, String... words) {
        for (String word : words) if (source.contains(word)) return true;
        return false;
    }

    private static String normalize(String raw) {
        if (raw == null) return "";
        String s = Normalizer.normalize(raw, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        return s.toLowerCase(Locale.ROOT).replaceAll("\\s+", " ").trim();
    }
}
