package com.ativacao.app;

import android.app.Activity;
import android.content.Context;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Sincronização geral do catálogo. Na primeira entrada de cada cliente/token,
 * o app baixa e persiste todas as páginas necessárias antes de liberar a UI.
 */
final class CatalogPreloader {
    private static final String PREF="dubai_content_preload";
    private static final int CACHE_SCHEMA=5;
    private static volatile boolean running=false;
    private static volatile boolean ready=false;

    interface Progress { void onProgress(String text,int done,int total); }

    static void init(Context c){ if(c!=null) ready=c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getBoolean(key(Session.token(c)),false); }
    static boolean isReady(){ return ready; }
    static boolean isPrepared(Context c){ return c!=null && c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getBoolean(key(Session.token(c)),false); }
    private static String key(String token){ return "ready_v"+CACHE_SCHEMA+"_"+Integer.toHexString((token==null?"":token).hashCode()); }
    private static void markReady(Context c,boolean value){ if(c!=null)c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putBoolean(key(Session.token(c)),value).apply(); ready=value; }

    static void start(Activity a, boolean force, Runnable done){ start(a,force,null,done); }

    static void start(Activity a, boolean force, Progress progress, Runnable done){
        if(a==null){ if(done!=null)done.run(); return; }
        if(!force && isPrepared(a)){ ready=true; if(done!=null)done.run(); return; }
        if(running)return;
        running=true; ready=false; markReady(a,false);
        if(force) ApiClient.clearCatalogCache();

        // 10 catálogos + 3 listas auxiliares. Cada catálogo pagina até o fim.
        final String[][] jobs={
            {"live","","TV ao vivo"},
            {"movie","","Filmes"},
            {"series","","Séries"},
            {"movie","kids","Kids • filmes"},
            {"series","kids","Kids • séries"},
            {"movie","anime","Anime • filmes"},
            {"series","anime","Anime • séries"},
            {"live","adult","HOT • canais"},
            {"movie","adult","HOT • filmes"},
            {"series","adult","HOT • séries"}
        };
        final int total=jobs.length+3;
        final AtomicInteger pending=new AtomicInteger(total);
        final AtomicInteger completed=new AtomicInteger(0);
        final AtomicInteger failures=new AtomicInteger(0);

        notify(progress,"Iniciando atualização geral...",0,total);
        for(String[] j:jobs) syncAllPages(a,j[0],j[1],j[2],72,pending,completed,total,failures,progress,done);

        ApiClient.categories("movie",new ApiClient.Callback<List<String>>(){ public void ok(List<String>x){finish(a,"Categorias de filmes",pending,completed,total,failures,progress,done);} public void error(String m){failures.incrementAndGet();finish(a,"Categorias de filmes",pending,completed,total,failures,progress,done);} });
        ApiClient.categories("series",new ApiClient.Callback<List<String>>(){ public void ok(List<String>x){finish(a,"Categorias de séries",pending,completed,total,failures,progress,done);} public void error(String m){failures.incrementAndGet();finish(a,"Categorias de séries",pending,completed,total,failures,progress,done);} });
        ApiClient.hotCategories(new ApiClient.Callback<List<ApiClient.HotCategory>>(){ public void ok(List<ApiClient.HotCategory>x){finish(a,"Categorias HOT",pending,completed,total,failures,progress,done);} public void error(String m){failures.incrementAndGet();finish(a,"Categorias HOT",pending,completed,total,failures,progress,done);} });
    }

    private static void syncAllPages(Activity a,String type,String smart,String label,int limit,
                                     AtomicInteger pending,AtomicInteger completed,int total,AtomicInteger failures,
                                     Progress progress,Runnable done){
        syncPage(a,type,smart,label,1,limit,-1,pending,completed,total,failures,progress,done);
    }

    private static void syncPage(Activity a,String type,String smart,String label,int page,int limit,int pages,
                                 AtomicInteger pending,AtomicInteger completed,int total,AtomicInteger failures,
                                 Progress progress,Runnable done){
        ApiClient.catalog(type,page,limit,"","",smart,new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){
                if(p==null){ failures.incrementAndGet(); finish(a,label,pending,completed,total,failures,progress,done); return; }
                warmVisibleImages(a,p);
                int totalPages=pages>0?pages:Math.max(1,(p.total+limit-1)/limit);
                notify(progress,label+" • página "+page+"/"+totalPages,completed.get(),total);
                if(page<totalPages) syncPage(a,type,smart,label,page+1,limit,totalPages,pending,completed,total,failures,progress,done);
                else finish(a,label,pending,completed,total,failures,progress,done);
            }
            public void error(String m){ failures.incrementAndGet(); finish(a,label,pending,completed,total,failures,progress,done); }
        });
    }

    private static void warmVisibleImages(Activity a,ApiClient.CatalogPage p){
        if(p==null)return;
        // Evita download de dezenas de GB, mas deixa capas iniciais de cada página no cache.
        int max=Math.min(p.items.size(),8);
        for(int i=0;i<max;i++){
            ApiClient.Item x=p.items.get(i); if(x==null)continue;
            String u=(x.logo==null||x.logo.trim().isEmpty())?x.backdrop:x.logo;
            ImageLoader.preload(a,u);
        }
    }

    private static void finish(Activity a,String label,AtomicInteger pending,AtomicInteger completed,int total,
                               AtomicInteger failures,Progress progress,Runnable done){
        int d=completed.incrementAndGet(); notify(progress,"Concluído: "+label,d,total);
        if(pending.decrementAndGet()!=0)return;
        running=false;
        boolean ok=failures.get()==0;
        markReady(a,ok);
        notify(progress,ok?"Tudo pronto":"Falha ao atualizar parte do conteúdo",total,total);
        if(done!=null)done.run();
    }

    private static void notify(Progress p,String text,int done,int total){ if(p!=null)p.onProgress(text,done,total); }
}
