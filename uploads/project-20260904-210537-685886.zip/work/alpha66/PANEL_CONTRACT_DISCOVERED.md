# GREEN PLAY V5 — Contrato do painel independente do aplicativo

O V5 não autentica mais clientes no painel IPTV.

## API do painel do aplicativo
Base: `APP_CONTROL_BASE_URL` em `gradle.properties`.

Headers:
- `X-App-Token: GP_APP_CONTROL_2026_8F4F0B6E`
- `Accept: application/json`

Endpoints usados:
- `GET status.php`: identidade básica / fundo de login / logo.
- `GET app_config.php`: branding, lista de servidores Xtream ativos e atualização do APK.

## Login IPTV
1. App baixa `app_config.php`.
2. Recebe os servidores ativos em ordem.
3. Cliente informa apenas usuário e senha.
4. App chama diretamente em cada servidor:
   `player_api.php?username=...&password=...`
5. A primeira conta ativa define o host da sessão.
6. TV, VOD, Séries e EPG passam a usar diretamente esse Xtream.

A lista de servidores é salva localmente para permitir login mesmo em uma indisponibilidade temporária do painel do aplicativo.
