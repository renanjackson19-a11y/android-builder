GREEN PLAY V5 - PAINEL DO APP SEPARADO

Este projeto NÃO depende mais do painel IPTV para autenticar clientes.

COMO APONTAR PARA A NOVA HOSPEDAGEM
1. Suba o ZIP GREEN_PLAY_APP_CONTROL_PANEL_V1.zip.
2. Acesse /install.php e crie a senha do painel.
3. Cadastre os servidores Xtream em Servidores IPTV.
4. No projeto Android, abra gradle.properties.
5. Troque apenas:
   APP_CONTROL_BASE_URL=https://appgreenplay.clickaqui.site/api/
6. Não altere APP_CONTROL_TOKEN, pois já é igual ao painel novo.
7. Compile o APK.

LOGIN DO CLIENTE
- Cliente informa apenas usuário e senha.
- O app consulta o painel do aplicativo para receber os DNS ativos.
- Tenta os servidores em ordem de prioridade.
- A autenticação é feita diretamente no player_api.php do servidor Xtream.
- Achou uma conta ativa: entra e usa aquele servidor para TV, Filmes, Séries e EPG.
- Não achou: mostra usuário/senha inválidos.

TROCA DE FORNECEDOR
- Para trocar DNS, basta editar no painel do app.
- Não precisa recompilar o APK para trocar os servidores depois que o endereço do painel do app estiver fixo.

CARREGAMENTO
- Não existe mais a tela obrigatória de pré-carga do catálogo.
- Login aprovado abre a TV diretamente.
- Catálogos são consultados diretamente no Xtream e as imagens usam cache local conforme aparecem, no padrão de clientes universais.
