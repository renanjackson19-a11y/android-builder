package com.greenplay.v5.data.model.series;
public final class SeriesEpisode {
    public long id;
    public int season;
    public int episode;
    public String title="";
    public String extension="mp4";
    public String image="";
    public String plot="";
    public String duration="";
    public String rating="";
}
