package com.greenplay.v5.core.network;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public final class StreamUrlFactory {
    private StreamUrlFactory() {}

    public static String live(String host, String user, String pass, long id, String ext) {
        return build(host, user, pass, "live", id, emptyTo(ext, "ts"));
    }
    public static String liveTs(String host, String user, String pass, long id) {
        return build(host, user, pass, "live", id, "ts");
    }
    public static String liveHls(String host, String user, String pass, long id) {
        return build(host, user, pass, "live", id, "m3u8");
    }
    public static String movie(String host, String user, String pass, long id, String ext) {
        return build(host, user, pass, "movie", id, emptyTo(ext, "mp4"));
    }
    public static String episode(String host, String user, String pass, long id, String ext) {
        return build(host, user, pass, "series", id, emptyTo(ext, "mp4"));
    }
    private static String build(String host, String user, String pass, String path, long id, String ext) {
        return HostNormalizer.normalize(host) + "/" + path + "/" + enc(user) + "/" + enc(pass) + "/" + id + "." + ext;
    }
    private static String enc(String v) { return URLEncoder.encode(v == null ? "" : v, StandardCharsets.UTF_8); }
    private static String emptyTo(String v, String fallback) { return v == null || v.trim().isEmpty() ? fallback : v.trim(); }
}
