package com.greenplay.v5.core.config;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import com.greenplay.v5.BuildConfig;

/** Displays maintenance, notices and published updates from the separated app panel. */
public final class AppNoticeUi {
    private AppNoticeUi() {}

    public static void show(Context context, AppControlStore store) {
        if (context == null || store == null) return;
        if (store.maintenance()) {
            String msg = store.maintenanceMessage();
            if (msg == null || msg.trim().isEmpty()) msg = "Estamos realizando uma manutenção rápida. Tente novamente em instantes.";
            new AlertDialog.Builder(context).setTitle("GREEN PLAY • MANUTENÇÃO").setMessage(msg).setPositiveButton("OK", null).show();
            return;
        }
        if (store.forceUpdate() && store.updateVersionCode() > BuildConfig.VERSION_CODE && !store.apkUrl().trim().isEmpty()) {
            new AlertDialog.Builder(context).setTitle("Atualização necessária").setMessage(store.updateMessage().isEmpty()?"Existe uma nova versão do GREEN PLAY.":store.updateMessage()).setCancelable(false)
                    .setPositiveButton("ATUALIZAR", (d,w)->open(context,store.apkUrl())).show();
            return;
        }
        if (store.noticeEnabled() && !store.noticeMessage().trim().isEmpty()) {
            String hash = Integer.toHexString((store.noticeTitle()+"|"+store.noticeMessage()).hashCode());
            android.content.SharedPreferences p = context.getSharedPreferences("green_play_notice", Context.MODE_PRIVATE);
            if (!hash.equals(p.getString("shown", ""))) {
                p.edit().putString("shown",hash).apply();
                new AlertDialog.Builder(context).setTitle(store.noticeTitle().trim().isEmpty()?"GREEN PLAY":store.noticeTitle()).setMessage(store.noticeMessage()).setPositiveButton("OK",null).show();
            }
        }
    }

    private static void open(Context c,String url){try{c.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));}catch(Exception ignored){}}
}
