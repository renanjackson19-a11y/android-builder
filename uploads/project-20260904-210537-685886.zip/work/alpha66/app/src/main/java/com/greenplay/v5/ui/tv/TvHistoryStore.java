package com.greenplay.v5.ui.tv;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import com.greenplay.v5.data.model.tv.TvChannel;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

final class TvHistoryStore {
    private static final String PREF = "green_play_v5_tv";
    private static final String FAVORITES = "favorite_ids";
    private static final String RECENTS = "recent_ids";
    private final SharedPreferences prefs;

    TvHistoryStore(Context context) {
        prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    boolean isFavorite(long id) {
        return favorites().contains(String.valueOf(id));
    }

    void toggleFavorite(long id) {
        Set<String> values = favorites();
        String key = String.valueOf(id);
        if (!values.add(key)) values.remove(key);
        prefs.edit().putStringSet(FAVORITES, values).apply();
    }

    void markRecent(long id) {
        List<String> rows = new ArrayList<>(prefs.getStringSet(RECENTS, new LinkedHashSet<>()));
        String key = String.valueOf(id);
        rows.remove(key);
        rows.add(0, key);
        if (rows.size() > 30) rows = rows.subList(0, 30);
        prefs.edit().putString(RECENTS + "_ordered", TextUtils.join(",", rows)).apply();
        prefs.edit().putStringSet(RECENTS, new LinkedHashSet<>(rows)).apply();
    }

    List<TvChannel> filterFavorites(List<TvChannel> source) {
        Set<String> ids = favorites();
        List<TvChannel> out = new ArrayList<>();
        for (TvChannel c : source) if (ids.contains(String.valueOf(c.id))) out.add(c);
        return out;
    }

    List<TvChannel> filterRecents(List<TvChannel> source) {
        String ordered = prefs.getString(RECENTS + "_ordered", "");
        List<TvChannel> out = new ArrayList<>();
        if (ordered == null || ordered.trim().isEmpty()) return out;
        String[] ids = ordered.split(",");
        for (String id : ids) {
            for (TvChannel c : source) {
                if (String.valueOf(c.id).equals(id)) { out.add(c); break; }
            }
        }
        return out;
    }

    private Set<String> favorites() {
        return new LinkedHashSet<>(prefs.getStringSet(FAVORITES, new LinkedHashSet<>()));
    }
}
