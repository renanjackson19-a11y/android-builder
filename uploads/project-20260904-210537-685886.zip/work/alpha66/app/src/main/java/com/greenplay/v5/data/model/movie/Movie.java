package com.greenplay.v5.data.model.movie;

public final class Movie {
    public long id;
    public String name = "";
    public String poster = "";
    public String categoryId = "";
    public String extension = "mp4";
    public String year = "";
    public String rating = "";
    public String directSource = "";
}
