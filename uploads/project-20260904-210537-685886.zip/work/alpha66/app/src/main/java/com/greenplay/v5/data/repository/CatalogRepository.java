package com.greenplay.v5.data.repository;

import com.google.gson.JsonArray;
import com.greenplay.v5.core.network.NetworkProvider;
import com.greenplay.v5.core.network.XtreamApi;
import java.util.Collections;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public final class CatalogRepository {
    public enum CatalogType { LIVE, MOVIES, SERIES }
    public interface Result { void success(JsonArray rows); void error(String message); }

    public void load(String host, String user, String pass, CatalogType type, Result result) {
        XtreamApi api = NetworkProvider.xtream(host);
        String action = type == CatalogType.LIVE ? "get_live_streams" : type == CatalogType.MOVIES ? "get_vod_streams" : "get_series";
        api.list(user, pass, action).enqueue(new Callback<JsonArray>() {
            @Override public void onResponse(Call<JsonArray> call, Response<JsonArray> response) {
                if (!response.isSuccessful() || response.body() == null) { result.error("Catálogo indisponível"); return; }
                result.success(response.body());
            }
            @Override public void onFailure(Call<JsonArray> call, Throwable t) { result.error("Falha ao carregar catálogo"); }
        });
    }
}
