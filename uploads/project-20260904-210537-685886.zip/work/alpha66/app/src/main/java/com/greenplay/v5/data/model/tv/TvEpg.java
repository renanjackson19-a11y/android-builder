package com.greenplay.v5.data.model.tv;

public final class TvEpg {
    public String nowTitle = "Sem informação";
    public String nextTitle = "Sem informação";
    public String nowTime = "";
    public String nextTime = "";
    public long nowStart = 0L;
    public long nowStop = 0L;
}
