package com.greenplay.v5.data.model.movie;

public final class MovieCategory {
    public String id = "";
    public String name = "";

    public MovieCategory() {}

    public MovieCategory(String id, String name) {
        this.id = id == null ? "" : id;
        this.name = name == null ? "" : name;
    }
}
