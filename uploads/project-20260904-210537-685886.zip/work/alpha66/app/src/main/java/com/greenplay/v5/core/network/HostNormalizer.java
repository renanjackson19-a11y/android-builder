package com.greenplay.v5.core.network;

public final class HostNormalizer {
    private HostNormalizer() {}
    public static String normalize(String raw) {
        String h = raw == null ? "" : raw.trim();
        if (h.isEmpty()) throw new IllegalArgumentException("Servidor vazio");
        if (!h.startsWith("http://") && !h.startsWith("https://")) h = "http://" + h;
        while (h.endsWith("/")) h = h.substring(0, h.length() - 1);
        return h;
    }
}
