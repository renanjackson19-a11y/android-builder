package com.greenplay.v5.data.model.series;
public final class SeriesCategory { public String id=""; public String name=""; }
