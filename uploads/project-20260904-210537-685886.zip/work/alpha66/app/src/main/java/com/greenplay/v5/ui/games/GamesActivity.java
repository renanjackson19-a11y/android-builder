package com.greenplay.v5.ui.games;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

import com.greenplay.v5.core.catalog.CatalogMemory;
import com.greenplay.v5.core.network.StreamUrlFactory;
import com.greenplay.v5.core.session.SessionStore;
import com.greenplay.v5.data.model.tv.TvChannel;
import com.greenplay.v5.data.repository.TvRepository;
import com.greenplay.v5.databinding.ActivityGamesBinding;
import com.greenplay.v5.ui.player.PlayerActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * GREEN PLAY - Jogos de hoje.
 *
 * V5.0.80:
 * - mantém a página de jogos fornecida pelo administrador;
 * - remove somente o logo quebrado da página;
 * - identifica os nomes dos canais exibidos em cada jogo;
 * - mostra ASSISTIR apenas quando o card indica que a partida está AO VIVO;
 * - abre o canal correspondente diretamente no player nativo do GREEN PLAY.
 */
public final class GamesActivity extends AppCompatActivity {
    private static final String GAMES_URL = "https://infynix.spanel.space/jogos/index.php";
    private static final String GAMES_HOST = "infynix.spanel.space";

    private ActivityGamesBinding b;
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private SessionStore session;
    private final List<TvChannel> availableChannels = new ArrayList<>();

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        b = ActivityGamesBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        com.greenplay.v5.core.ui.UniversalUi.apply(this, b.getRoot());

        session = new SessionStore(this);
        synchronized (availableChannels) {
            availableChannels.clear();
            availableChannels.addAll(CatalogMemory.channels());
        }
        if (availableChannels.isEmpty() && session.isLogged() && !session.host().trim().isEmpty()) {
            // Fallback para processo recriado: o login normalmente já deixou os canais em memória,
            // mas se o Android matou o processo, recuperamos a lista sem bloquear a página de jogos.
            new TvRepository(session.host(), session.user(), session.pass()).channels("", new TvRepository.ChannelsResult() {
                @Override public void success(List<TvChannel> rows) {
                    synchronized (availableChannels) {
                        availableChannels.clear();
                        if (rows != null) availableChannels.addAll(rows);
                    }
                    if (rows != null && !rows.isEmpty()) CatalogMemory.setChannels(rows);
                    runOnUiThread(GamesActivity.this::injectGreenPlayEnhancements);
                }
                @Override public void error(String message) { /* a página continua utilizável */ }
            });
        }

        configureWebView();

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                if (customView != null) {
                    hideCustomView();
                } else if (b.gamesWeb.canGoBack()) {
                    b.gamesWeb.goBack();
                } else {
                    finish();
                }
            }
        });

        if (state == null) b.gamesWeb.loadUrl(GAMES_URL);
        else b.gamesWeb.restoreState(state);
    }

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    private void configureWebView() {
        WebSettings s = b.gamesWeb.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(false);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        }

        CookieManager.getInstance().setAcceptCookie(true);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(b.gamesWeb, true);
        }

        b.gamesWeb.addJavascriptInterface(new GamesBridge(), "GreenPlay");
        b.gamesWeb.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, Bitmap favicon) {
                b.gamesLoading.setVisibility(View.VISIBLE);
                b.gamesError.setVisibility(View.GONE);
            }

            @Override public void onPageFinished(WebView view, String url) {
                b.gamesLoading.setVisibility(View.GONE);
                injectGreenPlayEnhancements();
                b.gamesWeb.requestFocus();
            }

            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(view, request.getUrl());
            }

            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(view, Uri.parse(url));
            }

            @Override public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                b.gamesLoading.setVisibility(View.GONE);
                if (failingUrl != null && failingUrl.equals(view.getUrl())) showLoadError();
            }
        });

        b.gamesWeb.setWebChromeClient(new WebChromeClient() {
            @Override public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) {
                    callback.onCustomViewHidden();
                    return;
                }
                customView = view;
                customViewCallback = callback;
                b.gamesWeb.setVisibility(View.GONE);
                b.gamesCustom.addView(view);
                b.gamesCustom.setVisibility(View.VISIBLE);
            }

            @Override public void onHideCustomView() {
                hideCustomView();
            }
        });

        b.gamesRetry.setOnClickListener(v -> {
            b.gamesError.setVisibility(View.GONE);
            b.gamesWeb.loadUrl(GAMES_URL);
        });
    }

    private void injectGreenPlayEnhancements() {
        if (b == null || b.gamesWeb == null) return;
        b.gamesWeb.evaluateJavascript(GREEN_PLAY_JS, null);
    }

    private boolean handleUrl(WebView view, Uri uri) {
        if (uri == null) return false;
        String scheme = uri.getScheme();
        if (scheme == null || "http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
            String host = uri.getHost();
            if (host == null || GAMES_HOST.equalsIgnoreCase(host)) {
                view.loadUrl(uri.toString());
                return true;
            }
            // Não entrega a ponte nativa para páginas externas.
            try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
            catch (Exception e) { Toast.makeText(this, "Não foi possível abrir este link", Toast.LENGTH_SHORT).show(); }
            return true;
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível abrir este link", Toast.LENGTH_SHORT).show();
        }
        return true;
    }

    private void openChannelByName(String pageName) {
        TvChannel channel = findBestChannel(pageName);
        if (channel == null) {
            Toast.makeText(this, "Canal não encontrado na sua lista: " + safe(pageName), Toast.LENGTH_SHORT).show();
            return;
        }
        if (session == null || !session.isLogged()) {
            Toast.makeText(this, "Entre novamente no GREEN PLAY", Toast.LENGTH_SHORT).show();
            return;
        }
        String ext = channel.extension == null || channel.extension.trim().isEmpty() ? "ts" : channel.extension.trim();
        String primary = StreamUrlFactory.live(session.host(), session.user(), session.pass(), channel.id, ext);
        String fallback = "m3u8".equalsIgnoreCase(ext)
                ? StreamUrlFactory.liveTs(session.host(), session.user(), session.pass(), channel.id)
                : StreamUrlFactory.liveHls(session.host(), session.user(), session.pass(), channel.id);
        Intent i = new Intent(this, PlayerActivity.class);
        i.putExtra("url", primary);
        i.putExtra("fallback_url", fallback);
        i.putExtra("media_type", "live");
        i.putExtra("title", channel.name);
        startActivity(i);
    }

    private TvChannel findBestChannel(String requested) {
        String target = normalizeChannel(requested);
        if (target.isEmpty()) return null;
        TvChannel best = null;
        int bestScore = -1;
        synchronized (availableChannels) {
            for (TvChannel c : availableChannels) {
                if (c == null) continue;
                String candidate = normalizeChannel(c.name);
                if (candidate.isEmpty()) continue;
                int score = channelScore(target, candidate);
                if (score > bestScore) { bestScore = score; best = c; }
            }
        }
        // Evita abrir um canal apenas vagamente parecido.
        return bestScore >= 70 ? best : null;
    }

    private static int channelScore(String a, String b) {
        if (a.equals(b)) return 100;
        if (a.startsWith(b + " ") || b.startsWith(a + " ")) return 94;
        if ((a.contains(b) || b.contains(a)) && Math.min(a.length(), b.length()) >= 5) return 90;
        String[] aa = a.split(" ");
        String[] bb = b.split(" ");
        int common = 0;
        for (String x : aa) {
            if (x.length() < 2) continue;
            for (String y : bb) if (x.equals(y)) { common++; break; }
        }
        int denom = Math.max(aa.length, bb.length);
        return denom == 0 ? 0 : (int) Math.round(100.0 * common / denom);
    }

    private static String normalizeChannel(String value) {
        String s = safe(value).toUpperCase(Locale.ROOT)
                .replace("+", " PLUS ")
                .replace("&", " E ");
        s = Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        s = s.replaceAll("\\[[^]]*]", " ")
                .replaceAll("\\([^)]*\\)", " ")
                .replaceAll("[^A-Z0-9]+", " ")
                .replaceAll("\\b(FHD|FULLHD|FULL HD|UHD|4K|HD|SD|H265|HEVC|VIP|BRASIL|BRAZIL|BR)\\b", " ")
                .replaceAll("\\s+", " ").trim();
        return s;
    }

    private final class GamesBridge {
        @JavascriptInterface public String channelNames() {
            JSONArray rows = new JSONArray();
            synchronized (availableChannels) {
                for (TvChannel c : availableChannels) {
                    if (c == null || safe(c.name).isEmpty()) continue;
                    JSONObject o = new JSONObject();
                    try { o.put("name", c.name); rows.put(o); } catch (Exception ignored) {}
                }
            }
            return rows.toString();
        }

        @JavascriptInterface public void watch(String channelName) {
            runOnUiThread(() -> openChannelByName(channelName));
        }
    }

    private void showLoadError() {
        b.gamesError.setVisibility(View.VISIBLE);
    }

    private void hideCustomView() {
        if (customView == null) return;
        b.gamesCustom.removeView(customView);
        b.gamesCustom.setVisibility(View.GONE);
        b.gamesWeb.setVisibility(View.VISIBLE);
        customView = null;
        if (customViewCallback != null) customViewCallback.onCustomViewHidden();
        customViewCallback = null;
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        b.gamesWeb.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override protected void onDestroy() {
        if (b != null) {
            b.gamesWeb.removeJavascriptInterface("GreenPlay");
            b.gamesWeb.stopLoading();
            b.gamesWeb.setWebChromeClient(null);
            b.gamesWeb.setWebViewClient(null);
            b.gamesWeb.destroy();
        }
        super.onDestroy();
    }

    private static String safe(String value) { return value == null ? "" : value.trim(); }

    private static final String GREEN_PLAY_JS =
            "(function(){" +
            "if(window.__gpInstalled){try{window.__gpEnhance&&window.__gpEnhance();}catch(e){}return;}" +
            "window.__gpInstalled=true;" +
            "var style=document.createElement('style');" +
            "style.textContent='.gp-watch-btn{margin-left:10px;padding:9px 15px;border-radius:9px;border:1px solid #23e66f;background:#0b3b21;color:#fff;font-weight:800;font-size:14px;cursor:pointer;box-shadow:0 0 12px rgba(35,230,111,.24)}.gp-watch-btn:focus{outline:3px solid #23e66f;outline-offset:2px;background:#146a38}.gp-channel-wrap{display:inline-flex!important;align-items:center!important;gap:6px!important;flex-wrap:wrap!important}';" +
            "document.head&&document.head.appendChild(style);" +
            "function norm(v){return (v||'').normalize('NFD').replace(/[\\u0300-\\u036f]/g,'').toUpperCase().replace(/\\+/g,' PLUS ').replace(/&/g,' E ').replace(/\\[[^\\]]*\\]/g,' ').replace(/\\([^)]*\\)/g,' ').replace(/[^A-Z0-9]+/g,' ').replace(/\\b(FHD|FULLHD|UHD|4K|HD|SD|H265|HEVC|VIP|BRASIL|BRAZIL|BR)\\b/g,' ').replace(/\\s+/g,' ').trim();}" +
            "function score(a,b){if(!a||!b)return 0;if(a===b)return 100;if(a.indexOf(b+' ')===0||b.indexOf(a+' ')===0)return 94;if((a.indexOf(b)>=0||b.indexOf(a)>=0)&&Math.min(a.length,b.length)>=5)return 90;var aa=a.split(' '),bb=b.split(' '),c=0;aa.forEach(function(x){if(x.length<2)return;if(bb.indexOf(x)>=0)c++;});return Math.round(100*c/Math.max(aa.length,bb.length,1));}" +
            "function channels(){try{var raw=window.GreenPlay.channelNames();var arr=JSON.parse(raw||'[]');return arr.map(function(x){return {name:x.name||'',n:norm(x.name||'')};}).filter(function(x){return x.n;});}catch(e){return [];}}" +
            "function hideBrokenLogo(){document.querySelectorAll('img').forEach(function(img){var alt=(img.getAttribute('alt')||'').trim().toLowerCase();var src=(img.getAttribute('src')||'').toLowerCase();if(alt==='logo' && (src.indexOf('logo')>=0||!img.complete||img.naturalWidth===0)){img.style.display='none';var p=img.parentElement;if(p&&p.children.length===1&&((p.textContent||'').trim()===''||(p.textContent||'').trim().toLowerCase()==='logo'))p.style.display='none';}});}" +
            "function statusOf(el){var p=el;for(var i=0;i<8&&p;i++,p=p.parentElement){var t=((p.innerText||p.textContent||'')+'').toUpperCase();if(/FIM DE JOGO|ENCERRADO|FINALIZADO|ADIADO|CANCELADO|NAO INICIADO|NÃO INICIADO|AGENDADO/.test(t))return 'off';if(/AO VIVO|EM ANDAMENTO|INTERVALO|1[º°]? TEMPO|2[º°]? TEMPO|PRORROGA|PENALT|PÊNALT|\\b[0-9]{1,3}['’]\\b/.test(t))return 'live';}return 'unknown';}" +
            "function ownText(el){var c=el.cloneNode(true);c.querySelectorAll&&c.querySelectorAll('.gp-watch-btn').forEach(function(x){x.remove();});return (c.textContent||'').replace(/\\s+/g,' ').trim();}" +
            "window.__gpEnhance=function(){hideBrokenLogo();var list=channels();if(!list.length)return;var nodes=document.querySelectorAll('button,a,span,div,p,strong,b');nodes.forEach(function(el){if(el.classList&&el.classList.contains('gp-watch-btn'))return;if(el.dataset&&el.dataset.gpDone==='1')return;var txt=ownText(el);if(!txt||txt.length>42)return;var n=norm(txt);if(!n)return;var best=null,bs=0;for(var i=0;i<list.length;i++){var s=score(n,list[i].n);if(s>bs){bs=s;best=list[i];}}if(!best||bs<92)return;var st=statusOf(el);if(st!=='live')return;if(el.dataset)el.dataset.gpDone='1';if(el.parentElement)el.parentElement.classList.add('gp-channel-wrap');var bt=document.createElement('button');bt.type='button';bt.className='gp-watch-btn';bt.textContent='▶ ASSISTIR';bt.setAttribute('aria-label','Assistir '+best.name);bt.onclick=function(ev){ev.preventDefault();ev.stopPropagation();try{window.GreenPlay.watch(best.name);}catch(e){}};el.insertAdjacentElement('afterend',bt);});};" +
            "var mo=new MutationObserver(function(){clearTimeout(window.__gpTimer);window.__gpTimer=setTimeout(window.__gpEnhance,120);});" +
            "mo.observe(document.documentElement,{childList:true,subtree:true,characterData:true});" +
            "setInterval(window.__gpEnhance,1500);window.__gpEnhance();" +
            "})();";
}
