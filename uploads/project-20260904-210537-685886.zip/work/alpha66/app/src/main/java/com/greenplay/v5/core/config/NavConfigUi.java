package com.greenplay.v5.core.config;

import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Applies section visibility and ordering from the separated app control panel. */
public final class NavConfigUi {
    private NavConfigUi() {}
    public static final class Entry {
        public final String key; public final View view; public final int fallbackOrder;
        public Entry(String key, View view, int fallbackOrder){this.key=key;this.view=view;this.fallbackOrder=fallbackOrder;}
    }
    public static Entry e(String key, View view, int fallbackOrder){return new Entry(key,view,fallbackOrder);}

    public static void apply(AppControlStore store, Entry... entries) {
        if (store == null || entries == null || entries.length == 0) return;
        ViewGroup parent = null; int insert = Integer.MAX_VALUE;
        List<Entry> list = new ArrayList<>();
        for (Entry e : entries) {
            if (e == null || e.view == null) continue;
            if (parent == null && e.view.getParent() instanceof ViewGroup) parent = (ViewGroup)e.view.getParent();
            if (e.view.getParent() == parent && parent != null) insert = Math.min(insert, parent.indexOfChild(e.view));
            e.view.setVisibility(store.sectionEnabled(e.key) ? View.VISIBLE : View.GONE);
            list.add(e);
        }
        if (parent == null || insert == Integer.MAX_VALUE) return;
        Collections.sort(list, Comparator.comparingInt(x -> store.sectionOrder(x.key, x.fallbackOrder)));
        for (Entry e : list) if (e.view.getParent() == parent) parent.removeView(e.view);
        int index = Math.min(insert, parent.getChildCount());
        for (Entry e : list) parent.addView(e.view, Math.min(index++, parent.getChildCount()));
    }
}
