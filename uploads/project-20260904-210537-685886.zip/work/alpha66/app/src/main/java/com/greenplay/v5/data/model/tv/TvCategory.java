package com.greenplay.v5.data.model.tv;

public final class TvCategory {
    public final String id;
    public final String name;
    public TvCategory(String id, String name) { this.id = id == null ? "" : id; this.name = name == null ? "" : name; }
}
