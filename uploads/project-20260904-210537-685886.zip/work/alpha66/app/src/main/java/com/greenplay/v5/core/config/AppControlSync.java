package com.greenplay.v5.core.config;

import android.content.Context;
import com.greenplay.v5.core.config.ServerDirectoryStore;
import com.greenplay.v5.core.network.NetworkProvider;
import com.greenplay.v5.data.model.AppConfigResponse;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/** One lightweight background refresh of the separated GREEN PLAY control panel. */
public final class AppControlSync {
    public interface Listener { void done(boolean ok); }
    private AppControlSync() {}
    public static void refresh(Context context, Listener listener) {
        NetworkProvider.panel().appConfig().enqueue(new Callback<AppConfigResponse>() {
            @Override public void onResponse(Call<AppConfigResponse> call, Response<AppConfigResponse> response) {
                AppConfigResponse cfg=response.body(); boolean ok=response.isSuccessful()&&cfg!=null&&cfg.ok;
                if(ok){
                    if(cfg.branding!=null)new BrandingStore(context).save(cfg.branding);
                    new AppControlStore(context).save(cfg);
                    if(cfg.universal!=null&&cfg.universal.servers!=null)new ServerDirectoryStore(context).save(cfg.universal.servers);
                }
                if(listener!=null)listener.done(ok);
            }
            @Override public void onFailure(Call<AppConfigResponse> call, Throwable t){if(listener!=null)listener.done(false);}
        });
    }
}
