package com.greenplay.v5.ui.series;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.greenplay.v5.R;
import com.greenplay.v5.data.model.series.SeriesItem;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;
import java.util.List;

public final class SeriesAdapter extends RecyclerView.Adapter<SeriesAdapter.Holder>{
    public interface Listener{void onOpen(SeriesItem item);}
    private final Listener listener; private final List<SeriesItem> rows=new ArrayList<>(); private String fallback="";
    public SeriesAdapter(Listener l){listener=l;setHasStableIds(true);} public void setFallback(String u){fallback=u==null?"":u;notifyDataSetChanged();}
    public void submit(List<SeriesItem> data){rows.clear();if(data!=null)rows.addAll(data);notifyDataSetChanged();}
    @Override public long getItemId(int p){return rows.get(p).id;}
    @NonNull @Override public Holder onCreateViewHolder(@NonNull ViewGroup p,int v){View x=LayoutInflater.from(p.getContext()).inflate(R.layout.item_series,p,false);return new Holder(x);}
    @Override public void onBindViewHolder(@NonNull Holder h,int p){SeriesItem x=rows.get(p);h.title.setText(x.name);StringBuilder m=new StringBuilder();if(x.year!=null&&!x.year.isEmpty()&&!"0".equals(x.year)){m.append(x.year);}if(x.rating!=null&&!x.rating.isEmpty()&&!"0".equals(x.rating)&&!"0.0".equals(x.rating)){if(m.length()>0)m.append("  •  ");m.append("★ ").append(x.rating);}h.meta.setText(m);String url=x.cover==null?"":x.cover.trim();if(url.isEmpty())url=fallback;Picasso.get().cancelRequest(h.poster);h.poster.setImageDrawable(null);if(!url.isEmpty())Picasso.get().load(url).priority(Picasso.Priority.HIGH).fit().centerCrop().noFade().into(h.poster);h.itemView.setOnClickListener(v->listener.onOpen(x));}
    @Override public int getItemCount(){return rows.size();}
    static final class Holder extends RecyclerView.ViewHolder{final ImageView poster;final TextView title,meta;Holder(View v){super(v);poster=v.findViewById(R.id.seriesPoster);title=v.findViewById(R.id.seriesTitle);meta=v.findViewById(R.id.seriesMeta);}}
}
