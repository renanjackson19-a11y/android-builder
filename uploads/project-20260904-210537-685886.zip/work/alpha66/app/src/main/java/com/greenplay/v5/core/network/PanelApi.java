package com.greenplay.v5.core.network;

import com.greenplay.v5.data.model.AppConfigResponse;
import com.greenplay.v5.data.model.StatusResponse;
import com.greenplay.v5.data.model.DeviceResponse;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Field;

/** API do painel independente do aplicativo. Não autentica cliente IPTV. */
public interface PanelApi {
    @GET("status.php") Call<StatusResponse> status();
    @GET("app_config.php") Call<AppConfigResponse> appConfig();

    @FormUrlEncoded
    @POST("device.php")
    Call<DeviceResponse> registerDevice(
            @Field("device_id") String deviceId,
            @Field("mac") String mac,
            @Field("username") String username,
            @Field("password") String password,
            @Field("dns") String dns,
            @Field("manufacturer") String manufacturer,
            @Field("model") String model,
            @Field("android_version") String androidVersion,
            @Field("app_version") String appVersion
    );
}
