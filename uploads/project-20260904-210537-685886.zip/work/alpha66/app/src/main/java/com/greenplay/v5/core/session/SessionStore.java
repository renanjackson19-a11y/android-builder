package com.greenplay.v5.core.session;

import android.content.Context;
import android.content.SharedPreferences;
import com.greenplay.v5.core.catalog.CatalogBackgroundPrime;
import com.greenplay.v5.core.catalog.CatalogMemory;

public final class SessionStore {
    private static final String PREF = "green_play_v5_session";
    private final SharedPreferences prefs;
    public SessionStore(Context c) { prefs = c.getSharedPreferences(PREF, Context.MODE_PRIVATE); }

    public void save(String host, String user, String pass, String expires, String plan, boolean adult, String token) {
        String oldKey = identity(prefs.getString("host", ""), prefs.getString("user", ""));
        String newKey = identity(host, user);
        boolean changedServer = !oldKey.isEmpty() && !oldKey.equals(newKey);
        prefs.edit()
                .putBoolean("logged", true)
                .putString("host", host == null ? "" : host)
                .putString("user", user == null ? "" : user)
                .putString("pass", pass == null ? "" : pass)
                .putString("expires", expires == null ? "" : expires)
                .putString("plan", plan == null ? "" : plan)
                .putBoolean("adult", adult)
                .putString("token", token == null ? "" : token)
                .commit();
        if (changedServer) {
            CatalogMemory.clear();
            CatalogBackgroundPrime.reset();
        }
    }
    public boolean isLogged() { return prefs.getBoolean("logged", false); }
    public String host() { return prefs.getString("host", ""); }
    public String user() { return prefs.getString("user", ""); }
    public String pass() { return prefs.getString("pass", ""); }
    public String expires() { return prefs.getString("expires", ""); }
    public String plan() { return prefs.getString("plan", ""); }
    public boolean adult() { return prefs.getBoolean("adult", false); }
    public String token() { return prefs.getString("token", ""); }
    public void clear() {
        prefs.edit().clear().commit();
        CatalogMemory.clear();
        CatalogBackgroundPrime.reset();
    }
    private static String identity(String host,String user){return (host==null?"":host.trim().toLowerCase(java.util.Locale.ROOT).replaceAll("/+$",""))+"|"+(user==null?"":user.trim());}
}
