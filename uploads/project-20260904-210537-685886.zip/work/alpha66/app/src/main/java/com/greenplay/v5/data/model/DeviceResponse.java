package com.greenplay.v5.data.model;

public final class DeviceResponse {
    public boolean ok;
    public boolean allowed = true;
    public boolean blocked = false;
    public String message;
}
