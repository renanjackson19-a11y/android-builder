package com.greenplay.v5.data.model;

public final class MediaItem {
    public enum Type { LIVE, MOVIE, SERIES, EPISODE }
    public long id;
    public Type type;
    public String name = "";
    public String poster = "";
    public String backdrop = "";
    public String categoryId = "";
    public String categoryName = "";
    public String extension = "";
    public String plot = "";
    public String year = "";
}
