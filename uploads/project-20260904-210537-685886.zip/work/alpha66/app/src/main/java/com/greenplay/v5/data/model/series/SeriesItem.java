package com.greenplay.v5.data.model.series;

import java.util.ArrayList;
import java.util.List;

public final class SeriesItem {
    public long id;
    public String name = "";
    public String cover = "";
    public String categoryId = "";
    public String year = "";
    public String rating = "";
    /** Other Xtream records that represent the same title/year. */
    public List<Long> alternateIds = new ArrayList<>();
}
