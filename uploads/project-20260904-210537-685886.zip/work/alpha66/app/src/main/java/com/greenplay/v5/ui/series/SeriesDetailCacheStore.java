package com.greenplay.v5.ui.series;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import com.greenplay.v5.data.model.series.SeriesDetails;

/** Small per-series cache so seasons, episodes and synopsis open instantly. */
public final class SeriesDetailCacheStore {
    private static final String PREF = "green_play_v5_series_detail_cache_v1";
    private final SharedPreferences prefs;
    private final Gson gson = new Gson();
    private final String scope;

    public SeriesDetailCacheStore(Context context, String host, String user) {
        prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        scope = Integer.toHexString(((host == null ? "" : host) + "|" + (user == null ? "" : user)).hashCode());
    }

    public SeriesDetails load(long seriesId) {
        try {
            String raw = prefs.getString(scope + "_" + seriesId, "");
            if (raw == null || raw.isEmpty()) return null;
            SeriesDetails detail = gson.fromJson(raw, SeriesDetails.class);
            return detail == null || detail.episodes.isEmpty() ? null : detail;
        } catch (Exception ignored) { return null; }
    }

    public void save(long seriesId, SeriesDetails detail) {
        if (seriesId <= 0 || detail == null || detail.episodes.isEmpty()) return;
        prefs.edit().putString(scope + "_" + seriesId, gson.toJson(detail)).apply();
    }
}
