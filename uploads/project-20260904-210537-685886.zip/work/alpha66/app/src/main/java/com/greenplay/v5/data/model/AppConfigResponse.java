package com.greenplay.v5.data.model;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public final class AppConfigResponse {
    public boolean ok;
    public Branding branding;
    public Universal universal;
    public AppSettings app;
    public PlayerSettings player;
    public Notice notice;
    public Support support;
    public Update update;

    public static final class Branding {
        @SerializedName("app_name") public String appName;
        @SerializedName("support_whatsapp") public String supportWhatsapp;
        @SerializedName("accent_color") public String accentColor;
        @SerializedName("secondary_color") public String secondaryColor;
        public String logo;
        public String background;
        @SerializedName("login_background") public String loginBackground;
        public String splash;
        public String banner;
        @SerializedName("profile_photo") public String profilePhoto;
        @SerializedName("fallback_cover") public String fallbackCover;
        @SerializedName("movie_cover") public String movieCover;
        @SerializedName("series_cover") public String seriesCover;
        @SerializedName("account_title") public String accountTitle;
        @SerializedName("about_text") public String aboutText;
        @SerializedName("show_login_logo") public boolean showLoginLogo = true;
        @SerializedName("show_parental") public boolean showParental;
        @SerializedName("show_favorites") public boolean showFavorites;
        @SerializedName("show_update") public boolean showUpdate;
        @SerializedName("show_clear_cache") public boolean showClearCache;
        @SerializedName("show_support") public boolean showSupport;
        @SerializedName("show_about") public boolean showAbout;
        @SerializedName("branding_version") public long brandingVersion;
    }

    public static final class Universal {
        public boolean enabled;
        public List<Server> servers;
        @SerializedName("login_mode") public String loginMode;
    }

    public static final class Server {
        public int id;
        public String name;
        public String host;
        public String type;
        @SerializedName("default") public boolean isDefault;
        public int priority;
    }

    public static final class AppSettings {
        @SerializedName("start_section") public String startSection;
        @SerializedName("catalog_refresh_minutes") public int catalogRefreshMinutes;
        @SerializedName("image_cache_days") public int imageCacheDays;
        @SerializedName("cover_loading") public String coverLoading;
        @SerializedName("epg_refresh_minutes") public int epgRefreshMinutes;
        public String timezone;
        public List<Section> sections;
    }

    public static final class Section {
        public String key;
        public String label;
        public boolean enabled;
        public int order;
    }

    public static final class PlayerSettings {
        public String engine;
        @SerializedName("buffer_seconds") public int bufferSeconds;
        @SerializedName("reconnect_attempts") public int reconnectAttempts;
        @SerializedName("auto_reconnect") public boolean autoReconnect;
        @SerializedName("resume_enabled") public boolean resumeEnabled;
        @SerializedName("resume_prompt") public boolean resumePrompt;
        @SerializedName("remember_audio") public boolean rememberAudio;
        @SerializedName("remember_subtitle") public boolean rememberSubtitle;
        @SerializedName("subtitle_size") public String subtitleSize;
        @SerializedName("preferred_audio") public String preferredAudio;
        @SerializedName("loading_text") public String loadingText;
    }

    public static final class Notice {
        public boolean enabled;
        public String title;
        public String message;
        public boolean maintenance;
        @SerializedName("maintenance_message") public String maintenanceMessage;
    }

    public static final class Support {
        public String whatsapp;
        public String telegram;
        public String website;
        public String hours;
    }

    public static final class Update {
        @SerializedName("latest_version") public String latestVersion;
        @SerializedName("version_code") public int versionCode;
        @SerializedName("apk_url") public String apkUrl;
        @SerializedName("force_update") public boolean forceUpdate;
        public String message;
        public String changelog;
        @SerializedName("published_at") public String publishedAt;
    }
}
