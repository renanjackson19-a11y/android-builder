package com.greenplay.v5.data.repository;

import android.os.Handler;
import android.os.Looper;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.greenplay.v5.core.network.HostNormalizer;
import com.greenplay.v5.core.network.NetworkProvider;
import com.greenplay.v5.core.network.XtreamApi;
import com.greenplay.v5.data.model.series.SeriesItem;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/** Prepares the series catalog before the Series UI is added. */
public final class SeriesWarmRepository {
    public interface Result { void success(List<SeriesItem> rows); void error(String message); }
    private static final ExecutorService PARSER = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private final XtreamApi api;
    private final String host;
    private final String user;
    private final String pass;

    public SeriesWarmRepository(String host, String user, String pass) {
        this.host = HostNormalizer.normalize(host);
        this.api = NetworkProvider.xtream(host);
        this.user = user;
        this.pass = pass;
    }

    public void series(Result result) {
        api.list(user, pass, "get_series").enqueue(new Callback<JsonArray>() {
            @Override public void onResponse(Call<JsonArray> call, Response<JsonArray> response) {
                final JsonArray body = response.body();
                if (!response.isSuccessful() || body == null) {
                    result.error("Séries indisponíveis");
                    return;
                }
                PARSER.execute(() -> {
                    List<SeriesItem> out = new ArrayList<>();
                    Set<Long> seenIds = new HashSet<>();
                    Set<String> seenNames = new HashSet<>();
                    for (JsonElement e : body) {
                        if (!e.isJsonObject()) continue;
                        JsonObject o = e.getAsJsonObject();
                        long id = longVal(o, "series_id");
                        if (id <= 0 || !seenIds.add(id)) continue;
                        SeriesItem row = new SeriesItem();
                        row.id = id;
                        row.name = clean(first(str(o, "name"), str(o, "title"), "Série"));
                        row.cover = normalizeImage(first(str(o, "cover"), str(o, "stream_icon")));
                        row.categoryId = str(o, "category_id").trim();
                        row.year = str(o, "year").trim();
                        row.rating = str(o, "rating").trim();
                        String key = key(row.name, row.year);
                        if (!key.isEmpty() && !seenNames.add(key)) continue;
                        out.add(row);
                    }
                    MAIN.post(() -> result.success(out));
                });
            }

            @Override public void onFailure(Call<JsonArray> call, Throwable t) {
                result.error("Falha ao carregar séries");
            }
        });
    }

    private String normalizeImage(String raw) {
        if (raw == null) return "";
        String u = raw.trim().replace("\\/", "/").replace(" ", "%20");
        if (u.isEmpty()) return "";
        if (u.startsWith("//")) return (host.startsWith("https://") ? "https:" : "http:") + u;
        if (u.startsWith("http://") || u.startsWith("https://")) return u;
        if (u.startsWith("/")) return host + u;
        return host + "/" + u;
    }

    private static String clean(String raw) {
        if (raw == null) return "";
        String s = raw.replace("\\/", "/").replace("\n", " ").replace("\r", " ").trim();
        s = s.replaceAll("^[^\\p{L}\\p{N}(]+", "");
        return s.replaceAll("\\s{2,}", " ").trim();
    }

    private static String key(String name, String year) {
        String n = name == null ? "" : name.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}]+", "");
        String y = year == null ? "" : year.trim();
        return n.isEmpty() ? "" : n + "|" + y;
    }

    private static String first(String... values) {
        if (values == null) return "";
        for (String v : values) if (v != null && !v.trim().isEmpty()) return v.trim();
        return "";
    }

    private static String str(JsonObject o, String key) {
        try { JsonElement e = o.get(key); return e == null || e.isJsonNull() ? "" : e.getAsString(); }
        catch (Exception e) { return ""; }
    }

    private static long longVal(JsonObject o, String key) {
        try { return o.get(key).getAsLong(); } catch (Exception e) { return 0L; }
    }
}
