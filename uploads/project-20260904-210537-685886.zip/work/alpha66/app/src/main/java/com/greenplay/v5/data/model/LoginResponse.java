package com.greenplay.v5.data.model;

import com.google.gson.annotations.SerializedName;

public final class LoginResponse {
    public boolean ok;
    public String message;
    public String username;
    @SerializedName("expires_at") public String expiresAt;
    public String plan;
    @SerializedName("max_connections") public int maxConnections;
    @SerializedName("adult_access") public boolean adultAccess;
    public String bouquet;
    @SerializedName("user_token") public String userToken;
    @SerializedName("adult_pin") public String adultPin;
    @SerializedName("xtream_password") public String xtreamPassword;
    @SerializedName("xtream_host") public String xtreamHost;
}
