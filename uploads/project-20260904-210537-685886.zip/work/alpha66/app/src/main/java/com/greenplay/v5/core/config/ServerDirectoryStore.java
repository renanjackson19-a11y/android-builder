package com.greenplay.v5.core.config;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.greenplay.v5.data.model.AppConfigResponse;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/** Cache local da lista de servidores do painel independente do aplicativo. */
public final class ServerDirectoryStore {
    private static final String PREF = "green_play_v5_servers";
    private static final String KEY = "servers_json";
    private static final Type TYPE = new TypeToken<List<AppConfigResponse.Server>>(){}.getType();
    private final SharedPreferences prefs;
    private final Gson gson = new Gson();

    public ServerDirectoryStore(Context context) {
        prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public void save(List<AppConfigResponse.Server> servers) {
        prefs.edit().putString(KEY, gson.toJson(servers == null ? new ArrayList<>() : servers)).apply();
    }

    public List<AppConfigResponse.Server> load() {
        try {
            List<AppConfigResponse.Server> rows = gson.fromJson(prefs.getString(KEY, "[]"), TYPE);
            return rows == null ? new ArrayList<>() : rows;
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }
}
