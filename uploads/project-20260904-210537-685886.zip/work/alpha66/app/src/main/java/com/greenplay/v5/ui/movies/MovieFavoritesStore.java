package com.greenplay.v5.ui.movies;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.HashSet;
import java.util.Set;

public final class MovieFavoritesStore {
    private static final String PREF = "green_play_v5_movie_favorites";
    private static final String KEY = "ids";
    private final SharedPreferences prefs;
    private final String key;

    public MovieFavoritesStore(Context context, String host, String user) {
        prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String scope = Integer.toHexString(((host == null ? "" : host) + "|" + (user == null ? "" : user)).hashCode());
        key = KEY + "_" + scope;
    }

    public boolean isFavorite(long id) {
        return prefs.getStringSet(key, java.util.Collections.emptySet()).contains(String.valueOf(id));
    }

    public Set<String> snapshotIds() {
        return new HashSet<>(prefs.getStringSet(key, java.util.Collections.emptySet()));
    }

    public boolean toggle(long id) {
        Set<String> copy = snapshotIds();
        String idKey = String.valueOf(id);
        boolean now;
        if (copy.contains(idKey)) { copy.remove(idKey); now = false; }
        else { copy.add(idKey); now = true; }
        prefs.edit().putStringSet(key, copy).apply();
        return now;
    }
}
