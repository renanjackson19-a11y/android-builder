package com.greenplay.v5.core.player;

import android.content.Context;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import java.util.HashMap;
import java.util.Map;

/** V5-owned player transport configuration. No legacy player classes are reused. */
public final class GreenPlayerFactory {
    private GreenPlayerFactory() {}

    public static ExoPlayer create(Context context) {
        Map<String,String> headers = new HashMap<>();
        headers.put("Accept", "*/*");
        headers.put("Accept-Encoding", "identity");
        headers.put("Connection", "keep-alive");

        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                .setUserAgent("VLC/3.0.20 LibVLC/3.0.20")
                .setConnectTimeoutMs(8000)
                .setReadTimeoutMs(30000)
                .setAllowCrossProtocolRedirects(true)
                .setDefaultRequestProperties(headers);

        DefaultMediaSourceFactory media = new DefaultMediaSourceFactory(context)
                .setDataSourceFactory(http);
        return new ExoPlayer.Builder(context)
                .setMediaSourceFactory(media)
                .build();
    }
}
