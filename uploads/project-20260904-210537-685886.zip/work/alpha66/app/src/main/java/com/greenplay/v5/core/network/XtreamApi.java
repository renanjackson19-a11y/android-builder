package com.greenplay.v5.core.network;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface XtreamApi {
    @GET("player_api.php")
    Call<JsonObject> authenticate(@Query("username") String user, @Query("password") String pass);

    @GET("player_api.php")
    Call<JsonArray> list(
            @Query("username") String user,
            @Query("password") String pass,
            @Query("action") String action
    );

    @GET("player_api.php")
    Call<JsonArray> listByCategory(
            @Query("username") String user,
            @Query("password") String pass,
            @Query("action") String action,
            @Query("category_id") String categoryId
    );

    @GET("player_api.php")
    Call<JsonObject> seriesInfo(
            @Query("username") String user,
            @Query("password") String pass,
            @Query("action") String action,
            @Query("series_id") long seriesId
    );

    @GET("player_api.php")
    Call<JsonObject> vodInfo(
            @Query("username") String user,
            @Query("password") String pass,
            @Query("action") String action,
            @Query("vod_id") long vodId
    );

    @GET("player_api.php")
    Call<JsonObject> shortEpg(
            @Query("username") String user,
            @Query("password") String pass,
            @Query("action") String action,
            @Query("stream_id") long streamId,
            @Query("limit") int limit
    );
}
