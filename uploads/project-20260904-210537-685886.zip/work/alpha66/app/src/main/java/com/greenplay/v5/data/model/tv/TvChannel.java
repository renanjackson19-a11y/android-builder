package com.greenplay.v5.data.model.tv;

public final class TvChannel {
    public final long id;
    public final String name;
    public final String logo;
    public final String categoryId;
    public final String epgChannelId;
    public final String extension;

    public TvChannel(long id, String name, String logo, String categoryId, String epgChannelId, String extension) {
        this.id = id; this.name = name == null ? "" : name; this.logo = logo == null ? "" : logo;
        this.categoryId = categoryId == null ? "" : categoryId; this.epgChannelId = epgChannelId == null ? "" : epgChannelId;
        this.extension = extension == null || extension.trim().isEmpty() ? "ts" : extension.trim();
    }
}
