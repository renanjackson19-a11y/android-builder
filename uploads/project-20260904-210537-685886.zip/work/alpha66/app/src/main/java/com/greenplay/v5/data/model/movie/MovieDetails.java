package com.greenplay.v5.data.model.movie;

public final class MovieDetails {
    public long id;
    public String name = "";
    public String poster = "";
    public String backdrop = "";
    public String plot = "";
    public String year = "";
    public String genre = "";
    public String duration = "";
    public String director = "";
    public String cast = "";
    public String country = "";
    public String releaseDate = "";
    public String rating = "";
    public String extension = "mp4";
    public String directSource = "";
}
