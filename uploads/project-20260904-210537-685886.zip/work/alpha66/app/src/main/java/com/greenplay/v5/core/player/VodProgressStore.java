package com.greenplay.v5.core.player;

import android.content.Context;
import android.content.SharedPreferences;

/** Persistent VOD resume position, scoped by the caller supplied media key. */
public final class VodProgressStore {
    private static final String PREFS = "greenplay_vod_progress_v1";
    private final SharedPreferences prefs;

    public VodProgressStore(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public long position(String key) {
        if (key == null || key.trim().isEmpty()) return 0L;
        return prefs.getLong("p_" + key, 0L);
    }

    public long duration(String key) {
        if (key == null || key.trim().isEmpty()) return 0L;
        return prefs.getLong("d_" + key, 0L);
    }

    public void save(String key, long positionMs, long durationMs) {
        if (key == null || key.trim().isEmpty()) return;
        SharedPreferences.Editor e = prefs.edit();
        if (positionMs < 15_000L || (durationMs > 0L && positionMs >= durationMs - 45_000L)) {
            e.remove("p_" + key).remove("d_" + key).apply();
            return;
        }
        e.putLong("p_" + key, positionMs);
        if (durationMs > 0L) e.putLong("d_" + key, durationMs);
        e.apply();
    }

    public void clear(String key) {
        if (key == null || key.trim().isEmpty()) return;
        prefs.edit().remove("p_" + key).remove("d_" + key).apply();
    }
}
