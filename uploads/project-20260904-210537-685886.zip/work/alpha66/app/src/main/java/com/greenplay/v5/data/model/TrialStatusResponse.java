package com.greenplay.v5.data.model;

import com.google.gson.annotations.SerializedName;

public final class TrialStatusResponse {
    public boolean ok;

    // Compatibilidade: painel novo usa "enabled"; V9.0.69 usava "trial_enabled".
    @SerializedName(value = "enabled", alternate = {"trial_enabled"})
    public boolean enabled;

    // Boolean permite distinguir "campo ausente" (painel antigo) de false real.
    public Boolean eligible;
    public Boolean used;
    public Boolean active;
    public String message;

    @SerializedName("trial_hours") public int trialHours;
    @SerializedName("expires_at") public String expiresAt;
    @SerializedName("remaining_today") public int remainingToday;
}
