package com.greenplay.v5.ui.series;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.greenplay.v5.R;
import com.greenplay.v5.data.model.series.SeriesCategory;
import java.util.ArrayList;
import java.util.List;

public final class SeriesCategoryAdapter extends RecyclerView.Adapter<SeriesCategoryAdapter.Holder> {
    public interface Listener { void onOpen(SeriesCategory category); }
    private final Listener listener;
    private final List<SeriesCategory> rows = new ArrayList<>();
    private String selectedId = "";
    public SeriesCategoryAdapter(Listener listener){this.listener=listener;}
    public void submit(List<SeriesCategory> data,String selected){rows.clear();if(data!=null)rows.addAll(data);selectedId=selected==null?"":selected;notifyDataSetChanged();}
    public void select(String id){selectedId=id==null?"":id;notifyDataSetChanged();}
    @NonNull @Override public Holder onCreateViewHolder(@NonNull ViewGroup p,int v){View x=LayoutInflater.from(p.getContext()).inflate(R.layout.item_series_category,p,false);return new Holder(x);}
    @Override public void onBindViewHolder(@NonNull Holder h,int pos){SeriesCategory c=rows.get(pos);h.name.setText(c.name);h.itemView.setSelected((c.id==null?"":c.id).equals(selectedId));h.itemView.setOnClickListener(v->{select(c.id);listener.onOpen(c);});}
    @Override public int getItemCount(){return rows.size();}
    static final class Holder extends RecyclerView.ViewHolder{final TextView name;Holder(View v){super(v);name=v.findViewById(R.id.seriesCategoryName);}}
}
