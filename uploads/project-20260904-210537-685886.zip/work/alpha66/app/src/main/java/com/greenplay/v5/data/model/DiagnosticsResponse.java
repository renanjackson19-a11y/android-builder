package com.greenplay.v5.data.model;

import com.google.gson.annotations.SerializedName;

public final class DiagnosticsResponse {
    public boolean ok;
    public boolean database;
    @SerializedName("active_sources") public int activeSources;
    @SerializedName("iptv_name") public String iptvName;
    @SerializedName("source_name") public String sourceName;
    public int live;
    public int movies;
    public int series;
    public int episodes;
    public int epg;
    @SerializedName("server_ready") public boolean serverReady;
}
