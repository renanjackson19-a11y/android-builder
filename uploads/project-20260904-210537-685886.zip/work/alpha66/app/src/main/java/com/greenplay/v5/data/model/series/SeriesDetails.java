package com.greenplay.v5.data.model.series;
import java.util.ArrayList;
import java.util.List;
public final class SeriesDetails {
    public String name="";
    public String cover="";
    public String backdrop="";
    public String plot="";
    public String genre="";
    public String releaseDate="";
    public String rating="";
    public final List<SeriesEpisode> episodes=new ArrayList<>();
}
