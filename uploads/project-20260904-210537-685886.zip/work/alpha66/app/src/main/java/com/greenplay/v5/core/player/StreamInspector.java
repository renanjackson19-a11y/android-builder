package com.greenplay.v5.core.player;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Small V5-only stream inspector. It does not depend on any V4 class.
 * It follows redirects manually so we know the URL/container actually returned by the provider.
 */
public final class StreamInspector {
    private static final ExecutorService IO = Executors.newFixedThreadPool(2);
    private StreamInspector() {}

    public static final class Result {
        public final String requestedUrl;
        public final String finalUrl;
        public final int httpCode;
        public final String contentType;
        public final String detected;
        public Result(String requestedUrl, String finalUrl, int httpCode, String contentType, String detected) {
            this.requestedUrl = requestedUrl;
            this.finalUrl = finalUrl;
            this.httpCode = httpCode;
            this.contentType = contentType == null ? "" : contentType;
            this.detected = detected == null ? "auto" : detected;
        }
    }

    public interface Callback {
        void success(Result result);
        void error(String message);
    }

    public static void inspect(String url, Callback cb) {
        IO.execute(() -> {
            HttpURLConnection c = null;
            try {
                String current = url;
                int code = 0;
                String type = "";
                String detected = "auto";
                for (int hop = 0; hop < 6; hop++) {
                    URL u = new URL(current);
                    c = (HttpURLConnection) u.openConnection();
                    c.setInstanceFollowRedirects(false);
                    c.setConnectTimeout(8000);
                    c.setReadTimeout(8000);
                    c.setRequestMethod("GET");
                    c.setRequestProperty("User-Agent", "VLC/3.0.20 LibVLC/3.0.20");
                    c.setRequestProperty("Accept", "*/*");
                    c.setRequestProperty("Accept-Encoding", "identity");
                    c.setRequestProperty("Range", "bytes=0-2047");
                    code = c.getResponseCode();
                    type = c.getContentType() == null ? "" : c.getContentType();
                    if (code >= 300 && code < 400) {
                        String loc = c.getHeaderField("Location");
                        c.disconnect(); c = null;
                        if (loc == null || loc.trim().isEmpty()) break;
                        current = new URL(u, loc).toString();
                        continue;
                    }
                    if (code >= 200 && code < 300) {
                        String low = type.toLowerCase(Locale.US);
                        if (low.contains("mpegurl") || low.contains("m3u8")) detected = "hls";
                        else if (low.contains("mp2t") || low.contains("mpegts")) detected = "ts";
                        try (InputStream raw = c.getInputStream(); BufferedInputStream in = new BufferedInputStream(raw)) {
                            byte[] buf = new byte[2048];
                            int n = in.read(buf);
                            if (n > 0) {
                                String head = new String(buf, 0, Math.min(n, 256), java.nio.charset.StandardCharsets.UTF_8).trim();
                                if (head.startsWith("#EXTM3U")) detected = "hls";
                                else if ((buf[0] & 0xFF) == 0x47) detected = "ts";
                            }
                        } catch (Exception ignored) {}
                    }
                    if (c != null) { c.disconnect(); c = null; }
                    break;
                }
                cb.success(new Result(url, current, code, type, detected));
            } catch (Exception e) {
                if (c != null) c.disconnect();
                String m = e.getMessage();
                cb.error(m == null || m.trim().isEmpty() ? e.getClass().getSimpleName() : m);
            }
        });
    }
}
