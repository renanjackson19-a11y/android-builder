package com.greenplay.v5.core.config;

import android.content.Context;
import android.content.SharedPreferences;
import com.greenplay.v5.data.model.AppConfigResponse;

/** Persists the operational configuration delivered by the separated GREEN PLAY panel. */
public final class AppControlStore {
    private static final String PREF = "green_play_v5_app_control";
    private final SharedPreferences p;

    public AppControlStore(Context context) {
        p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public void save(AppConfigResponse cfg) {
        if (cfg == null) return;
        SharedPreferences.Editor e = p.edit();
        if (cfg.app != null) {
            e.putString("start_section", nz(cfg.app.startSection, "tv"));
            e.putInt("catalog_refresh_minutes", Math.max(1, cfg.app.catalogRefreshMinutes));
            e.putInt("image_cache_days", Math.max(1, cfg.app.imageCacheDays));
            e.putString("cover_loading", nz(cfg.app.coverLoading, "on_demand"));
            e.putInt("epg_refresh_minutes", Math.max(5, cfg.app.epgRefreshMinutes));
            e.putString("timezone", nz(cfg.app.timezone, "America/Sao_Paulo"));
            if (cfg.app.sections != null) {
                for (AppConfigResponse.Section s : cfg.app.sections) {
                    if (s == null || s.key == null || s.key.trim().isEmpty()) continue;
                    String key = s.key.trim().toLowerCase(java.util.Locale.ROOT);
                    e.putBoolean("section_" + key, s.enabled);
                    e.putInt("order_" + key, s.order);
                    if (s.label != null) e.putString("label_" + key, s.label);
                }
            }
        }
        if (cfg.player != null) {
            e.putString("player_engine", nz(cfg.player.engine, "auto"));
            e.putInt("buffer_seconds", Math.max(2, cfg.player.bufferSeconds));
            e.putInt("reconnect_attempts", Math.max(0, cfg.player.reconnectAttempts));
            e.putBoolean("auto_reconnect", cfg.player.autoReconnect);
            e.putBoolean("resume_enabled", cfg.player.resumeEnabled);
            e.putBoolean("resume_prompt", cfg.player.resumePrompt);
            e.putBoolean("remember_audio", cfg.player.rememberAudio);
            e.putBoolean("remember_subtitle", cfg.player.rememberSubtitle);
            e.putString("subtitle_size", nz(cfg.player.subtitleSize, "normal"));
            e.putString("preferred_audio", nz(cfg.player.preferredAudio, "pt"));
            e.putString("loading_text", nz(cfg.player.loadingText, "Preparando reprodução…"));
        }
        if (cfg.notice != null) {
            e.putBoolean("notice_enabled", cfg.notice.enabled);
            e.putString("notice_title", nz(cfg.notice.title, ""));
            e.putString("notice_message", nz(cfg.notice.message, ""));
            e.putBoolean("maintenance", cfg.notice.maintenance);
            e.putString("maintenance_message", nz(cfg.notice.maintenanceMessage, ""));
        }
        if (cfg.support != null) {
            e.putString("support_whatsapp", nz(cfg.support.whatsapp, ""));
            e.putString("support_telegram", nz(cfg.support.telegram, ""));
            e.putString("support_website", nz(cfg.support.website, ""));
            e.putString("support_hours", nz(cfg.support.hours, ""));
        }
        if (cfg.update != null) {
            e.putString("latest_version", nz(cfg.update.latestVersion, ""));
            e.putInt("update_version_code", cfg.update.versionCode);
            e.putString("apk_url", nz(cfg.update.apkUrl, ""));
            e.putBoolean("force_update", cfg.update.forceUpdate);
            e.putString("update_message", nz(cfg.update.message, ""));
            e.putString("changelog", nz(cfg.update.changelog, ""));
        }
        e.putLong("last_sync", System.currentTimeMillis()).apply();
    }

    public boolean sectionEnabled(String key) { return p.getBoolean("section_" + key, true); }
    public int sectionOrder(String key, int fallback) { return p.getInt("order_" + key, fallback); }
    public String sectionLabel(String key, String fallback) { return p.getString("label_" + key, fallback); }
    public String startSection() { return p.getString("start_section", "tv"); }
    public int catalogRefreshMinutes() { return p.getInt("catalog_refresh_minutes", 15); }
    public int imageCacheDays() { return p.getInt("image_cache_days", 14); }
    public int epgRefreshMinutes() { return p.getInt("epg_refresh_minutes", 30); }
    public String timezone() { return p.getString("timezone", "America/Sao_Paulo"); }
    public boolean resumeEnabled() { return p.getBoolean("resume_enabled", true); }
    public boolean resumePrompt() { return p.getBoolean("resume_prompt", true); }
    public boolean rememberAudio() { return p.getBoolean("remember_audio", true); }
    public boolean rememberSubtitle() { return p.getBoolean("remember_subtitle", true); }
    public String subtitleSize() { return p.getString("subtitle_size", "normal"); }
    public String preferredAudio() { return p.getString("preferred_audio", "pt"); }
    public String loadingText() { return p.getString("loading_text", "Preparando reprodução…"); }
    public boolean noticeEnabled() { return p.getBoolean("notice_enabled", false); }
    public String noticeTitle() { return p.getString("notice_title", ""); }
    public String noticeMessage() { return p.getString("notice_message", ""); }
    public boolean maintenance() { return p.getBoolean("maintenance", false); }
    public String maintenanceMessage() { return p.getString("maintenance_message", ""); }
    public String supportWhatsapp() { return p.getString("support_whatsapp", ""); }
    public String supportTelegram() { return p.getString("support_telegram", ""); }
    public String supportWebsite() { return p.getString("support_website", ""); }
    public String supportHours() { return p.getString("support_hours", ""); }
    public String latestVersion() { return p.getString("latest_version", ""); }
    public int updateVersionCode() { return p.getInt("update_version_code", 0); }
    public String apkUrl() { return p.getString("apk_url", ""); }
    public boolean forceUpdate() { return p.getBoolean("force_update", false); }
    public String updateMessage() { return p.getString("update_message", ""); }
    public long lastSync() { return p.getLong("last_sync", 0L); }

    private static String nz(String value, String fallback) {
        return value == null || value.trim().isEmpty() ? fallback : value.trim();
    }
}
