package com.greenplay.v5.ui.tv;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.os.Handler;
import android.os.Looper;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.greenplay.v5.R;
import com.greenplay.v5.data.model.tv.TvChannel;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.HashMap;
import java.util.Map;
import java.util.HashSet;
import java.util.Set;

final class TvChannelAdapter extends RecyclerView.Adapter<TvChannelAdapter.Holder> {
    interface Listener {
        void onFocus(TvChannel channel);
        void onOpen(TvChannel channel);
        void onFavorite(TvChannel channel);
        boolean isFavorite(TvChannel channel);
    }

    private final List<TvChannel> all = new ArrayList<>();
    private final List<TvChannel> rows = new ArrayList<>();
    private final Listener listener;
    private String sectionLabel = "TV AO VIVO";
    private long focusedId = -1L;
    private long selectedId = -1L;
    private final Map<Long,String> epgLabels = new HashMap<>();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Set<Long> pendingEpgRefresh = new HashSet<>();

    TvChannelAdapter(Listener listener){this.listener=listener; setHasStableIds(true);}
    void setRows(List<TvChannel> data){all.clear();if(data!=null)all.addAll(data);filter("");}
    void setSectionLabel(String label){sectionLabel=(label==null||label.trim().isEmpty())?"TV AO VIVO":label;notifyDataSetChanged();}
    void setSelectedChannel(long id){long old=selectedId;selectedId=id;int a=positionOf(old),b=positionOf(id);if(a>=0)notifyItemChanged(a);if(b>=0&&b!=a)notifyItemChanged(b);}
    void setEpgText(long id,String text){
        if(text==null||text.trim().isEmpty())return;
        epgLabels.put(id,text.trim());
        scheduleSafeRefresh(id);
    }
    private void scheduleSafeRefresh(long id){
        if(!pendingEpgRefresh.add(id))return;
        mainHandler.postDelayed(()->{
            pendingEpgRefresh.remove(id);
            int p=positionOf(id);
            if(p<0)return;
            try{notifyItemChanged(p, "epg");}
            catch(IllegalStateException ex){
                // RecyclerView ainda está processando uma rajada do D-pad.
                // Reagenda em vez de derrubar o app.
                scheduleSafeRefresh(id);
            }
        },90L);
    }
    TvChannel itemAt(int position){return position>=0&&position<rows.size()?rows.get(position):null;}
    List<TvChannel> snapshot(){return new ArrayList<>(all);}
    void filter(String q){rows.clear();String s=q==null?"":q.trim().toLowerCase(Locale.ROOT);for(TvChannel c:all)if(s.isEmpty()||c.name.toLowerCase(Locale.ROOT).contains(s))rows.add(c);notifyDataSetChanged();}
    TvChannel first(){return rows.isEmpty()?null:rows.get(0);}
    void refreshFavorite(long id){for(int i=0;i<rows.size();i++)if(rows.get(i).id==id){notifyItemChanged(i);break;}}
    int positionOf(long id){for(int i=0;i<rows.size();i++)if(rows.get(i).id==id)return i;return -1;}
    long focusedId(){return focusedId;}
    @Override public long getItemId(int position){return rows.get(position).id;}

    @NonNull @Override public Holder onCreateViewHolder(@NonNull ViewGroup parent,int viewType){return new Holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_tv_channel,parent,false));}
    @Override public void onBindViewHolder(@NonNull Holder h,int position,@NonNull java.util.List<Object> payloads){
        if(payloads!=null && !payloads.isEmpty()){
            TvChannel c=itemAt(position);
            if(c!=null){String epg=epgLabels.get(c.id);h.subtitle.setText(epg==null||epg.trim().isEmpty()?"Carregando programação...":epg);}
            return;
        }
        super.onBindViewHolder(h,position,payloads);
    }
    @Override public void onBindViewHolder(@NonNull Holder h,int pos){
        TvChannel c=rows.get(pos);
        h.number.setText(String.valueOf(pos+1));
        h.name.setText(c.name);
        String epg=epgLabels.get(c.id);
        h.subtitle.setText(epg==null||epg.trim().isEmpty()?"Carregando programação...":epg);
        h.favorite.setText(listener.isFavorite(c)?"★":"☆");
        h.favorite.setTextColor(0xFF29E76F);
        h.logo.setImageDrawable(null);
        if(c.logo!=null&&!c.logo.trim().isEmpty()) Picasso.get().load(c.logo).fit().centerInside().noFade().into(h.logo);
        h.itemView.setSelected(c.id==selectedId);
        h.focusMarker.setVisibility(c.id==selectedId?View.VISIBLE:View.INVISIBLE);
        h.itemView.setOnFocusChangeListener((v,focus)->{
            v.setSelected(focus || c.id==selectedId);
            h.focusMarker.setVisibility((focus || c.id==selectedId)?View.VISIBLE:View.INVISIBLE);
            if(focus){focusedId=c.id;listener.onFocus(c);}
        });
        h.itemView.setOnClickListener(v->{focusedId=c.id;listener.onOpen(c);});
        h.favorite.setOnFocusChangeListener((v,focus)->{
            h.itemView.setSelected(focus || c.id==selectedId);
            h.focusMarker.setVisibility((focus || c.id==selectedId)?View.VISIBLE:View.INVISIBLE);
            h.favorite.setTextColor(focus?0xFF7CFFAA:0xFF29E76F);
            if(focus){focusedId=c.id;listener.onFocus(c);}
        });
        h.favorite.setOnClickListener(v->{listener.onFavorite(c);h.favorite.setText(listener.isFavorite(c)?"★":"☆");});
    }
    @Override public int getItemCount(){return rows.size();}
    static final class Holder extends RecyclerView.ViewHolder{
        final TextView number,name,subtitle,favorite,focusMarker;final ImageView logo;
        Holder(View v){super(v);focusMarker=v.findViewById(R.id.channelFocusMarker);number=v.findViewById(R.id.channelNumber);name=v.findViewById(R.id.channelName);subtitle=v.findViewById(R.id.channelSubtitle);favorite=v.findViewById(R.id.channelFavorite);logo=v.findViewById(R.id.channelLogo);}
    }
}
