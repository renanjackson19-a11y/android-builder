package com.greenplay.v5.core.network;

import android.content.Context;
import com.greenplay.v5.BuildConfig;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import okhttp3.ConnectionPool;
import okhttp3.Dispatcher;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Centraliza os clientes HTTP do app.
 *
 * O Xtream usa um único pool de conexões para TV/Filmes/Séries em vez de abrir
 * um cliente novo a cada tela. Isso reduz DNS/TCP/TLS repetido e deixa a troca
 * entre seções perceptivelmente mais rápida em TV Box e Fire TV.
 */
public final class NetworkProvider {
    private static PanelApi panelApi;
    private static OkHttpClient xtreamClient;
    private static OkHttpClient xtreamDetailClient;
    private static final Map<String, XtreamApi> XTREAM_APIS = new ConcurrentHashMap<>();
    private static final Map<String, XtreamApi> XTREAM_DETAIL_APIS = new ConcurrentHashMap<>();

    private NetworkProvider() {}

    public static synchronized void init(Context context) {
        if (panelApi != null && xtreamClient != null) return;

        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
        logging.setLevel(BuildConfig.DEBUG ? HttpLoggingInterceptor.Level.BASIC : HttpLoggingInterceptor.Level.NONE);

        OkHttpClient panelClient = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .readTimeout(25, TimeUnit.SECONDS)
                .callTimeout(35, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .addInterceptor(chain -> {
                    okhttp3.Request.Builder b = chain.request().newBuilder()
                            .header("Accept", "application/json")
                            .header("User-Agent", "GreenPlay/5 Android");
                    if (!BuildConfig.APP_TOKEN.isEmpty()) b.header("X-App-Token", BuildConfig.APP_TOKEN);
                    return chain.proceed(b.build());
                })
                .addInterceptor(logging)
                .build();

        panelApi = new Retrofit.Builder()
                .baseUrl(BuildConfig.APP_CONTROL_BASE_URL)
                .client(panelClient)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(PanelApi.class);

        Dispatcher dispatcher = new Dispatcher();
        dispatcher.setMaxRequests(32);
        dispatcher.setMaxRequestsPerHost(8);
        xtreamClient = new OkHttpClient.Builder()
                .dispatcher(dispatcher)
                .connectionPool(new ConnectionPool(8, 5, TimeUnit.MINUTES))
                .connectTimeout(10, TimeUnit.SECONDS)
                .readTimeout(35, TimeUnit.SECONDS)
                .callTimeout(50, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .followRedirects(true)
                .followSslRedirects(true)
                .addInterceptor(chain -> chain.proceed(chain.request().newBuilder()
                        .header("Accept", "application/json")
                        .header("User-Agent", "GreenPlay/5 Android")
                        .header("Cache-Control", "no-cache, no-store, max-age=0")
                        .header("Pragma", "no-cache")
                        .build()))
                .build();

        // Details/episodes must never sit behind multi-megabyte catalog calls.
        // A separate dispatcher gives user-initiated requests their own queue
        // while still sharing DNS and the connection pool.
        Dispatcher detailDispatcher = new Dispatcher();
        detailDispatcher.setMaxRequests(12);
        detailDispatcher.setMaxRequestsPerHost(4);
        xtreamDetailClient = xtreamClient.newBuilder()
                .dispatcher(detailDispatcher)
                .callTimeout(35, TimeUnit.SECONDS)
                .build();
    }

    public static PanelApi panel() {
        if (panelApi == null) throw new IllegalStateException("NetworkProvider not initialized");
        return panelApi;
    }

    /** Shared raw client used by progressive catalog readers. */
    public static OkHttpClient xtreamHttp() {
        if (xtreamClient == null) throw new IllegalStateException("NetworkProvider not initialized");
        return xtreamClient;
    }

    public static XtreamApi xtream(String host) {
        if (xtreamClient == null) throw new IllegalStateException("NetworkProvider not initialized");
        String normalized = HostNormalizer.normalize(host) + "/";
        return XTREAM_APIS.computeIfAbsent(normalized, base -> new Retrofit.Builder()
                .baseUrl(base)
                .client(xtreamClient)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(XtreamApi.class));
    }

    public static XtreamApi xtreamDetails(String host) {
        if (xtreamDetailClient == null) throw new IllegalStateException("NetworkProvider not initialized");
        String normalized = HostNormalizer.normalize(host) + "/";
        return XTREAM_DETAIL_APIS.computeIfAbsent(normalized, base -> new Retrofit.Builder()
                .baseUrl(base)
                .client(xtreamDetailClient)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(XtreamApi.class));
    }
}
