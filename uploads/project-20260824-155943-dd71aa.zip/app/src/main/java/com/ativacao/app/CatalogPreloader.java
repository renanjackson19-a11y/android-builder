package com.ativacao.app;

import android.app.Activity;
import android.content.Context;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

final class CatalogPreloader {
    private static volatile boolean running=false;
    private static volatile boolean ready=false;
    private static volatile long lastRun=0L;

    static boolean isReady(){ return ready; }

    static void start(Activity a, boolean force, Runnable done){
        if(a==null){ if(done!=null)done.run(); return; }
        long now=System.currentTimeMillis();
        if(!force && ready && now-lastRun<10L*60L*1000L){ if(done!=null)done.run(); return; }
        if(running){ if(done!=null)done.run(); return; }
        running=true;
        if(force) ApiClient.clearCatalogCache();

        final List<String[]> jobs=Arrays.asList(
            new String[]{"live","",""},
            new String[]{"movie","",""},
            new String[]{"series","",""},
            new String[]{"movie","","kids"},
            new String[]{"series","","kids"},
            new String[]{"movie","","anime"},
            new String[]{"series","","anime"},
            new String[]{"live","","adult"},
            new String[]{"movie","","adult"},
            new String[]{"series","","adult"}
        );

        AtomicInteger pending=new AtomicInteger(jobs.size());
        for(String[] job:jobs){
            String type=job[0], category=job[1], smart=job[2];
            int limit="live".equals(type)?72:60;
            ApiClient.catalog(type,1,limit,"",category,smart,new ApiClient.Callback<ApiClient.CatalogPage>(){
                public void ok(ApiClient.CatalogPage p){
                    warmImages(a,p);
                    finishOne(pending,done);
                }
                public void error(String m){ finishOne(pending,done); }
            });
        }
    }

    private static void warmImages(Activity a,ApiClient.CatalogPage p){
        if(p==null)return;
        int max=Math.min(p.items.size(),36);
        for(int n=0;n<max;n++){
            ApiClient.Item i=p.items.get(n);
            if(i==null)continue;
            if(("movie".equals(i.type)||"series".equals(i.type))&&!i.tmdbLoaded){
                ApiClient.tmdbEnrich(i,new ApiClient.Callback<ApiClient.Item>(){
                    public void ok(ApiClient.Item x){
                        ImageLoader.preload(a,clean(x.logo,x.backdrop));
                        ImageLoader.preload(a,clean(x.backdrop,x.logo));
                    }
                    public void error(String m){
                        ImageLoader.preload(a,clean(i.logo,i.backdrop));
                    }
                });
            }else{
                ImageLoader.preload(a,clean(i.logo,i.backdrop));
            }
        }
    }

    private static void finishOne(AtomicInteger pending,Runnable done){
        if(pending.decrementAndGet()==0){
            running=false;ready=true;lastRun=System.currentTimeMillis();
            if(done!=null)done.run();
        }
    }

    private static String clean(String a,String b){
        String x=a==null?"":a.trim();
        return x.isEmpty()?(b==null?"":b.trim()):x;
    }
}
