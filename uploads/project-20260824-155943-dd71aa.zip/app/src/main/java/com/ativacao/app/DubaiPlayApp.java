package com.ativacao.app;

import android.app.Application;

public class DubaiPlayApp extends Application {
    @Override public void onCreate() {
        super.onCreate();
        ApiClient.setUserToken(Session.token(this));
    }
}
