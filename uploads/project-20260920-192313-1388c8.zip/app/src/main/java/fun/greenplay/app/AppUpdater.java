package fun.greenplay.app;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import androidx.core.content.FileProvider;
import org.json.*;
import java.io.*;
import java.net.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.*;

final class AppUpdater {
    private static final ExecutorService IO=Executors.newSingleThreadExecutor(r->{Thread t=new Thread(r,"gp-updater");t.setDaemon(true);return t;});
    private static final Handler MAIN=new Handler(Looper.getMainLooper());
    private static boolean checking=false,shown=false,installLaunched=false;
    private static File pendingApk=null;
    private static String pendingVersion="";

    static int dp(Context c,int v){return Math.round(v*c.getResources().getDisplayMetrics().density);}
    static GradientDrawable bg(int color,int radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(radius);return g;}
    static TextView text(Context c,String s,int sp,int color){TextView t=new TextView(c);t.setText(s);t.setTextSize(sp);t.setTextColor(color);return t;}

    static void check(MainActivity a){
        if(a==null||a.isFinishing()||checking||shown)return;
        checking=true;
        Api.post("general_setting",Api.m(),new Api.CB(){public void ok(JSONObject j){checking=false;try{
            JSONArray r=j.optJSONArray("result");if(r==null)return;HashMap<String,String> m=new HashMap<>();
            for(int i=0;i<r.length();i++){JSONObject x=r.optJSONObject(i);if(x!=null)m.put(x.optString("key"),x.optString("value"));}
            if(!"1".equals(m.get("greenplay_update_enabled")))return;
            int code=0;try{code=Integer.parseInt(m.getOrDefault("greenplay_update_version_code","0"));}catch(Exception ignored){}
            String ver=m.getOrDefault("greenplay_update_version_name","").trim();String url=m.getOrDefault("greenplay_update_apk_url","").trim();String sha=m.getOrDefault("greenplay_update_sha256","").trim().toLowerCase(java.util.Locale.ROOT);
            if(url.isEmpty()||(!url.startsWith("https://")&&!url.startsWith("http://")))return;
            final int publishedCode=code; final String publishedVer=ver, publishedUrl=url, publishedSha=sha, notes=m.getOrDefault("greenplay_update_notes",""), required=m.getOrDefault("greenplay_update_required","0");
            if(publishedCode>BuildConfig.VERSION_CODE){shown=true;showPrompt(a,publishedCode,publishedVer,publishedUrl,notes,publishedSha,"1".equals(required));return;}
            if(publishedCode<BuildConfig.VERSION_CODE||publishedSha.isEmpty())return;
            // Mesmo versionCode: compara o APK publicado com o APK realmente instalado.
            // Isso permite publicar uma correção 5.25 revisada sem o app ignorá-la.
            IO.execute(()->{try{String installed=installedApkSha256(a);MAIN.post(()->{if(a.isFinishing()||shown)return;if(!publishedSha.equals(installed)){shown=true;showPrompt(a,publishedCode,publishedVer,publishedUrl,notes,publishedSha,"1".equals(required));}});}catch(Exception ignored){}});
        }catch(Exception ignored){}}public void err(String e){checking=false;}});
    }

    static void showPrompt(MainActivity a,int code,String ver,String url,String notes,String sha,boolean required){
        if(a.isFinishing())return;
        final Dialog d=new Dialog(a,android.R.style.Theme_Material_NoActionBar);
        d.setCancelable(!required);

        final int sw=a.getResources().getDisplayMetrics().widthPixels;
        FrameLayout dim=new FrameLayout(a);
        dim.setBackgroundColor(0xf0000000);
        dim.setPadding(dp(a,22),dp(a,22),dp(a,22),dp(a,22));

        ScrollView scroll=new ScrollView(a);
        scroll.setFillViewport(false);
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setBackgroundColor(Color.TRANSPARENT);
        int maxW=dp(a,a.tvMode?620:390);
        int contentW=Math.min(sw-dp(a,44),maxW);
        FrameLayout.LayoutParams slp=new FrameLayout.LayoutParams(contentW,-2,Gravity.CENTER);
        dim.addView(scroll,slp);

        LinearLayout outer=new LinearLayout(a);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setGravity(Gravity.CENTER_HORIZONTAL);
        outer.setPadding(dp(a,6),dp(a,10),dp(a,6),dp(a,10));
        scroll.addView(outer,new ScrollView.LayoutParams(-1,-2));

        TextView mark=text(a,"↻",a.tvMode?38:34,0xff20e070);
        mark.setGravity(Gravity.CENTER);mark.setTypeface(null,1);
        LinearLayout.LayoutParams mlp=new LinearLayout.LayoutParams(dp(a,64),dp(a,58));
        mlp.setMargins(0,0,0,dp(a,4));outer.addView(mark,mlp);

        TextView title=text(a,"Atualização disponível",a.tvMode?26:24,Color.WHITE);
        title.setTypeface(null,1);title.setGravity(Gravity.CENTER);
        outer.addView(title,new LinearLayout.LayoutParams(-1,-2));

        TextView sub=text(a,"GreenPlay "+(ver.isEmpty()?String.valueOf(code):ver),a.tvMode?15:14,0xff20e070);
        sub.setGravity(Gravity.CENTER);sub.setTypeface(null,1);
        LinearLayout.LayoutParams subLp=new LinearLayout.LayoutParams(-1,-2);subLp.setMargins(0,dp(a,5),0,dp(a,18));outer.addView(sub,subLp);

        String clean=notes==null?"":notes.trim();
        if(clean.isEmpty())clean="Melhorias de desempenho, estabilidade e correções do GreenPlay.";
        TextView nt=text(a,clean,a.tvMode?14:13,0xffc7d0cb);
        nt.setLineSpacing(dp(a,2),1.08f);nt.setGravity(Gravity.CENTER);nt.setMaxLines(a.tvMode?8:7);nt.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams ntp=new LinearLayout.LayoutParams(-1,-2);ntp.setMargins(dp(a,4),0,dp(a,4),dp(a,20));outer.addView(nt,ntp);

        LinearLayout progressArea=new LinearLayout(a);
        progressArea.setOrientation(LinearLayout.VERTICAL);progressArea.setVisibility(View.GONE);
        LinearLayout.LayoutParams pap=new LinearLayout.LayoutParams(-1,-2);pap.setMargins(dp(a,8),dp(a,2),dp(a,8),dp(a,12));outer.addView(progressArea,pap);
        ProgressBar bar=new ProgressBar(a,null,android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);bar.setProgress(0);bar.setIndeterminate(false);
        try{bar.getProgressDrawable().setColorFilter(0xff20e070,android.graphics.PorterDuff.Mode.SRC_IN);}catch(Exception ignored){}
        progressArea.addView(bar,new LinearLayout.LayoutParams(-1,dp(a,6)));
        TextView state=text(a,"0%",a.tvMode?13:12,0xffd5ddd8);state.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams stp=new LinearLayout.LayoutParams(-1,dp(a,32));stp.setMargins(0,dp(a,5),0,0);progressArea.addView(state,stp);

        Button go=new Button(a);go.setText("Atualizar agora");go.setTextColor(0xff031008);go.setTextSize(a.tvMode?15:14);go.setTypeface(null,1);go.setAllCaps(false);go.setBackground(bg(0xff20e070,dp(a,24)));
        LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(-1,dp(a,52));gp.setMargins(dp(a,12),0,dp(a,12),0);outer.addView(go,gp);

        Button later=new Button(a);later.setText("Agora não");later.setTextColor(0xffaeb9b3);later.setTextSize(a.tvMode?14:13);later.setAllCaps(false);later.setBackgroundColor(Color.TRANSPARENT);later.setVisibility(required?View.GONE:View.VISIBLE);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(a,44));lp.setMargins(dp(a,12),dp(a,6),dp(a,12),0);outer.addView(later,lp);

        TextView current=text(a,"Versão atual: "+BuildConfig.VERSION_NAME,a.tvMode?12:11,0xff65726b);current.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams curp=new LinearLayout.LayoutParams(-1,-2);curp.setMargins(0,dp(a,6),0,0);outer.addView(current,curp);

        later.setOnClickListener(v->d.dismiss());
        go.setOnClickListener(v->{
            go.setEnabled(false);later.setEnabled(false);go.setVisibility(View.GONE);later.setVisibility(View.GONE);
            progressArea.setVisibility(View.VISIBLE);mark.setText("↓");title.setText("Atualizando GreenPlay");
            sub.setText("Baixando "+(ver.isEmpty()?"a nova versão":"a versão "+ver));
            download(a,d,url,ver,sha,bar,state);
        });

        d.setContentView(dim);
        Window w=d.getWindow();
        if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.setLayout(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.MATCH_PARENT);w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);}
        d.setOnShowListener(x->{Window ww=d.getWindow();if(ww!=null)ww.setLayout(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.MATCH_PARENT);if(a.tvMode)go.requestFocus();});
        d.show();
    }

    static void download(MainActivity a,Dialog d,String url,String ver,String sha,ProgressBar bar,TextView state){
        IO.execute(()->{HttpURLConnection c=null;FileOutputStream out=null;InputStream in=null;try{
            File dir=new File(a.getCacheDir(),"updates");if(!dir.exists())dir.mkdirs();File[] old=dir.listFiles();if(old!=null)for(File f:old)if(f.isFile())f.delete();
            String safe=(ver==null||ver.trim().isEmpty()?"nova":ver.trim()).replaceAll("[^0-9A-Za-z._-]","_");File apk=new File(dir,"GreenPlay_"+safe+".apk");
            c=(HttpURLConnection)new URL(url).openConnection();c.setInstanceFollowRedirects(true);c.setConnectTimeout(15000);c.setReadTimeout(30000);c.setRequestProperty("User-Agent","GreenPlay/"+BuildConfig.VERSION_NAME);int rc=c.getResponseCode();if(rc<200||rc>=400)throw new IOException("Servidor respondeu HTTP "+rc);long total=c.getContentLengthLong();if(total>350L*1024L*1024L)throw new IOException("Arquivo de atualização muito grande");in=c.getInputStream();out=new FileOutputStream(apk);byte[] buf=new byte[64*1024];long got=0,lastAt=System.currentTimeMillis(),lastBytes=0;int n;
            while((n=in.read(buf))>0){out.write(buf,0,n);got+=n;long now=System.currentTimeMillis();if(now-lastAt>=300){long dg=got-lastBytes,dt=now-lastAt;double mbps=dt>0?(dg/1024.0/1024.0)/(dt/1000.0):0;int pct=total>0?(int)Math.min(99,got*100/total):0;long fg=got,ft=total;MAIN.post(()->{if(total>0){bar.setIndeterminate(false);bar.setProgress(pct);state.setText(pct+"%  •  "+String.format(java.util.Locale.US,"%.1f MB/s",mbps));}else{bar.setIndeterminate(true);state.setText(String.format(java.util.Locale.US,"%.1f MB baixados • %.1f MB/s",fg/1024.0/1024.0,mbps));}});lastAt=now;lastBytes=got;}
            }
            out.flush();if(apk.length()<64*1024)throw new IOException("APK baixado está incompleto");String expected=sha==null?"":sha.trim().toLowerCase(java.util.Locale.ROOT);if(!expected.isEmpty()&&!expected.equals(sha256(apk)))throw new IOException("Falha na verificação do arquivo");pendingApk=apk;pendingVersion=ver;installLaunched=false;MAIN.post(()->{bar.setIndeterminate(false);bar.setProgress(100);state.setText("100% • download concluído");requestInstall(a,d);});
        }catch(Exception e){String msg=e.getMessage()==null?"Falha ao baixar a atualização":e.getMessage();MAIN.post(()->{state.setText("Erro: "+msg);Toast.makeText(a,"Não foi possível atualizar: "+msg,Toast.LENGTH_LONG).show();});}finally{try{if(in!=null)in.close();}catch(Exception ignored){}try{if(out!=null)out.close();}catch(Exception ignored){}if(c!=null)c.disconnect();}});
    }

    static String sha256(File f)throws Exception{MessageDigest d=MessageDigest.getInstance("SHA-256");try(InputStream in=new FileInputStream(f)){byte[] b=new byte[64*1024];int n;while((n=in.read(b))>0)d.update(b,0,n);}StringBuilder s=new StringBuilder();for(byte x:d.digest())s.append(String.format(java.util.Locale.US,"%02x",x));return s.toString();}

    static String installedApkSha256(Context c)throws Exception{
        if(c==null||c.getApplicationInfo()==null||c.getApplicationInfo().sourceDir==null) return "";
        return sha256(new File(c.getApplicationInfo().sourceDir));
    }

    static void requestInstall(MainActivity a,Dialog d){
        try{if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O&&!a.getPackageManager().canRequestPackageInstalls()){Intent i=new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,Uri.parse("package:"+a.getPackageName()));a.startActivity(i);Toast.makeText(a,"Permita instalar atualizações do GreenPlay e volte para continuar.",Toast.LENGTH_LONG).show();return;}install(a,d);}catch(Exception e){Toast.makeText(a,"Não foi possível abrir o instalador.",Toast.LENGTH_LONG).show();}
    }
    static void resumeInstall(MainActivity a){if(pendingApk==null||!pendingApk.exists()||installLaunched)return;try{if(Build.VERSION.SDK_INT<Build.VERSION_CODES.O||a.getPackageManager().canRequestPackageInstalls())install(a,null);}catch(Exception ignored){}}
    static void install(MainActivity a,Dialog d)throws Exception{
        if(pendingApk==null||!pendingApk.exists()||installLaunched)return;Uri uri;if(Build.VERSION.SDK_INT>=24)uri=FileProvider.getUriForFile(a,a.getPackageName()+".fileprovider",pendingApk);else uri=Uri.fromFile(pendingApk);Intent i=new Intent(Intent.ACTION_VIEW);i.setDataAndType(uri,"application/vnd.android.package-archive");i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);installLaunched=true;if(d!=null)d.dismiss();a.startActivity(i);
    }
}
