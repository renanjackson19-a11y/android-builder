GREENPLAY 5.27

App completo.
Corrige TV presa em Carregando canais e mantém sincronização de logos sem travar.
Usar com o patch de painel v131.9 para corrigir também Filmes = 0 em fontes Xtream grandes.
