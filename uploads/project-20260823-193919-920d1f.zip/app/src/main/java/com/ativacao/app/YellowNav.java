package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

final class YellowNav {
    private YellowNav(){}

    static View bar(Activity a,String active){
        boolean phone=Ui.phone(a);

        LinearLayout shell=new LinearLayout(a);
        shell.setGravity(Gravity.CENTER_VERTICAL);
        shell.setPadding(Ui.dp(a,phone?10:20),Ui.dp(a,6),Ui.dp(a,phone?10:18),Ui.dp(a,6));
        shell.setBackgroundColor(0xF5000301);

        LinearLayout brand=new LinearLayout(a);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        brand.setPadding(Ui.dp(a,10),0,Ui.dp(a,14),0);
        brand.setBackground(Ui.round(0xFF111913,28,a));

        TextView play=Ui.text(a,"▶",phone?12:15,Color.BLACK,true);
        play.setGravity(Gravity.CENTER);
        play.setBackground(Ui.gradient(Ui.GREEN,Ui.GREEN_2,11,a));
        brand.addView(play,new LinearLayout.LayoutParams(Ui.dp(a,phone?34:42),Ui.dp(a,phone?34:42)));

        TextView name=Ui.text(a,"DUBAI PLAY",phone?13:18,Color.WHITE,true);
        LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(Ui.dp(a,phone?105:135),-1);
        np.leftMargin=Ui.dp(a,10);
        brand.addView(name,np);

        shell.addView(brand,new LinearLayout.LayoutParams(Ui.dp(a,phone?165:205),Ui.dp(a,phone?44:52)));

        LinearLayout nav=new LinearLayout(a);
        nav.setGravity(Gravity.CENTER);
        addTab(a,nav,"TV",active,()->open(a,LiveTvActivity.class));
        addTab(a,nav,"DESTAQUES",active,()->{Intent i=new Intent(a,MainActivity.class);i.putExtra("show_highlights",true);a.startActivity(i);});
        addTab(a,nav,"FILMES",active,()->catalog(a,"movie","Filmes",""));
        addTab(a,nav,"SÉRIES",active,()->catalog(a,"series","Séries",""));
        addTab(a,nav,"SHOWS",active,()->discover(a,"shows","Shows"));
        addTab(a,nav,"KIDS",active,()->discover(a,"kids","Kids"));
        addTab(a,nav,"ANIMES",active,()->discover(a,"anime","Animes"));
        addTab(a,nav,"GAMES",active,()->open(a,GamesActivity.class));
        addTab(a,nav,"EXPLORAR",active,()->discover(a,"explore","Explorar"));
        shell.addView(nav,new LinearLayout.LayoutParams(0,-1,1));

        TextView search=circle(a,"⌕");
        search.setContentDescription("Buscar");
        search.setOnClickListener(v->open(a,SearchActivity.class));
        shell.addView(search,new LinearLayout.LayoutParams(Ui.dp(a,phone?42:48),Ui.dp(a,phone?42:48)));

        TextView profile=circle(a,"♙");
        profile.setContentDescription("Conta");
        profile.setOnClickListener(v->open(a,ProfileActivity.class));
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(Ui.dp(a,phone?42:48),Ui.dp(a,phone?42:48));
        pp.leftMargin=Ui.dp(a,7);
        shell.addView(profile,pp);

        return shell;
    }

    private static TextView circle(Activity a,String icon){
        TextView b=Ui.text(a,icon,Ui.phone(a)?14:17,Color.WHITE,true);
        b.setGravity(Gravity.CENTER);b.setFocusable(true);b.setClickable(true);
        Ui.focus(b,a,Ui.round(0xFF232723,30,a),Ui.stroke(0xFF1B211C,Ui.GREEN,30,a));
        return b;
    }

    private static void addTab(Activity a,LinearLayout row,String label,String active,Runnable run){
        boolean sel=label.equalsIgnoreCase(active==null?"":active);
        FrameLayout box=new FrameLayout(a);
        box.setFocusable(true);box.setClickable(true);
        TextView text=Ui.text(a,label,Ui.phone(a)?8:10,sel?Ui.GREEN:0xFFD7DDD8,sel);
        text.setGravity(Gravity.CENTER);
        box.addView(text,new FrameLayout.LayoutParams(-1,-1));
        if(sel){
            View line=new View(a);line.setBackgroundColor(Ui.GREEN);
            FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(Ui.dp(a,28),Ui.dp(a,3),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
            lp.bottomMargin=Ui.dp(a,2);box.addView(line,lp);
        }
        box.setOnClickListener(v->run.run());
        Ui.focus(box,a,Ui.round(Color.TRANSPARENT,12,a),Ui.stroke(0xFF101710,Ui.GREEN,12,a));
        int w=("DESTAQUES".equals(label)||"EXPLORAR".equals(label))?(Ui.phone(a)?70:88):(Ui.phone(a)?55:70);
        row.addView(box,new LinearLayout.LayoutParams(Ui.dp(a,w),Ui.dp(a,44)));
    }

    private static void open(Activity a,Class<?> c){a.startActivity(new Intent(a,c));}
    private static void catalog(Activity a,String type,String title,String smart){Intent i=new Intent(a,CatalogActivity.class);i.putExtra("type",type);i.putExtra("title",title);i.putExtra("smart",smart);a.startActivity(i);}
    private static void discover(Activity a,String smart,String title){Intent i=new Intent(a,DiscoverActivity.class);i.putExtra("smart",smart);i.putExtra("title",title);a.startActivity(i);}
}
