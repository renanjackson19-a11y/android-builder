package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

public class ProfileActivity extends Activity {
    private boolean phone;
    @Override public void onCreate(Bundle b){super.onCreate(b);Ui.immersive(this);phone=Ui.phone(this);setContentView(build());}

    private View build(){
        LinearLayout page=Ui.column(this);page.setBackground(Ui.diagonalGradient(0xFF07130A,0xFF010302,0,this));
        page.addView(YellowNav.bar(this,""),new LinearLayout.LayoutParams(-1,Ui.dp(this,64)));
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.HORIZONTAL);root.setPadding(Ui.dp(this,phone?20:34),Ui.dp(this,18),Ui.dp(this,phone?20:34),Ui.dp(this,18));
        LinearLayout profile=Ui.column(this);profile.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL);profile.setPadding(Ui.dp(this,18),Ui.dp(this,18),Ui.dp(this,18),Ui.dp(this,18));profile.setBackground(Ui.stroke(0xEE09110B,Ui.GREEN,14,this));
        TextView avatar=Ui.text(this,"♙",phone?28:38,Color.BLACK,true);avatar.setGravity(Gravity.CENTER);avatar.setBackground(Ui.gradient(Ui.GREEN,Ui.GREEN_2,16,this));profile.addView(avatar,new LinearLayout.LayoutParams(Ui.dp(this,72),Ui.dp(this,72)));
        TextView u=Ui.text(this,"MINHA CONTA",phone?15:20,Ui.TEXT,true);u.setGravity(Gravity.CENTER);profile.addView(u,new LinearLayout.LayoutParams(-1,Ui.dp(this,38)));
        TextView user=Ui.text(this,clean(Session.user(this),"Usuário"),11,Ui.GREEN,true);user.setGravity(Gravity.CENTER);profile.addView(user,new LinearLayout.LayoutParams(-1,Ui.dp(this,28)));
        info(profile,"PLANO",clean(Session.plan(this),"Ativo")); info(profile,"VALIDADE",clean(Session.expires(this),"não informada")); info(profile,"APARELHO",DeviceInfo.macOrId(this));
        TextView settings=Ui.button(this,"⚙ CONFIGURAÇÕES");settings.setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class)));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,Ui.dp(this,42));sp.topMargin=Ui.dp(this,14);profile.addView(settings,sp);
        TextView exit=Ui.button(this,"SAIR DA CONTA");exit.setOnClickListener(v->{Session.clear(this);startActivity(new Intent(this,LoginActivity.class));finishAffinity();});LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,Ui.dp(this,42));ep.topMargin=Ui.dp(this,8);profile.addView(exit,ep);
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(Ui.dp(this,phone?250:330),-1);pp.rightMargin=Ui.dp(this,24);root.addView(profile,pp);

        LinearLayout rightWrap=Ui.column(this);
        TextView centerTitle=Ui.text(this,"CENTRAL DA CONTA",phone?19:25,Ui.GREEN,true);
        rightWrap.addView(centerTitle,new LinearLayout.LayoutParams(-1,Ui.dp(this,46)));

        LinearLayout shortcuts=new LinearLayout(this);
        TextView hist=bigShortcut("HISTÓRICO");hist.setOnClickListener(v->{Intent in=new Intent(this,LibraryActivity.class);in.putExtra("mode","history");startActivity(in);});
        TextView fav=bigShortcut("FAVORITOS");fav.setOnClickListener(v->{Intent in=new Intent(this,LibraryActivity.class);in.putExtra("mode","favorites");startActivity(in);});
        TextView parental=bigShortcut("CONTROLE ADULTO");parental.setOnClickListener(v->startActivity(new Intent(this,ParentalSettingsActivity.class)));
        TextView search=bigShortcut("BUSCAR");search.setOnClickListener(v->startActivity(new Intent(this,SearchActivity.class)));
        shortcuts.addView(hist,new LinearLayout.LayoutParams(0,Ui.dp(this,66),1));
        LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(0,Ui.dp(this,66),1);fp.leftMargin=Ui.dp(this,8);shortcuts.addView(fav,fp);
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,Ui.dp(this,66),1);ap.leftMargin=Ui.dp(this,8);shortcuts.addView(parental,ap);
        LinearLayout.LayoutParams qp=new LinearLayout.LayoutParams(0,Ui.dp(this,66),1);qp.leftMargin=Ui.dp(this,8);shortcuts.addView(search,qp);
        rightWrap.addView(shortcuts,new LinearLayout.LayoutParams(-1,Ui.dp(this,72)));

        ScrollView scroll=new ScrollView(this);scroll.setVerticalScrollBarEnabled(false);LinearLayout body=Ui.column(this);
        body.addView(Ui.text(this,"CONTINUAR ASSISTINDO",phone?19:25,Ui.TEXT,true),new LinearLayout.LayoutParams(-1,Ui.dp(this,46)));shelf(body,LocalStore.history(this));
        body.addView(Ui.text(this,"MEUS FAVORITOS",phone?19:25,Ui.TEXT,true),new LinearLayout.LayoutParams(-1,Ui.dp(this,46)));shelf(body,LocalStore.favorites(this));
        scroll.addView(body,new ScrollView.LayoutParams(-1,-2));rightWrap.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        root.addView(rightWrap,new LinearLayout.LayoutParams(0,-1,1));
        page.addView(root,new LinearLayout.LayoutParams(-1,0,1));settings.requestFocus();return page;
    }

    private void info(LinearLayout p,String label,String value){TextView l=Ui.text(this,label+"  •  "+value,10,Ui.MUTED,false);l.setGravity(Gravity.CENTER);p.addView(l,new LinearLayout.LayoutParams(-1,Ui.dp(this,30)));}

    private TextView bigShortcut(String s){TextView t=Ui.text(this,s,phone?13:16,Color.BLACK,true);t.setGravity(Gravity.CENTER);t.setFocusable(true);t.setClickable(true);Ui.focus(t,this,Ui.gradient(Ui.GREEN,Ui.GREEN_2,14,this),Ui.stroke(0xFF0D160F,Ui.GREEN,14,this));return t;}

    private void shelf(LinearLayout body,List<ApiClient.Item> items){if(items==null||items.isEmpty()){body.addView(Ui.text(this,"Nenhum item ainda.",11,Ui.MUTED,false),new LinearLayout.LayoutParams(-1,Ui.dp(this,58)));return;}HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setHorizontalScrollBarEnabled(false);LinearLayout row=new LinearLayout(this);for(int x=0;x<Math.min(12,items.size());x++){ApiClient.Item i=items.get(x);FrameLayout card=new FrameLayout(this);card.setFocusable(true);card.setClickable(true);card.setClipToOutline(true);Ui.focus(card,this,Ui.round(Color.TRANSPARENT,3,this),Ui.stroke(Color.argb(75,255,255,255),Ui.GREEN,3,this));ImageView img=new ImageView(this);img.setScaleType(ImageView.ScaleType.CENTER_CROP);img.setBackgroundColor(Ui.PANEL_2);card.addView(img,new FrameLayout.LayoutParams(-1,-1));ImageLoader.into(this,img,i.logo);View shade=new View(this);shade.setBackground(Ui.verticalGradient(Color.TRANSPARENT,Color.argb(220,0,0,0),0,this));card.addView(shade,new FrameLayout.LayoutParams(-1,-1));TextView n=Ui.text(this,clean(i.name,"Sem nome"),9,Ui.TEXT,true);n.setMaxLines(2);n.setPadding(Ui.dp(this,6),0,Ui.dp(this,6),Ui.dp(this,5));card.addView(n,new FrameLayout.LayoutParams(-1,Ui.dp(this,42),Gravity.BOTTOM));card.setOnClickListener(v->open(i));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(Ui.dp(this,phone?118:145),Ui.dp(this,phone?154:188));cp.rightMargin=Ui.dp(this,8);row.addView(card,cp);}hsv.addView(row);body.addView(hsv,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?160:194)));}
    private void open(ApiClient.Item i){if("series".equals(i.type)){Intent in=new Intent(this,SeriesActivity.class);in.putExtra("title",clean(i.seriesTitle,i.name));startActivity(in);}else if("movie".equals(i.type)){Intent in=new Intent(this,DetailActivity.class);MainActivity.putItem(in,i);startActivity(in);}else{Intent in=new Intent(this,PlayerActivity.class);MainActivity.putItem(in,i);startActivity(in);}}
    private String clean(String v,String f){if(v==null)return f;String s=v.trim();return s.isEmpty()||"null".equalsIgnoreCase(s)?f:s;}
}
