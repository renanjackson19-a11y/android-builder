package com.ativacao.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

final class Ui {
    // Dubai Play: identidade própria, inspirada em interfaces de TV premium.
    // Fundo vinho quase-preto + foco verde, sem copiar o app de referência.
    static final int BG = Color.rgb(2, 7, 4);
    static final int BG_2 = Color.rgb(5, 16, 8);
    static final int PANEL = Color.rgb(10, 18, 12);
    static final int PANEL_2 = Color.rgb(18, 28, 20);
    static final int PANEL_3 = Color.rgb(30, 33, 26);
    static final int TEXT = Color.rgb(250, 249, 249);
    static final int MUTED = Color.rgb(174, 180, 166);
    static final int GREEN = Color.rgb(176, 255, 0);
    static final int GREEN_2 = Color.rgb(52, 210, 88);
    static final int GOLD = Color.rgb(255, 231, 38);
    static final int PURPLE = Color.rgb(143, 103, 255);
    static final int RED = Color.rgb(244, 84, 106);
    static final int BLUE = Color.rgb(62, 155, 255);
    static final int BORDER = Color.rgb(67, 72, 56);
    static final int GLASS = Color.argb(220, 7, 8, 6);
    static final int GLASS_DARK = Color.argb(245, 3, 4, 3);

    static int dp(Context c, int n) { return (int)(n * c.getResources().getDisplayMetrics().density + .5f); }
    static boolean phone(Context c) { return c.getResources().getConfiguration().smallestScreenWidthDp < 600; }
    static boolean portrait(Context c) { return c.getResources().getConfiguration().orientation == android.content.res.Configuration.ORIENTATION_PORTRAIT; }
    static int sw(Context c) { return c.getResources().getConfiguration().screenWidthDp; }

    static GradientDrawable round(int color, int radiusDp, Context c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }
    static GradientDrawable stroke(int fill, int stroke, int radiusDp, Context c) {
        GradientDrawable g = round(fill, radiusDp, c);
        g.setStroke(dp(c, 1), stroke);
        return g;
    }
    static GradientDrawable gradient(int start, int end, int radiusDp, Context c) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{start, end});
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }
    static GradientDrawable verticalGradient(int top, int bottom, int radiusDp, Context c) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{top, bottom});
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }
    static GradientDrawable diagonalGradient(int a, int b, int radiusDp, Context c) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{a, b});
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }
    static TextView text(Context c, String s, int sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setIncludeFontPadding(false);
        t.setTypeface(Typeface.create("sans", bold ? Typeface.BOLD : Typeface.NORMAL));
        return t;
    }
    static TextView button(Context c, String s) {
        TextView b = text(c, s, phone(c) ? 11 : 13, TEXT, true);
        b.setGravity(Gravity.CENTER);
        b.setFocusable(true);
        b.setClickable(true);
        b.setPadding(dp(c, 12), dp(c, 7), dp(c, 12), dp(c, 7));
        focus(b, c, round(Color.argb(72,255,255,255), 8, c), stroke(Color.argb(120,255,255,255), GREEN, 8, c));
        return b;
    }
    static TextView ghostButton(Context c, String s) {
        TextView b = text(c, s, phone(c) ? 10 : 12, TEXT, true);
        b.setGravity(Gravity.CENTER);
        b.setFocusable(true);
        b.setClickable(true);
        b.setPadding(dp(c, 10), dp(c, 6), dp(c, 10), dp(c, 6));
        focus(b, c, round(Color.argb(42,255,255,255), 50, c), stroke(Color.argb(95,255,255,255), GREEN, 50, c));
        return b;
    }
    static TextView primaryButton(Context c, String s) {
        TextView b = text(c, s, phone(c) ? 11 : 13, Color.BLACK, true);
        b.setGravity(Gravity.CENTER);
        b.setFocusable(true);
        b.setClickable(true);
        b.setPadding(dp(c, 12), dp(c, 7), dp(c, 12), dp(c, 7));
        focus(b, c, gradient(GREEN, GREEN_2, 8, c), gradient(Color.rgb(255,245,80), Color.rgb(90,245,70), 8, c));
        return b;
    }
    static TextView nav(Context c, String s, boolean selected) {
        TextView t = text(c, s, phone(c) ? 10 : 12, selected ? GREEN : Color.rgb(225,213,216), false);
        t.setGravity(Gravity.CENTER);
        t.setFocusable(true);
        t.setClickable(true);
        if (selected) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setOnFocusChangeListener((v, f) -> {
            t.setTextColor(f || selected ? GREEN : Color.rgb(225,213,216));
            t.setTypeface(Typeface.create("sans", f || selected ? Typeface.BOLD : Typeface.NORMAL));
            if (f) v.animate().scaleX(1.06f).scaleY(1.06f).setDuration(110).start();
            else v.animate().scaleX(1f).scaleY(1f).setDuration(110).start();
        });
        return t;
    }
    static void focus(View v, Context c) {
        focus(v, c, round(Color.TRANSPARENT, 8, c), stroke(Color.argb(85,255,255,255), GREEN, 8, c));
    }
    static void focus(View v, Context c, android.graphics.drawable.Drawable normal, android.graphics.drawable.Drawable focused) {
        v.setBackground(normal);
        v.setOnFocusChangeListener((view, hasFocus) -> {
            view.animate().scaleX(hasFocus ? 1.045f : 1f).scaleY(hasFocus ? 1.045f : 1f).translationZ(hasFocus ? dp(c,8) : 0).setDuration(120).start();
            view.setBackground(hasFocus ? focused : normal);
        });
    }
    static LinearLayout column(Context c) { LinearLayout l = new LinearLayout(c); l.setOrientation(LinearLayout.VERTICAL); return l; }
    static FrameLayout centered(Context c, View child, int maxDp) {
        FrameLayout box = new FrameLayout(c);
        int w = Math.min(c.getResources().getDisplayMetrics().widthPixels, dp(c, maxDp));
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(w, -1, Gravity.CENTER_HORIZONTAL);
        box.addView(child, p);
        return box;
    }
    static void immersive(android.app.Activity a) {
        a.getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }
}
