package com.ativacao.app;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.zip.GZIPInputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ConcurrentHashMap;

final class ApiClient {
    static final ExecutorService IO = Executors.newFixedThreadPool(6);
    private static final long CATALOG_CACHE_MS = 8L * 60L * 1000L;
    private static final ConcurrentHashMap<String, CatalogCacheEntry> CATALOG_CACHE = new ConcurrentHashMap<>();
    // V4.1.6: catálogo fresco somente da sessão atual.
    private static final ConcurrentHashMap<String, java.util.List<Item>> SESSION_ITEMS = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<String, java.util.LinkedHashMap<String,String>> SESSION_CATEGORIES = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<String,Object> SESSION_LOCKS = new ConcurrentHashMap<>();
    
    private static final ConcurrentHashMap<String,SeriesData> SERIES_CACHE = new ConcurrentHashMap<>();
private static volatile String USER_TOKEN = "";
    private static volatile String XTREAM_HOST = "";
    private static volatile String XTREAM_USER = "";
    private static volatile String XTREAM_PASSWORD = "";
    private static final ConcurrentHashMap<String,String> XTREAM_CATEGORY_IDS = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<String,Long> XTREAM_SERIES_IDS = new ConcurrentHashMap<>();
    static void setUserToken(String token){ USER_TOKEN = token == null ? "" : token.trim(); }
    static void setXtreamCredentials(String user,String password){ XTREAM_USER=user==null?"":user.trim(); XTREAM_PASSWORD=password==null?"":password; }
    static void setXtreamServer(String host,String user,String password){
        XTREAM_HOST=cleanHost(host);
        setXtreamCredentials(user,password);
        XTREAM_CATEGORY_IDS.clear(); XTREAM_SERIES_IDS.clear(); CATALOG_CACHE.clear(); SERIES_CACHE.clear(); SESSION_ITEMS.clear(); SESSION_CATEGORIES.clear();
    }
    static boolean hasXtream(){ return !XTREAM_USER.isEmpty() && !XTREAM_PASSWORD.isEmpty(); }
    private static String cleanHost(String raw){
        String h=raw==null?"":raw.trim();
        while(h.endsWith("/"))h=h.substring(0,h.length()-1);
        if(!h.isEmpty()&&!h.startsWith("http://")&&!h.startsWith("https://"))h="http://"+h;
        return h;
    }
    static void clearCatalogCache(){ CATALOG_CACHE.clear(); SERIES_CACHE.clear(); SESSION_ITEMS.clear(); SESSION_CATEGORIES.clear(); PersistentContentCache.clearAll(); }

    private static class CatalogCacheEntry {
        final CatalogPage page;
        final long at;
        CatalogCacheEntry(CatalogPage page){ this.page=page; this.at=System.currentTimeMillis(); }
    }

    interface Callback<T> { void ok(T value); void error(String message); }

    static class Item {
        long id;
        String name = "";
        String logo = "";
        String backdrop = "";
        String group = "";
        String synopsis = "";
        String type = "";
        String format = "auto";
        String seriesTitle = "";
        int year = 0;
        int episodeCount = 0;
        int seasonCount = 0;
        int seasonNumber = 0;
        int episodeNumber = 0;
        int tmdbId = 0;
        boolean tmdbLoaded = false;
        int sourceId = 0;
        String sourceName = "";
        boolean adult = false;
    }

    static class HomeData {
        String name = "Dubai Play";
        int liveCount;
        int movieCount;
        int seriesCount;
        Item hero;
        final List<Item> live = new ArrayList<>();
        final List<Item> movies = new ArrayList<>();
        final List<Item> series = new ArrayList<>();
    }

    static class CatalogPage {
        int page = 1;
        int pages = 1;
        int total = 0;
        final List<Item> items = new ArrayList<>();
        final List<String> categories = new ArrayList<>();
    }

    static class SeriesData {
        String title = "";
        String logo = "";
        String backdrop = "";
        String synopsis = "";
        String group = "";
        int year = 0;
        final List<Season> seasons = new ArrayList<>();
    }

    static class Season {
        int number;
        final List<Item> episodes = new ArrayList<>();
    }

    static class EpgInfo {
        String nowTitle = "";
        String nowStart = "";
        String nowStop = "";
        String nextTitle = "";
        String nextStart = "";
    }

    static class Section {
        String title = "";
        String subtitle = "";
        String type = "live";
        String category = "";
        String smart = "";
        String action = "catalog";
        int count = 0;
    }

    static class FootballMatch {
        String league = "";
        String home = "";
        String away = "";
        String homeLogo = "";
        String awayLogo = "";
        String status = "";
        String clock = "";
        String score = "";
        String date = "";
        String channel = "";
        String leagueLogo = "";
    }


    static class Capabilities {
        boolean adultAccess = false;
        String bouquet = "";
        int adultItems = 0;
    }

    static void capabilities(Callback<Capabilities> cb) {
        IO.execute(() -> {
            try {
                JSONObject o = new JSONObject(request(Config.API_BASE_URL + "capabilities.php", true));
                if(!o.optBoolean("ok",false)) throw new Exception("Não foi possível atualizar o pacote");
                Capabilities c=new Capabilities();
                c.adultAccess=o.optBoolean("adult_access",false);
                c.bouquet=clean(o.optString("bouquet",""),"");
                c.adultItems=o.optInt("adult_items",0);
                cb.ok(c);
            } catch(Exception e){ cb.error(message(e)); }
        });
    }

    static String absoluteAssetUrl(String raw){
        String u=clean(raw,"");
        if(u.isEmpty())return "";
        if(u.startsWith("http://")||u.startsWith("https://"))return u;
        try{
            URL base=new URL(Config.API_BASE_URL);
            String root=base.getProtocol()+"://"+base.getHost()+(base.getPort()>0?":"+base.getPort():"");
            if(!u.startsWith("/"))u="/"+u;
            return root+u;
        }catch(Exception e){return u;}
    }


    static class AppServer {
        int id=0;
        String name="Servidor IPTV";
        String host="";
        String type="xtream";
        boolean isDefault=false;
    }

    static void appServers(Callback<List<AppServer>> cb) {
        IO.execute(() -> {
            try {
                JSONObject root = new JSONObject(request(Config.API_BASE_URL + "app_servers.php", true));
                JSONArray rows = root.optJSONArray("servers");
                List<AppServer> out = new ArrayList<>();
                if(rows!=null){
                    for(int i=0;i<rows.length();i++){
                        JSONObject o=rows.optJSONObject(i); if(o==null)continue;
                        AppServer s=new AppServer();
                        s.id=o.optInt("id",0);
                        s.name=clean(o.optString("name","Servidor IPTV"),"Servidor IPTV");
                        s.host=clean(o.optString("host",""),"");
                        s.type=clean(o.optString("type","xtream"),"xtream");
                        s.isDefault=o.optBoolean("default",false);
                        if(!s.host.isEmpty())out.add(s);
                    }
                }
                cb.ok(out);
            } catch(Exception e){ cb.error(message(e)); }
        });
    }

    static void appConfig(Callback<AppStatus> cb) {
        IO.execute(() -> {
            try {
                JSONObject root = new JSONObject(request(Config.API_BASE_URL + "app_config.php", true));
                JSONObject b=root.optJSONObject("branding");
                AppStatus st=new AppStatus();
                if(b!=null){
                    st.name=clean(b.optString("app_name","Green Play"),"Green Play");
                    st.appLogo=absoluteAssetUrl(b.optString("logo",""));
                    st.internalBackground=absoluteAssetUrl(b.optString("background",""));
                    st.loginBackground=st.internalBackground;
                    st.supportWhatsapp=clean(b.optString("support_whatsapp",""),"");
                    st.accountTitle=clean(b.optString("account_title","GREEN PLAY • SUA CENTRAL DE ENTRETENIMENTO"),"GREEN PLAY • SUA CENTRAL DE ENTRETENIMENTO");
                    st.aboutText=clean(b.optString("about_text",""),"");
                    st.showParental=b.optBoolean("show_parental",true);
                    st.showFavorites=b.optBoolean("show_favorites",true);
                    st.showUpdate=b.optBoolean("show_update",true);
                    st.showClearCache=b.optBoolean("show_clear_cache",true);
                    st.showSupport=b.optBoolean("show_support",true);
                    st.showAbout=b.optBoolean("show_about",true);
                }
                cb.ok(st);
            } catch(Exception e){ cb.error(message(e)); }
        });
    }

    static void loginXtream(String host,String username,String password,Callback<LoginResult> cb){
        IO.execute(() -> {
            try{
                String h=cleanHost(host);
                if(h.isEmpty())throw new Exception("Servidor inválido");
                String url=h+"/player_api.php?username="+URLEncoder.encode(username,"UTF-8")
                        +"&password="+URLEncoder.encode(password,"UTF-8");
                JSONObject root=new JSONObject(request(url,false));
                JSONObject ui=root.optJSONObject("user_info");
                if(ui==null || ui.optInt("auth",1)==0 || !"Active".equalsIgnoreCase(ui.optString("status","Active")))
                    throw new Exception("Usuário ou senha inválidos");
                LoginResult r=new LoginResult();
                r.username=clean(ui.optString("username",username),username);
                long exp=0;try{exp=Long.parseLong(ui.optString("exp_date","0"));}catch(Exception ignored){}
                r.expiresAt=exp>0?new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss",java.util.Locale.US).format(new java.util.Date(exp*1000L)):"";
                r.maxConnections=Math.max(1,ui.optInt("max_connections",1));
                r.adultAccess=true; // servidor externo: mostra HOT somente se houver categorias adultas
                r.userToken="xtream_"+Integer.toHexString((h+"|"+r.username).hashCode());
                setUserToken(r.userToken);
                setXtreamServer(h,r.username,password);
                cb.ok(r);
            }catch(Exception e){cb.error(message(e));}
        });
    }

    static class AppStatus {
        String name = "Dubai Play";
        boolean trialEnabled = true;
        int trialHours = 3;
        String loginBackground = "";
        String appLogo = "";
        String internalBackground = "";
        String supportWhatsapp = "";
        String accountTitle = "GREEN PLAY • SUA CENTRAL DE ENTRETENIMENTO";
        String aboutText = "";
        boolean showParental = true;
        boolean showFavorites = true;
        boolean showUpdate = true;
        boolean showClearCache = true;
        boolean showSupport = true;
        boolean showAbout = true;
    }

    static class LoginResult {
        String username = "";
        String expiresAt = "";
        String plan = "";
        int maxConnections = 1;
        boolean adultAccess = false;
        String bouquet = "";
        String userToken = "";
        String adultPin = "";
        String xtreamPassword = "";
    }

    static class StreamProbe {
        String format = "auto";
        String contentType = "";
        int httpCode = 0;
        String userAgent = "";
    }

    static class ResolvedStream {
        String url = "";
        String contentType = "";
        int httpCode = 0;
    }


    static void login(String username, String password, String device, Callback<LoginResult> cb) {
        IO.execute(() -> {
            try {
                String body = "username=" + URLEncoder.encode(username, "UTF-8")
                        + "&password=" + URLEncoder.encode(password, "UTF-8")
                        + "&device=" + URLEncoder.encode(device == null ? "" : device, "UTF-8");
                JSONObject root = new JSONObject(post(Config.API_BASE_URL + "login.php", body));
                if (!root.optBoolean("ok", false)) throw new Exception(clean(root.optString("message", "Acesso negado"), "Acesso negado"));
                LoginResult r = new LoginResult();
                r.username = clean(root.optString("username", username), username);
                r.expiresAt = clean(root.optString("expires_at", ""), "");
                r.plan = clean(root.optString("plan", ""), "");
                r.maxConnections = root.optInt("max_connections", 1);
                r.adultAccess = root.optBoolean("adult_access", false);
                r.bouquet = clean(root.optString("bouquet", ""), "");
                r.userToken = clean(root.optString("user_token", ""), "");
                r.adultPin = clean(root.optString("adult_pin", ""), "");
                r.xtreamPassword = clean(root.optString("xtream_password", password), password);
                setUserToken(r.userToken); setXtreamServer(xtreamRoot(),r.username,r.xtreamPassword);
                cb.ok(r);
            } catch (Exception e) { cb.error(message(e)); }
        });
    }

    static void statusInfo(Callback<AppStatus> cb) {
        IO.execute(() -> {
            try {
                JSONObject o = new JSONObject(request(Config.API_BASE_URL + "status.php", false));
                AppStatus st = new AppStatus();
                st.name = clean(o.optString("name","Dubai Play"),"Dubai Play");
                st.trialEnabled = o.optBoolean("trial_enabled", true);
                st.trialHours = Math.max(1, o.optInt("trial_hours", 3));
                st.loginBackground = absoluteAssetUrl(o.optString("login_background",""));
                st.appLogo = absoluteAssetUrl(o.optString("app_logo",""));
                st.internalBackground = absoluteAssetUrl(
                        o.optString("app_background",
                                o.optString("internal_background","")));
                cb.ok(st);
            } catch (Exception e) { cb.error(message(e)); }
        });
    }

    static void trial(String device, Callback<LoginResult> cb) {
        IO.execute(() -> {
            try {
                String body = "device=" + URLEncoder.encode(device == null ? "" : device, "UTF-8");
                JSONObject root = new JSONObject(post(Config.API_BASE_URL + "trial.php", body));
                if (!root.optBoolean("ok", false)) throw new Exception(clean(root.optString("message", "Teste indisponível"), "Teste indisponível"));
                LoginResult r = new LoginResult();
                r.username = clean(root.optString("username", "Teste"), "Teste");
                r.expiresAt = clean(root.optString("expires_at", ""), "");
                r.plan = clean(root.optString("plan", "Teste automático"), "Teste automático");
                r.maxConnections = root.optInt("max_connections", 1);
                r.adultAccess = root.optBoolean("adult_access", false);
                r.bouquet = clean(root.optString("bouquet", "Sem Adulto"), "Sem Adulto");
                r.userToken = clean(root.optString("user_token", ""), "");
                r.adultPin = clean(root.optString("adult_pin", ""), "");
                r.xtreamPassword = clean(root.optString("xtream_password", ""), "");
                setUserToken(r.userToken); setXtreamServer(xtreamRoot(),r.username,r.xtreamPassword);
                cb.ok(r);
            } catch (Exception e) { cb.error(message(e)); }
        });
    }

    static void status(Callback<String> cb) {
        IO.execute(() -> {
            try {
                JSONObject o = new JSONObject(request(Config.API_BASE_URL + "status.php", false));
                cb.ok(o.optString("name", "Dubai Play"));
            } catch (Exception e) { cb.error(message(e)); }
        });
    }

    static void home(Callback<HomeData> cb) {
        final HomeData h=new HomeData();
        final java.util.concurrent.atomic.AtomicInteger pending=new java.util.concurrent.atomic.AtomicInteger(3);
        final String[] error={""};

        Callback<CatalogPage> doneLive=new Callback<CatalogPage>(){
            public void ok(CatalogPage p){if(p!=null){h.liveCount=p.total;h.live.addAll(p.items);}finishHome();}
            public void error(String m){error[0]=m;finishHome();}
            private void finishHome(){if(pending.decrementAndGet()==0){h.hero=!h.movies.isEmpty()?h.movies.get(0):(!h.series.isEmpty()?h.series.get(0):(!h.live.isEmpty()?h.live.get(0):null));cb.ok(h);}}
        };
        Callback<CatalogPage> doneMovie=new Callback<CatalogPage>(){
            public void ok(CatalogPage p){if(p!=null){h.movieCount=p.total;h.movies.addAll(p.items);}finishHome();}
            public void error(String m){error[0]=m;finishHome();}
            private void finishHome(){if(pending.decrementAndGet()==0){h.hero=!h.movies.isEmpty()?h.movies.get(0):(!h.series.isEmpty()?h.series.get(0):(!h.live.isEmpty()?h.live.get(0):null));cb.ok(h);}}
        };
        Callback<CatalogPage> doneSeries=new Callback<CatalogPage>(){
            public void ok(CatalogPage p){if(p!=null){h.seriesCount=p.total;h.series.addAll(p.items);}finishHome();}
            public void error(String m){error[0]=m;finishHome();}
            private void finishHome(){if(pending.decrementAndGet()==0){h.hero=!h.movies.isEmpty()?h.movies.get(0):(!h.series.isEmpty()?h.series.get(0):(!h.live.isEmpty()?h.live.get(0):null));cb.ok(h);}}
        };
        catalog("live",1,16,"","","",doneLive);
        catalog("movie",1,16,"","","",doneMovie);
        catalog("series",1,16,"","","",doneSeries);
    }

    static void catalog(String type, int page, int limit, String search, Callback<CatalogPage> cb) {
        catalog(type, page, limit, search, "", "", cb);
    }

    static void catalog(String type, int page, int limit, String search, String category, String smart, Callback<CatalogPage> cb) {
        catalogInternal(type,page,limit,search,category,smart,-1,cb);
    }

    /**
     * Abre imediatamente o catálogo que já foi preparado no login.
     * Se não houver cache válido, consulta o painel normalmente.
     */
    static void catalogPrepared(String type,int page,int limit,String search,String category,String smart,Callback<CatalogPage> cb){
        // V4.1.4: catálogo sempre consulta o servidor atual.
        // Cache de imagem continua separado no ImageLoader.
        catalog(type,page,limit,search,category,smart,cb);
    }

    /** HOT com identidade real da categoria no painel: fonte + nome da categoria. */
    static void catalogAdult(String type, int page, int limit, String category, int sourceId, Callback<CatalogPage> cb) {
        catalogInternal(type,page,limit,"",category,"adult",sourceId,cb);
    }

    /** Abre o HOT já preparado na entrada; se ainda não existir snapshot, consulta o painel. */
    static void catalogAdultPrepared(String type,int page,int limit,String category,int sourceId,Callback<CatalogPage> cb){
        catalogAdult(type,page,limit,category,sourceId,cb);
    }

    private static void catalogInternal(String type, int page, int limit, String search, String category, String smart, int sourceId, Callback<CatalogPage> cb) {
        IO.execute(() -> {
            try {
                if (XTREAM_USER.isEmpty() || XTREAM_PASSWORD.isEmpty()) throw new Exception("Credenciais Xtream ausentes");
                final String t=clean(type,"movie").toLowerCase(java.util.Locale.ROOT);
                java.util.LinkedHashMap<String,String> cats=sessionCategoryMap(t);
                java.util.List<Item> base=sessionItems(t,cats);

                java.util.List<Item> filtered=new ArrayList<>();
                String q=clean(search,"").trim().toLowerCase(java.util.Locale.ROOT);
                String wanted=clean(category,"").trim();
                String smartMode=clean(smart,"").trim().toLowerCase(java.util.Locale.ROOT);

                for(Item it:base){
                    if(it==null)continue;
                    if(!wanted.isEmpty() && !clean(it.group,"").equalsIgnoreCase(wanted))continue;
                    if(!q.isEmpty() && !clean(it.name,"").toLowerCase(java.util.Locale.ROOT).contains(q))continue;
                    if(!smartMode.isEmpty()){
                        String g=clean(it.group,"");
                        if("adult".equals(smartMode)){
                            String ng=CatalogModeRules.n(g);
                            if(!(ng.contains("adult")||ng.contains("xxx")||ng.contains("+18")||ng.contains("18+")||ng.contains("hot")||ng.contains("onlyfans")||ng.contains("porno")))continue;
                        }
                        if("kids".equals(smartMode) && !CatalogModeRules.kidsCategory(g))continue;
                        if("anime".equals(smartMode) && !CatalogModeRules.animeCategory(g))continue;
                    }
                    filtered.add(it);
                }

                int per=Math.max(12,Math.min(72,limit));
                int pg=Math.max(1,page), total=filtered.size();
                int from=Math.min(total,(pg-1)*per), to=Math.min(total,from+per);
                CatalogPage out=new CatalogPage();
                out.page=pg;out.total=total;out.pages=Math.max(1,(int)Math.ceil(total/(double)per));
                for(int i=from;i<to;i++)out.items.add(filtered.get(i));
                for(String n:cats.keySet())out.categories.add(titleCaseCategory(n));
                cb.ok(out);
            } catch(Exception e){ cb.error(message(e)); }
        });
    }

    private static java.util.LinkedHashMap<String,String> sessionCategoryMap(String type) throws Exception {
        java.util.LinkedHashMap<String,String> cached=SESSION_CATEGORIES.get(type);
        if(cached!=null)return cached;
        Object lock=SESSION_LOCKS.computeIfAbsent("cat:"+type,k->new Object());
        synchronized(lock){
            cached=SESSION_CATEGORIES.get(type);
            if(cached!=null)return cached;
            cached=xtreamCategoryMap(type);
            SESSION_CATEGORIES.put(type,cached);
            return cached;
        }
    }

    private static java.util.List<Item> sessionItems(String type, java.util.LinkedHashMap<String,String> cats) throws Exception {
        java.util.List<Item> cached=SESSION_ITEMS.get(type);
        if(cached!=null)return cached;
        Object lock=SESSION_LOCKS.computeIfAbsent("items:"+type,k->new Object());
        synchronized(lock){
            cached=SESSION_ITEMS.get(type);
            if(cached!=null)return cached;
            String action="live".equalsIgnoreCase(type)?"get_live_streams":("series".equalsIgnoreCase(type)?"get_series":"get_vod_streams");
            JSONArray ar=new JSONArray(request(xtreamApiUrl(action),false));
            ArrayList<Item> all=new ArrayList<>(ar.length());

            for(int i=0;i<ar.length();i++){
                JSONObject o=ar.optJSONObject(i);if(o==null)continue;
                Item it=new Item();
                if("series".equalsIgnoreCase(type)){
                    it.id=o.optLong("series_id");
                    it.type="series";
                    it.logo=clean(o.optString("cover",""),"");
                    it.backdrop=firstJsonString(o.optJSONArray("backdrop_path"));
                    it.synopsis=clean(o.optString("plot",""),"");
                    XTREAM_SERIES_IDS.put(clean(o.optString("name",""),"").trim().toLowerCase(java.util.Locale.ROOT),it.id);
                }else{
                    it.id=o.optLong("stream_id");
                    it.type="live".equalsIgnoreCase(type)?"live":"movie";
                    it.logo=clean(o.optString("stream_icon",""),"");
                    it.format=clean(o.optString("container_extension","live".equalsIgnoreCase(type)?"ts":"mp4"),"live".equalsIgnoreCase(type)?"ts":"mp4");
                }
                if(it.id<=0)continue;
                it.name=clean(o.optString("name",o.optString("title","")),"Sem nome");
                it.year=parseYear(o.optString("year",""));
                String cid=clean(o.optString("category_id",""),"");
                it.group=categoryNameById(cats,cid);
                all.add(it);
            }
            SESSION_ITEMS.put(type,all);
            return all;
        }
    }

    private static String xtreamApiUrl(String action) throws Exception {
        return xtreamRoot()+"/player_api.php?username="+URLEncoder.encode(XTREAM_USER,"UTF-8")+"&password="+URLEncoder.encode(XTREAM_PASSWORD,"UTF-8")+"&action="+URLEncoder.encode(action,"UTF-8");
    }
    private static java.util.LinkedHashMap<String,String> xtreamCategoryMap(String type) throws Exception {
        String action="live".equalsIgnoreCase(type)?"get_live_categories":("series".equalsIgnoreCase(type)?"get_series_categories":"get_vod_categories");
        JSONArray a=new JSONArray(request(xtreamApiUrl(action),false));
        java.util.LinkedHashMap<String,String> out=new java.util.LinkedHashMap<>();
        for(int i=0;i<a.length();i++){
            JSONObject o=a.optJSONObject(i); if(o==null)continue;
            String name=clean(o.optString("category_name",""),""); String id=clean(o.optString("category_id",""),"");
            if(name.isEmpty()||id.isEmpty())continue;
            out.put(name.trim().toLowerCase(java.util.Locale.ROOT),id);
            XTREAM_CATEGORY_IDS.put(type+"|"+name.trim().toLowerCase(java.util.Locale.ROOT),id);
        }
        return out;
    }
    private static String categoryNameById(java.util.LinkedHashMap<String,String> cats,String id){
        for(java.util.Map.Entry<String,String> e:cats.entrySet())if(e.getValue().equals(id)){
            String key=e.getKey(); for(String s:key.split(" ")){} return titleCaseCategory(key);
        }
        return "";
    }
    private static String titleCaseCategory(String s){
        if(s==null)return ""; StringBuilder b=new StringBuilder(); boolean up=true;
        for(char c:s.toCharArray()){ if(up&&Character.isLetter(c)){b.append(Character.toUpperCase(c));up=false;}else b.append(c); if(Character.isWhitespace(c))up=true; }
        return b.toString();
    }
    private static String firstJsonString(JSONArray a){ return a!=null&&a.length()>0?clean(a.optString(0,""),""):""; }
    private static int parseYear(String y){ try{return Integer.parseInt(y.replaceAll("[^0-9]","").substring(0,4));}catch(Exception e){return 0;} }

    static void invalidateCatalog(String type,int page,int limit,String search,String category,String smart){
        String k=catalogCacheKey(type,page,limit,search,category,smart);
        CATALOG_CACHE.remove(k);
        PersistentContentCache.removeCatalog(k);
    }

    private static String defaultSnapshotKey(String type){
        String sessionKey = USER_TOKEN == null ? "" : Integer.toHexString(USER_TOKEN.hashCode());
        return "default_"+sessionKey+"_"+clean(type,"");
    }

    private static String adultCatalogCacheKey(String type,int page,int limit,String category,int sourceId){
        String sessionKey = USER_TOKEN == null ? "" : Integer.toHexString(USER_TOKEN.hashCode());
        return sessionKey+"|adult|"+clean(type,"")+"|"+Math.max(1,page)+"|"+Math.max(12,Math.min(72,limit))+"|"+clean(category,"")+"|"+sourceId;
    }

    private static String catalogCacheKey(String type,int page,int limit,String search,String category,String smart){
        // O token participa da chave: catálogos de clientes/bouquets diferentes
        // nunca podem compartilhar a mesma entrada de cache.
        String sessionKey = USER_TOKEN == null ? "" : Integer.toHexString(USER_TOKEN.hashCode());
        return sessionKey+"|"+clean(type,"")+"|"+Math.max(1,page)+"|"+Math.max(12,Math.min(72,limit))+"|"+clean(search,"")+"|"+clean(category,"")+"|"+clean(smart,"");
    }

    static void warmCatalog(String type,int page,int limit,String search,String category,String smart){
        catalog(type,page,limit,search,category,smart,new Callback<CatalogPage>(){
            @Override public void ok(CatalogPage p){
                if(p==null)return;
                // Filmes devem chegar completos do painel: capa, backdrop, sinopse,
                // ano e TMDB já gravados no catálogo. Não fazemos consulta TMDB
                // por card durante a navegação.
                if("movie".equals(type)) return;

                int max=Math.min(p.items.size(),12);
                for(int n=0;n<max;n++){
                    Item i=p.items.get(n);
                    if(i==null||i.tmdbLoaded||!"series".equals(i.type))continue;
                    tmdbEnrich(i,new Callback<Item>(){ public void ok(Item x){} public void error(String m){} });
                }
            }
            @Override public void error(String m){}
        });
    }

    static class HotCategory {
        String name = "";
        String cover = "";
        int count = 0;
        int liveCount = 0;
        int movieCount = 0;
        int seriesCount = 0;
        int sourceId = 0;
        String sourceName = "";
    }

    static void hotCategories(Callback<List<HotCategory>> cb) {
        // A API/painel é a fonte da verdade. O APK não inventa nomes, fontes ou categorias.
        // Sem cache persistente: qualquer categoria HOT adicionada/removida no painel aparece
        // na próxima abertura desta tela, sem recompilar o aplicativo.
        IO.execute(() -> {
            try {
                java.util.LinkedHashMap<String,HotCategory> map=new java.util.LinkedHashMap<>();

                // Endpoint oficial: uma entrada por categoria adulta real.
                try {
                    JSONObject root = new JSONObject(request(Config.API_BASE_URL + "hot_categories.php?_=" + System.currentTimeMillis(), true));
                    JSONArray a = root.optJSONArray("categories");
                    if(a!=null) for(int i=0;i<a.length();i++){
                        JSONObject o=a.optJSONObject(i); if(o==null) continue;
                        String name=clean(o.optString("name",""),""); if(name.isEmpty())continue;
                        int sid=o.optInt("source_id",0);
                        // V201: a identidade da categoria no painel é fonte + nome.
                        // Não juntar duas fontes com o mesmo nome, pois cada uma pode ter
                        // sua própria capa/logo configurada no painel.
                        String key=sid+"|"+name.trim().toLowerCase(java.util.Locale.ROOT);
                        HotCategory h=map.get(key);
                        if(h==null){h=new HotCategory();h.name=name;h.sourceId=sid;map.put(key,h);}
                        String cover=clean(o.optString("cover",""),"");
                        if(h.cover.isEmpty()&&!cover.isEmpty())h.cover=cover;
                        h.sourceId=sid;
                        h.sourceName=clean(o.optString("source_name",""),"");
                        h.count=Math.max(h.count,o.optInt("count",0));
                        h.liveCount=Math.max(h.liveCount,o.optInt("live",0));
                        h.movieCount=Math.max(h.movieCount,o.optInt("movie",0));
                        h.seriesCount=Math.max(h.seriesCount,o.optInt("series",0));
                    }
                } catch(Exception ignored) {}

                // Fallback compatível com painéis antigos: usa SOMENTE group_title retornado
                // pelo catálogo adulto. Nunca transforma source_name em categoria.
                if(map.isEmpty()){
                    String[] types={"movie","series"};
                    for(String type:types){
                        try{
                            String url=Config.API_BASE_URL+"catalog.php?type="+type+"&page=1&limit=100&smart=adult&_="+System.currentTimeMillis();
                            JSONObject r=new JSONObject(request(url,true));
                            JSONArray items=r.optJSONArray("items");
                            if(items==null)continue;
                            for(int i=0;i<items.length();i++){
                                JSONObject o=items.optJSONObject(i); if(o==null)continue;
                                String group=clean(o.optString("group_title",o.optString("group","")),"");
                                if(group.isEmpty())continue;
                                int sid=o.optInt("source_id",0);
                                String key=sid+"|"+group.trim().toLowerCase(java.util.Locale.ROOT);
                                HotCategory h=map.get(key);
                                if(h==null){h=new HotCategory();h.name=group;h.sourceId=sid;map.put(key,h);}
                                String art=clean(o.optString("backdrop",o.optString("backdrop_url","")),"");
                                if(art.isEmpty())art=clean(o.optString("logo",""),"");
                                if(h.cover.isEmpty()&&!art.isEmpty())h.cover=art;
                                h.count++;
                                if("live".equals(type))h.liveCount++; else if("movie".equals(type))h.movieCount++; else h.seriesCount++;
                            }
                        }catch(Exception ignored){}
                    }
                }

                List<HotCategory> out=new ArrayList<>(map.values());
                if(out.isEmpty()) throw new Exception("Nenhuma categoria HOT retornada pelo painel");
                cb.ok(out);
            } catch(Exception e){ cb.error(message(e)); }
        });
    }

    static void categories(String type, Callback<List<String>> cb) {
        IO.execute(() -> {
            try{
                java.util.LinkedHashMap<String,String> cats=sessionCategoryMap(clean(type,"movie").toLowerCase(java.util.Locale.ROOT));
                List<String> out=new ArrayList<>();
                for(String n:cats.keySet())out.add(titleCaseCategory(n));
                cb.ok(out);
            }catch(Exception e){cb.error(message(e));}
        });
    }

    private static String categoriesCacheKey(String type){
        String sessionKey=USER_TOKEN==null?"":Integer.toHexString(USER_TOKEN.hashCode());
        String serverKey=xtreamRoot()==null?"":Integer.toHexString(xtreamRoot().hashCode());
        return "categories_"+serverKey+"_"+sessionKey+"_"+clean(type,"");
    }

    static void categoriesPrepared(String type, Callback<List<String>> cb){
        // V4.1.4: servidor atual é a fonte da verdade; não usa categoria persistida antiga.
        categories(type,cb);
    }

    static void sections(Callback<List<Section>> cb) {
        IO.execute(() -> {
            try {
                JSONObject root = new JSONObject(request(Config.API_BASE_URL + "sections.php", true));
                JSONArray a = root.optJSONArray("sections");
                List<Section> out = new ArrayList<>();
                if (a != null) for (int i=0;i<a.length();i++) {
                    JSONObject o = a.optJSONObject(i); if (o == null) continue;
                    Section s = new Section();
                    s.title = clean(o.optString("title", ""), "Categoria");
                    s.subtitle = clean(o.optString("subtitle", ""), "");
                    s.type = clean(o.optString("type", "live"), "live");
                    s.category = clean(o.optString("category", ""), "");
                    s.smart = clean(o.optString("smart", ""), "");
                    s.action = clean(o.optString("action", "catalog"), "catalog");
                    s.count = o.optInt("count", 0);
                    out.add(s);
                }
                cb.ok(out);
            } catch (Exception e) { cb.error(message(e)); }
        });
    }

    static void football(Callback<List<FootballMatch>> cb) {
        IO.execute(() -> {
            try {
                JSONObject root = new JSONObject(request(Config.API_BASE_URL + "football.php", true));
                JSONArray a = root.optJSONArray("matches");
                List<FootballMatch> out = new ArrayList<>();
                if (a != null) for (int i=0;i<a.length();i++) {
                    JSONObject o = a.optJSONObject(i); if (o == null) continue;
                    FootballMatch m = new FootballMatch();
                    m.league = clean(o.optString("league", ""), "Futebol");
                    m.home = clean(o.optString("home", ""), "Casa");
                    m.away = clean(o.optString("away", ""), "Fora");
                    m.homeLogo = clean(o.optString("home_logo", ""), "");
                    m.awayLogo = clean(o.optString("away_logo", ""), "");
                    m.status = clean(o.optString("status", ""), "Agendado");
                    m.clock = clean(o.optString("clock", ""), "");
                    m.score = clean(o.optString("score", ""), "");
                    m.date = clean(o.optString("date", ""), "");
                    out.add(m);
                }
                cb.ok(out);
            } catch (Exception e) { cb.error(message(e)); }
        });
    }

    static void series(String title, Callback<SeriesData> cb) {
        final String key=seriesCacheKey(title);
        IO.execute(() -> {
            try {
                Long sid=XTREAM_SERIES_IDS.get(clean(title,"").trim().toLowerCase(java.util.Locale.ROOT));
                if(sid==null||sid<=0){
                    JSONArray all=new JSONArray(request(xtreamApiUrl("get_series"),false));
                    for(int i=0;i<all.length();i++){JSONObject o=all.optJSONObject(i);if(o==null)continue;String n=clean(o.optString("name",""),"");long x=o.optLong("series_id");XTREAM_SERIES_IDS.put(n.trim().toLowerCase(java.util.Locale.ROOT),x);if(n.equalsIgnoreCase(title))sid=x;}
                }
                if(sid==null||sid<=0)throw new Exception("Série não encontrada");
                JSONObject root=new JSONObject(request(xtreamApiUrl("get_series_info")+"&series_id="+sid,false));
                SeriesData out=new SeriesData(); JSONObject info=root.optJSONObject("info");
                out.title=info!=null?clean(info.optString("name",title),title):title;
                out.logo=info!=null?clean(info.optString("cover",""),""):""; out.synopsis=info!=null?clean(info.optString("plot",""),""):"";
                out.backdrop=info!=null?firstJsonString(info.optJSONArray("backdrop_path")):""; out.year=info!=null?parseYear(info.optString("year","")):0;
                JSONObject eps=root.optJSONObject("episodes"); if(eps!=null){java.util.Iterator<String> ks=eps.keys();while(ks.hasNext()){String sn=ks.next();Season season=new Season();try{season.number=Integer.parseInt(sn);}catch(Exception e){season.number=0;}JSONArray ea=eps.optJSONArray(sn);if(ea!=null)for(int i=0;i<ea.length();i++){JSONObject o=ea.optJSONObject(i);if(o==null)continue;Item it=new Item();it.id=o.optLong("id");it.name=clean(o.optString("title","Episódio"),"Episódio");it.type="episode";it.format=clean(o.optString("container_extension","mp4"),"mp4");it.seasonNumber=o.optInt("season",season.number);it.episodeNumber=o.optInt("episode_num",i+1);JSONObject ii=o.optJSONObject("info");if(ii!=null){it.logo=clean(ii.optString("movie_image",""),"");it.synopsis=clean(ii.optString("plot",""),"");}season.episodes.add(it);}out.seasons.add(season);}}
                SERIES_CACHE.put(key,out); cb.ok(out);
            } catch(Exception e){ cb.error(message(e)); }
        });
    }

    /** Abre a série imediatamente do cache. A primeira abertura busca no painel e salva. */
    static void seriesPrepared(String title, Callback<SeriesData> cb){
        series(title,cb);
    }

    /** Pré-aquece detalhes/episódios sem bloquear nenhuma tela. */
    static void warmSeries(String title){
        if(title==null || title.trim().isEmpty())return;
        final String key=seriesCacheKey(title);
        if(SERIES_CACHE.containsKey(key))return;
        try{
            JSONObject root=PersistentContentCache.getSeries(key);
            if(root!=null){
                SeriesData saved=parseSeriesData(root,title);
                if(saved!=null && !saved.seasons.isEmpty()){
                    SERIES_CACHE.put(key,saved);
                    return;
                }
            }
        }catch(Exception ignored){}
        series(title,new Callback<SeriesData>(){ public void ok(SeriesData x){} public void error(String m){} });
    }

    private static String seriesCacheKey(String title){
        String sessionKey=USER_TOKEN==null?"":Integer.toHexString(USER_TOKEN.hashCode());
        return sessionKey+"|series|"+clean(title,"").trim().toLowerCase(java.util.Locale.ROOT);
    }

    private static SeriesData parseSeriesData(JSONObject root,String fallbackTitle){
        SeriesData out = new SeriesData();
        if(root==null)return out;
        out.title = clean(root.optString("title", fallbackTitle), fallbackTitle);
        out.logo = clean(root.optString("logo", ""), "");
        out.backdrop = clean(root.optString("backdrop", ""), "");
        out.synopsis = clean(root.optString("synopsis", ""), "");
        out.group = clean(root.optString("group_title", ""), "");
        out.year = root.optInt("release_year", 0);
        JSONArray seasons = root.optJSONArray("seasons");
        if (seasons != null) {
            for (int i=0;i<seasons.length();i++) {
                JSONObject s = seasons.optJSONObject(i); if (s == null) continue;
                Season season = new Season();
                season.number = s.optInt("season", 0);
                parseArray(s.optJSONArray("episodes"), season.episodes, "series");
                out.seasons.add(season);
            }
        }
        return out;
    }

    static void details(long id, Callback<Item> cb) {
        IO.execute(() -> {
            try {
                JSONObject root=new JSONObject(request(xtreamApiUrl("get_vod_info")+"&vod_id="+id,false));
                JSONObject info=root.optJSONObject("info");
                JSONObject md=root.optJSONObject("movie_data");
                Item item=new Item();
                item.id=id; item.type="movie"; item.format=md!=null?clean(md.optString("container_extension","mp4"),"mp4"):"mp4";
                item.name=info!=null?clean(info.optString("name",info.optString("o_name","")),"Filme"):"Filme";
                item.logo=info!=null?clean(info.optString("movie_image",info.optString("cover_big","")),""):"";
                item.backdrop=info!=null?firstJsonString(info.optJSONArray("backdrop_path")):"";
                item.synopsis=info!=null?clean(info.optString("plot",info.optString("description","")),""):"";
                item.group=info!=null?clean(info.optString("genre",""),""):"";
                item.year=info!=null?parseYear(info.optString("year",info.optString("release_date",""))):0;
                cb.ok(item);
            } catch(Exception e){ cb.error(message(e)); }
        });
    }

    static void epg(long streamId, Callback<EpgInfo> cb) {
        IO.execute(() -> {
            try {
                JSONObject root=new JSONObject(request(xtreamApiUrl("get_short_epg")+"&stream_id="+streamId+"&limit=4",false));
                JSONArray a=root.optJSONArray("epg_listings"); EpgInfo info=new EpgInfo();
                if(a!=null&&a.length()>0){JSONObject n=a.optJSONObject(0);if(n!=null){info.nowTitle=decodeMaybeBase64(clean(n.optString("title",""),""));info.nowStart=clean(n.optString("start",""),"");info.nowStop=clean(n.optString("end",""),"");}if(a.length()>1){JSONObject nx=a.optJSONObject(1);if(nx!=null){info.nextTitle=decodeMaybeBase64(clean(nx.optString("title",""),""));info.nextStart=clean(nx.optString("start",""),"");}}}
                cb.ok(info);
            } catch(Exception e){ cb.error(message(e)); }
        });
    }
    private static String decodeMaybeBase64(String s){try{if(s==null||s.isEmpty())return "";byte[] b=android.util.Base64.decode(s,android.util.Base64.DEFAULT);String x=new String(b,"UTF-8");return x.matches(".*[\\p{L}\\p{N}].*")?x:s;}catch(Exception e){return s;}}

    static void reportStreamFailure(long streamId) {
        IO.execute(() -> {
            try { request(Config.API_BASE_URL + "stream_failure.php?id=" + streamId + "&_=" + System.currentTimeMillis(), true); }
            catch (Exception ignored) {}
        });
    }

    static void probeStream(long streamId, Callback<StreamProbe> cb) {
        IO.execute(() -> {
            try {
                JSONObject root = new JSONObject(request(Config.API_BASE_URL + "stream_probe.php?id=" + streamId, true));
                StreamProbe p = new StreamProbe();
                p.format = clean(root.optString("format", "auto"), "auto");
                p.contentType = clean(root.optString("content_type", ""), "");
                p.httpCode = root.optInt("http_code", 0);
                p.userAgent = clean(root.optString("user_agent", ""), "");
                cb.ok(p);
            } catch (Exception e) { cb.error(message(e)); }
        });
    }

    static void resolveStream(long id, Callback<ResolvedStream> cb) {
        IO.execute(() -> {
            HttpURLConnection con = null;
            try {
                String current = streamUrl(id);
                String contentType = "";
                int code = 0;
                for (int hop=0; hop<6; hop++) {
                    URL u = new URL(current);
                    con = (HttpURLConnection) u.openConnection();
                    con.setInstanceFollowRedirects(false);
                    con.setConnectTimeout(8000); con.setReadTimeout(10000);
                    con.setRequestMethod("GET");
                    con.setRequestProperty("User-Agent", "DubaiPlayTV/2.2 Android");
                    con.setRequestProperty("Accept", "*/*");
                    con.setRequestProperty("Accept-Encoding", "identity");
                    con.setRequestProperty("Range", "bytes=0-1");
                    code = con.getResponseCode();
                    contentType = clean(con.getContentType(), "");
                    if (code>=300 && code<400) {
                        String loc = con.getHeaderField("Location");
                        con.disconnect(); con=null;
                        if (loc==null || loc.trim().isEmpty()) break;
                        current = new URL(u, loc).toString();
                        continue;
                    }
                    if (con!=null) { con.disconnect(); con=null; }
                    break;
                }
                ResolvedStream r = new ResolvedStream(); r.url=current; r.contentType=contentType; r.httpCode=code; cb.ok(r);
            } catch (Exception e) { if(con!=null)con.disconnect(); cb.error(message(e)); }
        });
    }

    static String xtreamRoot() {
        if(XTREAM_HOST!=null && !XTREAM_HOST.trim().isEmpty()) return XTREAM_HOST;
        try { URL base=new URL(Config.API_BASE_URL); return base.getProtocol()+"://"+base.getHost()+(base.getPort()>0?":"+base.getPort():""); }
        catch(Exception e){ return "https://dubaiplay.shop"; }
    }
    static String xtreamStreamUrl(long id,String kind,String format) {
        try {
            String k=clean(kind,"live"); if("episode".equals(k))k="series"; if(!"live".equals(k)&&!"movie".equals(k)&&!"series".equals(k))k="movie";
            String ext=clean(format,""); if(ext.isEmpty()||"auto".equals(ext)) ext="live".equals(k)?"ts":"mp4";
            return xtreamRoot()+"/"+k+"/"+URLEncoder.encode(XTREAM_USER,"UTF-8")+"/"+URLEncoder.encode(XTREAM_PASSWORD,"UTF-8")+"/"+id+"."+ext;
        } catch(Exception e){return "";}
    }
    static String streamUrl(long id) { return xtreamStreamUrl(id,"live","ts"); }



    private static CatalogPage parseCatalogPage(JSONObject root) {
        CatalogPage out = new CatalogPage();
        if(root==null)return out;
        out.page = root.optInt("page", 1);
        out.pages = root.optInt("pages", 1);
        out.total = root.optInt("total", 0);
        parseArray(root.optJSONArray("items"), out.items, root.optString("type", ""));
        JSONArray cats = root.optJSONArray("categories");
        if (cats != null) for (int i=0;i<cats.length();i++) { String x=cats.optString(i,""); if(!x.isEmpty())out.categories.add(x); }
        return out;
    }

    private static List<HotCategory> parseHotCategories(JSONArray a){
        List<HotCategory> out=new ArrayList<>();
        if(a!=null)for(int i=0;i<a.length();i++){
            JSONObject o=a.optJSONObject(i); if(o==null)continue;
            HotCategory h=new HotCategory(); h.name=clean(o.optString("name",""),""); h.cover=clean(o.optString("cover",""),"");
            h.sourceId=o.optInt("source_id",0);h.sourceName=clean(o.optString("source_name",""),"");
            h.count=o.optInt("count",0);h.liveCount=o.optInt("live",0);h.movieCount=o.optInt("movie",0);h.seriesCount=o.optInt("series",0);
            if(!h.name.isEmpty())out.add(h);
        }
        return out;
    }

    private static Item parseItem(JSONObject o) {
        if (o == null) return null;
        Item item = new Item();
        item.id = o.optLong("id"); item.name = clean(o.optString("name", ""), "Sem nome");
        item.logo = clean(o.optString("logo", ""), ""); item.backdrop = clean(o.optString("backdrop", o.optString("backdrop_url", "")), "");
        item.group = clean(o.optString("group_title", ""), ""); item.synopsis = clean(o.optString("synopsis", ""), "");
        item.sourceId = o.optInt("source_id", 0); item.sourceName = clean(o.optString("source_name", ""), ""); item.adult = o.optBoolean("is_adult", o.optInt("is_adult",0)==1);
        item.type = clean(o.optString("type", ""), ""); item.format = clean(o.optString("stream_format", "auto"), "auto");
        item.seriesTitle = clean(o.optString("series_title", ""), ""); item.year = o.optInt("release_year", 0);
        item.episodeCount = o.optInt("episode_count", 0); item.seasonCount = o.optInt("season_count", 0);
        item.seasonNumber = o.optInt("season_number", 0); item.episodeNumber = o.optInt("episode_number", 0);
        item.tmdbId = o.optInt("tmdb_id", 0);
        return item;
    }

    private static Item findSame(Item hero, List<Item> list) {
        if (hero == null || list == null) return null;
        for (Item i : list) {
            if (i == null) continue;
            if (hero.id > 0 && i.id == hero.id) return i;
            if (hero.name != null && i.name != null && hero.name.equalsIgnoreCase(i.name)) return i;
        }
        return null;
    }

    private static void parseArray(JSONArray a, List<Item> out, String type) {
        if (a == null) return;
        for (int i=0;i<a.length();i++) { Item item = parseItem(a.optJSONObject(i)); if (item != null) { if (item.type == null || item.type.isEmpty()) item.type = type; out.add(item); } }
    }


    static void tmdbEnrich(Item item, Callback<Item> cb) {
        if (item == null) { cb.error("Item inválido"); return; }
        IO.execute(() -> {
            try {
                String media = "series".equalsIgnoreCase(item.type) ? "tv" : "movie";
                JSONObject data;
                if (item.tmdbId > 0) {
                    String u = "https://api.themoviedb.org/3/" + media + "/" + item.tmdbId
                            + "?api_key=" + URLEncoder.encode(Config.TMDB_API_KEY, "UTF-8")
                            + "&language=pt-BR";
                    data = new JSONObject(request(u, false));
                } else {
                    String query = clean(item.name, clean(item.seriesTitle, ""));
                    if (query.isEmpty()) throw new Exception("Título não disponível");
                    StringBuilder u = new StringBuilder("https://api.themoviedb.org/3/search/")
                            .append(media).append("?api_key=")
                            .append(URLEncoder.encode(Config.TMDB_API_KEY, "UTF-8"))
                            .append("&language=pt-BR&include_adult=false&query=")
                            .append(URLEncoder.encode(query, "UTF-8"));
                    if (item.year > 0) {
                        if ("tv".equals(media)) u.append("&first_air_date_year=").append(item.year);
                        else u.append("&primary_release_year=").append(item.year);
                    }
                    JSONObject search = new JSONObject(request(u.toString(), false));
                    JSONArray results = search.optJSONArray("results");
                    if (results == null || results.length() == 0) throw new Exception("Sem resultado no TMDB");
                    data = results.optJSONObject(0);
                    if (data == null) throw new Exception("Sem resultado no TMDB");
                    item.tmdbId = data.optInt("id", item.tmdbId);
                }
                applyTmdb(item, data, media);
                item.tmdbLoaded = true;
                cb.ok(item);
            } catch (Exception e) { item.tmdbLoaded = true; cb.error(message(e)); }
        });
    }

    private static void applyTmdb(Item item, JSONObject data, String media) {
        if (item == null || data == null) return;
        String poster = clean(data.optString("poster_path", ""), "");
        String backdrop = clean(data.optString("backdrop_path", ""), "");
        if (!poster.isEmpty()) item.logo = Config.TMDB_IMAGE_POSTER + poster;
        if (!backdrop.isEmpty()) item.backdrop = Config.TMDB_IMAGE_BACKDROP + backdrop;
        String overview = clean(data.optString("overview", ""), "");
        if (!overview.isEmpty()) item.synopsis = overview;
        String title = "tv".equals(media) ? clean(data.optString("name", ""), "") : clean(data.optString("title", ""), "");
        if (!title.isEmpty()) item.name = title;
        String date = "tv".equals(media) ? clean(data.optString("first_air_date", ""), "") : clean(data.optString("release_date", ""), "");
        if (date.length() >= 4) {
            try { item.year = Integer.parseInt(date.substring(0, 4)); } catch (Exception ignored) {}
        }
        item.tmdbId = data.optInt("id", item.tmdbId);
    }

    private static String post(String url, String body) throws Exception {
        Exception last = null;
        for (int attempt=0; attempt<2; attempt++) {
            HttpURLConnection con = null;
            try {
                con = (HttpURLConnection) new URL(url).openConnection();
                con.setConnectTimeout(attempt==0?6500:9000);
                con.setReadTimeout(attempt==0?9000:14000);
                con.setInstanceFollowRedirects(true);
                con.setUseCaches(false);
                con.setRequestMethod("POST"); con.setDoOutput(true);
                con.setRequestProperty("Accept", "application/json");
                con.setRequestProperty("Accept-Encoding", "identity");
                con.setRequestProperty("Cache-Control", "no-cache, no-store");
                con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
                con.setRequestProperty("X-App-Token", Config.APP_TOKEN);
                con.setRequestProperty("User-Agent", "GreenPlay/6.0 AndroidTV");
                byte[] data = body.getBytes("UTF-8");
                con.setFixedLengthStreamingMode(data.length);
                java.io.OutputStream out = con.getOutputStream(); out.write(data); out.flush(); out.close();
                int code = con.getResponseCode();
                InputStream in = code >= 200 && code < 300 ? con.getInputStream() : con.getErrorStream();
                String bodyText = readBody(con, in);
                if (code == 401) throw new Exception("Aplicativo não autorizado no painel");
                if (code == 403) {
                    try { throw new Exception(new JSONObject(bodyText).optString("message", "Acesso bloqueado")); }
                    catch(org.json.JSONException ignored){ throw new Exception("Acesso bloqueado"); }
                }
                if (code < 200 || code >= 300) {
                    String m="Servidor respondeu HTTP "+code;
                    try { String x=new JSONObject(bodyText).optString("message",""); if(!x.isEmpty())m=x; } catch(Exception ignored){}
                    throw new Exception(m);
                }
                if(bodyText==null || bodyText.trim().isEmpty()) throw new Exception("Servidor respondeu vazio");
                return bodyText;
            } catch (java.net.SocketTimeoutException e) {
                last = new Exception(attempt==0?"Servidor demorou para criar o acesso":"Timeout ao criar acesso");
                if(attempt==0){ try{Thread.sleep(250);}catch(InterruptedException ignored){} continue; }
            } catch (Exception e) { last=e; break; }
            finally { if(con!=null)con.disconnect(); }
        }
        throw last==null?new Exception("Falha de conexão"):last;
    }

    private static String request(String url, boolean authenticated) throws Exception {
        Exception last = null;
        for (int attempt=0; attempt<2; attempt++) {
            HttpURLConnection con = null;
            try {
                con = (HttpURLConnection) new URL(url).openConnection();
                con.setConnectTimeout(attempt==0?6500:9500); con.setReadTimeout(attempt==0?14000:22000); con.setInstanceFollowRedirects(true);
                con.setUseCaches(false);
                con.setRequestProperty("Cache-Control", "no-cache, no-store, max-age=0");
                con.setRequestProperty("Pragma", "no-cache");
                con.setRequestProperty("Accept", "application/json"); con.setRequestProperty("Accept-Encoding", "identity"); con.setRequestProperty("Connection", "keep-alive");
                con.setRequestProperty("User-Agent", "DubaiPlayTV/2.2 Android");
                if (authenticated) {
                    con.setRequestProperty("X-App-Token", Config.APP_TOKEN);
                    if (!USER_TOKEN.isEmpty()) con.setRequestProperty("X-User-Token", USER_TOKEN);
                }
                int code = con.getResponseCode(); InputStream in = code >= 200 && code < 300 ? con.getInputStream() : con.getErrorStream();
                String bodyText = readBody(con, in);
                if (code == 401) throw new Exception("Aplicativo não autorizado no painel");
                if (code >= 500 && attempt == 0) { try { Thread.sleep(350); } catch (InterruptedException ignored) {} continue; }
                if (code < 200 || code >= 300) throw new Exception("Servidor respondeu HTTP " + code);
                if (bodyText == null || bodyText.trim().isEmpty()) throw new Exception("Servidor respondeu vazio");
                return bodyText;
            } catch (java.net.SocketTimeoutException e) {
                last = new Exception(attempt==0 ? "Servidor demorou para responder" : "Timeout do servidor");
                if (attempt==0) { try { Thread.sleep(300); } catch (InterruptedException ignored) {} continue; }
            } catch (Exception e) { last=e; if(attempt==0 && (e instanceof java.io.IOException)){ try { Thread.sleep(300); } catch (InterruptedException ignored) {} continue; } break; }
            finally { if(con!=null) con.disconnect(); }
        }
        throw last == null ? new Exception("Falha de conexão") : last;
    }

    private static String readBody(HttpURLConnection con, InputStream in) throws Exception {
        if (in == null) return "";
        String enc = con.getHeaderField("Content-Encoding");
        InputStream decoded = in;
        if (enc != null && enc.toLowerCase(java.util.Locale.US).contains("gzip")) decoded = new GZIPInputStream(in);
        BufferedReader br = new BufferedReader(new InputStreamReader(decoded, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        String text = sb.toString().trim();
        // Alguns proxies devolvem BOM antes do JSON.
        if (text.startsWith("\uFEFF")) text = text.substring(1);
        return text;
    }

    private static String clean(String value, String fallback) { if (value == null) return fallback; String s = value.trim(); return s.isEmpty() || "null".equalsIgnoreCase(s) ? fallback : s; }
    private static String message(Exception e) { String m = e.getMessage(); return m == null || m.trim().isEmpty() ? "Falha de conexão" : m; }
}
