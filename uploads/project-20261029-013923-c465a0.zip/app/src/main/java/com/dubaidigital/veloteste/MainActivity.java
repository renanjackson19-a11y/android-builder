package com.dubaidigital.veloteste;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.widget.*;
import android.net.Uri;
import org.json.*;
import java.net.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    private static final String CATALOG="https://megaunitv.oficiall.sbs/api/mobile/catalog.php";
    private static final String PROVIDER="https://megaunitv.oficiall.sbs/api/mobile/provider.php";
    private LinearLayout root, content;
    private VideoView player;
    private final int white=Color.WHITE;
    @Override public void onCreate(Bundle state) {super.onCreate(state);home();}
    private TextView text(String value,int size){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(white);t.setPadding(18,14,18,14);return t;}
    private Button button(String label,View.OnClickListener action){Button b=new Button(this);b.setText(label);b.setOnClickListener(action);return b;}
    private void base(String title){root=new LinearLayout(this);root.setOrientation(1);root.setPadding(16,26,16,12);root.setBackgroundColor(Color.rgb(14,19,31));setContentView(root);root.addView(text(title,24));content=new LinearLayout(this);content.setOrientation(1);ScrollView sc=new ScrollView(this);sc.addView(content);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));}
    private void home(){base("Velo Teste • Integração experimental");content.addView(text("Consulta automática às APIs configuradas no Mega como fonte 'velo'. Não há garantia de acesso ao catálogo.",15));content.addView(button("Canais",v->load("canais")));content.addView(button("Filmes",v->load("filmes")));content.addView(button("Séries",v->load("series")));content.addView(button("Verificar API do provedor",v->checkProvider()));content.addView(button("Diagnosticar HTTP 405",v->diagnose()));}
    private void load(String category){base(category.toUpperCase(Locale.ROOT));content.addView(button("← Início",v->home()));TextView status=text("Consultando catálogo...",16);content.addView(status);request(CATALOG,(code,body,error)->{status.setText(error!=null?"Falha de conexão: "+error:("POST HTTP "+code));if(error!=null)return;if(code==401||code==403){content.addView(text("Servidor exige autorização. Não foi feita tentativa de contornar o acesso.",15));return;}if(code<200||code>=300){content.addView(text(code==405?"POST não foi aceito nesta rota. Confira o protocolo e os parâmetros exigidos pelo servidor.":"API não retornou catálogo utilizável. HTTP "+code+". "+validationHint(body),15));return;}try{Object json=new JSONTokener(body).nextValue();ArrayList<JSONObject> entries=new ArrayList<>();collect(json,entries,0);int shown=0;for(JSONObject item:entries){String title=first(item,"name","title","channel_name","vod_name","series_name");if(title.isEmpty())continue;String type=first(item,"type","category","content_type").toLowerCase(Locale.ROOT);if(!type.isEmpty()&&!matches(type,category))continue;String stream=first(item,"stream_url","play_url","url","video_url","stream");content.addView(button(title,v->{if(stream.startsWith("https://"))play(title,stream);else Toast.makeText(this,"Item sem endereço de reprodução disponível",Toast.LENGTH_LONG).show();}));shown++;if(shown>=150)break;}if(shown==0)content.addView(text("Resposta recebida, mas nenhum item compatível foi identificado. O formato da API pode exigir integração específica.",15));else status.setText("HTTP "+code+" • "+shown+" itens encontrados");}catch(Exception e){content.addView(text("Resposta recebida, mas não é um catálogo JSON compatível.",15));}});}
    private boolean matches(String type,String cat){if(cat.equals("canais"))return type.contains("live")||type.contains("channel")||type.contains("canal")||type.contains("tv");if(cat.equals("filmes"))return type.contains("movie")||type.contains("film")||type.contains("vod");return type.contains("series")||type.contains("serie")||type.contains("show");}
    private String first(JSONObject o,String...keys){for(String k:keys){Object v=o.opt(k);if(v instanceof String&&!((String)v).isEmpty())return (String)v;}return "";}
    private void collect(Object node,List<JSONObject> result,int depth){if(depth>8||result.size()>1000)return;if(node instanceof JSONArray){JSONArray a=(JSONArray)node;for(int i=0;i<a.length();i++)collect(a.opt(i),result,depth+1);}else if(node instanceof JSONObject){JSONObject o=(JSONObject)node;if(!first(o,"name","title","channel_name","vod_name","series_name").isEmpty())result.add(o);Iterator<String> keys=o.keys();while(keys.hasNext()){String k=keys.next();Object v=o.opt(k);if(v instanceof JSONArray||v instanceof JSONObject)collect(v,result,depth+1);}}}
    private void checkProvider(){base("Teste de provedor");content.addView(button("← Início",v->home()));TextView status=text("Consultando API...",16);content.addView(status);request(PROVIDER,(code,body,error)->{if(error!=null)status.setText("Falha: "+error);else if(code==401||code==403)status.setText("HTTP "+code+" • autenticação necessária");else status.setText("POST HTTP "+code+" • "+validationHint(body));});}
    private void diagnose(){base("Diagnóstico das APIs");content.addView(button("← Início",v->home()));content.addView(text("Verificação somente de leitura: consulta os métodos anunciados pelo servidor. Não tenta autenticação nem altera dados.",15));probe("Catálogo",CATALOG);probe("Provedor",PROVIDER);}
    private void probe(String label,String endpoint){TextView status=text(label+": verificando...",16);content.addView(status);new Thread(()->{HttpURLConnection c=null;String msg;try{c=(HttpURLConnection)new URL(endpoint).openConnection();c.setRequestMethod("OPTIONS");c.setConnectTimeout(9000);c.setReadTimeout(9000);c.setInstanceFollowRedirects(false);int code=c.getResponseCode();String allow=c.getHeaderField("Allow");msg=label+" — OPTIONS HTTP "+code+"\nMétodos permitidos: "+(allow==null?"não informados":allow)+"\nObservação: OPTIONS pode estar desabilitado mesmo quando outros métodos funcionam.";}catch(Exception e){msg=label+" — "+e.getClass().getSimpleName()+": "+e.getMessage();}finally{if(c!=null)c.disconnect();}final String result=msg;runOnUiThread(()->status.setText(result));}).start();}
    private interface Result {void done(int code,String body,String error);}
    private String validationHint(String body){
        try {
            JSONObject obj=new JSONObject(body);
            StringBuilder out=new StringBuilder("Diagnóstico: ");
            for(String key:new String[]{"message","error","detail","errors","required_fields"}){
                if(!obj.has(key))continue;
                Object v=obj.opt(key);
                if(v instanceof JSONObject){JSONObject fields=(JSONObject)v;java.util.Iterator<String> it=fields.keys();int count=0;out.append("campos informados: ");while(it.hasNext()&&count++<15)out.append(it.next()).append(", ");}
                else if(v instanceof JSONArray){out.append("lista de ").append(((JSONArray)v).length()).append(" erros; ");}
                else if(v instanceof String && (key.equals("message")||key.equals("error"))){String msg=(String)v;if(msg.length()<160 && !msg.matches("(?i).*(token|bearer|secret|password|senha|api.key).*"))out.append(msg);}
            }
            return out.length()>13?out.toString():"A API não informou campos obrigatórios em formato reconhecido.";
        }catch(Exception e){return "Resposta não é JSON de validação reconhecido.";}
    }
    private void request(String endpoint,Result callback){new Thread(()->{HttpURLConnection c=null;int code=0;String body="";String error=null;try{c=(HttpURLConnection)new URL(endpoint).openConnection();c.setRequestMethod("POST");c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=UTF-8");c.setConnectTimeout(9000);c.setReadTimeout(9000);c.setInstanceFollowRedirects(false);c.setRequestProperty("Accept","application/json");try(OutputStream post=c.getOutputStream()){post.write("{}".getBytes("UTF-8"));post.flush();}code=c.getResponseCode();InputStream in=(code>=400?c.getErrorStream():c.getInputStream());if(in!=null){ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[4096];int n;while((n=in.read(buf))!=-1&&out.size()<1024*1024)out.write(buf,0,n);body=out.toString("UTF-8");in.close();}}catch(Exception e){error=e.getClass().getSimpleName()+": "+e.getMessage();}finally{if(c!=null)c.disconnect();}final int fcode=code;final String fbody=body,ferror=error;runOnUiThread(()->callback.done(fcode,fbody,ferror));}).start();}
    private void play(String title,String url){base(title);content.addView(button("← Início",v->home()));player=new VideoView(this);content.addView(player,new LinearLayout.LayoutParams(-1,520));MediaController mc=new MediaController(this);mc.setAnchorView(player);player.setMediaController(mc);player.setOnErrorListener((mp,what,extra)->{Toast.makeText(this,"Reprodução indisponível",Toast.LENGTH_LONG).show();return true;});player.setVideoURI(Uri.parse(url));player.start();}
    @Override public void onBackPressed(){if(player!=null){player.stopPlayback();player=null;}home();}
}
