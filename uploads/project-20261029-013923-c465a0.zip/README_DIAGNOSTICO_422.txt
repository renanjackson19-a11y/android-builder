Atualização: exibe somente nomes dos campos de validação retornados pela API no HTTP 422, sem mostrar valores de tokens ou credenciais. Não implementa autenticação ou acesso ao catálogo.
