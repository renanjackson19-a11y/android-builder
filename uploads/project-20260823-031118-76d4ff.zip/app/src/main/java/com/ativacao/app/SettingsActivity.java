package com.ativacao.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class SettingsActivity extends Activity {
    @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(build());}
    private View build(){LinearLayout root=Ui.column(this);root.setBackgroundColor(Ui.BG);root.setPadding(Ui.dp(this,36),Ui.dp(this,28),Ui.dp(this,36),Ui.dp(this,28));TextView title=Ui.text(this,"Configurações",28,Ui.TEXT,true);root.addView(title,new LinearLayout.LayoutParams(-1,Ui.dp(this,58)));TextView sub=Ui.text(this,"Painel: https://dubaiplay.shop/",14,Ui.MUTED,false);root.addView(sub,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));TextView lab=Ui.text(this,"Chave da API do painel",15,Ui.TEXT,true);root.addView(lab,new LinearLayout.LayoutParams(-1,Ui.dp(this,38)));EditText key=new EditText(this);key.setSingleLine(true);key.setText(ApiClient.apiKey(this));key.setHint("Cole aqui a chave gerada pelo painel");key.setHintTextColor(Ui.MUTED);key.setTextColor(Ui.TEXT);key.setPadding(Ui.dp(this,16),0,Ui.dp(this,16),0);key.setBackground(Ui.stroke(Ui.PANEL_2,Color.rgb(50,68,95),14,this));root.addView(key,new LinearLayout.LayoutParams(-1,Ui.dp(this,56)));LinearLayout actions=new LinearLayout(this);actions.setPadding(0,Ui.dp(this,20),0,0);TextView save=Ui.button(this,"SALVAR E TESTAR");TextView back=Ui.button(this,"VOLTAR");actions.addView(save,new LinearLayout.LayoutParams(Ui.dp(this,220),Ui.dp(this,56)));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(Ui.dp(this,160),Ui.dp(this,56));bp.leftMargin=Ui.dp(this,14);actions.addView(back,bp);root.addView(actions);TextView result=Ui.text(this,"",14,Ui.MUTED,false);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,Ui.dp(this,60));rp.topMargin=Ui.dp(this,16);root.addView(result,rp);save.setOnClickListener(v->{ApiClient.saveApiKey(this,key.getText().toString());((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(key.getWindowToken(),0);result.setText("Testando conexão...");ApiClient.catalog(this,"live",new ApiClient.Callback<java.util.List<ApiClient.Item>>(){public void ok(java.util.List<ApiClient.Item> items){runOnUiThread(()->{result.setText("✓ Conectado ao painel • "+items.size()+" canais encontrados");result.setTextColor(Ui.GREEN);});}public void error(String m){runOnUiThread(()->{result.setText("Falha: "+m);result.setTextColor(Color.rgb(255,100,110));});}});});back.setOnClickListener(v->finish());save.requestFocus();return root;}
}
