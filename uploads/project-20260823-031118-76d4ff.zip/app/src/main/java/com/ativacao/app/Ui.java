package com.ativacao.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

final class Ui {
    static final int BG = Color.rgb(5, 9, 20);
    static final int PANEL = Color.rgb(13, 23, 40);
    static final int PANEL_2 = Color.rgb(17, 29, 49);
    static final int TEXT = Color.rgb(245, 247, 255);
    static final int MUTED = Color.rgb(145, 157, 181);
    static final int PURPLE = Color.rgb(124, 77, 255);
    static final int BLUE = Color.rgb(41, 121, 255);
    static final int GREEN = Color.rgb(0, 200, 120);

    static int dp(Context c, int n) { return (int)(n * c.getResources().getDisplayMetrics().density + .5f); }

    static GradientDrawable round(int color, int radiusDp, Context c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    static GradientDrawable stroke(int fill, int stroke, int radiusDp, Context c) {
        GradientDrawable g = round(fill, radiusDp, c);
        g.setStroke(dp(c, 1), stroke);
        return g;
    }

    static TextView text(Context c, String s, int sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    static TextView button(Context c, String s) {
        TextView b = text(c, s, 16, TEXT, true);
        b.setGravity(Gravity.CENTER);
        b.setFocusable(true);
        b.setClickable(true);
        b.setPadding(dp(c, 20), dp(c, 12), dp(c, 20), dp(c, 12));
        b.setBackground(stroke(PANEL_2, Color.rgb(48, 66, 94), 14, c));
        focus(b, c);
        return b;
    }

    static void focus(View v, Context c) {
        v.setOnFocusChangeListener((view, focused) -> {
            view.animate().scaleX(focused ? 1.045f : 1f).scaleY(focused ? 1.045f : 1f).setDuration(120).start();
            view.setBackground(focused ? stroke(Color.rgb(28, 39, 69), PURPLE, 14, c) : stroke(PANEL_2, Color.rgb(48, 66, 94), 14, c));
        });
    }

    static LinearLayout column(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }
}
