package com.ativacao.app;

import android.app.Activity;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

public class PlayerActivity extends Activity {
    private VideoView video;
    private ProgressBar loading;
    private TextView epgNow;
    private TextView epgNext;

    @Override public void onCreate(Bundle b){
        super.onCreate(b); immersive();
        FrameLayout root=new FrameLayout(this);root.setBackgroundColor(Color.BLACK);
        video=new VideoView(this);root.addView(video,new FrameLayout.LayoutParams(-1,-1));
        loading=new ProgressBar(this);FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(Ui.dp(this,55),Ui.dp(this,55),Gravity.CENTER);root.addView(loading,lp);

        TextView name=Ui.text(this,getIntent().getStringExtra("name")==null?"Dubai Play":getIntent().getStringExtra("name"),16,Color.WHITE,true);
        name.setPadding(Ui.dp(this,20),Ui.dp(this,10),Ui.dp(this,20),Ui.dp(this,10));name.setBackgroundColor(0x88000000);
        FrameLayout.LayoutParams np=new FrameLayout.LayoutParams(-1,Ui.dp(this,50),Gravity.TOP);root.addView(name,np);

        String type=getIntent().getStringExtra("type");
        long id=getIntent().getLongExtra("id",0);
        if("live".equals(type)){
            LinearLayout guide=Ui.column(this);guide.setPadding(Ui.dp(this,22),Ui.dp(this,10),Ui.dp(this,22),Ui.dp(this,10));guide.setBackgroundColor(0xCC07111F);
            epgNow=Ui.text(this,"AGORA  Carregando programação...",15,Color.WHITE,true);
            epgNext=Ui.text(this,"A SEGUIR  —",13,Ui.MUTED,false);
            guide.addView(epgNow,new LinearLayout.LayoutParams(-1,Ui.dp(this,28)));
            guide.addView(epgNext,new LinearLayout.LayoutParams(-1,Ui.dp(this,25)));
            FrameLayout.LayoutParams gp=new FrameLayout.LayoutParams(-1,Ui.dp(this,68),Gravity.BOTTOM);gp.leftMargin=Ui.dp(this,18);gp.rightMargin=Ui.dp(this,18);gp.bottomMargin=Ui.dp(this,16);root.addView(guide,gp);
        }
        setContentView(root);

        String url=ApiClient.streamUrl(this,id);if(url.isEmpty()){Toast.makeText(this,"Chave da API não configurada.",Toast.LENGTH_LONG).show();finish();return;}
        MediaController controls=new MediaController(this);controls.setAnchorView(video);video.setMediaController(controls);
        video.setOnPreparedListener(mp->{loading.setVisibility(View.GONE);mp.setScreenOnWhilePlaying(true);video.start();});
        video.setOnErrorListener((mp,what,extra)->{loading.setVisibility(View.GONE);Toast.makeText(this,"Não foi possível reproduzir este conteúdo.",Toast.LENGTH_LONG).show();return true;});
        video.setVideoURI(Uri.parse(url));video.requestFocus();

        if("live".equals(type))loadEpg(id);
    }

    private void loadEpg(long id){
        ApiClient.epg(this,id,new ApiClient.Callback<ApiClient.EpgInfo>(){
            public void ok(ApiClient.EpgInfo i){runOnUiThread(()->{
                if(epgNow!=null)epgNow.setText(i.nowTitle.isEmpty()?"AGORA  Programação não disponível":"AGORA  "+i.nowTitle);
                if(epgNext!=null)epgNext.setText(i.nextTitle.isEmpty()?"A SEGUIR  —":"A SEGUIR  "+i.nextTitle);
            });}
            public void error(String m){runOnUiThread(()->{if(epgNow!=null)epgNow.setText("AGORA  Programação não disponível");if(epgNext!=null)epgNext.setText("A SEGUIR  —");});}
        });
    }

    @Override protected void onStop(){if(video!=null)video.stopPlayback();super.onStop();}
    private void immersive(){getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);}
}
