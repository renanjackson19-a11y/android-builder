package com.ativacao.app;

public final class Config {
    private Config() {}

    // Painel já apontado para seu domínio.
    public static final String API_BASE_URL = "https://dubaiplay.shop/api/";

    // Você pode deixar vazio no código e preencher pelo menu Configurações do app.
    public static final String DEFAULT_API_KEY = "";
}
