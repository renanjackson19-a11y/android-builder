package com.ativacao.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class ApiClient {
    static final ExecutorService IO = Executors.newFixedThreadPool(3);

    interface Callback<T> { void ok(T value); void error(String message); }

    static class Item {
        long id;
        String name = "";
        String logo = "";
        String group = "";
        String synopsis = "";
        int year = 0;
    }

    static class EpgInfo {
        String nowTitle = "";
        String nowStart = "";
        String nowStop = "";
        String nextTitle = "";
        String nextStart = "";
    }

    static String apiKey(Context c) {
        SharedPreferences p = c.getSharedPreferences("dubai_play", Context.MODE_PRIVATE);
        return p.getString("api_key", Config.DEFAULT_API_KEY);
    }

    static void saveApiKey(Context c, String key) {
        c.getSharedPreferences("dubai_play", Context.MODE_PRIVATE).edit().putString("api_key", key == null ? "" : key.trim()).apply();
    }

    static void status(Callback<String> cb) {
        IO.execute(() -> {
            try {
                String json = request(Config.API_BASE_URL + "status.php", "");
                JSONObject o = new JSONObject(json);
                cb.ok(o.optString("name", "Dubai Play"));
            } catch (Exception e) { cb.error(message(e)); }
        });
    }

    static void catalog(Context c, String type, Callback<List<Item>> cb) {
        IO.execute(() -> {
            try {
                String key = apiKey(c);
                if (key.trim().isEmpty()) throw new Exception("Chave da API não configurada");
                String url = Config.API_BASE_URL + "catalog.php?type=" + URLEncoder.encode(type, "UTF-8");
                String json = request(url, key);
                JSONObject root = new JSONObject(json);
                JSONArray a = root.optJSONArray("items");
                List<Item> out = new ArrayList<>();
                if (a != null) {
                    for (int i = 0; i < a.length(); i++) {
                        JSONObject o = a.optJSONObject(i);
                        if (o == null) continue;
                        Item item = new Item();
                        item.id = o.optLong("id");
                        item.name = o.optString("name", "Sem nome");
                        item.logo = o.optString("logo", "");
                        item.group = o.optString("group_title", "");
                        item.synopsis = o.optString("synopsis", "");
                        item.year = o.optInt("release_year", 0);
                        out.add(item);
                    }
                }
                cb.ok(out);
            } catch (Exception e) { cb.error(message(e)); }
        });
    }

    static void epg(Context c, long streamId, Callback<EpgInfo> cb) {
        IO.execute(() -> {
            try {
                String key = apiKey(c);
                if (key.trim().isEmpty()) throw new Exception("Chave da API não configurada");
                String json = request(Config.API_BASE_URL + "epg.php?stream_id=" + streamId + "&limit=12", key);
                JSONObject root = new JSONObject(json);
                EpgInfo info = new EpgInfo();
                JSONObject now = root.optJSONObject("now");
                JSONObject next = root.optJSONObject("next");
                if (now != null) {
                    info.nowTitle = now.optString("title", "");
                    info.nowStart = now.optString("start_time", "");
                    info.nowStop = now.optString("stop_time", "");
                }
                if (next != null) {
                    info.nextTitle = next.optString("title", "");
                    info.nextStart = next.optString("start_time", "");
                }
                cb.ok(info);
            } catch (Exception e) { cb.error(message(e)); }
        });
    }

    static String streamUrl(Context c, long id) {
        try {
            return Config.API_BASE_URL + "stream.php?id=" + id + "&key=" + URLEncoder.encode(apiKey(c), "UTF-8");
        } catch (Exception e) { return ""; }
    }

    private static String request(String url, String apiKey) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
        con.setConnectTimeout(12000);
        con.setReadTimeout(30000);
        con.setInstanceFollowRedirects(true);
        con.setRequestProperty("Accept", "application/json");
        if (apiKey != null && !apiKey.isEmpty()) con.setRequestProperty("X-API-Key", apiKey);
        int code = con.getResponseCode();
        InputStream in = code >= 200 && code < 300 ? con.getInputStream() : con.getErrorStream();
        StringBuilder sb = new StringBuilder();
        if (in != null) {
            BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();
        }
        con.disconnect();
        if (code == 401) throw new Exception("Aplicativo não autorizado pela API");
        if (code < 200 || code >= 300) throw new Exception("Servidor respondeu HTTP " + code);
        return sb.toString();
    }

    private static String message(Exception e) {
        String m = e.getMessage();
        return m == null || m.trim().isEmpty() ? "Falha de conexão" : m;
    }
}
