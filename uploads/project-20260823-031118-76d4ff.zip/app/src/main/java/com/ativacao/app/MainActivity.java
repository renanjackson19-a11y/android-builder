package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends Activity {
    private TextView liveCount, movieCount, seriesCount, server;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        immersive();
        setContentView(build());
        refresh();
    }

    @Override protected void onResume() {
        super.onResume();
        immersive();
        refresh();
    }

    private View build() {
        LinearLayout root = Ui.column(this);
        root.setBackgroundColor(Ui.BG);
        root.setPadding(Ui.dp(this, 38), Ui.dp(this, 26), Ui.dp(this, 38), Ui.dp(this, 24));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = Ui.text(this, "DUBAI PLAY", 28, Ui.TEXT, true);
        TextView pill = Ui.text(this, "  IPTV • TV  ", 13, Color.rgb(190,177,255), true);
        pill.setGravity(Gravity.CENTER);
        pill.setBackground(Ui.round(Color.rgb(38,26,70), 20, this));
        pill.setPadding(Ui.dp(this,12), Ui.dp(this,6), Ui.dp(this,12), Ui.dp(this,6));
        server = Ui.text(this, "● CONECTANDO", 13, Ui.MUTED, true);
        server.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        top.addView(brand, new LinearLayout.LayoutParams(0, Ui.dp(this, 52), 1));
        top.addView(pill, new LinearLayout.LayoutParams(Ui.dp(this, 120), Ui.dp(this, 38)));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(Ui.dp(this, 230), Ui.dp(this, 52)); sp.leftMargin=Ui.dp(this,18);
        top.addView(server, sp);
        root.addView(top);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout content = Ui.column(this);
        content.setPadding(0, Ui.dp(this, 20), 0, 0);

        TextView hello = Ui.text(this, "Seu entretenimento em um só lugar", 29, Ui.TEXT, true);
        content.addView(hello);
        TextView sub = Ui.text(this, "Canais ao vivo, filmes e séries carregados diretamente do seu painel.", 15, Ui.MUTED, false);
        LinearLayout.LayoutParams subp = new LinearLayout.LayoutParams(-1, Ui.dp(this,42));
        content.addView(sub, subp);

        LinearLayout cards = new LinearLayout(this);
        cards.setOrientation(LinearLayout.HORIZONTAL);
        liveCount = makeCard(cards, "▣", "CANAIS AO VIVO", "live", Ui.BLUE);
        movieCount = makeCard(cards, "▶", "FILMES", "movie", Ui.GREEN);
        seriesCount = makeCard(cards, "▤", "SÉRIES", "series", Ui.PURPLE);
        content.addView(cards, new LinearLayout.LayoutParams(-1, Ui.dp(this, 235)));

        LinearLayout bottom = new LinearLayout(this);
        bottom.setPadding(0, Ui.dp(this,24), 0, 0);
        TextView explore = Ui.button(this, "▶  ABRIR CANAIS");
        TextView settings = Ui.button(this, "⚙  CONFIGURAÇÕES");
        explore.setOnClickListener(v -> open("live", "Canais ao Vivo"));
        settings.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(Ui.dp(this,260), Ui.dp(this,56));
        bottom.addView(explore, bp);
        LinearLayout.LayoutParams bp2 = new LinearLayout.LayoutParams(Ui.dp(this,260), Ui.dp(this,56)); bp2.leftMargin=Ui.dp(this,16);
        bottom.addView(settings, bp2);
        content.addView(bottom);

        TextView note = Ui.text(this, "DUBAI PLAY • Aplicativo conectado ao painel dubaiplay.shop", 12, Color.rgb(92,105,129), false);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, Ui.dp(this,70)); np.topMargin=Ui.dp(this,12);
        content.addView(note, np);

        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        return root;
    }

    private TextView makeCard(LinearLayout row, String icon, String title, String type, int accent) {
        LinearLayout card = Ui.column(this);
        card.setPadding(Ui.dp(this,24), Ui.dp(this,22), Ui.dp(this,24), Ui.dp(this,18));
        card.setBackground(Ui.stroke(Ui.PANEL, Color.rgb(32,51,76), 18, this));
        card.setFocusable(true); card.setClickable(true);
        Ui.focus(card, this);
        card.setOnClickListener(v -> open(type, titleCase(title)));
        TextView ico = Ui.text(this, icon, 33, accent, true);
        card.addView(ico, new LinearLayout.LayoutParams(-1, Ui.dp(this,48)));
        TextView t = Ui.text(this, title, 16, Ui.TEXT, true);
        card.addView(t, new LinearLayout.LayoutParams(-1, Ui.dp(this,38)));
        TextView count = Ui.text(this, "0", 34, Ui.TEXT, true);
        card.addView(count, new LinearLayout.LayoutParams(-1, Ui.dp(this,48)));
        TextView small = Ui.text(this, "Conteúdo disponível", 13, Ui.MUTED, false);
        card.addView(small, new LinearLayout.LayoutParams(-1, Ui.dp(this,36)));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, Ui.dp(this,215),1); p.rightMargin=Ui.dp(this,16);
        row.addView(card,p);
        if (row.getChildCount()==1) card.requestFocus();
        return count;
    }

    private String titleCase(String s) {
        if ("live".equals(s)) return "Canais ao Vivo";
        if ("movie".equals(s)) return "Filmes";
        if ("series".equals(s)) return "Séries";
        String lower=s.toLowerCase(); return Character.toUpperCase(lower.charAt(0))+lower.substring(1);
    }

    private void open(String type, String title) {
        Intent i = new Intent(this, CatalogActivity.class);
        i.putExtra("type", type); i.putExtra("title", title); startActivity(i);
    }

    private void refresh() {
        ApiClient.status(new ApiClient.Callback<String>() {
            public void ok(String s) { runOnUiThread(() -> { server.setText("● SERVIDOR ONLINE"); server.setTextColor(Ui.GREEN); }); }
            public void error(String m) { runOnUiThread(() -> { server.setText("● SEM CONEXÃO"); server.setTextColor(Color.rgb(255,90,100)); }); }
        });
        count("live", liveCount); count("movie", movieCount); count("series", seriesCount);
    }

    private void count(String type, TextView tv) {
        ApiClient.catalog(this,type,new ApiClient.Callback<List<ApiClient.Item>>() {
            public void ok(List<ApiClient.Item> v) { runOnUiThread(() -> tv.setText(String.valueOf(v.size()))); }
            public void error(String m) { runOnUiThread(() -> tv.setText("0")); }
        });
    }

    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }
}
