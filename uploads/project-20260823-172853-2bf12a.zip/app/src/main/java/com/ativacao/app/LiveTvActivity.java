package com.ativacao.app;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.common.PlaybackException;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.PlayerView;
import androidx.media3.ui.AspectRatioFrameLayout;

import java.util.ArrayList;
import java.util.List;

/** TV: lista/categorias à esquerda + preview à direita. Primeiro OK seleciona; segundo OK abre tela cheia. */
public class LiveTvActivity extends android.app.Activity {
    private final List<ApiClient.Item> allChannels = new ArrayList<>();
    private LinearLayout rows;
    private PlayerView preview;
    private FrameLayout playerCard;
    private FrameLayout shell, fullscreenLayer;
    private LinearLayout content, rightColumn;
    private LinearLayout.LayoutParams playerNormalLp;
    private boolean fullscreen = false;
    private ExoPlayer player;
    private TextView title, epgNow, epgNext, hint;
    private ProgressBar loading;
    private ApiClient.Item current;
    private View currentRow;
    private long armedChannelId = -1L;
    private int channelLoadToken = 0;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        immersive();
        setContentView(build());
        loadChannels();
    }

    private View build() {
        shell = new FrameLayout(this);
        LinearLayout root = Ui.column(this);
        root.setBackgroundColor(Color.rgb(1,2,1));
        shell.addView(root,new FrameLayout.LayoutParams(-1,-1));

        fullscreenLayer = new FrameLayout(this);
        fullscreenLayer.setBackgroundColor(Color.BLACK);
        fullscreenLayer.setVisibility(View.GONE);
        shell.addView(fullscreenLayer,new FrameLayout.LayoutParams(-1,-1));

        root.addView(YellowNav.bar(this,"TV"),new LinearLayout.LayoutParams(-1,Ui.dp(this,64)));

        // Conteúdo em 2 áreas bem definidas
        LinearLayout contentWrap=new LinearLayout(this);
        contentWrap.setOrientation(LinearLayout.HORIZONTAL);
        contentWrap.setPadding(Ui.dp(this,22),Ui.dp(this,14),Ui.dp(this,22),Ui.dp(this,18));

        // Sidebar
        LinearLayout sidebar=Ui.column(this);
        sidebar.setBackground(Ui.round(0xFF080A08,10,this));
        sidebar.setPadding(Ui.dp(this,14),Ui.dp(this,14),Ui.dp(this,14),Ui.dp(this,12));

        TextView liveTitle=Ui.text(this,"AO VIVO",14,Ui.GREEN,true);
        sidebar.addView(liveTitle,new LinearLayout.LayoutParams(-1,Ui.dp(this,34)));
        TextView channelLabel=Ui.text(this,"CANAIS",9,0xFFB8BDB5,true);
        sidebar.addView(channelLabel,new LinearLayout.LayoutParams(-1,Ui.dp(this,26)));

        ScrollView sc=new ScrollView(this);
        sc.setVerticalScrollBarEnabled(false);
        sc.setFillViewport(true);
        rows=Ui.column(this);
        sc.addView(rows,new ScrollView.LayoutParams(-1,-2));
        sidebar.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout.LayoutParams sideLp=new LinearLayout.LayoutParams(Ui.dp(this,330),-1);
        sideLp.rightMargin=Ui.dp(this,18);
        contentWrap.addView(sidebar,sideLp);

        // Área direita: player + EPG separado
        rightColumn=Ui.column(this);

        playerCard=new FrameLayout(this);
        playerCard.setFocusable(true);
        playerCard.setClickable(true);
        playerCard.setBackground(Ui.stroke(Color.BLACK,0xFF343A2C,8,this));
        preview=new PlayerView(this);
        preview.setUseController(false);
        preview.setBackgroundColor(Color.BLACK);
        preview.setKeepScreenOn(true);
        preview.setFocusable(false);
        preview.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        playerCard.addView(preview,new FrameLayout.LayoutParams(-1,-1));
        loading=new ProgressBar(this);
        playerCard.addView(loading,new FrameLayout.LayoutParams(Ui.dp(this,44),Ui.dp(this,44),Gravity.CENTER));
        playerCard.setOnClickListener(v->openFullscreen());
        playerNormalLp=new LinearLayout.LayoutParams(-1,0,1);
        rightColumn.addView(playerCard,playerNormalLp);

        LinearLayout epg=Ui.column(this);
        epg.setBackground(Ui.round(0xFF0B0D0A,8,this));
        epg.setPadding(Ui.dp(this,18),Ui.dp(this,10),Ui.dp(this,18),Ui.dp(this,8));
        title=Ui.text(this,"Carregando canal...",16,Color.WHITE,true);
        title.setMaxLines(1);
        epg.addView(title,new LinearLayout.LayoutParams(-1,Ui.dp(this,32)));
        epgNow=Ui.text(this,"AGORA  —",10,Ui.GREEN,true);
        epgNow.setMaxLines(1);
        epg.addView(epgNow,new LinearLayout.LayoutParams(-1,Ui.dp(this,25)));
        epgNext=Ui.text(this,"A SEGUIR  —",10,0xFFCCD0C8,false);
        epgNext.setMaxLines(1);
        epg.addView(epgNext,new LinearLayout.LayoutParams(-1,Ui.dp(this,25)));
        hint=Ui.text(this,"OK seleciona • OK novamente abre tela cheia",8,0xFF8E958A,false);
        hint.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        epg.addView(hint,new LinearLayout.LayoutParams(-1,Ui.dp(this,22)));

        LinearLayout.LayoutParams epgLp=new LinearLayout.LayoutParams(-1,Ui.dp(this,112));
        epgLp.topMargin=Ui.dp(this,10);
        rightColumn.addView(epg,epgLp);
        contentWrap.addView(rightColumn,new LinearLayout.LayoutParams(0,-1,1));

        root.addView(contentWrap,new LinearLayout.LayoutParams(-1,0,1));
        return shell;
    }

    private void addNav(LinearLayout row,String label,boolean selected,Runnable action){
        TextView v=Ui.nav(this,label,selected); if(action!=null)v.setOnClickListener(x->action.run());
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1); row.addView(v,p);
    }

    private void loadChannels(){
        int token=++channelLoadToken;
        loadChannelPage(1, new ArrayList<>(), token);
    }

    private void loadChannelPage(int page, List<ApiClient.Item> acc, int token){
        if(token!=channelLoadToken || isFinishing() || isDestroyed()) return;
        ApiClient.catalog("live",page,72,"","","",new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){
                if(token!=channelLoadToken) return;
                int before=acc.size();
                if(p!=null && p.items!=null){
                    java.util.HashSet<Long> ids=new java.util.HashSet<>();
                    for(ApiClient.Item old:acc) ids.add(old.id);
                    for(ApiClient.Item item:p.items) if(item!=null && !ids.contains(item.id)){acc.add(item);ids.add(item.id);}
                }
                int pages=p==null?1:Math.max(1,p.pages);
                boolean apiHasNext=page<pages;
                boolean fullPage=p!=null && p.items!=null && p.items.size()>=72 && acc.size()>before;
                // Alguns backends antigos não informam "pages" corretamente. Continua enquanto vier página cheia.
                if(page<30 && (apiHasNext || fullPage)){ loadChannelPage(page+1,acc,token); return; }
                runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())renderAll(acc);});
            }
            public void error(String m){
                if(!acc.isEmpty()){runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())renderAll(acc);});return;}
                runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())Toast.makeText(LiveTvActivity.this,"Não foi possível carregar os canais",Toast.LENGTH_LONG).show();});
            }
        });
    }

    private void renderAll(List<ApiClient.Item> list){
        allChannels.clear(); if(list!=null)allChannels.addAll(list);
        renderRows();
    }


    private void renderRows(){
        rows.removeAllViews();
        List<ApiClient.Item> visible=new ArrayList<>();
        for(ApiClient.Item i:allChannels){
            visible.add(i);
        }
        if(visible.isEmpty()){rows.addView(Ui.text(this,"Nenhum canal nesta categoria",10,Ui.MUTED,false));return;}

        ApiClient.Item last=LocalStore.lastLive(this); ApiClient.Item initial=null;
        if(current!=null) for(ApiClient.Item x:visible)if(x.id==current.id){initial=x;break;}
        if(initial==null&&last!=null)for(ApiClient.Item x:visible)if(x.id==last.id){initial=x;break;}
        if(initial==null)initial=visible.get(0);
        View focus=null; int n=1;
        for(ApiClient.Item i:visible){
            LinearLayout r=new LinearLayout(this); r.setGravity(Gravity.CENTER_VERTICAL); r.setPadding(Ui.dp(this,6),Ui.dp(this,5),Ui.dp(this,8),Ui.dp(this,5)); r.setFocusable(true); r.setClickable(true);
            TextView num=Ui.text(this,String.valueOf(n++),9,Ui.MUTED,true); num.setGravity(Gravity.CENTER); r.addView(num,new LinearLayout.LayoutParams(Ui.dp(this,28),-1));
            ImageView logo=new ImageView(this);logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);logo.setBackground(Ui.round(0x25FFFFFF,7,this));ImageLoader.into(this,logo,i.logo);
            LinearLayout.LayoutParams lip=new LinearLayout.LayoutParams(Ui.dp(this,52),Ui.dp(this,52));lip.rightMargin=Ui.dp(this,9);r.addView(logo,lip);
            TextView name=Ui.text(this,clean(i.name,"Canal"),10,Color.WHITE,true);name.setMaxLines(1);name.setGravity(Gravity.CENTER_VERTICAL);
            r.addView(name,new LinearLayout.LayoutParams(0,-1,1));
            TextView fav=Ui.text(this,LocalStore.isFavorite(this,i.id)?"★":"☆",17,LocalStore.isFavorite(this,i.id)?Ui.GREEN:0xFF777D74,true);
            fav.setGravity(Gravity.CENTER); fav.setFocusable(true); fav.setClickable(true);
            fav.setOnClickListener(v->{LocalStore.toggleFavorite(this,i); boolean yes=LocalStore.isFavorite(this,i.id); fav.setText(yes?"★":"☆"); fav.setTextColor(yes?Ui.GREEN:0xFF777D74);});
            r.addView(fav,new LinearLayout.LayoutParams(Ui.dp(this,38),-1));
            android.graphics.drawable.Drawable normal=Ui.round(0xFF11130F,6,this), focused=Ui.stroke(0xFF1C1F17,Ui.GREEN,6,this);
            r.setBackground(normal);
            r.setOnFocusChangeListener((v,has)->{
                v.animate().scaleX(has?1.015f:1f).scaleY(has?1.015f:1f).setDuration(90).start();
                v.setBackground(has?focused:normal);
                if(has){
                    if(current==null || current.id!=i.id){
                        armedChannelId=-1L;
                        previewChannel(i,v);
                    } else {
                        currentRow=v;
                    }
                }
            });
            r.setOnClickListener(v->{
                // OK em OUTRO canal: troca o preview uma única vez e arma o canal.
                // OK no MESMO canal: não recarrega; segundo OK abre tela cheia.
                if(current==null || current.id!=i.id){
                    armedChannelId=i.id;
                    previewChannel(i,v);
                    currentRow=v;
                    hint.setText("OK novamente: tela cheia  •  ou OK no preview");
                    return;
                }
                if(armedChannelId==i.id){
                    openFullscreen();
                    return;
                }
                armedChannelId=i.id;
                currentRow=v;
                hint.setText("OK novamente: tela cheia  •  ou OK no preview");
            });
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,Ui.dp(this,68)); rp.bottomMargin=Ui.dp(this,5); rows.addView(r,rp);
            if(i.id==initial.id)focus=r;
        }
        previewChannel(initial,focus); if(focus!=null)focus.requestFocus();
    }

    private void previewChannel(ApiClient.Item i, View row){
        if(i==null)return;
        if(current!=null && current.id==i.id){currentRow=row;return;}
        current=i; currentRow=row; LocalStore.saveLastLive(this,i);
        title.setText(clean(i.name,"Canal")); epgNow.setText("AGORA  Carregando programação..."); epgNext.setText("A SEGUIR  —"); hint.setText("1º OK seleciona • 2º OK abre tela cheia");
        loadEpg(i.id); startPreview(i.id);
    }

    private void startPreview(long id){
        if(isFinishing() || isDestroyed()) return;
        loading.setVisibility(View.VISIBLE);
        if(player!=null){try{preview.setPlayer(null);player.release();}catch(Exception ignored){} player=null;}
        try{
            String url=ApiClient.streamUrl(id);
            if(url==null || url.trim().isEmpty()) throw new IllegalArgumentException("URL do canal vazia");
            DefaultHttpDataSource.Factory http=new DefaultHttpDataSource.Factory().setUserAgent("DubaiPlayTV/3.0.1 Android").setConnectTimeoutMs(8000).setReadTimeoutMs(30000).setAllowCrossProtocolRedirects(true);
            player=new ExoPlayer.Builder(this).setMediaSourceFactory(new DefaultMediaSourceFactory(this).setDataSourceFactory(http)).build();
            preview.setPlayer(player);
            player.addListener(new Player.Listener(){
                @Override public void onPlaybackStateChanged(int state){if(state==Player.STATE_READY && loading!=null)loading.setVisibility(View.GONE);}
                @Override public void onPlayerError(PlaybackException error){
                    if(loading!=null)loading.setVisibility(View.GONE);
                    if(epgNow!=null)epgNow.setText("AGORA  Sinal indisponível");
                }
            });
            player.setMediaItem(MediaItem.fromUri(url)); player.prepare(); player.play();
        }catch(Throwable e){
            loading.setVisibility(View.GONE);
            epgNow.setText("AGORA  Sinal indisponível");
        }
    }

    private void loadEpg(long id){
        ApiClient.epg(id,new ApiClient.Callback<ApiClient.EpgInfo>(){
            public void ok(ApiClient.EpgInfo e){runOnUiThread(()->{if(current==null||current.id!=id)return;epgNow.setText("AGORA  "+clean(e.nowTitle,"Sem informação"));epgNext.setText("A SEGUIR  "+clean(e.nextTitle,"—"));});}
            public void error(String m){runOnUiThread(()->{if(current!=null&&current.id==id){epgNow.setText("AGORA  Sem informação");epgNext.setText("A SEGUIR  —");}});}
        });
    }

    private void openFullscreen(){
        if(current==null || fullscreen)return;
        fullscreen=true;
        if(playerCard.getParent() instanceof android.view.ViewGroup){
            ((android.view.ViewGroup)playerCard.getParent()).removeView(playerCard);
        }
        fullscreenLayer.removeAllViews();
        preview.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FILL);
        fullscreenLayer.addView(playerCard,new FrameLayout.LayoutParams(-1,-1));
        fullscreenLayer.setVisibility(View.VISIBLE);
        fullscreenLayer.bringToFront();
        hint.setText("VOLTAR: lista de canais");
        playerCard.requestFocus();
        immersive();
    }

    private void closeFullscreen(){
        if(!fullscreen)return;
        fullscreen=false;
        if(playerCard.getParent() instanceof android.view.ViewGroup){
            ((android.view.ViewGroup)playerCard.getParent()).removeView(playerCard);
        }
        fullscreenLayer.setVisibility(View.GONE);
        preview.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        if(rightColumn!=null) rightColumn.addView(playerCard,0,playerNormalLp);
        hint.setText("1º OK seleciona • 2º OK abre tela cheia");
        if(currentRow!=null) currentRow.requestFocus();
        immersive();
    }

    private void openMain(){Intent in=new Intent(this,MainActivity.class);in.putExtra("show_highlights",true);startActivity(in);finish();}
    private void openCatalog(String type,String name){Intent in=new Intent(this,CatalogActivity.class);in.putExtra("type",type);in.putExtra("title",name);startActivity(in);}
    private void openDiscover(String smart,String name){Intent in=new Intent(this,DiscoverActivity.class);in.putExtra("smart",smart);in.putExtra("title",name);startActivity(in);}

    @Override public void onBackPressed(){if(fullscreen){closeFullscreen();return;}finish();}
    @Override protected void onResume(){super.onResume();immersive();try{if(player!=null)player.play();}catch(Throwable ignored){}}
    @Override protected void onPause(){try{if(player!=null)player.pause();}catch(Throwable ignored){}super.onPause();}
    @Override protected void onDestroy(){super.onDestroy();if(player!=null){try{player.release();}catch(Exception ignored){}}}
    private void immersive(){WindowCompat.setDecorFitsSystemWindows(getWindow(),false);WindowInsetsControllerCompat c=WindowCompat.getInsetsController(getWindow(),getWindow().getDecorView());c.hide(WindowInsetsCompat.Type.systemBars());c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);}
    private String clean(String v,String f){if(v==null)return f;String s=v.trim();return s.isEmpty()||"null".equalsIgnoreCase(s)?f:s;}
}
