package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class DiscoverActivity extends Activity {
    private boolean phone; private LinearLayout body; private String smart,title;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);Ui.immersive(this);phone=Ui.phone(this);
        smart=clean(getIntent().getStringExtra("smart"),"kids");title=clean(getIntent().getStringExtra("title"),smart.toUpperCase());
        setContentView(build());
        if("explore".equals(smart)) renderExplore(); else load();
    }

    private View build(){
        LinearLayout root=Ui.column(this);root.setBackground(Ui.diagonalGradient(Ui.BG_2,Ui.BG,0,this));
        root.addView(header(),new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?56:64)));
        ScrollView s=new ScrollView(this);s.setVerticalScrollBarEnabled(false);s.setFillViewport(true);
        body=Ui.column(this);body.setPadding(Ui.dp(this,phone?14:26),Ui.dp(this,10),Ui.dp(this,phone?14:26),Ui.dp(this,24));
        s.addView(Ui.centered(this,body,1480),new ScrollView.LayoutParams(-1,-2));root.addView(s,new LinearLayout.LayoutParams(-1,0,1));return root;
    }

    private View header(){
        String active="EXPLORAR";
        if("kids".equals(smart)) active="KIDS";
        else if("anime".equals(smart)) active="ANIMES";
        else if("shows".equals(smart)) active="SHOWS";
        return YellowNav.bar(this,active);
    }

    private void addNav(LinearLayout row,String label,boolean selected,Runnable run){TextView v=Ui.nav(this,label,selected);v.setOnClickListener(x->run.run());row.addView(v,new LinearLayout.LayoutParams(Ui.dp(this,phone?72:96),Ui.dp(this,44)));}

    private void renderExplore(){
        body.removeAllViews();
        TextView h=Ui.text(this,"Explorar",phone?21:28,Ui.TEXT,true);body.addView(h,new LinearLayout.LayoutParams(-1,Ui.dp(this,48)));
        TextView sub=Ui.text(this,"Escolha o que quer assistir",11,Ui.MUTED,false);body.addView(sub,new LinearLayout.LayoutParams(-1,Ui.dp(this,30)));
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        addExploreMosaic(top,"FILMES","Cinema e lançamentos","movies",2.0f,0xFF182218);
        addExploreMosaic(top,"SÉRIES","Temporadas e episódios","series",1.0f,0xFF142018);
        addExploreMosaic(top,"HOT / ADULTOS","Acesso por categoria","adult",1.0f,0xFF121A13);
        body.addView(top,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?210:285)));
        LinearLayout bottom=new LinearLayout(this);bottom.setGravity(Gravity.CENTER_VERTICAL);
        addExploreMosaic(bottom,"KIDS","Conteúdo infantil","kids",1.0f,0xFF172319);
        addExploreMosaic(bottom,"ANIME","Animes e animações","anime",1.0f,0xFF122116);
        body.addView(bottom,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?155:205)));
    }

    private void addExploreMosaic(LinearLayout row,String name,String desc,String target,float weight,int fill){
        FrameLayout card=new FrameLayout(this);card.setFocusable(true);card.setClickable(true);Ui.focus(card,this,Ui.gradient(fill,Ui.PANEL,7,this),Ui.stroke(Ui.PANEL_2,Ui.GREEN,7,this));
        LinearLayout text=Ui.column(this);text.setPadding(Ui.dp(this,18),Ui.dp(this,15),Ui.dp(this,18),Ui.dp(this,14));
        TextView n=Ui.text(this,name,phone?18:24,Ui.TEXT,true);text.addView(n,new LinearLayout.LayoutParams(-1,0,1));
        TextView d=Ui.text(this,desc,10,Ui.MUTED,false);text.addView(d,new LinearLayout.LayoutParams(-1,Ui.dp(this,28)));card.addView(text,new FrameLayout.LayoutParams(-1,-1));
        card.setOnClickListener(v->{if("adult".equals(target))startActivity(new Intent(this,AdultPinActivity.class));else if("movies".equals(target)||"series".equals(target))openCatalog("movies".equals(target)?"movie":"series",name,"");else openDiscover(target,name);});
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,weight);p.rightMargin=Ui.dp(this,7);p.bottomMargin=Ui.dp(this,7);row.addView(card,p);
    }

    private void load(){
        body.removeAllViews();body.addView(Ui.text(this,"Carregando coleções...",12,Ui.MUTED,false),new LinearLayout.LayoutParams(-1,Ui.dp(this,70)));
        ApiClient.catalog("movie",1,36,"","",smart,new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage movies){ApiClient.catalog("series",1,36,"","",smart,new ApiClient.Callback<ApiClient.CatalogPage>(){
                public void ok(ApiClient.CatalogPage series){runOnUiThread(()->{body.removeAllViews();if("kids".equals(smart)){renderKidsMosaic(movies.items,series.items);}else if("shows".equals(smart)){List<ApiClient.Item> mm=onlyMusic(movies.items),ss=onlyMusic(series.items);shelf("Shows musicais e concertos",mm,"movie");shelf("Festivais, artistas e especiais",ss,"series");if(mm.isEmpty()&&ss.isEmpty())body.addView(Ui.text(DiscoverActivity.this,"Nenhum show musical disponível",12,Ui.MUTED,false));}else if("anime".equals(smart)){List<ApiClient.Item> mm=onlyAnime(movies.items),ss=onlyAnime(series.items);shelf("Filmes de anime",mm,"movie");shelf("Séries de anime",ss,"series");if(mm.isEmpty()&&ss.isEmpty())body.addView(Ui.text(DiscoverActivity.this,"Nenhum anime disponível",12,Ui.MUTED,false));}else{shelf("Filmes",movies.items,"movie");shelf("Séries",series.items,"series");}});}
                public void error(String m){runOnUiThread(()->{body.removeAllViews();if("kids".equals(smart))renderKidsMosaic(movies.items,new ArrayList<>());else shelf("Filmes",movies.items,"movie");});}
            });}
            public void error(String m){runOnUiThread(()->{body.removeAllViews();body.addView(Ui.text(DiscoverActivity.this,"Não foi possível carregar • "+m,12,Ui.RED,false),new LinearLayout.LayoutParams(-1,Ui.dp(DiscoverActivity.this,70)));});}
        });
    }

    private void renderKidsMosaic(List<ApiClient.Item> movies,List<ApiClient.Item> series){
        ArrayList<ApiClient.Item> all=new ArrayList<>(); if(movies!=null)all.addAll(movies); if(series!=null)all.addAll(series);
        if(all.isEmpty()){body.addView(Ui.text(this,"Nenhum conteúdo Kids disponível",12,Ui.MUTED,false));return;}

        // Área Kids própria: visual infantil, colorido e diferente de Filmes/Séries.
        LinearLayout kidsHead=new LinearLayout(this); kidsHead.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo=Ui.text(this,"★ KIDS",phone?24:34,0xFFFFE000,true); logo.setGravity(Gravity.CENTER_VERTICAL);
        kidsHead.addView(logo,new LinearLayout.LayoutParams(0,Ui.dp(this,52),1));
        TextView tag=Ui.text(this,"MUNDO DA DIVERSÃO",phone?10:13,0xFF77F15A,true); tag.setGravity(Gravity.CENTER);
        tag.setBackground(Ui.round(0xFF172015,18,this)); kidsHead.addView(tag,new LinearLayout.LayoutParams(Ui.dp(this,phone?150:210),Ui.dp(this,36)));
        body.addView(kidsHead,new LinearLayout.LayoutParams(-1,Ui.dp(this,58)));

        LinearLayout quick=new LinearLayout(this); quick.setGravity(Gravity.CENTER_VERTICAL);
        addKidsCategory(quick,"☺\nTODOS",0xFFFFD54F,()->openCatalog("movie","Kids • Todos","kids"));
        addKidsCategory(quick,"★\nFAVORITOS",0xFF66E46F,()->startActivity(new Intent(this,ProfileActivity.class)));
        addKidsCategory(quick,"✦\nANIMAÇÕES",0xFFFF8A80,()->openDiscover("anime","Anime"));
        addKidsCategory(quick,"☁\nAVENTURAS",0xFF80D8FF,()->openCatalog("movie","Kids • Aventuras","kids"));
        addKidsCategory(quick,"♫\nMÚSICA",0xFFCE93D8,()->openCatalog("movie","Kids • Música","kids"));
        body.addView(quick,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?112:138)));

        LinearLayout heroRow=new LinearLayout(this); heroRow.setGravity(Gravity.CENTER_VERTICAL);
        FrameLayout hero=kidsTile(item(all,0),"DESTAQUE KIDS",0xFFFFC928,true); heroRow.addView(hero,new LinearLayout.LayoutParams(0,-1,1.75f));
        LinearLayout side=Ui.column(this); LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,-1,1f); sp.leftMargin=Ui.dp(this,8); heroRow.addView(side,sp);
        FrameLayout a=kidsTile(item(all,1),"MAIS VISTOS",0xFF67E26F,false); side.addView(a,new LinearLayout.LayoutParams(-1,0,1));
        FrameLayout b=kidsTile(item(all,2),"PARA VOCÊ",0xFF55C7FF,false); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,0,1); bp.topMargin=Ui.dp(this,8); side.addView(b,bp);
        body.addView(heroRow,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?300:390)));

        shelf("Filmes para crianças",movies==null?new ArrayList<>():movies,"movie");
        shelf("Desenhos e séries",series==null?new ArrayList<>():series,"series");
    }

    private void addKidsCategory(LinearLayout row,String label,int color,Runnable run){
        TextView b=Ui.text(this,label,phone?11:14,Color.BLACK,true); b.setGravity(Gravity.CENTER); b.setFocusable(true); b.setClickable(true);
        Ui.focus(b,this,Ui.round(color,12,this),Ui.stroke(color,Color.WHITE,12,this)); b.setOnClickListener(v->run.run());
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1); p.rightMargin=Ui.dp(this,7); row.addView(b,p);
    }

    private FrameLayout kidsTile(ApiClient.Item i,String label,int accent,boolean hero){
        FrameLayout box=new FrameLayout(this); box.setFocusable(true); box.setClickable(true); box.setClipToOutline(true);
        Ui.focus(box,this,Ui.round(Ui.PANEL,12,this),Ui.stroke(Ui.PANEL_2,accent,12,this));
        ImageView img=new ImageView(this); img.setScaleType(ImageView.ScaleType.CENTER_CROP); img.setBackgroundColor(Ui.PANEL_2); box.addView(img,new FrameLayout.LayoutParams(-1,-1)); ImageLoader.into(this,img,clean(i.backdrop,i.logo));
        View shade=new View(this); shade.setBackground(Ui.verticalGradient(Color.TRANSPARENT,Color.argb(225,0,0,0),0,this)); box.addView(shade,new FrameLayout.LayoutParams(-1,-1));
        TextView t=Ui.text(this,label,hero?17:13,Color.BLACK,true); t.setGravity(Gravity.CENTER); t.setBackground(Ui.round(accent,12,this)); FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(hero?Ui.dp(this,200):Ui.dp(this,150),Ui.dp(this,hero?48:40),Gravity.LEFT|Gravity.BOTTOM); tp.leftMargin=Ui.dp(this,12); tp.bottomMargin=Ui.dp(this,12); box.addView(t,tp);
        box.setOnClickListener(v->openItem(i)); return box;
    }

    private ApiClient.Item item(List<ApiClient.Item> x,int n){return x.get(Math.min(n,x.size()-1));}

    private FrameLayout mediaTile(ApiClient.Item i,String label,boolean hero){
        FrameLayout box=new FrameLayout(this);box.setFocusable(true);box.setClickable(true);Ui.focus(box,this,Ui.round(Ui.PANEL,4,this),Ui.stroke(Ui.PANEL_2,Ui.GREEN,4,this));
        ImageView img=new ImageView(this);img.setScaleType(ImageView.ScaleType.CENTER_CROP);img.setBackgroundColor(Ui.PANEL_2);box.addView(img,new FrameLayout.LayoutParams(-1,-1));ImageLoader.into(this,img,clean(i.backdrop,i.logo));
        View shade=new View(this);shade.setBackground(Ui.verticalGradient(Color.TRANSPARENT,Color.argb(210,0,0,0),0,this));box.addView(shade,new FrameLayout.LayoutParams(-1,-1));
        TextView t=Ui.text(this,label,hero?16:13,Ui.TEXT,true);t.setGravity(Gravity.CENTER);t.setBackgroundColor(0x99101810);FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(-1,Ui.dp(this,hero?46:38),Gravity.BOTTOM);box.addView(t,tp);
        box.setOnClickListener(v->openItem(i));return box;
    }

    private void shelf(String label,List<ApiClient.Item> items,String type){
        if(items==null||items.isEmpty())return;LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);head.addView(Ui.text(this,label,phone?17:22,Ui.TEXT,true),new LinearLayout.LayoutParams(0,Ui.dp(this,44),1));
        TextView all=Ui.ghostButton(this,"VER TODOS");all.setOnClickListener(v->{Intent in=new Intent(this,CatalogActivity.class);in.putExtra("type",type);in.putExtra("title",label+" • "+title);in.putExtra("smart",smart);startActivity(in);});head.addView(all,new LinearLayout.LayoutParams(Ui.dp(this,100),Ui.dp(this,34)));body.addView(head,new LinearLayout.LayoutParams(-1,Ui.dp(this,48)));
        HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setHorizontalScrollBarEnabled(false);LinearLayout row=new LinearLayout(this);
        for(ApiClient.Item i:items){FrameLayout card=mediaTile(i,clean(i.name,"Sem nome"),false);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(Ui.dp(this,phone?130:165),Ui.dp(this,phone?180:225));cp.rightMargin=Ui.dp(this,8);row.addView(card,cp);}hsv.addView(row);body.addView(hsv,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?185:230)));
    }

    private List<ApiClient.Item> onlyMusic(List<ApiClient.Item> src){ArrayList<ApiClient.Item> out=new ArrayList<>();if(src==null)return out;String[] keys={"music","musical","música","musica","show","concert","concerto","festival","artist","artista","acústico","acustico","tour","turnê","turne","singer","cantor","banda"};for(ApiClient.Item i:src){if(i==null)continue;String hay=(clean(i.name,"")+" "+clean(i.group,"")+" "+clean(i.synopsis,"")).toLowerCase(java.util.Locale.ROOT);for(String k:keys)if(hay.contains(k)){out.add(i);break;}}return out;}
    private List<ApiClient.Item> onlyAnime(List<ApiClient.Item> src){ArrayList<ApiClient.Item> out=new ArrayList<>();if(src==null)return out;String[] keys={"anime","animê","animes","japon","mangá","manga","shonen","shounen","seinen","isekai","otaku"};for(ApiClient.Item i:src){if(i==null)continue;String hay=(clean(i.name,"")+" "+clean(i.group,"")+" "+clean(i.synopsis,"")).toLowerCase(java.util.Locale.ROOT);for(String k:keys)if(hay.contains(k)){out.add(i);break;}}return out;}

    private void openItem(ApiClient.Item i){if(i==null)return;if("series".equals(i.type)){Intent in=new Intent(this,SeriesActivity.class);in.putExtra("title",clean(i.seriesTitle,i.name));startActivity(in);}else{Intent in=new Intent(this,DetailActivity.class);MainActivity.putItem(in,i);startActivity(in);}}
    private void openCatalog(String type,String name,String smartKey){Intent in=new Intent(this,CatalogActivity.class);in.putExtra("type",type);in.putExtra("title",name);in.putExtra("smart",smartKey);startActivity(in);}
    private void openDiscover(String key,String name){Intent in=new Intent(this,DiscoverActivity.class);in.putExtra("smart",key);in.putExtra("title",name);startActivity(in);}
    private String clean(String v,String f){if(v==null)return f;String s=v.trim();return s.isEmpty()||"null".equalsIgnoreCase(s)?f:s;}
}
