GreenPlay v16.148

Base: v16.147

- Em modo TV, quando a fonte possui canais ao vivo, o aplicativo agora abre direto na tela de TV ao vivo, seguindo mais de perto a referência aprovada.
- Quando a fonte não possui canais ao vivo, o modo TV continua abrindo na Home/Destaques para não ficar vazio.
- Mantidos: layout de TV com topo TV/Futebol/Filmes/Séries/Kids, remoção de Anime/Hot, lista de canais à esquerda, player à direita, EPG, D-pad e fullscreen sem crop.
