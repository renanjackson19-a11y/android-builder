GreenPlay v16.152

Base: v16.151

- Ajuste visual do modo TV para ficar mais próximo da referência aprovada.
- Topo com logo maior e navegação mais destacada.
- Cartões de canal reformulados com coluna de número/indicador, mini logo, nome e informação abaixo.
- Chips de categorias maiores.
- Mantidas as correções de 1 toque/1 OK e autoplay do canal.
