GreenPlay v16.151

Base: v16.150

Correção global do modo TV:
- Um único OK/Enter executa a opção focada.
- Um único toque no celular em Modo TV executa a opção, sem primeiro toque apenas para foco.
- Aplicado ao cabeçalho, categorias, canais, filmes, séries, kids, futebol, perfil e troca de servidor.
- Confirm keys tratados globalmente: DPAD_CENTER, ENTER, NUMPAD_ENTER e BUTTON_A.
- ACTION_UP do OK é consumido para evitar comportamento duplicado de alguns controles remotos.
