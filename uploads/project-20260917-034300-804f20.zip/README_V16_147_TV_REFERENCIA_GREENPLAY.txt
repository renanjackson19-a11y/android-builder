GreenPlay v16.147

Base: v16.146

Modo TV/TV Box redesenhado conforme a referencia enviada:
- Barra superior unica com logo GreenPlay, TV, Futebol, Filmes, Series e Kids.
- Anime e Hot nao aparecem no modo TV.
- Perfil, horario e indicador online ficam no canto direito.
- TV ao vivo com Lista de Canais a esquerda, categorias em chips e player grande a direita.
- Linhas de canais maiores, com numero/logo/nome/favorito e foco verde.
- Faixa de programa atual/proximo abaixo do player, temporaria e sem cobrir o video.
- EPG continua usando somente dados reais da fonte; quando nao existir, informa Sem informacao.
- Fullscreen continua sem crop/zoom da imagem do canal.
- Celular/tablet mantidos no layout original.
