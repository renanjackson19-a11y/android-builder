GreenPlay v16.153

Base: v16.152

- Tela TV refeita para aproximar estruturalmente da referência, não apenas por escala.
- Lista de canais: número, indicador, logo, nome, EPG real assíncrono e favorito.
- EPG do canal fica em painel temporário abaixo do vídeo dentro da área direita, sem cobrir a imagem.
- Categorias de canais maiores, duas predominantes visíveis por vez.
- Filmes/Séries no modo TV: categorias na esquerda + grade na direita.
- Kids no modo TV: categorias reais relacionadas a infantil/kids/família/animação, sem inventar conteúdo.
- Mantidos 1 OK/1 toque, autoplay e regras de fonte com/sem TV.
