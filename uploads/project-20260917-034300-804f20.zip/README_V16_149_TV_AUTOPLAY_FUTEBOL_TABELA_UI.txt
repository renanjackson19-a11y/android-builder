GreenPlay v16.149

Base: v16.148

- TV aparece somente quando a fonte/provedor possui canais ao vivo, igual ao celular.
- Ao entrar na tela TV em modo TV/TV Box, reproduz automaticamente o último canal assistido disponível; se não houver, o primeiro canal da lista carregada.
- Último canal salvo por provedor/fonte.
- Futebol ganhou tela própria com tabela visual de jogos e navegação por datas.
- Nenhum jogo/horário/campeonato/transmissão é inventado. Até a API real ser conectada, a tabela mostra estado vazio.
- Futebol permanece no topo mesmo se a fonte não tiver TV ao vivo; o item TV continua condicional aos canais da fonte.
- Mantidas correções anteriores de D-pad, EPG, fullscreen sem crop, estabilidade do player e layout móvel separado.
