package com.ativacao.app;

import android.Manifest;
import android.app.Activity;
import android.app.AppOpsManager;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.Context;
import android.content.ComponentName;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.PackageInfo;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.text.Editable;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class MainActivity extends Activity {
    private EditText edtLicenca;
    private TextView txtStatus;
    private ProgressBar progress;
    private Button btnAtivar;
    private Button btnApagarConfig;
    private RadioGroup grupoTipoAparelho;
    private String tipoAparelhoEscolhido = "";

    // Referências da tela atual. A configuração remota atualiza somente os componentes
    // visíveis, sem reconstruir toda a Activity e sem causar a tremida da interface.
    private ScrollView telaScrollAtual;
    private LinearLayout cardAtual;
    private ImageView logoTopoAtual;
    private TextView badgeTopoAtual;
    private TextView tituloTopoAtual;
    private TextView subtituloDinamicoAtual;
    private TextView destaqueTextoAtual;
    private Button btnPermissaoAtual;
    private RadioButton opcaoAndroidAtual;
    private RadioButton opcaoTvBoxAtual;
    private String telaAtual = "";

    private volatile boolean ativacaoEmAndamento = false;
    private volatile int progressoGlobal = 0;
    private volatile boolean ativacaoBloqueadaPorNotificacao = false;
    private volatile String mensagemBloqueioNotificacao = "";
    private volatile long ultimaConsultaNotificacao = 0L;
    private volatile boolean dialogoNotificacaoAberto = false;
    private boolean primeiraRetomada = true;
    private volatile String baseOrigemAtivacao = Config.BASE_URL;
    private volatile String avisoSalvamentoConfig = "";
    private boolean aguardandoRetornoPermissao = false;
    private boolean permissaoRuntimeJaSolicitada = false;
    private String nomeOpcaoAndroid = "TV Android / Celular";
    private String nomeOpcaoTvBox = "TV Box / Fire Stick / MXQ";
    private String textoEscolhaAparelho = "Escolha onde será instalado:";
    private volatile boolean atualizacaoObrigatoriaPendente = false;
    private volatile boolean dialogoAtualizacaoAberto = false;
    private volatile int versaoRemotaAtivador = 0;

    // A verificação acontece antes da tela de licença em cada abertura do aplicativo.
    private volatile boolean verificandoRoot = false;
    private volatile boolean verificacaoRootConcluida = false;
    private volatile boolean rootDetectado = false;
    private volatile boolean rootGateLiberado = false;
    private volatile boolean removendoRoot = false;
    private volatile boolean aguardandoAutorizacaoRoot = false;
    private volatile boolean retornoGerenciadorEmProcessamento = false;
    private String pacoteGerenciadorAberto = "";
    private RootInfo ultimaInfoRoot = new RootInfo();
    private Button btnRemoverRoot;
    private TextView txtRootStatus;
    private ProgressBar progressoRoot;
    private final Handler rootHandler = new Handler(Looper.getMainLooper());

    private int COR_PRINCIPAL = Color.rgb(235, 30, 45);
    private int COR_PRINCIPAL_ESCURO = Color.rgb(135, 12, 22);
    private final int FUNDO = Color.rgb(12, 10, 16);
    private final int TEXTO_CLARO = Color.rgb(245, 246, 250);
    private final int TEXTO_SUAVE = Color.rgb(190, 190, 202);

    private String appTitulo = "Ativador UnitvFree";
    private String badgeTexto = "DUBAI DIGITAL";
    private String destaqueTexto = "2 painel em 1";
    private String appSubtitulo = "Digite sua licença para ativar seu acesso.";
    private String textoPermissao = "Antes de usar sua licença, toque em LIBERAR PERMISSÕES. O ativador vai abrir a tela correta do aparelho; marque Permitir e volte para o app.";
    private String textoBotaoPermissao = "LIBERAR PERMISSÕES";
    private String textoBotaoAtivar = "ATIVAR LICENÇA";
    private String msgPronto = "Pronto para ativar. A configuração será instalada automaticamente no aparelho.";
    private String logoUrl = "";
    private String fundoUrl = "";
    private String propagandaTexto = "";
    private String propagandaLink = "";
    private String propagandaBotao = "ACESSAR AGORA";
    private volatile int fundoCarregamentoSeq = 0;

    private String suporteSessaoId = "";
    private String suporteCodigoAtual = "";
    private Handler suporteHandler = new Handler(Looper.getMainLooper());
    private boolean suporteAtivo = false;

    private static final String PREFS = "ativador_prefs";
    private static final String KEY_PERMISSOES_CONFIRMADAS = "permissoes_confirmadas";
    private static final String KEY_ULTIMA_NOTIFICACAO = "ultima_notificacao_gerador";
    private static final String KEY_PENDING_UNITV_INSTALL = "pending_unitv_install_package";
    private static final String KEY_UNITV_PERMISSION_PACKAGE = "unitv_permission_package";
    private boolean aguardandoRetornoPermissaoUnitv = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        instalarProtecaoContraFechamento();
        try {
            getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
            carregarConfigDoPainel();
            consultarNotificacaoDoPainel(false);
            mostrarTelaCorreta();
            verificarAtualizacaoAtivador();
        } catch (Throwable erro) {
            mostrarTelaRecuperacao("Não foi possível iniciar uma parte do ativador neste aparelho.", erro);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        try {
            // Primeiro trata o retorno do instalador do UniTV e da tela de acesso a arquivos.
            // Isso precisa ocorrer antes do fluxo de permissões do próprio ativador.
            if (processarRetornoPermissaoUnitv()) return;
            if (processarRetornoInstalacaoUnitv()) return;

            // onCreate já montou a primeira tela. Evita montar tudo novamente no primeiro
            // onResume, o que causava uma pequena tremida em aparelhos mais lentos.
            if (primeiraRetomada) {
                primeiraRetomada = false;
                consultarNotificacaoDoPainel(false);
                return;
            }
            if (aguardandoRetornoPermissao) {
                aguardandoRetornoPermissao = false;
                // TVs e projetores podem demorar para atualizar o estado da permissão.
                new Handler(Looper.getMainLooper()).postDelayed(this::verificarPermissoesEContinuar, 700);
            } else if (aguardandoAutorizacaoRoot && !retornoGerenciadorEmProcessamento) {
                retornoGerenciadorEmProcessamento = true;
                rootHandler.postDelayed(this::verificarAutorizacaoAoRetornar, 700);
            } else {
                mostrarTelaCorreta();
            }
            consultarNotificacaoDoPainel(false);
        } catch (Throwable erro) {
            mostrarTelaRecuperacao("O ativador encontrou uma incompatibilidade neste aparelho.", erro);
        }
    }

    private void carregarConfigDoPainel() {
        new Thread(() -> {
            try {
                String json = httpGetDireto(adicionarCacheBuster(Config.API_APP_CONFIG));
                if (json == null || json.trim().isEmpty()) return;
                JSONObject obj = new JSONObject(json);
                if (!"ok".equalsIgnoreCase(obj.optString("status", "ok"))) return;

                appTitulo = valorNaoVazio(obj.optString("titulo", ""), appTitulo);
                badgeTexto = valorNaoVazio(obj.optString("badge_texto", ""), badgeTexto);
                destaqueTexto = valorNaoVazio(obj.optString("destaque_texto", ""), destaqueTexto);
                appSubtitulo = valorNaoVazio(obj.optString("subtitulo", ""), appSubtitulo);
                textoPermissao = valorNaoVazio(obj.optString("texto_permissao", ""), textoPermissao);
                textoBotaoPermissao = valorNaoVazio(obj.optString("botao_permissao", ""), textoBotaoPermissao);
                textoBotaoAtivar = valorNaoVazio(obj.optString("botao_ativar", ""), textoBotaoAtivar);
                msgPronto = valorNaoVazio(obj.optString("mensagem_pronto", ""), msgPronto);
                textoEscolhaAparelho = valorNaoVazio(obj.optString("texto_escolha_aparelho", ""), textoEscolhaAparelho);

                String imagemPainel = valorNaoVazio(obj.optString("logo_url", ""), obj.optString("foto_url", ""));
                logoUrl = normalizarUrl(imagemPainel);
                fundoUrl = normalizarUrl(valorNaoVazio(obj.optString("fundo_url", ""), obj.optString("background_url", "")));

                boolean propagandaLigada = obj.optInt("propaganda_ativa", 0) == 1;
                if (propagandaLigada) {
                    propagandaTexto = obj.optString("propaganda_texto", "");
                    propagandaLink = normalizarUrl(obj.optString("propaganda_link", ""));
                    propagandaBotao = valorNaoVazio(obj.optString("propaganda_botao", ""), propagandaBotao);
                } else {
                    propagandaTexto = "";
                    propagandaLink = "";
                }

                nomeOpcaoAndroid = valorNaoVazio(obj.optString("opcao_android_label",
                        obj.optString("nome_tv_android", obj.optString("opcao1_nome", obj.optString("opcao_1", obj.optString("opcao1", ""))))), nomeOpcaoAndroid);
                nomeOpcaoTvBox = valorNaoVazio(obj.optString("opcao_box_label",
                        obj.optString("nome_tv_box", obj.optString("opcao2_nome", obj.optString("opcao_2", obj.optString("opcao2", ""))))), nomeOpcaoTvBox);

                String cor = obj.optString("cor_principal", "").trim();
                if (cor.matches("#?[0-9A-Fa-f]{6}")) {
                    if (!cor.startsWith("#")) cor = "#" + cor;
                    COR_PRINCIPAL = Color.parseColor(cor);
                    COR_PRINCIPAL_ESCURO = escurecer(COR_PRINCIPAL);
                }
                runOnUiThread(this::aplicarConfigNaTelaAtual);
            } catch (Exception ignored) {
                // A tela mantém os valores padrão se a API remota estiver indisponível.
            }
        }, "nexo-app-config").start();
    }

    private int escurecer(int cor) {
        int r = Math.max(0, (int)(Color.red(cor) * 0.55));
        int g = Math.max(0, (int)(Color.green(cor) * 0.55));
        int b = Math.max(0, (int)(Color.blue(cor) * 0.55));
        return Color.rgb(r, g, b);
    }

    private String valorNaoVazio(String valor, String padrao) {
        if (valor == null || valor.trim().isEmpty()) return padrao == null ? "" : padrao;
        return valor.trim();
    }

    private void aplicarConfigNaTelaAtual() {
        try {
            if (telaScrollAtual != null) configurarFundo(telaScrollAtual);
            if (cardAtual != null) {
                cardAtual.setBackground(criarBorda(Color.argb(188, 4, 7, 14),
                        comAlpha(COR_PRINCIPAL, 125), dp(28), dp(1)));
            }
            if (badgeTopoAtual != null) badgeTopoAtual.setText(badgeTexto);
            if (tituloTopoAtual != null) {
                tituloTopoAtual.setText(appTitulo);
                tituloTopoAtual.setTextColor(TEXTO_CLARO);
            }
            if (destaqueTextoAtual != null) destaqueTextoAtual.setText(destaqueTexto);
            if (logoTopoAtual != null) {
                if (!logoUrl.isEmpty()) carregarImagemComFallback(logoTopoAtual, logoUrl);
                else logoTopoAtual.setImageResource(com.ativacao.app.R.drawable.ic_launcher);
            }
            if (subtituloDinamicoAtual != null) {
                if ("permissoes".equals(telaAtual)) subtituloDinamicoAtual.setText(textoPermissao);
                else if ("ativacao".equals(telaAtual)) subtituloDinamicoAtual.setText(appSubtitulo);
            }
            if (btnPermissaoAtual != null) {
                btnPermissaoAtual.setText(textoBotaoPermissao);
                btnPermissaoAtual.setBackground(criarGradienteBotao());
            }
            if (btnAtivar != null) {
                btnAtivar.setText(textoBotaoAtivar);
                btnAtivar.setBackground(criarGradienteBotao());
            }
            if (opcaoAndroidAtual != null) opcaoAndroidAtual.setText(nomeOpcaoAndroid);
            if (opcaoTvBoxAtual != null) opcaoTvBoxAtual.setText(nomeOpcaoTvBox);
            if (txtStatus != null && !ativacaoEmAndamento) txtStatus.setText(msgPronto);
        } catch (Throwable ignored) {}
    }

    private void consultarNotificacaoDoPainel(boolean forcar) {
        // O painel NEXO atual ainda não possui API de notificações do ativador.
        // Não consultar nem usar bloqueios do Gerador/painel antigo.
        ativacaoBloqueadaPorNotificacao = false;
        mensagemBloqueioNotificacao = "";
    }

    private void mostrarNotificacaoPainel(String id, String titulo, String mensagem, String textoBotao,
                                          String linkBotao, boolean mostrarUmaVez, boolean bloquear) {
        if (!atividadeDisponivel() || dialogoNotificacaoAberto) return;
        dialogoNotificacaoAberto = true;

        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle(titulo)
                .setMessage(mensagem.isEmpty() ? "Existe um novo comunicado no Gerador Config." : mensagem)
                .setCancelable(!bloquear)
                .setPositiveButton(textoBotao, (d, w) -> {
                    if (!linkBotao.isEmpty()) {
                        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(linkBotao))); }
                        catch (Throwable ignored) {}
                    }
                });
        if (!bloquear) builder.setNegativeButton("FECHAR", null);

        AlertDialog dialog = builder.create();
        dialog.setOnDismissListener(d -> {
            dialogoNotificacaoAberto = false;
            if (mostrarUmaVez && !id.isEmpty()) {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                        .putString(KEY_ULTIMA_NOTIFICACAO, id).apply();
            }
        });
        dialog.show();
    }

    private boolean isTV() {
        int mode = getResources().getConfiguration().uiMode & Configuration.UI_MODE_TYPE_MASK;
        return mode == Configuration.UI_MODE_TYPE_TELEVISION
                || mode == Configuration.UI_MODE_TYPE_APPLIANCE
                || !getPackageManager().hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN);
    }

    private void mostrarTelaCorreta() {
        // Ordem original obrigatória: permissões primeiro, root depois e licença por último.
        if (!permissoesLiberadas() || !permissoesConfirmadas()) {
            montarTelaPermissoes();
            return;
        }

        // O root só é verificado depois que todas as permissões do aplicativo foram liberadas.
        if (!verificacaoRootConcluida || rootDetectado || !rootGateLiberado) {
            montarTelaRoot();
            if (!verificandoRoot && !removendoRoot && !verificacaoRootConcluida) iniciarVerificacaoRoot();
            return;
        }

        montarTelaAtivacao();
    }

    private boolean permissoesConfirmadas() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        return prefs.getBoolean(KEY_PERMISSOES_CONFIRMADAS, false);
    }

    private void confirmarPermissoes() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_PERMISSOES_CONFIRMADAS, true).apply();
    }

    private void configurarFundo(ScrollView scroll) {
        final int carregamentoId = ++fundoCarregamentoSeq;
        GradientDrawable fundo = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.rgb(5, 9, 19), FUNDO, Color.rgb(15, 5, 10)});
        scroll.setBackground(fundo);
        scroll.setFillViewport(true);

        final String urlAtual = fundoUrl == null ? "" : fundoUrl.trim();
        if (!urlAtual.isEmpty()) {
            new Thread(() -> {
                try {
                    Bitmap bmp = baixarBitmap(adicionarCacheBuster(urlAtual));
                    if (bmp != null) runOnUiThread(() -> {
                        if (carregamentoId != fundoCarregamentoSeq || scroll != telaScrollAtual) return;

                        Drawable imagemPreenchida = new CenterCropDrawable(bmp);
                        GradientDrawable overlay = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                                new int[]{Color.argb(105, 2, 6, 15), Color.argb(155, 3, 6, 13), Color.argb(145, 12, 3, 8)});
                        LayerDrawable camadas = new LayerDrawable(new Drawable[]{imagemPreenchida, overlay});
                        scroll.setBackground(camadas);
                        scroll.invalidate();
                    });
                } catch (Exception ignored) {}
            }, "background-cover-load").start();
        }
    }

    /**
     * Drawable que recorta a imagem no centro e ocupa 100% dos limites da tela,
     * equivalente ao centerCrop. Evita a imagem pequena/centralizada em aparelhos
     * com densidades e proporções diferentes.
     */
    private static final class CenterCropDrawable extends Drawable {
        private final Bitmap bitmap;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
        private final Rect origem = new Rect();
        private final Rect destino = new Rect();

        CenterCropDrawable(Bitmap bitmap) {
            this.bitmap = bitmap;
        }

        @Override
        public void draw(Canvas canvas) {
            if (bitmap == null || bitmap.isRecycled()) return;
            Rect bounds = getBounds();
            if (bounds.width() <= 0 || bounds.height() <= 0) return;

            int bw = bitmap.getWidth();
            int bh = bitmap.getHeight();
            float escala = Math.max(bounds.width() / (float) bw, bounds.height() / (float) bh);
            int larguraVisivel = Math.max(1, Math.round(bounds.width() / escala));
            int alturaVisivel = Math.max(1, Math.round(bounds.height() / escala));
            int esquerda = Math.max(0, (bw - larguraVisivel) / 2);
            int topo = Math.max(0, (bh - alturaVisivel) / 2);

            origem.set(esquerda, topo,
                    Math.min(bw, esquerda + larguraVisivel),
                    Math.min(bh, topo + alturaVisivel));
            destino.set(bounds);
            canvas.drawBitmap(bitmap, origem, destino, paint);
        }

        @Override public void setAlpha(int alpha) { paint.setAlpha(alpha); }
        @Override public void setColorFilter(android.graphics.ColorFilter colorFilter) { paint.setColorFilter(colorFilter); }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
        @Override public int getIntrinsicWidth() { return -1; }
        @Override public int getIntrinsicHeight() { return -1; }
    }

    private LinearLayout criarContainer(ScrollView scroll) {
        telaScrollAtual = scroll;
        configurarFundo(scroll);
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setGravity(Gravity.CENTER);
        outer.setMinimumHeight(getResources().getDisplayMetrics().heightPixels);
        outer.setPadding(dp(isTV() ? 34 : 12), dp(isTV() ? 26 : 22), dp(isTV() ? 34 : 12), dp(isTV() ? 26 : 22));
        scroll.addView(outer, new ScrollView.LayoutParams(-1, -1));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(isTV() ? 38 : 22), dp(isTV() ? 30 : 24), dp(isTV() ? 38 : 22), dp(26));
        root.setBackground(criarBorda(Color.argb(188, 4, 7, 14), comAlpha(COR_PRINCIPAL, 125), dp(28), dp(1)));
        cardAtual = root;
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(isTV() ? dp(760) : -1, -2);
        rp.gravity = Gravity.CENTER_HORIZONTAL;
        outer.addView(root, rp);
        return root;
    }

    private void adicionarTopo(LinearLayout root) {
        ImageView logo = new ImageView(this);
        logoTopoAtual = logo;
        logo.setAdjustViewBounds(true);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams lpLogo = new LinearLayout.LayoutParams(dp(isTV()?150:110), dp(isTV()?90:70));
        lpLogo.gravity = Gravity.CENTER_HORIZONTAL;
        lpLogo.setMargins(0, 0, 0, dp(12));
        root.addView(logo, lpLogo);
        if (!logoUrl.isEmpty()) carregarImagemComFallback(logo, logoUrl); else logo.setImageResource(com.ativacao.app.R.drawable.ic_launcher);

        TextView badge = new TextView(this);
        badgeTopoAtual = badge;
        badge.setText(badgeTexto);
        badge.setTextColor(Color.WHITE);
        badge.setTextSize(isTV() ? 16 : 13);
        badge.setTypeface(Typeface.DEFAULT_BOLD);
        badge.setGravity(Gravity.CENTER);
        badge.setLetterSpacing(0.10f);
        badge.setPadding(dp(14), dp(8), dp(14), dp(8));
        badge.setBackground(criarBorda(Color.argb(70, 255, 40, 55), COR_PRINCIPAL, dp(26), dp(1)));
        LinearLayout.LayoutParams badgeParams = new LinearLayout.LayoutParams(-2, -2);
        badgeParams.gravity = Gravity.CENTER_HORIZONTAL;
        badgeParams.setMargins(0, 0, 0, dp(18));
        root.addView(badge, badgeParams);

        TextView titulo = new TextView(this);
        tituloTopoAtual = titulo;
        titulo.setText(appTitulo);
        titulo.setTextColor(TEXTO_CLARO);
        titulo.setTextSize(isTV() ? 42 : 32);
        titulo.setTypeface(Typeface.DEFAULT_BOLD);
        titulo.setGravity(Gravity.CENTER);
        titulo.setLineSpacing(0, 0.96f);
        root.addView(titulo, new LinearLayout.LayoutParams(-1, -2));
    }

    private void adicionarPropaganda(LinearLayout root) {
        if ((propagandaTexto == null || propagandaTexto.trim().isEmpty()) && (propagandaLink == null || propagandaLink.trim().isEmpty())) return;

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(dp(16), dp(14), dp(16), dp(14));
        box.setBackground(criarBorda(Color.argb(90, 255, 255, 255), COR_PRINCIPAL, dp(16), dp(1)));

        TextView txt = new TextView(this);
        txt.setText(propagandaTexto == null || propagandaTexto.trim().isEmpty() ? "Acesse nossa propaganda" : propagandaTexto.trim());
        txt.setTextColor(Color.WHITE);
        txt.setTextSize(isTV() ? 18 : 15);
        txt.setTypeface(Typeface.DEFAULT_BOLD);
        txt.setGravity(Gravity.CENTER);
        txt.setPadding(0, 0, 0, dp(10));
        box.addView(txt, new LinearLayout.LayoutParams(-1, -2));

        if (propagandaLink != null && !propagandaLink.trim().isEmpty()) {
            Button btn = criarBotao(propagandaBotao == null || propagandaBotao.trim().isEmpty() ? "ACESSAR AGORA" : propagandaBotao.trim());
            btn.setTextSize(isTV() ? 17 : 14);
            box.addView(btn, new LinearLayout.LayoutParams(-1, dp(isTV() ? 58 : 48)));
            btn.setOnClickListener(v -> abrirPropaganda());
            box.setOnClickListener(v -> abrirPropaganda());
            box.setFocusable(true);
        }

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(18), 0, dp(6));
        root.addView(box, lp);
    }


    private void montarTelaSuporteRemoto() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = criarContainer(scroll);
        adicionarTopo(root);

        TextView desc = new TextView(this);
        desc.setText("Digite o código de suporte que o atendente gerou no painel. O suporte só inicia depois que você aceitar.");
        desc.setTextColor(TEXTO_SUAVE);
        desc.setTextSize(isTV() ? 20 : 16);
        desc.setGravity(Gravity.CENTER);
        desc.setPadding(dp(6), 0, dp(6), dp(18));
        root.addView(desc, new LinearLayout.LayoutParams(-1, -2));

        TvEditText edtCodigo = new TvEditText(this);
        edtCodigo.setHint("Código de suporte");
        edtCodigo.setTextColor(Color.WHITE);
        edtCodigo.setHintTextColor(Color.rgb(150,145,154));
        edtCodigo.setTextSize(isTV()?28:22);
        edtCodigo.setGravity(Gravity.CENTER);
        edtCodigo.setSingleLine(true);
        edtCodigo.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        edtCodigo.setFilters(new InputFilter[]{new InputFilter.LengthFilter(6)});
        edtCodigo.setBackground(criarBorda(Color.argb(65,120,10,20), COR_PRINCIPAL, dp(18), dp(1)));
        root.addView(edtCodigo, new LinearLayout.LayoutParams(-1, dp(isTV()?78:66)));

        TextView aviso = new TextView(this);
        aviso.setText("Você pode encerrar o suporte a qualquer momento. O suporte permite comandos dentro do ativador e abertura das telas de permissão do Android.");
        aviso.setTextColor(TEXTO_SUAVE);
        aviso.setTextSize(isTV()?16:13);
        aviso.setGravity(Gravity.CENTER);
        aviso.setPadding(0, dp(14), 0, dp(14));
        root.addView(aviso, new LinearLayout.LayoutParams(-1, -2));

        Button entrar = criarBotao("CONECTAR E ACEITAR SUPORTE");
        root.addView(entrar, new LinearLayout.LayoutParams(-1, dp(isTV()?68:58)));
        entrar.setOnClickListener(v -> conectarSuporte(edtCodigo.getText().toString().trim()));
        configurarTecladoTv(edtCodigo, entrar, () -> conectarSuporte(edtCodigo.getText().toString().trim()));
        entrar.requestFocus();

        Button voltar = criarBotao("VOLTAR");
        voltar.setBackground(criarBorda(Color.argb(90,20,20,28), COR_PRINCIPAL, dp(16), dp(1)));
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-1, dp(isTV()?58:50));
        vp.setMargins(0, dp(12), 0, 0);
        root.addView(voltar, vp);
        voltar.setOnClickListener(v -> mostrarTelaCorreta());

        setContentView(scroll);
    }

    private void conectarSuporte(String codigo) {
        if (!codigo.matches("\\d{6}")) {
            Toast.makeText(this, "Digite o código de 6 números.", Toast.LENGTH_LONG).show();
            return;
        }
        Toast.makeText(this, "Conectando suporte...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            try {
                String androidId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
                String aparelho = Build.MANUFACTURER + " " + Build.MODEL;
                String url = Config.API_SUPORTE + "?action=aceitar&codigo=" + URLEncoder.encode(codigo, "UTF-8")
                        + "&device=" + URLEncoder.encode(aparelho, "UTF-8")
                        + "&device_id=" + URLEncoder.encode(androidId == null ? "" : androidId, "UTF-8")
                        + "&android=" + URLEncoder.encode(String.valueOf(Build.VERSION.SDK_INT), "UTF-8")
                        + "&tipo_aparelho=" + URLEncoder.encode(isTV() ? "tv" : "mobile", "UTF-8");
                JSONObject obj = new JSONObject(httpGet(url));
                if (!"ok".equalsIgnoreCase(obj.optString("status"))) {
                    runOnUiThread(() -> Toast.makeText(this, obj.optString("mensagem", "Código não encontrado ou expirado."), Toast.LENGTH_LONG).show());
                    return;
                }
                suporteSessaoId = obj.optString("sessao_id", "");
                suporteCodigoAtual = codigo;
                suporteAtivo = true;
                runOnUiThread(() -> {
                    Toast.makeText(this, "Suporte conectado. Aguarde o atendente.", Toast.LENGTH_LONG).show();
                    iniciarPollSuporte();
                    mostrarTelaCorreta();
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Erro no suporte: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    private void iniciarPollSuporte() {
        suporteHandler.removeCallbacksAndMessages(null);
        suporteHandler.postDelayed(new Runnable() {
            @Override public void run() {
                if (!suporteAtivo || suporteSessaoId == null || suporteSessaoId.isEmpty()) return;
                consultarComandosSuporte();
                suporteHandler.postDelayed(this, 3000);
            }
        }, 1200);
    }

    private void consultarComandosSuporte() {
        new Thread(() -> {
            try {
                String tela = edtLicenca == null ? "permissoes" : "licenca";
                String url = Config.API_SUPORTE + "?action=poll&sessao_id=" + URLEncoder.encode(suporteSessaoId, "UTF-8")
                        + "&tela=" + URLEncoder.encode(tela, "UTF-8")
                        + "&permissoes=" + URLEncoder.encode(permissoesLiberadas() ? "sim" : "nao", "UTF-8");
                JSONObject obj = new JSONObject(httpGet(url));
                String status = obj.optString("status", "");
                if ("encerrado".equalsIgnoreCase(status)) {
                    suporteAtivo = false;
                    runOnUiThread(() -> Toast.makeText(this, "Suporte encerrado.", Toast.LENGTH_LONG).show());
                    return;
                }
                String cmd = obj.optString("comando", "");
                String msg = obj.optString("mensagem", "");
                String lic = obj.optString("licenca", "");
                if (cmd == null || cmd.trim().isEmpty()) return;
                runOnUiThread(() -> executarComandoSuporte(cmd, msg, lic));
            } catch (Exception ignored) {}
        }).start();
    }

    private void executarComandoSuporte(String cmd, String msg, String licenca) {
        if (msg != null && !msg.trim().isEmpty()) Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
        if ("abrir_permissoes".equals(cmd)) {
            montarTelaPermissoes();
            abrirPermissoesNecessarias();
        } else if ("abrir_ativacao".equals(cmd)) {
            if (permissoesLiberadas()) confirmarPermissoes();
            montarTelaAtivacao();
        } else if ("preencher_licenca".equals(cmd)) {
            if (permissoesLiberadas()) confirmarPermissoes();
            montarTelaAtivacao();
            if (edtLicenca != null && licenca != null) edtLicenca.setText(licenca);
        } else if ("ativar_licenca".equals(cmd)) {
            if (permissoesLiberadas()) confirmarPermissoes();
            montarTelaAtivacao();
            if (edtLicenca != null && licenca != null && licenca.matches("\\d{11}")) edtLicenca.setText(licenca);
            if (edtLicenca != null) ativar();
        } else if ("mensagem".equals(cmd)) {
            // Mensagem já foi mostrada acima.
        } else if ("encerrar".equals(cmd)) {
            suporteAtivo = false;
            Toast.makeText(this, "Suporte encerrado.", Toast.LENGTH_LONG).show();
        }
    }

    private void abrirPropaganda() {
        try {
            if (propagandaLink == null || propagandaLink.trim().isEmpty()) return;
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(propagandaLink.trim()));
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível abrir o link da propaganda.", Toast.LENGTH_LONG).show();
        }
    }

    private void mostrarTelaPermissoes() {
        montarTelaPermissoes();
    }

    private void montarTelaPermissoes() {
        telaAtual = "permissoes";
        subtituloDinamicoAtual = null;
        btnPermissaoAtual = null;
        opcaoAndroidAtual = null;
        opcaoTvBoxAtual = null;
        btnAtivar = null;
        txtStatus = null;
        progress = null;
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = criarContainer(scroll);
        adicionarTopo(root);

        TextView subtitulo = new TextView(this);
        subtituloDinamicoAtual = subtitulo;
        subtitulo.setText(textoPermissao);
        subtitulo.setTextColor(TEXTO_SUAVE);
        subtitulo.setTextSize(isTV() ? 20 : 16);
        subtitulo.setGravity(Gravity.CENTER);
        subtitulo.setPadding(dp(6), 0, dp(6), dp(18));
        root.addView(subtitulo, new LinearLayout.LayoutParams(-1, -2));

        TextView lista = new TextView(this);
        lista.setText(statusPermissoesTexto());
        lista.setTextColor(Color.WHITE);
        lista.setTextSize(isTV() ? 18 : 15);
        lista.setPadding(dp(18), dp(16), dp(18), dp(16));
        lista.setBackground(criarBorda(Color.argb(85, 30, 35, 50), Color.argb(120, 255, 255, 255), dp(16), dp(1)));
        root.addView(lista, new LinearLayout.LayoutParams(-1, -2));

        Button btn = criarBotao(textoBotaoPermissao);
        btnPermissaoAtual = btn;
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(isTV() ? 70 : 62));
        bp.setMargins(0, dp(20), 0, dp(12));
        root.addView(btn, bp);
        btn.setOnClickListener(v -> abrirPermissoesNecessarias());
        btn.requestFocus();

        Button atualizar = criarBotao("JÁ LIBEREI, VERIFICAR AGORA");
        atualizar.setBackground(criarBorda(Color.argb(90, 20, 20, 28), COR_PRINCIPAL, dp(16), dp(1)));
        root.addView(atualizar, new LinearLayout.LayoutParams(-1, dp(isTV() ? 62 : 54)));
        atualizar.setOnClickListener(v -> verificarPermissoesEContinuar());

        adicionarPropaganda(root);

        setContentView(scroll);
    }

    private void montarTelaAtivacao() {
        telaAtual = "ativacao";
        subtituloDinamicoAtual = null;
        btnPermissaoAtual = null;
        opcaoAndroidAtual = null;
        opcaoTvBoxAtual = null;
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = criarContainer(scroll);
        adicionarTopo(root);

        TextView subtitulo = new TextView(this);
        subtituloDinamicoAtual = subtitulo;
        subtitulo.setText(appSubtitulo);
        subtitulo.setTextColor(TEXTO_SUAVE);
        subtitulo.setTextSize(isTV() ? 20 : 16);
        subtitulo.setGravity(Gravity.CENTER);
        subtitulo.setPadding(dp(8), 0, dp(8), dp(24));
        root.addView(subtitulo, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout destaqueBox = new LinearLayout(this);
        destaqueBox.setOrientation(LinearLayout.HORIZONTAL);
        destaqueBox.setGravity(Gravity.CENTER_VERTICAL);
        destaqueBox.setPadding(dp(18), dp(16), dp(18), dp(16));
        destaqueBox.setBackground(criarBorda(Color.argb(125, 7, 11, 21), comAlpha(COR_PRINCIPAL, 155), dp(20), dp(1)));

        TextView destaqueIcone = new TextView(this);
        destaqueIcone.setText("▣");
        destaqueIcone.setTextColor(COR_PRINCIPAL);
        destaqueIcone.setTextSize(isTV() ? 32 : 24);
        destaqueIcone.setTypeface(Typeface.DEFAULT_BOLD);
        destaqueIcone.setGravity(Gravity.CENTER);
        destaqueBox.addView(destaqueIcone, new LinearLayout.LayoutParams(dp(46), -2));

        View divisor = new View(this);
        divisor.setBackgroundColor(Color.argb(90, 255, 255, 255));
        LinearLayout.LayoutParams divisorParams = new LinearLayout.LayoutParams(dp(1), dp(isTV() ? 50 : 42));
        divisorParams.setMargins(dp(8), 0, dp(14), 0);
        destaqueBox.addView(divisor, divisorParams);

        TextView destaque = new TextView(this);
        destaqueTextoAtual = destaque;
        destaque.setText(destaqueTexto);
        destaque.setTextColor(TEXTO_CLARO);
        destaque.setTextSize(isTV() ? 22 : 18);
        destaque.setTypeface(Typeface.DEFAULT_BOLD);
        destaque.setGravity(Gravity.CENTER_VERTICAL);
        destaqueBox.addView(destaque, new LinearLayout.LayoutParams(0, -2, 1));

        LinearLayout.LayoutParams destaqueParams = new LinearLayout.LayoutParams(-1, -2);
        destaqueParams.setMargins(0, 0, 0, dp(16));
        root.addView(destaqueBox, destaqueParams);

        LinearLayout inputBox = new LinearLayout(this);
        inputBox.setOrientation(LinearLayout.HORIZONTAL);
        inputBox.setGravity(Gravity.CENTER_VERTICAL);
        inputBox.setPadding(dp(18), dp(10), dp(18), dp(10));
        inputBox.setBackground(criarBorda(Color.argb(155, 5, 8, 15), comAlpha(COR_PRINCIPAL, 190), dp(20), dp(1)));

        TextView lock = new TextView(this);
        lock.setText("#");
        lock.setTextColor(COR_PRINCIPAL);
        lock.setTextSize(isTV() ? 34 : 27);
        lock.setTypeface(Typeface.DEFAULT_BOLD);
        lock.setGravity(Gravity.CENTER);
        inputBox.addView(lock, new LinearLayout.LayoutParams(dp(46), -1));

        edtLicenca = new TvEditText(this);
        edtLicenca.setHint("Código de 11 dígitos");
        edtLicenca.setTextColor(Color.WHITE);
        edtLicenca.setHintTextColor(Color.rgb(150, 145, 154));
        edtLicenca.setTextSize(isTV() ? 29 : 22);
        edtLicenca.setGravity(Gravity.CENTER);
        edtLicenca.setSingleLine(true);
        edtLicenca.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        edtLicenca.setFilters(new InputFilter[]{new InputFilter.LengthFilter(11)});
        edtLicenca.setBackgroundColor(Color.TRANSPARENT);
        inputBox.addView(edtLicenca, new LinearLayout.LayoutParams(0, -2, 1));

        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(-1, dp(isTV() ? 88 : 74));
        inputParams.setMargins(0, 0, 0, dp(10));
        root.addView(inputBox, inputParams);

        grupoTipoAparelho = new RadioGroup(this);
        grupoTipoAparelho.setOrientation(RadioGroup.VERTICAL);
        grupoTipoAparelho.setVisibility(View.GONE);
        grupoTipoAparelho.setPadding(dp(12), dp(6), dp(12), dp(10));
        grupoTipoAparelho.setBackground(criarBorda(Color.argb(55, 255, 255, 255), Color.argb(90, 255, 255, 255), dp(16), dp(1)));

        TextView escolhaTitulo = new TextView(this);
        escolhaTitulo.setText(textoEscolhaAparelho);
        escolhaTitulo.setTextColor(TEXTO_CLARO);
        escolhaTitulo.setTextSize(isTV() ? 18 : 14);
        escolhaTitulo.setTypeface(Typeface.DEFAULT_BOLD);
        escolhaTitulo.setGravity(Gravity.CENTER);
        escolhaTitulo.setPadding(0, 0, 0, dp(6));
        grupoTipoAparelho.addView(escolhaTitulo, new RadioGroup.LayoutParams(-1, -2));

        RadioButton opcaoAndroid = criarOpcaoTipo(1001, nomeOpcaoAndroid);
        RadioButton opcaoTvBox = criarOpcaoTipo(1002, nomeOpcaoTvBox);
        opcaoAndroidAtual = opcaoAndroid;
        opcaoTvBoxAtual = opcaoTvBox;
        grupoTipoAparelho.addView(opcaoAndroid);
        grupoTipoAparelho.addView(opcaoTvBox);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1, -2);
        gp.setMargins(0, 0, 0, dp(14));
        root.addView(grupoTipoAparelho, gp);

        grupoTipoAparelho.setOnCheckedChangeListener((g, checkedId) -> {
            if (checkedId == 1001) tipoAparelhoEscolhido = "android";
            else if (checkedId == 1002) tipoAparelhoEscolhido = "tv_box";
        });

        edtLicenca.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence texto, int start, int before, int count) {
                boolean mostrar = texto != null && texto.toString().trim().length() == 11;
                grupoTipoAparelho.setVisibility(mostrar ? View.VISIBLE : View.GONE);
                if (!mostrar) {
                    grupoTipoAparelho.clearCheck();
                    tipoAparelhoEscolhido = "";
                }
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        btnAtivar = criarBotao(textoBotaoAtivar);
        LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(-1, dp(isTV() ? 76 : 66));
        btnParams.setMargins(0, dp(4), 0, dp(18));
        root.addView(btnAtivar, btnParams);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setVisibility(View.GONE);
        progress.setMax(100);
        LinearLayout.LayoutParams progressParams = new LinearLayout.LayoutParams(-1, dp(8));
        progressParams.setMargins(0, 0, 0, dp(14));
        root.addView(progress, progressParams);

        txtStatus = new TextView(this);
        txtStatus.setText(msgPronto);
        txtStatus.setTextColor(TEXTO_SUAVE);
        txtStatus.setTextSize(isTV() ? 17 : 14);
        txtStatus.setGravity(Gravity.CENTER);
        txtStatus.setPadding(dp(6), dp(8), dp(6), dp(8));
        root.addView(txtStatus, new LinearLayout.LayoutParams(-1, -2));

        btnApagarConfig = criarBotao("APAGAR CONFIG BAIXADA");
        btnApagarConfig.setBackground(criarBorda(Color.argb(150, 6, 9, 16), Color.argb(125,255,255,255), dp(18), dp(1)));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, dp(isTV() ? 58 : 50));
        ap.setMargins(0, dp(12), 0, 0);
        root.addView(btnApagarConfig, ap);
        btnApagarConfig.setOnClickListener(v -> apagarConfigBaixada());

        adicionarPropaganda(root);

        btnAtivar.setOnClickListener(v -> ativar());
        configurarTecladoTv(edtLicenca, btnAtivar, () -> {
            if (grupoTipoAparelho.getVisibility() == View.VISIBLE) {
                opcaoAndroid.requestFocus();
            } else {
                btnAtivar.requestFocus();
            }
        });
        btnAtivar.requestFocus();
        setContentView(scroll);
    }

    private void iniciarVerificacaoRoot() {
        if (verificandoRoot || removendoRoot) return;
        verificandoRoot = true;
        verificacaoRootConcluida = false;
        rootGateLiberado = false;
        rootDetectado = false;
        montarTelaRoot();

        new Thread(() -> {
            try {
            RootInfo info = detectarRootReal();
            ultimaInfoRoot = info;
            rootDetectado = info.rooted;
            verificacaoRootConcluida = true;
            verificandoRoot = false;

            runOnUiThread(() -> {
                montarTelaRoot();
                if (!rootDetectado) {
                    rootHandler.removeCallbacksAndMessages(null);
                    rootHandler.postDelayed(() -> {
                        if (!rootDetectado && verificacaoRootConcluida && !removendoRoot) {
                            rootGateLiberado = true;
                            mostrarTelaCorreta();
                        }
                    }, 1800);
                }
            });
            } catch (Throwable erro) {
                verificandoRoot = false;
                verificacaoRootConcluida = true;
                rootDetectado = false;
                rootGateLiberado = true;
                runOnUiThread(() -> {
                    if (atividadeDisponivel()) mostrarTelaRecuperacao("A verificação de root falhou neste aparelho.", erro);
                });
            }
        }, "root-check").start();
    }

    private void montarTelaRoot() {
        telaAtual = "root";
        subtituloDinamicoAtual = null;
        btnPermissaoAtual = null;
        opcaoAndroidAtual = null;
        opcaoTvBoxAtual = null;
        btnAtivar = null;
        txtStatus = null;
        progress = null;
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = criarContainer(scroll);
        adicionarTopo(root);

        TextView titulo = new TextView(this);
        titulo.setText(verificandoRoot || !verificacaoRootConcluida ? "VERIFICANDO ROOT" :
                (rootDetectado ? "⚠ ROOT DETECTADO" : "✓ APARELHO SEM ROOT"));
        titulo.setTextColor(rootDetectado ? Color.rgb(255, 90, 100) : Color.rgb(105, 235, 155));
        titulo.setTextSize(isTV() ? 28 : 22);
        titulo.setTypeface(Typeface.DEFAULT_BOLD);
        titulo.setGravity(Gravity.CENTER);
        titulo.setPadding(dp(10), dp(4), dp(10), dp(12));
        root.addView(titulo, new LinearLayout.LayoutParams(-1, -2));

        txtRootStatus = new TextView(this);
        txtRootStatus.setText(removendoRoot ? "Removendo o root verdadeiro do sistema. Não desligue o aparelho..." :
                (!verificacaoRootConcluida ? "Detectando automaticamente o acesso de superusuário..." :
                        (rootDetectado ? textoRootDetectado() : "Este aparelho não tem root. Abrindo a próxima etapa...")));
        txtRootStatus.setTextColor(TEXTO_CLARO);
        txtRootStatus.setTextSize(isTV() ? 19 : 15);
        txtRootStatus.setGravity(Gravity.CENTER);
        txtRootStatus.setPadding(dp(18), dp(18), dp(18), dp(18));
        int corBorda = rootDetectado ? Color.rgb(235, 30, 45) : Color.rgb(65, 190, 115);
        txtRootStatus.setBackground(criarBorda(Color.argb(95, 25, 25, 34), corBorda, dp(16), dp(1)));
        root.addView(txtRootStatus, new LinearLayout.LayoutParams(-1, -2));

        progressoRoot = new ProgressBar(this);
        progressoRoot.setIndeterminate(true);
        progressoRoot.setVisibility((verificandoRoot || removendoRoot || !verificacaoRootConcluida) ? View.VISIBLE : View.GONE);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(dp(isTV() ? 58 : 48), dp(isTV() ? 58 : 48));
        pp.gravity = Gravity.CENTER_HORIZONTAL;
        pp.setMargins(0, dp(18), 0, dp(12));
        root.addView(progressoRoot, pp);

        if (rootDetectado && verificacaoRootConcluida) {
            btnRemoverRoot = criarBotao(removendoRoot ? "REMOVENDO ROOT..." : "REMOVER ROOT");
            btnRemoverRoot.setEnabled(!removendoRoot);
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(isTV() ? 72 : 62));
            bp.setMargins(0, dp(8), 0, dp(10));
            root.addView(btnRemoverRoot, bp);
            btnRemoverRoot.setOnClickListener(v -> removerRootReal());
            if (!removendoRoot) btnRemoverRoot.requestFocus();

            if (ultimaInfoRoot != null && !ultimaInfoRoot.active) {
                Button orientar = criarBotao("COMO AUTORIZAR O ROOT");
                orientar.setBackground(criarBorda(Color.argb(80, 255, 255, 255), Color.rgb(255, 185, 40), dp(14), dp(1)));
                LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(-1, dp(isTV() ? 66 : 58));
                op.setMargins(0, dp(6), 0, dp(8));
                root.addView(orientar, op);
                orientar.setOnClickListener(v -> mostrarOrientacaoPermissaoRoot());
            }
        }

        TextView rodape = new TextView(this);
        rodape.setText(rootDetectado
                ? "A licença só será liberada depois que o aparelho iniciar sem root."
                : "A verificação é feita novamente sempre que o aplicativo é aberto.");
        rodape.setTextColor(TEXTO_SUAVE);
        rodape.setTextSize(isTV() ? 15 : 12);
        rodape.setGravity(Gravity.CENTER);
        rodape.setPadding(dp(8), dp(10), dp(8), 0);
        root.addView(rodape, new LinearLayout.LayoutParams(-1, -2));

        setContentView(scroll);
    }

    private String textoRootDetectado() {
        String tipo = ultimaInfoRoot == null ? "" : ultimaInfoRoot.type;
        if ("magisk".equals(tipo)) {
            return "Root Magisk detectado. Toque em REMOVER ROOT: a limpeza será executada dentro deste ativador, sem abrir outro aplicativo.";
        }
        if ("kernelsu".equals(tipo)) {
            return "Root KernelSU detectado. Toque em REMOVER ROOT: o ativador tentará a remoção direta usando os arquivos de restauração disponíveis no aparelho.";
        }
        if ("apatch".equals(tipo)) {
            return "Root APatch detectado. Toque em REMOVER ROOT: o processo será feito dentro deste ativador, sem abrir outra tela.";
        }
        if (ultimaInfoRoot != null && !ultimaInfoRoot.active) {
            return "Foram encontrados arquivos de root, mas o acesso de superusuário não foi autorizado. Autorize a solicitação e toque novamente em REMOVER ROOT.";
        }
        return "Seu aparelho tem ROOT ativo. O ativador removerá os arquivos de superusuário e reiniciará o aparelho para validar.";
    }

    private RootInfo detectarRootReal() {
        RootInfo info = new RootInfo();
        StringBuilder detalhes = new StringBuilder();

        if (android.os.Process.myUid() == 0) {
            info.active = true;
            detalhes.append("processo_uid_0;");
        }

        String[] rootPaths = caminhosRootConhecidos();
        String comandoSu = null;
        for (String path : rootPaths) {
            try {
                File f = new File(path);
                if (f.exists()) {
                    info.artifacts = true;
                    detalhes.append(path).append(';');
                    if (comandoSu == null && (path.endsWith("/su") || path.endsWith("/.su") || path.endsWith("/daemonsu"))) {
                        comandoSu = path;
                    }
                }
            } catch (Exception ignored) {}
        }

        CommandResult pacotes = executarComando(new String[]{"sh", "-c",
                "pm list packages 2>/dev/null | grep -Ei 'magisk|kernelsu|apatch|supersu|superuser|kingroot|kingo' || true"}, 6);
        String pkg = pacotes.output.toLowerCase();
        if (pkg.contains("magisk")) info.type = "magisk";
        else if (pkg.contains("kernelsu")) info.type = "kernelsu";
        else if (pkg.contains("apatch")) info.type = "apatch";
        else if (pkg.contains("supersu") || pkg.contains("superuser") || pkg.contains("kingroot") || pkg.contains("kingo")) info.type = "system";

        CommandResult indicadores = executarComando(new String[]{"sh", "-c",
                "PATH=/sbin:/system/sbin:/system/bin:/system/xbin:/vendor/bin:/product/bin:/odm/bin:$PATH; " +
                        "command -v magisk 2>/dev/null || true; command -v su 2>/dev/null || true; " +
                        "[ -d /data/adb/magisk ] && echo MAGISK_DIR || true; " +
                        "[ -d /data/adb/ksu ] && echo KERNELSU_DIR || true; " +
                        "[ -d /data/adb/ap ] && echo APATCH_DIR || true"}, 6);
        String ind = indicadores.output.toLowerCase();
        if (ind.contains("magisk")) info.type = "magisk";
        else if (ind.contains("kernelsu") || ind.contains("ksu")) info.type = "kernelsu";
        else if (ind.contains("apatch")) info.type = "apatch";
        if (!ind.trim().isEmpty()) {
            info.artifacts = true;
            detalhes.append(ind.replace('\n', ';'));
        }

        List<String> suCandidates = new ArrayList<>();
        suCandidates.add("su");
        if (comandoSu != null && !"su".equals(comandoSu)) suCandidates.add(comandoSu);
        for (String path : rootPaths) {
            if ((path.endsWith("/su") || path.endsWith("/.su")) && !suCandidates.contains(path)) suCandidates.add(path);
        }

        for (String su : suCandidates) {
            CommandResult id = executarComando(new String[]{su, "-c", "id"}, 12);
            if (id.output.contains("uid=0")) {
                info.active = true;
                info.suCommand = su;
                detalhes.append("uid0_por_").append(su).append(';');
                break;
            }
        }

        if (info.type.isEmpty()) info.type = "system";
        info.rooted = info.active || info.artifacts;
        info.details = detalhes.toString();
        return info;
    }

    private String[] caminhosRootConhecidos() {
        return new String[]{
                "/system/bin/su", "/system/xbin/su", "/sbin/su", "/su/bin/su",
                "/vendor/bin/su", "/product/bin/su", "/odm/bin/su",
                "/system/sd/xbin/su", "/system/bin/failsafe/su", "/data/local/xbin/su",
                "/data/local/bin/su", "/data/local/su", "/system/xbin/daemonsu",
                "/system/bin/.ext/.su", "/system/app/Superuser.apk", "/system/app/SuperSU.apk",
                "/system/priv-app/Superuser.apk", "/system/priv-app/SuperSU.apk",
                "/sbin/.magisk", "/data/adb/magisk", "/data/adb/ksu", "/data/adb/ap"
        };
    }

    private void removerRootReal() {
        if (removendoRoot) return;
        removendoRoot = true;
        montarTelaRoot();

        new Thread(() -> {
            RootInfo atual = detectarRootReal();
            // Segurança obrigatória: nenhuma limpeza é executada sem uma autorização SU
            // real confirmada por uid=0 naquele momento.
            String suTeste = atual.suCommand == null || atual.suCommand.trim().isEmpty() ? "su" : atual.suCommand;
            CommandResult autorizacao = executarComando(new String[]{suTeste, "-c", "id"}, 20);
            boolean suAutorizado = autorizacao.output != null && autorizacao.output.contains("uid=0");
            if (!atual.active || !suAutorizado) {
                removendoRoot = false;
                ultimaInfoRoot = atual;
                runOnUiThread(() -> {
                    if (!atividadeDisponivel()) return;
                    montarTelaRoot();
                    mostrarOrientacaoPermissaoRoot();
                });
                return;
            }

            String su = atual.suCommand == null || atual.suCommand.trim().isEmpty() ? "su" : atual.suCommand;
            String script = scriptRemocaoRootDireta();
            CommandResult resultado = executarComando(new String[]{su, "-c", script}, 95);

            boolean removeu = resultado.output.contains("ROOT_REMOVE_OK");
            boolean backupAusente = resultado.output.contains("ROOT_BACKUP_MISSING");
            boolean tipoKernelSemBackup = resultado.output.contains("ROOT_KERNEL_BACKUP_MISSING");
            boolean restou = resultado.output.contains("ROOT_FILES_REMAIN");

            if (removeu && !restou) {
                runOnUiThread(() -> {
                    if (txtRootStatus != null) {
                        txtRootStatus.setText("Purificando o sistema... O aparelho será reiniciado automaticamente em instantes.");
                    }
                    Toast.makeText(this, "Root removido. Reiniciando o aparelho para confirmar.", Toast.LENGTH_LONG).show();
                    rootHandler.postDelayed(() -> {
                        if (removendoRoot && !isFinishing()) {
                            removendoRoot = false;
                            montarTelaRoot();
                            if (txtRootStatus != null) {
                                txtRootStatus.setText("A limpeza terminou, mas o aparelho não reiniciou sozinho. Reinicie-o para validar a remoção.");
                            }
                        }
                    }, 14000);
                });
                return;
            }

            removendoRoot = false;
            RootInfo depois = detectarRootReal();
            ultimaInfoRoot = depois;
            rootDetectado = depois.rooted;
            verificacaoRootConcluida = true;

            runOnUiThread(() -> {
                montarTelaRoot();
                String msg;
                if (backupAusente) {
                    msg = "O Magisk foi detectado, mas o backup original do boot não existe no aparelho. A remoção direta foi interrompida para não danificar a TV.";
                } else if (tipoKernelSemBackup) {
                    msg = "Este root está gravado no kernel/boot e não existe imagem original salva no aparelho. A remoção direta foi interrompida para evitar falha de inicialização.";
                } else if (resultado.timedOut) {
                    msg = "A remoção demorou além do limite. Reinicie o aparelho e verifique novamente.";
                } else {
                    msg = "Não foi possível concluir a remoção nesta ROM. Nenhuma outra tela foi aberta e a licença continua bloqueada.";
                }
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
                if (txtRootStatus != null) txtRootStatus.setText(msg);
            });
        }, "root-remove-direct").start();
    }

    private void mostrarOrientacaoPermissaoRoot() {
        if (!atividadeDisponivel()) return;

        String nome = nomeGerenciadorDetectado();
        String caminho = caminhoPermissaoGerenciador();

        new AlertDialog.Builder(this)
                .setTitle("Autorizar remoção de root")
                .setMessage(nome + " detectado.\n\n" + caminho +
                        "\n\nO ativador vai solicitar a permissão primeiro. Se a janela não aparecer, ele abrirá o gerenciador correto para você conceder o acesso.")
                .setPositiveButton("CONTINUAR", (d, w) -> solicitarRootEContinuar())
                .setNeutralButton("ABRIR GERENCIADOR", (d, w) -> abrirGerenciadorRoot())
                .setNegativeButton("FECHAR", null)
                .show();
    }

    private String caminhoPermissaoGerenciador() {
        String tipo = ultimaInfoRoot == null ? "" : ultimaInfoRoot.type;
        if ("magisk".equals(tipo)) {
            return "No Magisk: toque em Superusuário, encontre Ativador UnitvFree e marque Permitir sempre.";
        }
        if ("kernelsu".equals(tipo)) {
            return "No KernelSU: abra Superusuário, selecione Ativador UnitvFree e ative a permissão.";
        }
        if ("apatch".equals(tipo)) {
            return "No APatch: abra Superusuário, selecione Ativador UnitvFree e ative a permissão.";
        }
        return "No aplicativo de root: abra Superusuário ou Permissões, selecione Ativador UnitvFree e marque Permitir sempre.";
    }

    private void solicitarRootEContinuar() {
        aguardandoAutorizacaoRoot = true;
        retornoGerenciadorEmProcessamento = true;
        if (txtRootStatus != null) {
            txtRootStatus.setText("Solicitando acesso de superusuário. Quando aparecer, escolha PERMITIR SEMPRE.");
        }
        Toast.makeText(this, "Aguarde a janela de superusuário e toque em PERMITIR SEMPRE.", Toast.LENGTH_LONG).show();

        rootHandler.postDelayed(() -> new Thread(() -> {
            CommandResult permissao = executarComando(new String[]{"su", "-c", "id"}, 35);
            boolean concedida = permissao.output != null && permissao.output.contains("uid=0");

            runOnUiThread(() -> {
                retornoGerenciadorEmProcessamento = false;
                if (!atividadeDisponivel()) return;
                if (concedida) {
                    aguardandoAutorizacaoRoot = false;
                    Toast.makeText(this, "Permissão concedida. Iniciando a remoção do root...", Toast.LENGTH_SHORT).show();
                    removerRootReal();
                } else {
                    if (txtRootStatus != null) {
                        txtRootStatus.setText("A permissão ainda não foi concedida. Abrindo " + nomeGerenciadorDetectado() + " para você autorizar.");
                    }
                    abrirGerenciadorRoot();
                }
            });
        }, "root-permission-direct").start(), 600);
    }

    private void verificarAutorizacaoAoRetornar() {
        new Thread(() -> {
            CommandResult permissao = executarComando(new String[]{"su", "-c", "id"}, 12);
            boolean concedida = permissao.output != null && permissao.output.contains("uid=0");
            runOnUiThread(() -> {
                retornoGerenciadorEmProcessamento = false;
                if (!atividadeDisponivel()) return;
                if (concedida) {
                    aguardandoAutorizacaoRoot = false;
                    Toast.makeText(this, "Permissão concedida. Iniciando a remoção do root...", Toast.LENGTH_SHORT).show();
                    removerRootReal();
                } else {
                    aguardandoAutorizacaoRoot = true;
                    montarTelaRoot();
                    if (txtRootStatus != null) {
                        txtRootStatus.setText("Permissão ainda não concedida. " + caminhoPermissaoGerenciador());
                    }
                    new AlertDialog.Builder(this)
                            .setTitle("Falta conceder a permissão")
                            .setMessage(caminhoPermissaoGerenciador() +
                                    "\n\nDepois volte ao ativador. A remoção será iniciada automaticamente.")
                            .setPositiveButton("ABRIR NOVAMENTE", (d, w) -> abrirGerenciadorRoot())
                            .setNeutralButton("SOLICITAR PERMISSÃO", (d, w) -> solicitarRootEContinuar())
                            .setNegativeButton("FECHAR", null)
                            .show();
                }
            });
        }, "root-return-check").start();
    }

    private String nomeGerenciadorDetectado() {
        String tipo = ultimaInfoRoot == null ? "" : ultimaInfoRoot.type;
        if ("magisk".equals(tipo)) return "Magisk";
        if ("kernelsu".equals(tipo)) return "KernelSU";
        if ("apatch".equals(tipo)) return "APatch";
        return "o gerenciador de root";
    }

    private boolean iniciarComponente(String pacote, String classe) {
        try {
            Intent intent = new Intent(Intent.ACTION_MAIN);
            intent.setComponent(new ComponentName(pacote, classe));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private void prepararRetornoGerenciador(String pacote) {
        pacoteGerenciadorAberto = pacote == null ? "" : pacote;
        aguardandoAutorizacaoRoot = true;
        retornoGerenciadorEmProcessamento = false;
        if (txtRootStatus != null) {
            txtRootStatus.setText(caminhoPermissaoGerenciador() + " Depois volte ao ativador.");
        }
        Toast.makeText(this, caminhoPermissaoGerenciador() + " Depois volte ao ativador.", Toast.LENGTH_LONG).show();
    }

    private void abrirGerenciadorRoot() {
        String[][] componentes = new String[][]{
                {"com.topjohnwu.magisk", "com.topjohnwu.magisk.ui.MainActivity"},
                {"io.github.vvb2060.magisk", "com.topjohnwu.magisk.ui.MainActivity"},
                {"me.weishu.kernelsu", "me.weishu.kernelsu.ui.MainActivity"},
                {"me.bmax.apatch", "me.bmax.apatch.ui.MainActivity"},
                {"eu.chainfire.supersu", "eu.chainfire.supersu.MainActivity"},
                {"com.noshufou.android.su", "com.noshufou.android.su.MainActivity"},
                {"com.kingroot.kinguser", "com.kingroot.kinguser.activitys.SliderMainActivity"},
                {"com.kingo.root", "com.kingo.root.MainActivity"}
        };

        for (String[] item : componentes) {
            if (iniciarComponente(item[0], item[1])) {
                prepararRetornoGerenciador(item[0]);
                return;
            }
        }

        String[] pacotes = new String[]{
                "com.topjohnwu.magisk",
                "io.github.vvb2060.magisk",
                "me.weishu.kernelsu",
                "me.bmax.apatch",
                "eu.chainfire.supersu",
                "com.noshufou.android.su",
                "com.kingroot.kinguser",
                "com.kingo.root"
        };
        for (String pacote : pacotes) {
            try {
                Intent intent = getPackageManager().getLaunchIntentForPackage(pacote);
                if (intent != null) {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                    prepararRetornoGerenciador(pacote);
                    return;
                }
            } catch (Throwable ignored) {}
        }

        pacoteGerenciadorAberto = "";
        aguardandoAutorizacaoRoot = true;
        retornoGerenciadorEmProcessamento = false;
        new AlertDialog.Builder(this)
                .setTitle("Gerenciador de root não localizado")
                .setMessage("Não consegui abrir automaticamente porque alguns gerenciadores escondem ou alteram o nome do aplicativo.\n\n" +
                        "Abra manualmente Magisk, KernelSU, APatch ou SuperSU > Superusuário/Permissões > Ativador UnitvFree > Permitir sempre. Depois volte ao ativador.")
                .setPositiveButton("ABRIR LISTA DE APLICATIVOS", (d, w) -> {
                    try {
                        startActivity(new Intent(Settings.ACTION_APPLICATION_SETTINGS));
                    } catch (Throwable ignored) {}
                })
                .setNegativeButton("FECHAR", null)
                .show();
    }

    private boolean atividadeDisponivel() {
        if (isFinishing()) return false;
        return Build.VERSION.SDK_INT < 17 || !isDestroyed();
    }

    private void instalarProtecaoContraFechamento() {
        final Thread.UncaughtExceptionHandler anterior = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, erro) -> {
            try {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                        .putString("ultimo_erro", erro.getClass().getSimpleName() + ": " + String.valueOf(erro.getMessage()))
                        .apply();
            } catch (Throwable ignored) {}
            if (anterior != null) anterior.uncaughtException(thread, erro);
        });
    }

    private void mostrarTelaRecuperacao(String mensagem, Throwable erro) {
        try {
            ScrollView scroll = new ScrollView(this);
            LinearLayout box = criarContainer(scroll);
            adicionarTopo(box);

            TextView titulo = new TextView(this);
            titulo.setText("MODO DE COMPATIBILIDADE");
            titulo.setTextColor(Color.rgb(255, 190, 70));
            titulo.setTextSize(isTV() ? 26 : 21);
            titulo.setTypeface(Typeface.DEFAULT_BOLD);
            titulo.setGravity(Gravity.CENTER);
            box.addView(titulo, new LinearLayout.LayoutParams(-1, -2));

            TextView texto = new TextView(this);
            texto.setText(mensagem + "\n\nO aplicativo não será fechado. Toque abaixo para tentar novamente.");
            texto.setTextColor(TEXTO_CLARO);
            texto.setTextSize(isTV() ? 18 : 15);
            texto.setGravity(Gravity.CENTER);
            texto.setPadding(dp(12), dp(20), dp(12), dp(20));
            box.addView(texto, new LinearLayout.LayoutParams(-1, -2));

            Button tentar = criarBotao("TENTAR NOVAMENTE");
            box.addView(tentar, new LinearLayout.LayoutParams(-1, dp(isTV() ? 68 : 58)));
            tentar.setOnClickListener(v -> iniciarVerificacaoRoot());
            setContentView(scroll);
        } catch (Throwable ignorado) {
            Toast.makeText(this, "Falha de compatibilidade. Reinicie o aplicativo.", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onDestroy() {
        try { rootHandler.removeCallbacksAndMessages(null); } catch (Throwable ignored) {}
        try { suporteHandler.removeCallbacksAndMessages(null); } catch (Throwable ignored) {}
        super.onDestroy();
    }

    private String scriptRemocaoRootDireta() {
        return "PATH=/sbin:/system/sbin:/system/bin:/system/xbin:/vendor/bin:/product/bin:/odm/bin:/data/adb/magisk:$PATH\n" +
                "echo ROOT_REMOVE_START\n" +
                "id\n" +
                "SUCCESS=0\n" +
                "MAGISK_PRESENT=0\n" +
                "MAGISK_RESTORED=0\n" +
                "KERNEL_ROOT_PRESENT=0\n" +
                "MAGISKTMP=$(magisk --path 2>/dev/null || true)\n" +
                "MAGISKBIN=/data/adb/magisk\n" +
                "if [ -x /data/adb/magisk/magisk ]; then MAGISKCMD=/data/adb/magisk/magisk; else MAGISKCMD=magisk; fi\n" +
                "if [ -d /data/adb/magisk ] || command -v magisk >/dev/null 2>&1; then\n" +
                "  MAGISK_PRESENT=1\n" +
                "  SHA1=''\n" +
                "  for C in \"$MAGISKTMP/.magisk/config\" /data/.magisk /cache/.magisk; do\n" +
                "    if [ -f \"$C\" ]; then\n" +
                "      SHA1=$(sed -n 's/^SHA1=//p' \"$C\" | head -n 1)\n" +
                "      [ -n \"$SHA1\" ] && break\n" +
                "    fi\n" +
                "  done\n" +
                "  BACKUPDIR=''\n" +
                "  [ -n \"$SHA1\" ] && BACKUPDIR=/data/magisk_backup_${SHA1}\n" +
                "  if [ -n \"$BACKUPDIR\" ] && [ -f \"$BACKUPDIR/boot.img.gz\" ] && [ -f /data/adb/magisk/util_functions.sh ]; then\n" +
                "    BOOTMODE=true\n" +
                "    TMPDIR=/data/local/tmp/ativador_unroot\n" +
                "    mkdir -p \"$TMPDIR\"\n" +
                "    export BOOTMODE TMPDIR MAGISKBIN MAGISKTMP\n" +
                "    . /data/adb/magisk/util_functions.sh\n" +
                "    mount_partitions >/dev/null 2>&1 || true\n" +
                "    get_flags >/dev/null 2>&1 || true\n" +
                "    find_boot_image\n" +
                "    if [ -n \"$BOOTIMAGE\" ] && flash_image \"$BACKUPDIR/boot.img.gz\" \"$BOOTIMAGE\" >/dev/null 2>&1; then\n" +
                "      EXTRA_OK=1\n" +
                "      for N in dtb dtbo dtbs; do\n" +
                "        IMG=\"$BACKUPDIR/${N}.img.gz\"\n" +
                "        [ -f \"$IMG\" ] || continue\n" +
                "        DEV=$(find_block \"${N}${SLOT}\" \"$N\")\n" +
                "        if [ -n \"$DEV\" ]; then\n" +
                "          flash_image \"$IMG\" \"$DEV\" >/dev/null 2>&1 || EXTRA_OK=0\n" +
                "        fi\n" +
                "      done\n" +
                "      if [ \"$EXTRA_OK\" -eq 1 ]; then\n" +
                "        MAGISK_RESTORED=1\n" +
                "        SUCCESS=1\n" +
                "      fi\n" +
                "    fi\n" +
                "  else\n" +
                "    echo ROOT_BACKUP_MISSING\n" +
                "  fi\n" +
                "  \"$MAGISKCMD\" --remove-modules -n >/dev/null 2>&1 || true\n" +
                "fi\n" +
                "if [ -d /data/adb/ksu ] || [ -e /data/adb/ksud ] || [ -d /data/adb/ap ]; then\n" +
                "  KERNEL_ROOT_PRESENT=1\n" +
                "  echo ROOT_KERNEL_BACKUP_MISSING\n" +
                "fi\n" +
                "mount -o rw,remount / 2>/dev/null || true\n" +
                "mount -o remount,rw /system 2>/dev/null || mount -o rw,remount /system 2>/dev/null || true\n" +
                "mount -o remount,rw /vendor 2>/dev/null || true\n" +
                "mount -o remount,rw /product 2>/dev/null || true\n" +
                "mount -o remount,rw /odm 2>/dev/null || true\n" +
                "REMOVED=0\n" +
                "for P in /system/bin/su /system/xbin/su /sbin/su /su/bin/su /vendor/bin/su /product/bin/su /odm/bin/su /system/sd/xbin/su /system/bin/failsafe/su /data/local/xbin/su /data/local/bin/su /data/local/su /system/xbin/daemonsu /system/bin/.ext/.su; do\n" +
                "  if [ -e \"$P\" ] || [ -L \"$P\" ]; then\n" +
                "    chmod 700 \"$P\" 2>/dev/null || true\n" +
                "    rm -f \"$P\" 2>/dev/null && REMOVED=$((REMOVED+1))\n" +
                "  fi\n" +
                "done\n" +
                "for P in /system/app/Superuser.apk /system/app/SuperSU.apk /system/priv-app/Superuser.apk /system/priv-app/SuperSU.apk; do\n" +
                "  if [ -e \"$P\" ]; then rm -f \"$P\" 2>/dev/null && REMOVED=$((REMOVED+1)); fi\n" +
                "done\n" +
                "for D in /system/app/Superuser /system/app/SuperSU /system/priv-app/Superuser /system/priv-app/SuperSU /data/su /data/adb/su /data/local/su; do\n" +
                "  if [ -e \"$D\" ]; then rm -rf \"$D\" 2>/dev/null && REMOVED=$((REMOVED+1)); fi\n" +
                "done\n" +
                "pm uninstall --user 0 eu.chainfire.supersu >/dev/null 2>&1 || true\n" +
                "pm uninstall --user 0 com.noshufou.android.su >/dev/null 2>&1 || true\n" +
                "pm uninstall --user 0 com.kingroot.kinguser >/dev/null 2>&1 || true\n" +
                "pm uninstall --user 0 com.kingo.root >/dev/null 2>&1 || true\n" +
                "if [ \"$MAGISK_RESTORED\" -eq 1 ]; then\n" +
                "  \"$MAGISKCMD\" --stop >/dev/null 2>&1 || true\n" +
                "  rm -rf /data/adb/magisk /data/adb/modules /data/adb/modules_update /data/adb/post-fs-data.d /data/adb/service.d\n" +
                "  pm uninstall --user 0 com.topjohnwu.magisk >/dev/null 2>&1 || true\n" +
                "fi\n" +
                "LEFT=0\n" +
                "for P in /system/bin/su /system/xbin/su /sbin/su /su/bin/su /vendor/bin/su /product/bin/su /odm/bin/su /system/sd/xbin/su /system/bin/failsafe/su /data/local/xbin/su /data/local/bin/su /data/local/su /system/xbin/daemonsu /system/bin/.ext/.su; do\n" +
                "  if [ -e \"$P\" ] || [ -L \"$P\" ]; then LEFT=$((LEFT+1)); fi\n" +
                "done\n" +
                "if [ \"$MAGISK_PRESENT\" -eq 0 ] && [ \"$KERNEL_ROOT_PRESENT\" -eq 0 ] && [ \"$REMOVED\" -gt 0 ]; then SUCCESS=1; fi\n" +
                "sync\n" +
                "echo REMOVED=$REMOVED LEFT=$LEFT SUCCESS=$SUCCESS\n" +
                "if [ \"$SUCCESS\" -eq 1 ] && [ \"$LEFT\" -eq 0 ]; then\n" +
                "  echo ROOT_REMOVE_OK\n" +
                "  (sleep 4; reboot) >/dev/null 2>&1 &\n" +
                "else\n" +
                "  echo ROOT_FILES_REMAIN\n" +
                "fi\n";
    }

    private CommandResult executarComando(String[] comando, long timeoutSegundos) {
        CommandResult result = new CommandResult();
        Process processo = null;
        try {
            ProcessBuilder pb = new ProcessBuilder(comando);
            pb.redirectErrorStream(true);
            processo = pb.start();
            long limite = System.currentTimeMillis() + (timeoutSegundos * 1000L);
            boolean terminou = false;
            while (System.currentTimeMillis() < limite) {
                try {
                    result.exitCode = processo.exitValue();
                    terminou = true;
                    break;
                } catch (IllegalThreadStateException aindaExecutando) {
                    try { Thread.sleep(100); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); break; }
                }
            }
            if (!terminou) {
                result.timedOut = true;
                processo.destroy();
            }
            result.output = lerSaidaProcesso(processo);
        } catch (Exception e) {
            result.output = e.getClass().getSimpleName() + ": " + e.getMessage();
        } finally {
            if (processo != null) {
                try { processo.getInputStream().close(); } catch (Exception ignored) {}
                try { processo.getOutputStream().close(); } catch (Exception ignored) {}
                try { processo.getErrorStream().close(); } catch (Exception ignored) {}
                try { processo.destroy(); } catch (Exception ignored) {}
            }
        }
        return result;
    }

    private String lerSaidaProcesso(Process processo) {
        if (processo == null) return "";
        StringBuilder out = new StringBuilder();
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(processo.getInputStream()));
            String linha;
            while ((linha = reader.readLine()) != null) {
                if (out.length() < 12000) out.append(linha).append('\n');
            }
            reader.close();
        } catch (Exception ignored) {}
        return out.toString();
    }

    private void configurarTecladoTv(EditText campo, View focoDepois, Runnable aoConcluir) {
        campo.setImeOptions(EditorInfo.IME_ACTION_DONE | EditorInfo.IME_FLAG_NO_EXTRACT_UI);
        campo.setSingleLine(true);

        Runnable fechar = () -> {
            esconderTeclado(campo);
            campo.clearFocus();
            if (aoConcluir != null) aoConcluir.run();
            else if (focoDepois != null) focoDepois.requestFocus();
        };

        if (campo instanceof TvEditText) ((TvEditText) campo).setAoFecharTeclado(fechar);

        campo.setOnEditorActionListener((v, actionId, event) -> {
            boolean teclaEnter = event != null && event.getAction() == KeyEvent.ACTION_UP &&
                    (event.getKeyCode() == KeyEvent.KEYCODE_ENTER ||
                            event.getKeyCode() == KeyEvent.KEYCODE_NUMPAD_ENTER ||
                            event.getKeyCode() == KeyEvent.KEYCODE_DPAD_CENTER);
            boolean acaoConcluir = actionId == EditorInfo.IME_ACTION_DONE ||
                    actionId == EditorInfo.IME_ACTION_GO ||
                    actionId == EditorInfo.IME_ACTION_NEXT ||
                    actionId == EditorInfo.IME_ACTION_SEND ||
                    actionId == EditorInfo.IME_ACTION_UNSPECIFIED;
            if (teclaEnter || acaoConcluir) {
                fechar.run();
                return true;
            }
            return false;
        });

        campo.setOnKeyListener((v, keyCode, event) -> {
            if (event.getAction() == KeyEvent.ACTION_UP &&
                    (keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER)) {
                fechar.run();
                return true;
            }
            return false;
        });
    }

    private void esconderTeclado(View view) {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        } catch (Exception ignored) {}
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event != null && event.getKeyCode() == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
            View foco = getCurrentFocus();
            if (foco instanceof EditText) {
                esconderTeclado(foco);
                foco.clearFocus();
                if (btnAtivar != null) btnAtivar.requestFocus();
                return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }

    private class TvEditText extends EditText {
        private Runnable aoFecharTeclado;

        TvEditText(Context context) {
            super(context);
        }

        void setAoFecharTeclado(Runnable runnable) {
            aoFecharTeclado = runnable;
        }

        @Override
        public boolean onKeyPreIme(int keyCode, KeyEvent event) {
            if (keyCode == KeyEvent.KEYCODE_BACK && event != null && event.getAction() == KeyEvent.ACTION_UP) {
                esconderTeclado(this);
                clearFocus();
                if (aoFecharTeclado != null) aoFecharTeclado.run();
                return true;
            }
            return super.onKeyPreIme(keyCode, event);
        }
    }

    private static class RootInfo {
        boolean rooted;
        boolean active;
        boolean artifacts;
        String type = "";
        String suCommand = "su";
        String details = "";
    }

    private static class CommandResult {
        int exitCode = -1;
        boolean timedOut;
        String output = "";
    }

    private RadioButton criarOpcaoTipo(int id, String texto) {
        RadioButton rb = new RadioButton(this);
        rb.setId(id);
        rb.setText(texto);
        rb.setTextColor(TEXTO_CLARO);
        rb.setTextSize(isTV() ? 20 : 16);
        rb.setTypeface(Typeface.DEFAULT_BOLD);
        rb.setPadding(dp(4), dp(4), dp(4), dp(4));
        rb.setFocusable(true);
        return rb;
    }

    private Button criarBotao(String texto) {
        Button b = new Button(this);
        b.setText(texto);
        b.setTextColor(Color.WHITE);
        b.setTextSize(isTV() ? 20 : 16);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setAllCaps(false);
        b.setFocusable(true);
        b.setBackground(criarGradienteBotao());
        return b;
    }

    private GradientDrawable criarBorda(int corFundo, int corBorda, int raio, int largura) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(corFundo);
        gd.setCornerRadius(raio);
        gd.setStroke(largura, corBorda);
        return gd;
    }

    private GradientDrawable criarGradienteBotao() {
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{COR_PRINCIPAL_ESCURO, COR_PRINCIPAL, Color.rgb(255, 105, 65)});
        gd.setCornerRadius(dp(20));
        gd.setStroke(dp(1), Color.argb(150, 255, 220, 210));
        return gd;
    }

    private int comAlpha(int cor, int alpha) {
        return Color.argb(Math.max(0, Math.min(255, alpha)), Color.red(cor), Color.green(cor), Color.blue(cor));
    }

    private int dp(int valor) {
        return (int) (valor * getResources().getDisplayMetrics().density + 0.5f);
    }

    private boolean temPermissaoArmazenamentoRuntime() {
        if (Build.VERSION.SDK_INT < 23) return true;
        return checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean permissoesLiberadas() {
        // A base usa targetSdk 28 e armazenamento legado. Em várias TVs Android 11+
        // Environment.isExternalStorageManager() continua falso mesmo quando "Arquivos e mídia"
        // está permitido. Por isso a confirmação principal é uma escrita real nos caminhos públicos.
        boolean storageOk = testarEscritaPermissaoReal();

        if (!storageOk && Build.VERSION.SDK_INT >= 30 && Environment.isExternalStorageManager()) {
            storageOk = testarEscritaPermissaoReal();
        }

        if (!storageOk && temPermissaoArmazenamentoRuntime()) {
            storageOk = testarEscritaPermissaoReal();
        }

        boolean installOk = true;
        if (Build.VERSION.SDK_INT >= 26) installOk = getPackageManager().canRequestPackageInstalls();
        return storageOk && installOk;
    }

    private void verificarPermissoesEContinuar() {
        if (permissoesLiberadas()) {
            confirmarPermissoes();
            // Reinicia o estado para obrigar a verificação de root imediatamente após as permissões.
            verificacaoRootConcluida = false;
            rootGateLiberado = false;
            rootDetectado = false;
            Toast.makeText(this, "Permissões confirmadas. Verificando o root do aparelho...", Toast.LENGTH_LONG).show();
            mostrarTelaCorreta();
        } else {
            Toast.makeText(this, "Ainda falta liberar uma permissão. Toque em Liberar permissões.", Toast.LENGTH_LONG).show();
            montarTelaPermissoes();
        }
    }

    private String statusPermissoesTexto() {
        StringBuilder sb = new StringBuilder();
        boolean escritaPublica = testarEscritaPermissaoReal();
        boolean runtime = temPermissaoArmazenamentoRuntime();
        boolean todosArquivos = Build.VERSION.SDK_INT >= 30 && Environment.isExternalStorageManager();

        if (escritaPublica) {
            sb.append("✓ Permissão de arquivos confirmada na memória pública\n");
        } else if (runtime || todosArquivos) {
            sb.append("• Permissão marcada, mas a TV ainda não liberou a gravação pública\n");
        } else {
            sb.append("• Liberar Arquivos e mídia / Armazenamento\n");
        }

        if (Build.VERSION.SDK_INT >= 26) {
            sb.append(getPackageManager().canRequestPackageInstalls()
                    ? "✓ Instalação de aplicativos liberada"
                    : "• Permitir instalar aplicativos desconhecidos");
        } else {
            sb.append("✓ Instalação liberada");
        }
        return sb.toString();
    }

    private boolean testarEscritaPermissaoReal() {
        // Testa somente caminhos públicos realmente usados pela ativação. Não usa a pasta
        // privada do ativador, pois ela funciona mesmo sem permissão e causava falso positivo.
        List<File> testes = new ArrayList<>();
        File raiz = Environment.getExternalStorageDirectory();
        if (raiz != null) {
            adicionarCaminhoConfig(testes, new File(raiz, ".config_teste_permissao"));
            adicionarCaminhoConfig(testes, new File(raiz, "Android/.config_teste_permissao"));
        }
        adicionarCaminhoConfig(testes, new File("/storage/emulated/0/.config_teste_permissao"));
        adicionarCaminhoConfig(testes, new File("/storage/emulated/0/Android/.config_teste_permissao"));
        adicionarCaminhoConfig(testes, new File("/storage/self/primary/.config_teste_permissao"));
        adicionarCaminhoConfig(testes, new File("/storage/self/primary/Android/.config_teste_permissao"));
        adicionarCaminhoConfig(testes, new File("/sdcard/.config_teste_permissao"));
        adicionarCaminhoConfig(testes, new File("/sdcard/Android/.config_teste_permissao"));

        for (File teste : testes) {
            try {
                File pai = teste.getParentFile();
                if (pai != null && !pai.exists() && !pai.mkdirs() && !pai.exists()) continue;
                FileOutputStream fos = new FileOutputStream(teste, false);
                fos.write("ok".getBytes("UTF-8"));
                fos.flush();
                fos.close();
                boolean gravou = teste.exists() && teste.length() == 2;
                try { teste.delete(); } catch (Throwable ignored) {}
                if (gravou) return true;
            } catch (Throwable ignored) {}
        }
        return false;
    }

    private boolean pacoteInstalado(String pacote) {
        if (pacote == null || pacote.trim().isEmpty()) return false;
        try {
            getPackageManager().getPackageInfo(pacote, 0);
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private String pacoteDoApk(File apkFile) {
        if (apkFile == null || !apkFile.isFile() || apkFile.length() == 0) return "";
        try {
            PackageInfo info = getPackageManager().getPackageArchiveInfo(
                    apkFile.getAbsolutePath(), PackageManager.GET_META_DATA | PackageManager.GET_PERMISSIONS);
            return info == null || info.packageName == null ? "" : info.packageName.trim();
        } catch (Throwable ignored) {
            return "";
        }
    }

    private String pacoteUnitvDoArquivo(File apkFile) {
        // Só acompanha o APK principal do UniTV. Atualizações do próprio ativador não entram neste fluxo.
        if (apkFile == null || !Config.NOME_APK_FINAL.equalsIgnoreCase(apkFile.getName())) return "";
        String pacote = pacoteDoApk(apkFile);
        return pacote.isEmpty() || pacote.equals(getPackageName()) ? "" : pacote;
    }

    private boolean processarRetornoInstalacaoUnitv() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String pacote = prefs.getString(KEY_PENDING_UNITV_INSTALL, "");
        if (pacote == null || pacote.trim().isEmpty()) return false;

        if (!pacoteInstalado(pacote)) {
            prefs.edit().remove(KEY_PENDING_UNITV_INSTALL).apply();
            Toast.makeText(this,
                    "A instalação do UniTV Free não foi confirmada. A licença continua vinculada a este aparelho; toque em ATIVAR LICENÇA para tentar novamente.",
                    Toast.LENGTH_LONG).show();
            return false;
        }

        prefs.edit()
                .remove(KEY_PENDING_UNITV_INSTALL)
                .putString(KEY_UNITV_PERMISSION_PACKAGE, pacote)
                .apply();
        new Handler(Looper.getMainLooper()).postDelayed(() -> abrirPermissaoTodosArquivosUnitv(pacote), 500);
        return true;
    }

    private boolean processarRetornoPermissaoUnitv() {
        if (!aguardandoRetornoPermissaoUnitv) return false;
        aguardandoRetornoPermissaoUnitv = false;

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String pacote = prefs.getString(KEY_UNITV_PERMISSION_PACKAGE, "");
        if (pacote == null || pacote.trim().isEmpty()) return false;

        if (temAcessoTodosArquivos(pacote)) {
            prefs.edit().remove(KEY_UNITV_PERMISSION_PACKAGE).apply();
            Toast.makeText(this, "UniTV Free instalado e acesso a todos os arquivos confirmado.", Toast.LENGTH_LONG).show();
        } else {
            new AlertDialog.Builder(this)
                    .setTitle("Permissão do UniTV Free")
                    .setMessage("O UniTV Free foi instalado. Para funcionar corretamente, abra Acesso a todos os arquivos e ative Permitir gerenciamento de todos os arquivos para o UniTV Free.")
                    .setPositiveButton("ABRIR PERMISSÃO", (dialog, which) -> abrirPermissaoTodosArquivosUnitv(pacote))
                    .setNegativeButton("DEPOIS", (dialog, which) -> {
                        Toast.makeText(this, "Você pode liberar essa permissão depois nas configurações do UniTV Free.", Toast.LENGTH_LONG).show();
                    })
                    .show();
        }
        return true;
    }

    private boolean temAcessoTodosArquivos(String pacote) {
        if (Build.VERSION.SDK_INT < 30) return true;
        try {
            PackageInfo info = getPackageManager().getPackageInfo(pacote, 0);
            AppOpsManager appOps = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
            if (appOps == null || info.applicationInfo == null) return false;
            int modo = appOps.checkOpNoThrow("android:manage_external_storage", info.applicationInfo.uid, pacote);
            return modo == AppOpsManager.MODE_ALLOWED;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private boolean abrirPermissaoTodosArquivosUnitv(String pacote) {
        if (pacote == null || pacote.trim().isEmpty()) return false;
        if (!pacoteInstalado(pacote)) {
            Toast.makeText(this, "Instale o UniTV Free antes de liberar o acesso aos arquivos.", Toast.LENGTH_LONG).show();
            return false;
        }
        if (Build.VERSION.SDK_INT < 30) {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(KEY_UNITV_PERMISSION_PACKAGE).apply();
            Toast.makeText(this, "O Android deste aparelho não usa a permissão especial Acesso a todos os arquivos.", Toast.LENGTH_LONG).show();
            return true;
        }

        Intent[] tentativas = new Intent[]{
                new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).setData(Uri.parse("package:" + pacote)),
                new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION),
                new Intent("android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION").setData(Uri.parse("package:" + pacote)),
                new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(Uri.parse("package:" + pacote))
        };
        for (Intent intent : tentativas) {
            try {
                aguardandoRetornoPermissaoUnitv = true;
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                Toast.makeText(this, "No UniTV Free, ative Permitir gerenciamento de todos os arquivos e volte ao ativador.", Toast.LENGTH_LONG).show();
                return true;
            } catch (Throwable ignored) {
                aguardandoRetornoPermissaoUnitv = false;
            }
        }
        Toast.makeText(this, "Não foi possível abrir a permissão automaticamente. Abra Configurações > Aplicativos > UniTV Free > Acesso a todos os arquivos.", Toast.LENGTH_LONG).show();
        return false;
    }

    private boolean abrirIntentPermissao(Intent intent, String mensagem) {
        try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            aguardandoRetornoPermissao = true;
            startActivity(intent);
            Toast.makeText(this, mensagem, Toast.LENGTH_LONG).show();
            return true;
        } catch (Exception ignored) {
            return false;
        }
    }

    private boolean abrirTelaTodosArquivos() {
        if (Build.VERSION.SDK_INT < 30) return false;
        String pacote = getPackageName();

        Intent[] tentativas = new Intent[]{
                // Tela verdadeira do Android 11+ para o app atual.
                new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).setData(Uri.parse("package:" + pacote)),
                // Lista geral: Acesso especial > Acesso a todos os arquivos.
                new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION),
                // Fallback usado por algumas ROMs de TV Box.
                new Intent("android.settings.MANAGE_ALL_FILES_ACCESS_PERMISSION"),
                new Intent("android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION").setData(Uri.parse("package:" + pacote)),
                // Último recurso: detalhes do app para o usuário entrar em permissões manualmente.
                new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(Uri.parse("package:" + pacote)),
                new Intent(Settings.ACTION_SETTINGS)
        };

        for (Intent i : tentativas) {
            if (abrirIntentPermissao(i, "Ative a permissão geral de arquivos para o ativador e volte aqui.")) return true;
        }
        return false;
    }

    private boolean abrirTelaInstalarAppsDesconhecidos() {
        if (Build.VERSION.SDK_INT < 26) return false;
        Intent intent = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName()));
        return abrirIntentPermissao(intent, "Marque 'Permitir desta fonte' e volte para o ativador.");
    }

    private boolean abrirTelaPermissoesDiretoDoApp() {
        String pacote = getPackageName();

        Intent[] tentativas = new Intent[]{
                new Intent("android.intent.action.MANAGE_APP_PERMISSIONS")
                        .putExtra("android.intent.extra.PACKAGE_NAME", pacote)
                        .putExtra("android.provider.extra.APP_PACKAGE", pacote)
                        .putExtra("package", pacote),
                new Intent("android.settings.APP_PERMISSION_SETTINGS")
                        .putExtra("android.intent.extra.PACKAGE_NAME", pacote)
                        .putExtra("android.provider.extra.APP_PACKAGE", pacote)
                        .putExtra("package", pacote),
                new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                        .setData(Uri.parse("package:" + pacote))
        };

        for (Intent intent : tentativas) {
            if (abrirIntentPermissao(intent, "Libere as permissões do aplicativo e volte para o ativador.")) return true;
        }
        return false;
    }

    private void abrirPermissoesNecessarias() {
        try {
            // Primeiro pede a permissão normal "Arquivos e mídia". A base targetSdk 28
            // depende dela em várias TVs, inclusive Android 11 e 12 com armazenamento legado.
            if (Build.VERSION.SDK_INT >= 23
                    && !temPermissaoArmazenamentoRuntime()
                    && !permissaoRuntimeJaSolicitada) {
                permissaoRuntimeJaSolicitada = true;
                aguardandoRetornoPermissao = true;
                requestPermissions(new String[]{
                        Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.READ_EXTERNAL_STORAGE
                }, 10);
                return;
            }

            // Se a permissão normal já está marcada, mas a escrita pública continua bloqueada,
            // abre o acesso especial de todos os arquivos somente nos Android 11+ que precisam dele.
            if (!testarEscritaPermissaoReal()
                    && Build.VERSION.SDK_INT >= 30
                    && !Environment.isExternalStorageManager()) {
                if (abrirTelaTodosArquivos()) return;
                if (abrirTelaPermissoesDiretoDoApp()) return;
            }

            if (!testarEscritaPermissaoReal()) {
                if (abrirTelaPermissoesDiretoDoApp()) return;
            }

            // Mantém a permissão de instalação no mesmo fluxo original desta base.
            if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
                if (abrirTelaInstalarAppsDesconhecidos()) return;
                if (abrirTelaPermissoesDiretoDoApp()) return;
            }

            verificarPermissoesEContinuar();
        } catch (Exception e) {
            if (abrirTelaPermissoesDiretoDoApp()) return;
            try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch (Exception ignored2) {}
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 10) {
            // Algumas TVs só atualizam o estado alguns milissegundos depois do diálogo.
            new Handler(Looper.getMainLooper()).postDelayed(this::abrirPermissoesNecessarias, 650);
        }
    }

    private void ativar() {
        if (!permissoesLiberadas()) {
            Toast.makeText(this, "Libere as permissões antes de usar a licença.", Toast.LENGTH_LONG).show();
            mostrarTelaPermissoes();
            return;
        }
        if (ativacaoBloqueadaPorNotificacao) {
            mensagem("Ativação temporariamente bloqueada pelo painel. " + mensagemBloqueioNotificacao);
            consultarNotificacaoDoPainel(true);
            return;
        }
        if (atualizacaoObrigatoriaPendente) {
            mensagem("A atualização obrigatória do ativador ainda não foi concluída. Atualize o aplicativo e tente novamente.");
            verificarAtualizacaoAtivador();
            return;
        }
        String licenca = edtLicenca.getText().toString().trim();
        if (!licenca.matches("\\d{11}")) {
            mensagem("Digite uma licença com exatamente 11 números.");
            return;
        }
        if (tipoAparelhoEscolhido == null || tipoAparelhoEscolhido.trim().isEmpty()) {
            mensagem("Escolha a opção do aparelho antes de ativar.");
            return;
        }

        ativacaoEmAndamento = true;
        progressoGlobal = 1;
        progress.setVisibility(View.VISIBLE);
        progress.setIndeterminate(false);
        progress.setProgress(1);
        btnAtivar.setEnabled(false);
        atualizarProgressoGlobal(1, "Iniciando ativação");

        new Thread(() -> {
            try {
                try { Thread.sleep(180); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
                atualizarProgressoGlobal(3, "Validando licença");
                String json = chamarApi(licenca);
                if (json == null || json.trim().isEmpty()) {
                    runOnUiThread(() -> finalizar("Não foi possível consultar a licença. Verifique sua internet e tente novamente."));
                    return;
                }
                JSONObject obj = new JSONObject(json);
                String status = obj.optString("status", "erro");
                String msg = obj.optString("mensagem", "Resposta recebida.");

                if (!"ok".equalsIgnoreCase(status)) {
                    String erroLicenca = msg == null || msg.trim().isEmpty()
                            ? "Licença inválida. Verifique o código e tente novamente."
                            : msg;
                    runOnUiThread(() -> finalizar(erroLicenca));
                    return;
                }
                atualizarProgressoGlobal(10, "Licença validada");

                // Mantém o mesmo pequeno intervalo do APK antigo que ativa corretamente
                // em aparelhos mais lentos e sistemas Android modificados.
                try { Thread.sleep(700); } catch (InterruptedException ignored) {
                    Thread.currentThread().interrupt();
                }

                String configUrl = normalizarUrl(obj.optString("config_url", ""));
                String propertiesUrl = normalizarUrl(obj.optString("properties_url", ""));
                String apkUrl = normalizarUrl(obj.optString("apk_url", ""));

                if (configUrl.isEmpty()) {
                    runOnUiThread(() -> finalizar("Licença liberada, mas o painel não enviou a config."));
                    return;
                }

                int fimConfigPrincipal = propertiesUrl.isEmpty() ? 30 : 25;
                byte[] configBytes = baixarBytes(configUrl, "Baixando configuração", 10, fimConfigPrincipal);

                // Compatibilidade restaurada do APK antigo: grava a nova configuração
                // em todos os caminhos conhecidos. Alguns Android TV, R Box e projetores
                // leem a config em caminhos diferentes de /storage/emulated/0/.config.
                // A limpeza manual continua disponível no botão próprio e não bloqueia
                // a ativação antes da nova config ser gravada.
                salvarConfigUnitvSegura(configBytes);

                if (!propertiesUrl.isEmpty()) {
                    byte[] propBytes = baixarBytes(propertiesUrl, "Baixando propriedades", 25, 30);
                    // Mantém o arquivo auxiliar somente na pasta do ativador. O arquivo
                    // .properties da raiz foi removido antes da ativação, igual ao APK de referência.
                    salvarArquivoAlternativo(Config.NOME_PROPERTIES_FINAL, propBytes);
                } else {
                    atualizarProgressoGlobal(30, "Configuração concluída");
                }

                File apkFile = null;
                if (!apkUrl.isEmpty()) {
                    if (!permissoesLiberadas()) {
                        runOnUiThread(() -> { finalizar("Permissão removida. Libere novamente para instalar o aplicativo."); mostrarTelaPermissoes(); });
                        return;
                    }
                    // Baixa diretamente para arquivo temporário em vez de manter o APK inteiro
                    // na RAM. Isso reduz pressão de memória e evita travar perto do fim em TV Boxes.
                    apkFile = baixarArquivo(apkUrl, "Baixando aplicativo", 30, 98);
                    if (!pareceApkValido(apkFile)) {
                        if (apkFile != null) apkFile.delete();
                        throw new java.io.IOException("O servidor não entregou um APK válido. Verifique o APK principal configurado no painel.");
                    }
                    if (apkFile == null || !apkFile.isFile() || apkFile.length() < 4) {
                        throw new java.io.IOException("O APK foi baixado, mas não pôde ser salvo integralmente no aparelho.");
                    }
                    atualizarProgressoGlobal(99, "Download concluído");
                } else {
                    atualizarProgressoGlobal(98, "Aplicativo não configurado");
                }

                File finalApkFile = apkFile;
                runOnUiThread(() -> {
                    if (finalApkFile != null) {
                        atualizarProgressoGlobal(100, "Instalação pronta");
                        ativacaoEmAndamento = false;
                        btnAtivar.setEnabled(true);
                        txtStatus.setText(comAvisoConfig("100% — Configuração salva. Abrindo instalação do aplicativo..."));
                        Toast.makeText(this, "Download concluído. Abrindo instalação.", Toast.LENGTH_LONG).show();
                        abrirInstalador(finalApkFile);
                    } else {
                        finalizar(comAvisoConfig("Configuração salva, mas nenhum APK principal foi configurado no painel."));
                    }
                });
            } catch (Exception e) {
                String detalhe = e.getMessage() == null || e.getMessage().trim().isEmpty()
                        ? "falha inesperada durante o download" : e.getMessage();
                runOnUiThread(() -> finalizar("Não foi possível concluir a instalação: " + detalhe
                        + ". A licença continua vinculada a este aparelho; toque em ATIVAR LICENÇA para tentar novamente."));
            }
        }, "ativacao-download").start();
    }

    private boolean pareceApkValido(byte[] dados) {
        if (dados == null || dados.length < 4) return false;
        // APK é um arquivo ZIP; rejeita páginas HTML/JSON retornadas por erro do servidor.
        return dados[0] == 'P' && dados[1] == 'K'
                && ((dados[2] == 3 && dados[3] == 4)
                || (dados[2] == 5 && dados[3] == 6)
                || (dados[2] == 7 && dados[3] == 8));
    }

    private boolean pareceApkValido(File arquivo) {
        if (arquivo == null || !arquivo.isFile() || arquivo.length() < 4) return false;
        // APK é um ZIP; rejeita HTML/JSON de erro do servidor.
        try (InputStream in = new java.io.FileInputStream(arquivo)) {
            int a = in.read(), b = in.read(), c = in.read(), d = in.read();
            return a == 'P' && b == 'K'
                    && ((c == 3 && d == 4) || (c == 5 && d == 6) || (c == 7 && d == 8));
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Baixa arquivos grandes diretamente ao disco, validando HTTP, EOF e Content-Length.
     * O APK só recebe o nome definitivo depois de chegar completo.
     */
    private File baixarArquivo(String urlStr, String etapa, int inicio, int fim) throws Exception {
        int inicioSeguro = Math.max(1, Math.min(99, inicio));
        int fimSeguro = Math.max(inicioSeguro + 1, Math.min(99, fim));
        atualizarProgressoGlobal(inicioSeguro, etapa);
        Exception ultimoErro = null;

        File pasta = getExternalFilesDir(null);
        if (pasta == null) {
            pasta = new File(Environment.getExternalStorageDirectory(), Config.PASTA_ALTERNATIVA);
        }
        if (!pasta.exists() && !pasta.mkdirs() && !pasta.isDirectory()) {
            throw new java.io.IOException("Não foi possível criar a pasta temporária do download.");
        }

        for (String tentativa : gerarUrlsFallback(urlStr)) {
            HttpURLConnection conn = null;
            File temporario = null;
            try {
                conn = (HttpURLConnection) new URL(tentativa).openConnection();
                conn.setUseCaches(false);
                conn.setInstanceFollowRedirects(true);
                conn.setConnectTimeout(20000);
                conn.setReadTimeout(180000);
                conn.setRequestProperty("Cache-Control", "no-cache");
                conn.setRequestProperty("Accept-Encoding", "identity");
                conn.setRequestProperty("User-Agent", "NEXO-Activator/3.6.5.2.5");

                int http = conn.getResponseCode();
                if (http < 200 || http >= 300) {
                    throw new java.io.IOException("Servidor retornou HTTP " + http + " no download do APK.");
                }
                long total = -1L;
                try {
                    String h = conn.getHeaderField("Content-Length");
                    if (h != null && !h.trim().isEmpty()) total = Long.parseLong(h.trim());
                } catch (Exception ignored) {}

                temporario = File.createTempFile("unitv-download-", ".part", pasta);
                long baixado = 0L;
                int faixa = Math.max(0, fimSeguro - inicioSeguro - 1);
                long ultimoMarco = 0L;
                try (InputStream in = new BufferedInputStream(conn.getInputStream());
                     FileOutputStream out = new FileOutputStream(temporario, false)) {
                    byte[] buffer = new byte[64 * 1024];
                    int len;
                    while ((len = in.read(buffer)) != -1) {
                        out.write(buffer, 0, len);
                        baixado += len;
                        int pct;
                        if (total > 0L) {
                            pct = inicioSeguro + Math.min(faixa,
                                    (int)Math.min(Integer.MAX_VALUE, (baixado * (long)faixa) / total));
                        } else {
                            long marco = baixado / (512L * 1024L);
                            if (marco > ultimoMarco) ultimoMarco = marco;
                            pct = inicioSeguro + (int)Math.min(faixa, ultimoMarco);
                        }
                        if (pct > progressoGlobal) atualizarProgressoGlobal(pct, etapa);
                    }
                    out.flush();
                    out.getFD().sync();
                }
                if (baixado <= 0L) throw new java.io.IOException("O servidor enviou um APK vazio.");
                if (total > 0L && baixado != total) {
                    throw new java.io.IOException("Download incompleto: recebidos " + baixado + " de " + total + " bytes.");
                }
                if (temporario.length() != baixado) {
                    throw new java.io.IOException("O arquivo temporário não foi gravado integralmente.");
                }
                if (!pareceApkValido(temporario)) {
                    throw new java.io.IOException("A resposta do servidor não é um APK válido.");
                }

                File destino = new File(pasta, Config.NOME_APK_FINAL);
                if (destino.exists() && !destino.delete()) {
                    throw new java.io.IOException("Não foi possível substituir o APK anterior.");
                }
                if (!temporario.renameTo(destino)) {
                    try (InputStream in = new java.io.FileInputStream(temporario);
                         FileOutputStream out = new FileOutputStream(destino, false)) {
                        byte[] buffer = new byte[64 * 1024];
                        int len;
                        while ((len = in.read(buffer)) != -1) out.write(buffer, 0, len);
                        out.flush();
                        out.getFD().sync();
                    }
                    if (destino.length() != baixado) {
                        destino.delete();
                        throw new java.io.IOException("Não foi possível finalizar a gravação do APK.");
                    }
                    temporario.delete();
                }
                atualizarProgressoGlobal(fimSeguro, etapa);
                return destino;
            } catch (Exception e) {
                ultimoErro = e;
                if (temporario != null && temporario.exists()) temporario.delete();
            } finally {
                if (conn != null) conn.disconnect();
            }
        }
        throw ultimoErro == null ? new java.io.IOException("Falha ao baixar o APK.") : ultimoErro;
    }

    private void atualizarProgressoGlobal(int porcentagem, String etapa) {
        int limitado = Math.max(1, Math.min(100, porcentagem));
        if (limitado < progressoGlobal) limitado = progressoGlobal;
        progressoGlobal = limitado;
        final int mostrar = limitado;
        runOnUiThread(() -> {
            if (progress == null || txtStatus == null) return;
            progress.setVisibility(View.VISIBLE);
            progress.setIndeterminate(false);
            progress.setProgress(mostrar);
            txtStatus.setText(etapa + "... " + mostrar + "%");
        });
    }

    private void verificarAtualizacaoAtivador() {
        new Thread(() -> {
            try {
                String json = httpGetDireto(adicionarCacheBuster(Config.API_ATIVADOR_UPDATE));
                if (json == null || json.trim().isEmpty()) return;
                JSONObject obj = new JSONObject(json);
                if (!"ok".equalsIgnoreCase(obj.optString("status", "ok"))) return;
                int versaoRemota = obj.optInt("version_code", obj.optInt("ativador_version_code", 0));
                int versaoInstalada = obterVersionCodeInstalado();
                if (versaoRemota <= versaoInstalada) return;

                String url = normalizarUrl(valorNaoVazio(obj.optString("apk_url", ""), obj.optString("ativador_apk_url", "")));
                String mensagemUpdate = valorNaoVazio(obj.optString("message", ""), obj.optString("ativador_update_msg", "Nova versão do ativador disponível."));
                boolean obrigatoria = obj.optInt("required", obj.optInt("ativador_update_obrigatoria", 0)) == 1;
                versaoRemotaAtivador = versaoRemota;
                atualizacaoObrigatoriaPendente = obrigatoria;
                runOnUiThread(() -> mostrarDialogoAtualizacaoAtivador(versaoInstalada, mensagemUpdate, obrigatoria, url));
            } catch (Exception ignored) {
                // Falha na API de atualização não impede a ativação normal.
            }
        }, "nexo-activator-update-check").start();
    }

    private int obterVersionCodeInstalado() {
        try {
            PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0);
            if (Build.VERSION.SDK_INT >= 28) return (int) info.getLongVersionCode();
            return info.versionCode;
        } catch (Exception ignored) { return 0; }
    }

    private void mostrarDialogoAtualizacaoAtivador(int versaoInstalada, String texto, boolean obrigatoria, String url) {
        if (!atividadeDisponivel() || dialogoAtualizacaoAberto) return;
        dialogoAtualizacaoAberto = true;
        String mensagemFinal = texto + "\n\nVersão instalada: " + versaoInstalada + "\nNova versão: " + versaoRemotaAtivador;
        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle(obrigatoria ? "Atualização obrigatória" : "Atualização do ativador")
                .setMessage(url.isEmpty() ? mensagemFinal + "\n\nO painel não informou um APK de atualização do ativador." : mensagemFinal)
                .setCancelable(!obrigatoria);
        if (!url.isEmpty()) {
            builder.setPositiveButton("BAIXAR E INSTALAR", (d, w) -> baixarAtualizacaoAtivador(url));
        } else {
            builder.setPositiveButton("ENTENDI", (d, w) -> {});
        }
        if (!obrigatoria) builder.setNegativeButton("DEPOIS", (d, w) -> {});
        AlertDialog dialog = builder.create();
        dialog.setOnDismissListener(d -> dialogoAtualizacaoAberto = false);
        dialog.show();
    }

    private void baixarAtualizacaoAtivador(String url) {
        if (url == null || url.trim().isEmpty()) {
            mensagem("O painel não configurou o APK de atualização do ativador.");
            return;
        }
        new Thread(() -> {
            try {
                byte[] bytes = baixarBytes(url, "Baixando atualização do ativador", 0, 95);
                if (bytes == null || bytes.length < 1024) throw new Exception("O APK recebido está vazio ou incompleto.");
                File arquivo = salvarArquivoAlternativo("ativador-update.apk", bytes);
                runOnUiThread(() -> {
                    atualizarProgressoGlobal(100, "Atualização baixada");
                    abrirInstalador(arquivo);
                });
            } catch (Exception e) {
                runOnUiThread(() -> mensagem("Não foi possível baixar a atualização do ativador: " + e.getMessage()));
            }
        }, "nexo-activator-update-download").start();
    }

    private String chamarApi(String licenca) throws Exception {
        baseOrigemAtivacao = Config.BASE_URL;
        String androidId = obterIdentificadorDispositivo();
        String aparelho = Build.MANUFACTURER + " " + Build.MODEL;
        JSONObject body = new JSONObject();
        body.put("licenca", licenca);
        body.put("device", aparelho);
        body.put("device_id", androidId);
        body.put("android", String.valueOf(Build.VERSION.SDK_INT));
        body.put("tipo", tipoAparelhoEscolhido);
        body.put("tipo_aparelho", tipoAparelhoEscolhido);

        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(Config.API_ATIVAR).openConnection();
            conn.setUseCaches(false);
            conn.setConnectTimeout(20000);
            conn.setReadTimeout(45000);
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            conn.setRequestProperty("Cache-Control", "no-cache, no-store, must-revalidate");
            byte[] request = body.toString().getBytes(StandardCharsets.UTF_8);
            try (OutputStream out = conn.getOutputStream()) { out.write(request); }
            int code = conn.getResponseCode();
            InputStream stream = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
            if (stream == null) throw new Exception("API NEXO não respondeu. Código HTTP: " + code);
            StringBuilder result = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) result.append(line);
            }
            return result.toString();
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private String obterIdentificadorDispositivo() {
        try {
            String androidId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
            if (androidId != null && !androidId.trim().isEmpty()) return androidId.trim();
        } catch (Throwable ignored) {}
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String fallback = prefs.getString("device_id_fallback", "");
        if (fallback == null || fallback.trim().isEmpty()) {
            fallback = "local-" + UUID.randomUUID().toString();
            prefs.edit().putString("device_id_fallback", fallback).apply();
        }
        return fallback;
    }

    private String httpGetDireto(String urlStr) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(urlStr).openConnection();
        conn.setUseCaches(false);
        conn.setRequestProperty("Cache-Control", "no-cache, no-store, must-revalidate");
        conn.setRequestProperty("Pragma", "no-cache");
        conn.setConnectTimeout(20000);
        conn.setReadTimeout(45000);
        conn.setRequestMethod("GET");
        int code = conn.getResponseCode();
        InputStream is = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
        if (is == null) throw new Exception("API não respondeu. Código HTTP: " + code);
        BufferedReader br = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        return sb.toString();
    }

    private String httpGet(String urlStr) throws Exception {
        Exception ultimoErro = null;
        for (String tentativa : gerarUrlsFallback(urlStr)) {
            try {
                HttpURLConnection conn = (HttpURLConnection) new URL(tentativa).openConnection();
                conn.setUseCaches(false);
                conn.setRequestProperty("Cache-Control", "no-cache, no-store, must-revalidate");
                conn.setRequestProperty("Pragma", "no-cache");
                conn.setConnectTimeout(20000);
                conn.setReadTimeout(30000);
                conn.setRequestMethod("GET");
                InputStream is = conn.getResponseCode() >= 400 ? conn.getErrorStream() : conn.getInputStream();
                if (is == null) throw new Exception("API não respondeu. Código HTTP: " + conn.getResponseCode());
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line);
                br.close();
                return sb.toString();
            } catch (Exception e) {
                ultimoErro = e;
            }
        }
        throw ultimoErro == null ? new Exception("Falha de conexão.") : ultimoErro;
    }

    private String adicionarCacheBuster(String url) {
        if (url == null || url.trim().isEmpty()) return "";
        String separador = url.contains("?") ? "&" : "?";
        return url + separador + "_appv=" + System.currentTimeMillis();
    }

    private String normalizarUrl(String url) {
        if (url == null) return "";
        url = url.trim();
        if (url.isEmpty()) return "";
        if (url.startsWith("http://") || url.startsWith("https://")) {
            return url.replace("http://", "https://").replace("://www.", "://");
        }
        String base = (baseOrigemAtivacao == null || baseOrigemAtivacao.trim().isEmpty()) ? Config.BASE_URL : baseOrigemAtivacao;
        return base + "/" + url.replaceFirst("^/+", "");
    }

    private List<String> gerarUrlsFallback(String urlStr) {
        List<String> urls = new ArrayList<>();
        if (urlStr == null) return urls;

        String normalizada = urlStr.trim();
        if (normalizada.isEmpty()) return urls;
        normalizada = normalizada.replace("http://", "https://").replace("://www.", "://");

        String path = normalizada;
        boolean dominioConhecido = false;
        boolean urlAbsoluta = false;

        try {
            URL u = new URL(normalizada);
            urlAbsoluta = true;
            String host = u.getHost() == null ? "" : u.getHost();
            if (host.startsWith("www.")) host = host.substring(4);
            path = u.getFile();
            for (String base : Config.BASE_URLS) {
                URL b = new URL(base);
                String baseHost = b.getHost() == null ? "" : b.getHost();
                if (baseHost.startsWith("www.")) baseHost = baseHost.substring(4);
                if (host.equalsIgnoreCase(baseHost)) {
                    dominioConhecido = true;
                    break;
                }
            }
        } catch (Exception ignored) {
            path = "/" + normalizada.replaceFirst("^/+", "");
            dominioConhecido = true;
        }

        if (dominioConhecido) {
            // Tenta primeiro o domínio que veio na URL. Depois usa os demais como fallback.
            // Isso evita que um link do NEXO seja enviado primeiro para um domínio legado.
            if (urlAbsoluta) urls.add(normalizada);
            for (String base : Config.BASE_URLS) {
                String tentativa = base + (path.startsWith("/") ? path : "/" + path);
                boolean jaAdicionada = false;
                for (String existente : urls) {
                    if (existente.equalsIgnoreCase(tentativa)) {
                        jaAdicionada = true;
                        break;
                    }
                }
                if (!jaAdicionada) urls.add(tentativa);
            }
        } else {
            urls.add(normalizada);
        }
        return urls;
    }

    private void carregarImagemComFallback(ImageView view, String url) {
        view.setImageResource(com.ativacao.app.R.drawable.ic_launcher);
        new Thread(() -> {
            try {
                Bitmap bmp = baixarBitmap(url);
                if (bmp != null) runOnUiThread(() -> view.setImageBitmap(bmp));
            } catch (Exception ignored) {
                runOnUiThread(() -> view.setImageResource(com.ativacao.app.R.drawable.ic_launcher));
            }
        }, "logo-load").start();
    }

    private Bitmap baixarBitmap(String urlStr) throws Exception {
        Exception ultimoErro = null;
        for (String tentativa : gerarUrlsFallback(urlStr)) {
            try {
                HttpURLConnection conn = (HttpURLConnection) new URL(tentativa).openConnection();
                conn.setUseCaches(false);
                conn.setRequestProperty("Cache-Control", "no-cache, no-store, must-revalidate");
                conn.setRequestProperty("Pragma", "no-cache");
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(30000);
                InputStream in = conn.getInputStream();
                Bitmap bmp = BitmapFactory.decodeStream(in);
                in.close();
                return bmp;
            } catch (Exception e) {
                ultimoErro = e;
            }
        }
        throw ultimoErro == null ? new Exception("Falha ao baixar imagem.") : ultimoErro;
    }

    private void carregarImagem(ImageView view, String url) {
        new Thread(() -> {
            try {
                Bitmap bmp = baixarBitmap(url);
                if (bmp != null) runOnUiThread(() -> { view.setImageBitmap(bmp); view.setVisibility(View.VISIBLE); });
            } catch (Exception ignored) {}
        }).start();
    }

    private byte[] baixarBytes(String urlStr, String etapa, int inicio, int fim) throws Exception {
        int inicioSeguro = Math.max(1, Math.min(99, inicio));
        int fimSeguro = Math.max(inicioSeguro + 1, Math.min(99, fim));
        atualizarProgressoGlobal(inicioSeguro, etapa);

        Exception ultimoErro = null;
        for (String tentativa : gerarUrlsFallback(urlStr)) {
            HttpURLConnection conn = null;
            try {
                conn = (HttpURLConnection) new URL(tentativa).openConnection();
                conn.setUseCaches(false);
                conn.setInstanceFollowRedirects(true);
                conn.setRequestProperty("Cache-Control", "no-cache, no-store, must-revalidate");
                conn.setRequestProperty("Pragma", "no-cache");
                conn.setConnectTimeout(20000);
                conn.setReadTimeout(90000);

                int http = conn.getResponseCode();
                if (http < 200 || http >= 300) {
                    throw new java.io.IOException("Servidor retornou HTTP " + http);
                }

                long total = -1L;
                try {
                    String cabecalho = conn.getHeaderField("Content-Length");
                    if (cabecalho != null && !cabecalho.trim().isEmpty()) total = Long.parseLong(cabecalho.trim());
                } catch (Exception ignored) {}

                try (InputStream in = new BufferedInputStream(conn.getInputStream());
                     java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream()) {
                    byte[] buffer = new byte[8192];
                    int len;
                    long baixado = 0L;
                    int faixa = Math.max(0, fimSeguro - inicioSeguro - 1);
                    long ultimoMarcoDesconhecido = 0L;

                    while ((len = in.read(buffer)) != -1) {
                        out.write(buffer, 0, len);
                        baixado += len;
                        int pct;
                        if (total > 0L) {
                            pct = inicioSeguro + Math.min(faixa,
                                    (int) Math.min(Integer.MAX_VALUE, (baixado * (long) faixa) / total));
                        } else {
                            // Alguns servidores/CDNs omitem Content-Length. Continua animando por bytes
                            // recebidos, mas reserva o último percentual para o EOF real do download.
                            long marco = baixado / (256L * 1024L);
                            if (marco > ultimoMarcoDesconhecido) ultimoMarcoDesconhecido = marco;
                            pct = inicioSeguro + (int) Math.min(faixa, ultimoMarcoDesconhecido);
                        }
                        if (pct > progressoGlobal) atualizarProgressoGlobal(pct, etapa);
                    }

                    if (baixado <= 0L) throw new java.io.IOException("O servidor enviou um arquivo vazio.");
                    if (total > 0L && baixado < total) {
                        throw new java.io.IOException("Download incompleto (" + baixado + " de " + total + " bytes).");
                    }
                    byte[] resultado = out.toByteArray();
                    atualizarProgressoGlobal(fimSeguro, etapa);
                    return resultado;
                }
            } catch (Exception e) {
                ultimoErro = e;
            } finally {
                if (conn != null) conn.disconnect();
            }
        }
        throw ultimoErro == null ? new java.io.IOException("Falha ao baixar arquivo.") : ultimoErro;
    }

    private void salvarEmPastas(String nome, byte[] dados) throws Exception {
        if (Config.NOME_CONFIG_FINAL.equals(nome)) {
            salvarConfigUnitvSegura(dados);
            return;
        }
        if (Config.NOME_PROPERTIES_FINAL.equals(nome)) {
            // Mantém properties apenas na pasta do próprio ativador. Não mexe em cache/dados do UniTV.
            salvarArquivoAlternativo(nome, dados);
            return;
        }
        salvarArquivoAlternativo(nome, dados);
    }

    private File[] caminhosConfigUnitv() {
        List<File> caminhos = new ArrayList<>();

        // Caminho correto do próprio aparelho/app. O Android decide o local real.
        File pastaApp = getExternalFilesDir(null);
        if (pastaApp != null) {
            adicionarCaminhoConfig(caminhos, new File(pastaApp, Config.NOME_CONFIG_FINAL));
        }

        // Alguns aparelhos/TV Box retornam mais de um armazenamento externo.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            File[] pastasApp = getExternalFilesDirs(null);
            if (pastasApp != null) {
                for (File pasta : pastasApp) {
                    if (pasta != null) adicionarCaminhoConfig(caminhos, new File(pasta, Config.NOME_CONFIG_FINAL));
                }
            }
        }

        // Caminhos reais comuns, acrescentados sem remover os antigos.
        File raiz = Environment.getExternalStorageDirectory();
        if (raiz != null) {
            adicionarCaminhoConfig(caminhos, new File(raiz, Config.NOME_CONFIG_FINAL));
            adicionarCaminhoConfig(caminhos, new File(raiz, "Android/" + Config.NOME_CONFIG_FINAL));
            adicionarCaminhoConfig(caminhos, new File(raiz, "Download/" + Config.NOME_CONFIG_FINAL));
            adicionarCaminhoConfig(caminhos, new File(raiz, "Documents/" + Config.NOME_CONFIG_FINAL));

            // Caminho adicional do pacote oficial do UniTV. Apenas acrescentado;
            // nenhum caminho antigo foi removido ou substituído.
            adicionarCaminhoConfig(caminhos, new File(raiz,
                    "Android/data/com.integration.unitvsiptv/files/" + Config.NOME_CONFIG_FINAL));
        }

        // Detecta também cartão/armazenamento secundário e acrescenta o caminho do UniTV.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            File[] pastasDoAtivador = getExternalFilesDirs(null);
            if (pastasDoAtivador != null) {
                for (File pasta : pastasDoAtivador) {
                    if (pasta == null) continue;
                    String absoluto = pasta.getAbsolutePath();
                    int posAndroidData = absoluto.indexOf("/Android/data/");
                    if (posAndroidData > 0) {
                        File raizVolume = new File(absoluto.substring(0, posAndroidData));
                        adicionarCaminhoConfig(caminhos, new File(raizVolume,
                                "Android/data/com.integration.unitvsiptv/files/" + Config.NOME_CONFIG_FINAL));
                    }
                }
            }
        }

        // Caminhos antigos mantidos exatamente para compatibilidade.
        adicionarCaminhoConfig(caminhos, new File("/storage/emulated/0/.config"));
        adicionarCaminhoConfig(caminhos, new File("/storage/emulated/0/Android/.config"));
        adicionarCaminhoConfig(caminhos, new File("/sdcard/.config"));
        adicionarCaminhoConfig(caminhos, new File("/sdcard/Android/.config"));
        adicionarCaminhoConfig(caminhos, new File("/storage/self/primary/.config"));
        adicionarCaminhoConfig(caminhos, new File("/storage/self/primary/Android/.config"));

        // Aliases do caminho adicional do pacote UniTV em ROMs de TV Box.
        adicionarCaminhoConfig(caminhos, new File("/storage/emulated/0/Android/data/com.integration.unitvsiptv/files/.config"));
        adicionarCaminhoConfig(caminhos, new File("/sdcard/Android/data/com.integration.unitvsiptv/files/.config"));
        adicionarCaminhoConfig(caminhos, new File("/storage/self/primary/Android/data/com.integration.unitvsiptv/files/.config"));

        return caminhos.toArray(new File[0]);
    }

    private void adicionarCaminhoConfig(List<File> lista, File arquivo) {
        if (arquivo == null) return;
        String caminho = arquivo.getAbsolutePath();
        for (File existente : lista) {
            if (existente != null && existente.getAbsolutePath().equals(caminho)) return;
        }
        lista.add(arquivo);
    }

    /**
     * Limpeza exata observada no APK que ativou corretamente. Antes de copiar a nova
     * configuração, remove somente os quatro alvos usados pelo UniTV na memória principal.
     */
    private ResultadoLimpezaConfig limparAntesDaAtivacaoComoReferencia() {
        List<File> alvos = new ArrayList<>();
        File raiz = Environment.getExternalStorageDirectory();
        if (raiz != null) {
            adicionarCaminhoConfig(alvos, new File(raiz, ".config"));
            adicionarCaminhoConfig(alvos, new File(raiz, "Android/.config"));
            adicionarCaminhoConfig(alvos, new File(raiz, ".properties"));
            adicionarCaminhoConfig(alvos, new File(raiz, "Alarms/system_uf/google.wav"));
        }

        int apagados = 0;
        for (File alvo : alvos) {
            try {
                if (alvo.exists() && apagarRecursivamente(alvo)) apagados++;
            } catch (Throwable ignored) {}
        }

        // Se a ROM bloquear algum caminho, repete somente esses mesmos alvos via SU.
        int apagadosSu = apagarComSu(alvos);
        if (apagadosSu > 0) apagados += apagadosSu;

        StringBuilder restantes = new StringBuilder();
        for (File alvo : alvos) {
            try {
                if (alvo.exists()) {
                    if (restantes.length() > 0) restantes.append("\n");
                    restantes.append(alvo.getAbsolutePath());
                }
            } catch (Throwable ignored) {}
        }

        ResultadoLimpezaConfig resultado = new ResultadoLimpezaConfig();
        resultado.apagados = apagados;
        resultado.restantes = restantes.toString();
        return resultado;
    }

    /**
     * Copia a configuração exatamente como o APK de referência que ativou na hora:
     * somente para .config e Android/.config na raiz do armazenamento principal.
     */
    private void salvarConfigComoReferencia(byte[] dados) throws Exception {
        File raiz = Environment.getExternalStorageDirectory();
        if (raiz == null) throw new Exception("Armazenamento principal não encontrado.");

        File[] destinos = new File[]{
                new File(raiz, ".config"),
                new File(raiz, "Android/.config")
        };

        int salvos = 0;
        StringBuilder erros = new StringBuilder();
        for (File destino : destinos) {
            try {
                File pai = destino.getParentFile();
                if (pai != null && !pai.exists() && !pai.mkdirs() && !pai.exists()) {
                    throw new Exception("Não foi possível criar a pasta " + pai.getAbsolutePath());
                }
                escreverArquivo(destino, dados);
                if (!destino.exists() || destino.length() != dados.length) {
                    throw new Exception("Arquivo gravado incompleto");
                }
                salvos++;
            } catch (Throwable erro) {
                if (erros.length() > 0) erros.append("\n");
                erros.append(destino.getAbsolutePath()).append(" -> ").append(erro.getMessage());
            }
        }

        if (salvos != destinos.length) {
            throw new Exception("A configuração precisa ser gravada nos dois caminhos. Erros:\n" + erros);
        }
        avisoSalvamentoConfig = "Config gravada nos dois caminhos corretos, igual ao APK de referência.";
    }

    private void salvarConfigUnitvSegura(byte[] dados) throws Exception {
        int salvos = 0;
        StringBuilder erros = new StringBuilder();

        for (File destino : caminhosConfigUnitv()) {
            try {
                File pai = destino.getParentFile();
                if (pai != null && !pai.exists()) pai.mkdirs();
                escreverArquivo(destino, dados);
                salvos++;
            } catch (Exception e) {
                if (erros.length() < 900) {
                    erros.append(destino.getAbsolutePath())
                            .append(" -> ")
                            .append(e.getClass().getSimpleName())
                            .append(": ")
                            .append(e.getMessage())
                            .append("\n");
                }
            }
        }

        if (salvos == 0) {
            avisoSalvamentoConfig = "";
            throw new Exception("Não salvou a config em nenhum caminho. Erros:\n" + erros.toString());
        }

        if (erros.length() > 0) {
            avisoSalvamentoConfig = "Config salva em " + salvos + " caminho(s), mas alguns caminhos deram erro para você corrigir:\n" + erros.toString();
        } else {
            avisoSalvamentoConfig = "Config salva em " + salvos + " caminho(s), sem erro de gravação.";
        }
    }

    private boolean permissaoArquivosLiberadaParaLimpeza() {
        // O botão de apagar depende somente do acesso aos arquivos.
        // A permissão para instalar APK não pode bloquear a exclusão da config.
        if (Build.VERSION.SDK_INT < 23) return true;
        if (Build.VERSION.SDK_INT >= 30 && Environment.isExternalStorageManager()) return true;
        if (temPermissaoArmazenamentoRuntime()) return true;
        return testarEscritaPermissaoReal();
    }

    private void apagarConfigBaixada() {
        if (!permissaoArquivosLiberadaParaLimpeza()) {
            Toast.makeText(this, "Libere a permissão de arquivos antes de apagar a config.", Toast.LENGTH_LONG).show();
            mostrarTelaPermissoes();
            return;
        }

        // A limpeza pode consultar vários armazenamentos e, quando necessário, solicitar
        // autorização SU. Executa fora da thread da interface para não travar a TV Box.
        if (btnApagarConfig != null) btnApagarConfig.setEnabled(false);
        Toast.makeText(this, "Apagando configurações...", Toast.LENGTH_SHORT).show();

        new Thread(() -> {
            ResultadoLimpezaConfig resultado = limparArquivosUnitvCompleto();
            runOnUiThread(() -> {
                if (btnApagarConfig != null) btnApagarConfig.setEnabled(true);

                if (resultado.restantes.length() > 0) {
                    mensagem("Alguns arquivos não puderam ser apagados. Autorize o acesso de superusuário (SU) e tente novamente.\n\n" + resultado.restantes);
                } else if (resultado.apagados > 0) {
                    mensagem("Config e arquivos auxiliares apagados com sucesso. Total removido: " + resultado.apagados + ".");
                } else {
                    mensagem("Nenhuma config encontrada para apagar.");
                }
            });
        }, "unitv-config-cleaner").start();
    }

    /**
     * Replica a limpeza comprovada pelo APK de referência e mantém também todos os
     * caminhos usados por este ativador. Os alvos são estritamente os arquivos do
     * UniTV: .config, Android/.config, .properties e Alarms/system_uf/google.wav.
     */
    private ResultadoLimpezaConfig limparArquivosUnitvCompleto() {
        List<File> alvos = caminhosLimpezaCompletaUnitv();
        int apagados = 0;
        // Primeira tentativa: API normal do Android. Também remove diretórios .config
        // recursivamente, igual ao APK que foi enviado para comparação.
        for (File alvo : alvos) {
            try {
                if (!alvo.exists()) continue;
                if (apagarRecursivamente(alvo)) apagados++;
            } catch (Throwable ignored) {}
        }

        // Em Android/TV Box com armazenamento protegido, repete somente os caminhos
        // específicos acima via SU. Não apaga dados de outros aplicativos nem pastas genéricas.
        int apagadosSu = apagarComSu(alvos);
        if (apagadosSu > 0) apagados += apagadosSu;

        StringBuilder restantes = new StringBuilder();
        for (File alvo : alvos) {
            try {
                if (alvo.exists()) {
                    if (restantes.length() > 0) restantes.append("\n");
                    restantes.append(alvo.getAbsolutePath());
                }
            } catch (Throwable ignored) {}
        }

        ResultadoLimpezaConfig resultado = new ResultadoLimpezaConfig();
        resultado.apagados = apagados;
        resultado.restantes = restantes.toString();
        return resultado;
    }

    private List<File> caminhosLimpezaCompletaUnitv() {
        List<File> alvos = new ArrayList<>();

        // Todos os locais onde este ativador salva .config.
        for (File arquivo : caminhosConfigUnitv()) adicionarCaminhoConfig(alvos, arquivo);

        // Caminhos exatos usados pelo APK de referência que apaga de verdade.
        File raiz = Environment.getExternalStorageDirectory();
        if (raiz != null) {
            adicionarCaminhoConfig(alvos, new File(raiz, ".config"));
            adicionarCaminhoConfig(alvos, new File(raiz, "Android/.config"));
            adicionarCaminhoConfig(alvos, new File(raiz, ".properties"));
            adicionarCaminhoConfig(alvos, new File(raiz, "Alarms/system_uf/google.wav"));
        }

        // Properties eventualmente salvas na pasta privada externa do ativador.
        File pastaApp = getExternalFilesDir(null);
        if (pastaApp != null) adicionarCaminhoConfig(alvos, new File(pastaApp, Config.NOME_PROPERTIES_FINAL));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            File[] pastasApp = getExternalFilesDirs(null);
            if (pastasApp != null) {
                for (File pasta : pastasApp) {
                    if (pasta != null) adicionarCaminhoConfig(alvos, new File(pasta, Config.NOME_PROPERTIES_FINAL));
                }
            }
        }

        // Alias comuns mantidos para boxes que expõem a memória por caminhos diferentes.
        adicionarCaminhoConfig(alvos, new File("/storage/emulated/0/.properties"));
        adicionarCaminhoConfig(alvos, new File("/sdcard/.properties"));
        adicionarCaminhoConfig(alvos, new File("/storage/self/primary/.properties"));
        adicionarCaminhoConfig(alvos, new File("/storage/emulated/0/Alarms/system_uf/google.wav"));
        adicionarCaminhoConfig(alvos, new File("/sdcard/Alarms/system_uf/google.wav"));
        adicionarCaminhoConfig(alvos, new File("/storage/self/primary/Alarms/system_uf/google.wav"));

        return alvos;
    }

    private boolean apagarRecursivamente(File arquivo) {
        if (arquivo == null) return true;
        try {
            if (arquivo.isDirectory()) {
                File[] filhos = arquivo.listFiles();
                if (filhos != null) {
                    for (File filho : filhos) {
                        if (!apagarRecursivamente(filho)) return false;
                    }
                }
            }
            return !arquivo.exists() || arquivo.delete();
        } catch (Throwable erro) {
            return false;
        }
    }

    private int apagarComSu(List<File> alvos) {
        try {
            if (alvos == null || alvos.isEmpty()) return 0;

            StringBuilder script = new StringBuilder();
            script.append("REMOVED=0\n");
            for (File alvo : alvos) {
                if (alvo == null) continue;
                String caminho = escaparShell(alvo.getAbsolutePath());
                script.append("P='").append(caminho).append("'\n")
                        .append("if [ -e \"$P\" ] || [ -L \"$P\" ]; then ")
                        .append("rm -rf \"$P\" >/dev/null 2>&1 && REMOVED=$((REMOVED+1)); fi\n");
            }
            script.append("sync >/dev/null 2>&1 || true\n")
                    .append("echo UNITV_CONFIG_REMOVED=$REMOVED\n");

            String su = ultimaInfoRoot != null && ultimaInfoRoot.suCommand != null
                    && !ultimaInfoRoot.suCommand.trim().isEmpty()
                    ? ultimaInfoRoot.suCommand.trim() : "su";
            CommandResult comando = executarComando(new String[]{su, "-c", script.toString()}, 35);
            if (comando == null || comando.output == null) return 0;

            java.util.regex.Matcher matcher = java.util.regex.Pattern
                    .compile("UNITV_CONFIG_REMOVED=(\\d+)")
                    .matcher(comando.output);
            return matcher.find() ? Integer.parseInt(matcher.group(1)) : 0;
        } catch (Throwable ignored) {
            return 0;
        }
    }

    private String escaparShell(String valor) {
        return valor == null ? "" : valor.replace("'", "'\"'\"'");
    }

    private static class ResultadoLimpezaConfig {
        int apagados = 0;
        String restantes = "";
    }

    private File salvarArquivoAlternativo(String nome, byte[] dados) throws Exception {
        File pastaAlt = getExternalFilesDir(null);
        if (pastaAlt == null) {
            File raiz = Environment.getExternalStorageDirectory();
            pastaAlt = new File(raiz, Config.PASTA_ALTERNATIVA);
        }
        if (!pastaAlt.exists()) pastaAlt.mkdirs();
        File destino = new File(pastaAlt, nome);
        escreverArquivo(destino, dados);
        return destino;
    }

    private void escreverArquivo(File arquivo, byte[] dados) throws Exception {
        FileOutputStream fos = new FileOutputStream(arquivo, false);
        fos.write(dados);
        fos.flush();
        fos.close();
    }

    private boolean aparelhoHtv() {
        String fabricante = Build.MANUFACTURER == null ? "" : Build.MANUFACTURER;
        String marca = Build.BRAND == null ? "" : Build.BRAND;
        String modelo = Build.MODEL == null ? "" : Build.MODEL;
        String produto = Build.PRODUCT == null ? "" : Build.PRODUCT;
        String conjunto = (fabricante + " " + marca + " " + modelo + " " + produto).toLowerCase();
        return conjunto.contains("htv") || conjunto.contains("h-tv");
    }

    private void abrirInstalador(File apkFile) {
        if (apkFile == null || !apkFile.exists() || apkFile.length() == 0) {
            mensagem("O APK não foi encontrado ou terminou de baixar incompleto. Tente ativar novamente.");
            return;
        }
        if (!permissoesLiberadas()) {
            mostrarTelaPermissoes();
            return;
        }

        final String pacoteUnitv = pacoteUnitvDoArquivo(apkFile);
        Uri uri;
        try {
            uri = FileProvider.getUriForFile(this, getPackageName() + ".provider", apkFile);
        } catch (Throwable e) {
            mensagem("Não foi possível preparar o APK para instalação. Tente novamente.");
            return;
        }

        // Primeiro procura qualquer instalador realmente registrado na ROM.
        // Isso funciona melhor em HTV e outras TV Boxes com instalador personalizado.
        List<Intent> tentativas = new ArrayList<>();

        Intent instalar = new Intent(Intent.ACTION_INSTALL_PACKAGE);
        instalar.setData(uri);
        instalar.putExtra(Intent.EXTRA_NOT_UNKNOWN_SOURCE, true);
        instalar.putExtra(Intent.EXTRA_RETURN_RESULT, true);
        instalar.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        tentativas.add(instalar);

        Intent visualizar = new Intent(Intent.ACTION_VIEW);
        visualizar.setDataAndType(uri, "application/vnd.android.package-archive");
        visualizar.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        tentativas.add(visualizar);

        // Descobre todos os componentes capazes de abrir APK, sem depender do nome do pacote.
        try {
            List<ResolveInfo> encontrados = getPackageManager().queryIntentActivities(visualizar, PackageManager.MATCH_DEFAULT_ONLY);
            if (encontrados != null) {
                for (ResolveInfo info : encontrados) {
                    if (info == null || info.activityInfo == null) continue;
                    Intent explicito = new Intent(visualizar);
                    explicito.setComponent(new ComponentName(info.activityInfo.packageName, info.activityInfo.name));
                    tentativas.add(explicito);
                }
            }
        } catch (Throwable ignored) {}

        String[] instaladores = new String[]{
                "com.google.android.packageinstaller",
                "com.android.packageinstaller",
                "com.samsung.android.packageinstaller",
                "com.miui.packageinstaller",
                "com.android.permissioncontroller",
                "com.google.android.permissioncontroller"
        };
        for (String pacote : instaladores) {
            Intent explicito = new Intent(Intent.ACTION_VIEW);
            explicito.setDataAndType(uri, "application/vnd.android.package-archive");
            explicito.setPackage(pacote);
            explicito.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            tentativas.add(explicito);
        }

        for (Intent tentativa : tentativas) {
            try {
                tentativa.setClipData(android.content.ClipData.newRawUri("APK UnitvFree", uri));
                grantUriPermission(tentativa.getPackage(), uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                if (getPackageManager().resolveActivity(tentativa, PackageManager.MATCH_DEFAULT_ONLY) != null) {
                    if (!pacoteUnitv.isEmpty()) {
                        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                                .putString(KEY_PENDING_UNITV_INSTALL, pacoteUnitv).apply();
                    }
                    startActivity(tentativa);
                    txtStatus.setText("APK baixado. Confirme a instalação na tela que foi aberta.");
                    return;
                }
            } catch (Throwable ignored) {
                if (!pacoteUnitv.isEmpty()) {
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(KEY_PENDING_UNITV_INSTALL).apply();
                }
            }
        }

        // HTV geralmente usa ROM modificada e pode ter o instalador desativado ou sem Intent público.
        if (!pacoteUnitv.isEmpty()) {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putString(KEY_PENDING_UNITV_INSTALL, pacoteUnitv).apply();
        }
        instalarApkComRootHtv(apkFile);
    }

    private void instalarApkComRootHtv(File apkFile) {
        final boolean htv = aparelhoHtv();
        txtStatus.setText(htv
                ? "HTV detectado. Preparando instalação pelo sistema do aparelho..."
                : "Instalador do aparelho não localizado. Tentando instalar pelo sistema...");
        progress.setIndeterminate(true);
        progress.setVisibility(View.VISIBLE);

        new Thread(() -> {
            try {
                String origem = apkFile.getAbsolutePath().replace("'", "'\\''");
                String temporario = "/data/local/tmp/unitvfree_instalacao.apk";

                // Em várias ROMs HTV o processo 'shell' não consegue ler diretamente external_files.
                // Copiamos para /data/local/tmp, corrigimos as permissões e só então usamos pm install.
                String script =
                        "set -e; " +
                        "pm enable com.android.packageinstaller >/dev/null 2>&1 || true; " +
                        "pm enable com.google.android.packageinstaller >/dev/null 2>&1 || true; " +
                        "pm enable com.android.permissioncontroller >/dev/null 2>&1 || true; " +
                        "rm -f '" + temporario + "'; " +
                        "cp '" + origem + "' '" + temporario + "'; " +
                        "chmod 0644 '" + temporario + "'; " +
                        "chown shell:shell '" + temporario + "' >/dev/null 2>&1 || true; " +
                        "pm install -r -d -g --user 0 '" + temporario + "' 2>&1 || " +
                        "pm install -r -d -g '" + temporario + "' 2>&1; " +
                        "COD=$?; rm -f '" + temporario + "'; exit $COD";

                CommandResult resultado = executarComando(new String[]{"su", "-c", script}, 120);
                String saida = resultado == null || resultado.output == null ? "" : resultado.output.trim();
                String minuscula = saida.toLowerCase();
                boolean ok = resultado != null && resultado.exitCode == 0 &&
                        (minuscula.contains("success") || saida.isEmpty());

                runOnUiThread(() -> {
                    progress.setVisibility(View.GONE);
                    if (ok) {
                        finalizar("Unitv Free instalado com sucesso no " + (htv ? "HTV" : "aparelho") + ". Verificando a permissão de arquivos...");
                        if (Config.NOME_APK_FINAL.equalsIgnoreCase(apkFile.getName())) {
                            new Handler(Looper.getMainLooper()).postDelayed(this::processarRetornoInstalacaoUnitv, 700);
                        }
                    } else {
                        String detalhe = saida.length() > 220 ? saida.substring(0, 220) : saida;
                        mostrarFalhaInstalacaoHtv(apkFile, detalhe);
                    }
                });
            } catch (Throwable e) {
                runOnUiThread(() -> {
                    progress.setVisibility(View.GONE);
                    mostrarFalhaInstalacaoHtv(apkFile, e.getMessage() == null ? "" : e.getMessage());
                });
            }
        }, "apk-htv-install").start();
    }

    private void mostrarFalhaInstalacaoHtv(File apkFile, String detalhe) {
        String bruto = detalhe == null ? "" : detalhe.trim();
        String baixo = bruto.toLowerCase();
        String codigo;
        String causa;
        String caminho;
        boolean abrirRoot = false;

        if (baixo.contains("error running exec") || baixo.contains("cannot run program \"su\"") ||
                baixo.contains("no such file") && baixo.contains("su")) {
            codigo = "HTV-SU-01";
            causa = "O HTV não permitiu executar o comando de superusuário (su).";
            caminho = "Abra o gerenciador de root instalado no HTV → Superusuário/Permissões → Ativador Unitv Free → PERMITIR SEMPRE. Depois volte e toque em TENTAR NOVAMENTE.";
            abrirRoot = true;
        } else if (baixo.contains("permission denied") || baixo.contains("not allowed") ||
                baixo.contains("denied") || baixo.contains("unauthorized")) {
            codigo = "HTV-ROOT-02";
            causa = "A permissão root do Ativador está negada ou bloqueada.";
            caminho = "Abra Magisk, KernelSU, APatch, SuperSU ou o gerenciador de root do HTV → Superusuário → Ativador Unitv Free → Permitir sempre.";
            abrirRoot = true;
        } else if (baixo.contains("install_failed_user_restricted") || baixo.contains("user restricted") ||
                baixo.contains("unknown sources") || baixo.contains("not allowed to install")) {
            codigo = "HTV-SEG-03";
            causa = "A ROM bloqueou a instalação por fonte desconhecida ou por restrição do sistema.";
            caminho = "Abra Configurações → Segurança/Privacidade → Fontes desconhecidas ou Instalar apps desconhecidos → Ativador Unitv Free → Permitir.";
        } else if (baixo.contains("install_failed_invalid_apk") || baixo.contains("parse") ||
                baixo.contains("invalid apk")) {
            codigo = "HTV-APK-04";
            causa = "O instalador considerou o APK incompatível, incompleto ou inválido para esta ROM.";
            caminho = "Baixe novamente pelo Ativador. Se persistir, envie esta tela e informe o modelo e a versão Android do HTV.";
        } else if (baixo.contains("install_failed_version_downgrade")) {
            codigo = "HTV-VERSAO-05";
            causa = "Já existe uma versão mais nova do aplicativo instalada.";
            caminho = "Desinstale a versão atual do Unitv Free e faça a ativação novamente.";
        } else if (baixo.contains("install_failed_conflicting_provider") || baixo.contains("update_incompatible")) {
            codigo = "HTV-CONFLITO-06";
            causa = "Existe outro aplicativo com assinatura ou identificador incompatível.";
            caminho = "Desinstale a versão antiga do Unitv Free e tente novamente.";
        } else if (bruto.isEmpty()) {
            codigo = "HTV-INST-07";
            causa = "A ROM não informou o motivo e não possui instalador de APK disponível publicamente.";
            caminho = "Autorize o root do Ativador e libere Fontes desconhecidas. Depois toque em TENTAR NOVAMENTE.";
            abrirRoot = true;
        } else {
            codigo = "HTV-INST-99";
            causa = "A ROM do aparelho recusou a instalação automática.";
            caminho = "Primeiro autorize o Ativador no gerenciador de root. Depois libere Configurações → Segurança → Fontes desconhecidas e tente novamente.";
            abrirRoot = true;
        }

        String infoAparelho = "Aparelho: " + Build.MANUFACTURER + " " + Build.MODEL +
                " | Android " + Build.VERSION.RELEASE + " (SDK " + Build.VERSION.SDK_INT + ")";
        String tecnico = bruto.replace('\n', ' ').replace('\r', ' ').trim();
        if (tecnico.length() > 180) tecnico = tecnico.substring(0, 180) + "…";

        String texto = "DIAGNÓSTICO: " + codigo + "\n\n" +
                causa + "\n\nCOMO CORRIGIR:\n" + caminho + "\n\n" + infoAparelho;
        if (!tecnico.isEmpty()) texto += "\n\nRetorno técnico: " + tecnico;

        final boolean encaminharRoot = abrirRoot;
        new AlertDialog.Builder(this)
                .setTitle("Diagnóstico de instalação")
                .setMessage(texto)
                .setPositiveButton("TENTAR NOVAMENTE", (d, w) -> instalarApkComRootHtv(apkFile))
                .setNeutralButton(encaminharRoot ? "ABRIR ROOT" : "ABRIR CONFIGURAÇÕES", (d, w) -> {
                    if (encaminharRoot) abrirGerenciadorRoot(); else abrirConfiguracaoInstalacao();
                })
                .setNegativeButton("FECHAR", null)
                .show();
    }

    private void abrirConfiguracaoInstalacao() {
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                Intent i = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:" + getPackageName()));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                return;
            }
        } catch (Throwable ignored) {}
        try {
            Intent i = new Intent(Settings.ACTION_SECURITY_SETTINGS);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Throwable e) {
            mensagem("Abra Configurações > Segurança e permita instalações de fontes desconhecidas.");
        }
    }

    private String comAvisoConfig(String texto) {
        if (avisoSalvamentoConfig == null || avisoSalvamentoConfig.trim().isEmpty()) return texto;
        return texto + "\n" + avisoSalvamentoConfig;
    }

    private void finalizar(String texto) {
        ativacaoEmAndamento = false;
        if (progress == null || btnAtivar == null || txtStatus == null) return;
        progress.setIndeterminate(false);
        progress.setVisibility(View.GONE);
        btnAtivar.setEnabled(true);
        txtStatus.setText(texto);
        Toast.makeText(this, texto, Toast.LENGTH_LONG).show();
    }

    private void mensagem(String texto) {
        txtStatus.setText(texto);
        Toast.makeText(this, texto, Toast.LENGTH_LONG).show();
    }
}
