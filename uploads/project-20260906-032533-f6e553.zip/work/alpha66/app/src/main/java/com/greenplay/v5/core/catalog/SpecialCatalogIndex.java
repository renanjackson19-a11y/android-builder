package com.greenplay.v5.core.catalog;

import com.greenplay.v5.core.ui.SpecialSections;
import com.greenplay.v5.data.model.movie.Movie;
import com.greenplay.v5.data.model.movie.MovieCategory;
import com.greenplay.v5.data.model.series.SeriesCategory;
import com.greenplay.v5.data.model.series.SeriesItem;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * V5.0.90 — Central special-catalog index.
 *
 * Velox-style behavior: KIDS / ANIME / HOT are resolved once into explicit media
 * indexes. The UI no longer re-guesses the catalog on every screen switch.
 *
 * Xtream does not expose a universal media_type=KIDS/ANIME field, so this class
 * converts the data available at login into a stable local type index. Explicit
 * server categories always win. Mixed generic series categories are admitted
 * only when the series metadata itself is strong enough to classify the item.
 */
public final class SpecialCatalogIndex {
    public static final class CategoryRow {
        public final String id;
        public final String name;
        public CategoryRow(String id, String name) {
            this.id = id == null ? "" : id;
            this.name = name == null ? "" : name;
        }
    }

    public static final class Scope {
        public final String mode;
        public final Set<Long> movieIds;
        public final Set<Long> seriesIds;
        public final List<CategoryRow> movieCategories;
        public final List<CategoryRow> seriesCategories;
        public final List<Movie> moviePreview;
        public final List<SeriesItem> seriesPreview;

        private Scope(String mode, Set<Long> movieIds, Set<Long> seriesIds,
                      List<CategoryRow> movieCategories, List<CategoryRow> seriesCategories,
                      List<Movie> moviePreview, List<SeriesItem> seriesPreview) {
            this.mode = mode;
            this.movieIds = Collections.unmodifiableSet(new HashSet<>(movieIds));
            this.seriesIds = Collections.unmodifiableSet(new HashSet<>(seriesIds));
            this.movieCategories = Collections.unmodifiableList(new ArrayList<>(movieCategories));
            this.seriesCategories = Collections.unmodifiableList(new ArrayList<>(seriesCategories));
            this.moviePreview = Collections.unmodifiableList(new ArrayList<>(moviePreview));
            this.seriesPreview = Collections.unmodifiableList(new ArrayList<>(seriesPreview));
        }
    }

    /**
     * V5.0.114 — o mapa inteiro é trocado de forma atômica depois que o índice
     * termina de ser montado. A UI nunca espera o monitor de um rebuild pesado.
     *
     * Antes, rebuild()/cachedScope() eram synchronized no MESMO monitor. Se o
     * catálogo tinha milhares de itens e o rebuild estava rodando em background,
     * tocar em KIDS/ANIMES podia bloquear a main thread por vários segundos e o
     * Android mostrava "GREEN PLAY não está respondendo".
     */
    private static volatile long builtFrom = Long.MIN_VALUE;
    private static volatile Map<String, Scope> SCOPES = Collections.emptyMap();

    private SpecialCatalogIndex() {}

    public static void clear() {
        SCOPES = Collections.emptyMap();
        builtFrom = Long.MIN_VALUE;
    }

    public static void rebuild() {
        // Copia os snapshots primeiro. Todo o processamento pesado acontece sem
        // segurar nenhum lock do SpecialCatalogIndex.
        final long source = CatalogMemory.updatedAt();
        final List<MovieCategory> movieCategories = CatalogMemory.movieCategories();
        final List<Movie> movies = CatalogMemory.movies();
        final List<SeriesCategory> seriesCategories = CatalogMemory.seriesCategories();
        final List<SeriesItem> series = CatalogMemory.series();

        final Map<String, Scope> fresh = new HashMap<>();
        fresh.put(SpecialSections.KIDS,
                buildScope(SpecialSections.KIDS, movieCategories, movies, seriesCategories, series));
        fresh.put(SpecialSections.ANIME,
                buildScope(SpecialSections.ANIME, movieCategories, movies, seriesCategories, series));
        fresh.put(SpecialSections.HOT,
                buildScope(SpecialSections.HOT, movieCategories, movies, seriesCategories, series));

        // Publicação atômica: cachedScope() continua instantâneo mesmo enquanto
        // outro rebuild está sendo calculado. Um refresh transitório nunca apaga um
        // escopo válido e troca por TODOS/vazio.
        Map<String, Scope> current = SCOPES;
        Map<String, Scope> published = new HashMap<>();
        for (String mode : new String[]{SpecialSections.KIDS, SpecialSections.ANIME, SpecialSections.HOT}) {
            Scope candidate = fresh.get(mode);
            Scope previous = current.get(mode);
            // O catálogo geral é carregado com includeAdult=false. Portanto um HOT
            // separado já publicado pelo cache adulto não pode ser encolhido por um
            // rebuild do catálogo normal.
            if (SpecialSections.HOT.equals(mode) && hasContent(previous)) published.put(mode, previous);
            else published.put(mode, preferValid(candidate, previous));
        }
        SCOPES = Collections.unmodifiableMap(published);
        builtFrom = source;
    }

    /**
     * Publica somente um escopo já calculado em background. Usado pela correção
     * leve de categorias sem reconstruir KIDS+ANIMES+HOT completos.
     */
    public static void publishScope(String mode, Scope scope) {
        if (mode == null || scope == null) return;
        Map<String, Scope> current = SCOPES;
        Map<String, Scope> next = new HashMap<>(current);
        next.put(mode, preferValid(scope, current.get(mode)));
        SCOPES = Collections.unmodifiableMap(next);
    }

    /**
     * Acesso lock-free ao último índice pronto. Nunca monta nem espera catálogo.
     */
    public static Scope cachedScope(String mode) {
        Scope s = SCOPES.get(mode);
        if (s != null) return s;
        return emptyScope(mode);
    }

    /**
     * Mantido por compatibilidade. Chamadores de UI recebem somente o último
     * snapshot pronto; rebuilds devem ser disparados por executores de background.
     */
    public static Scope scope(String mode) {
        return cachedScope(mode);
    }

    public static boolean hasContent(Scope scope) {
        return scope != null && (!scope.movieIds.isEmpty() || !scope.seriesIds.isEmpty());
    }

    private static Scope preferValid(Scope candidate, Scope previous) {
        if (hasContent(candidate)) return candidate;
        if (hasContent(previous)) return previous;
        return candidate == null ? emptyScope(previous == null ? "" : previous.mode) : candidate;
    }

    private static Scope emptyScope(String mode) {
        return new Scope(mode, Collections.emptySet(), Collections.emptySet(),
                Collections.singletonList(new CategoryRow("", "TODOS")),
                Collections.singletonList(new CategoryRow("", "TODOS")),
                Collections.emptyList(), Collections.emptyList());
    }

    /** Public builder is also used by HOT after its adult-inclusive catalog is fetched. */
    public static Scope buildScope(String mode,
                                   List<MovieCategory> movieCategories,
                                   List<Movie> movies,
                                   List<SeriesCategory> seriesCategories,
                                   List<SeriesItem> series) {
        LinkedHashMap<String,String> movieNames = new LinkedHashMap<>();
        LinkedHashMap<String,String> seriesNames = new LinkedHashMap<>();
        Set<String> explicitMovieCats = new HashSet<>();
        Set<String> explicitSeriesCats = new HashSet<>();
        // V5.0.132 — KIDS/SÉRIES usa a QUALIDADE do nome da categoria.
        // Categoria claramente infantil continua automática; buckets mistos como
        // Família/Disney precisam de sinal infantil no próprio item.
        Set<String> directKidsSeriesCats = new HashSet<>();
        Set<String> safeKidsSeriesCats = new HashSet<>();
        Set<String> mixedKidsSeriesCats = new HashSet<>();

        if (movieCategories != null) {
            for (MovieCategory c : movieCategories) {
                if (c == null || blank(c.id)) continue;
                movieNames.put(c.id, safe(c.name));
                if (SpecialSections.matches(mode, c.name) || (SpecialSections.HOT.equals(mode) && c.isAdult)) explicitMovieCats.add(c.id);
            }
        }
        if (seriesCategories != null) {
            for (SeriesCategory c : seriesCategories) {
                if (c == null || blank(c.id)) continue;
                seriesNames.put(c.id, safe(c.name));
                if (SpecialSections.matches(mode, c.name) || (SpecialSections.HOT.equals(mode) && c.isAdult)) {
                    explicitSeriesCats.add(c.id);
                    if (SpecialSections.KIDS.equals(mode)) {
                        if (directKidsSeriesCategoryName(c.name)) directKidsSeriesCats.add(c.id);
                        else if (safeKidsSeriesCategoryName(c.name)) safeKidsSeriesCats.add(c.id);
                        else mixedKidsSeriesCats.add(c.id);
                    }
                }
            }
        }

        Set<Long> movieIds = new HashSet<>();
        Set<Long> seriesIds = new HashSet<>();
        Set<String> visibleMovieCats = new HashSet<>();
        Set<String> visibleSeriesCats = new HashSet<>();
        ArrayList<Movie> moviePreview = new ArrayList<>();
        ArrayList<SeriesItem> seriesPreview = new ArrayList<>();

        if (movies != null) {
            for (Movie m : movies) {
                if (m == null || m.id <= 0) continue;
                String tag = specialTag(m.mediaType, m.vodType, m.filterType);
                boolean match;
                if (!tag.isEmpty()) {
                    // When the backend explicitly tags an asset, that tag is authoritative.
                    match = mode.equals(tag);
                } else {
                    match = matchesAnyCategory(combinedCategoryIds(m.categoryId, m.allCategoryIds), explicitMovieCats);
                    // HOT is category/flag driven. Never classify by movie title text.
                    if (SpecialSections.HOT.equals(mode) && (m.isAdult || strongAdultMetadata(m.mediaType, m.vodType, m.filterType))) match = true;
                }
                if (!match) continue;
                movieIds.add(m.id);
                if (moviePreview.size() < 12) moviePreview.add(m);
                addVisibleCategoryIds(visibleMovieCats, combinedCategoryIds(m.categoryId, m.allCategoryIds), explicitMovieCats);
            }
        }

        if (series != null) {
            for (SeriesItem item : series) {
                if (item == null || item.id <= 0) continue;
                String cat = combinedCategoryIds(item.categoryId, item.allCategoryIds);
                String tag = specialTag(item.mediaType, item.vodType, item.filterType);
                boolean match;
                if (!tag.isEmpty()) {
                    match = mode.equals(tag);
                } else {
                    boolean explicit = matchesAnyCategory(cat, explicitSeriesCats);
                    if (SpecialSections.KIDS.equals(mode)) {
                        // V5.0.132 — não muda cache/layout nem o catálogo de FILMES.
                        // A série é decidida pela categoria de ORIGEM:
                        // 1) KIDS/INFANTIL/DESENHOS/canais infantis: entra;
                        // 2) ANIMAÇÃO/JUVENIL/Pixar/DreamWorks: entra se não for madura;
                        // 3) FAMÍLIA/Disney genérico: só entra com sinal infantil/familiar
                        //    no item. Isso corta 9-1-1 e sitcoms gerais sem zerar KIDS.
                        boolean direct = matchesAnyCategory(cat, directKidsSeriesCats);
                        boolean safeBroad = matchesAnyCategory(cat, safeKidsSeriesCats);
                        boolean mixedBroad = matchesAnyCategory(cat, mixedKidsSeriesCats);
                        if (direct) match = !hardRejectKidsSeries(item);
                        else if (safeBroad) match = !hardRejectKidsSeries(item);
                        else if (mixedBroad) match = positiveKidsSeries(item) && !hardRejectKidsSeries(item);
                        else match = strictKids(item);
                    } else if (SpecialSections.ANIME.equals(mode)) {
                        match = explicit || strictAnime(item);
                    } else {
                        // HOT is category/flag driven. Never classify by series title/plot/genre words.
                        match = explicit || item.isAdult || strongAdultMetadata(item.mediaType, item.vodType, item.filterType);
                    }
                }
                if (!match) continue;
                seriesIds.add(item.id);
                if (seriesPreview.size() < 12) seriesPreview.add(item);
                addVisibleCategoryIds(visibleSeriesCats, cat, explicitSeriesCats);
            }
        }

        // An explicit category may legitimately be empty at the moment; keep it visible.
        visibleMovieCats.addAll(explicitMovieCats);
        visibleSeriesCats.addAll(explicitSeriesCats);

        List<CategoryRow> movieRows = rows(movieNames, visibleMovieCats);
        List<CategoryRow> seriesRows = rows(seriesNames, visibleSeriesCats);
        return new Scope(mode, movieIds, seriesIds, movieRows, seriesRows, moviePreview, seriesPreview);
    }

    private static String specialTag(String mediaType, String vodType, String filterType) {
        String n = " " + normalize(safe(mediaType) + " " + safe(vodType) + " " + safe(filterType)) + " ";
        if (SpecialSections.isKidsCategoryName(n)) return SpecialSections.KIDS;
        if (SpecialSections.isAnimeCategoryName(n)) return SpecialSections.ANIME;
        if (hasAny(n, " adult_vod ", " adult ", " adulto ", " adultos ", " hot ", " xxx ", " 18+ ", " +18 ")) return SpecialSections.HOT;
        return "";
    }


    /**
     * Fallback somente para METADADOS estruturais do backend (media_type/vod_type/filter_type).
     * Não olha título, sinopse ou gênero, para um filme comum com palavra sexual no nome
     * nunca entrar no HOT por engano.
     */
    private static boolean strongAdultMetadata(String... values) {
        StringBuilder raw = new StringBuilder();
        if (values != null) for (String v : values) raw.append(' ').append(safe(v));
        String original = raw.toString().toLowerCase(Locale.ROOT);
        if (original.contains("🔞") || original.contains("+18") || original.contains("18+")) return true;
        String n = " " + normalize(original) + " ";
        return hasAny(n,
                " adult_vod ", " adult_content ", " adult ", " adults ",
                " adulto ", " adultos ", " xxx ", " hot ");
    }

    private static boolean matchesAnyCategory(String raw, Set<String> allowed) {
        if (allowed == null || allowed.isEmpty() || blank(raw)) return false;
        for (String id : categoryIds(raw)) if (allowed.contains(id)) return true;
        return false;
    }

    private static String combinedCategoryIds(String primary, String all) {
        String a = safe(primary);
        String b = safe(all);
        if (a.isEmpty()) return b;
        if (b.isEmpty()) return a;
        return a + "|" + b;
    }

    private static void addVisibleCategoryIds(Set<String> out, String raw, Set<String> allowed) {
        if (out == null || allowed == null || allowed.isEmpty()) return;
        for (String id : categoryIds(raw)) if (allowed.contains(id)) out.add(id);
    }

    /** Alguns painéis retornam mais de um category_id no mesmo campo. */
    private static List<String> categoryIds(String raw) {
        ArrayList<String> out = new ArrayList<>();
        if (raw == null) return out;
        String cleaned = raw.trim();
        if (cleaned.isEmpty()) return out;
        String[] parts = cleaned.split("[|,;]+");
        for (String part : parts) {
            String id = part == null ? "" : part.trim();
            if (!id.isEmpty() && !out.contains(id)) out.add(id);
        }
        if (out.isEmpty()) out.add(cleaned);
        return out;
    }

    private static List<CategoryRow> rows(LinkedHashMap<String,String> names, Set<String> allowed) {
        ArrayList<CategoryRow> out = new ArrayList<>();
        out.add(new CategoryRow("", "TODOS"));
        for (Map.Entry<String,String> e : names.entrySet()) {
            if (!allowed.contains(e.getKey())) continue;
            out.add(new CategoryRow(e.getKey(), cleanDisplay(e.getValue())));
        }
        return out;
    }

    /**
     * Strict KIDS rule for mixed provider categories.
     * Family alone is intentionally NOT enough: that was the source of normal series leaking into KIDS.
     */
    private static boolean strictKids(SeriesItem item) {
        if (item.isAdult) return false;
        String genre = " " + normalize(item.genre) + " ";
        String title = " " + normalize(item.name) + " ";
        if (genre.trim().isEmpty()) return false;

        boolean directKids = hasAny(genre,
                " kids ", " kid ", " children ", " childrens ", " child ",
                " infantil ", " infantis ", " infanto juvenil ", " infantojuvenil ",
                " preschool ", " pre school ", " educativo ", " educational ");
        boolean animation = hasAny(genre,
                " animation ", " animations ", " animacao ", " animacoes ", " animated ", " animado ", " animados ", " cartoon ", " cartoons ");
        boolean family = hasAny(genre, " family ", " familia ", " familiar ");

        // V5.0.129: muitos Xtreams publicam KIDS somente como ANIMAÇÃO ou FAMÍLIA.
        // Esses metadados são aceitos desde que não sejam anime/adulto/maduro.
        if (!directKids && !animation && !family) return false;

        // Anime belongs in ANIMES, not KIDS, unless the server explicitly classified the category as KIDS.
        if (hasAny(genre, " anime ", " manga ", " shonen ", " shoujo ", " seinen ", " isekai ")) return false;

        String mature = genre + title;
        return !hasAny(mature,
                " adult ", " adulto ", " adultos ", " erotic ", " erotico ", " porn ",
                " horror ", " terror ", " thriller ", " crime ", " slasher ", " gore ",
                " family guy ", " south park ", " rick and morty ", " american dad ",
                " bojack horseman ", " big mouth ", " paradise pd ", " brickleberry ",
                " archer ", " solar opposites ");
    }


    /** Categoria de série inequivocamente infantil. */
    private static boolean directKidsSeriesCategoryName(String raw) {
        String n = kidsCategoryNorm(raw);
        if (n.trim().isEmpty() || adultOrAnimeCategory(n)) return false;
        return hasAny(n,
                " kids ", " kid ", " infantil ", " infantis ", " crianca ", " criancas ",
                " infanto juvenil ", " infantojuvenil ", " desenho ", " desenhos ",
                " cartoon ", " cartoons ", " baby ", " bebe ", " children ", " childrens ",
                " child ", " preschool ", " pre school ", " educativo ", " educativos ",
                " educacao ", " educational ", " discovery kids ", " cartoon network ",
                " disney junior ", " disney channel ", " nickelodeon ", " nick jr ",
                " nick junior ", " gloob ", " gloobinho ", " boomerang ", " tooncast ",
                " cartoonito ", " pbs kids ", " family kids ", " animacao infantil ",
                " animation kids ");
    }

    /**
     * Categoria ainda apropriada para KIDS, mas que pode conter exceções maduras.
     * Por isso passa pelo hardRejectKidsSeries().
     */
    private static boolean safeKidsSeriesCategoryName(String raw) {
        String n = kidsCategoryNorm(raw);
        if (n.trim().isEmpty() || adultOrAnimeCategory(n) || directKidsSeriesCategoryName(raw)) return false;
        return hasAny(n,
                " juvenil ", " animacao ", " animacoes ", " animation ", " animations ",
                " animated ", " animado ", " animados ", " pixar ", " dreamworks ",
                " illumination ");
    }

    /** Buckets mistos (Família/Disney genérico) exigem sinal positivo no item. */
    private static boolean positiveKidsSeries(SeriesItem item) {
        if (item == null || item.isAdult) return false;
        String genre = " " + normalize(item.genre) + " ";
        String title = " " + normalize(item.name) + " ";
        String plot = " " + normalize(item.plot) + " ";
        String structural = " " + normalize(safe(item.mediaType) + " " + safe(item.vodType) + " " + safe(item.filterType)) + " ";
        String all = genre + " " + title + " " + plot + " " + structural;

        if (hasAny(all,
                " kids ", " kid ", " children ", " child ", " infantil ", " infantis ",
                " crianca ", " criancas ", " infanto juvenil ", " infantojuvenil ",
                " preschool ", " pre school ", " educativo ", " educational ",
                " desenho ", " desenhos ", " cartoon ", " cartoons ", " animacao ",
                " animation ", " animated ")) return true;

        // Live-action juvenil/familiar: sinais genéricos, sem lista de títulos.
        boolean youth = hasAny(all,
                " escola ", " escolar ", " colegio ", " estudante ", " estudantes ",
                " aluno ", " alunos ", " aluna ", " alunas ", " academia esportiva ",
                " academico esportivo ", " garoto ", " garotos ", " garota ", " garotas ",
                " menino ", " meninos ", " menina ", " meninas ", " jovem ", " jovens ",
                " teen ", " teenager ", " aventura juvenil ", " musical juvenil ");
        boolean family = hasAny(genre, " family ", " familia ", " familiar ");
        boolean lightGenre = hasAny(genre,
                " adventure ", " aventura ", " comedy ", " comedia ", " musical ",
                " music ", " musica ", " fantasy ", " fantasia ", " family ", " familia ");
        return youth || (family && lightGenre);
    }

    /**
     * Rejeição forte, usada só em SÉRIES KIDS. A regra é semântica/genérica;
     * não depende de nomes de programas específicos.
     */
    private static boolean hardRejectKidsSeries(SeriesItem item) {
        if (item == null || item.isAdult) return true;
        String genre = " " + normalize(item.genre) + " ";
        String title = " " + normalize(item.name) + " ";
        String plot = " " + normalize(item.plot) + " ";
        String all = genre + " " + title + " " + plot;

        // Anime fica na seção ANIMES quando não veio de uma categoria infantil direta.
        if (hasAny(genre, " anime ", " manga ", " shonen ", " shoujo ", " shojo ", " seinen ", " isekai ")) return true;

        return hasAny(all,
                " adult ", " adults ", " adulto ", " adultos ", " erotic ", " erotico ",
                " erotica ", " porn ", " porno ", " sexual ", " sexo ", " sexy ",
                " horror ", " terror ", " thriller ", " crime ", " criminal ",
                " police ", " policial ", " policia ", " detective ", " detetive ",
                " murder ", " assassin ", " assassino ", " homicidio ", " homicide ",
                " hospital ", " medical ", " medico ", " medica ", " firefighter ",
                " bombeiro ", " bombeiros ", " paramedic ", " paramedico ", " emergencia ",
                " emergency ", " war ", " guerra ", " narcotic ", " droga ", " drogas ",
                " cartel ", " true crime ", " reality show ", " news ", " noticias ",
                " namoro ", " namorar ", " dating ", " date ", " relationship ",
                " relacionamento ", " casamento ", " divorce ", " divorcio ",
                " boyfriend ", " girlfriend ", " marido ", " esposa ");
    }

    private static String kidsCategoryNorm(String raw) {
        return " " + normalize(raw).replace("+", " plus ").replaceAll("\\s+", " ").trim() + " ";
    }

    private static boolean adultOrAnimeCategory(String n) {
        return hasAny(n,
                " anime ", " animes ", " manga ", " shonen ", " shoujo ", " shojo ",
                " seinen ", " isekai ", " hentai ", " ecchi ", " adult ", " adults ",
                " adulto ", " adultos ", " hot ", " xxx ", " porn ", " porno ",
                " erotico ", " erotica ", " sexy ", " sex ", " 18 plus ", " plus 18 ");
    }

    private static boolean strictAnime(SeriesItem item) {
        if (item.isAdult) return false;
        String genre = " " + normalize(item.genre) + " ";
        return hasAny(genre,
                " anime ", " manga ", " shonen ", " shoujo ", " shojo ", " seinen ",
                " isekai ", " japanese animation ", " animacao japonesa ");
    }

    private static String cleanDisplay(String raw) {
        String s = safe(raw).replace("\\/", "/").replace("\n", " ").replace("\r", " ").trim();
        s = s.replaceAll("(?i)^(filmes|series|séries)\\s*[-|:]\\s*", "").trim();
        return s.isEmpty() ? "Categoria" : s;
    }

    private static boolean hasAny(String source, String... terms) {
        for (String t : terms) if (source.contains(t)) return true;
        return false;
    }

    private static String normalize(String raw) {
        if (raw == null) return "";
        String s = Normalizer.normalize(raw, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        return s.toLowerCase(Locale.ROOT)
                .replace('|', ' ').replace('/', ' ').replace(',', ' ').replace(';', ' ')
                .replaceAll("\\s+", " ").trim();
    }

    private static String safe(String s) { return s == null ? "" : s.trim(); }
    private static boolean blank(String s) { return s == null || s.trim().isEmpty(); }
}
