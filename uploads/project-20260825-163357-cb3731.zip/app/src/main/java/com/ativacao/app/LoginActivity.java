package com.ativacao.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class LoginActivity extends Activity {
    private EditText user,pass; private TextView message,serverBadge,enter,trial,brandMark,loadTitle,loadStep; private ImageView bgImage,brandLogo; private FrameLayout loadingOverlay; private boolean phone; private int trialHours=3;
    @Override public void onCreate(Bundle b){super.onCreate(b);ApiClient.setUserToken(Session.token(this));getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);Ui.immersive(this);if(Session.isLogged(this)){openHome();return;}phone=Ui.phone(this);setContentView(build());checkServer();}
    @Override protected void onResume(){super.onResume();Ui.immersive(this);}

    private View build(){
        FrameLayout root=new FrameLayout(this); root.setBackgroundColor(Color.BLACK);
        bgImage=new ImageView(this); bgImage.setScaleType(ImageView.ScaleType.CENTER_CROP); bgImage.setBackgroundColor(Color.rgb(2,10,6)); root.addView(bgImage,new FrameLayout.LayoutParams(-1,-1));
        View shade=new View(this); shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0xE9000C06,0xB7000805,0xD9000000})); root.addView(shade,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout shell=new LinearLayout(this); shell.setOrientation(LinearLayout.HORIZONTAL); shell.setGravity(Gravity.CENTER_VERTICAL); shell.setPadding(Ui.dp(this,phone?28:52),Ui.dp(this,22),Ui.dp(this,phone?28:52),Ui.dp(this,22)); root.addView(shell,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout brand=Ui.column(this); brand.setGravity(Gravity.CENTER); brand.setPadding(Ui.dp(this,12),0,Ui.dp(this,32),0);
        brandLogo=new ImageView(this); brandLogo.setScaleType(ImageView.ScaleType.CENTER_INSIDE); String savedLogo=BrandConfig.logo(this); if(savedLogo!=null&&!savedLogo.trim().isEmpty()) ImageLoader.into(this,brandLogo,savedLogo); else { brandLogo.setImageDrawable(null); brandLogo.setBackgroundColor(Color.TRANSPARENT); } brand.addView(brandLogo,new LinearLayout.LayoutParams(-1,Ui.dp(this,76))); brandMark=Ui.text(this,"DUBAI PLAY",phone?22:30,Color.WHITE,true); brandMark.setGravity(Gravity.CENTER); LinearLayout.LayoutParams mlp=new LinearLayout.LayoutParams(-1,Ui.dp(this,40)); if(savedLogo!=null&&!savedLogo.trim().isEmpty()) brandMark.setVisibility(View.GONE); brand.addView(brandMark,mlp);
        TextView tag=Ui.text(this,"TV, FILMES E SÉRIES SEM COMPLICAÇÃO.",phone?12:15,0xFF35E86B,true); tag.setGravity(Gravity.CENTER); brand.addView(tag,new LinearLayout.LayoutParams(-1,Ui.dp(this,30)));
        TextView dev=Ui.text(this,"ID Dispositivo: "+DeviceInfo.macOrId(this)+"\nVersão: 4.0.70.1",9,0xFFB3BAB5,false); dev.setLineSpacing(0,1.35f); LinearLayout.LayoutParams dv=new LinearLayout.LayoutParams(-1,Ui.dp(this,58));dv.topMargin=Ui.dp(this,48);brand.addView(dev,dv);
        shell.addView(brand,new LinearLayout.LayoutParams(0,-1,0.95f));

        LinearLayout right=Ui.column(this); right.setGravity(Gravity.CENTER_VERTICAL); right.setPadding(Ui.dp(this,24),Ui.dp(this,10),0,Ui.dp(this,10));
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL); TextView head=Ui.text(this,"Entre na sua conta",phone?23:30,Color.WHITE,true);top.addView(head,new LinearLayout.LayoutParams(0,Ui.dp(this,38),1)); serverBadge=Ui.text(this,"● VERIFICANDO",9,Ui.GOLD,true);serverBadge.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);top.addView(serverBadge,new LinearLayout.LayoutParams(Ui.dp(this,150),Ui.dp(this,34)));right.addView(top,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));
        TextView desc=Ui.text(this,"Digite seu usuário e senha para acessar o aplicativo.",10,0xFFB4B8B6,false);right.addView(desc,new LinearLayout.LayoutParams(-1,Ui.dp(this,26)));
        right.addView(label("Usuário"),new LinearLayout.LayoutParams(-1,Ui.dp(this,18)));user=field("Por favor insira seu usuário",false);right.addView(user,new LinearLayout.LayoutParams(-1,Ui.dp(this,44)));
        TextView sl=label("Senha");LinearLayout.LayoutParams slp=new LinearLayout.LayoutParams(-1,Ui.dp(this,18));slp.topMargin=Ui.dp(this,6);right.addView(sl,slp);pass=field("Por favor insira sua senha",true);right.addView(pass,new LinearLayout.LayoutParams(-1,Ui.dp(this,44)));

        enter=Ui.primaryButton(this,"ENTRAR");LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,Ui.dp(this,44));ep.topMargin=Ui.dp(this,11);right.addView(enter,ep);
        TextView test=Ui.button(this,"◉   TESTAR CONEXÃO");LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,Ui.dp(this,40));tp.topMargin=Ui.dp(this,7);right.addView(test,tp);
        trial=Ui.button(this,"TESTE AUTOMÁTICO • 3 HORAS");LinearLayout.LayoutParams trp=new LinearLayout.LayoutParams(-1,Ui.dp(this,36));trp.topMargin=Ui.dp(this,7);right.addView(trial,trp);
        message=Ui.text(this,"",10,Ui.MUTED,false);message.setGravity(Gravity.CENTER);right.addView(message,new LinearLayout.LayoutParams(-1,Ui.dp(this,22)));
        TextView help=Ui.text(this,"Problemas para acessar? Teste sua conexão.",9,0xFF9EA4A0,false);help.setGravity(Gravity.CENTER);right.addView(help,new LinearLayout.LayoutParams(-1,Ui.dp(this,20)));

        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(0,-1,1.05f);rp.leftMargin=Ui.dp(this,24);shell.addView(right,rp);
        enter.setOnClickListener(v->doLogin()); trial.setOnClickListener(v->doTrial()); test.setOnClickListener(v->showDiagnostic()); pass.setOnEditorActionListener((v,a,e)->{doLogin();return true;}); user.requestFocus();
        loadingOverlay=buildLoadingOverlay(); root.addView(loadingOverlay,new FrameLayout.LayoutParams(-1,-1)); loadingOverlay.setVisibility(View.GONE); return root;
    }
    private TextView label(String s){return Ui.text(this,s,10,Color.WHITE,true);}
    private EditText field(String hint,boolean password){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(0xFF727B86);e.setTextColor(Color.WHITE);e.setTextSize(phone?12:14);e.setSingleLine(true);e.setPadding(Ui.dp(this,18),0,Ui.dp(this,18),0);e.setBackground(Ui.stroke(0xD9141921,0xFF31404B,20,this));if(password)e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);e.setOnFocusChangeListener((v,f)->e.setBackground(Ui.stroke(0xD9141921,f?Ui.GREEN:0xFF31404B,20,this)));return e;}
    private void doLogin(){String u=user.getText().toString().trim(),p=pass.getText().toString();if(u.isEmpty()||p.isEmpty()){message.setText("Informe usuário e senha.");message.setTextColor(Ui.RED);return;}enter.setEnabled(false);enter.setText("ENTRANDO...");message.setText("Validando acesso...");message.setTextColor(Ui.MUTED);ApiClient.login(u,p,DeviceInfo.macOrId(this),new ApiClient.Callback<ApiClient.LoginResult>(){public void ok(ApiClient.LoginResult r){runOnUiThread(()->{Session.save(LoginActivity.this,r.username,r.expiresAt,r.plan,r.adultAccess,r.bouquet,r.userToken);ApiClient.setUserToken(r.userToken);startInitialPreparation();});}public void error(String m){runOnUiThread(()->{enter.setEnabled(true);enter.setText("ENTRAR");message.setText(m);message.setTextColor(Ui.RED);});}});}
    private void checkServer(){ApiClient.statusInfo(new ApiClient.Callback<ApiClient.AppStatus>(){public void ok(ApiClient.AppStatus st){runOnUiThread(()->{serverBadge.setText("● SERVIDOR ONLINE");serverBadge.setTextColor(Ui.GREEN);trialHours=Math.max(1,st.trialHours);trial.setVisibility(View.VISIBLE);trial.setEnabled(st.trialEnabled);trial.setText((st.trialEnabled?"TESTE AUTOMÁTICO • ":"TESTE INDISPONÍVEL • ")+trialHours+(trialHours==1?" HORA":" HORAS"));if(st.loginBackground!=null&&!st.loginBackground.trim().isEmpty())ImageLoader.into(LoginActivity.this,bgImage,st.loginBackground); if(st.appLogo!=null&&!st.appLogo.trim().isEmpty()){BrandConfig.save(LoginActivity.this,st.appLogo); if(brandLogo!=null)ImageLoader.into(LoginActivity.this,brandLogo,st.appLogo); if(brandMark!=null)brandMark.setVisibility(View.GONE);}});}public void error(String m){runOnUiThread(()->{serverBadge.setText("● SERVIDOR OFFLINE");serverBadge.setTextColor(Ui.RED);trial.setEnabled(false);trial.setText("TESTE AUTOMÁTICO • SERVIDOR OFFLINE");});}});}
    private void doTrial(){if(trial==null)return;trial.setEnabled(false);trial.setText("CRIANDO TESTE...");message.setText("Gerando acesso de teste...");message.setTextColor(Ui.MUTED);ApiClient.trial(DeviceInfo.macOrId(this),new ApiClient.Callback<ApiClient.LoginResult>(){public void ok(ApiClient.LoginResult r){runOnUiThread(()->{Session.save(LoginActivity.this,r.username,r.expiresAt,r.plan,r.adultAccess,r.bouquet,r.userToken);ApiClient.setUserToken(r.userToken);startInitialPreparation();});}public void error(String m){runOnUiThread(()->{trial.setEnabled(true);trial.setText("TESTE AUTOMÁTICO • "+trialHours+(trialHours==1?" HORA":" HORAS"));message.setText(m);message.setTextColor(Ui.RED);});}});}
    private FrameLayout buildLoadingOverlay(){
        FrameLayout ov=new FrameLayout(this); ov.setBackgroundColor(0xF7000905); ov.setClickable(true); ov.setFocusable(true);
        LinearLayout box=Ui.column(this); box.setGravity(Gravity.CENTER); box.setPadding(Ui.dp(this,24),Ui.dp(this,24),Ui.dp(this,24),Ui.dp(this,24));
        ImageView logo=new ImageView(this); logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE); String l=BrandConfig.logo(this); if(l!=null&&!l.trim().isEmpty())ImageLoader.into(this,logo,l); else logo.setImageResource(R.mipmap.ic_launcher);
        box.addView(logo,new LinearLayout.LayoutParams(Ui.dp(this,180),Ui.dp(this,82)));
        loadTitle=Ui.text(this,"Preparando seu conteúdo",phone?20:27,Color.WHITE,true); loadTitle.setGravity(Gravity.CENTER); LinearLayout.LayoutParams t=new LinearLayout.LayoutParams(-1,Ui.dp(this,48)); t.topMargin=Ui.dp(this,12); box.addView(loadTitle,t);
        loadStep=Ui.text(this,"Atualizando canais, filmes e séries...",phone?11:14,Ui.MUTED,true); loadStep.setGravity(Gravity.CENTER); box.addView(loadStep,new LinearLayout.LayoutParams(-1,Ui.dp(this,34)));
        TextView hint=Ui.text(this,"Aguarde. O aplicativo será liberado quando o conteúdo inicial estiver pronto.",phone?9:11,0xFF8FA79A,false); hint.setGravity(Gravity.CENTER); box.addView(hint,new LinearLayout.LayoutParams(-1,Ui.dp(this,28)));
        FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(phone?Ui.dp(this,560):Ui.dp(this,720),Ui.dp(this,240),Gravity.CENTER); ov.addView(box,bp); return ov;
    }

    private void startInitialPreparation(){
        if(loadingOverlay!=null){loadingOverlay.setVisibility(View.VISIBLE);loadingOverlay.bringToFront();loadingOverlay.requestFocus();}
        CatalogPreloader.start(this,true,(text,done,total)->runOnUiThread(()->{
            if(loadStep!=null)loadStep.setText(text+(total>0?"   "+done+"/"+total:""));
        }),()->runOnUiThread(this::openHome));
    }

    private boolean hasNetwork(){try{ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);NetworkInfo n=cm==null?null:cm.getActiveNetworkInfo();return n!=null&&n.isConnected();}catch(Throwable e){return false;}}
    private void showDiagnostic(){final Dialog d=new Dialog(this);d.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout box=Ui.column(this);box.setPadding(Ui.dp(this,24),Ui.dp(this,20),Ui.dp(this,24),Ui.dp(this,20));box.setBackground(Ui.stroke(Ui.PANEL,Ui.BORDER,18,this));TextView t=Ui.text(this,"Diagnóstico de rede",18,Ui.TEXT,true);t.setGravity(Gravity.CENTER);box.addView(t,new LinearLayout.LayoutParams(-1,Ui.dp(this,40)));LinearLayout steps=new LinearLayout(this);steps.setGravity(Gravity.CENTER);TextView a=step("BOX",Ui.GREEN),b=step("REDE",hasNetwork()?Ui.GREEN:Ui.RED),c=step("INTERNET",hasNetwork()?Ui.GREEN:Ui.RED),s=step("SERVIDOR",Ui.MUTED);for(TextView v:new TextView[]{a,b,c,s}){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(Ui.dp(this,95),Ui.dp(this,60));p.leftMargin=Ui.dp(this,5);p.rightMargin=Ui.dp(this,5);steps.addView(v,p);}box.addView(steps,new LinearLayout.LayoutParams(-1,Ui.dp(this,72)));TextView result=Ui.text(this,"Testando servidor...",11,Ui.MUTED,true);result.setGravity(Gravity.CENTER);box.addView(result,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));TextView close=Ui.button(this,"FECHAR");close.setOnClickListener(v->d.dismiss());box.addView(close,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));d.setContentView(box);Window w=d.getWindow();d.show();if(w!=null){w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));w.setLayout(Math.min(Ui.dp(this,520),getResources().getDisplayMetrics().widthPixels-Ui.dp(this,24)),WindowManager.LayoutParams.WRAP_CONTENT);}ApiClient.status(new ApiClient.Callback<String>(){public void ok(String x){runOnUiThread(()->{s.setTextColor(Ui.GREEN);result.setText("✓ Servidor online e acessível");result.setTextColor(Ui.GREEN);});}public void error(String m){runOnUiThread(()->{s.setTextColor(Ui.RED);result.setText("Falha: "+m);result.setTextColor(Ui.RED);});}});}
    private TextView step(String txt,int color){TextView v=Ui.text(this,"●\n"+txt,10,color,true);v.setGravity(Gravity.CENTER);v.setBackground(Ui.stroke(Color.rgb(12,16,20),color,11,this));return v;}
    private void openHome(){Intent in=new Intent(this,LiveTvActivity.class);in.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(in);finish();}
}
