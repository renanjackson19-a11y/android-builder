SPOTNET MUSIC V27 — CONTROLES E INDICAÇÃO

- Link individual de indicação retornado pelo painel em api/client_profile.php.
- Botão COMPARTILHAR LINK abre o compartilhamento nativo do Android.
- Mini player com anterior, play/pausa e próxima, sem ícone duplicado.
- Navegação inferior com destaque visual da aba ativa.
- Cache curto do áudio resolvido para repetir/trocar faixas mais rápido.
- Timeout da API de reprodução reduzido para evitar espera longa.

Painel: https://spotnet.br232.shop
