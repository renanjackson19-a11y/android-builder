package com.dubaidigital.music;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.net.URL;
import java.util.List;

public class SongAdapter extends RecyclerView.Adapter<SongAdapter.Holder> {
    public interface Click {
        void onClick(int position);
    }

    private final List<Song> data;
    private final Click click;

    public SongAdapter(List<Song> data, Click click) {
        this.data = data;
        this.click = click;
    }

    public static class Holder extends RecyclerView.ViewHolder {
        final TextView title;
        final TextView artist;
        final ImageView thumbnail;

        Holder(View view) {
            super(view);
            title = view.findViewById(R.id.title);
            artist = view.findViewById(R.id.artist);
            thumbnail = view.findViewById(R.id.thumb);
        }
    }

    @Override
    public Holder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_song, parent, false);
        return new Holder(view);
    }

    @Override
    public void onBindViewHolder(Holder holder, int position) {
        Song song = data.get(position);
        holder.title.setText(song.title);
        holder.artist.setText(song.artist);
        holder.itemView.setOnClickListener(view -> {
            int adapterPosition = holder.getBindingAdapterPosition();
            if (adapterPosition != RecyclerView.NO_POSITION) click.onClick(adapterPosition);
        });
        holder.thumbnail.setImageDrawable(null);

        if (!song.thumb.isEmpty()) {
            new Thread(() -> {
                try {
                    Bitmap bitmap = BitmapFactory.decodeStream(new URL(song.thumb).openStream());
                    holder.thumbnail.post(() -> holder.thumbnail.setImageBitmap(bitmap));
                } catch (Exception ignored) {
                }
            }).start();
        }
    }

    @Override
    public int getItemCount() {
        return data.size();
    }
}
