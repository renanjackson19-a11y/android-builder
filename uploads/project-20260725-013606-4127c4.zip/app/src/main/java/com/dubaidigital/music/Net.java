package com.dubaidigital.music;
import java.io.*;import java.net.*;import java.nio.charset.StandardCharsets;
public final class Net {
 public static String get(String url) throws Exception { HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection(); c.setConnectTimeout(15000);c.setReadTimeout(20000);c.setRequestProperty("User-Agent","DubaiMusic/1.0"); return read(c); }
 public static String post(String url,String body) throws Exception { HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setRequestMethod("POST");c.setDoOutput(true);c.setConnectTimeout(15000);c.setReadTimeout(20000);c.setRequestProperty("Content-Type","application/x-www-form-urlencoded");try(OutputStream o=c.getOutputStream()){o.write(body.getBytes(StandardCharsets.UTF_8));}return read(c); }
 private static String read(HttpURLConnection c)throws Exception{int code=c.getResponseCode();InputStream in=code>=400?c.getErrorStream():c.getInputStream();if(in==null)throw new IOException("HTTP "+code);try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){StringBuilder b=new StringBuilder();String s;while((s=r.readLine())!=null)b.append(s);if(code>=400)throw new IOException("HTTP "+code+": "+b);return b.toString();}}
}
