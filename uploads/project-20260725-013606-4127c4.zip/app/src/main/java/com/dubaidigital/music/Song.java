package com.dubaidigital.music;
public class Song {
 public final String id,title,artist,thumb;
 public Song(String id,String title,String artist,String thumb){this.id=id;this.title=title;this.artist=artist;this.thumb=thumb;}
}
