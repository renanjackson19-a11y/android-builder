package com.ativacao.app;

import android.app.Activity;
import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Sincronização inicial: o painel já entrega capa/sinopse/TMDB prontos.
 * O APK apenas baixa seis pacotes (normal/adulto x live/movie/series), grava localmente
 * e só então libera a navegação.
 */
final class CatalogPreloader {
    private static final String PREF="dubai_content_preload";
    private static final int CACHE_SCHEMA=77;
    private static volatile boolean running=false,ready=false;
    interface Progress { void onProgress(String text,int done,int total); }
    static void init(Context c){if(c!=null)ready=isPrepared(c);}
    static boolean isPrepared(Context c){return c!=null&&c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getBoolean(key(Session.token(c)),false);}
    private static String key(String token){return "ready_v"+CACHE_SCHEMA+"_"+Integer.toHexString((token==null?"":token).hashCode());}
    private static void mark(Context c,boolean v){if(c!=null)c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putBoolean(key(Session.token(c)),v).apply();ready=v;}
    static void start(Activity a,boolean force,Runnable done){start(a,force,null,done);}
    static void start(Activity a,boolean force,Progress progress,Runnable done){
        if(a==null){if(done!=null)done.run();return;} String token=Session.token(a);
        if(!force&&isPrepared(a)&&bundlesReady(token)){ready=true;if(done!=null)done.run();return;}
        if(running)return;running=true;mark(a,false);if(force)CatalogBundleStore.clearToken(token);
        final int total=7;AtomicInteger left=new AtomicInteger(total),ok=new AtomicInteger(0),step=new AtomicInteger(0);
        notify(progress,"Carregando conteúdos, aguarde...",0,total);
        fetch(a,"live",false,"TV",left,ok,step,total,progress,done);
        fetch(a,"movie",false,"Filmes",left,ok,step,total,progress,done);
        fetch(a,"series",false,"Séries",left,ok,step,total,progress,done);
        fetch(a,"live",true,"HOT canais",left,ok,step,total,progress,done);
        fetch(a,"movie",true,"HOT filmes",left,ok,step,total,progress,done);
        fetch(a,"series",true,"HOT séries",left,ok,step,total,progress,done);
        ApiClient.hotCategories(new ApiClient.Callback<java.util.List<ApiClient.HotCategory>>(){public void ok(java.util.List<ApiClient.HotCategory> x){ok.incrementAndGet();finish(a,"Categorias HOT",left,ok,step,total,progress,done);}public void error(String m){finish(a,"Categorias HOT",left,ok,step,total,progress,done);}});
    }
    private static void fetch(Activity a,String type,boolean adult,String label,AtomicInteger left,AtomicInteger ok,AtomicInteger step,int total,Progress progress,Runnable done){
        ApiClient.fetchCatalogBundle(type,adult,new ApiClient.Callback<JSONObject>(){
            public void ok(JSONObject root){if(root!=null&&root.optBoolean("ok",false)){ok.incrementAndGet();warmCovers(a,root);}finish(a,label,left,ok,step,total,progress,done);}
            public void error(String m){finish(a,label,left,ok,step,total,progress,done);}
        });
    }
    private static void finish(Activity a,String label,AtomicInteger left,AtomicInteger ok,AtomicInteger step,int total,Progress progress,Runnable done){
        int d=step.incrementAndGet();notify(progress,"Preparando "+label+"...",d,total);if(left.decrementAndGet()!=0)return;running=false;
        boolean good=ok.get()==total&&bundlesReady(Session.token(a));mark(a,good);notify(progress,good?"Conteúdo pronto":"Não foi possível preparar todo o conteúdo",total,total);if(done!=null)done.run();
    }
    private static boolean bundlesReady(String t){return CatalogBundleStore.has(t,"live",false)&&CatalogBundleStore.has(t,"movie",false)&&CatalogBundleStore.has(t,"series",false)&&CatalogBundleStore.has(t,"live",true)&&CatalogBundleStore.has(t,"movie",true)&&CatalogBundleStore.has(t,"series",true);}
    private static void warmCovers(Activity a,JSONObject root){JSONArray arr=root.optJSONArray("items");if(arr==null)return;int max=Math.min(arr.length(),80);for(int n=0;n<max;n++){JSONObject o=arr.optJSONObject(n);if(o==null)continue;String logo=o.optString("logo","");String back=o.optString("backdrop","");ImageLoader.preload(a,!logo.trim().isEmpty()?logo:back);}}
    private static void notify(Progress p,String t,int d,int total){if(p!=null)p.onProgress(t,d,total);}
}
