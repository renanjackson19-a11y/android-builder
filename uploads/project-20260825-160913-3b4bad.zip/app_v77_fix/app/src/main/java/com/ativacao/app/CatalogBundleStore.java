package com.ativacao.app;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Catálogo completo entregue pronto pelo painel. O APK apenas lê/cacheia. */
final class CatalogBundleStore {
    private static Context app;
    private CatalogBundleStore(){}
    static void init(Context c){ if(c!=null) app=c.getApplicationContext(); }
    private static File dir(){ if(app==null)return null; File d=new File(app.getFilesDir(),"catalog_bundle"); if(!d.exists())d.mkdirs(); return d; }
    private static String safe(String s){return Integer.toHexString((s==null?"":s).hashCode());}
    private static File file(String token,String type,boolean adult){File d=dir();return d==null?null:new File(d,safe(token)+"_"+type+"_"+(adult?"adult":"normal")+".json");}
    static void put(String token,String type,boolean adult,JSONObject root){File f=file(token,type,adult);if(f==null||root==null)return;try(FileOutputStream o=new FileOutputStream(f,false)){o.write(root.toString().getBytes(StandardCharsets.UTF_8));}catch(Exception ignored){}}
    static JSONObject get(String token,String type,boolean adult){File f=file(token,type,adult);if(f==null||!f.isFile())return null;try(BufferedReader r=new BufferedReader(new InputStreamReader(new FileInputStream(f),StandardCharsets.UTF_8))){StringBuilder b=new StringBuilder();String l;while((l=r.readLine())!=null)b.append(l);return new JSONObject(b.toString());}catch(Exception e){return null;}}
    static boolean has(String token,String type,boolean adult){JSONObject o=get(token,type,adult);return o!=null&&o.optJSONArray("items")!=null;}
    static void clearToken(String token){File d=dir();if(d==null)return;String p=safe(token)+"_";File[] fs=d.listFiles();if(fs!=null)for(File f:fs)if(f.getName().startsWith(p))f.delete();}

    static List<String> categories(String token,String type,boolean adult){JSONObject root=get(token,type,adult);if(root==null)return null;JSONArray a=root.optJSONArray("categories");if(a==null)return null;List<String> out=new ArrayList<>();for(int n=0;n<a.length();n++){String x=a.optString(n,"");if(!x.isEmpty())out.add(x);}return out;}

    static ApiClient.CatalogPage page(String token,String type,int page,int limit,String search,String category,String smart){
        boolean adult="adult".equalsIgnoreCase(clean(smart)); JSONObject root=get(token,type,adult); if(root==null)return null;
        JSONArray arr=root.optJSONArray("items"); if(arr==null)return null;
        String q=clean(search).toLowerCase(), cat=clean(category), sm=clean(smart).toLowerCase();
        List<ApiClient.Item> filtered=new ArrayList<>();
        for(int n=0;n<arr.length();n++){JSONObject o=arr.optJSONObject(n);if(o==null)continue;ApiClient.Item i=ApiClient.parseItemForStore(o);if(i==null)continue;
            if(!cat.isEmpty()&&!cat.equalsIgnoreCase(i.group))continue;
            if(!q.isEmpty()&&!((i.name+" "+i.group+" "+i.seriesTitle).toLowerCase().contains(q)))continue;
            if("kids".equals(sm)&&!containsAny(i.group,"kids","infantil","desenho"))continue;
            if("anime".equals(sm)&&!containsAny(i.group,"anime"))continue;
            filtered.add(i);
        }
        ApiClient.CatalogPage out=new ApiClient.CatalogPage(); out.total=filtered.size(); out.page=Math.max(1,page); out.pages=Math.max(1,(int)Math.ceil(out.total/(double)Math.max(1,limit)));
        int from=Math.min(out.total,(out.page-1)*limit),to=Math.min(out.total,from+limit); for(int n=from;n<to;n++)out.items.add(filtered.get(n));
        JSONArray cats=root.optJSONArray("categories");if(cats!=null)for(int n=0;n<cats.length();n++){String x=cats.optString(n,"");if(!x.isEmpty())out.categories.add(x);} return out;
    }
    private static boolean containsAny(String s,String... ks){String x=clean(s).toLowerCase();for(String k:ks)if(x.contains(k))return true;return false;}
    private static String clean(String s){return s==null?"":s.trim();}
}
