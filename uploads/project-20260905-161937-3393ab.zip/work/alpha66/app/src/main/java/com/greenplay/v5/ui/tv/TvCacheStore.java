package com.greenplay.v5.ui.tv;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.greenplay.v5.data.model.tv.TvChannel;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/** Last-known TV channel list for transient Xtream failures on the same host/account. */
public final class TvCacheStore {
    private static final String PREF = "green_play_v5_tv_cache_v1";
    private static final Type CHANNELS = new TypeToken<List<TvChannel>>(){}.getType();
    private final SharedPreferences prefs;
    private final Gson gson = new Gson();
    private final String scope;

    public TvCacheStore(Context context, String host, String user) {
        prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        scope = Integer.toHexString(((host == null ? "" : host) + "|" + (user == null ? "" : user)).hashCode());
    }

    public List<TvChannel> channels() {
        try {
            List<TvChannel> rows = gson.fromJson(prefs.getString(scope + "_channels", "[]"), CHANNELS);
            return rows == null ? new ArrayList<>() : rows;
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    public void saveChannels(List<TvChannel> rows) {
        prefs.edit().putString(scope + "_channels", gson.toJson(rows == null ? java.util.Collections.emptyList() : rows)).apply();
    }
}
