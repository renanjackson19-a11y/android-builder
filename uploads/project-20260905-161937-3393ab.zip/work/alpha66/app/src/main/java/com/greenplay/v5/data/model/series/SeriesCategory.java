package com.greenplay.v5.data.model.series;

public final class SeriesCategory {
    public String id = "";
    public String name = "";
    /** Explicit adult marker supplied by compatible Xtream/panel backends. */
    public boolean isAdult = false;
}
