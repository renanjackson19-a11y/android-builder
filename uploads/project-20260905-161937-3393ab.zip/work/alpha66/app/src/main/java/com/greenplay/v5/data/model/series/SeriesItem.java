package com.greenplay.v5.data.model.series;

import java.util.ArrayList;
import java.util.List;

public final class SeriesItem {
    public long id;
    public String name = "";
    public String cover = "";
    public String categoryId = "";
    public String year = "";
    public String rating = "";
    /** Metadata published by get_series when available; used by special sections without opening every detail page. */
    public String plot = "";
    public String genre = "";
    public boolean isAdult = false;
    /** Optional backend classification fields (when present in the Xtream/custom payload). */
    public String mediaType = "";
    public String vodType = "";
    public String filterType = "";
    /** Other Xtream records that represent the same title/year. */
    public List<Long> alternateIds = new ArrayList<>();
}
