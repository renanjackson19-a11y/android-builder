package com.greenplay.v5.core.catalog;

import android.os.Handler;
import android.os.Looper;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Warms Picasso's persistent image cache without blocking the UI.
 * A small priority window can be awaited by startup; the full catalog keeps
 * warming in the background after the app opens.
 */
public final class CatalogCoverWarmer {
    public interface ProgressListener {
        void onProgress(int done, int total);
        void onComplete(int total);
    }

    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final ArrayDeque<String> QUEUE = new ArrayDeque<>();
    private static final Set<String> SEEN = new HashSet<>();
    private static boolean running = false;

    private CatalogCoverWarmer() {}

    public static synchronized void enqueue(List<String> urls) {
        if (urls == null) return;
        for (String raw : urls) {
            String url = clean(raw);
            if (url.isEmpty() || !SEEN.add(url)) continue;
            QUEUE.add(url);
        }
        if (!running && !QUEUE.isEmpty()) {
            running = true;
            MAIN.post(CatalogCoverWarmer::drainBatch);
        }
    }

    public static void warmPriority(List<String> urls, int limit, ProgressListener listener) {
        List<String> unique = new ArrayList<>();
        Set<String> local = new HashSet<>();
        if (urls != null) {
            for (String raw : urls) {
                String url = clean(raw);
                if (url.isEmpty() || !local.add(url)) continue;
                synchronized (CatalogCoverWarmer.class) { SEEN.add(url); }
                unique.add(url);
                if (unique.size() >= Math.max(1, limit)) break;
            }
        }
        if (unique.isEmpty()) {
            if (listener != null) listener.onComplete(0);
            return;
        }
        PrioritySession session = new PrioritySession(unique, listener);
        MAIN.post(session::start);
    }

    private static final class PrioritySession {
        private final ArrayDeque<String> urls;
        private final ProgressListener listener;
        private final int total;
        private int done;
        private int active;
        private boolean completed;

        PrioritySession(List<String> rows, ProgressListener listener) {
            this.urls = new ArrayDeque<>(rows);
            this.listener = listener;
            this.total = rows.size();
        }

        void start() {
            int starters = Math.min(3, total);
            for (int i = 0; i < starters; i++) launchNext();
        }

        void launchNext() {
            if (completed) return;
            String url = urls.poll();
            if (url == null) {
                if (active == 0) finish();
                return;
            }
            active++;
            fetchWithRetry(url, 0);
        }

        void fetchWithRetry(String url, int attempt) {
            try {
                Picasso.get().load(url).fetch(new Callback() {
                    @Override public void onSuccess() { oneDone(); }
                    @Override public void onError(Exception e) {
                        if (attempt < 1) MAIN.postDelayed(() -> fetchWithRetry(url, attempt + 1), 420L);
                        else oneDone();
                    }
                });
            } catch (Exception e) {
                if (attempt < 1) MAIN.postDelayed(() -> fetchWithRetry(url, attempt + 1), 420L);
                else oneDone();
            }
        }

        void oneDone() {
            active = Math.max(0, active - 1);
            done++;
            if (listener != null) listener.onProgress(done, total);
            if (!urls.isEmpty()) launchNext();
            else if (active == 0) finish();
        }

        void finish() {
            if (completed) return;
            completed = true;
            if (listener != null) listener.onComplete(total);
        }
    }

    private static void drainBatch() {
        int count = 0;
        while (count < 2) {
            String url;
            synchronized (CatalogCoverWarmer.class) { url = QUEUE.poll(); }
            if (url == null) break;
            try { Picasso.get().load(url).fetch(); } catch (Exception ignored) {}
            count++;
        }
        synchronized (CatalogCoverWarmer.class) {
            if (QUEUE.isEmpty()) {
                running = false;
                return;
            }
        }
        MAIN.postDelayed(CatalogCoverWarmer::drainBatch, 320L);
    }

    private static String clean(String raw) {
        return raw == null ? "" : raw.trim();
    }
}
