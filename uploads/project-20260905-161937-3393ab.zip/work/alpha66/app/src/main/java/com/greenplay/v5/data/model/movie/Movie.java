package com.greenplay.v5.data.model.movie;

public final class Movie {
    public long id;
    public String name = "";
    public String poster = "";
    public String categoryId = "";
    public String extension = "mp4";
    public String year = "";
    public String rating = "";
    public String directSource = "";
    /** Xtream is_adult flag, kept for the dedicated HOT catalog only. */
    public boolean isAdult = false;
    /** Optional backend classification fields (Velox-style when the server exposes them). */
    public String mediaType = "";
    public String vodType = "";
    public String filterType = "";
}
