package com.greenplay.v5.core.catalog;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Política de atualização do catálogo.
 *
 * V5.0.109:
 * - primeira utilização: baixa o catálogo completo e grava localmente;
 * - aberturas seguintes: usa o catálogo local imediatamente;
 * - somente depois de um período longo sem abrir o app é feita uma atualização
 *   silenciosa em segundo plano, sem prender o cliente na tela de carregamento.
 */
public final class CatalogRefreshPolicy {
    private static final String PREF = "green_play_v5_catalog_refresh_policy_v1";
    // "Muito tempo sem acessar": 12 horas. Pode ser alterado aqui sem tocar na rede/UI.
    public static final long LONG_IDLE_MS = 12L * 60L * 60L * 1000L;

    private final SharedPreferences prefs;
    private final String scope;

    public CatalogRefreshPolicy(Context context, String host, String user) {
        prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        scope = Integer.toHexString(((host == null ? "" : host.trim()) + "|" +
                (user == null ? "" : user.trim())).hashCode());
    }

    public long lastAccess() { return prefs.getLong(scope + "_last_access", 0L); }
    public long lastFullRefresh() { return prefs.getLong(scope + "_last_full_refresh", 0L); }

    /** Retorna o tempo desde a abertura anterior e já registra a abertura atual. */
    public long consumeIdleAndTouch() {
        long now = System.currentTimeMillis();
        long previous = lastAccess();
        prefs.edit().putLong(scope + "_last_access", now).apply();
        return previous <= 0L ? Long.MAX_VALUE : Math.max(0L, now - previous);
    }

    public void markFullRefresh() {
        long now = System.currentTimeMillis();
        prefs.edit()
                .putLong(scope + "_last_full_refresh", now)
                .putLong(scope + "_last_access", now)
                .apply();
    }

    public boolean shouldSilentRefresh(long idleBeforeOpen) {
        // Cache herdado de versão antiga (sem timestamp) também recebe UMA atualização
        // silenciosa, mas nunca bloqueia a entrada do cliente.
        return idleBeforeOpen == Long.MAX_VALUE || idleBeforeOpen >= LONG_IDLE_MS;
    }
}
