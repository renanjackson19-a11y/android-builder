package com.greenplay.v5.ui.special;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.greenplay.v5.R;
import com.greenplay.v5.core.catalog.SpecialCatalogIndex;
import java.util.ArrayList;
import java.util.List;

public final class SpecialCategoryAdapter extends RecyclerView.Adapter<SpecialCategoryAdapter.Holder> {
    public interface Listener { void onOpen(SpecialCatalogIndex.CategoryRow row); }
    private final Listener listener;
    private final List<SpecialCatalogIndex.CategoryRow> rows = new ArrayList<>();
    private String selectedId = "";

    public SpecialCategoryAdapter(Listener listener) {
        this.listener = listener;
        setHasStableIds(true);
    }

    public void submit(List<SpecialCatalogIndex.CategoryRow> data, String selected) {
        rows.clear();
        if (data != null) rows.addAll(data);
        selectedId = selected == null ? "" : selected;
        notifyDataSetChanged();
    }

    public void select(String id) {
        selectedId = id == null ? "" : id;
        notifyDataSetChanged();
    }

    @Override public long getItemId(int position) {
        String id = rows.get(position).id;
        try { return Long.parseLong(id); } catch (Exception e) { return id.hashCode(); }
    }

    @NonNull @Override public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new Holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_movie_category, parent, false));
    }

    @Override public void onBindViewHolder(@NonNull Holder h, int position) {
        SpecialCatalogIndex.CategoryRow row = rows.get(position);
        h.name.setText(row.name);
        boolean selected = selectedId.equals(row.id);
        h.itemView.setSelected(selected);
        h.itemView.setOnFocusChangeListener((v, focused) -> v.setSelected(focused || selectedId.equals(row.id)));
        h.itemView.setOnClickListener(v -> listener.onOpen(row));
    }

    @Override public int getItemCount() { return rows.size(); }

    static final class Holder extends RecyclerView.ViewHolder {
        final TextView name;
        Holder(View item) {
            super(item);
            name = item.findViewById(R.id.movieCategoryName);
        }
    }
}
