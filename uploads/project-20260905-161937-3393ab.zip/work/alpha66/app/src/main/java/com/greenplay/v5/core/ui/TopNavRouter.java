package com.greenplay.v5.core.ui;

import android.app.Activity;
import android.content.Intent;

/**
 * V5.0.106: navegação superior sem animação e sem empilhar cópias da mesma tela.
 * Reutiliza Activities já abertas para evitar o "piscar" entre TV/Jogos/Filmes/Séries.
 */
public final class TopNavRouter {
    private TopNavRouter() {}

    public static void open(Activity activity, Class<? extends Activity> target) {
        if (activity == null || target == null) return;
        if (target.isInstance(activity)) return;
        Intent i = new Intent(activity, target);
        i.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                | Intent.FLAG_ACTIVITY_SINGLE_TOP
                | Intent.FLAG_ACTIVITY_NO_ANIMATION);
        activity.startActivity(i);
        activity.overridePendingTransition(0, 0);
    }
}
