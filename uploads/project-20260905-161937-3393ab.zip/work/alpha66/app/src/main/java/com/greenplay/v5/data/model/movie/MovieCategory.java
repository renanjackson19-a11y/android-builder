package com.greenplay.v5.data.model.movie;

public final class MovieCategory {
    public String id = "";
    public String name = "";
    /** Explicit adult marker supplied by compatible Xtream/panel backends. */
    public boolean isAdult = false;

    public MovieCategory() {}

    public MovieCategory(String id, String name) {
        this(id, name, false);
    }

    public MovieCategory(String id, String name, boolean isAdult) {
        this.id = id == null ? "" : id;
        this.name = name == null ? "" : name;
        this.isAdult = isAdult;
    }
}
