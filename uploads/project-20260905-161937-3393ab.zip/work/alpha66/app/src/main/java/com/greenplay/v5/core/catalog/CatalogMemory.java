package com.greenplay.v5.core.catalog;

import com.greenplay.v5.data.model.movie.Movie;
import com.greenplay.v5.data.model.movie.MovieCategory;
import com.greenplay.v5.data.model.series.SeriesItem;
import com.greenplay.v5.data.model.series.SeriesCategory;
import com.greenplay.v5.data.model.tv.TvChannel;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Fresh catalog prepared at app startup. It deliberately lives only in-process:
 * every cold start re-reads the current bouquet from the panel, avoiding stale
 * permissions after a source is changed.
 */
public final class CatalogMemory {
    private static List<TvChannel> channels = Collections.emptyList();
    private static List<MovieCategory> movieCategories = Collections.emptyList();
    private static List<Movie> movies = Collections.emptyList();
    private static List<SeriesItem> series = Collections.emptyList();
    private static List<SeriesCategory> seriesCategories = Collections.emptyList();
    private static long updatedAt = 0L;

    private CatalogMemory() {}

    public static synchronized void clear() {
        channels = Collections.emptyList();
        movieCategories = Collections.emptyList();
        movies = Collections.emptyList();
        series = Collections.emptyList();
        seriesCategories = Collections.emptyList();
        updatedAt = 0L;
        SpecialCatalogIndex.clear();
    }

    public static synchronized void setChannels(List<TvChannel> rows) {
        channels = copy(rows);
        touch();
    }

    public static synchronized void setMovieCategories(List<MovieCategory> rows) {
        movieCategories = copy(rows);
        touch();
    }

    public static synchronized void setMovies(List<Movie> rows) {
        movies = copy(rows);
        touch();
    }

    public static synchronized void setSeries(List<SeriesItem> rows) {
        series = copy(rows);
        touch();
    }

    public static synchronized void setSeriesCategories(List<SeriesCategory> rows) {
        seriesCategories = copy(rows);
        touch();
    }

    public static synchronized List<TvChannel> channels() { return new ArrayList<>(channels); }
    public static synchronized List<MovieCategory> movieCategories() { return new ArrayList<>(movieCategories); }
    public static synchronized List<Movie> movies() { return new ArrayList<>(movies); }
    public static synchronized List<SeriesItem> series() { return new ArrayList<>(series); }
    public static synchronized List<SeriesCategory> seriesCategories() { return new ArrayList<>(seriesCategories); }
    public static synchronized long updatedAt() { return updatedAt; }

    /** V5.0.104: retorna apenas os itens permitidos pelo escopo, sem copiar o catálogo inteiro. */
    public static synchronized List<Movie> moviesForIds(java.util.Set<Long> ids) {
        ArrayList<Movie> out = new ArrayList<>();
        if (ids == null || ids.isEmpty()) return out;
        for (Movie x : movies) if (x != null && ids.contains(x.id)) out.add(x);
        return out;
    }

    public static synchronized List<SeriesItem> seriesForIds(java.util.Set<Long> ids) {
        ArrayList<SeriesItem> out = new ArrayList<>();
        if (ids == null || ids.isEmpty()) return out;
        for (SeriesItem x : series) if (x != null && ids.contains(x.id)) out.add(x);
        return out;
    }

    private static void touch() { updatedAt = android.os.SystemClock.elapsedRealtime(); }

    private static <T> List<T> copy(List<T> rows) {
        return rows == null ? new ArrayList<>() : new ArrayList<>(rows);
    }
}
