package fun.greenplay.app;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import androidx.core.content.FileProvider;
import org.json.*;
import java.io.*;
import java.net.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.*;

final class AppUpdater {
    private static final ExecutorService IO=Executors.newSingleThreadExecutor(r->{Thread t=new Thread(r,"gp-updater");t.setDaemon(true);return t;});
    private static final Handler MAIN=new Handler(Looper.getMainLooper());
    private static boolean checking=false,shown=false,installLaunched=false;
    private static File pendingApk=null;
    private static String pendingVersion="";

    static int dp(Context c,int v){return Math.round(v*c.getResources().getDisplayMetrics().density);}
    static GradientDrawable bg(int color,int radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(radius);return g;}
    static TextView text(Context c,String s,int sp,int color){TextView t=new TextView(c);t.setText(s);t.setTextSize(sp);t.setTextColor(color);return t;}

    static void check(MainActivity a){
        if(a==null||a.isFinishing()||checking||shown)return;
        checking=true;
        Api.post("general_setting",Api.m(),new Api.CB(){public void ok(JSONObject j){checking=false;try{
            JSONArray r=j.optJSONArray("result");if(r==null)return;HashMap<String,String> m=new HashMap<>();
            for(int i=0;i<r.length();i++){JSONObject x=r.optJSONObject(i);if(x!=null)m.put(x.optString("key"),x.optString("value"));}
            if(!"1".equals(m.get("greenplay_update_enabled")))return;
            int code=0;try{code=Integer.parseInt(m.getOrDefault("greenplay_update_version_code","0"));}catch(Exception ignored){}
            String ver=m.getOrDefault("greenplay_update_version_name","").trim();String url=m.getOrDefault("greenplay_update_apk_url","").trim();
            if(code<=BuildConfig.VERSION_CODE||url.isEmpty()||(!url.startsWith("https://")&&!url.startsWith("http://")))return;
            shown=true;showPrompt(a,code,ver,url,m.getOrDefault("greenplay_update_notes",""),m.getOrDefault("greenplay_update_sha256",""),"1".equals(m.get("greenplay_update_required")));
        }catch(Exception ignored){}}public void err(String e){checking=false;}});
    }

    static void showPrompt(MainActivity a,int code,String ver,String url,String notes,String sha,boolean required){
        if(a.isFinishing())return;
        final Dialog d=new Dialog(a,android.R.style.Theme_Material_NoActionBar);
        d.setCancelable(!required);

        FrameLayout dim=new FrameLayout(a);
        dim.setBackgroundColor(0xf0000000);
        ScrollView scroll=new ScrollView(a);scroll.setFillViewport(true);scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        dim.addView(scroll,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout outer=new LinearLayout(a);outer.setOrientation(LinearLayout.VERTICAL);outer.setGravity(Gravity.CENTER_HORIZONTAL);
        int side=dp(a,a.tvMode?86:24);outer.setPadding(side,dp(a,a.tvMode?46:28),side,dp(a,24));
        scroll.addView(outer,new ScrollView.LayoutParams(-1,-2));

        TextView title=text(a,"Nova atualização disponível",a.tvMode?27:23,Color.WHITE);title.setTypeface(null,1);title.setGravity(Gravity.CENTER);
        outer.addView(title,new LinearLayout.LayoutParams(-1,dp(a,54)));
        TextView sub=text(a,"GreenPlay "+(ver.isEmpty()?String.valueOf(code):ver),a.tvMode?17:15,0xff20e070);sub.setGravity(Gravity.CENTER);
        outer.addView(sub,new LinearLayout.LayoutParams(-1,dp(a,34)));

        View divider=new View(a);divider.setBackgroundColor(0xff1d2a23);LinearLayout.LayoutParams divp=new LinearLayout.LayoutParams(-1,dp(a,1));divp.setMargins(0,dp(a,16),0,dp(a,20));outer.addView(divider,divp);

        TextView ntitle=text(a,"Novas funções  (v "+(ver.isEmpty()?String.valueOf(code):ver)+")",a.tvMode?18:16,Color.WHITE);ntitle.setTypeface(null,1);outer.addView(ntitle,new LinearLayout.LayoutParams(-1,dp(a,38)));
        String clean=notes==null?"":notes.trim();if(clean.isEmpty())clean="Melhorias de desempenho, estabilidade e correções do GreenPlay.";
        TextView nt=text(a,clean,a.tvMode?15:14,0xffd2d8d4);nt.setLineSpacing(dp(a,3),1.08f);nt.setGravity(Gravity.START);
        LinearLayout.LayoutParams ntp=new LinearLayout.LayoutParams(-1,-2);ntp.setMargins(0,0,0,dp(a,22));outer.addView(nt,ntp);

        LinearLayout progressArea=new LinearLayout(a);progressArea.setOrientation(LinearLayout.VERTICAL);progressArea.setVisibility(View.GONE);
        outer.addView(progressArea,new LinearLayout.LayoutParams(-1,-2));
        ProgressBar bar=new ProgressBar(a,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(100);bar.setProgress(0);bar.setIndeterminate(false);
        try{bar.getProgressDrawable().setColorFilter(0xff20e070,android.graphics.PorterDuff.Mode.SRC_IN);}catch(Exception ignored){}
        progressArea.addView(bar,new LinearLayout.LayoutParams(-1,dp(a,12)));
        TextView state=text(a,"0%",a.tvMode?14:13,0xffd5ddd8);state.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams stp=new LinearLayout.LayoutParams(-1,dp(a,38));stp.setMargins(0,dp(a,6),0,dp(a,4));progressArea.addView(state,stp);

        LinearLayout actions=new LinearLayout(a);actions.setOrientation(LinearLayout.HORIZONTAL);actions.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams actp=new LinearLayout.LayoutParams(-1,dp(a,58));actp.setMargins(0,dp(a,8),0,0);outer.addView(actions,actp);
        Button later=new Button(a);later.setText("Depois");later.setTextColor(Color.WHITE);later.setTextSize(a.tvMode?15:14);later.setAllCaps(false);later.setBackground(bg(0xff252a27,dp(a,10)));
        Button go=new Button(a);go.setText("Atualizar agora");go.setTextColor(0xff031008);go.setTextSize(a.tvMode?15:14);go.setTypeface(null,1);go.setAllCaps(false);go.setBackground(bg(0xff20e070,dp(a,10)));
        if(!required){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,1);lp.setMargins(0,0,dp(a,7),0);actions.addView(later,lp);}
        LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(0,-1,1);gp.setMargins(required?0:dp(a,7),0,0,0);actions.addView(go,gp);

        TextView current=text(a,"Versão atual: "+BuildConfig.VERSION_NAME,a.tvMode?13:12,0xff929d97);current.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams curp=new LinearLayout.LayoutParams(-1,dp(a,42));curp.setMargins(0,dp(a,16),0,0);outer.addView(current,curp);

        later.setOnClickListener(v->d.dismiss());
        go.setOnClickListener(v->{
            go.setEnabled(false);later.setEnabled(false);actions.setVisibility(View.GONE);
            progressArea.setVisibility(View.VISIBLE);
            title.setText("Atualizando...");
            title.setTextSize(a.tvMode?26:22);
            sub.setText("Atualizando... não feche o aplicativo");
            sub.setTextColor(0xffffb347);
            download(a,d,url,ver,sha,bar,state);
        });

        d.setContentView(dim);
        Window w=d.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.setLayout(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.MATCH_PARENT);w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);}
        d.setOnShowListener(x->{Window ww=d.getWindow();if(ww!=null)ww.setLayout(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.MATCH_PARENT);if(a.tvMode)go.requestFocus();});
        d.show();
    }

    static void download(MainActivity a,Dialog d,String url,String ver,String sha,ProgressBar bar,TextView state){
        IO.execute(()->{HttpURLConnection c=null;FileOutputStream out=null;InputStream in=null;try{
            File dir=new File(a.getCacheDir(),"updates");if(!dir.exists())dir.mkdirs();File[] old=dir.listFiles();if(old!=null)for(File f:old)if(f.isFile())f.delete();
            String safe=(ver==null||ver.trim().isEmpty()?"nova":ver.trim()).replaceAll("[^0-9A-Za-z._-]","_");File apk=new File(dir,"GreenPlay_"+safe+".apk");
            c=(HttpURLConnection)new URL(url).openConnection();c.setInstanceFollowRedirects(true);c.setConnectTimeout(15000);c.setReadTimeout(30000);c.setRequestProperty("User-Agent","GreenPlay/"+BuildConfig.VERSION_NAME);int rc=c.getResponseCode();if(rc<200||rc>=400)throw new IOException("Servidor respondeu HTTP "+rc);long total=c.getContentLengthLong();if(total>350L*1024L*1024L)throw new IOException("Arquivo de atualização muito grande");in=c.getInputStream();out=new FileOutputStream(apk);byte[] buf=new byte[64*1024];long got=0,lastAt=System.currentTimeMillis(),lastBytes=0;int n;
            while((n=in.read(buf))>0){out.write(buf,0,n);got+=n;long now=System.currentTimeMillis();if(now-lastAt>=300){long dg=got-lastBytes,dt=now-lastAt;double mbps=dt>0?(dg/1024.0/1024.0)/(dt/1000.0):0;int pct=total>0?(int)Math.min(99,got*100/total):0;long fg=got,ft=total;MAIN.post(()->{if(total>0){bar.setIndeterminate(false);bar.setProgress(pct);state.setText(pct+"%  •  "+String.format(java.util.Locale.US,"%.1f MB/s",mbps));}else{bar.setIndeterminate(true);state.setText(String.format(java.util.Locale.US,"%.1f MB baixados • %.1f MB/s",fg/1024.0/1024.0,mbps));}});lastAt=now;lastBytes=got;}
            }
            out.flush();if(apk.length()<64*1024)throw new IOException("APK baixado está incompleto");String expected=sha==null?"":sha.trim().toLowerCase(java.util.Locale.ROOT);if(!expected.isEmpty()&&!expected.equals(sha256(apk)))throw new IOException("Falha na verificação do arquivo");pendingApk=apk;pendingVersion=ver;installLaunched=false;MAIN.post(()->{bar.setIndeterminate(false);bar.setProgress(100);state.setText("100% • download concluído");requestInstall(a,d);});
        }catch(Exception e){String msg=e.getMessage()==null?"Falha ao baixar a atualização":e.getMessage();MAIN.post(()->{state.setText("Erro: "+msg);Toast.makeText(a,"Não foi possível atualizar: "+msg,Toast.LENGTH_LONG).show();});}finally{try{if(in!=null)in.close();}catch(Exception ignored){}try{if(out!=null)out.close();}catch(Exception ignored){}if(c!=null)c.disconnect();}});
    }

    static String sha256(File f)throws Exception{MessageDigest d=MessageDigest.getInstance("SHA-256");try(InputStream in=new FileInputStream(f)){byte[] b=new byte[64*1024];int n;while((n=in.read(b))>0)d.update(b,0,n);}StringBuilder s=new StringBuilder();for(byte x:d.digest())s.append(String.format(java.util.Locale.US,"%02x",x));return s.toString();}

    static void requestInstall(MainActivity a,Dialog d){
        try{if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O&&!a.getPackageManager().canRequestPackageInstalls()){Intent i=new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,Uri.parse("package:"+a.getPackageName()));a.startActivity(i);Toast.makeText(a,"Permita instalar atualizações do GreenPlay e volte para continuar.",Toast.LENGTH_LONG).show();return;}install(a,d);}catch(Exception e){Toast.makeText(a,"Não foi possível abrir o instalador.",Toast.LENGTH_LONG).show();}
    }
    static void resumeInstall(MainActivity a){if(pendingApk==null||!pendingApk.exists()||installLaunched)return;try{if(Build.VERSION.SDK_INT<Build.VERSION_CODES.O||a.getPackageManager().canRequestPackageInstalls())install(a,null);}catch(Exception ignored){}}
    static void install(MainActivity a,Dialog d)throws Exception{
        if(pendingApk==null||!pendingApk.exists()||installLaunched)return;Uri uri;if(Build.VERSION.SDK_INT>=24)uri=FileProvider.getUriForFile(a,a.getPackageName()+".fileprovider",pendingApk);else uri=Uri.fromFile(pendingApk);Intent i=new Intent(Intent.ACTION_VIEW);i.setDataAndType(uri,"application/vnd.android.package-archive");i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);installLaunched=true;if(d!=null)d.dismiss();a.startActivity(i);
    }
}
