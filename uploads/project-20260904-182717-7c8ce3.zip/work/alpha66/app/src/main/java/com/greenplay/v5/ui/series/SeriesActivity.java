package com.greenplay.v5.ui.series;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.greenplay.v5.core.catalog.CatalogCoverWarmer;
import com.greenplay.v5.core.catalog.CatalogMemory;
import com.greenplay.v5.core.config.AppControlStore;
import com.greenplay.v5.core.config.NavConfigUi;
import com.greenplay.v5.core.config.AppNoticeUi;
import com.greenplay.v5.core.config.AppControlSync;
import com.greenplay.v5.core.config.BrandingStore;
import com.greenplay.v5.core.config.BrandingUi;
import com.greenplay.v5.core.session.SessionStore;
import com.greenplay.v5.data.model.series.SeriesCategory;
import com.greenplay.v5.data.model.series.SeriesItem;
import com.greenplay.v5.data.repository.SeriesRepository;
import com.greenplay.v5.databinding.ActivitySeriesBinding;
import com.greenplay.v5.ui.movies.MovieActivity;
import com.greenplay.v5.ui.settings.SettingsActivity;
import com.greenplay.v5.ui.tv.TvActivity;
import com.squareup.picasso.Target;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class SeriesActivity extends AppCompatActivity {
    private static final int PAGE_SIZE = 180;
    private static final int PREFETCH = 36;

    private ActivitySeriesBinding b;
    private SessionStore session;
    private BrandingStore branding;
    private AppControlStore control;
    private Target backgroundTarget;
    private SeriesRepository repo;
    private SeriesCacheStore cache;
    private SeriesCategoryAdapter categories;
    private SeriesAdapter adapter;
    private GridLayoutManager grid;

    private volatile List<SeriesItem> all = Collections.emptyList();
    private final List<SeriesItem> filtered = new ArrayList<>();
    private String categoryId = "";
    private String query = "";
    private int rendered = 0;
    private int generation = 0;
    private int requestGeneration = 0;
    private boolean loading = false;
    private boolean networkCatalogComplete = false;
    private boolean usingNetworkPreview = false;

    private final ExecutorService filter = Executors.newSingleThreadExecutor();
    private final ExecutorService cacheExecutor = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Runnable delayedSearch = this::rebuild;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        b = ActivitySeriesBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        com.greenplay.v5.core.ui.UniversalUi.apply(this, b.getRoot());
        session = new SessionStore(this);
        if (!session.isLogged() || session.host().trim().isEmpty()) { finish(); return; }

        branding = new BrandingStore(this);
        control = new AppControlStore(this);
        repo = new SeriesRepository(session.host(), session.user(), session.pass());
        cache = new SeriesCacheStore(this, session.host(), session.user());

        applyBranding();
        setup();
        bindNav();
        AppNoticeUi.show(this, control);
        AppControlSync.refresh(this, ok -> runOnUiThread(() -> {
            if (ok && !isFinishing()) {
                branding = new BrandingStore(this);
                control = new AppControlStore(this);
                applyBranding();
                applySectionVisibility();
                AppNoticeUi.show(this, control);
            }
        }));

        boolean preloaded = showPreloadedSeries();
        if (!preloaded) loadCachedSeries();
        loadCategories();
        if (preloaded) main.postDelayed(() -> loadSeries(false), 8000L);
        else loadSeries(true);
    }

    private void applyBranding() {
        BrandingUi.applyHeaderBrand(b.brandNameSeries, b.brandLogoSeries, branding);
        backgroundTarget = BrandingUi.applyBackground(b.getRoot(), branding);
        if (adapter != null) {
            String fallback = branding.seriesCover();
            if (fallback == null || fallback.trim().isEmpty()) fallback = branding.fallback();
            adapter.setFallback(branding.absolute(fallback));
        }
    }

    private void setup() {
        categories = new SeriesCategoryAdapter(c -> {
            categoryId = c.id == null ? "" : c.id;
            categories.select(categoryId);
            rebuild();
        });
        b.seriesCategories.setLayoutManager(new LinearLayoutManager(this));
        b.seriesCategories.setAdapter(categories);
        b.seriesCategories.setItemAnimator(null);

        adapter = new SeriesAdapter(this::openDetail);
        String seriesFallback = branding.seriesCover();
        if (seriesFallback == null || seriesFallback.trim().isEmpty()) seriesFallback = branding.fallback();
        adapter.setFallback(branding.absolute(seriesFallback));

        grid = new GridLayoutManager(this, 6);
        b.seriesGrid.setLayoutManager(grid);
        b.seriesGrid.setAdapter(adapter);
        b.seriesGrid.setItemAnimator(null);
        b.seriesGrid.setHasFixedSize(true);
        b.seriesGrid.setItemViewCacheSize(18);
        b.seriesGrid.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override public void onScrolled(RecyclerView rv, int dx, int dy) {
                if (dy > 0 && rendered < filtered.size() && grid.findLastVisibleItemPosition() >= adapter.getItemCount() - PREFETCH) append();
            }
        });

        b.seriesSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int st, int before, int count) {
                query = s == null ? "" : s.toString().trim();
                main.removeCallbacks(delayedSearch);
                main.postDelayed(delayedSearch, 180L);
            }
            @Override public void afterTextChanged(Editable e) {}
        });
    }

    private void bindNav() {
        b.navTv.setOnClickListener(v -> startActivity(new Intent(this, TvActivity.class)));
        b.navMovies.setOnClickListener(v -> startActivity(new Intent(this, MovieActivity.class)));
        b.navSeries.setOnClickListener(v -> b.seriesSearch.requestFocus());
        b.navFootball.setOnClickListener(v -> startActivity(new Intent(this, com.greenplay.v5.ui.games.GamesActivity.class)));
        b.navKids.setOnClickListener(v -> pending("KIDS"));
        b.navAnime.setOnClickListener(v -> pending("ANIME"));
        b.navHot.setOnClickListener(v -> pending("HOT"));
        b.seriesSettings.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        applySectionVisibility();
    }

    private void applySectionVisibility() {
        NavConfigUi.apply(control,
                NavConfigUi.e("tv", b.navTv, 10), NavConfigUi.e("football", b.navFootball, 20),
                NavConfigUi.e("movies", b.navMovies, 30), NavConfigUi.e("series", b.navSeries, 40),
                NavConfigUi.e("kids", b.navKids, 50), NavConfigUi.e("anime", b.navAnime, 60),
                NavConfigUi.e("hot", b.navHot, 70));
    }

    private boolean showPreloadedSeries() {
        List<SeriesItem> prepared = CatalogMemory.series();
        if (prepared.isEmpty()) return false;
        all = prepared;
        b.seriesLoading.setVisibility(View.GONE);
        b.seriesError.setText("");
        rebuild();
        warmSeriesArtwork(prepared, true);
        return true;
    }

    private void loadCachedSeries() {
        cacheAsync(() -> {
            final List<SeriesCategory> cachedCategories = cache.categories();
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed() || networkCatalogComplete) return;
                if (!cachedCategories.isEmpty()) categories.submit(cachedCategories, categoryId);
            });

            // Reading/parsing the cached catalog is much heavier than reading
            // its small category list. Publish categories immediately instead
            // of making the sidebar wait for the entire series cache.
            final List<SeriesItem> cachedSeries = cache.series();
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed() || networkCatalogComplete) return;
                if (!cachedSeries.isEmpty() && (all.isEmpty() || usingNetworkPreview || cachedSeries.size() > all.size())) {
                    usingNetworkPreview = false;
                    all = cachedSeries;
                    CatalogMemory.setSeries(cachedSeries);
                    b.seriesLoading.setVisibility(View.GONE);
                    b.seriesError.setText("");
                    rebuild();
                    warmSeriesArtwork(cachedSeries, false);
                }
            });
        });
    }

    private void loadCategories() {
        repo.categories(new SeriesRepository.CategoriesResult() {
            @Override public void success(List<SeriesCategory> rows) {
                runOnUiThread(() -> categories.submit(rows, categoryId));
                cacheAsync(() -> cache.saveCategories(rows));
            }
            @Override public void error(String m) { }
        });
    }

    private void loadSeries(boolean showSpinner) {
        final int request = ++requestGeneration;
        loading = true;
        networkCatalogComplete = false;
        if (showSpinner && all.isEmpty()) {
            b.seriesLoading.setVisibility(View.GONE);
            main.postDelayed(() -> {
                if (loading && all.isEmpty() && !isFinishing() && !isDestroyed()) b.seriesLoading.setVisibility(View.VISIBLE);
            }, 350L);
        }
        b.seriesError.setText("");

        repo.seriesProgressive("", 24, 240, new SeriesRepository.ProgressiveSeriesResult() {
            @Override public void partial(List<SeriesItem> rows) {
                if (request != requestGeneration || rows == null || rows.isEmpty()) return;
                if (all.isEmpty() || usingNetworkPreview) {
                    usingNetworkPreview = true;
                    all = rows;
                    CatalogMemory.setSeries(rows);
                    b.seriesLoading.setVisibility(View.GONE);
                    rebuild();
                    warmSeriesArtwork(rows, true);
                }
            }

            @Override public void success(List<SeriesItem> rows) {
                if (request != requestGeneration) return;
                loading = false;
                networkCatalogComplete = true;
                usingNetworkPreview = false;
                b.seriesLoading.setVisibility(View.GONE);
                all = rows == null ? Collections.emptyList() : rows;
                CatalogMemory.setSeries(all);
                rebuild();
                final List<SeriesItem> saveRows = all;
                cacheAsync(() -> cache.saveSeries(saveRows));
                warmSeriesArtwork(all, false);
            }

            @Override public void error(String m) {
                if (request != requestGeneration) return;
                loading = false;
                b.seriesLoading.setVisibility(View.GONE);
                if (all.isEmpty()) b.seriesError.setText(m);
            }
        });
    }

    private void rebuild() {
        final int g = ++generation;
        final List<SeriesItem> snap = all;
        final String cat = categoryId;
        final String q = query.toLowerCase(Locale.ROOT);
        filter.execute(() -> {
            ArrayList<SeriesItem> out = new ArrayList<>();
            for (SeriesItem x : snap) {
                if (x == null) continue;
                if (cat != null && !cat.isEmpty() && !cat.equals(x.categoryId)) continue;
                if (!q.isEmpty() && (x.name == null || !x.name.toLowerCase(Locale.ROOT).contains(q))) continue;
                out.add(x);
            }
            runOnUiThread(() -> {
                if (g != generation || isFinishing() || isDestroyed()) return;
                filtered.clear();
                filtered.addAll(out);
                rendered = Math.min(PAGE_SIZE, filtered.size());
                adapter.submit(rendered == 0 ? Collections.emptyList() : new ArrayList<>(filtered.subList(0, rendered)));
                b.seriesEmpty.setVisibility(filtered.isEmpty() && !loading ? View.VISIBLE : View.GONE);
                if (grid != null) grid.scrollToPosition(0);
            });
        });
    }

    private void append() {
        int end = Math.min(filtered.size(), rendered + PAGE_SIZE);
        if (end <= rendered) return;
        rendered = end;
        adapter.submit(new ArrayList<>(filtered.subList(0, rendered)));
    }

    private void warmSeriesArtwork(List<SeriesItem> rows, boolean priorityOnly) {
        if (rows == null || rows.isEmpty()) return;
        ArrayList<String> urls = new ArrayList<>();
        int max = priorityOnly ? Math.min(96, rows.size()) : Math.min(360, rows.size());
        for (int i = 0; i < max; i++) {
            SeriesItem x = rows.get(i);
            if (x != null && x.cover != null && !x.cover.trim().isEmpty()) urls.add(x.cover);
        }
        if (urls.isEmpty()) return;
        if (priorityOnly) CatalogCoverWarmer.warmPriority(urls, 96, null);
        else CatalogCoverWarmer.enqueue(urls);
    }

    private void cacheAsync(Runnable task) {
        try {
            if (!cacheExecutor.isShutdown()) cacheExecutor.execute(task);
        } catch (RuntimeException ignored) { }
    }

    private void openDetail(SeriesItem x) {
        Intent i = new Intent(this, SeriesDetailActivity.class);
        i.putExtra("id", x.id);
        i.putExtra("name", x.name);
        i.putExtra("cover", x.cover);
        i.putExtra("year", x.year);
        i.putExtra("rating", x.rating);
        if (x.alternateIds != null && !x.alternateIds.isEmpty()) {
            long[] ids = new long[x.alternateIds.size()];
            for (int p = 0; p < ids.length; p++) ids[p] = x.alternateIds.get(p);
            i.putExtra("alternate_ids", ids);
        }
        startActivity(i);
    }

    private void pending(String n) {
        Toast.makeText(this, n + " será aberto no módulo próprio", Toast.LENGTH_SHORT).show();
    }

    @Override protected void onDestroy() {
        main.removeCallbacksAndMessages(null);
        generation++;
        requestGeneration++;
        filter.shutdownNow();
        cacheExecutor.shutdownNow();
        super.onDestroy();
    }
}
