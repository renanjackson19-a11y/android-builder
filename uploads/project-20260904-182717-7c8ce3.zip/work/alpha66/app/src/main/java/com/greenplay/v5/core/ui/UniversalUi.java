package com.greenplay.v5.core.ui;

import android.app.Activity;
import android.app.UiModeManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.view.View;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;

/**
 * Common screen handling for phones, tablets, TV Box, Android TV/Google TV,
 * Fire TV-compatible Android devices and Android projectors.
 * Keeps content inside system/cutout safe areas without drawing an in-app back button.
 */
public final class UniversalUi {
    private UniversalUi() {}

    public static void apply(Activity activity, View root) {
        if (activity == null || root == null) return;
        WindowCompat.setDecorFitsSystemWindows(activity.getWindow(), false);
        // The app is landscape-only and its screens already provide their own
        // content spacing. Applying navigation-bar/cutout insets to the root
        // also moves full-screen backgrounds, creating a large empty strip on
        // phones that keep the gesture bar on one side after rotation.
        // Keep the root edge-to-edge; individual controls remain padded by
        // their layouts.
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> insets);
        ViewCompat.requestApplyInsets(root);
    }

    public static boolean isTv(Context context) {
        if (context == null) return false;
        PackageManager pm = context.getPackageManager();
        if (pm.hasSystemFeature(PackageManager.FEATURE_LEANBACK)) return true;
        UiModeManager ui = (UiModeManager) context.getSystemService(Context.UI_MODE_SERVICE);
        return ui != null && ui.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION;
    }
}
