package com.ativacao.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

/** Returns the user to the activator after UniTV is installed or updated. */
public final class UnitvInstalledReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || intent.getData() == null) return;
        String packageName = intent.getData().getSchemeSpecificPart();
        if (!"com.integration.unitvsiptv".equals(packageName)) return;
        SharedPreferences prefs = context.getSharedPreferences("ativador_prefs", Context.MODE_PRIVATE);
        prefs.edit().putBoolean("unitv_instalacao_pendente", false)
                .putBoolean("unitv_permissao_todos_arquivos_pendente", true).apply();
        try {
            Intent voltar = new Intent(context, MainActivity.class);
            voltar.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            context.startActivity(voltar);
        } catch (Throwable ignored) {}
    }
}
