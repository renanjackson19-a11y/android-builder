package com.ativacao.app;

/** Endpoints exclusivos do painel NEXO novo. O painel antigo não é usado como fallback. */
public final class Config {
    public static final String BASE_URL = "https://dubaiativa.site";
    public static final String[] BASE_URLS = new String[] { BASE_URL };
    public static final String API_ATIVAR = BASE_URL + "/api/ativar.php";
    public static final String API_APP_CONFIG = BASE_URL + "/api/app_config.php";
    public static final String API_ATIVADOR_UPDATE = BASE_URL + "/api/ativador_update.php";
    // O painel NEXO atual ainda não disponibiliza api/suporte_app.php.
    // A tela de suporte remoto não é ligada a nenhum painel legado.
    public static final String API_SUPORTE = BASE_URL + "/api/suporte_app.php";
    public static final String PASTA_ALTERNATIVA = "Android/data/com.ativacao.app.teste/files";
    public static final String NOME_CONFIG_FINAL = ".config";
    public static final String NOME_PROPERTIES_FINAL = ".properties";
    public static final String NOME_APK_FINAL = "unitvfree.apk";
    private Config() {}
}
