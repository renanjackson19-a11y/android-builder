package com.dubaidigital.tv;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

public class MainActivity extends Activity {
  private WebView w, gamesWeb;
  private FrameLayout root;
  private PlayerView playerView;
  private ExoPlayer player;
  private int generation = 0;
  private String fallbackUrl = "";
  private FrameLayout.LayoutParams videoLayout;

  public class Bridge {
    @JavascriptInterface public void openGames(){runOnUiThread(() -> {
      if(gamesWeb != null) return;
      gamesWeb = new WebView(MainActivity.this);
      gamesWeb.getSettings().setJavaScriptEnabled(true);
      gamesWeb.getSettings().setDomStorageEnabled(true);
      gamesWeb.setWebViewClient(new WebViewClient());
      gamesWeb.setWebChromeClient(new WebChromeClient());
      root.addView(gamesWeb,new FrameLayout.LayoutParams(-1,-1));
      gamesWeb.loadUrl("https://gerenciapro.top/sport.php");
    });}
    @JavascriptInterface public void closeGames(){runOnUiThread(() -> closeGamesPage());}
    @JavascriptInterface public void stop(){runOnUiThread(() -> {generation++;stopPlayer();});}
    @JavascriptInterface public void playAtFallback(String url,String backup,int x,int y,int width,int height,int viewportWidth){
      runOnUiThread(() -> startAt(url,backup,x,y,width,height,viewportWidth));
    }
    @JavascriptInterface public void playAt(String url,int x,int y,int width,int height,int viewportWidth){
      runOnUiThread(() -> startAt(url,"",x,y,width,height,viewportWidth));
    }
    @JavascriptInterface public void play(String url){runOnUiThread(() -> startFull(url));}
  }

  @Override public void onCreate(Bundle b){
    super.onCreate(b);
    getWindow().getDecorView().setSystemUiVisibility(5894|1024|512);
    root=new FrameLayout(this);
    w=new WebView(this);
    w.setBackgroundColor(0xff0c0d12);
    w.getSettings().setJavaScriptEnabled(true);
    w.getSettings().setDomStorageEnabled(true);
    w.addJavascriptInterface(new Bridge(),"NativePlayer");
    w.setWebChromeClient(new WebChromeClient());
    w.setWebViewClient(new WebViewClient());
    w.setFocusable(true);w.setFocusableInTouchMode(true);
    root.addView(w);setContentView(root);
    w.loadUrl("file:///android_asset/index.html");
  }

  private void startAt(String url,String backup,int x,int y,int width,int height,int viewportWidth){
    float scale=(float)w.getWidth()/Math.max(1,viewportWidth);
    FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(Math.max(1,Math.round(width*scale)),Math.max(1,Math.round(height*scale)));
    lp.leftMargin=Math.round(x*scale);lp.topMargin=Math.round(y*scale);
    startNew(url,backup,lp);
  }
  private void startFull(String url){startNew(url,"",new FrameLayout.LayoutParams(-1,-1));}
  private void startNew(String url,String backup,FrameLayout.LayoutParams lp){
    generation++;
    fallbackUrl=backup==null?"":backup;
    videoLayout=lp;
    stopPlayer();
    if(!valid(url)){Toast.makeText(this,"URL do canal inválida",Toast.LENGTH_LONG).show();return;}
    playAttempt(url,generation,false);
  }
  private boolean valid(String url){return url!=null&&(url.startsWith("http://")||url.startsWith("https://"));}
  private void playAttempt(String url,int request,boolean isFallback){
    if(request!=generation)return;
    stopPlayer();
    player=new ExoPlayer.Builder(this).build();
    playerView=new PlayerView(this);
    playerView.setUseController(false);
    playerView.setPlayer(player);
    root.addView(playerView,videoLayout);
    final ExoPlayer current=player;
    player.addListener(new Player.Listener(){
      @Override public void onPlayerError(PlaybackException error){
        if(request!=generation||player!=current)return;
        String backup=fallbackUrl;
        fallbackUrl="";
        if(!isFallback&&valid(backup)&&!backup.equals(url)){
          playAttempt(backup,request,true);
        } else {
          android.util.Log.e("ResellerPlayback","Falha na fonte: "+url+" / "+error.errorCodeName,error);
          Toast.makeText(MainActivity.this,"Falha no canal: "+error.errorCodeName,Toast.LENGTH_LONG).show();
        }
      }
    });
    MediaItem.Builder item=new MediaItem.Builder().setUri(Uri.parse(url));
    String path=Uri.parse(url).getPath();
    if(path!=null){
      String p=path.toLowerCase(java.util.Locale.ROOT);
      if(p.endsWith(".m3u8"))item.setMimeType(MimeTypes.APPLICATION_M3U8);
      else if(p.endsWith(".mpd"))item.setMimeType(MimeTypes.APPLICATION_MPD);
    }
    player.setMediaItem(item.build());
    player.prepare();
    player.setPlayWhenReady(true);
  }
  private void stopPlayer(){
    if(playerView!=null){playerView.setPlayer(null);root.removeView(playerView);playerView=null;}
    if(player!=null){player.release();player=null;}
  }
  private void closeGamesPage(){if(gamesWeb!=null){root.removeView(gamesWeb);gamesWeb.destroy();gamesWeb=null;w.requestFocus();}}
  @Override public void onBackPressed(){
    if(gamesWeb!=null){closeGamesPage();return;}
    if(player!=null){generation++;stopPlayer();w.requestFocus();}
    else w.evaluateJavascript("window.appBack && window.appBack()",null);
  }
  @Override protected void onDestroy(){generation++;stopPlayer();if(gamesWeb!=null)closeGamesPage();w.destroy();super.onDestroy();}
}
