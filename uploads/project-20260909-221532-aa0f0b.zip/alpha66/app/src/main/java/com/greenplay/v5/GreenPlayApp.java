package com.greenplay.v5;

import android.app.Application;
import com.greenplay.v5.core.config.BrandingStore;
import com.greenplay.v5.core.config.ServerDirectoryStore;
import com.greenplay.v5.core.network.NetworkProvider;
import com.greenplay.v5.data.model.AppConfigResponse;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public final class GreenPlayApp extends Application {
    private static final java.util.concurrent.ExecutorService APP_IO = java.util.concurrent.Executors.newSingleThreadExecutor();
    @Override public void onCreate() {
        super.onCreate();
        NetworkProvider.init(this);
        // Atualiza identidade e lista de servidores sem bloquear a abertura do app.
        NetworkProvider.panel().appConfig().enqueue(new Callback<AppConfigResponse>() {
            @Override public void onResponse(Call<AppConfigResponse> call, Response<AppConfigResponse> response) {
                AppConfigResponse cfg = response.body();
                if (!response.isSuccessful() || cfg == null || !cfg.ok) return;
                APP_IO.execute(() -> {
                    if (cfg.branding != null) new BrandingStore(GreenPlayApp.this).save(cfg.branding);
                    if (cfg.universal != null && cfg.universal.servers != null) new ServerDirectoryStore(GreenPlayApp.this).save(cfg.universal.servers);
                });
            }
            @Override public void onFailure(Call<AppConfigResponse> call, Throwable t) { }
        });
    }
}
