package com.greenplay.v5.core.catalog;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import com.greenplay.v5.core.ui.SpecialSections;
import com.greenplay.v5.data.model.movie.Movie;
import com.greenplay.v5.data.model.series.SeriesItem;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * V5.0.141 — snapshot pequeno e persistente dos catálogos especiais.
 *
 * A abertura rápida da V139 deixou KIDS/ANIMES dependentes da reidratação do
 * catálogo bruto (Filmes/Séries), que pode levar vários segundos em TV Box.
 * Aqui guardamos apenas o índice pronto + 12 destaques. Isso permite reconstruir
 * a landing instantaneamente sem voltar a ler milhares de registros na frente.
 */
public final class SpecialCatalogScopeStore {
    private static final String PREF = "green_play_v5_special_scope_cache_v141";
    private final SharedPreferences prefs;
    private final Gson gson = new Gson();
    private final String scopeKey;

    private static final class CatDto {
        String id = "";
        String name = "";
    }

    private static final class Snapshot {
        String mode = "";
        long savedAt = 0L;
        List<Long> movieIds = new ArrayList<>();
        List<Long> seriesIds = new ArrayList<>();
        List<CatDto> movieCategories = new ArrayList<>();
        List<CatDto> seriesCategories = new ArrayList<>();
        List<Movie> moviePreview = new ArrayList<>();
        List<SeriesItem> seriesPreview = new ArrayList<>();
    }

    public SpecialCatalogScopeStore(Context context, String host, String user) {
        prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        scopeKey = Integer.toHexString(((host == null ? "" : host.trim()) + "|" +
                (user == null ? "" : user.trim())).hashCode());
    }

    private String key(String mode) { return scopeKey + "_" + (mode == null ? "" : mode); }

    public void saveCurrent() {
        save(SpecialSections.KIDS, SpecialCatalogIndex.cachedScope(SpecialSections.KIDS));
        save(SpecialSections.ANIME, SpecialCatalogIndex.cachedScope(SpecialSections.ANIME));
    }

    public void save(String mode, SpecialCatalogIndex.Scope scope) {
        if (!SpecialCatalogIndex.hasContent(scope)) return;
        Snapshot dto = new Snapshot();
        dto.mode = mode == null ? "" : mode;
        dto.savedAt = System.currentTimeMillis();
        dto.movieIds.addAll(scope.movieIds);
        dto.seriesIds.addAll(scope.seriesIds);
        for (SpecialCatalogIndex.CategoryRow c : scope.movieCategories) {
            if (c == null) continue;
            CatDto x = new CatDto(); x.id = c.id; x.name = c.name; dto.movieCategories.add(x);
        }
        for (SpecialCatalogIndex.CategoryRow c : scope.seriesCategories) {
            if (c == null) continue;
            CatDto x = new CatDto(); x.id = c.id; x.name = c.name; dto.seriesCategories.add(x);
        }
        dto.moviePreview.addAll(scope.moviePreview);
        dto.seriesPreview.addAll(scope.seriesPreview);
        try { prefs.edit().putString(key(mode), gson.toJson(dto)).apply(); }
        catch (Exception ignored) { }
    }

    public SpecialCatalogIndex.Scope load(String mode) {
        try {
            String raw = prefs.getString(key(mode), "");
            if (raw == null || raw.trim().isEmpty()) return null;
            Snapshot dto = gson.fromJson(raw, Snapshot.class);
            if (dto == null) return null;
            Set<Long> movieIds = dto.movieIds == null ? new HashSet<>() : new HashSet<>(dto.movieIds);
            Set<Long> seriesIds = dto.seriesIds == null ? new HashSet<>() : new HashSet<>(dto.seriesIds);
            List<SpecialCatalogIndex.CategoryRow> movieCats = new ArrayList<>();
            if (dto.movieCategories != null) for (CatDto c : dto.movieCategories) {
                if (c != null) movieCats.add(new SpecialCatalogIndex.CategoryRow(c.id, c.name));
            }
            List<SpecialCatalogIndex.CategoryRow> seriesCats = new ArrayList<>();
            if (dto.seriesCategories != null) for (CatDto c : dto.seriesCategories) {
                if (c != null) seriesCats.add(new SpecialCatalogIndex.CategoryRow(c.id, c.name));
            }
            SpecialCatalogIndex.Scope restored = SpecialCatalogIndex.fromSnapshot(
                    mode, movieIds, seriesIds, movieCats, seriesCats,
                    dto.moviePreview, dto.seriesPreview);
            return SpecialCatalogIndex.hasContent(restored) ? restored : null;
        } catch (Exception ignored) { return null; }
    }

    /** Publica os snapshots salvos sem varrer Filmes/Séries. */
    public boolean restoreIntoIndex() {
        boolean any = false;
        for (String mode : new String[]{SpecialSections.KIDS, SpecialSections.ANIME}) {
            SpecialCatalogIndex.Scope s = load(mode);
            if (SpecialCatalogIndex.hasContent(s)) {
                SpecialCatalogIndex.publishScope(mode, s);
                any = true;
            }
        }
        return any;
    }
}
