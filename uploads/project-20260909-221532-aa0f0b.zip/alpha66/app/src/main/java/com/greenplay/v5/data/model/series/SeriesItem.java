package com.greenplay.v5.data.model.series;

import java.util.ArrayList;
import java.util.List;

public final class SeriesItem {
    public long id;
    public String name = "";
    public String cover = "";
    public String categoryId = "";
    /** All Xtream category IDs merged from duplicate records; categoryId remains the primary ID for normal catalog filters. */
    public String allCategoryIds = "";
    public String year = "";
    public String rating = "";
    /** Optional age/content classification published by Xtream/custom providers (e.g. Livre, 10, TV-Y7, TV-14). */
    public String contentRating = "";
    /** Metadata published by get_series when available; used by special sections without opening every detail page. */
    public String plot = "";
    public String genre = "";
    public boolean isAdult = false;
    /** Optional backend classification fields (when present in the Xtream/custom payload). */
    public String mediaType = "";
    public String vodType = "";
    public String filterType = "";
    /** Other Xtream records that represent the same title/year. */
    public List<Long> alternateIds = new ArrayList<>();
}
