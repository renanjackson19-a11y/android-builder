package com.greenplay.v5.ui.tv;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import com.greenplay.v5.data.model.tv.TvChannel;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

final class TvHistoryStore {
    private static final String PREF = "green_play_v5_tv";
    private static final String FAVORITES = "favorite_ids";
    private static final String RECENTS = "recent_ids";
    private final SharedPreferences prefs;
    private final Set<String> favoriteCache = new LinkedHashSet<>();
    private final List<String> recentCache = new ArrayList<>();

    TvHistoryStore(Context context) {
        prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        Set<String> fav = prefs.getStringSet(FAVORITES, null);
        if (fav != null) favoriteCache.addAll(fav);
        String ordered = prefs.getString(RECENTS + "_ordered", "");
        if (ordered != null && !ordered.trim().isEmpty()) {
            for (String id : ordered.split(",")) if (!id.trim().isEmpty()) recentCache.add(id.trim());
        }
    }

    boolean isFavorite(long id) {
        return favoriteCache.contains(String.valueOf(id));
    }

    void toggleFavorite(long id) {
        String key = String.valueOf(id);
        if (!favoriteCache.add(key)) favoriteCache.remove(key);
        prefs.edit().putStringSet(FAVORITES, new LinkedHashSet<>(favoriteCache)).apply();
    }

    void markRecent(long id) {
        String key = String.valueOf(id);
        recentCache.remove(key);
        recentCache.add(0, key);
        while (recentCache.size() > 30) recentCache.remove(recentCache.size()-1);
        List<String> snapshot = new ArrayList<>(recentCache);
        prefs.edit().putString(RECENTS + "_ordered", TextUtils.join(",", snapshot)).apply();
        prefs.edit().putStringSet(RECENTS, new LinkedHashSet<>(snapshot)).apply();
    }

    List<TvChannel> filterFavorites(List<TvChannel> source) {
        List<TvChannel> out = new ArrayList<>();
        for (TvChannel c : source) if (favoriteCache.contains(String.valueOf(c.id))) out.add(c);
        return out;
    }

    List<TvChannel> filterRecents(List<TvChannel> source) {
        List<TvChannel> out = new ArrayList<>();
        if (recentCache.isEmpty()) return out;
        java.util.HashMap<String,TvChannel> byId = new java.util.HashMap<>();
        for (TvChannel c : source) byId.put(String.valueOf(c.id), c);
        for (String id : recentCache) {
            TvChannel c = byId.get(id);
            if (c != null) out.add(c);
        }
        return out;
    }
}
