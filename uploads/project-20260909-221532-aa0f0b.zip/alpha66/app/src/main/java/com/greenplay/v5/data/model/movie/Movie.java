package com.greenplay.v5.data.model.movie;

public final class Movie {
    public long id;
    public String name = "";
    public String poster = "";
    public String categoryId = "";
    /** All Xtream category IDs merged from duplicate records; categoryId remains the primary ID for normal catalog filters. */
    public String allCategoryIds = "";
    public String extension = "mp4";
    public String year = "";
    public String rating = "";
    /** Optional age/content classification from Xtream/custom providers (Livre, TV-Y7, 10, etc.). */
    public String contentRating = "";
    /** Lightweight metadata returned by get_vod_streams on many Xtream forks. */
    public String genre = "";
    public String plot = "";
    /** Optional origin metadata used only as a generic ANIME fallback when the provider exposes it. */
    public String originalLanguage = "";
    public String country = "";
    public String directSource = "";
    /** Xtream is_adult flag, kept for the dedicated HOT catalog only. */
    public boolean isAdult = false;
    /** Optional backend classification fields (Velox-style when the server exposes them). */
    public String mediaType = "";
    public String vodType = "";
    public String filterType = "";
}
