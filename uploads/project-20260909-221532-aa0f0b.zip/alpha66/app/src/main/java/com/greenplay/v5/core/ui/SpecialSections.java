package com.greenplay.v5.core.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.text.InputType;
import android.widget.EditText;
import android.widget.Toast;
import com.greenplay.v5.core.session.SessionStore;
import com.greenplay.v5.ui.special.SpecialCatalogActivity;
import com.greenplay.v5.data.model.series.SeriesItem;
import java.text.Normalizer;
import java.util.Locale;

/** Shared navigation/filter rules for the dedicated KIDS, ANIME and HOT sections. */
public final class SpecialSections {
    public static final String EXTRA_MODE = "special_mode";
    public static final String KIDS = "kids";
    public static final String ANIME = "anime";
    public static final String HOT = "hot";

    private SpecialSections() {}

    public static boolean valid(String mode) {
        return KIDS.equals(mode) || ANIME.equals(mode) || HOT.equals(mode);
    }

    public static String label(String mode) {
        if (KIDS.equals(mode)) return "KIDS";
        if (ANIME.equals(mode)) return "ANIMES";
        if (HOT.equals(mode)) return "HOT";
        return "";
    }

    /**
     * V5.0.116 — regras genéricas por categoria. Não dependem de um servidor,
     * fornecedor ou título específico. Separadores, emojis e prefixos como
     * "FILMES | KIDS" / "SÉRIES - ANIMES" são normalizados antes da comparação.
     */
    public static boolean matches(String mode, String categoryName) {
        if (!valid(mode)) return true;
        if (KIDS.equals(mode)) return isKidsCategoryName(categoryName);
        if (ANIME.equals(mode)) return isAnimeCategoryName(categoryName);
        return isHotCategoryName(categoryName);
    }

    public static boolean isKidsCategoryName(String raw) {
        String original = raw == null ? "" : raw.toLowerCase(Locale.ROOT);
        if (original.contains("🔞") || original.contains("+18") || original.contains("18+")) return false;
        String n = " " + normalizeCategory(raw) + " ";
        if (n.trim().isEmpty() || " todos ".equals(n)) return false;

        // V5.0.129: não deixa ANIME/HOT cair em KIDS quando o servidor usa nomes amplos.
        if (has(n,
                " anime ", " animes ", " manga ", " shonen ", " shoujo ", " shojo ", " seinen ", " isekai ", " hentai ", " ecchi ",
                " hot ", " adult ", " adults ", " adulto ", " adultos ", " xxx ", " porno ", " porn ",
                " erotico ", " erotica ", " sexy ", " sex ", " 18 plus ", " plus 18 ")) return false;

        // Alguns Xtreams não chamam a pasta de KIDS; usam apenas ANIMAÇÃO/FAMÍLIA/
        // INFANTO-JUVENIL ou a marca infantil (Disney/Nick/etc.). Esses nomes agora
        // contam como KIDS sem depender de um fornecedor específico.
        return has(n,
                " kids ", " kid ", " infantil ", " infantis ", " crianca ", " criancas ",
                " infanto juvenil ", " infantojuvenil ", " juvenil ",
                " desenho ", " desenhos ", " cartoon ", " cartoons ", " baby ", " bebe ",
                " children ", " childrens ", " child ", " preschool ", " pre school ",
                " animacao ", " animacoes ", " animation ", " animations ", " animated ", " animado ", " animados ", " familia ", " family ", " familiar ",
                " educativo ", " educativos ", " educacao ", " educational ",
                " discovery kids ", " cartoon network ", " disney ", " disney junior ", " disney channel ",
                " pixar ", " dreamworks ", " illumination ",
                " nickelodeon ", " nick ", " nick jr ", " nick junior ", " gloob ", " gloobinho ",
                " boomerang ", " tooncast ", " cartoonito ", " pbs kids ", " family kids ",
                " animacao infantil ", " animation kids ");
    }

    public static boolean isAnimeCategoryName(String raw) {
        String n = " " + normalizeCategory(raw) + " ";
        if (n.trim().isEmpty() || " todos ".equals(n)) return false;
        return has(n,
                " anime ", " animes ", " otaku ", " manga ", " shonen ", " shoujo ", " shojo ",
                " seinen ", " isekai ", " animacao japonesa ", " japanese animation ",
                " crunchyroll ", " crunchy roll ", " funimation ", " hidive ",
                " anime onegai ", " retrocrush ", " aniplus ");
    }

    public static boolean isHotCategoryName(String raw) {
        String original = raw == null ? "" : raw.toLowerCase(Locale.ROOT);
        if (original.contains("🔞") || original.contains("+18") || original.contains("18+")) return true;
        String n = " " + normalizeCategory(raw) + " ";
        if (n.trim().isEmpty() || " todos ".equals(n)) return false;
        // HOT: somente sinais adultos explícitos.
        // Não usar palavras genéricas como "privacy/privacidade" e não analisar
        // título de conteúdo aqui: a classificação vem da categoria/flag estrutural.
        return has(n,
                " hot ", " adult ", " adults ", " adulto ", " adultos ", " adulta ", " adultas ",
                " adulte ", " adultes ", " adulti ", " erwachsene ",
                " conteudo adulto ", " conteudos adultos ", " contenido adulto ", " contenidos adultos ",
                " para adultos ", " solo adultos ", " adults only ", " adult only ",
                " conteudo 18 ", " conteudo +18 ", " contenido 18 ", " 18 anos ", " 18 plus ", " plus 18 ",
                " maior de idade ", " maiores de idade ", " maiores de 18 ", " maioridade ",
                " mayor de edad ", " mayores de edad ", " mayores de 18 ",
                " xxx ", " x-rated ", " x rated ", " xrated ",
                " erotico ", " erotica ", " eroticos ", " eroticas ", " erotic ", " erotics ",
                " erotique ", " erotiques ", " erotici ",
                " porno ", " porn ", " pornografia ", " pornografico ", " pornografica ",
                " pornography ", " pornographic ",
                " mature ", " mature content ", " contenido maduro ",
                " adult content ", " adult vod ", " adult movies ", " adult series ",
                " filmes adultos ", " series adultas ", " peliculas adultas ",
                " playboy ", " onlyfans ", " only fans ",
                " prive ", " privê ", " private adult ", " redlight ", " red light ");
    }

    /**
     * Fallback apenas por metadados estruturais de série. Não usa título nem sinopse
     * para decidir a seção; isso evita depender de nomes específicos de conteúdo.
     */
    public static boolean matchesSeriesItem(String mode, String categoryName, SeriesItem item) {
        if (!valid(mode) || item == null) return !valid(mode);
        if (matches(mode, categoryName)) return true;
        if (HOT.equals(mode)) return item.isAdult || isHotCategoryName(item.mediaType)
                || isHotCategoryName(item.vodType) || isHotCategoryName(item.filterType);

        String genre = " " + normalizeCategory(item.genre) + " ";
        if (ANIME.equals(mode)) {
            return has(genre,
                    " anime ", " manga ", " otaku ", " japanese animation ",
                    " animacao japonesa ", " shonen ", " shoujo ", " shojo ",
                    " seinen ", " isekai ");
        }

        boolean directKids = has(genre,
                " kids ", " kid ", " children ", " childrens ", " child ",
                " infantil ", " infantis ", " infanto juvenil ", " infantojuvenil ",
                " preschool ", " pre school ", " educativo ", " educational ");
        boolean animation = has(genre,
                " animation ", " animations ", " animacao ", " animacoes ", " animated ", " animado ", " animados ", " cartoon ", " cartoons ");
        boolean family = has(genre, " family ", " familia ", " familiar ");
        if (!directKids && !animation && !family) return false;
        return !has(genre,
                " adult ", " adults ", " adulto ", " adultos ", " erotic ", " erotico ",
                " porn ", " horror ", " terror ", " thriller ", " crime ", " gore ");
    }

    public static void open(Activity activity, String mode) {
        if (activity == null || !valid(mode)) return;
        if (HOT.equals(mode)) {
            SessionStore session = new SessionStore(activity);
            if (!session.adult()) {
                Toast.makeText(activity, "Conteúdo HOT não está liberado para esta conta", Toast.LENGTH_SHORT).show();
                return;
            }
            String saved = activity.getSharedPreferences("green_play_parental", Activity.MODE_PRIVATE).getString("pin", "");
            if (saved != null && !saved.trim().isEmpty()) {
                EditText input = new EditText(activity);
                input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
                input.setHint("PIN de 4 dígitos");
                input.setSingleLine(true);
                new AlertDialog.Builder(activity)
                        .setTitle("Conteúdo HOT")
                        .setMessage("Digite o PIN configurado neste aparelho.")
                        .setView(input)
                        .setPositiveButton("ENTRAR", (d, w) -> {
                            if (saved.equals(input.getText().toString().trim())) launch(activity, mode);
                            else Toast.makeText(activity, "PIN incorreto", Toast.LENGTH_SHORT).show();
                        })
                        .setNegativeButton("CANCELAR", null)
                        .show();
                return;
            }
        }
        launch(activity, mode);
    }

    private static void launch(Activity activity, String mode) {
        Intent i = new Intent(activity, SpecialCatalogActivity.class);
        i.putExtra(EXTRA_MODE, mode);
        i.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NO_ANIMATION);
        activity.startActivity(i);
        activity.overridePendingTransition(0, 0);
    }

    private static boolean has(String source, String... words) {
        for (String word : words) if (source.contains(word)) return true;
        return false;
    }

    private static String normalize(String raw) {
        return normalizeCategory(raw);
    }

    private static String normalizeCategory(String raw) {
        if (raw == null) return "";
        String s = Normalizer.normalize(raw, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        return s.toLowerCase(Locale.ROOT)
                .replaceAll("[^\\p{L}\\p{N}+]+", " ")
                .replaceAll("\\s+", " ").trim();
    }
}
