package com.greenplay.v5.ui.tv;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.greenplay.v5.data.model.tv.TvChannel;
import java.lang.reflect.Type;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

/** Last-known TV channel list for transient Xtream failures on the same host/account. */
public final class TvCacheStore {
    private static final String PREF = "green_play_v5_tv_cache_v1";
    private static final String FAST_PREF = "green_play_v5_tv_fast_cache_v139";
    private static final int FAST_LIMIT = 420;
    private static final Type CHANNELS = new TypeToken<List<TvChannel>>(){}.getType();
    private final SharedPreferences prefs;
    private final SharedPreferences fastPrefs;
    private final Gson gson = new Gson();
    private final String scope;

    public TvCacheStore(Context context, String host, String user) {
        prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        fastPrefs = context.getSharedPreferences(FAST_PREF, Context.MODE_PRIVATE);
        scope = Integer.toHexString(((host == null ? "" : host) + "|" + (user == null ? "" : user)).hashCode());
    }

    public List<TvChannel> channels() {
        try {
            List<TvChannel> rows = gson.fromJson(prefs.getString(scope + "_channels", "[]"), CHANNELS);
            return rows == null ? new ArrayList<>() : rows;
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    /**
     * V5.0.139 — leitura de arranque. Faz streaming do JSON e desserializa somente
     * os primeiros canais necessários para colocar a TV na tela. O catálogo inteiro
     * continua sendo hidratado em background depois que a Activity já abriu.
     *
     * Isso é importante em TV Box mais lenta: o cache de TV pode ter milhares de
     * canais e não deve ficar na mesma fila de Filmes + Séries antes da primeira tela.
     */
    public List<TvChannel> channelsFast(int maxItems) {
        ArrayList<TvChannel> out = new ArrayList<>();
        if (maxItems <= 0) return out;

        // Nas próximas aberturas nem o SharedPreferences gigante de TV precisa entrar
        // no caminho crítico: a janela de arranque vive em um arquivo separado e pequeno.
        try {
            List<TvChannel> fast = gson.fromJson(fastPrefs.getString(scope + "_channels", "[]"), CHANNELS);
            if (fast != null && !fast.isEmpty()) {
                if (fast.size() <= maxItems) return fast;
                return new ArrayList<>(fast.subList(0, maxItems));
            }
        } catch (Exception ignored) { }

        // Migração transparente da V138 e anteriores: lê somente o começo do JSON
        // antigo uma vez e já cria o snapshot pequeno para as próximas aberturas.
        String raw = prefs.getString(scope + "_channels", "[]");
        if (raw == null || raw.length() < 3) return out;
        try (JsonReader reader = new JsonReader(new StringReader(raw))) {
            reader.setLenient(true);
            reader.beginArray();
            while (reader.hasNext() && out.size() < maxItems) {
                TvChannel row = gson.fromJson(reader, TvChannel.class);
                if (row != null) out.add(row);
            }
            if (!out.isEmpty()) fastPrefs.edit().putString(scope + "_channels", gson.toJson(out)).apply();
        } catch (Exception ignored) {
            out.clear();
        }
        return out;
    }

    public void saveChannels(List<TvChannel> rows) {
        List<TvChannel> safe = rows == null ? java.util.Collections.emptyList() : rows;
        prefs.edit().putString(scope + "_channels", gson.toJson(safe)).apply();
        int end = Math.min(FAST_LIMIT, safe.size());
        List<TvChannel> fast = end <= 0 ? java.util.Collections.emptyList() : new ArrayList<>(safe.subList(0, end));
        fastPrefs.edit().putString(scope + "_channels", gson.toJson(fast)).apply();
    }
}
