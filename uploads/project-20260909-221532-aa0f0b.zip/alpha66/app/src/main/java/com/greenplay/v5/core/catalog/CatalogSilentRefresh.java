package com.greenplay.v5.core.catalog;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import com.greenplay.v5.data.model.movie.Movie;
import com.greenplay.v5.data.model.movie.MovieCategory;
import com.greenplay.v5.data.model.series.SeriesCategory;
import com.greenplay.v5.data.model.series.SeriesItem;
import com.greenplay.v5.data.model.tv.TvChannel;
import com.greenplay.v5.data.repository.MovieRepository;
import com.greenplay.v5.data.repository.SeriesRepository;
import com.greenplay.v5.data.repository.TvRepository;
import com.greenplay.v5.ui.movies.MovieCacheStore;
import com.greenplay.v5.ui.series.SeriesCacheStore;
import com.greenplay.v5.ui.tv.TvCacheStore;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Atualiza o catálogo sem abrir loader e sem apagar o último catálogo válido. */
public final class CatalogSilentRefresh {
    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static String runningKey = "";

    private CatalogSilentRefresh() {}

    public static void start(Context context, String host, String user, String pass) {
        final Context app = context.getApplicationContext();
        final String key = (host == null ? "" : host.trim()) + "|" + (user == null ? "" : user.trim());
        synchronized (CatalogSilentRefresh.class) {
            if (key.equals(runningKey)) return;
            runningKey = key;
        }
        // Dá tempo para a primeira tela aparecer antes de tocar no servidor.
        MAIN.postDelayed(() -> IO.execute(() -> refreshTv(app, host, user, pass, key)), 1800L);
    }

    private static boolean current(String key) {
        synchronized (CatalogSilentRefresh.class) { return key.equals(runningKey); }
    }

    private static void done(String key) {
        synchronized (CatalogSilentRefresh.class) { if (key.equals(runningKey)) runningKey = ""; }
    }

    private static void refreshTv(Context app, String host, String user, String pass, String key) {
        new TvRepository(host, user, pass).channels("", new TvRepository.ChannelsResult() {
            @Override public void success(List<TvChannel> rows) { IO.execute(() -> {
                if (!current(key)) return;
                if (rows != null && !rows.isEmpty()) {
                    CatalogMemory.setChannels(rows);
                    new TvCacheStore(app, host, user).saveChannels(rows);
                }
                refreshMovieCategories(app, host, user, pass, key);
            }); }
            @Override public void error(String message) { IO.execute(() -> refreshMovieCategories(app, host, user, pass, key)); }
        });
    }

    private static void refreshMovieCategories(Context app, String host, String user, String pass, String key) {
        new MovieRepository(host, user, pass).categories(new MovieRepository.CategoriesResult() {
            @Override public void success(List<MovieCategory> rows) { IO.execute(() -> {
                if (!current(key)) return;
                if (rows != null && !rows.isEmpty()) {
                    CatalogMemory.setMovieCategories(rows);
                    new MovieCacheStore(app, host, user).saveCategories(rows);
                }
                refreshMovies(app, host, user, pass, key);
            }); }
            @Override public void error(String message) { IO.execute(() -> refreshMovies(app, host, user, pass, key)); }
        });
    }

    private static void refreshMovies(Context app, String host, String user, String pass, String key) {
        new MovieRepository(host, user, pass).moviesProgressive("", 24, 240, new MovieRepository.ProgressiveMoviesResult() {
            @Override public void partial(List<Movie> rows) { /* nunca substitui cache completo por parcial */ }
            @Override public void success(List<Movie> rows) { IO.execute(() -> {
                if (!current(key)) return;
                if (rows != null && !rows.isEmpty()) {
                    CatalogMemory.setMovies(rows);
                    new MovieCacheStore(app, host, user).saveMovies(rows);
                }
                refreshSeriesCategories(app, host, user, pass, key);
            }); }
            @Override public void error(String message) { IO.execute(() -> refreshSeriesCategories(app, host, user, pass, key)); }
        });
    }

    private static void refreshSeriesCategories(Context app, String host, String user, String pass, String key) {
        new SeriesRepository(host, user, pass).categories(new SeriesRepository.CategoriesResult() {
            @Override public void success(List<SeriesCategory> rows) { IO.execute(() -> {
                if (!current(key)) return;
                if (rows != null && !rows.isEmpty()) {
                    CatalogMemory.setSeriesCategories(rows);
                    new SeriesCacheStore(app, host, user).saveCategories(rows);
                }
                refreshSeries(app, host, user, pass, key);
            }); }
            @Override public void error(String message) { IO.execute(() -> refreshSeries(app, host, user, pass, key)); }
        });
    }

    private static void refreshSeries(Context app, String host, String user, String pass, String key) {
        new SeriesRepository(host, user, pass).seriesProgressive("", 24, 240, new SeriesRepository.ProgressiveSeriesResult() {
            @Override public void partial(List<SeriesItem> rows) { /* preserva último catálogo completo */ }
            @Override public void success(List<SeriesItem> rows) { IO.execute(() -> {
                if (!current(key)) return;
                if (rows != null && !rows.isEmpty()) {
                    CatalogMemory.setSeries(rows);
                    new SeriesCacheStore(app, host, user).saveSeries(rows);
                }
                finish(app, host, user, key);
            }); }
            @Override public void error(String message) { IO.execute(() -> finish(app, host, user, key)); }
        });
    }

    private static void finish(Context app, String host, String user, String key) {
        IO.execute(() -> {
            try {
                SpecialCatalogIndex.rebuild();
            } catch (Exception ignored) { }
            // Só marca como sincronizado se ao final ainda existe um catálogo utilizável.
            if (!CatalogMemory.channels().isEmpty() && !CatalogMemory.movies().isEmpty() && !CatalogMemory.series().isEmpty()) {
                new CatalogRefreshPolicy(app, host, user).markFullRefresh();
            }
            done(key);
        });
    }
}
