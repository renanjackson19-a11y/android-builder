package com.greenplay.v5.data.model;

import com.google.gson.annotations.SerializedName;

public final class DiagnosticsResponse {
    public boolean ok;
    public boolean database;
    @SerializedName("active_sources") public int activeSources;
    public int live;
    public int movies;
    public int series;
    public int episodes;
    public int epg;
    @SerializedName("server_ready") public boolean serverReady;
}
