package com.greenplay.v5.ui.player;

import android.net.Uri;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import com.greenplay.v5.core.player.GreenPlayerFactory;
import com.greenplay.v5.databinding.ActivityPlayerBinding;

public final class PlayerActivity extends AppCompatActivity {
    private ActivityPlayerBinding b;
    private ExoPlayer player;
    private String fallbackUrl;
    private boolean fallbackTried;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        b = ActivityPlayerBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        String url = getIntent().getStringExtra("url");
        fallbackUrl = getIntent().getStringExtra("fallback_url");
        if (url == null || url.trim().isEmpty()) { finish(); return; }
        player = GreenPlayerFactory.create(this);
        b.playerView.setPlayer(player);
        player.addListener(new Player.Listener(){
            @Override public void onPlayerError(@NonNull PlaybackException error){
                if(!fallbackTried && fallbackUrl!=null && !fallbackUrl.trim().isEmpty()){
                    fallbackTried=true;
                    startUrl(fallbackUrl);
                }
            }
        });
        startUrl(url);
    }

    private void startUrl(String url){
        if(player==null)return;
        MediaItem.Builder item=new MediaItem.Builder().setUri(Uri.parse(url));
        String lower=url.toLowerCase(java.util.Locale.US);
        if(lower.contains(".m3u8")) item.setMimeType(MimeTypes.APPLICATION_M3U8);
        else if(lower.contains(".ts")) item.setMimeType(MimeTypes.VIDEO_MP2T);
        player.setMediaItem(item.build());
        player.setPlayWhenReady(true);
        player.prepare();
    }

    @Override protected void onStop() { super.onStop(); if (player != null) player.pause(); }
    @Override protected void onStart() { super.onStart(); if(player!=null && player.getMediaItemCount()>0) player.play(); }
    @Override protected void onDestroy() { if(player!=null){player.release();player=null;} super.onDestroy(); }
}
