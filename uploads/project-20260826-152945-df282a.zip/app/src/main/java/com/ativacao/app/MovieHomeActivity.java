package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.BaseAdapter;
import android.widget.AbsListView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MovieHomeActivity extends Activity {
    private final List<ApiClient.Item> latest = new ArrayList<>();
    private GridView grid;
    private MovieAdapter adapter;
    private boolean phone;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        Ui.immersive(this);
        phone=Ui.phone(this);
        setContentView(AppBackground.wrap(this,build()));
        loadLatest();
    }

    @Override protected void onResume(){
        super.onResume();
        Ui.immersive(this);
    }

    private View build(){
        LinearLayout root=Ui.column(this);
        root.setBackgroundColor(Color.TRANSPARENT);
        root.addView(YellowNav.bar(this,"FILMES"),new LinearLayout.LayoutParams(-1,Ui.dp(this,64)));

        LinearLayout body=Ui.column(this);
        body.setPadding(Ui.dp(this,phone?18:26),Ui.dp(this,10),Ui.dp(this,phone?18:26),Ui.dp(this,14));

        LinearLayout heading=new LinearLayout(this);
        heading.setGravity(Gravity.CENTER_VERTICAL);

        TextView title=Ui.text(this,"FILMES  •  LANÇAMENTOS",phone?16:20,Ui.TEXT,true);
        heading.addView(title,new LinearLayout.LayoutParams(0,Ui.dp(this,40),1));

        TextView recent=Ui.text(this,"MAIS RECENTES",phone?9:11,Ui.GREEN,true);
        recent.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        heading.addView(recent,new LinearLayout.LayoutParams(Ui.dp(this,phone?120:150),Ui.dp(this,40)));

        body.addView(heading,new LinearLayout.LayoutParams(-1,Ui.dp(this,44)));

        grid=new GridView(this);
        grid.setNumColumns(getResources().getConfiguration().orientation==
                android.content.res.Configuration.ORIENTATION_LANDSCAPE ? 6 : 3);
        grid.setHorizontalSpacing(Ui.dp(this,10));
        grid.setVerticalSpacing(Ui.dp(this,10));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setSelector(android.R.color.transparent);
        grid.setClipChildren(false);
        grid.setClipToPadding(false);

        adapter=new MovieAdapter();
        grid.setAdapter(adapter);

        body.addView(grid,new LinearLayout.LayoutParams(-1,0,1));
        root.addView(body,new LinearLayout.LayoutParams(-1,0,1));
        return root;
    }

    private void loadLatest(){
        // Primeiro tenta o catálogo que JÁ foi preparado depois do login.
        ApiClient.catalogPrepared("movie",1,72,"","","",new ApiClient.Callback<ApiClient.CatalogPage>(){
            @Override public void ok(ApiClient.CatalogPage p){
                runOnUiThread(()->{
                    latest.clear();
                    if(p!=null&&p.items!=null)latest.addAll(p.items);

                    Collections.sort(latest,(x,y)->{
                        int ay=x==null?0:x.year;
                        int by=y==null?0:y.year;
                        if(ay!=by)return Integer.compare(by,ay);
                        long ai=x==null?0:x.id;
                        long bi=y==null?0:y.id;
                        return Long.compare(bi,ai);
                    });

                    adapter.notifyDataSetChanged();
                    if(adapter.getCount()>0)grid.requestFocus();
                });
            }

            @Override public void error(String m){
                // Sem tela de "Carregando". Tenta atualização silenciosa.
                ApiClient.catalog("movie",1,72,"","","",new ApiClient.Callback<ApiClient.CatalogPage>(){
                    public void ok(ApiClient.CatalogPage p){
                        runOnUiThread(()->{
                            latest.clear();
                            if(p!=null&&p.items!=null)latest.addAll(p.items);
                            Collections.sort(latest,(x,y)->{
                                int ay=x==null?0:x.year, by=y==null?0:y.year;
                                if(ay!=by)return Integer.compare(by,ay);
                                return Long.compare(y==null?0:y.id,x==null?0:x.id);
                            });
                            adapter.notifyDataSetChanged();
                        });
                    }
                    public void error(String e){}
                });
            }
        });
    }

    private class MovieAdapter extends BaseAdapter {
        // 1 card TODOS + 5 lançamentos = 6 cards por linha na TV.
        @Override public int getCount(){
            return 1 + Math.min(5,latest.size());
        }

        @Override public Object getItem(int position){
            if(position==0)return null;
            return latest.get(position-1);
        }

        @Override public long getItemId(int position){
            if(position==0)return -1;
            return latest.get(position-1).id;
        }

        @Override public View getView(int position,View convert,android.view.ViewGroup parent){
            if(position==0)return allCard();
            return movieCard(latest.get(position-1));
        }
    }

    private View allCard(){
        FrameLayout card=new FrameLayout(this);
        card.setFocusable(true);
        card.setClickable(true);
        card.setClipChildren(false);
        Ui.focus(card,this,
                Ui.round(0xCC0A1610,12,this),
                Ui.stroke(0xFF102218,Ui.GREEN,12,this));

        ImageView bg=new ImageView(this);
        bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        bg.setImageResource(R.drawable.green_play_placeholder);
        if(!latest.isEmpty()){
            ApiClient.Item cover=latest.get(0);
            ImageLoader.intoPoster(this,bg,clean(cover.backdrop,cover.logo));
        }
        card.addView(bg,new FrameLayout.LayoutParams(-1,-1));

        View shade=new View(this);
        shade.setBackgroundColor(Color.argb(150,0,18,7));
        card.addView(shade,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout text=Ui.column(this);
        text.setGravity(Gravity.CENTER);
        TextView t=Ui.text(this,"TODOS",phone?16:20,Color.WHITE,true);
        t.setGravity(Gravity.CENTER);
        TextView sub=Ui.text(this,"Ver catálogo completo",phone?8:10,0xFFE4E9E5,false);
        sub.setGravity(Gravity.CENTER);
        text.addView(t,new LinearLayout.LayoutParams(-1,Ui.dp(this,34)));
        text.addView(sub,new LinearLayout.LayoutParams(-1,Ui.dp(this,22)));

        card.addView(text,new FrameLayout.LayoutParams(-1,Ui.dp(this,72),Gravity.CENTER));
        card.setOnClickListener(v->openAll());

        card.setLayoutParams(new AbsListView.LayoutParams(-1,Ui.dp(this,phone?180:250)));
        return card;
    }

    private View movieCard(ApiClient.Item i){
        LinearLayout outer=Ui.column(this);
        outer.setFocusable(true);
        outer.setClickable(true);
        outer.setClipChildren(false);
        outer.setBackground(Ui.round(0x26000000,10,this));
        Ui.focus(outer,this,
                Ui.round(0x26000000,10,this),
                Ui.stroke(0x00101010,Ui.GREEN,10,this));

        ImageView poster=new ImageView(this);
        poster.setScaleType(ImageView.ScaleType.CENTER_CROP);
        poster.setBackgroundColor(Ui.PANEL_2);
        ImageLoader.intoPoster(this,poster,clean(i.logo,i.backdrop));

        int posterH=phone?150:205;
        outer.addView(poster,new LinearLayout.LayoutParams(-1,Ui.dp(this,posterH)));

        TextView name=Ui.text(this,clean(i.name,"Filme"),phone?9:10,Color.WHITE,true);
        name.setMaxLines(1);
        name.setPadding(Ui.dp(this,5),Ui.dp(this,4),Ui.dp(this,5),0);
        outer.addView(name,new LinearLayout.LayoutParams(-1,Ui.dp(this,28)));

        TextView year=Ui.text(this,i.year>0?String.valueOf(i.year):"",phone?8:9,0xFFB8C1BA,false);
        year.setPadding(Ui.dp(this,5),0,Ui.dp(this,5),0);
        outer.addView(year,new LinearLayout.LayoutParams(-1,Ui.dp(this,18)));

        outer.setOnClickListener(v->openMovie(i));
        outer.setLayoutParams(new AbsListView.LayoutParams(-1,Ui.dp(this,phone?198:255)));
        return outer;
    }

    private void openAll(){
        Intent i=new Intent(this,CatalogActivity.class);
        i.putExtra("type","movie");
        i.putExtra("title","Filmes");
        i.putExtra("category","");
        i.putExtra("browse",true);
        startActivity(i);
    }

    private void openMovie(ApiClient.Item i){
        Intent d=new Intent(this,DetailActivity.class);
        d.putExtra("type","movie");
        d.putExtra("id",i.id);
        d.putExtra("name",i.name);
        d.putExtra("logo",i.logo);
        d.putExtra("backdrop",i.backdrop);
        d.putExtra("year",i.year);
        d.putExtra("synopsis",i.synopsis);
        startActivity(d);
    }

    private static String clean(String a,String b){
        return a==null||a.trim().isEmpty()?b:a.trim();
    }
}
