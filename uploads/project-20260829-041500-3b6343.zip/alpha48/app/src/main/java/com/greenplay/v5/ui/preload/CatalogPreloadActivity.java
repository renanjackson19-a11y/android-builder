package com.greenplay.v5.ui.preload;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import androidx.appcompat.app.AppCompatActivity;
import com.greenplay.v5.core.catalog.CatalogMemory;
import com.greenplay.v5.core.catalog.CatalogCoverWarmer;
import com.greenplay.v5.core.session.SessionStore;
import com.greenplay.v5.data.model.movie.Movie;
import com.greenplay.v5.data.model.movie.MovieCategory;
import com.greenplay.v5.data.model.series.SeriesItem;
import com.greenplay.v5.data.model.tv.TvChannel;
import com.greenplay.v5.data.repository.MovieRepository;
import com.greenplay.v5.data.repository.SeriesWarmRepository;
import com.greenplay.v5.data.repository.TvRepository;
import com.greenplay.v5.databinding.ActivityCatalogPreloadBinding;
import com.greenplay.v5.ui.tv.TvActivity;
import java.util.List;
import java.util.ArrayList;

/**
 * Startup bootstrap: fresh bouquet first, UI afterwards.
 * This moves heavy catalog loading out of TV/Movies screens.
 */
public final class CatalogPreloadActivity extends AppCompatActivity {
    private ActivityCatalogPreloadBinding b;
    private SessionStore session;
    private TvRepository tvRepo;
    private MovieRepository movieRepo;
    private SeriesWarmRepository seriesRepo;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private boolean channelsDone = false;
    private boolean moviesDone = false;
    private boolean movieCategoriesDone = false;
    private boolean seriesDone = false;
    private boolean opened = false;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        b = ActivityCatalogPreloadBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());

        session = new SessionStore(this);
        if (!session.isLogged() || session.host().trim().isEmpty() || session.user().trim().isEmpty()) {
            finish();
            return;
        }

        CatalogMemory.clear();
        tvRepo = new TvRepository(session.host(), session.user(), session.pass());
        movieRepo = new MovieRepository(session.host(), session.user(), session.pass());
        seriesRepo = new SeriesWarmRepository(session.host(), session.user(), session.pass());

        updateCatalogProgress(4);
        loadChannels();
        loadMovieCategories();
        loadMovies();
        loadSeries();
    }

    private void loadChannels() {
        b.statusChannels.setText("●  Carregando canais...");
        tvRepo.channels("", new TvRepository.ChannelsResult() {
            @Override public void success(List<TvChannel> rows) {
                CatalogMemory.setChannels(rows);
                warmChannelLogos(rows);
                channelsDone = true;
                b.statusChannels.setText("✓  Canais prontos  •  " + rows.size());
                b.statusChannels.setTextColor(0xFF29E76F);
                updateProgressAndFinish();
            }

            @Override public void error(String message) {
                channelsDone = true;
                b.statusChannels.setText("!  Canais: " + message);
                b.statusChannels.setTextColor(0xFFFFA56B);
                updateProgressAndFinish();
            }
        });
    }

    private void loadMovieCategories() {
        movieRepo.categories(new MovieRepository.CategoriesResult() {
            @Override public void success(List<MovieCategory> rows) {
                CatalogMemory.setMovieCategories(rows);
                movieCategoriesDone = true;
                updateProgressAndFinish();
            }

            @Override public void error(String message) {
                movieCategoriesDone = true;
                updateProgressAndFinish();
            }
        });
    }

    private void loadMovies() {
        b.statusMovies.setText("●  Carregando filmes e capas...");
        b.statusMovies.setTextColor(0xFFFFFFFF);
        movieRepo.movies("", new MovieRepository.MoviesResult() {
            @Override public void success(List<Movie> rows) {
                CatalogMemory.setMovies(rows);
                warmMoviePosters(rows);
                moviesDone = true;
                b.statusMovies.setText("✓  Filmes prontos  •  " + rows.size());
                b.statusMovies.setTextColor(0xFF29E76F);
                updateProgressAndFinish();
            }

            @Override public void error(String message) {
                moviesDone = true;
                b.statusMovies.setText("!  Filmes: " + message);
                b.statusMovies.setTextColor(0xFFFFA56B);
                updateProgressAndFinish();
            }
        });
    }

    private void loadSeries() {
        b.statusSeries.setText("●  Carregando séries e capas...");
        b.statusSeries.setTextColor(0xFFFFFFFF);
        seriesRepo.series(new SeriesWarmRepository.Result() {
            @Override public void success(List<SeriesItem> rows) {
                CatalogMemory.setSeries(rows);
                warmSeriesCovers(rows);
                seriesDone = true;
                b.statusSeries.setText("✓  Séries prontas  •  " + rows.size());
                b.statusSeries.setTextColor(0xFF29E76F);
                updateProgressAndFinish();
            }

            @Override public void error(String message) {
                seriesDone = true;
                b.statusSeries.setText("!  Séries: " + message);
                b.statusSeries.setTextColor(0xFFFFA56B);
                updateProgressAndFinish();
            }
        });
    }

    private void updateProgressAndFinish() {
        int done = 0;
        if (channelsDone) done++;
        if (moviesDone && movieCategoriesDone) done++;
        if (seriesDone) done++;
        int progress = done == 0 ? 8 : (done == 1 ? 36 : (done == 2 ? 68 : 100));
        updateCatalogProgress(progress);

        if (channelsDone && moviesDone && movieCategoriesDone && seriesDone && !opened) {
            opened = true;
            b.catalogMessage.setText("Conteúdo preparado • abrindo GREEN PLAY");
            handler.postDelayed(this::openTv, 450L);
        }
    }

    private void updateCatalogProgress(int value) {
        int p = Math.max(0, Math.min(100, value));
        b.catalogProgress.setProgress(p);
        b.catalogPercent.setText(p + "%");
    }

    private void warmChannelLogos(List<TvChannel> rows) {
        List<String> urls = new ArrayList<>();
        if (rows != null) for (TvChannel row : rows) if (row != null) urls.add(row.logo);
        CatalogCoverWarmer.enqueue(urls);
    }

    private void warmMoviePosters(List<Movie> rows) {
        List<String> urls = new ArrayList<>();
        if (rows != null) for (Movie row : rows) if (row != null) urls.add(row.poster);
        CatalogCoverWarmer.enqueue(urls);
    }

    private void warmSeriesCovers(List<SeriesItem> rows) {
        List<String> urls = new ArrayList<>();
        if (rows != null) for (SeriesItem row : rows) if (row != null) urls.add(row.cover);
        CatalogCoverWarmer.enqueue(urls);
    }

    private void openTv() {
        if (isFinishing()) return;
        startActivity(new Intent(this, TvActivity.class));
        finish();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
