package com.greenplay.v5.data.model;

import com.google.gson.annotations.SerializedName;

public final class StatusResponse {
    public String name;
    @SerializedName("trial_enabled") public boolean trialEnabled;
    @SerializedName("trial_hours") public int trialHours;
    @SerializedName("login_background") public String loginBackground;
    @SerializedName("app_logo") public String appLogo;
    @SerializedName("app_background") public String appBackground;
    @SerializedName("internal_background") public String internalBackground;
}
