package com.greenplay.v5.ui.movies;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.greenplay.v5.R;
import com.greenplay.v5.data.model.movie.Movie;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;
import java.util.List;

/**
 * Lightweight adapter: it only renders the page already prepared by MovieActivity.
 * Expensive catalog filtering/deduplication must never run on the UI thread here.
 */
public final class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.Holder> {
    public interface Listener {
        void onOpen(Movie movie);
        void onFavorite(Movie movie);
        boolean isFavorite(Movie movie);
    }

    private final Listener listener;
    private final List<Movie> rows = new ArrayList<>();
    private String fallbackPoster = "";

    public MovieAdapter(Listener listener) {
        this.listener = listener;
        setHasStableIds(true);
    }

    public void setFallbackPoster(String url) {
        fallbackPoster = url == null ? "" : url.trim();
    }

    public void replace(List<Movie> items) {
        rows.clear();
        if (items != null) rows.addAll(items);
        notifyDataSetChanged();
    }

    public void append(List<Movie> items) {
        if (items == null || items.isEmpty()) return;
        int start = rows.size();
        rows.addAll(items);
        notifyItemRangeInserted(start, items.size());
    }

    public void refreshFavorite(long id) {
        for (int i = 0; i < rows.size(); i++) {
            if (rows.get(i).id == id) {
                notifyItemChanged(i);
                return;
            }
        }
    }

    public void refreshVisible() {
        if (!rows.isEmpty()) notifyItemRangeChanged(0, rows.size());
    }

    @Override public long getItemId(int position) { return rows.get(position).id; }

    @NonNull @Override public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new Holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_movie, parent, false));
    }

    @Override public void onBindViewHolder(@NonNull Holder h, int position) {
        Movie m = rows.get(position);
        h.title.setText(cleanLabel(m.name));
        String meta = meta(m);
        h.meta.setText(meta);
        h.meta.setVisibility(meta.isEmpty() ? View.GONE : View.VISIBLE);
        h.favorite.setText(listener.isFavorite(m) ? "★" : "☆");
        h.poster.setImageDrawable(null);
        h.poster.setBackgroundResource(R.drawable.bg_movie_poster_placeholder);
        String posterUrl = m.poster == null ? "" : m.poster.trim();
        if (posterUrl.isEmpty()) posterUrl = fallbackPoster;
        if (!posterUrl.isEmpty()) {
            Picasso.get().load(posterUrl).fit().centerCrop().noFade().into(h.poster);
        }
        h.itemView.setOnClickListener(v -> listener.onOpen(m));
        h.favorite.setOnClickListener(v -> listener.onFavorite(m));
    }

    private static String meta(Movie m) {
        String y = m.year == null ? "" : m.year.trim();
        if ("0".equals(y) || "0000".equals(y)) y = "";
        String r = m.rating == null ? "" : m.rating.trim();
        if (!r.isEmpty() && !"0".equals(r) && !"0.0".equals(r)) {
            return y.isEmpty() ? "★ " + r : y + "  •  ★ " + r;
        }
        return y;
    }

    private static String cleanLabel(String raw) {
        if (raw == null) return "";
        String s = raw.replace("\\/", "/").replace("\n", " ").replace("\r", " ").trim();
        s = s.replaceAll("^[^\\p{L}\\p{N}(]+", "");
        return s.replaceAll("\\s{2,}", " ").trim();
    }

    @Override public int getItemCount() { return rows.size(); }

    static final class Holder extends RecyclerView.ViewHolder {
        final ImageView poster;
        final TextView title, meta, favorite;
        Holder(View itemView) {
            super(itemView);
            poster = itemView.findViewById(R.id.moviePoster);
            title = itemView.findViewById(R.id.movieTitle);
            meta = itemView.findViewById(R.id.movieMeta);
            favorite = itemView.findViewById(R.id.movieFavorite);
        }
    }
}
