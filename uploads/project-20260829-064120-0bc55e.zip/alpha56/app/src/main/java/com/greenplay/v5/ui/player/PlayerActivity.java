package com.greenplay.v5.ui.player;

import android.app.AlertDialog;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.OptIn;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.Tracks;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.TrackSelectionDialogBuilder;
import com.greenplay.v5.core.player.GreenPlayerFactory;
import com.greenplay.v5.core.config.AppControlStore;
import com.greenplay.v5.core.player.VodProgressStore;
import com.greenplay.v5.databinding.ActivityPlayerBinding;
import java.util.ArrayList;
import java.util.List;

/**
 * Shared player. The TV transport path is intentionally untouched.
 * VOD receives its own loading overlay, resume persistence and conditional
 * language/subtitle controls.
 */
@OptIn(markerClass = UnstableApi.class)
public final class PlayerActivity extends AppCompatActivity {
    private ActivityPlayerBinding b;
    private ExoPlayer player;
    private String fallbackUrl;
    private boolean fallbackTried;
    private boolean vodMode;
    private String title;
    private String progressKey;
    private long initialResumeMs;
    private VodProgressStore progressStore;
    private AppControlStore control;
    private final Handler progressHandler = new Handler(Looper.getMainLooper());

    private final Runnable progressSaver = new Runnable() {
        @Override public void run() {
            saveProgress();
            progressHandler.postDelayed(this, 5_000L);
        }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        b = ActivityPlayerBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());

        String url = getIntent().getStringExtra("url");
        fallbackUrl = getIntent().getStringExtra("fallback_url");
        vodMode = "vod".equalsIgnoreCase(getIntent().getStringExtra("media_type"));
        title = safe(getIntent().getStringExtra("title"));
        progressKey = safe(getIntent().getStringExtra("progress_key"));
        initialResumeMs = Math.max(0L, getIntent().getLongExtra("resume_position", 0L));
        if (url == null || url.trim().isEmpty()) { finish(); return; }

        control = new AppControlStore(this);
        player = GreenPlayerFactory.create(this);
        try {
            String preferredAudio = control.preferredAudio();
            if (preferredAudio != null && !preferredAudio.trim().isEmpty()) {
                player.setTrackSelectionParameters(player.getTrackSelectionParameters().buildUpon()
                        .setPreferredAudioLanguage(preferredAudio.trim()).build());
            }
        } catch (Exception ignored) {}
        b.playerView.setPlayer(player);

        b.vodTopBar.setVisibility(vodMode ? View.VISIBLE : View.GONE);
        b.vodLoadingOverlay.setVisibility(vodMode ? View.VISIBLE : View.GONE);
        b.vodSettings.setVisibility(View.GONE);
        if (vodMode) {
            b.vodPlayerTitle.setText(title.isEmpty() ? "GREEN PLAY" : title);
            b.vodLoadingTitle.setText(title.isEmpty() ? "Preparando reprodução" : title);
            b.vodLoadingStatus.setText(control.loadingText());
            progressStore = new VodProgressStore(this);
            applyDefaultSubtitleSize();
            b.vodSettings.setOnClickListener(v -> openPlaybackSettings());
            progressHandler.postDelayed(progressSaver, 5_000L);
        }

        player.addListener(new Player.Listener() {
            @Override public void onPlayerError(@NonNull PlaybackException error) {
                if (!fallbackTried && fallbackUrl != null && !fallbackUrl.trim().isEmpty()) {
                    fallbackTried = true;
                    if (vodMode) {
                        b.vodLoadingOverlay.setVisibility(View.VISIBLE);
                        b.vodLoadingStatus.setText("Ajustando a rota de reprodução…");
                    }
                    long keep = player == null ? 0L : Math.max(initialResumeMs, player.getCurrentPosition());
                    initialResumeMs = keep;
                    startUrl(fallbackUrl);
                    return;
                }
                if (vodMode) {
                    b.vodLoadingOverlay.setVisibility(View.VISIBLE);
                    b.vodLoadingStatus.setText("Não foi possível iniciar este conteúdo");
                }
            }

            @Override public void onPlaybackStateChanged(int state) {
                if (!vodMode) return;
                if (state == Player.STATE_BUFFERING) {
                    b.vodLoadingOverlay.setVisibility(View.VISIBLE);
                    b.vodLoadingStatus.setText("Carregando vídeo…");
                } else if (state == Player.STATE_READY) {
                    b.vodLoadingOverlay.setVisibility(View.GONE);
                } else if (state == Player.STATE_ENDED) {
                    if (progressStore != null) progressStore.clear(progressKey);
                }
            }

            @Override public void onTracksChanged(@NonNull Tracks tracks) {
                if (!vodMode) return;
                boolean hasSubtitle = tracks.containsType(C.TRACK_TYPE_TEXT);
                int audioTracks = countSupportedTracks(tracks, C.TRACK_TYPE_AUDIO);
                boolean hasOptions = hasSubtitle || audioTracks > 1;
                b.vodSettings.setVisibility(hasOptions ? View.VISIBLE : View.GONE);
                b.vodSettings.setText(hasSubtitle && audioTracks > 1
                        ? "⚙  ÁUDIO / LEGENDAS"
                        : (hasSubtitle ? "CC  LEGENDAS" : "🔊  IDIOMA"));
            }
        });
        startUrl(url);
    }

    private int countSupportedTracks(Tracks tracks, int trackType) {
        int count = 0;
        try {
            for (Tracks.Group group : tracks.getGroups()) {
                if (group.getType() != trackType) continue;
                for (int i = 0; i < group.length; i++) if (group.isTrackSupported(i)) count++;
            }
        } catch (Exception ignored) {}
        return count;
    }

    private void openPlaybackSettings() {
        if (player == null) return;
        Tracks tracks = player.getCurrentTracks();
        boolean subtitles = tracks.containsType(C.TRACK_TYPE_TEXT);
        boolean languages = countSupportedTracks(tracks, C.TRACK_TYPE_AUDIO) > 1;
        List<String> options = new ArrayList<>();
        if (languages) options.add("Áudio / idioma");
        if (subtitles) options.add("Idioma da legenda");
        if (subtitles) options.add("Tamanho da legenda");
        if (options.isEmpty()) {
            Toast.makeText(this, "Este conteúdo não possui opções adicionais na fonte", Toast.LENGTH_SHORT).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Configurações de reprodução")
                .setItems(options.toArray(new String[0]), (dialog, which) -> {
                    String selected = options.get(which);
                    if (selected.startsWith("Áudio")) openTracks(C.TRACK_TYPE_AUDIO, "Áudio / idioma");
                    else if (selected.startsWith("Idioma")) openTracks(C.TRACK_TYPE_TEXT, "Idioma da legenda");
                    else openSubtitleSize();
                })
                .setNegativeButton("Fechar", null)
                .show();
    }

    private void openTracks(int trackType, String dialogTitle) {
        if (player == null) return;
        Tracks tracks = player.getCurrentTracks();
        if (!tracks.containsType(trackType)) return;
        new TrackSelectionDialogBuilder(this, dialogTitle, player, trackType)
                .setAllowAdaptiveSelections(false)
                .setAllowMultipleOverrides(false)
                .setShowDisableOption(trackType == C.TRACK_TYPE_TEXT)
                .build()
                .show();
    }

    private void openSubtitleSize() {
        final String[] sizes = {"Pequena", "Normal", "Grande"};
        new AlertDialog.Builder(this)
                .setTitle("Tamanho da legenda")
                .setSingleChoiceItems(sizes, 1, (dialog, which) -> {
                    if (b.playerView.getSubtitleView() != null) {
                        float size = which == 0 ? 0.042f : (which == 2 ? 0.065f : 0.0533f);
                        b.playerView.getSubtitleView().setFractionalTextSize(size);
                    }
                    dialog.dismiss();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void startUrl(String url) {
        if (player == null) return;
        MediaItem.Builder item = new MediaItem.Builder().setUri(Uri.parse(url));
        String lower = url.toLowerCase(java.util.Locale.US);
        if (lower.contains(".m3u8")) item.setMimeType(MimeTypes.APPLICATION_M3U8);
        else if (lower.contains(".ts")) item.setMimeType(MimeTypes.VIDEO_MP2T);
        player.setMediaItem(item.build());
        if (vodMode && initialResumeMs > 0L) player.seekTo(initialResumeMs);
        player.setPlayWhenReady(true);
        player.prepare();
    }

    private void saveProgress() {
        if (!vodMode || player == null || progressStore == null || progressKey.isEmpty() || (control != null && !control.resumeEnabled())) return;
        long position = Math.max(0L, player.getCurrentPosition());
        long duration = Math.max(0L, player.getDuration());
        progressStore.save(progressKey, position, duration);
    }

    @Override protected void onStop() {
        saveProgress();
        super.onStop();
        if (player != null) player.pause();
    }

    @Override protected void onStart() {
        super.onStart();
        if (player != null && player.getMediaItemCount() > 0) player.play();
    }

    @Override protected void onDestroy() {
        progressHandler.removeCallbacksAndMessages(null);
        saveProgress();
        if (player != null) { player.release(); player = null; }
        super.onDestroy();
    }


    private void applyDefaultSubtitleSize() {
        if (b.playerView.getSubtitleView() == null || control == null) return;
        String value = control.subtitleSize();
        float size = "small".equalsIgnoreCase(value) ? 0.042f : ("large".equalsIgnoreCase(value) ? 0.065f : 0.0533f);
        b.playerView.getSubtitleView().setFractionalTextSize(size);
    }
    private static String safe(String value) { return value == null ? "" : value.trim(); }
}
