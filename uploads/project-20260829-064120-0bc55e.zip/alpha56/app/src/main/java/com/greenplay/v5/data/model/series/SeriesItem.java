package com.greenplay.v5.data.model.series;

public final class SeriesItem {
    public long id;
    public String name = "";
    public String cover = "";
    public String categoryId = "";
    public String year = "";
    public String rating = "";
}
