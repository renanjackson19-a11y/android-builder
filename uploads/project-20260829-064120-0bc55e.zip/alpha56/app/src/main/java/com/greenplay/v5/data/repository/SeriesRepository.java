package com.greenplay.v5.data.repository;

import android.os.Handler;
import android.os.Looper;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.greenplay.v5.core.network.HostNormalizer;
import com.greenplay.v5.core.network.NetworkProvider;
import com.greenplay.v5.core.network.XtreamApi;
import com.greenplay.v5.data.model.series.SeriesCategory;
import com.greenplay.v5.data.model.series.SeriesDetails;
import com.greenplay.v5.data.model.series.SeriesEpisode;
import com.greenplay.v5.data.model.series.SeriesItem;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public final class SeriesRepository {
    public interface CategoriesResult { void success(List<SeriesCategory> rows); void error(String message); }
    public interface SeriesResult { void success(List<SeriesItem> rows); void error(String message); }
    public interface DetailResult { void success(SeriesDetails detail); void error(String message); }

    private static final ExecutorService PARSER = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private final XtreamApi api;
    private final String host;
    private final String user;
    private final String pass;

    public SeriesRepository(String host, String user, String pass) {
        this.host = HostNormalizer.normalize(host);
        this.api = NetworkProvider.xtream(host);
        this.user = user;
        this.pass = pass;
    }

    public void categories(CategoriesResult result) {
        api.list(user, pass, "get_series_categories").enqueue(new Callback<JsonArray>() {
            @Override public void onResponse(Call<JsonArray> call, Response<JsonArray> response) {
                JsonArray body = response.body();
                if (!response.isSuccessful() || body == null) { result.error("Categorias de séries indisponíveis"); return; }
                PARSER.execute(() -> {
                    List<SeriesCategory> out = new ArrayList<>();
                    SeriesCategory all = new SeriesCategory(); all.id=""; all.name="TODOS"; out.add(all);
                    for (JsonElement e : body) {
                        if (!e.isJsonObject()) continue;
                        JsonObject o=e.getAsJsonObject();
                        SeriesCategory c=new SeriesCategory();
                        c.id=str(o,"category_id"); c.name=clean(str(o,"category_name"));
                        if (!c.id.isEmpty() && !c.name.isEmpty()) out.add(c);
                    }
                    MAIN.post(() -> result.success(out));
                });
            }
            @Override public void onFailure(Call<JsonArray> call, Throwable t) { result.error("Falha ao carregar categorias de séries"); }
        });
    }

    public void series(String categoryId, SeriesResult result) {
        Call<JsonArray> call = categoryId == null || categoryId.trim().isEmpty()
                ? api.list(user, pass, "get_series")
                : api.listByCategory(user, pass, "get_series", categoryId.trim());
        call.enqueue(new Callback<JsonArray>() {
            @Override public void onResponse(Call<JsonArray> call, Response<JsonArray> response) {
                JsonArray body=response.body();
                if(!response.isSuccessful()||body==null){result.error("Séries indisponíveis");return;}
                PARSER.execute(() -> {
                    List<SeriesItem> out=new ArrayList<>(); Set<Long> ids=new HashSet<>(); Set<String> keys=new HashSet<>();
                    for(JsonElement e:body){if(!e.isJsonObject())continue;JsonObject o=e.getAsJsonObject();long id=longVal(o,"series_id");if(id<=0||!ids.add(id))continue;
                        SeriesItem row=new SeriesItem();row.id=id;row.name=clean(first(str(o,"name"),str(o,"title"),"Série"));row.cover=image(first(str(o,"cover"),str(o,"stream_icon")));row.categoryId=str(o,"category_id");row.year=first(str(o,"year"),yearFromDate(str(o,"releaseDate")),yearFromDate(str(o,"release_date")));row.rating=str(o,"rating");
                        String k=key(row.name,row.year);if(!k.isEmpty()&&!keys.add(k))continue;out.add(row);
                    }
                    MAIN.post(() -> result.success(out));
                });
            }
            @Override public void onFailure(Call<JsonArray> call, Throwable t){result.error("Falha ao carregar séries");}
        });
    }

    public void detail(long seriesId, DetailResult result) {
        api.seriesInfo(user, pass, "get_series_info", seriesId).enqueue(new Callback<JsonObject>() {
            @Override public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                JsonObject body=response.body(); if(!response.isSuccessful()||body==null){result.error("Detalhes da série indisponíveis");return;}
                PARSER.execute(() -> {
                    SeriesDetails d=new SeriesDetails();
                    JsonObject info=obj(body,"info");
                    d.name=clean(first(str(info,"name"),str(info,"title"),"Série"));
                    d.cover=image(first(str(info,"cover"),str(info,"movie_image"),str(info,"stream_icon")));
                    JsonArray backs=array(info,"backdrop_path"); if(backs!=null&&backs.size()>0) d.backdrop=image(asString(backs.get(0)));
                    d.plot=first(str(info,"plot"),str(info,"description")); d.genre=str(info,"genre"); d.releaseDate=first(str(info,"releaseDate"),str(info,"release_date")); d.rating=str(info,"rating");
                    JsonObject episodes=obj(body,"episodes");
                    if(episodes!=null){for(String seasonKey:episodes.keySet()){JsonArray list=array(episodes,seasonKey);if(list==null)continue;int season=parseInt(seasonKey,0);for(JsonElement ee:list){if(!ee.isJsonObject())continue;JsonObject o=ee.getAsJsonObject();SeriesEpisode ep=new SeriesEpisode();ep.id=longVal(o,"id");if(ep.id<=0)continue;ep.season=season>0?season:intVal(o,"season");ep.episode=intVal(o,"episode_num");ep.title=clean(first(str(o,"title"),"Episódio "+(ep.episode>0?ep.episode:"")));ep.extension=first(str(o,"container_extension"),"mp4");JsonObject ei=obj(o,"info");ep.image=image(first(str(ei,"movie_image"),str(ei,"cover_big"),str(ei,"cover")));ep.plot=first(str(ei,"plot"),str(ei,"description"));ep.duration=first(str(ei,"duration"),str(ei,"duration_secs"));ep.rating=str(ei,"rating");d.episodes.add(ep);}}}
                    Collections.sort(d.episodes, Comparator.comparingInt((SeriesEpisode x)->x.season).thenComparingInt(x->x.episode));
                    MAIN.post(() -> result.success(d));
                });
            }
            @Override public void onFailure(Call<JsonObject> call, Throwable t){result.error("Falha ao carregar temporadas");}
        });
    }

    private String image(String raw){if(raw==null)return "";String u=raw.trim().replace("\\/","/").replace(" ","%20");if(u.isEmpty())return "";if(u.startsWith("//"))return(host.startsWith("https://")?"https:":"http:")+u;if(u.startsWith("http://")||u.startsWith("https://"))return u;if(u.startsWith("/"))return host+u;return host+"/"+u;}
    private static JsonObject obj(JsonObject o,String k){try{JsonElement e=o.get(k);return e!=null&&e.isJsonObject()?e.getAsJsonObject():null;}catch(Exception e){return null;}}
    private static JsonArray array(JsonObject o,String k){try{JsonElement e=o.get(k);return e!=null&&e.isJsonArray()?e.getAsJsonArray():null;}catch(Exception e){return null;}}
    private static String str(JsonObject o,String k){try{if(o==null)return "";JsonElement e=o.get(k);return e==null||e.isJsonNull()?"":e.getAsString();}catch(Exception e){return "";}}
    private static long longVal(JsonObject o,String k){try{return o.get(k).getAsLong();}catch(Exception e){return 0L;}}
    private static int intVal(JsonObject o,String k){try{return o.get(k).getAsInt();}catch(Exception e){return 0;}}
    private static int parseInt(String s,int f){try{return Integer.parseInt(s);}catch(Exception e){return f;}}
    private static String asString(JsonElement e){try{return e==null||e.isJsonNull()?"":e.getAsString();}catch(Exception ex){return "";}}
    private static String clean(String s){if(s==null)return "";return s.replace("\\/","/").replace("\n"," ").replace("\r"," ").replaceAll("\\s{2,}"," ").trim();}
    private static String key(String n,String y){String a=n==null?"":n.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}]+","");return a.isEmpty()?"":a+"|"+(y==null?"":y.trim());}
    private static String yearFromDate(String raw){if(raw==null)return "";String s=raw.trim();return s.length()>=4?s.substring(0,4):"";}
    private static String first(String...v){if(v!=null)for(String x:v)if(x!=null&&!x.trim().isEmpty())return x.trim();return "";}
}
