package com.greenplay.v5.core.network;

import android.content.Context;
import com.greenplay.v5.BuildConfig;
import java.util.concurrent.TimeUnit;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public final class NetworkProvider {
    private static PanelApi panelApi;
    private NetworkProvider() {}

    public static void init(Context context) {
        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
        logging.setLevel(BuildConfig.DEBUG ? HttpLoggingInterceptor.Level.BASIC : HttpLoggingInterceptor.Level.NONE);

        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .readTimeout(25, TimeUnit.SECONDS)
                .callTimeout(35, TimeUnit.SECONDS)
                .addInterceptor(chain -> {
                    okhttp3.Request.Builder b = chain.request().newBuilder()
                            .header("Accept", "application/json")
                            .header("User-Agent", "GreenPlay/5 Android");
                    if (!BuildConfig.APP_TOKEN.isEmpty()) b.header("X-App-Token", BuildConfig.APP_TOKEN);
                    return chain.proceed(b.build());
                })
                .addInterceptor(logging)
                .build();

        panelApi = new Retrofit.Builder()
                .baseUrl(BuildConfig.APP_CONTROL_BASE_URL)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(PanelApi.class);
    }

    public static PanelApi panel() {
        if (panelApi == null) throw new IllegalStateException("NetworkProvider not initialized");
        return panelApi;
    }

    public static XtreamApi xtream(String host) {
        String normalized = HostNormalizer.normalize(host) + "/";
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .readTimeout(25, TimeUnit.SECONDS)
                .callTimeout(35, TimeUnit.SECONDS)
                .addInterceptor(chain -> chain.proceed(chain.request().newBuilder()
                        .header("Cache-Control", "no-cache, no-store, max-age=0")
                        .header("Pragma", "no-cache")
                        .build()))
                .build();
        return new Retrofit.Builder()
                .baseUrl(normalized)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(XtreamApi.class);
    }
}
