package com.greenplay.v5.core.session;

import android.content.Context;
import android.content.SharedPreferences;

public final class SessionStore {
    private static final String PREF = "green_play_v5_session";
    private final SharedPreferences prefs;
    public SessionStore(Context c) { prefs = c.getSharedPreferences(PREF, Context.MODE_PRIVATE); }

    public void save(String host, String user, String pass, String expires, String plan, boolean adult, String token) {
        prefs.edit()
                .putBoolean("logged", true)
                .putString("host", host == null ? "" : host)
                .putString("user", user == null ? "" : user)
                .putString("pass", pass == null ? "" : pass)
                .putString("expires", expires == null ? "" : expires)
                .putString("plan", plan == null ? "" : plan)
                .putBoolean("adult", adult)
                .putString("token", token == null ? "" : token)
                .apply();
    }
    public boolean isLogged() { return prefs.getBoolean("logged", false); }
    public String host() { return prefs.getString("host", ""); }
    public String user() { return prefs.getString("user", ""); }
    public String pass() { return prefs.getString("pass", ""); }
    public String expires() { return prefs.getString("expires", ""); }
    public String plan() { return prefs.getString("plan", ""); }
    public boolean adult() { return prefs.getBoolean("adult", false); }
    public String token() { return prefs.getString("token", ""); }
    public void clear() { prefs.edit().clear().apply(); }
}
