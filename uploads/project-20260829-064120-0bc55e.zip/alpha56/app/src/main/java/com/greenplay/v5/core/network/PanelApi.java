package com.greenplay.v5.core.network;

import com.greenplay.v5.data.model.AppConfigResponse;
import com.greenplay.v5.data.model.StatusResponse;
import retrofit2.Call;
import retrofit2.http.GET;

/** API do painel independente do aplicativo. Não autentica cliente IPTV. */
public interface PanelApi {
    @GET("status.php") Call<StatusResponse> status();
    @GET("app_config.php") Call<AppConfigResponse> appConfig();
}
