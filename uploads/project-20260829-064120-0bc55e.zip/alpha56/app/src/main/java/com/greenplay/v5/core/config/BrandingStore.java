package com.greenplay.v5.core.config;

import android.content.Context;
import android.content.SharedPreferences;
import com.greenplay.v5.core.network.PanelHost;
import com.greenplay.v5.data.model.AppConfigResponse;

public final class BrandingStore {
    private static final String PREF="green_play_v5_branding";
    private final SharedPreferences p;
    public BrandingStore(Context c){p=c.getSharedPreferences(PREF,Context.MODE_PRIVATE);}
    public void save(AppConfigResponse.Branding b){
        if(b==null)return;
        p.edit()
          .putString("app_name",nz(b.appName)).putString("support",nz(b.supportWhatsapp))
          .putString("accent",nz(b.accentColor)).putString("secondary",nz(b.secondaryColor)).putString("logo",nz(b.logo))
          .putString("background",nz(b.background)).putString("splash",nz(b.splash)).putString("banner",nz(b.banner))
          .putString("fallback",nz(b.fallbackCover)).putString("movie_cover",nz(b.movieCover)).putString("series_cover",nz(b.seriesCover)).putString("account_title",nz(b.accountTitle))
          .putString("about",nz(b.aboutText)).putLong("version",b.brandingVersion)
          .putBoolean("show_parental",b.showParental).putBoolean("show_favorites",b.showFavorites)
          .putBoolean("show_update",b.showUpdate).putBoolean("show_clear_cache",b.showClearCache)
          .putBoolean("show_support",b.showSupport).putBoolean("show_about",b.showAbout).apply();
    }
    public boolean showFavorites(){return p.getBoolean("show_favorites",true);}
    public boolean showParental(){return p.getBoolean("show_parental",true);}
    public boolean showUpdate(){return p.getBoolean("show_update",true);}
    public boolean showClearCache(){return p.getBoolean("show_clear_cache",true);}
    public boolean showSupport(){return p.getBoolean("show_support",true);}
    public boolean showAbout(){return p.getBoolean("show_about",true);}
    public String appName(){return p.getString("app_name","GREEN PLAY");}
    public String support(){return p.getString("support","");}
    public String accent(){return p.getString("accent","#29E76F");}
    public String secondary(){return p.getString("secondary","#0DB94A");}
    public String logo(){return p.getString("logo","");}
    public String background(){return p.getString("background","");}
    public String splash(){return p.getString("splash","");}
    public String banner(){return p.getString("banner","");}
    public String fallback(){return p.getString("fallback","");}
    public String movieCover(){return p.getString("movie_cover","");}
    public String seriesCover(){return p.getString("series_cover","");}
    public String accountTitle(){return p.getString("account_title","GREEN PLAY • SUA CENTRAL DE ENTRETENIMENTO");}
    public String about(){return p.getString("about","");}
    public long version(){return p.getLong("version",0L);}
    public String absolute(String raw){
        if(raw==null)return "";String s=raw.trim();if(s.isEmpty())return "";
        if(s.startsWith("http://")||s.startsWith("https://"))return s;
        String root=PanelHost.root();if(root.endsWith("/"))root=root.substring(0,root.length()-1);
        return root+(s.startsWith("/")?s:"/"+s);
    }
    private static String nz(String s){return s==null?"":s;}
}
