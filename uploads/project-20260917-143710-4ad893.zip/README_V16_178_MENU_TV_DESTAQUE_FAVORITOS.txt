GreenPlay v16.178

Base: v16.177

Ajuste solicitado no menu superior do modo TV/Android TV/TV Box:
- TV
- Destaque (logo após TV)
- Futebol
- Filmes
- Séries
- Kids
- Favoritos (no final das categorias)

Destaque abre a tela principal/recomendações.
Favoritos abre a lista de conteúdos favoritados.
O fluxo de foco/D-pad foi atualizado para incluir os dois novos itens.
Nenhuma alteração foi feita no player, EPG, estabilidade ou demais telas nesta versão.
