GreenPlay v16.184
- Corrige diferença entre celular e TV/TV Box no carregamento de canais.
- O modo TV agora usa primeiro o mesmo live_channels já carregado no bootstrap que o celular usa.
- Em seguida tenta atualizar via get_channel em segundo plano.
- Se a atualização direta falhar, não apaga a lista que já veio do snapshot.
- currentProviderHasLive também reconhece os canais presentes no snapshot.
