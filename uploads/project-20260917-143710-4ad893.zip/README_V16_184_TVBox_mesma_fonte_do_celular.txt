GreenPlay v16.184

Correção principal:
- TV Box/Android TV passa a usar primeiro o mesmo live_channels provider-specific carregado no bootstrap que já funciona no celular.
- Só cai para get_channel direto quando esse snapshot não tiver canais úteis para a categoria/busca atual.
- Mantém o fallback get_channel e type=live da v16.183.
- Evita o cenário em que celular mostra canais e TV/TV Box fica vazia por seguir uma rota diferente de dados.
