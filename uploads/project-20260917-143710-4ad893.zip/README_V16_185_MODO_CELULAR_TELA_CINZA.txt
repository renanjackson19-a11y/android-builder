GreenPlay v16.185

Correções incluídas:
- resolve a tela cinza ao trocar do modo TV para o modo celular;
- ao mudar o modo, o app reinicia a MainActivity de forma limpa, sem usar apenas recreate();
- limpa os flags de fullscreen/imersivo ao voltar para o modo celular;
- mantém a correção da lista de canais da TV/TV Box usando a mesma base do celular.
