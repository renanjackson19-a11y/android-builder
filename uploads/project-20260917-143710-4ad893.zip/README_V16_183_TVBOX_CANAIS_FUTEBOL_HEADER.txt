GreenPlay v16.183

Base: v16.182

Correções:
- TV Box/Android TV: carregamento de canais usa primeiro o formato legado sem type, igual às versões que funcionavam no celular; se necessário usa fallback type=live.
- Prova de existência de TV ao vivo também usa o formato legado primeiro.
- Em TV real não usa amostra/cache de live como lista final: busca a lista completa direto do servidor.
- Se categorias live falharem, mantém TODOS e carrega canais diretamente.
- Retry automático de canais após falha temporária.
- Ícone Futebol adicionado com a arte enviada pelo usuário.
- Cabeçalho reorganizado para Favoritos e Alterar servidor não cortarem em resoluções menores.
