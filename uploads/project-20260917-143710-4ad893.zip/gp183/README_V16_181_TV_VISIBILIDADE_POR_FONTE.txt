GreenPlay v16.181

- Corrige a detecção real de canais ao vivo ao trocar de servidor.
- Antes de montar o menu, testa get_channel(type=live, limit=1) quando o snapshot não trouxe live_channels.
- Se a fonte realmente não tiver canais ao vivo, o item TV é removido do menu.
- Se a fonte tiver ao menos um canal, TV aparece e carrega normalmente em Android TV/TV Box.
- A mesma regra passa a valer também no menu do celular.
- Mantém Kids com ícone, Destaque/Favoritos, Alterar servidor e correções anteriores do player/EPG.
