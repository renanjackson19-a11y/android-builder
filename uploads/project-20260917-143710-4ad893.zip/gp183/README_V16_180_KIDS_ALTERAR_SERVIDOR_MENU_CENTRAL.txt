GreenPlay v16.180

Base: v16.179
- mantém a correção de carregamento de canais em Android TV/TV Box da v16.179
- usa o ícone Kids colorido enviado pelo usuário no menu superior
- troca o botão simbólico por texto "Alterar servidor"
- centraliza melhor TV, Destaque, Futebol, Filmes, Séries, Kids e Favoritos
- preserva D-pad/foco remoto
