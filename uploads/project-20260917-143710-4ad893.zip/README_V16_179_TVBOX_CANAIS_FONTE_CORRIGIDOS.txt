GreenPlay v16.179

Correção específica para Android TV / TV Box:
- TV não depende mais de provider_live_count/has_live para tentar carregar a lista real.
- bootstrap sempre pede live quando o plano permite, mesmo em aparelho novo sem cache.
- snapshot live vazio deixa de bloquear o fallback direto get_channel.
- get_channel recebe type=live, limite maior e retry sem categoria quando necessário.
- troca de servidor limpa categoria/busca/canal antigos antes de carregar a nova fonte.
- respostas atrasadas de servidor anterior são ignoradas para evitar lista errada/vazia após alternar servidor.
- quando canais reais chegam, capability live é atualizada no aparelho.

Base: v16.178
VersionName: 1.16.179.0
VersionCode: 199
