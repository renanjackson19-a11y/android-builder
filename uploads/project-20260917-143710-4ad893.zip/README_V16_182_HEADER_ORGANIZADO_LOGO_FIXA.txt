GreenPlay v16.182

Base: v16.181

Ajustes do cabeçalho TV/TV Box:
- Logo passa a ser apenas visual: sem clique e sem foco D-pad.
- Removida a moldura/quadrado da logo.
- Menu superior centralizado com áreas laterais simétricas.
- Favoritos não fica mais cortado.
- Botão "Alterar servidor" passa a caber por completo.
- Redimensionamento dos itens do menu para melhor compatibilidade com 720p/1080p.
- Mantidas as correções de canais reais em Android TV/TV Box da v16.181.
