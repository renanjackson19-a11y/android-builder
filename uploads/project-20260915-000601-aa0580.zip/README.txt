GREENPLAY ANDROID NATIVO 1.0
- Projeto novo, sem DTLive.
- Android 7.1+ (API 25), celular/tablet/Android TV/Google TV.
- Login: código da revenda + usuário/e-mail + senha.
- Home, Filmes/Séries, busca, detalhes, player, favoritos, perfil, assinatura PIX e suporte por revenda.
- Release com minify + shrinkResources para APK pequeno.
- Requer o patch de painel GreenPlay v40 Multi-Revenda incluído separadamente.
