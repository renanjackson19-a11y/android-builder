package com.ativacao.app;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import androidx.media3.exoplayer.upstream.DefaultBandwidthMeter;

import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.common.PlaybackException;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.PlayerView;
import androidx.media3.ui.AspectRatioFrameLayout;

import java.util.ArrayList;
import java.util.List;

/** TV: lista/categorias à esquerda + preview à direita. Primeiro OK seleciona; segundo OK abre tela cheia. */
public class LiveTvActivity extends android.app.Activity {
    private final List<ApiClient.Item> allChannels = new ArrayList<>();
    private LinearLayout rows;
    private PlayerView preview;
    private FrameLayout playerCard;
    private FrameLayout shell, fullscreenLayer;
    private LinearLayout content, rightColumn;
    private LinearLayout.LayoutParams playerNormalLp;
    private boolean fullscreen = false;
    private ExoPlayer player;
    private TextView title, epgNow, epgNext, hint;
    private ProgressBar loading;
    private ApiClient.Item current;
    private View currentRow;
    private long armedChannelId = -1L;
    private int channelLoadToken = 0;
    private String listMode = "all";
    private String searchQuery = "";
    private boolean adultOnly = false;
    private TextView tabAll, tabFav, tabRecent;
    private ProgressBar epgProgress;
    private TextView epgNowTitle, epgNowTime, epgNextTitle, epgNextTime;
    private String requestedChannelName="";
    private boolean refreshLiveOnResume = false;
    private EditText searchBox;
    private View previewOverlay;
    private final Handler overlayHandler = new Handler(Looper.getMainLooper());
    private final Runnable hideOverlayTask = () -> { if (previewOverlay != null) previewOverlay.setVisibility(View.GONE); };
    private boolean launchedDirectPlayer = false;
    private FrameLayout fullscreenChrome;
    private LinearLayout fullscreenDrawerRows;
    private EditText fullscreenSearch;
    private TextView fullscreenClock, fullscreenSpeed, loadingSpeed;
    private View fullscreenDrawer;
    private DefaultBandwidthMeter bandwidthMeter;
    private final Handler statsHandler = new Handler(Looper.getMainLooper());
    private final Runnable statsTask = new Runnable(){ @Override public void run(){ updateFullscreenStats(); statsHandler.postDelayed(this,1000); } };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        adultOnly=getIntent().getBooleanExtra("adult_only",false);
        requestedChannelName=getIntent().getStringExtra("open_channel_name"); if(requestedChannelName==null)requestedChannelName="";
        FreeFootballSource.preload();
        immersive();
        setContentView(build());
        loadChannels();
    }

    private void warmMediaCatalog(){
        warmMediaType("movie",48);
        warmMediaType("series",30);
    }

    private void warmMediaType(String type,int limit){
        ApiClient.catalog(type,1,limit,"","","",new ApiClient.Callback<ApiClient.CatalogPage>(){
            @Override public void ok(ApiClient.CatalogPage p){
                if(p==null)return;
                int max=Math.min(p.items.size(),24);
                for(int n=0;n<max;n++){
                    ApiClient.Item i=p.items.get(n);
                    if(i==null)continue;
            if(isAdultChannelName(i.name))continue;
                    if(!i.tmdbLoaded){
                        ApiClient.tmdbEnrich(i,new ApiClient.Callback<ApiClient.Item>(){
                            @Override public void ok(ApiClient.Item x){
                                ImageLoader.preload(LiveTvActivity.this,cleanWarm(x.logo,x.backdrop));
                            }
                            @Override public void error(String m){ ImageLoader.preload(LiveTvActivity.this,cleanWarm(i.logo,i.backdrop)); }
                        });
                    }else ImageLoader.preload(LiveTvActivity.this,cleanWarm(i.logo,i.backdrop));
                }
            }
            @Override public void error(String m){}
        });
    }

    private String cleanWarm(String a,String b){
        String x=a==null?"":a.trim();
        if(!x.isEmpty()&&!"null".equalsIgnoreCase(x))return x;
        x=b==null?"":b.trim();
        return "null".equalsIgnoreCase(x)?"":x;
    }

    private View build() {
        shell=new FrameLayout(this);

        LinearLayout root=Ui.column(this);
        root.setBackground(Ui.diagonalGradient(0xFF061109,0xFF010302,0,this));
        shell.addView(root,new FrameLayout.LayoutParams(-1,-1));

        fullscreenLayer=new FrameLayout(this);
        fullscreenLayer.setBackgroundColor(Color.BLACK);
        statsHandler.removeCallbacks(statsTask);
        fullscreenLayer.setVisibility(View.GONE);
        shell.addView(fullscreenLayer,new FrameLayout.LayoutParams(-1,-1));

        root.addView(YellowNav.bar(this,"TV"),new LinearLayout.LayoutParams(-1,Ui.dp(this,64)));

        // Busca fica no topo, separada da lista de canais, como em players IPTV profissionais.
        LinearLayout searchTop=new LinearLayout(this);
        searchTop.setOrientation(LinearLayout.HORIZONTAL);
        searchTop.setGravity(Gravity.CENTER_VERTICAL);
        searchTop.setPadding(Ui.dp(this,26),Ui.dp(this,7),Ui.dp(this,18),Ui.dp(this,5));
        EditText search=new EditText(this);
        searchBox=search;
        search.setSingleLine(true);
        search.setHint("Pesquisar canais...");
        search.setHintTextColor(0xFF8E9890);
        search.setTextColor(Color.WHITE);
        search.setTextSize(12);
        search.setPadding(Ui.dp(this,16),0,Ui.dp(this,16),0);
        search.setBackground(Ui.stroke(0xD908100B,Ui.GREEN,18,this));
        searchTop.addView(search,new LinearLayout.LayoutParams(Ui.dp(this,355),Ui.dp(this,42)));
        View searchSpacer=new View(this);
        searchTop.addView(searchSpacer,new LinearLayout.LayoutParams(0,Ui.dp(this,42),1));
        root.addView(searchTop,new LinearLayout.LayoutParams(-1,Ui.dp(this,54)));

        LinearLayout main=new LinearLayout(this);
        main.setOrientation(LinearLayout.HORIZONTAL);
        main.setPadding(Ui.dp(this,18),Ui.dp(this,2),Ui.dp(this,18),Ui.dp(this,8));

        // LEFT
        LinearLayout left=Ui.column(this);
        left.setPadding(Ui.dp(this,8),0,Ui.dp(this,10),0);
        left.setBackground(Ui.round(0xCC08100B,10,this));

        TextView section=Ui.text(this,"LISTA DE CANAIS",13,0xFFEAF1EC,true);
        section.setGravity(Gravity.CENTER_VERTICAL);
        left.addView(section,new LinearLayout.LayoutParams(-1,Ui.dp(this,30)));

        LinearLayout filters=new LinearLayout(this);
        filters.setGravity(Gravity.CENTER_VERTICAL);
        tabAll=filterButton("TODOS",true);
        tabFav=filterButton("FAVORITOS",false);
        tabRecent=filterButton("RECENTES",false);
        filters.addView(tabAll,new LinearLayout.LayoutParams(0,Ui.dp(this,36),1));
        filters.addView(tabFav,new LinearLayout.LayoutParams(0,Ui.dp(this,36),1));
        filters.addView(tabRecent,new LinearLayout.LayoutParams(0,Ui.dp(this,36),1));
        TextView refresh=filterButton("↻",false);
        filters.addView(refresh,new LinearLayout.LayoutParams(Ui.dp(this,42),Ui.dp(this,36)));
        refresh.setOnClickListener(v->{CatalogPreloader.start(LiveTvActivity.this,true,()->runOnUiThread(()->{allChannels.clear();loadChannels();}));});
        LinearLayout.LayoutParams flp=new LinearLayout.LayoutParams(-1,Ui.dp(this,42));
        flp.topMargin=Ui.dp(this,7);flp.bottomMargin=Ui.dp(this,4);
        left.addView(filters,flp);

        tabAll.setOnClickListener(v->{listMode="all";updateFilterButtons();renderRowsFiltered(searchQuery);});
        tabFav.setOnClickListener(v->{listMode="fav";updateFilterButtons();renderRowsFiltered(searchQuery);});
        tabRecent.setOnClickListener(v->{listMode="recent";updateFilterButtons();renderRowsFiltered(searchQuery);});

        ScrollView sc=new ScrollView(this);
        sc.setVerticalScrollBarEnabled(false);
        sc.setFillViewport(true);
        rows=Ui.column(this);
        sc.addView(rows,new ScrollView.LayoutParams(-1,-2));
        left.addView(sc,new LinearLayout.LayoutParams(-1,0,1));

        search.addTextChangedListener(new android.text.TextWatcher(){
            public void beforeTextChanged(CharSequence cs,int st,int c,int a){}
            public void onTextChanged(CharSequence cs,int st,int b,int c){
                searchQuery=cs==null?"":cs.toString();
                renderRowsFiltered(searchQuery);
            }
            public void afterTextChanged(android.text.Editable e){}
        });

        LinearLayout.LayoutParams llp=new LinearLayout.LayoutParams(Ui.dp(this,380),-1);
        llp.rightMargin=Ui.dp(this,10);
        main.addView(left,llp);

        // RIGHT / PLAYER
        rightColumn=Ui.column(this);
        playerCard=new FrameLayout(this);
        playerCard.setFocusable(true);playerCard.setClickable(true);
        playerCard.setBackground(Ui.round(Color.BLACK,8,this));

        preview=new PlayerView(this);
        preview.setUseController(false);preview.setKeepScreenOn(true);preview.setFocusable(false);
        preview.setBackgroundColor(Color.BLACK);
        preview.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_ZOOM);
        playerCard.addView(preview,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout loadingBox=Ui.column(this);
        loadingBox.setGravity(Gravity.CENTER);
        loading=new ProgressBar(this);
        loadingBox.addView(loading,new LinearLayout.LayoutParams(Ui.dp(this,42),Ui.dp(this,42)));
        loadingSpeed=Ui.text(this,"0 Kbps",10,Color.WHITE,true);
        loadingSpeed.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lsp=new LinearLayout.LayoutParams(Ui.dp(this,130),Ui.dp(this,26));lsp.topMargin=Ui.dp(this,6);
        loadingBox.addView(loadingSpeed,lsp);
        playerCard.addView(loadingBox,new FrameLayout.LayoutParams(Ui.dp(this,150),Ui.dp(this,82),Gravity.CENTER));
        loading.setTag(loadingBox);

        LinearLayout stats=Ui.row(this);
        stats.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);
        stats.setPadding(Ui.dp(this,10),0,Ui.dp(this,10),0);
        stats.setBackground(Ui.round(0x99050806,12,this));
        fullscreenClock=Ui.text(this,"--:--",11,Color.WHITE,true);
        fullscreenClock.setGravity(Gravity.CENTER);
        stats.addView(fullscreenClock,new LinearLayout.LayoutParams(Ui.dp(this,72),Ui.dp(this,34)));
        fullscreenSpeed=Ui.text(this,"0 Kbps",10,0xFFE7ECE9,true);
        fullscreenSpeed.setGravity(Gravity.CENTER);
        stats.addView(fullscreenSpeed,new LinearLayout.LayoutParams(Ui.dp(this,88),Ui.dp(this,34)));
        FrameLayout.LayoutParams stp=new FrameLayout.LayoutParams(Ui.dp(this,170),Ui.dp(this,38),Gravity.TOP|Gravity.RIGHT);
        stp.topMargin=Ui.dp(this,12);stp.rightMargin=Ui.dp(this,16);
        playerCard.addView(stats,stp);

        LinearLayout overlay=Ui.column(this);
        previewOverlay=overlay;
        overlay.setPadding(Ui.dp(this,16),Ui.dp(this,9),Ui.dp(this,16),Ui.dp(this,8));
        overlay.setBackground(Ui.verticalGradient(0xDD0A0E0C,0xF20A0E0C,10,this));

        LinearLayout topEpg=new LinearLayout(this);
        topEpg.setGravity(Gravity.CENTER_VERTICAL);
        ImageView epgLogo=new ImageView(this); epgLogo.setId(0x1FA001); epgLogo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        topEpg.addView(epgLogo,new LinearLayout.LayoutParams(Ui.dp(this,82),Ui.dp(this,58)));

        LinearLayout centerInfo=Ui.column(this);
        LinearLayout channelLine=Ui.row(this); channelLine.setGravity(Gravity.CENTER_VERTICAL);
        TextView chNum=Ui.text(this,"1",18,Color.WHITE,true); chNum.setId(0x1FA002);
        channelLine.addView(chNum,new LinearLayout.LayoutParams(Ui.dp(this,46),Ui.dp(this,28)));
        title=Ui.text(this,"Canal",15,Color.WHITE,true); title.setMaxLines(1);
        channelLine.addView(title,new LinearLayout.LayoutParams(0,Ui.dp(this,28),1));
        centerInfo.addView(channelLine,new LinearLayout.LayoutParams(-1,Ui.dp(this,30)));
        epgNow=Ui.text(this,"AGORA",8,Ui.GREEN,true);
        epgNowTitle=Ui.text(this,"Carregando programação...",10,Color.WHITE,false);epgNowTitle.setMaxLines(1);
        epgNowTime=Ui.text(this,"",8,0xFFABB5AF,false);
        centerInfo.addView(epgNow,new LinearLayout.LayoutParams(-1,Ui.dp(this,15)));
        centerInfo.addView(epgNowTitle,new LinearLayout.LayoutParams(-1,Ui.dp(this,20)));
        centerInfo.addView(epgNowTime,new LinearLayout.LayoutParams(-1,Ui.dp(this,15)));
        topEpg.addView(centerInfo,new LinearLayout.LayoutParams(0,Ui.dp(this,80),1));

        View divider=new View(this);divider.setBackgroundColor(0x665A6A60);
        LinearLayout.LayoutParams dlp=new LinearLayout.LayoutParams(Ui.dp(this,1),Ui.dp(this,58));dlp.leftMargin=Ui.dp(this,12);dlp.rightMargin=Ui.dp(this,16);
        topEpg.addView(divider,dlp);

        LinearLayout nextBox=Ui.column(this);
        epgNext=Ui.text(this,"A SEGUIR",8,0xFFD4DBD7,true);
        epgNextTitle=Ui.text(this,"—",10,Color.WHITE,false);epgNextTitle.setMaxLines(1);
        epgNextTime=Ui.text(this,"",8,0xFFABB5AF,false);
        nextBox.addView(epgNext,new LinearLayout.LayoutParams(-1,Ui.dp(this,18)));
        nextBox.addView(epgNextTitle,new LinearLayout.LayoutParams(-1,Ui.dp(this,24)));
        nextBox.addView(epgNextTime,new LinearLayout.LayoutParams(-1,Ui.dp(this,18)));
        topEpg.addView(nextBox,new LinearLayout.LayoutParams(0,Ui.dp(this,72),0.75f));

        LinearLayout dateBox=Ui.column(this);dateBox.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);
        TextView epgDate=Ui.text(this,new SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).format(new Date()),10,0xFFD1D7D3,false); epgDate.setId(0x1FA003); epgDate.setGravity(Gravity.RIGHT);
        TextView liveBadge=Ui.text(this,"● AO VIVO",8,0xFFFF5E6F,true);liveBadge.setGravity(Gravity.RIGHT);
        dateBox.addView(epgDate,new LinearLayout.LayoutParams(-1,Ui.dp(this,28)));
        dateBox.addView(liveBadge,new LinearLayout.LayoutParams(-1,Ui.dp(this,22)));
        topEpg.addView(dateBox,new LinearLayout.LayoutParams(Ui.dp(this,130),Ui.dp(this,70)));
        overlay.addView(topEpg,new LinearLayout.LayoutParams(-1,Ui.dp(this,82)));

        epgProgress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);epgProgress.setVisibility(View.GONE);
        hint=Ui.text(this,"OK: canais • VOLTAR",7,0xFF89938D,false);hint.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        overlay.addView(hint,new LinearLayout.LayoutParams(-1,Ui.dp(this,13)));

        FrameLayout.LayoutParams olp=new FrameLayout.LayoutParams(-1,Ui.dp(this,108),Gravity.BOTTOM);
        olp.leftMargin=Ui.dp(this,0);olp.rightMargin=Ui.dp(this,0);olp.bottomMargin=0;
        playerCard.addView(overlay,olp);

        playerCard.setOnClickListener(v->{
            // A TV continua abrindo no layout normal (lista + preview).
            // Ao clicar no preview, abre o player em tela cheia com o menu lateral/EPG overlay.
            if(!fullscreen){
                // Mantém o MESMO ExoPlayer/stream ao ampliar o preview.
                // Não abre outra Activity e não prepara o canal novamente.
                openFullscreen();
                return;
            }
            if(fullscreen){
                toggleFullscreenDrawer();
                showPreviewOverlay();
            }
        });
        playerNormalLp=new LinearLayout.LayoutParams(-1,-1);
        rightColumn.addView(playerCard,playerNormalLp);
        main.addView(rightColumn,new LinearLayout.LayoutParams(0,-1,1));

        root.addView(main,new LinearLayout.LayoutParams(-1,0,1));

        // Bottom category strip: same composition as target mockup.
        // Navegação inferior removida: o menu superior já concentra as categorias.

        return shell;
    }

    private TextView filterButton(String text,boolean selected){
        TextView t=Ui.text(this,text,9,selected?Color.BLACK:0xFFDDE5DF,true);
        t.setGravity(Gravity.CENTER);t.setFocusable(true);t.setClickable(true);
        t.setBackground(selected?Ui.gradient(Ui.GREEN,Ui.GREEN_2,20,this):Ui.round(Color.TRANSPARENT,20,this));
        return t;
    }

    private void updateFilterButtons(){
        TextView[] bs={tabAll,tabFav,tabRecent};
        String[] ms={"all","fav","recent"};
        for(int i=0;i<bs.length;i++){
            boolean on=ms[i].equals(listMode);
            bs[i].setTextColor(on?Color.BLACK:0xFFDDE5DF);
            bs[i].setBackground(on?Ui.gradient(Ui.GREEN,Ui.GREEN_2,20,this):Ui.round(Color.TRANSPARENT,20,this));
        }
    }

    private void addCategoryTile(LinearLayout row,String label,String type,String smart,Runnable click){
        FrameLayout card=new FrameLayout(this);
        card.setFocusable(true);card.setClickable(true);card.setClipToOutline(true);
        Ui.focus(card,this,Ui.round(0xFF102018,9,this),Ui.stroke(0xFF102018,Ui.GREEN,9,this));

        ImageView img=new ImageView(this);img.setScaleType(ImageView.ScaleType.CENTER_CROP);img.setBackgroundColor(0xFF122018);
        card.addView(img,new FrameLayout.LayoutParams(-1,-1));

        View shade=new View(this);shade.setBackground(Ui.verticalGradient(0x22000000,0xE8000000,0,this));
        card.addView(shade,new FrameLayout.LayoutParams(-1,-1));

        TextView t=Ui.text(this,label,10,Color.WHITE,true);t.setGravity(Gravity.CENTER);
        card.addView(t,new FrameLayout.LayoutParams(-1,Ui.dp(this,34),Gravity.BOTTOM));
        card.setOnClickListener(v->click.run());

        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,1);
        lp.rightMargin=Ui.dp(this,8);row.addView(card,lp);

        ApiClient.catalog(type,1,1,"","",smart,new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){
                if(p!=null&&p.items!=null&&!p.items.isEmpty()){
                    ApiClient.Item it=p.items.get(0);
                    runOnUiThread(()->ImageLoader.into(LiveTvActivity.this,img,clean(it.backdrop,it.logo)));
                }
            }
            public void error(String m){}
        });
    }

    private void openCatalog(String type,String title,String smart){
        Intent i=new Intent(this,CatalogActivity.class);i.putExtra("type",type);i.putExtra("title",title);i.putExtra("smart",smart);startActivity(i);
    }
    private void openDiscover(String smart,String title){
        Intent i=new Intent(this,DiscoverActivity.class);i.putExtra("smart",smart);i.putExtra("title",title);startActivity(i);
    }

    private int phonePad(){return Ui.phone(this)?12:24;}
    private int phoneLeftWidth(){return Ui.phone(this)?315:380;}

    private void addNav(LinearLayout row,String label,boolean selected,Runnable action){
        TextView v=Ui.nav(this,label,selected); if(action!=null)v.setOnClickListener(x->action.run());
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1); row.addView(v,p);
    }

    private void loadChannels(){
        int token=++channelLoadToken;
        loadChannelPage(1, new ArrayList<>(), token);
    }

    private void loadChannelPage(int page, List<ApiClient.Item> acc, int token){
        if(token!=channelLoadToken || isFinishing() || isDestroyed()) return;
        ApiClient.catalog("live",page,72,"","","",new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){
                if(token!=channelLoadToken) return;
                int before=acc.size();
                if(p!=null && p.items!=null){
                    java.util.HashSet<Long> ids=new java.util.HashSet<>();
                    for(ApiClient.Item old:acc) ids.add(old.id);
                    for(ApiClient.Item item:p.items) if(item!=null && !ids.contains(item.id)){acc.add(item);ids.add(item.id);}
                }
                // Mostra a primeira página imediatamente. As demais entram em segundo plano,
                // então a tela não fica vazia esperando o catálogo inteiro.
                if(page==1 || page%3==0){
                    java.util.ArrayList<ApiClient.Item> snapshot=new java.util.ArrayList<>(acc);
                    runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())renderAll(snapshot);});
                }
                int pages=p==null?1:Math.max(1,p.pages);
                boolean apiHasNext=page<pages;
                boolean fullPage=p!=null && p.items!=null && p.items.size()>=72 && acc.size()>before;
                if(page<30 && (apiHasNext || fullPage)){ loadChannelPage(page+1,acc,token); return; }
                java.util.ArrayList<ApiClient.Item> snapshot=new java.util.ArrayList<>(acc);
                runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())renderAll(snapshot);});
            }
            public void error(String m){
                if(!acc.isEmpty()){java.util.ArrayList<ApiClient.Item> snapshot=new java.util.ArrayList<>(acc);runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())renderAll(snapshot);});return;}
                runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())Toast.makeText(LiveTvActivity.this,"Não foi possível carregar os canais",Toast.LENGTH_LONG).show();});
            }
        });
    }

    private void renderAll(List<ApiClient.Item> list){
        allChannels.clear(); if(list!=null)allChannels.addAll(list);
        renderRows();
    }


    private void renderRows(){ renderRowsFiltered(""); }

    private void renderRowsFiltered(String query){
        if(rows==null)return;
        rows.removeAllViews();
        String q=query==null?"":query.trim().toLowerCase(java.util.Locale.ROOT);

        List<ApiClient.Item> source=new ArrayList<>();
        if("fav".equals(listMode)){
            for(ApiClient.Item i:LocalStore.favorites(this))if(i!=null&&"live".equals(i.type))source.add(i);
        }else if("recent".equals(listMode)){
            for(ApiClient.Item i:LocalStore.history(this))if(i!=null&&"live".equals(i.type))source.add(i);
            ApiClient.Item last=LocalStore.lastLive(this);
            if(last!=null){
                boolean exists=false;for(ApiClient.Item x:source)if(x.id==last.id){exists=true;break;}
                if(!exists)source.add(0,last);
            }
        }else source.addAll(allChannels);

        List<ApiClient.Item> visible=new ArrayList<>();
        for(ApiClient.Item i:source){
            if(i==null)continue;
            boolean adult=isAdultChannelName(i.name)||isAdultChannelName(i.group);
            if(adultOnly && !adult)continue;
            if(!adultOnly && adult)continue;
            String nm=clean(i.name,"Canal").toLowerCase(java.util.Locale.ROOT);
            if(q.isEmpty()||nm.contains(q))visible.add(i);
        }

        if(visible.isEmpty()){
            TextView empty=Ui.text(this,"Nenhum canal encontrado",10,Ui.MUTED,false);
            empty.setGravity(Gravity.CENTER);
            rows.addView(empty,new LinearLayout.LayoutParams(-1,Ui.dp(this,90)));
            return;
        }

        boolean typedSearch=!q.isEmpty();
        ApiClient.Item last=LocalStore.lastLive(this);
        ApiClient.Item initial=null;
        if(!typedSearch){
            if(!requestedChannelName.trim().isEmpty()){
                String wanted=normalizeChannelName(requestedChannelName);
                for(ApiClient.Item x:visible){String nm=normalizeChannelName(x.name);if(nm.contains(wanted)||wanted.contains(nm)){initial=x;break;}}
            }
            if(initial==null&&current!=null)for(ApiClient.Item x:visible)if(x.id==current.id){initial=x;break;}
            if(initial==null&&last!=null)for(ApiClient.Item x:visible)if(x.id==last.id){initial=x;break;}
            if(initial==null)initial=visible.get(0);
        }

        View focus=null;
        int n=1;
        for(ApiClient.Item i:visible){
            LinearLayout r=new LinearLayout(this);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(Ui.dp(this,4),Ui.dp(this,3),Ui.dp(this,8),Ui.dp(this,3));
            r.setFocusable(true);r.setClickable(true);

            TextView num=Ui.text(this,String.valueOf(n++),11,Ui.GREEN,true);
            num.setGravity(Gravity.CENTER);
            r.addView(num,new LinearLayout.LayoutParams(Ui.dp(this,28),-1));

            ImageView logo=new ImageView(this);
            logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            logo.setBackground(Ui.round(0x20FFFFFF,7,this));
            ImageLoader.into(this,logo,i.logo);
            LinearLayout.LayoutParams lip=new LinearLayout.LayoutParams(Ui.dp(this,42),Ui.dp(this,42));
            lip.rightMargin=Ui.dp(this,10);
            r.addView(logo,lip);

            LinearLayout names=Ui.column(this);
            TextView nm=Ui.text(this,clean(i.name,"Canal"),12,Color.WHITE,true);
            nm.setMaxLines(1);
            names.addView(nm,new LinearLayout.LayoutParams(-1,0,1));

            if(i.group!=null&&!i.group.trim().isEmpty()){
                TextView grp=Ui.text(this,i.group,8,0xFF8F9991,false);
                grp.setMaxLines(1);
                names.addView(grp,new LinearLayout.LayoutParams(-1,Ui.dp(this,18)));
            }
            r.addView(names,new LinearLayout.LayoutParams(0,-1,1));

            TextView fav=Ui.text(this,LocalStore.isFavorite(this,i.id)?"★":"☆",16,
                    LocalStore.isFavorite(this,i.id)?Ui.GREEN:0xFF6F7771,true);
            fav.setGravity(Gravity.CENTER);fav.setFocusable(true);fav.setClickable(true);
            fav.setOnClickListener(v->{
                LocalStore.toggleFavorite(this,i);
                boolean yes=LocalStore.isFavorite(this,i.id);
                fav.setText(yes?"★":"☆");fav.setTextColor(yes?Ui.GREEN:0xFF6F7771);
            });
            r.addView(fav,new LinearLayout.LayoutParams(Ui.dp(this,38),-1));

            android.graphics.drawable.Drawable normal=Ui.round(0x18000000,7,this);
            android.graphics.drawable.Drawable focused=Ui.stroke(0xFF102016,Ui.GREEN,7,this);
            r.setBackground(normal);

            r.setOnFocusChangeListener((v,has)->{
                v.animate().scaleX(has?1.018f:1f).scaleY(has?1.018f:1f).setDuration(90).start();
                v.setBackground(has?focused:normal);
                if(has){
                    if(current==null||current.id!=i.id){armedChannelId=-1L;previewChannel(i,v);}
                    else currentRow=v;
                }
            });

            r.setOnClickListener(v->{
                if(current==null||current.id!=i.id){
                    armedChannelId=i.id;
                    previewChannel(i,v);
                    currentRow=v;
                    hint.setText("OK novamente: tela cheia");
                    return;
                }
                if(armedChannelId==i.id){openFullscreen();return;}
                armedChannelId=i.id;currentRow=v;hint.setText("OK novamente: tela cheia");
                showPreviewOverlay();
            });

            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,Ui.dp(this,56));
            rp.bottomMargin=Ui.dp(this,2);
            rows.addView(r,rp);
            if(initial!=null && i.id==initial.id)focus=r;
        }

        // Enquanto o usuário digita, apenas filtre a lista. Não troque o canal automaticamente.
        if(!typedSearch && initial!=null){
            previewChannel(initial,focus);
            if(focus!=null)focus.requestFocus();
            requestedChannelName="";
        }
    }

    private void previewChannel(ApiClient.Item i, View row){
        if(i==null)return;
        if(current!=null && current.id==i.id){currentRow=row;return;}
        current=i; currentRow=row; LocalStore.saveLastLive(this,i); LocalStore.addHistory(this,i);
        title.setText(clean(i.name,"Canal"));
        ImageView epgLogo=playerCard.findViewById(0x1FA001);if(epgLogo!=null)ImageLoader.into(this,epgLogo,i.logo);
        TextView chNum=playerCard.findViewById(0x1FA002);if(chNum!=null)chNum.setText(String.valueOf(channelNumber(i)));
        TextView dt=playerCard.findViewById(0x1FA003);if(dt!=null)dt.setText(new SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).format(new Date()));
        epgNow.setText("AGORA"); epgNext.setText("A SEGUIR");
        epgNowTitle.setText("Carregando programação...");epgNextTitle.setText("—");
        epgNowTime.setText("");epgNextTime.setText("");epgProgress.setProgress(35);
        hint.setText("OK seleciona • OK novamente abre tela cheia");
        showPreviewOverlay();
        loadEpg(i.id); startPreview(i.id);
    }

    private void showPreviewOverlay(){
        if(previewOverlay==null)return;
        previewOverlay.setVisibility(View.VISIBLE);
        schedulePreviewOverlayHide();
    }

    private void schedulePreviewOverlayHide(){
        overlayHandler.removeCallbacks(hideOverlayTask);
        overlayHandler.postDelayed(hideOverlayTask,4500);
    }

    private void hidePreviewOverlay(){
        overlayHandler.removeCallbacks(hideOverlayTask);
        if(previewOverlay!=null)previewOverlay.setVisibility(View.GONE);
    }

    private void startPreview(long id){
        if(isFinishing() || isDestroyed()) return;
        {View box=(View)loading.getTag();if(box!=null)box.setVisibility(View.VISIBLE);else loading.setVisibility(View.VISIBLE);}
        if(player!=null){try{preview.setPlayer(null);player.release();}catch(Exception ignored){} player=null;}
        try{
            String url=ApiClient.streamUrl(id);
            if(url==null || url.trim().isEmpty()) throw new IllegalArgumentException("URL do canal vazia");
            bandwidthMeter = new DefaultBandwidthMeter.Builder(this).build();
            DefaultHttpDataSource.Factory http=new DefaultHttpDataSource.Factory().setUserAgent("VLC/3.0.20 LibVLC/3.0.20").setConnectTimeoutMs(8000).setReadTimeoutMs(30000).setAllowCrossProtocolRedirects(true).setTransferListener(bandwidthMeter);
            player=new ExoPlayer.Builder(this).setMediaSourceFactory(new DefaultMediaSourceFactory(this).setDataSourceFactory(http)).build();
            preview.setPlayer(player);
            player.addListener(new Player.Listener(){
                @Override public void onPlaybackStateChanged(int state){if(state==Player.STATE_READY && loading!=null){View box=(View)loading.getTag();if(box!=null)box.setVisibility(View.GONE);else loading.setVisibility(View.GONE);}else if(state==Player.STATE_BUFFERING&&loading!=null){View box=(View)loading.getTag();if(box!=null)box.setVisibility(View.VISIBLE);}}
                @Override public void onPlayerError(PlaybackException error){
                    if(loading!=null){View box=(View)loading.getTag();if(box!=null)box.setVisibility(View.GONE);else loading.setVisibility(View.GONE);}
                    if(epgNowTitle!=null)epgNowTitle.setText("Sinal indisponível");
                }
            });
            player.setMediaItem(MediaItem.fromUri(url)); player.prepare(); player.play();
        }catch(Throwable e){
            loading.setVisibility(View.GONE);
            epgNowTitle.setText("Sinal indisponível");
        }
    }

    private void loadEpg(long id){
        ApiClient.epg(id,new ApiClient.Callback<ApiClient.EpgInfo>(){
            public void ok(ApiClient.EpgInfo e){runOnUiThread(()->{
                if(current==null||current.id!=id)return;
                epgNow.setText("AGORA");epgNext.setText("A SEGUIR");
                epgNowTitle.setText(clean(e.nowTitle,"Sem informação"));
                epgNextTitle.setText(clean(e.nextTitle,"—"));
                epgNowTime.setText(timeRange(e.nowStart,e.nowStop));
                epgNextTime.setText(clean(e.nextStart,""));
                epgProgress.setProgress(epgPercent(e.nowStart,e.nowStop));
            });}
            public void error(String m){runOnUiThread(()->{
                if(current!=null&&current.id==id){
                    epgNowTitle.setText("Sem informação");epgNextTitle.setText("—");
                    epgNowTime.setText("");epgNextTime.setText("");epgProgress.setProgress(40);
                }
            });}
        });
    }

    private String timeRange(String a,String b){
        String x=clean(a,""),y=clean(b,"");
        if(x.isEmpty()&&y.isEmpty())return "";
        return x+(y.isEmpty()?"":" - "+y);
    }

    private int epgPercent(String a,String b){
        try{
            java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("HH:mm",java.util.Locale.getDefault());
            java.util.Date s=f.parse(a),e=f.parse(b),n=f.parse(f.format(new java.util.Date()));
            if(s==null||e==null||n==null)return 42;
            long total=e.getTime()-s.getTime(),done=n.getTime()-s.getTime();
            if(total<=0)return 42;
            return Math.max(3,Math.min(97,(int)(done*100/total)));
        }catch(Exception ex){return 42;}
    }


    private void openOverlayPlayer(){
        if(current==null)return;
        Intent in=new Intent(this,PlayerActivity.class);
        in.putExtra("id",current.id);
        in.putExtra("type","live");
        in.putExtra("name",clean(current.name,"Canal"));
        in.putExtra("logo",clean(current.logo,""));
        in.putExtra("backdrop",clean(current.backdrop,""));
        in.putExtra("group",clean(current.group,""));
        in.putExtra("format",clean(current.format,"auto"));
        in.putExtra("from_home_tv",true);
        startActivity(in);
    }

    private void openFullscreen(){
        if(current==null || fullscreen)return;
        fullscreen=true;
        if(playerCard.getParent() instanceof android.view.ViewGroup){
            ((android.view.ViewGroup)playerCard.getParent()).removeView(playerCard);
        }
        fullscreenLayer.removeAllViews();
        preview.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FILL);
        fullscreenLayer.addView(playerCard,new FrameLayout.LayoutParams(-1,-1));
        buildFullscreenChrome();
        fullscreenLayer.setVisibility(View.VISIBLE);
        fullscreenLayer.bringToFront();
        hint.setText("VOLTAR");
        showPreviewOverlay();
        playerCard.requestFocus();
        immersive();
    }

    private void closeFullscreen(){
        if(!fullscreen)return;
        fullscreen=false;
        if(playerCard.getParent() instanceof android.view.ViewGroup){
            ((android.view.ViewGroup)playerCard.getParent()).removeView(playerCard);
        }
        fullscreenLayer.setVisibility(View.GONE);
        preview.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_ZOOM);
        if(rightColumn!=null) rightColumn.addView(playerCard,0,playerNormalLp);
        hint.setText("OK: informações");
        showPreviewOverlay();
        if(currentRow!=null) currentRow.requestFocus();
        immersive();
    }


    private void buildFullscreenChrome(){
        if(fullscreenChrome!=null && fullscreenChrome.getParent()==fullscreenLayer) fullscreenLayer.removeView(fullscreenChrome);
        fullscreenChrome=new FrameLayout(this);fullscreenChrome.setClickable(false);
        fullscreenLayer.addView(fullscreenChrome,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout drawer=new LinearLayout(this);drawer.setOrientation(LinearLayout.HORIZONTAL);drawer.setBackgroundColor(0xD812181B);
        LinearLayout rail=Ui.column(this);rail.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL);rail.setBackgroundColor(0xE5151C1F);rail.setPadding(0,Ui.dp(this,18),0,0);
        TextView si=fsIcon("⌕"), ri=fsIcon("◷"), fi=fsIcon("☆"), li=fsIcon("☷");
        rail.addView(si,new LinearLayout.LayoutParams(-1,Ui.dp(this,58)));rail.addView(ri,new LinearLayout.LayoutParams(-1,Ui.dp(this,58)));rail.addView(fi,new LinearLayout.LayoutParams(-1,Ui.dp(this,58)));rail.addView(li,new LinearLayout.LayoutParams(-1,Ui.dp(this,58)));
        drawer.addView(rail,new LinearLayout.LayoutParams(Ui.dp(this,64),-1));
        LinearLayout body=Ui.column(this);body.setPadding(Ui.dp(this,12),Ui.dp(this,12),Ui.dp(this,10),Ui.dp(this,10));
        TextView drawerTitle=Ui.text(this,"Lista de canais",14,Color.WHITE,false);body.addView(drawerTitle,new LinearLayout.LayoutParams(-1,Ui.dp(this,38)));
        fullscreenSearch=new EditText(this);fullscreenSearch.setSingleLine(true);fullscreenSearch.setHint("Pesquisar canais...");fullscreenSearch.setHintTextColor(0xFF89938E);fullscreenSearch.setTextColor(Color.WHITE);fullscreenSearch.setTextSize(12);fullscreenSearch.setBackground(Ui.stroke(0xCC22282A,Ui.GREEN,8,this));fullscreenSearch.setPadding(Ui.dp(this,12),0,Ui.dp(this,12),0);fullscreenSearch.setVisibility(View.GONE);body.addView(fullscreenSearch,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));
        ScrollView sc=new ScrollView(this);sc.setVerticalScrollBarEnabled(false);fullscreenDrawerRows=Ui.column(this);sc.addView(fullscreenDrawerRows,new ScrollView.LayoutParams(-1,-2));body.addView(sc,new LinearLayout.LayoutParams(-1,0,1));drawer.addView(body,new LinearLayout.LayoutParams(0,-1,1));
        FrameLayout.LayoutParams dlp=new FrameLayout.LayoutParams(Ui.dp(this,430),-1,Gravity.LEFT);fullscreenChrome.addView(drawer,dlp);fullscreenDrawer=drawer;fullscreenDrawer.setVisibility(View.GONE);
        li.setOnClickListener(v->{drawerTitle.setText("Lista de canais");fullscreenSearch.setVisibility(View.GONE);renderFullscreenDrawer("all","");});
        fi.setOnClickListener(v->{drawerTitle.setText("Favoritos");fullscreenSearch.setVisibility(View.GONE);renderFullscreenDrawer("fav","");});
        ri.setOnClickListener(v->{drawerTitle.setText("Recentes");fullscreenSearch.setVisibility(View.GONE);renderFullscreenDrawer("recent","");});
        si.setOnClickListener(v->{drawerTitle.setText("Pesquisar canais");fullscreenSearch.setVisibility(View.VISIBLE);fullscreenSearch.requestFocus();renderFullscreenDrawer("all",fullscreenSearch.getText().toString());});
        fullscreenSearch.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){}public void onTextChanged(CharSequence s,int a,int b,int c){renderFullscreenDrawer("all",s==null?"":s.toString());}public void afterTextChanged(android.text.Editable e){}});
        renderFullscreenDrawer("all","");
        statsHandler.removeCallbacks(statsTask);statsHandler.post(statsTask);
    }

    private TextView fsIcon(String x){TextView t=Ui.text(this,x,25,Color.WHITE,false);t.setGravity(Gravity.CENTER);t.setFocusable(true);t.setClickable(true);return t;}

    private void toggleFullscreenDrawer(){if(fullscreenDrawer==null)return;boolean show=fullscreenDrawer.getVisibility()!=View.VISIBLE;fullscreenDrawer.setVisibility(show?View.VISIBLE:View.GONE);if(show){renderFullscreenDrawer("all","");fullscreenDrawer.requestFocus();}}

    private void renderFullscreenDrawer(String mode,String query){
        if(fullscreenDrawerRows==null)return;fullscreenDrawerRows.removeAllViews();String q=query==null?"":query.trim().toLowerCase(Locale.ROOT);
        List<ApiClient.Item> src=new ArrayList<>();
        if("fav".equals(mode)){for(ApiClient.Item i:allChannels)if(LocalStore.isFavorite(this,i.id))src.add(i);}else if("recent".equals(mode)){List<ApiClient.Item> h=LocalStore.history(this);if(h!=null)src.addAll(h);}else src.addAll(allChannels);
        int n=0;for(ApiClient.Item i:src){if(i==null)continue;String nm=clean(i.name,"Canal");if(!q.isEmpty()&&!nm.toLowerCase(Locale.ROOT).contains(q))continue;n++;
            LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(Ui.dp(this,8),Ui.dp(this,3),Ui.dp(this,6),Ui.dp(this,3));r.setFocusable(true);r.setClickable(true);r.setBackground(current!=null&&current.id==i.id?Ui.stroke(0x4420FF74,Ui.GREEN,5,this):Ui.round(0x11000000,5,this));
            ImageView logo=new ImageView(this);logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);ImageLoader.into(this,logo,i.logo);r.addView(logo,new LinearLayout.LayoutParams(Ui.dp(this,48),Ui.dp(this,46)));
            LinearLayout txt=Ui.column(this);TextView name=Ui.text(this,channelNumber(i)+"  "+nm,13,Color.WHITE,true);name.setMaxLines(1);txt.addView(name,new LinearLayout.LayoutParams(-1,Ui.dp(this,25)));TextView sub=Ui.text(this,clean(i.group,""),8,0xFFC3CBC6,false);sub.setMaxLines(1);txt.addView(sub,new LinearLayout.LayoutParams(-1,Ui.dp(this,18)));r.addView(txt,new LinearLayout.LayoutParams(0,Ui.dp(this,48),1));
            final ApiClient.Item ci=i;r.setOnClickListener(v->{if(current==null||current.id!=ci.id)previewChannel(ci,null);fullscreenDrawer.setVisibility(View.GONE);showPreviewOverlay();});
            fullscreenDrawerRows.addView(r,new LinearLayout.LayoutParams(-1,Ui.dp(this,54)));
        }
    }

    private int channelNumber(ApiClient.Item item){if(item==null)return 0;for(int i=0;i<allChannels.size();i++)if(allChannels.get(i)!=null&&allChannels.get(i).id==item.id)return i+1;return 1;}

    private void updateFullscreenStats(){
        String tm=new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date());if(fullscreenClock!=null)fullscreenClock.setText(tm);
        long bps=0;try{if(bandwidthMeter!=null)bps=bandwidthMeter.getBitrateEstimate();}catch(Throwable ignored){}
        String sp=formatSpeed(bps);if(fullscreenSpeed!=null)fullscreenSpeed.setText(sp);if(loadingSpeed!=null)loadingSpeed.setText(sp);
    }
    private String formatSpeed(long bits){if(bits<=0)return "0 Kbps";if(bits>=1000000)return String.format(Locale.US,"%.1f Mbps",bits/1000000.0);return String.format(Locale.US,"%.0f Kbps",bits/1000.0);}

    private void openMain(){Intent in=new Intent(this,MainActivity.class);in.putExtra("show_highlights",true);startActivity(in);finish();}
    private void openCatalog(String type,String name){Intent in=new Intent(this,CatalogActivity.class);in.putExtra("type",type);in.putExtra("title",name);startActivity(in);}

    @Override public void onBackPressed(){if(fullscreen){closeFullscreen();return;}finish();}

    /**
     * TV ao vivo não deve continuar do ponto onde ficou pausada ao sair da tela.
     * Ao voltar de Filmes/Séries/Kids/etc., recriamos o stream do canal atual para
     * entrar novamente na borda AO VIVO e atualizamos o EPG.
     */
    @Override protected void onResume(){
        super.onResume();
        immersive();
        if(refreshLiveOnResume && current!=null){
            refreshLiveOnResume=false;
            startPreview(current.id);
            loadEpg(current.id);
            return;
        }
        try{if(player!=null)player.play();}catch(Throwable ignored){}
    }

    @Override protected void onPause(){
        if(current!=null) refreshLiveOnResume=true;
        try{if(player!=null)player.pause();}catch(Throwable ignored){}
        super.onPause();
    }

    @Override protected void onDestroy(){statsHandler.removeCallbacks(statsTask);super.onDestroy();if(player!=null){try{player.release();}catch(Exception ignored){}}}
    private String normalizeChannelName(String s){
        if(s==null)return "";String x=java.text.Normalizer.normalize(s,java.text.Normalizer.Form.NFD).replaceAll("\\p{M}+","").toLowerCase(java.util.Locale.ROOT);
        x=x.replace("hd","").replace("fhd","").replace("4k","").replace("canal","").replace("tv","").replaceAll("[^a-z0-9]+"," ").trim();
        return x;
    }

    private void immersive(){WindowCompat.setDecorFitsSystemWindows(getWindow(),false);WindowInsetsControllerCompat c=WindowCompat.getInsetsController(getWindow(),getWindow().getDecorView());c.hide(WindowInsetsCompat.Type.systemBars());c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);}
    private String clean(String v,String f){if(v==null)return f;String s=v.trim();return s.isEmpty()||"null".equalsIgnoreCase(s)?f:s;}

    private boolean isAdultChannelName(String name){
        if(name==null)return false;
        String x=name.toLowerCase(java.util.Locale.ROOT);
        String[] keys={"adulto","adultos","adult","18+","hot","sexy","privê","prive","erótico","erotico","porn","xxx"};
        for(String k:keys)if(x.contains(k))return true;
        return false;
    }
}
