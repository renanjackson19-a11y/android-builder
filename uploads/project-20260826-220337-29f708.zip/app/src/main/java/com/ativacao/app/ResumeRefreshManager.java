package com.ativacao.app;

import android.app.Activity;
import android.app.Application;
import android.content.Intent;
import android.os.Bundle;

final class ResumeRefreshManager implements Application.ActivityLifecycleCallbacks {
    // Pedido: alguns segundos fora do app já devem atualizar tudo.
    private static final long REFRESH_AFTER_MS=7000L;

    private static int started=0;
    private static long backgroundAt=0L;
    private static boolean wasBackground=false;
    private static boolean refreshing=false;

    static void install(Application app){
        app.registerActivityLifecycleCallbacks(new ResumeRefreshManager());
    }

    static void completeRefresh(){
        refreshing=false;
        wasBackground=false;
        backgroundAt=0L;
    }

    @Override public void onActivityStarted(Activity a){
        if(started==0 && wasBackground){
            long away=backgroundAt<=0?0:(System.currentTimeMillis()-backgroundAt);
            if(away>=REFRESH_AFTER_MS && !refreshing && Session.isLogged(a)
                    && !(a instanceof LoginActivity)
                    && !(a instanceof ContentRefreshActivity)){
                refreshing=true;
                Intent i=new Intent(a,ContentRefreshActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
                a.startActivity(i);
                return;
            }
        }
        started++;
    }

    @Override public void onActivityStopped(Activity a){
        started=Math.max(0,started-1);
        if(started==0 && !a.isChangingConfigurations() && !(a instanceof ContentRefreshActivity)){
            backgroundAt=System.currentTimeMillis();
            wasBackground=true;
        }
    }

    @Override public void onActivityCreated(Activity a,Bundle b){}
    @Override public void onActivityResumed(Activity a){}
    @Override public void onActivityPaused(Activity a){}
    @Override public void onActivitySaveInstanceState(Activity a,Bundle b){}
    @Override public void onActivityDestroyed(Activity a){}
}
