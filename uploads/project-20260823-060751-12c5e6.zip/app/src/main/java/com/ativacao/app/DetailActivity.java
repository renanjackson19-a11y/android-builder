package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class DetailActivity extends Activity {
    private ApiClient.Item item;private TextView fav;
    @Override public void onCreate(Bundle b){super.onCreate(b);Ui.immersive(this);item=readItem();setContentView(build());}
    private View build(){FrameLayout root=new FrameLayout(this);root.setBackgroundColor(Ui.BG);ImageView bg=new ImageView(this);bg.setScaleType(ImageView.ScaleType.CENTER_CROP);bg.setAlpha(.50f);root.addView(bg,new FrameLayout.LayoutParams(-1,-1));ImageLoader.into(this,bg,clean(item.backdrop,clean(item.logo,"")));View shade=new View(this);shade.setBackground(Ui.gradient(0xF205070B,0x6605070B,0,this));root.addView(shade,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout content=new LinearLayout(this);content.setGravity(Gravity.CENTER_VERTICAL);content.setPadding(Ui.dp(this,32),Ui.dp(this,24),Ui.dp(this,32),Ui.dp(this,24));ImageView poster=new ImageView(this);poster.setScaleType(ImageView.ScaleType.CENTER_CROP);poster.setBackgroundColor(Ui.PANEL_2);content.addView(poster,new LinearLayout.LayoutParams(Ui.dp(this,Ui.phone(this)?175:220),Ui.dp(this,Ui.phone(this)?255:320)));ImageLoader.into(this,poster,item.logo);
        LinearLayout info=Ui.column(this);info.setPadding(Ui.dp(this,26),0,0,0);TextView badge=Ui.text(this,"DUBAI PLAY • FILME",10,Ui.GREEN,true);info.addView(badge,new LinearLayout.LayoutParams(-1,Ui.dp(this,28)));TextView title=Ui.text(this,clean(item.name,"Filme"),Ui.phone(this)?27:38,Color.WHITE,true);title.setMaxLines(2);info.addView(title,new LinearLayout.LayoutParams(-1,Ui.dp(this,95)));TextView meta=Ui.text(this,clean(item.group,"Filmes")+(item.year>0?" • "+item.year:""),12,Color.rgb(224,227,232),true);info.addView(meta,new LinearLayout.LayoutParams(-1,Ui.dp(this,34)));TextView sin=Ui.text(this,clean(item.synopsis,"Assista agora no Dubai Play."),Ui.phone(this)?11:13,Color.rgb(196,201,210),false);sin.setMaxLines(5);info.addView(sin,new LinearLayout.LayoutParams(-1,0,1));LinearLayout actions=new LinearLayout(this);TextView play=Ui.primaryButton(this,"▶ ASSISTIR");play.setOnClickListener(v->play());actions.addView(play,new LinearLayout.LayoutParams(Ui.dp(this,170),Ui.dp(this,44)));fav=Ui.button(this,LocalStore.isFavorite(this,item.id)?"✓ MINHA LISTA":"+ MINHA LISTA");fav.setOnClickListener(v->{LocalStore.toggleFavorite(this,item);fav.setText(LocalStore.isFavorite(this,item.id)?"✓ MINHA LISTA":"+ MINHA LISTA");});LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(Ui.dp(this,170),Ui.dp(this,44));fp.leftMargin=Ui.dp(this,10);actions.addView(fav,fp);TextView back=Ui.button(this,"VOLTAR");back.setOnClickListener(v->finish());LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(Ui.dp(this,110),Ui.dp(this,44));bp.leftMargin=Ui.dp(this,10);actions.addView(back,bp);info.addView(actions,new LinearLayout.LayoutParams(-1,Ui.dp(this,50)));content.addView(info,new LinearLayout.LayoutParams(0,Ui.dp(this,Ui.phone(this)?260:325),1));root.addView(content,new FrameLayout.LayoutParams(-1,-1));play.requestFocus();return root;}
    private void play(){LocalStore.addHistory(this,item);Intent in=new Intent(this,PlayerActivity.class);MainActivity.putItem(in,item);startActivity(in);}
    private ApiClient.Item readItem(){ApiClient.Item i=new ApiClient.Item();i.id=getIntent().getLongExtra("id",0);i.name=getIntent().getStringExtra("name");i.logo=getIntent().getStringExtra("logo");i.backdrop=getIntent().getStringExtra("backdrop");i.group=getIntent().getStringExtra("group");i.synopsis=getIntent().getStringExtra("synopsis");i.type=clean(getIntent().getStringExtra("type"),"movie");i.format=clean(getIntent().getStringExtra("format"),"auto");i.year=getIntent().getIntExtra("year",0);i.seriesTitle=getIntent().getStringExtra("series_title");return i;}
    private String clean(String v,String f){if(v==null)return f;String s=v.trim();return s.isEmpty()||"null".equalsIgnoreCase(s)?f:s;}
}
