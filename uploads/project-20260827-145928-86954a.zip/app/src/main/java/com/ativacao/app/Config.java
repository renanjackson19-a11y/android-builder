package com.ativacao.app;

public final class Config {
    private Config() {}

    public static final String API_BASE_URL = "https://" + host() + "/greenplay/api/";
    public static final String APP_TOKEN = token();
    public static final String TMDB_API_KEY = "53588c7196b0013c96bb541e452dfd8c";
    public static final String TMDB_IMAGE_POSTER = "https://image.tmdb.org/t/p/w500";
    public static final String TMDB_IMAGE_BACKDROP = "https://image.tmdb.org/t/p/w1280";

    private static String host() {
        char[] c = new char[]{'d','u','b','a','i','p','l','a','y','.','s','h','o','p'};
        return new String(c);
    }
    private static String token() {
        return "CTAdcb_" + "S0Y7Sjnpx7w3F8c" + "-v7rW6sA9lxkhkcvVAWuQ";
    }
}
