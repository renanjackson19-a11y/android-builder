package com.spotnet.music;
import java.io.*;import java.net.*;import java.nio.charset.StandardCharsets;
public final class Net{
 public static String get(String url)throws Exception{return request("GET",url,null,9000,18000,2);}
 public static String getFast(String url)throws Exception{return request("GET",url,null,2800,4500,1);}
 public static String getStream(String url)throws Exception{return request("GET",url,null,6500,12000,1);}
 public static String post(String url,String body)throws Exception{return request("POST",url,body,10000,22000,2);}
 private static String request(String method,String url,String body,int connectTimeout,int readTimeout,int attempts)throws Exception{
   Exception last=null;
   for(int attempt=1;attempt<=attempts;attempt++){
     HttpURLConnection c=null;
     try{
       c=(HttpURLConnection)new URL(url).openConnection();c.setRequestMethod(method);c.setConnectTimeout(connectTimeout);c.setReadTimeout(readTimeout);c.setUseCaches(true);c.setRequestProperty("User-Agent","SpotnetMusic/25.0");c.setRequestProperty("Accept","application/json");c.setRequestProperty("Connection","keep-alive");
       if(body!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/x-www-form-urlencoded");try(OutputStream o=c.getOutputStream()){o.write(body.getBytes(StandardCharsets.UTF_8));}}
       return read(c);
     }catch(UnknownHostException e){last=new IOException("Internet ou DNS indisponível.",e);
     }catch(SocketTimeoutException e){last=new IOException("O servidor demorou para responder.",e);
     }catch(Exception e){last=e;}
     finally{if(c!=null)c.disconnect();}
     try{Thread.sleep(350L*attempt);}catch(InterruptedException ignored){Thread.currentThread().interrupt();}
   }
   throw last!=null?last:new IOException("Falha de conexão");
 }
 private static String read(HttpURLConnection c)throws Exception{int code=c.getResponseCode();InputStream in=code>=400?c.getErrorStream():c.getInputStream();if(in==null)throw new IOException("HTTP "+code);BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8));StringBuilder b=new StringBuilder();String s;while((s=r.readLine())!=null)b.append(s);String text=b.toString();if(code>=400)throw new IOException("HTTP "+code+": "+text);if(text.trim().startsWith("<"))throw new IOException("O servidor devolveu HTML em vez da API.");return text;}
}
