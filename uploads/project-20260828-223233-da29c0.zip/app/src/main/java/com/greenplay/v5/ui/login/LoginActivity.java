package com.greenplay.v5.ui.login;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.MotionEvent;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.greenplay.v5.BuildConfig;
import com.greenplay.v5.R;
import com.greenplay.v5.core.network.NetworkProvider;
import com.greenplay.v5.core.network.PanelHost;
import com.greenplay.v5.core.session.SessionStore;
import com.greenplay.v5.data.model.LoginResponse;
import com.greenplay.v5.data.model.StatusResponse;
import com.greenplay.v5.data.model.TrialStatusResponse;
import com.greenplay.v5.data.repository.AuthRepository;
import com.greenplay.v5.databinding.ActivityLoginBinding;
import com.greenplay.v5.ui.tv.TvActivity;
import com.squareup.picasso.Picasso;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public final class LoginActivity extends AppCompatActivity {
    private ActivityLoginBinding b;
    private AuthRepository auth;
    private int trialHours = 3;
    private boolean trialEnabled = false;
    private boolean passwordVisible = false;
    private String deviceId = "";

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        b = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        auth = new AuthRepository(this);

        SessionStore session = new SessionStore(this);
        if (session.isLogged() && !session.host().trim().isEmpty() && !session.user().trim().isEmpty() && !session.pass().isEmpty()) {
            openTv();
            return;
        }

        deviceId = resolveDeviceId();
        b.txtDevice.setText("ID Dispositivo: " + (deviceId.isEmpty() ? "NÃO DISPONÍVEL" : deviceId.toUpperCase()));
        b.txtVersion.setText("Versão: " + BuildConfig.VERSION_NAME);

        // O botão nasce oculto. Quem decide se ele aparece é o servidor.
        b.btnTrial.setVisibility(View.GONE);
        b.btnTrial.setEnabled(false);

        b.btnEnter.setOnClickListener(v -> login());
        b.btnConnection.setOnClickListener(v -> testConnection());
        b.btnTrial.setOnClickListener(v -> createTrial());
        configurePasswordEye();

        // Branding e autorização do teste são consultados em paralelo para abrir rápido.
        loadPanelBranding();
        loadTrialEligibility(false);
    }

    @Override protected void onResume() {
        super.onResume();
        if (b != null && !deviceId.isEmpty()) loadTrialEligibility(false);
    }

    private String resolveDeviceId() {
        String device = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        return device == null ? "" : device.trim();
    }

    private void configurePasswordEye() {
        b.inputPass.setOnTouchListener((v, event) -> {
            if (event.getAction() != MotionEvent.ACTION_UP) return false;
            if (b.inputPass.getCompoundDrawablesRelative()[2] == null) return false;
            int touchStart = b.inputPass.getWidth() - b.inputPass.getPaddingEnd()
                    - b.inputPass.getCompoundDrawablesRelative()[2].getBounds().width() - 24;
            if (event.getX() < touchStart) return false;

            int cursor = b.inputPass.getSelectionStart();
            passwordVisible = !passwordVisible;
            b.inputPass.setTransformationMethod(passwordVisible
                    ? HideReturnsTransformationMethod.getInstance()
                    : PasswordTransformationMethod.getInstance());
            b.inputPass.setSelection(Math.max(0, cursor));
            v.performClick();
            return true;
        });
    }

    private void loadPanelBranding() {
        setServerOnline(false);
        NetworkProvider.panel().status().enqueue(new Callback<StatusResponse>() {
            @Override public void onResponse(Call<StatusResponse> call, Response<StatusResponse> response) {
                StatusResponse st = response.body();
                if (!response.isSuccessful() || st == null) {
                    runOnUiThread(() -> setServerOnline(false));
                    return;
                }
                runOnUiThread(() -> {
                    setServerOnline(true);
                    applyStatus(st);
                });
            }
            @Override public void onFailure(Call<StatusResponse> call, Throwable t) {
                runOnUiThread(() -> setServerOnline(false));
            }
        });
    }

    private void applyStatus(StatusResponse st) {
        String bg = absoluteAsset(st.loginBackground);
        if (!bg.isEmpty()) {
            Picasso.get()
                    .load(bg)
                    .placeholder(R.drawable.login_green_play_default)
                    .error(R.drawable.login_green_play_default)
                    .noFade()
                    .into(b.loginBackground);
        }

        String logo = absoluteAsset(st.appLogo);
        if (!logo.isEmpty()) {
            Picasso.get().load(logo).noFade().into(b.appLogo, new com.squareup.picasso.Callback() {
                @Override public void onSuccess() { b.appLogo.setVisibility(View.VISIBLE); }
                @Override public void onError(Exception e) { b.appLogo.setVisibility(View.GONE); }
            });
        } else {
            b.appLogo.setVisibility(View.GONE);
        }

        // Duração também vem do painel, mas a exibição do botão depende do status por aparelho.
        trialHours = Math.max(1, st.trialHours);
        if (!st.trialEnabled) {
            trialEnabled = false;
            b.btnTrial.setVisibility(View.GONE);
            b.btnTrial.setEnabled(false);
        }
    }

    private void loadTrialEligibility(boolean showBlockedMessage) {
        if (deviceId.isEmpty()) {
            trialEnabled = false;
            b.btnTrial.setVisibility(View.GONE);
            return;
        }
        NetworkProvider.panel().trialStatus(deviceId).enqueue(new Callback<TrialStatusResponse>() {
            @Override public void onResponse(Call<TrialStatusResponse> call, Response<TrialStatusResponse> response) {
                TrialStatusResponse st = response.body();
                runOnUiThread(() -> {
                    if (!response.isSuccessful() || st == null || !st.ok) {
                        trialEnabled = false;
                        b.btnTrial.setVisibility(View.GONE);
                        return;
                    }
                    trialHours = Math.max(1, st.trialHours);
                    trialEnabled = st.enabled && st.eligible;
                    if (trialEnabled) {
                        b.btnTrial.setText("TESTE AUTOMÁTICO  •  " + trialHours + (trialHours == 1 ? " HORA" : " HORAS"));
                        b.btnTrial.setVisibility(View.VISIBLE);
                        b.btnTrial.setEnabled(true);
                    } else {
                        b.btnTrial.setVisibility(View.GONE);
                        b.btnTrial.setEnabled(false);
                        if (showBlockedMessage && st.used) {
                            b.txtError.setTextColor(ContextCompat.getColor(LoginActivity.this, R.color.gp_muted));
                            b.txtError.setText(st.active ? "Teste deste aparelho já está em uso" : "Teste deste aparelho já foi utilizado");
                        }
                    }
                });
            }

            @Override public void onFailure(Call<TrialStatusResponse> call, Throwable t) {
                runOnUiThread(() -> {
                    trialEnabled = false;
                    b.btnTrial.setVisibility(View.GONE);
                    b.btnTrial.setEnabled(false);
                });
            }
        });
    }

    private void testConnection() {
        b.btnConnection.setEnabled(false);
        b.txtError.setTextColor(ContextCompat.getColor(this, R.color.gp_muted));
        b.txtError.setText("Testando conexão...");
        NetworkProvider.panel().status().enqueue(new Callback<StatusResponse>() {
            @Override public void onResponse(Call<StatusResponse> call, Response<StatusResponse> response) {
                StatusResponse st = response.body();
                runOnUiThread(() -> {
                    b.btnConnection.setEnabled(true);
                    if (response.isSuccessful() && st != null) {
                        setServerOnline(true);
                        applyStatus(st);
                        loadTrialEligibility(false);
                        b.txtError.setTextColor(ContextCompat.getColor(LoginActivity.this, R.color.gp_green_soft));
                        b.txtError.setText("Conexão OK • servidor online");
                    } else {
                        setServerOnline(false);
                        b.txtError.setTextColor(0xFFFF7979);
                        b.txtError.setText("Servidor indisponível no momento");
                    }
                });
            }
            @Override public void onFailure(Call<StatusResponse> call, Throwable t) {
                runOnUiThread(() -> {
                    b.btnConnection.setEnabled(true);
                    setServerOnline(false);
                    b.txtError.setTextColor(0xFFFF7979);
                    b.txtError.setText("Sem conexão com o servidor");
                });
            }
        });
    }

    private void setServerOnline(boolean online) {
        b.serverDot.setBackgroundResource(online ? R.drawable.bg_status_online : R.drawable.bg_status_offline);
    }

    private String absoluteAsset(String raw) {
        if (raw == null) return "";
        String s = raw.trim();
        if (s.isEmpty()) return "";
        if (s.startsWith("http://") || s.startsWith("https://")) return s;
        String root = PanelHost.root();
        if (root.endsWith("/")) root = root.substring(0, root.length() - 1);
        return root + (s.startsWith("/") ? s : "/" + s);
    }

    private void setLoading(boolean loading, String text) {
        b.progress.setVisibility(loading ? View.VISIBLE : View.GONE);
        b.btnEnter.setEnabled(!loading);
        b.btnConnection.setEnabled(!loading);
        b.btnTrial.setEnabled(!loading && trialEnabled);
        if (text != null) b.txtError.setText(text);
    }

    private void login() {
        String user = b.inputUser.getText().toString().trim();
        String pass = b.inputPass.getText().toString();
        if (user.isEmpty() || pass.isEmpty()) {
            b.txtError.setTextColor(0xFFFF7979);
            b.txtError.setText("Digite usuário e senha");
            return;
        }
        b.txtError.setTextColor(0xFFFF7979);
        setLoading(true, "");
        auth.login(user, pass, deviceId, new AuthRepository.Result() {
            @Override public void success(LoginResponse login) { runOnUiThread(() -> openTv()); }
            @Override public void error(String message) { runOnUiThread(() -> setLoading(false, message)); }
        });
    }

    private void createTrial() {
        if (!trialEnabled || deviceId.isEmpty()) return;
        // O APK não envia duração, plano ou bouquet. O servidor decide tudo.
        b.txtError.setTextColor(ContextCompat.getColor(this, R.color.gp_muted));
        setLoading(true, "Solicitando teste ao painel...");
        NetworkProvider.panel().trial(deviceId).enqueue(new Callback<LoginResponse>() {
            @Override public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                LoginResponse body = response.body();
                if (!response.isSuccessful() || body == null || !body.ok) {
                    String msg = body != null && body.message != null ? body.message : "Teste indisponível no momento";
                    runOnUiThread(() -> {
                        b.txtError.setTextColor(0xFFFF7979);
                        setLoading(false, msg);
                        loadTrialEligibility(false);
                    });
                    return;
                }
                String user = body.username == null ? "" : body.username.trim();
                String pass = body.xtreamPassword == null ? "" : body.xtreamPassword;
                String host = body.xtreamHost == null || body.xtreamHost.trim().isEmpty() ? PanelHost.root() : body.xtreamHost.trim();
                new SessionStore(LoginActivity.this).save(host, user, pass, body.expiresAt, body.plan, body.adultAccess, body.userToken);
                trialEnabled = false;
                runOnUiThread(() -> {
                    b.btnTrial.setVisibility(View.GONE);
                    openTv();
                });
            }
            @Override public void onFailure(Call<LoginResponse> call, Throwable t) {
                runOnUiThread(() -> {
                    b.txtError.setTextColor(0xFFFF7979);
                    setLoading(false, "Sem conexão com o painel");
                    loadTrialEligibility(false);
                });
            }
        });
    }

    private void openTv() {
        startActivity(new Intent(LoginActivity.this, TvActivity.class));
        finish();
    }
}
