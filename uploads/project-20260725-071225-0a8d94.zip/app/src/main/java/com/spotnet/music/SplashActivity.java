package com.spotnet.music;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.bumptech.glide.Glide;
import org.json.JSONObject;

public class SplashActivity extends AppCompatActivity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private long duration = 2600;
    private boolean finished = false;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        ImageView media=findViewById(R.id.splashMedia);
        LinearLayout brand=findViewById(R.id.splashBrand);
        TextView title=findViewById(R.id.splashTitle);
        new Thread(() -> {
            try {
                JSONObject response=new JSONObject(Net.get(BuildConfig.PANEL_URL+"/api/config.php"));
                JSONObject cfg=response.optJSONObject("settings");
                if(cfg!=null){
                    String rawUrl=cfg.optString("splash_media_url","");
                    if(!rawUrl.isEmpty()&&!rawUrl.startsWith("http")){if(!rawUrl.startsWith("/"))rawUrl="/"+rawUrl;rawUrl=BuildConfig.PANEL_URL+rawUrl;}
                    final String url=rawUrl;
                    duration=Math.max(1200,Math.min(10000,cfg.optLong("splash_duration_ms",2600)));
                    boolean showBrand=cfg.optBoolean("splash_show_branding",true);
                    String appName=cfg.optString("site_name","Spotnet Music");
                    runOnUiThread(() -> {
                        title.setText(appName.toUpperCase());
                        brand.setVisibility(showBrand?View.VISIBLE:View.GONE);
                        if(!url.isEmpty()) Glide.with(this).load(url).centerCrop().into(media);
                        else media.setImageResource(R.drawable.splash_gradient);
                        scheduleOpen();
                    });
                    return;
                }
            }catch(Exception ignored){}
            runOnUiThread(() -> {media.setImageResource(R.drawable.splash_gradient);scheduleOpen();});
        }).start();
        handler.postDelayed(this::openApp,7000);
    }

    private void scheduleOpen(){handler.postDelayed(this::openApp,duration);}
    private void openApp(){
        if(finished)return; finished=true;
        String user=getSharedPreferences("auth",MODE_PRIVATE).getString("user","");
        startActivity(new Intent(this,user.isEmpty()?LoginActivity.class:MainActivity.class));
        overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);
        finish();
    }
    @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);super.onDestroy();}
}
