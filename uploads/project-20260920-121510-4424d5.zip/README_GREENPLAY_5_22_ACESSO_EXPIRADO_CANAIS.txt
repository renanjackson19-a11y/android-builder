GREENPLAY 5.22 — ACESSO EXPIRADO UNIFICADO

Correções:
- Filmes, séries e canais usam a mesma validação de assinatura antes de reproduzir.
- Plano vencido: mostra “Acesso expirado. Seu acesso expirou. Renove seu plano para continuar assistindo.”
- Teste real vencido: mostra “Teste expirado. Seu teste expirou. Assine um plano para continuar assistindo.”
- Canais não iniciam o fluxo do player quando a conta está vencida.
- Removida aquisição antecipada de sessão na abertura da área de TV, evitando fechamento/instabilidade em contas expiradas.
- Modo TV / Android TV Box também usa a mesma proteção.
