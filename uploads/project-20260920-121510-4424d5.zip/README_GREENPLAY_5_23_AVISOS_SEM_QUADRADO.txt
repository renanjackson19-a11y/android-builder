GreenPlay 5.23 — Avisos sem quadrado

- Atualização do aplicativo redesenhada sem card/caixa central.
- Assinatura ou teste expirado redesenhado sem card/caixa.
- Fundo escurecido + conteúdo limpo + botões arredondados.
- Mantidas as correções da 5.22 para Filmes, Séries e Canais.
- Não altera canais, logos, catálogo, filmes/séries, player nem atualizador funcional; apenas a apresentação do atualizador.
