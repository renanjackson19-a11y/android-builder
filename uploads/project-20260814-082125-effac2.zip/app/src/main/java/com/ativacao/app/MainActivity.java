package com.ativacao.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.PackageInfo;
import android.content.pm.Signature;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.text.Editable;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;

public class MainActivity extends Activity {
    private EditText edtLicenca;
    private TextView txtStatus;
    private ProgressBar progress;
    private Button btnAtivar;
    private Button btnApagarConfig;
    private RadioGroup grupoTipoAparelho;
    private String tipoAparelhoEscolhido = "";
    private volatile String avisoSalvamentoConfig = "";
    private boolean aguardandoRetornoPermissao = false;
    private String nomeOpcaoAndroid = "TV Android / Celular";
    private String nomeOpcaoTvBox = "TV Box / Fire Stick / MXQ";

    // A verificação acontece antes da tela de licença em cada abertura do aplicativo.
    private volatile boolean verificandoRoot = false;
    private volatile boolean verificacaoRootConcluida = false;
    private volatile boolean rootDetectado = false;
    private volatile boolean rootGateLiberado = false;
    private volatile boolean removendoRoot = false;
    private RootInfo ultimaInfoRoot = new RootInfo();
    private Button btnRemoverRoot;
    private TextView txtRootStatus;
    private ProgressBar progressoRoot;
    private final Handler rootHandler = new Handler(Looper.getMainLooper());

    private int COR_PRINCIPAL = Color.rgb(235, 30, 45);
    private int COR_PRINCIPAL_ESCURO = Color.rgb(135, 12, 22);
    private final int FUNDO = Color.rgb(12, 10, 16);
    private final int TEXTO_CLARO = Color.rgb(245, 246, 250);
    private final int TEXTO_SUAVE = Color.rgb(190, 190, 202);

    private String appTitulo = "Ativador Launcher";
    private String appSubtitulo = "Digite sua licença para instalar a configuração e o UniTV.";
    private String textoPermissao = "Antes de usar sua licença, toque em LIBERAR PERMISSÕES. O ativador vai abrir a tela correta do aparelho; marque Permitir e volte para o app.";
    private String textoBotaoPermissao = "LIBERAR PERMISSÕES";
    private String textoBotaoAtivar = "ATIVAR LICENÇA";
    private String msgPronto = "Pronto para ativar. A configuração será instalada automaticamente no aparelho.";
    private String logoUrl = "";
    private String fundoUrl = "";
    private String propagandaTexto = "";
    private String propagandaLink = "";
    private String propagandaBotao = "ACESSAR AGORA";
    private volatile String atualizacaoUrl = "";
    private volatile String atualizacaoVersao = "";
    private volatile long atualizacaoVersionCode = 0L;
    private volatile boolean atualizacaoAvisada = false;

    private String suporteSessaoId = "";
    private String suporteCodigoAtual = "";
    private Handler suporteHandler = new Handler(Looper.getMainLooper());
    private boolean suporteAtivo = false;

    private static final String PREFS = "ativador_prefs";
    private static final String KEY_PERMISSOES_CONFIRMADAS = "permissoes_confirmadas";
    private static final String KEY_ROOT_PULADO = "root_pulado";
    private boolean forceActivationUi = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        forceActivationUi = getIntent() != null && getIntent().getBooleanExtra("force_activation_ui", false);
        getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        carregarConfigDoPainel();
        if (getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(KEY_ROOT_PULADO, false)) {
            verificacaoRootConcluida = true; rootDetectado = false; rootGateLiberado = true; mostrarTelaCorreta();
        } else iniciarVerificacaoRoot();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (DeviceControl.isDeviceOwner(this)) DeviceControl.enforceManagedState(this);
        PolicyScheduler.schedule(this);
        new Thread(() -> PolicySync.sync(getApplicationContext()), "policy-resume").start();
        if (aguardandoRetornoPermissao) {
            aguardandoRetornoPermissao = false;
            verificarPermissoesEContinuar();
        } else {
            mostrarTelaCorreta();
        }
    }

    private void carregarConfigDoPainel() {
        new Thread(() -> {
            try {
                String json = httpGet(Config.API_APP_CONFIG);
                if (json == null || json.trim().isEmpty()) return;
                JSONObject obj = new JSONObject(json);
                if (!"ok".equalsIgnoreCase(obj.optString("status", "ok"))) return;
                String controlUrl = obj.optString("control_url", "").trim();
                if (!controlUrl.isEmpty()) { PolicyStore.setControlUrl(this, controlUrl); PolicyScheduler.schedule(this); }
                appTitulo = obj.optString("titulo", appTitulo);
                appSubtitulo = obj.optString("subtitulo", appSubtitulo);
                textoPermissao = obj.optString("texto_permissao", textoPermissao);
                textoBotaoPermissao = obj.optString("botao_permissao", textoBotaoPermissao);
                textoBotaoAtivar = obj.optString("botao_ativar", textoBotaoAtivar);
                msgPronto = obj.optString("mensagem_pronto", msgPronto);
                logoUrl = normalizarUrl(obj.optString("logo_url", ""));
                fundoUrl = normalizarUrl(obj.optString("fundo_url", ""));
                propagandaTexto = obj.optString("propaganda_texto", propagandaTexto);
                propagandaLink = normalizarUrl(obj.optString("propaganda_link", propagandaLink));
                propagandaBotao = obj.optString("propaganda_botao", propagandaBotao);
                nomeOpcaoAndroid = obj.optString("nome_tv_android", obj.optString("opcao1_nome", obj.optString("opcao_1", obj.optString("opcao1", nomeOpcaoAndroid))));
                nomeOpcaoTvBox = obj.optString("nome_tv_box", obj.optString("opcao2_nome", obj.optString("opcao_2", obj.optString("opcao2", nomeOpcaoTvBox))));
                JSONObject upd = obj.optJSONObject("activator_update");
                if (upd != null) {
                    atualizacaoUrl = normalizarUrl(upd.optString("url", ""));
                    atualizacaoVersao = upd.optString("version_name", "").trim();
                    atualizacaoVersionCode = upd.optLong("version_code", 0L);
                }
                // Migração para quem já vinha da V3.2: recupera do painel se este aparelho era TV Box.
                if (LauncherStore.getDeviceType(this).trim().isEmpty()) {
                    String dc = LauncherStore.getDeviceCode(this).trim();
                    if (!dc.isEmpty()) {
                        try {
                            String sync = httpGet(Config.BASE_URL + "/api/launcher_sync.php?device_code=" + URLEncoder.encode(dc, "UTF-8"));
                            JSONObject so = new JSONObject(sync);
                            String antigoTarget = so.optString("app_target", "").trim();
                            if (!antigoTarget.isEmpty()) {
                                LauncherStore.setDeviceType(this, antigoTarget);
                                LauncherStore.setCachedJson(this, sync);
                            }
                        } catch (Exception ignored) {}
                    }
                }
                String cor = obj.optString("cor_principal", "").trim();
                if (cor.matches("#?[0-9A-Fa-f]{6}")) {
                    if (!cor.startsWith("#")) cor = "#" + cor;
                    COR_PRINCIPAL = Color.parseColor(cor);
                    COR_PRINCIPAL_ESCURO = escurecer(COR_PRINCIPAL);
                }
                runOnUiThread(() -> { boolean vaiParaLauncher = LauncherStore.isActivationComplete(this) && LauncherStore.isTvBoxMode(this) && !forceActivationUi; mostrarTelaCorreta(); if (!vaiParaLauncher) verificarAtualizacaoDoAtivador(); });
            } catch (Exception ignored) {}
        }).start();
    }

    private int escurecer(int cor) {
        int r = Math.max(0, (int)(Color.red(cor) * 0.55));
        int g = Math.max(0, (int)(Color.green(cor) * 0.55));
        int b = Math.max(0, (int)(Color.blue(cor) * 0.55));
        return Color.rgb(r, g, b);
    }

    private boolean isTV() {
        int mode = getResources().getConfiguration().uiMode & Configuration.UI_MODE_TYPE_MASK;
        return mode == Configuration.UI_MODE_TYPE_TELEVISION
                || mode == Configuration.UI_MODE_TYPE_APPLIANCE
                || !getPackageManager().hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN);
    }

    private void mostrarTelaCorreta() {
        // ROOT sempre é verificado antes de permitir a digitação da licença.
        if (!rootGateLiberado || rootDetectado || !verificacaoRootConcluida) {
            montarTelaRoot();
            if (!verificandoRoot && !removendoRoot && !verificacaoRootConcluida) iniciarVerificacaoRoot();
            return;
        }

        // Mostra a tela de permissões pelo menos uma vez antes da licença.
        if (!permissoesLiberadas() || !permissoesConfirmadas()) { montarTelaPermissoes(); return; }
        if (LauncherStore.isActivationComplete(this) && LauncherStore.isTvBoxMode(this) && !forceActivationUi) {
            Intent i = new Intent(this, LauncherActivity.class); startActivity(i); finish(); return;
        }
        montarTelaAtivacao();
    }

    private boolean permissoesConfirmadas() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        return prefs.getBoolean(KEY_PERMISSOES_CONFIRMADAS, false);
    }

    private void confirmarPermissoes() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_PERMISSOES_CONFIRMADAS, true).apply();
    }

    private void configurarFundo(ScrollView scroll) {
        GradientDrawable fundo = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{escurecer(COR_PRINCIPAL), FUNDO, Color.rgb(18, 10, 14)});
        scroll.setBackground(fundo);
        if (!fundoUrl.isEmpty()) {
            new Thread(() -> {
                try {
                    Bitmap bmp = baixarBitmap(fundoUrl);
                    if (bmp != null) runOnUiThread(() -> {
                        BitmapDrawable bd = new BitmapDrawable(getResources(), bmp);
                        bd.setGravity(Gravity.CENTER);
                        scroll.setBackground(bd);
                    });
                } catch (Exception ignored) {}
            }).start();
        }
    }

    private LinearLayout criarContainer(ScrollView scroll) {
        configurarFundo(scroll);
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setGravity(Gravity.CENTER);
        outer.setMinimumHeight(getResources().getDisplayMetrics().heightPixels);
        outer.setPadding(dp(isTV() ? 40 : 18), dp(isTV() ? 32 : 38), dp(isTV() ? 40 : 18), dp(isTV() ? 32 : 38));
        scroll.addView(outer, new ScrollView.LayoutParams(-1, -1));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(isTV() ? 38 : 22), dp(isTV() ? 30 : 24), dp(isTV() ? 38 : 22), dp(24));
        root.setBackground(criarBorda(Color.argb(170, 10, 10, 16), Color.argb(120, 255, 255, 255), dp(22), dp(1)));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(isTV() ? dp(760) : -1, -2);
        rp.gravity = Gravity.CENTER_HORIZONTAL;
        outer.addView(root, rp);
        return root;
    }

    private void adicionarTopo(LinearLayout root) {
        ImageView logo = new ImageView(this);
        logo.setAdjustViewBounds(true);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams lpLogo = new LinearLayout.LayoutParams(dp(isTV()?150:110), dp(isTV()?90:70));
        lpLogo.gravity = Gravity.CENTER_HORIZONTAL;
        lpLogo.setMargins(0, 0, 0, dp(12));
        root.addView(logo, lpLogo);
        if (!logoUrl.isEmpty()) carregarImagem(logo, logoUrl); else logo.setVisibility(View.GONE);

        TextView badge = new TextView(this);
        badge.setText("DUBAI DIGITAL");
        badge.setTextColor(Color.WHITE);
        badge.setTextSize(isTV() ? 16 : 13);
        badge.setTypeface(Typeface.DEFAULT_BOLD);
        badge.setGravity(Gravity.CENTER);
        badge.setLetterSpacing(0.10f);
        badge.setPadding(dp(14), dp(8), dp(14), dp(8));
        badge.setBackground(criarBorda(Color.argb(70, 255, 40, 55), COR_PRINCIPAL, dp(26), dp(1)));
        LinearLayout.LayoutParams badgeParams = new LinearLayout.LayoutParams(-2, -2);
        badgeParams.gravity = Gravity.CENTER_HORIZONTAL;
        badgeParams.setMargins(0, 0, 0, dp(18));
        root.addView(badge, badgeParams);

        TextView titulo = new TextView(this);
        titulo.setText(appTitulo);
        titulo.setTextColor(TEXTO_CLARO);
        titulo.setTextSize(isTV() ? 42 : 32);
        titulo.setTypeface(Typeface.DEFAULT_BOLD);
        titulo.setGravity(Gravity.CENTER);
        titulo.setLineSpacing(0, 0.96f);
        root.addView(titulo, new LinearLayout.LayoutParams(-1, -2));

        TextView by = new TextView(this);
        by.setText("By Dubai Digital");
        by.setTextColor(COR_PRINCIPAL);
        by.setTextSize(isTV() ? 18 : 15);
        by.setTypeface(Typeface.DEFAULT_BOLD);
        by.setGravity(Gravity.CENTER);
        by.setPadding(0, dp(8), 0, dp(18));
        root.addView(by, new LinearLayout.LayoutParams(-1, -2));
    }

    private void adicionarPropaganda(LinearLayout root) {
        if ((propagandaTexto == null || propagandaTexto.trim().isEmpty()) && (propagandaLink == null || propagandaLink.trim().isEmpty())) return;

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(dp(16), dp(14), dp(16), dp(14));
        box.setBackground(criarBorda(Color.argb(90, 255, 255, 255), COR_PRINCIPAL, dp(16), dp(1)));

        TextView txt = new TextView(this);
        txt.setText(propagandaTexto == null || propagandaTexto.trim().isEmpty() ? "Acesse nossa propaganda" : propagandaTexto.trim());
        txt.setTextColor(Color.WHITE);
        txt.setTextSize(isTV() ? 18 : 15);
        txt.setTypeface(Typeface.DEFAULT_BOLD);
        txt.setGravity(Gravity.CENTER);
        txt.setPadding(0, 0, 0, dp(10));
        box.addView(txt, new LinearLayout.LayoutParams(-1, -2));

        if (propagandaLink != null && !propagandaLink.trim().isEmpty()) {
            Button btn = criarBotao(propagandaBotao == null || propagandaBotao.trim().isEmpty() ? "ACESSAR AGORA" : propagandaBotao.trim());
            btn.setTextSize(isTV() ? 17 : 14);
            box.addView(btn, new LinearLayout.LayoutParams(-1, dp(isTV() ? 58 : 48)));
            btn.setOnClickListener(v -> abrirPropaganda());
            box.setOnClickListener(v -> abrirPropaganda());
            box.setFocusable(true);
        }

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(18), 0, dp(6));
        root.addView(box, lp);
    }


    private void adicionarSuporteRemoto(LinearLayout root) {
        Button btn = criarBotao("RECEBER AJUDA REMOTA");
        btn.setTextSize(isTV() ? 17 : 14);
        btn.setBackground(criarBorda(Color.argb(90, 20, 20, 28), Color.argb(170,255,255,255), dp(16), dp(1)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(isTV() ? 58 : 50));
        lp.setMargins(0, dp(12), 0, 0);
        root.addView(btn, lp);
        btn.setOnClickListener(v -> montarTelaSuporteRemoto());
    }

    private void montarTelaSuporteRemoto() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = criarContainer(scroll);
        adicionarTopo(root);

        TextView desc = new TextView(this);
        desc.setText("Digite o código de suporte que o atendente gerou no painel. O suporte só inicia depois que você aceitar.");
        desc.setTextColor(TEXTO_SUAVE);
        desc.setTextSize(isTV() ? 20 : 16);
        desc.setGravity(Gravity.CENTER);
        desc.setPadding(dp(6), 0, dp(6), dp(18));
        root.addView(desc, new LinearLayout.LayoutParams(-1, -2));

        TvEditText edtCodigo = new TvEditText(this);
        edtCodigo.setHint("Código de suporte");
        edtCodigo.setTextColor(Color.WHITE);
        edtCodigo.setHintTextColor(Color.rgb(150,145,154));
        edtCodigo.setTextSize(isTV()?28:22);
        edtCodigo.setGravity(Gravity.CENTER);
        edtCodigo.setSingleLine(true);
        edtCodigo.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        edtCodigo.setFilters(new InputFilter[]{new InputFilter.LengthFilter(6)});
        edtCodigo.setBackground(criarBorda(Color.argb(65,120,10,20), COR_PRINCIPAL, dp(18), dp(1)));
        root.addView(edtCodigo, new LinearLayout.LayoutParams(-1, dp(isTV()?78:66)));

        TextView aviso = new TextView(this);
        aviso.setText("Você pode encerrar o suporte a qualquer momento. O suporte permite comandos dentro do ativador e abertura das telas de permissão do Android.");
        aviso.setTextColor(TEXTO_SUAVE);
        aviso.setTextSize(isTV()?16:13);
        aviso.setGravity(Gravity.CENTER);
        aviso.setPadding(0, dp(14), 0, dp(14));
        root.addView(aviso, new LinearLayout.LayoutParams(-1, -2));

        Button entrar = criarBotao("CONECTAR E ACEITAR SUPORTE");
        root.addView(entrar, new LinearLayout.LayoutParams(-1, dp(isTV()?68:58)));
        entrar.setOnClickListener(v -> conectarSuporte(edtCodigo.getText().toString().trim()));
        configurarTecladoTv(edtCodigo, entrar, () -> conectarSuporte(edtCodigo.getText().toString().trim()));
        entrar.requestFocus();

        Button voltar = criarBotao("VOLTAR");
        voltar.setBackground(criarBorda(Color.argb(90,20,20,28), COR_PRINCIPAL, dp(16), dp(1)));
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-1, dp(isTV()?58:50));
        vp.setMargins(0, dp(12), 0, 0);
        root.addView(voltar, vp);
        voltar.setOnClickListener(v -> mostrarTelaCorreta());

        setContentView(scroll);
    }

    private void conectarSuporte(String codigo) {
        if (!codigo.matches("\\d{6}")) {
            Toast.makeText(this, "Digite o código de 6 números.", Toast.LENGTH_LONG).show();
            return;
        }
        Toast.makeText(this, "Conectando suporte...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            try {
                String androidId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
                String aparelho = Build.MANUFACTURER + " " + Build.MODEL;
                String url = Config.API_SUPORTE + "?action=aceitar&codigo=" + URLEncoder.encode(codigo, "UTF-8")
                        + "&device=" + URLEncoder.encode(aparelho, "UTF-8")
                        + "&device_id=" + URLEncoder.encode(androidId == null ? "" : androidId, "UTF-8")
                        + "&android=" + URLEncoder.encode(String.valueOf(Build.VERSION.SDK_INT), "UTF-8")
                        + "&tipo_aparelho=" + URLEncoder.encode(isTV() ? "tv" : "mobile", "UTF-8");
                JSONObject obj = new JSONObject(httpGet(url));
                if (!"ok".equalsIgnoreCase(obj.optString("status"))) {
                    runOnUiThread(() -> Toast.makeText(this, obj.optString("mensagem", "Código não encontrado ou expirado."), Toast.LENGTH_LONG).show());
                    return;
                }
                suporteSessaoId = obj.optString("sessao_id", "");
                suporteCodigoAtual = codigo;
                suporteAtivo = true;
                runOnUiThread(() -> {
                    Toast.makeText(this, "Suporte conectado. Aguarde o atendente.", Toast.LENGTH_LONG).show();
                    iniciarPollSuporte();
                    mostrarTelaCorreta();
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Erro no suporte: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    private void iniciarPollSuporte() {
        suporteHandler.removeCallbacksAndMessages(null);
        suporteHandler.postDelayed(new Runnable() {
            @Override public void run() {
                if (!suporteAtivo || suporteSessaoId == null || suporteSessaoId.isEmpty()) return;
                consultarComandosSuporte();
                suporteHandler.postDelayed(this, 3000);
            }
        }, 1200);
    }

    private void consultarComandosSuporte() {
        new Thread(() -> {
            try {
                String tela = edtLicenca == null ? "permissoes" : "licenca";
                String url = Config.API_SUPORTE + "?action=poll&sessao_id=" + URLEncoder.encode(suporteSessaoId, "UTF-8")
                        + "&tela=" + URLEncoder.encode(tela, "UTF-8")
                        + "&permissoes=" + URLEncoder.encode(permissoesLiberadas() ? "sim" : "nao", "UTF-8");
                JSONObject obj = new JSONObject(httpGet(url));
                String status = obj.optString("status", "");
                if ("encerrado".equalsIgnoreCase(status)) {
                    suporteAtivo = false;
                    runOnUiThread(() -> Toast.makeText(this, "Suporte encerrado.", Toast.LENGTH_LONG).show());
                    return;
                }
                String cmd = obj.optString("comando", "");
                String msg = obj.optString("mensagem", "");
                String lic = obj.optString("licenca", "");
                if (cmd == null || cmd.trim().isEmpty()) return;
                runOnUiThread(() -> executarComandoSuporte(cmd, msg, lic));
            } catch (Exception ignored) {}
        }).start();
    }

    private void executarComandoSuporte(String cmd, String msg, String licenca) {
        if (msg != null && !msg.trim().isEmpty()) Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
        if ("abrir_permissoes".equals(cmd)) {
            montarTelaPermissoes();
            abrirPermissoesNecessarias();
        } else if ("abrir_ativacao".equals(cmd)) {
            if (permissoesLiberadas()) confirmarPermissoes();
            montarTelaAtivacao();
        } else if ("preencher_licenca".equals(cmd)) {
            if (permissoesLiberadas()) confirmarPermissoes();
            montarTelaAtivacao();
            if (edtLicenca != null && licenca != null) edtLicenca.setText(licenca);
        } else if ("ativar_licenca".equals(cmd)) {
            if (permissoesLiberadas()) confirmarPermissoes();
            montarTelaAtivacao();
            if (edtLicenca != null && licenca != null && licenca.matches("\\d{11}")) edtLicenca.setText(licenca);
            if (edtLicenca != null) ativar();
        } else if ("mensagem".equals(cmd)) {
            // Mensagem já foi mostrada acima.
        } else if ("encerrar".equals(cmd)) {
            suporteAtivo = false;
            Toast.makeText(this, "Suporte encerrado.", Toast.LENGTH_LONG).show();
        }
    }

    private void abrirPropaganda() {
        try {
            if (propagandaLink == null || propagandaLink.trim().isEmpty()) return;
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(propagandaLink.trim()));
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível abrir o link da propaganda.", Toast.LENGTH_LONG).show();
        }
    }

    private void mostrarTelaPermissoes() {
        montarTelaPermissoes();
    }

    private void montarTelaPermissoes() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = criarContainer(scroll);
        adicionarTopo(root);

        TextView subtitulo = new TextView(this);
        subtitulo.setText(textoPermissao);
        subtitulo.setTextColor(TEXTO_SUAVE);
        subtitulo.setTextSize(isTV() ? 20 : 16);
        subtitulo.setGravity(Gravity.CENTER);
        subtitulo.setPadding(dp(6), 0, dp(6), dp(18));
        root.addView(subtitulo, new LinearLayout.LayoutParams(-1, -2));

        TextView lista = new TextView(this);
        lista.setText(statusPermissoesTexto());
        lista.setTextColor(Color.WHITE);
        lista.setTextSize(isTV() ? 18 : 15);
        lista.setPadding(dp(18), dp(16), dp(18), dp(16));
        lista.setBackground(criarBorda(Color.argb(85, 30, 35, 50), Color.argb(120, 255, 255, 255), dp(16), dp(1)));
        root.addView(lista, new LinearLayout.LayoutParams(-1, -2));

        Button btn = criarBotao(textoBotaoPermissao);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(isTV() ? 70 : 62));
        bp.setMargins(0, dp(20), 0, dp(12));
        root.addView(btn, bp);
        btn.setOnClickListener(v -> abrirPermissoesNecessarias());
        btn.requestFocus();

        Button atualizar = criarBotao("JÁ LIBEREI, VERIFICAR AGORA");
        atualizar.setBackground(criarBorda(Color.argb(90, 20, 20, 28), COR_PRINCIPAL, dp(16), dp(1)));
        root.addView(atualizar, new LinearLayout.LayoutParams(-1, dp(isTV() ? 62 : 54)));
        atualizar.setOnClickListener(v -> verificarPermissoesEContinuar());

        adicionarPropaganda(root);
        adicionarSuporteRemoto(root);

        setContentView(scroll);
    }

    private void montarTelaAtivacao() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = criarContainer(scroll);
        adicionarTopo(root);

        TextView subtitulo = new TextView(this);
        subtitulo.setText(appSubtitulo);
        subtitulo.setTextColor(TEXTO_SUAVE);
        subtitulo.setTextSize(isTV() ? 20 : 16);
        subtitulo.setGravity(Gravity.CENTER);
        subtitulo.setPadding(dp(8), 0, dp(8), dp(24));
        root.addView(subtitulo, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout inputBox = new LinearLayout(this);
        inputBox.setOrientation(LinearLayout.HORIZONTAL);
        inputBox.setGravity(Gravity.CENTER_VERTICAL);
        inputBox.setPadding(dp(18), dp(10), dp(18), dp(10));
        inputBox.setBackground(criarBorda(Color.argb(65, 120, 10, 20), COR_PRINCIPAL, dp(18), dp(1)));

        TextView lock = new TextView(this);
        lock.setText("#");
        lock.setTextColor(COR_PRINCIPAL);
        lock.setTextSize(isTV() ? 34 : 27);
        lock.setTypeface(Typeface.DEFAULT_BOLD);
        lock.setGravity(Gravity.CENTER);
        inputBox.addView(lock, new LinearLayout.LayoutParams(dp(46), -1));

        edtLicenca = new TvEditText(this);
        edtLicenca.setHint("Código de 11 dígitos");
        edtLicenca.setTextColor(Color.WHITE);
        edtLicenca.setHintTextColor(Color.rgb(150, 145, 154));
        edtLicenca.setTextSize(isTV() ? 29 : 22);
        edtLicenca.setGravity(Gravity.CENTER);
        edtLicenca.setSingleLine(true);
        edtLicenca.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        edtLicenca.setFilters(new InputFilter[]{new InputFilter.LengthFilter(11)});
        edtLicenca.setBackgroundColor(Color.TRANSPARENT);
        inputBox.addView(edtLicenca, new LinearLayout.LayoutParams(0, -2, 1));

        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(-1, dp(isTV() ? 88 : 74));
        inputParams.setMargins(0, 0, 0, dp(10));
        root.addView(inputBox, inputParams);

        grupoTipoAparelho = new RadioGroup(this);
        grupoTipoAparelho.setOrientation(RadioGroup.VERTICAL);
        grupoTipoAparelho.setVisibility(View.GONE);
        grupoTipoAparelho.setPadding(dp(12), dp(6), dp(12), dp(10));
        grupoTipoAparelho.setBackground(criarBorda(Color.argb(55, 255, 255, 255), Color.argb(90, 255, 255, 255), dp(16), dp(1)));

        TextView escolhaTitulo = new TextView(this);
        escolhaTitulo.setText("Escolha onde será instalado:");
        escolhaTitulo.setTextColor(TEXTO_CLARO);
        escolhaTitulo.setTextSize(isTV() ? 18 : 14);
        escolhaTitulo.setTypeface(Typeface.DEFAULT_BOLD);
        escolhaTitulo.setGravity(Gravity.CENTER);
        escolhaTitulo.setPadding(0, 0, 0, dp(6));
        grupoTipoAparelho.addView(escolhaTitulo, new RadioGroup.LayoutParams(-1, -2));

        RadioButton opcaoAndroid = criarOpcaoTipo(1001, nomeOpcaoAndroid);
        RadioButton opcaoTvBox = criarOpcaoTipo(1002, nomeOpcaoTvBox);
        grupoTipoAparelho.addView(opcaoAndroid);
        grupoTipoAparelho.addView(opcaoTvBox);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1, -2);
        gp.setMargins(0, 0, 0, dp(14));
        root.addView(grupoTipoAparelho, gp);

        grupoTipoAparelho.setOnCheckedChangeListener((g, checkedId) -> {
            if (checkedId == 1001) tipoAparelhoEscolhido = "android";
            else if (checkedId == 1002) tipoAparelhoEscolhido = "tv_box";
        });

        edtLicenca.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence texto, int start, int before, int count) {
                boolean mostrar = texto != null && texto.toString().trim().length() == 11;
                grupoTipoAparelho.setVisibility(mostrar ? View.VISIBLE : View.GONE);
                if (!mostrar) {
                    grupoTipoAparelho.clearCheck();
                    tipoAparelhoEscolhido = "";
                }
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        btnAtivar = criarBotao(textoBotaoAtivar);
        LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(-1, dp(isTV() ? 72 : 62));
        btnParams.setMargins(0, 0, 0, dp(18));
        root.addView(btnAtivar, btnParams);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setVisibility(View.GONE);
        progress.setMax(100);
        LinearLayout.LayoutParams progressParams = new LinearLayout.LayoutParams(-1, dp(8));
        progressParams.setMargins(0, 0, 0, dp(14));
        root.addView(progress, progressParams);

        txtStatus = new TextView(this);
        txtStatus.setText(msgPronto);
        txtStatus.setTextColor(TEXTO_SUAVE);
        txtStatus.setTextSize(isTV() ? 17 : 14);
        txtStatus.setGravity(Gravity.CENTER);
        txtStatus.setPadding(dp(6), dp(8), dp(6), dp(8));
        root.addView(txtStatus, new LinearLayout.LayoutParams(-1, -2));

        btnApagarConfig = criarBotao("APAGAR CONFIG BAIXADA");
        btnApagarConfig.setBackground(criarBorda(Color.argb(90,20,20,28), Color.argb(170,255,255,255), dp(16), dp(1)));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, dp(isTV() ? 58 : 50));
        ap.setMargins(0, dp(12), 0, 0);
        root.addView(btnApagarConfig, ap);
        btnApagarConfig.setOnClickListener(v -> apagarConfigBaixada());

        adicionarPropaganda(root);
        adicionarSuporteRemoto(root);

        btnAtivar.setOnClickListener(v -> ativar());
        configurarTecladoTv(edtLicenca, btnAtivar, () -> {
            if (grupoTipoAparelho.getVisibility() == View.VISIBLE) {
                opcaoAndroid.requestFocus();
            } else {
                btnAtivar.requestFocus();
            }
        });
        btnAtivar.requestFocus();
        setContentView(scroll);
    }

    private void iniciarVerificacaoRoot() {
        if (verificandoRoot || removendoRoot) return;
        verificandoRoot = true;
        verificacaoRootConcluida = false;
        rootGateLiberado = false;
        rootDetectado = false;
        montarTelaRoot();

        new Thread(() -> {
            RootInfo info = detectarRootReal();
            ultimaInfoRoot = info;
            rootDetectado = info.rooted;
            verificacaoRootConcluida = true;
            verificandoRoot = false;

            runOnUiThread(() -> {
                montarTelaRoot();
                if (!rootDetectado) {
                    rootHandler.removeCallbacksAndMessages(null);
                    rootHandler.postDelayed(() -> {
                        if (!rootDetectado && verificacaoRootConcluida && !removendoRoot) {
                            rootGateLiberado = true;
                            mostrarTelaCorreta();
                        }
                    }, 1800);
                }
            });
        }, "root-check").start();
    }

    private void montarTelaRoot() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = criarContainer(scroll);
        adicionarTopo(root);

        TextView titulo = new TextView(this);
        titulo.setText(verificandoRoot || !verificacaoRootConcluida ? "VERIFICANDO ROOT" :
                (rootDetectado ? "⚠ ROOT DETECTADO" : "✓ APARELHO SEM ROOT"));
        titulo.setTextColor(rootDetectado ? Color.rgb(255, 90, 100) : Color.rgb(105, 235, 155));
        titulo.setTextSize(isTV() ? 28 : 22);
        titulo.setTypeface(Typeface.DEFAULT_BOLD);
        titulo.setGravity(Gravity.CENTER);
        titulo.setPadding(dp(10), dp(4), dp(10), dp(12));
        root.addView(titulo, new LinearLayout.LayoutParams(-1, -2));

        txtRootStatus = new TextView(this);
        txtRootStatus.setText(removendoRoot ? "Removendo o root verdadeiro do sistema. Não desligue o aparelho..." :
                (!verificacaoRootConcluida ? "Detectando automaticamente o acesso de superusuário..." :
                        (rootDetectado ? textoRootDetectado() : "Este aparelho não tem root. Abrindo a próxima etapa...")));
        txtRootStatus.setTextColor(TEXTO_CLARO);
        txtRootStatus.setTextSize(isTV() ? 19 : 15);
        txtRootStatus.setGravity(Gravity.CENTER);
        txtRootStatus.setPadding(dp(18), dp(18), dp(18), dp(18));
        int corBorda = rootDetectado ? Color.rgb(235, 30, 45) : Color.rgb(65, 190, 115);
        txtRootStatus.setBackground(criarBorda(Color.argb(95, 25, 25, 34), corBorda, dp(16), dp(1)));
        root.addView(txtRootStatus, new LinearLayout.LayoutParams(-1, -2));

        progressoRoot = new ProgressBar(this);
        progressoRoot.setIndeterminate(true);
        progressoRoot.setVisibility((verificandoRoot || removendoRoot || !verificacaoRootConcluida) ? View.VISIBLE : View.GONE);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(dp(isTV() ? 58 : 48), dp(isTV() ? 58 : 48));
        pp.gravity = Gravity.CENTER_HORIZONTAL;
        pp.setMargins(0, dp(18), 0, dp(12));
        root.addView(progressoRoot, pp);

        if (rootDetectado && verificacaoRootConcluida) {
            btnRemoverRoot = criarBotao(removendoRoot ? "REMOVENDO ROOT..." : "REMOVER ROOT");
            btnRemoverRoot.setEnabled(!removendoRoot);
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(isTV() ? 72 : 62));
            bp.setMargins(0, dp(8), 0, dp(10));
            root.addView(btnRemoverRoot, bp);
            btnRemoverRoot.setOnClickListener(v -> removerRootReal());
            Button btnPularRoot = criarBotao("PULAR E CONTINUAR");
            btnPularRoot.setBackground(criarBorda(Color.argb(90,20,20,28), Color.argb(170,255,255,255), dp(16), dp(1)));
            LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, dp(isTV() ? 62 : 54));
            sp.setMargins(0, dp(4), 0, dp(10));
            root.addView(btnPularRoot, sp);
            btnPularRoot.setEnabled(!removendoRoot);
            btnPularRoot.setOnClickListener(v -> {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_ROOT_PULADO, true).apply();
                rootDetectado = false; verificacaoRootConcluida = true; rootGateLiberado = true;
                mostrarTelaCorreta();
            });
            if (!removendoRoot) btnRemoverRoot.requestFocus();
        }

        TextView rodape = new TextView(this);
        rodape.setText(rootDetectado
                ? "Escolha REMOVER ROOT para tentar a remoção direta ou PULAR E CONTINUAR para seguir sem remover."
                : "A verificação de root foi concluída.");
        rodape.setTextColor(TEXTO_SUAVE);
        rodape.setTextSize(isTV() ? 15 : 12);
        rodape.setGravity(Gravity.CENTER);
        rodape.setPadding(dp(8), dp(10), dp(8), 0);
        root.addView(rodape, new LinearLayout.LayoutParams(-1, -2));

        setContentView(scroll);
    }

    private String textoRootDetectado() {
        String tipo = ultimaInfoRoot == null ? "" : ultimaInfoRoot.type;
        if ("magisk".equals(tipo)) {
            return "Root Magisk detectado. Toque em REMOVER ROOT: a limpeza será executada dentro deste ativador, sem abrir outro aplicativo.";
        }
        if ("kernelsu".equals(tipo)) {
            return "Root KernelSU detectado. Toque em REMOVER ROOT: o ativador tentará a remoção direta usando os arquivos de restauração disponíveis no aparelho.";
        }
        if ("apatch".equals(tipo)) {
            return "Root APatch detectado. Toque em REMOVER ROOT: o processo será feito dentro deste ativador, sem abrir outra tela.";
        }
        if (ultimaInfoRoot != null && !ultimaInfoRoot.active) {
            return "Foram encontrados arquivos de root, mas o acesso de superusuário não foi autorizado. Autorize a solicitação e toque novamente em REMOVER ROOT.";
        }
        return "Seu aparelho tem ROOT ativo. O ativador removerá os arquivos de superusuário e reiniciará o aparelho para validar.";
    }

    private RootInfo detectarRootReal() {
        RootInfo info = new RootInfo();
        StringBuilder detalhes = new StringBuilder();

        if (android.os.Process.myUid() == 0) {
            info.active = true;
            detalhes.append("processo_uid_0;");
        }

        String[] rootPaths = caminhosRootConhecidos();
        String comandoSu = null;
        for (String path : rootPaths) {
            try {
                File f = new File(path);
                if (f.exists()) {
                    info.artifacts = true;
                    detalhes.append(path).append(';');
                    if (comandoSu == null && (path.endsWith("/su") || path.endsWith("/.su") || path.endsWith("/daemonsu"))) {
                        comandoSu = path;
                    }
                }
            } catch (Exception ignored) {}
        }

        CommandResult pacotes = executarComando(new String[]{"sh", "-c",
                "pm list packages 2>/dev/null | grep -Ei 'magisk|kernelsu|apatch|supersu|superuser|kingroot|kingo' || true"}, 6);
        String pkg = pacotes.output.toLowerCase();
        if (pkg.contains("magisk")) info.type = "magisk";
        else if (pkg.contains("kernelsu")) info.type = "kernelsu";
        else if (pkg.contains("apatch")) info.type = "apatch";
        else if (pkg.contains("supersu") || pkg.contains("superuser") || pkg.contains("kingroot") || pkg.contains("kingo")) info.type = "system";

        CommandResult indicadores = executarComando(new String[]{"sh", "-c",
                "PATH=/sbin:/system/sbin:/system/bin:/system/xbin:/vendor/bin:/product/bin:/odm/bin:$PATH; " +
                        "command -v magisk 2>/dev/null || true; command -v su 2>/dev/null || true; " +
                        "[ -d /data/adb/magisk ] && echo MAGISK_DIR || true; " +
                        "[ -d /data/adb/ksu ] && echo KERNELSU_DIR || true; " +
                        "[ -d /data/adb/ap ] && echo APATCH_DIR || true"}, 6);
        String ind = indicadores.output.toLowerCase();
        if (ind.contains("magisk")) info.type = "magisk";
        else if (ind.contains("kernelsu") || ind.contains("ksu")) info.type = "kernelsu";
        else if (ind.contains("apatch")) info.type = "apatch";
        if (!ind.trim().isEmpty()) {
            info.artifacts = true;
            detalhes.append(ind.replace('\n', ';'));
        }

        List<String> suCandidates = new ArrayList<>();
        suCandidates.add("su");
        if (comandoSu != null && !"su".equals(comandoSu)) suCandidates.add(comandoSu);
        for (String path : rootPaths) {
            if ((path.endsWith("/su") || path.endsWith("/.su")) && !suCandidates.contains(path)) suCandidates.add(path);
        }

        for (String su : suCandidates) {
            CommandResult id = executarComando(new String[]{su, "-c", "id"}, 12);
            if (id.output.contains("uid=0")) {
                info.active = true;
                info.suCommand = su;
                detalhes.append("uid0_por_").append(su).append(';');
                break;
            }
        }

        if (info.type.isEmpty()) info.type = "system";
        info.rooted = info.active || info.artifacts;
        info.details = detalhes.toString();
        return info;
    }

    private String[] caminhosRootConhecidos() {
        return new String[]{
                "/system/bin/su", "/system/xbin/su", "/sbin/su", "/su/bin/su",
                "/vendor/bin/su", "/product/bin/su", "/odm/bin/su",
                "/system/sd/xbin/su", "/system/bin/failsafe/su", "/data/local/xbin/su",
                "/data/local/bin/su", "/data/local/su", "/system/xbin/daemonsu",
                "/system/bin/.ext/.su", "/system/app/Superuser.apk", "/system/app/SuperSU.apk",
                "/system/priv-app/Superuser.apk", "/system/priv-app/SuperSU.apk",
                "/sbin/.magisk", "/data/adb/magisk", "/data/adb/ksu", "/data/adb/ap"
        };
    }

    private void removerRootReal() {
        if (removendoRoot) return;
        removendoRoot = true;
        montarTelaRoot();

        new Thread(() -> {
            RootInfo atual = detectarRootReal();
            if (!atual.active) {
                removendoRoot = false;
                ultimaInfoRoot = atual;
                runOnUiThread(() -> {
                    montarTelaRoot();
                    Toast.makeText(this, "O aparelho não autorizou o acesso root. Autorize a solicitação de superusuário e tente novamente.", Toast.LENGTH_LONG).show();
                });
                return;
            }

            String su = atual.suCommand == null || atual.suCommand.trim().isEmpty() ? "su" : atual.suCommand;
            String script = scriptRemocaoRootDireta();
            CommandResult resultado = executarComando(new String[]{su, "-c", script}, 95);

            boolean removeu = resultado.output.contains("ROOT_REMOVE_OK");
            boolean backupAusente = resultado.output.contains("ROOT_BACKUP_MISSING");
            boolean tipoKernelSemBackup = resultado.output.contains("ROOT_KERNEL_BACKUP_MISSING");
            boolean restou = resultado.output.contains("ROOT_FILES_REMAIN");

            if (removeu && !restou) {
                runOnUiThread(() -> {
                    if (txtRootStatus != null) {
                        txtRootStatus.setText("Purificando o sistema... O aparelho será reiniciado automaticamente em instantes.");
                    }
                    Toast.makeText(this, "Root removido. Reiniciando o aparelho para confirmar.", Toast.LENGTH_LONG).show();
                    rootHandler.postDelayed(() -> {
                        if (removendoRoot && !isFinishing()) {
                            removendoRoot = false;
                            montarTelaRoot();
                            if (txtRootStatus != null) {
                                txtRootStatus.setText("A limpeza terminou, mas o aparelho não reiniciou sozinho. Reinicie-o para validar a remoção.");
                            }
                        }
                    }, 14000);
                });
                return;
            }

            removendoRoot = false;
            RootInfo depois = detectarRootReal();
            ultimaInfoRoot = depois;
            rootDetectado = depois.rooted;
            verificacaoRootConcluida = true;

            runOnUiThread(() -> {
                montarTelaRoot();
                String msg;
                if (backupAusente) {
                    msg = "O Magisk foi detectado, mas o backup original do boot não existe no aparelho. A remoção direta foi interrompida para não danificar a TV.";
                } else if (tipoKernelSemBackup) {
                    msg = "Este root está gravado no kernel/boot e não existe imagem original salva no aparelho. A remoção direta foi interrompida para evitar falha de inicialização.";
                } else if (resultado.timedOut) {
                    msg = "A remoção demorou além do limite. Reinicie o aparelho e verifique novamente.";
                } else {
                    msg = "Não foi possível concluir a remoção nesta ROM. Nenhuma outra tela foi aberta e a licença continua bloqueada.";
                }
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
                if (txtRootStatus != null) txtRootStatus.setText(msg);
            });
        }, "root-remove-direct").start();
    }

    private String scriptRemocaoRootDireta() {
        return "PATH=/sbin:/system/sbin:/system/bin:/system/xbin:/vendor/bin:/product/bin:/odm/bin:/data/adb/magisk:$PATH\n" +
                "echo ROOT_REMOVE_START\n" +
                "id\n" +
                "SUCCESS=0\n" +
                "MAGISK_PRESENT=0\n" +
                "MAGISK_RESTORED=0\n" +
                "KERNEL_ROOT_PRESENT=0\n" +
                "MAGISKTMP=$(magisk --path 2>/dev/null || true)\n" +
                "MAGISKBIN=/data/adb/magisk\n" +
                "if [ -x /data/adb/magisk/magisk ]; then MAGISKCMD=/data/adb/magisk/magisk; else MAGISKCMD=magisk; fi\n" +
                "if [ -d /data/adb/magisk ] || command -v magisk >/dev/null 2>&1; then\n" +
                "  MAGISK_PRESENT=1\n" +
                "  SHA1=''\n" +
                "  for C in \"$MAGISKTMP/.magisk/config\" /data/.magisk /cache/.magisk; do\n" +
                "    if [ -f \"$C\" ]; then\n" +
                "      SHA1=$(sed -n 's/^SHA1=//p' \"$C\" | head -n 1)\n" +
                "      [ -n \"$SHA1\" ] && break\n" +
                "    fi\n" +
                "  done\n" +
                "  BACKUPDIR=''\n" +
                "  [ -n \"$SHA1\" ] && BACKUPDIR=/data/magisk_backup_${SHA1}\n" +
                "  if [ -n \"$BACKUPDIR\" ] && [ -f \"$BACKUPDIR/boot.img.gz\" ] && [ -f /data/adb/magisk/util_functions.sh ]; then\n" +
                "    BOOTMODE=true\n" +
                "    TMPDIR=/data/local/tmp/ativador_unroot\n" +
                "    mkdir -p \"$TMPDIR\"\n" +
                "    export BOOTMODE TMPDIR MAGISKBIN MAGISKTMP\n" +
                "    . /data/adb/magisk/util_functions.sh\n" +
                "    mount_partitions >/dev/null 2>&1 || true\n" +
                "    get_flags >/dev/null 2>&1 || true\n" +
                "    find_boot_image\n" +
                "    if [ -n \"$BOOTIMAGE\" ] && flash_image \"$BACKUPDIR/boot.img.gz\" \"$BOOTIMAGE\" >/dev/null 2>&1; then\n" +
                "      EXTRA_OK=1\n" +
                "      for N in dtb dtbo dtbs; do\n" +
                "        IMG=\"$BACKUPDIR/${N}.img.gz\"\n" +
                "        [ -f \"$IMG\" ] || continue\n" +
                "        DEV=$(find_block \"${N}${SLOT}\" \"$N\")\n" +
                "        if [ -n \"$DEV\" ]; then\n" +
                "          flash_image \"$IMG\" \"$DEV\" >/dev/null 2>&1 || EXTRA_OK=0\n" +
                "        fi\n" +
                "      done\n" +
                "      if [ \"$EXTRA_OK\" -eq 1 ]; then\n" +
                "        MAGISK_RESTORED=1\n" +
                "        SUCCESS=1\n" +
                "      fi\n" +
                "    fi\n" +
                "  else\n" +
                "    echo ROOT_BACKUP_MISSING\n" +
                "  fi\n" +
                "  \"$MAGISKCMD\" --remove-modules -n >/dev/null 2>&1 || true\n" +
                "fi\n" +
                "if [ -d /data/adb/ksu ] || [ -e /data/adb/ksud ] || [ -d /data/adb/ap ]; then\n" +
                "  KERNEL_ROOT_PRESENT=1\n" +
                "  echo ROOT_KERNEL_BACKUP_MISSING\n" +
                "fi\n" +
                "mount -o rw,remount / 2>/dev/null || true\n" +
                "mount -o remount,rw /system 2>/dev/null || mount -o rw,remount /system 2>/dev/null || true\n" +
                "mount -o remount,rw /vendor 2>/dev/null || true\n" +
                "mount -o remount,rw /product 2>/dev/null || true\n" +
                "mount -o remount,rw /odm 2>/dev/null || true\n" +
                "REMOVED=0\n" +
                "for P in /system/bin/su /system/xbin/su /sbin/su /su/bin/su /vendor/bin/su /product/bin/su /odm/bin/su /system/sd/xbin/su /system/bin/failsafe/su /data/local/xbin/su /data/local/bin/su /data/local/su /system/xbin/daemonsu /system/bin/.ext/.su; do\n" +
                "  if [ -e \"$P\" ] || [ -L \"$P\" ]; then\n" +
                "    chmod 700 \"$P\" 2>/dev/null || true\n" +
                "    rm -f \"$P\" 2>/dev/null && REMOVED=$((REMOVED+1))\n" +
                "  fi\n" +
                "done\n" +
                "for P in /system/app/Superuser.apk /system/app/SuperSU.apk /system/priv-app/Superuser.apk /system/priv-app/SuperSU.apk; do\n" +
                "  if [ -e \"$P\" ]; then rm -f \"$P\" 2>/dev/null && REMOVED=$((REMOVED+1)); fi\n" +
                "done\n" +
                "for D in /system/app/Superuser /system/app/SuperSU /system/priv-app/Superuser /system/priv-app/SuperSU /data/su /data/adb/su /data/local/su; do\n" +
                "  if [ -e \"$D\" ]; then rm -rf \"$D\" 2>/dev/null && REMOVED=$((REMOVED+1)); fi\n" +
                "done\n" +
                "pm uninstall --user 0 eu.chainfire.supersu >/dev/null 2>&1 || true\n" +
                "pm uninstall --user 0 com.noshufou.android.su >/dev/null 2>&1 || true\n" +
                "pm uninstall --user 0 com.kingroot.kinguser >/dev/null 2>&1 || true\n" +
                "pm uninstall --user 0 com.kingo.root >/dev/null 2>&1 || true\n" +
                "if [ \"$MAGISK_RESTORED\" -eq 1 ]; then\n" +
                "  \"$MAGISKCMD\" --stop >/dev/null 2>&1 || true\n" +
                "  rm -rf /data/adb/magisk /data/adb/modules /data/adb/modules_update /data/adb/post-fs-data.d /data/adb/service.d\n" +
                "  pm uninstall --user 0 com.topjohnwu.magisk >/dev/null 2>&1 || true\n" +
                "fi\n" +
                "LEFT=0\n" +
                "for P in /system/bin/su /system/xbin/su /sbin/su /su/bin/su /vendor/bin/su /product/bin/su /odm/bin/su /system/sd/xbin/su /system/bin/failsafe/su /data/local/xbin/su /data/local/bin/su /data/local/su /system/xbin/daemonsu /system/bin/.ext/.su; do\n" +
                "  if [ -e \"$P\" ] || [ -L \"$P\" ]; then LEFT=$((LEFT+1)); fi\n" +
                "done\n" +
                "if [ \"$MAGISK_PRESENT\" -eq 0 ] && [ \"$KERNEL_ROOT_PRESENT\" -eq 0 ] && [ \"$REMOVED\" -gt 0 ]; then SUCCESS=1; fi\n" +
                "sync\n" +
                "echo REMOVED=$REMOVED LEFT=$LEFT SUCCESS=$SUCCESS\n" +
                "if [ \"$SUCCESS\" -eq 1 ] && [ \"$LEFT\" -eq 0 ]; then\n" +
                "  echo ROOT_REMOVE_OK\n" +
                "  (sleep 4; reboot) >/dev/null 2>&1 &\n" +
                "else\n" +
                "  echo ROOT_FILES_REMAIN\n" +
                "fi\n";
    }

    private CommandResult executarComando(String[] comando, long timeoutSegundos) {
        CommandResult result = new CommandResult();
        Process processo = null;
        try {
            ProcessBuilder pb = new ProcessBuilder(comando);
            pb.redirectErrorStream(true);
            processo = pb.start();
            long limite = System.currentTimeMillis() + (timeoutSegundos * 1000L);
            boolean terminou = false;
            while (System.currentTimeMillis() < limite) {
                try {
                    result.exitCode = processo.exitValue();
                    terminou = true;
                    break;
                } catch (IllegalThreadStateException aindaExecutando) {
                    try { Thread.sleep(100); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); break; }
                }
            }
            if (!terminou) {
                result.timedOut = true;
                processo.destroy();
            }
            result.output = lerSaidaProcesso(processo);
        } catch (Exception e) {
            result.output = e.getClass().getSimpleName() + ": " + e.getMessage();
        } finally {
            if (processo != null) {
                try { processo.getInputStream().close(); } catch (Exception ignored) {}
                try { processo.getOutputStream().close(); } catch (Exception ignored) {}
                try { processo.getErrorStream().close(); } catch (Exception ignored) {}
                try { processo.destroy(); } catch (Exception ignored) {}
            }
        }
        return result;
    }

    private String lerSaidaProcesso(Process processo) {
        if (processo == null) return "";
        StringBuilder out = new StringBuilder();
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(processo.getInputStream()));
            String linha;
            while ((linha = reader.readLine()) != null) {
                if (out.length() < 12000) out.append(linha).append('\n');
            }
            reader.close();
        } catch (Exception ignored) {}
        return out.toString();
    }

    private void configurarTecladoTv(EditText campo, View focoDepois, Runnable aoConcluir) {
        campo.setImeOptions(EditorInfo.IME_ACTION_DONE | EditorInfo.IME_FLAG_NO_EXTRACT_UI);
        campo.setSingleLine(true);

        Runnable fechar = () -> {
            esconderTeclado(campo);
            campo.clearFocus();
            if (aoConcluir != null) aoConcluir.run();
            else if (focoDepois != null) focoDepois.requestFocus();
        };

        if (campo instanceof TvEditText) ((TvEditText) campo).setAoFecharTeclado(fechar);

        campo.setOnEditorActionListener((v, actionId, event) -> {
            boolean teclaEnter = event != null && event.getAction() == KeyEvent.ACTION_UP &&
                    (event.getKeyCode() == KeyEvent.KEYCODE_ENTER ||
                            event.getKeyCode() == KeyEvent.KEYCODE_NUMPAD_ENTER ||
                            event.getKeyCode() == KeyEvent.KEYCODE_DPAD_CENTER);
            boolean acaoConcluir = actionId == EditorInfo.IME_ACTION_DONE ||
                    actionId == EditorInfo.IME_ACTION_GO ||
                    actionId == EditorInfo.IME_ACTION_NEXT ||
                    actionId == EditorInfo.IME_ACTION_SEND ||
                    actionId == EditorInfo.IME_ACTION_UNSPECIFIED;
            if (teclaEnter || acaoConcluir) {
                fechar.run();
                return true;
            }
            return false;
        });

        campo.setOnKeyListener((v, keyCode, event) -> {
            if (event.getAction() == KeyEvent.ACTION_UP &&
                    (keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER)) {
                fechar.run();
                return true;
            }
            return false;
        });
    }

    private void esconderTeclado(View view) {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        } catch (Exception ignored) {}
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event != null && event.getKeyCode() == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
            View foco = getCurrentFocus();
            if (foco instanceof EditText) {
                esconderTeclado(foco);
                foco.clearFocus();
                if (btnAtivar != null) btnAtivar.requestFocus();
                return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }

    private class TvEditText extends EditText {
        private Runnable aoFecharTeclado;

        TvEditText(Context context) {
            super(context);
        }

        void setAoFecharTeclado(Runnable runnable) {
            aoFecharTeclado = runnable;
        }

        @Override
        public boolean onKeyPreIme(int keyCode, KeyEvent event) {
            if (keyCode == KeyEvent.KEYCODE_BACK && event != null && event.getAction() == KeyEvent.ACTION_UP) {
                esconderTeclado(this);
                clearFocus();
                if (aoFecharTeclado != null) aoFecharTeclado.run();
                return true;
            }
            return super.onKeyPreIme(keyCode, event);
        }
    }

    private static class RootInfo {
        boolean rooted;
        boolean active;
        boolean artifacts;
        String type = "";
        String suCommand = "su";
        String details = "";
    }

    private static class CommandResult {
        int exitCode = -1;
        boolean timedOut;
        String output = "";
    }

    private RadioButton criarOpcaoTipo(int id, String texto) {
        RadioButton rb = new RadioButton(this);
        rb.setId(id);
        rb.setText(texto);
        rb.setTextColor(TEXTO_CLARO);
        rb.setTextSize(isTV() ? 20 : 16);
        rb.setTypeface(Typeface.DEFAULT_BOLD);
        rb.setPadding(dp(4), dp(4), dp(4), dp(4));
        rb.setFocusable(true);
        return rb;
    }

    private Button criarBotao(String texto) {
        Button b = new Button(this);
        b.setText(texto);
        b.setTextColor(Color.WHITE);
        b.setTextSize(isTV() ? 20 : 16);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setAllCaps(false);
        b.setFocusable(true);
        b.setBackground(criarGradienteBotao());
        return b;
    }

    private GradientDrawable criarBorda(int corFundo, int corBorda, int raio, int largura) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(corFundo);
        gd.setCornerRadius(raio);
        gd.setStroke(largura, corBorda);
        return gd;
    }

    private GradientDrawable criarGradienteBotao() {
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{COR_PRINCIPAL_ESCURO, COR_PRINCIPAL, Color.rgb(255, 95, 75)});
        gd.setCornerRadius(dp(16));
        return gd;
    }

    private int dp(int valor) {
        return (int) (valor * getResources().getDisplayMetrics().density + 0.5f);
    }

    private boolean permissoesLiberadas() {
        boolean storageOk = true;
        if (Build.VERSION.SDK_INT >= 30) {
            // Permissão geral verdadeira do Android 11+: Acesso a todos os arquivos.
            storageOk = Environment.isExternalStorageManager();
        } else if (Build.VERSION.SDK_INT >= 23 && Build.VERSION.SDK_INT <= 29) {
            // Android 6 até 10 usa a permissão normal de armazenamento.
            storageOk = checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        }

        // Não basta o Android dizer que liberou: testa escrita real no aparelho.
        if (storageOk) {
            storageOk = testarEscritaPermissaoReal();
        }

        boolean installOk = true;
        if (Build.VERSION.SDK_INT >= 26) installOk = getPackageManager().canRequestPackageInstalls();
        return storageOk && installOk;
    }

    private void verificarPermissoesEContinuar() {
        if (permissoesLiberadas()) {
            confirmarPermissoes();
            Toast.makeText(this, "Permissões confirmadas. Agora digite a licença.", Toast.LENGTH_LONG).show();
            montarTelaAtivacao();
        } else {
            Toast.makeText(this, "Ainda falta liberar uma permissão. Toque em Liberar permissões.", Toast.LENGTH_LONG).show();
            montarTelaPermissoes();
        }
    }

    private String statusPermissoesTexto() {
        StringBuilder sb = new StringBuilder();
        boolean acessoArquivos = true;
        if (Build.VERSION.SDK_INT >= 30) {
            acessoArquivos = Environment.isExternalStorageManager();
            sb.append(acessoArquivos ? "✓ Acesso a todos os arquivos liberado\n" : "• Liberar Acesso a todos os arquivos\n");
        } else if (Build.VERSION.SDK_INT >= 23 && Build.VERSION.SDK_INT <= 29) {
            acessoArquivos = checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
            sb.append(acessoArquivos ? "✓ Armazenamento liberado\n" : "• Liberar armazenamento\n");
        } else {
            sb.append("✓ Armazenamento liberado\n");
        }

        if (acessoArquivos) {
            sb.append(testarEscritaPermissaoReal() ? "✓ Escrita real confirmada no aparelho\n" : "• Permissão marcada, mas escrita real ainda bloqueada\n");
        }

        if (Build.VERSION.SDK_INT >= 26) sb.append(getPackageManager().canRequestPackageInstalls() ? "✓ Instalação de apps liberada" : "• Permitir instalar aplicativos desconhecidos");
        else sb.append("✓ Instalação liberada");
        return sb.toString();
    }

    private boolean testarEscritaPermissaoReal() {
        // Testa primeiro o caminho que algumas TVs pedem no erro.
        File[] testes = new File[]{
                new File("/storage/self/primary/Android/.config_teste_permissao"),
                new File("/storage/emulated/0/Android/.config_teste_permissao"),
                new File(Environment.getExternalStorageDirectory(), "Android/.config_teste_permissao")
        };

        for (File teste : testes) {
            if (teste == null) continue;
            try {
                File pai = teste.getParentFile();
                if (pai != null && !pai.exists()) pai.mkdirs();
                FileOutputStream fos = new FileOutputStream(teste, false);
                fos.write("ok".getBytes("UTF-8"));
                fos.flush();
                fos.close();
                // Se conseguiu criar no caminho pedido, apaga só o teste.
                try { teste.delete(); } catch (Exception ignored) {}
                return true;
            } catch (Exception ignored) {}
        }

        // Se a TV bloqueia /Android, confirma pelo caminho automático correto do aparelho.
        try {
            File pastaApp = getExternalFilesDir(null);
            if (pastaApp != null) {
                File teste = new File(pastaApp, ".config_teste_permissao");
                File pai = teste.getParentFile();
                if (pai != null && !pai.exists()) pai.mkdirs();
                FileOutputStream fos = new FileOutputStream(teste, false);
                fos.write("ok".getBytes("UTF-8"));
                fos.flush();
                fos.close();
                try { teste.delete(); } catch (Exception ignored) {}
                return true;
            }
        } catch (Exception ignored) {}

        return false;
    }

    private boolean abrirIntentPermissao(Intent intent, String mensagem) {
        try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            aguardandoRetornoPermissao = true;
            startActivity(intent);
            Toast.makeText(this, mensagem, Toast.LENGTH_LONG).show();
            return true;
        } catch (Exception ignored) {
            return false;
        }
    }

    private boolean abrirTelaTodosArquivos() {
        if (Build.VERSION.SDK_INT < 30) return false;
        String pacote = getPackageName();

        Intent[] tentativas = new Intent[]{
                // Tela verdadeira do Android 11+ para o app atual.
                new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).setData(Uri.parse("package:" + pacote)),
                // Lista geral: Acesso especial > Acesso a todos os arquivos.
                new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION),
                // Fallback usado por algumas ROMs de TV Box.
                new Intent("android.settings.MANAGE_ALL_FILES_ACCESS_PERMISSION"),
                new Intent("android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION").setData(Uri.parse("package:" + pacote)),
                // Último recurso: detalhes do app para o usuário entrar em permissões manualmente.
                new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(Uri.parse("package:" + pacote)),
                new Intent(Settings.ACTION_SETTINGS)
        };

        for (Intent i : tentativas) {
            if (abrirIntentPermissao(i, "Ative a permissão geral de arquivos para o ativador e volte aqui.")) return true;
        }
        return false;
    }

    private boolean abrirTelaInstalarAppsDesconhecidos() {
        if (Build.VERSION.SDK_INT < 26) return false;
        Intent intent = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName()));
        return abrirIntentPermissao(intent, "Marque 'Permitir desta fonte' e volte para o ativador.");
    }

    private boolean abrirTelaPermissoesDiretoDoApp() {
        String pacote = getPackageName();

        Intent[] tentativas = new Intent[]{
                new Intent("android.intent.action.MANAGE_APP_PERMISSIONS")
                        .putExtra("android.intent.extra.PACKAGE_NAME", pacote)
                        .putExtra("android.provider.extra.APP_PACKAGE", pacote)
                        .putExtra("package", pacote),
                new Intent("android.settings.APP_PERMISSION_SETTINGS")
                        .putExtra("android.intent.extra.PACKAGE_NAME", pacote)
                        .putExtra("android.provider.extra.APP_PACKAGE", pacote)
                        .putExtra("package", pacote),
                new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                        .setData(Uri.parse("package:" + pacote))
        };

        for (Intent intent : tentativas) {
            if (abrirIntentPermissao(intent, "Libere as permissões do aplicativo e volte para o ativador.")) return true;
        }
        return false;
    }

    private void abrirPermissoesNecessarias() {
        try {
            // Android 11+ precisa da permissão especial verdadeira para salvar em caminhos públicos/fixos.
            if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
                if (abrirTelaTodosArquivos()) return;
                if (abrirTelaPermissoesDiretoDoApp()) return;
            }

            // Android 6 até 10 usa solicitação normal de armazenamento.
            if (Build.VERSION.SDK_INT >= 23 && Build.VERSION.SDK_INT <= 29
                    && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                aguardandoRetornoPermissao = true;
                requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, 10);
                return;
            }

            // Permissão real para abrir o instalador do APK baixado.
            if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
                if (abrirTelaInstalarAppsDesconhecidos()) return;
                if (abrirTelaPermissoesDiretoDoApp()) return;
            }

            verificarPermissoesEContinuar();
        } catch (Exception e) {
            if (abrirTelaPermissoesDiretoDoApp()) return;
            try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch (Exception ignored2) {}
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 10) {
            verificarPermissoesEContinuar();
        }
    }

    private void ativar() {
        if (!permissoesLiberadas()) {
            Toast.makeText(this, "Libere as permissões antes de usar a licença.", Toast.LENGTH_LONG).show();
            mostrarTelaPermissoes();
            return;
        }
        String licenca = edtLicenca.getText().toString().trim();
        if (!licenca.matches("\\d{11}")) {
            mensagem("Digite uma licença com exatamente 11 números.");
            return;
        }
        if (tipoAparelhoEscolhido == null || tipoAparelhoEscolhido.trim().isEmpty()) {
            mensagem("Escolha a opção do aparelho antes de ativar.");
            return;
        }
        LauncherStore.setDeviceType(this, tipoAparelhoEscolhido);
        if (DeviceControl.isDeviceOwner(this)) DeviceControl.enforceManagedState(this);
        progress.setVisibility(View.VISIBLE);
        progress.setIndeterminate(true);
        btnAtivar.setEnabled(false);
        txtStatus.setText("Consultando licença...");

        new Thread(() -> {
            try {
                String json = chamarApi(licenca);
                if (json == null || json.trim().isEmpty()) {
                    runOnUiThread(() -> finalizar("Não foi possível consultar a licença. Verifique sua internet e tente novamente."));
                    return;
                }
                JSONObject obj = new JSONObject(json);
                String status = obj.optString("status", "erro");
                String msg = obj.optString("mensagem", "Resposta recebida.");

                if (!"ok".equalsIgnoreCase(status)) {
                    String erroLicenca = msg == null || msg.trim().isEmpty()
                            ? "Licença inválida. Verifique o código e tente novamente."
                            : msg;
                    runOnUiThread(() -> finalizar(erroLicenca));
                    return;
                }

                PolicyStore.setLicense(this, licenca);
                String targetServidor = obj.optString("app_target", tipoAparelhoEscolhido).trim();
                if (!targetServidor.isEmpty()) LauncherStore.setDeviceType(this, targetServidor);
                String deviceCode = obj.optString("device_code", "").trim();
                if (!deviceCode.isEmpty()) LauncherStore.setDeviceCode(this, deviceCode);
                String controlFromLicense = obj.optString("control_url", "").trim();
                if (!controlFromLicense.isEmpty()) PolicyStore.setControlUrl(this, controlFromLicense);
                PolicyScheduler.schedule(this);
                new Thread(() -> PolicySync.sync(getApplicationContext()), "policy-after-license").start();

                runOnUiThread(() -> {
                    progress.setIndeterminate(false);
                    progress.setProgress(0);
                    txtStatus.setText("Licença ativada com sucesso.");
                });
                Thread.sleep(700);

                String configUrl = normalizarUrl(obj.optString("config_url", ""));
                String propertiesUrl = normalizarUrl(obj.optString("properties_url", ""));
                String apkUrl = normalizarUrl(obj.optString("apk_url", ""));
                String unitvNome = obj.optString("unitv_name", tipoAparelhoEscolhido.equals("tv_box") ? "UniTV - TV Box / Fire Stick / MXQ" : "UniTV - TV Android / Celular");
                String unitvVersao = obj.optString("unitv_version", "").trim();

                if (configUrl.isEmpty()) {
                    runOnUiThread(() -> finalizar("Licença liberada, mas o painel não enviou a config."));
                    return;
                }

                runOnUiThread(() -> txtStatus.setText("Baixando configuração..."));
                byte[] configBytes = baixarBytes(configUrl, "Baixando configuração");
                salvarEmPastas(Config.NOME_CONFIG_FINAL, configBytes);

                if (!propertiesUrl.isEmpty()) {
                    runOnUiThread(() -> txtStatus.setText("Baixando propriedades..."));
                    byte[] propBytes = baixarBytes(propertiesUrl, "Baixando propriedades");
                    salvarEmPastas(Config.NOME_PROPERTIES_FINAL, propBytes);
                }

                File apkFile = null;
                if (!apkUrl.isEmpty()) {
                    if (!permissoesLiberadas()) {
                        runOnUiThread(() -> { finalizar("Permissão removida. Libere novamente para instalar o aplicativo."); mostrarTelaPermissoes(); });
                        return;
                    }
                    final String descricaoApk = unitvNome + (unitvVersao.isEmpty() ? "" : " v" + unitvVersao);
                    runOnUiThread(() -> txtStatus.setText("Baixando " + descricaoApk + "..."));
                    byte[] apkBytes = baixarBytes(apkUrl, "Baixando aplicativo");
                    String nomeArquivoApk = tipoAparelhoEscolhido.equals("tv_box") ? Config.NOME_APK_TV_BOX : Config.NOME_APK_ANDROID;
                    apkFile = salvarArquivoAlternativo(nomeArquivoApk, apkBytes);
                }

                File finalApkFile = apkFile;
                if (finalApkFile != null) LauncherStore.setActivationComplete(this, true);
                runOnUiThread(() -> {
                    if (finalApkFile != null) {
                        String versaoTxt = unitvVersao.isEmpty() ? "" : " v" + unitvVersao;
                        finalizar(comAvisoConfig("Configuração salva. Abrindo instalação de " + unitvNome + versaoTxt + "..."));
                        abrirInstalador(finalApkFile);
                    } else {
                        finalizar(comAvisoConfig("Configuração salva, mas nenhum APK principal foi configurado no painel."));
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> finalizar("Erro: " + e.getMessage()));
            }
        }).start();
    }

    private String chamarApi(String licenca) throws Exception {
        String androidId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        String aparelho = Build.MANUFACTURER + " " + Build.MODEL;
        String urlStr = Config.API_ATIVAR + "?codigo=" + URLEncoder.encode(licenca, "UTF-8")
                + "&device=" + URLEncoder.encode(aparelho, "UTF-8")
                + "&device_id=" + URLEncoder.encode(androidId == null ? "" : androidId, "UTF-8")
                + "&android=" + URLEncoder.encode(String.valueOf(Build.VERSION.SDK_INT), "UTF-8")
                + "&tipo=" + URLEncoder.encode(tipoAparelhoEscolhido, "UTF-8")
                + "&tipo_aparelho=" + URLEncoder.encode(tipoAparelhoEscolhido, "UTF-8");
        return httpGet(urlStr);
    }

    private String httpGet(String urlStr) throws Exception {
        Exception ultimoErro = null;
        for (String tentativa : gerarUrlsFallback(urlStr)) {
            try {
                HttpURLConnection conn = (HttpURLConnection) new URL(tentativa).openConnection();
                conn.setConnectTimeout(20000);
                conn.setReadTimeout(30000);
                conn.setRequestMethod("GET");
                InputStream is = conn.getResponseCode() >= 400 ? conn.getErrorStream() : conn.getInputStream();
                if (is == null) throw new Exception("API não respondeu. Código HTTP: " + conn.getResponseCode());
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line);
                br.close();
                return sb.toString();
            } catch (Exception e) {
                ultimoErro = e;
            }
        }
        throw ultimoErro == null ? new Exception("Falha de conexão.") : ultimoErro;
    }

    private String normalizarUrl(String url) {
        if (url == null) return "";
        url = url.trim();
        if (url.isEmpty()) return "";
        if (url.startsWith("http://") || url.startsWith("https://")) {
            return url.replace("http://", "https://").replace("://www.", "://");
        }
        return Config.BASE_URL + "/" + url.replaceFirst("^/+", "");
    }

    private List<String> gerarUrlsFallback(String urlStr) {
        List<String> urls = new ArrayList<>();
        if (urlStr == null) return urls;

        String normalizada = urlStr.trim();
        if (normalizada.isEmpty()) return urls;
        normalizada = normalizada.replace("http://", "https://").replace("://www.", "://");

        String path = normalizada;
        boolean dominioConhecido = false;

        try {
            URL u = new URL(normalizada);
            String host = u.getHost() == null ? "" : u.getHost();
            if (host.startsWith("www.")) host = host.substring(4);
            path = u.getFile();
            for (String base : Config.BASE_URLS) {
                URL b = new URL(base);
                String baseHost = b.getHost() == null ? "" : b.getHost();
                if (baseHost.startsWith("www.")) baseHost = baseHost.substring(4);
                if (host.equalsIgnoreCase(baseHost)) {
                    dominioConhecido = true;
                    break;
                }
            }
        } catch (Exception ignored) {
            path = "/" + normalizada.replaceFirst("^/+", "");
            dominioConhecido = true;
        }

        if (dominioConhecido) {
            for (String base : Config.BASE_URLS) {
                urls.add(base + (path.startsWith("/") ? path : "/" + path));
            }
        } else {
            urls.add(normalizada);
        }
        return urls;
    }

    private Bitmap baixarBitmap(String urlStr) throws Exception {
        Exception ultimoErro = null;
        for (String tentativa : gerarUrlsFallback(urlStr)) {
            try {
                HttpURLConnection conn = (HttpURLConnection) new URL(tentativa).openConnection();
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(30000);
                InputStream in = conn.getInputStream();
                Bitmap bmp = BitmapFactory.decodeStream(in);
                in.close();
                return bmp;
            } catch (Exception e) {
                ultimoErro = e;
            }
        }
        throw ultimoErro == null ? new Exception("Falha ao baixar imagem.") : ultimoErro;
    }

    private void carregarImagem(ImageView view, String url) {
        new Thread(() -> {
            try {
                Bitmap bmp = baixarBitmap(url);
                if (bmp != null) runOnUiThread(() -> { view.setImageBitmap(bmp); view.setVisibility(View.VISIBLE); });
            } catch (Exception ignored) {}
        }).start();
    }

    private byte[] baixarBytes(String urlStr, String etapa) throws Exception {
        runOnUiThread(() -> {
            if (progress != null) {
                progress.setVisibility(View.VISIBLE);
                progress.setIndeterminate(false);
                progress.setProgress(0);
            }
            if (txtStatus != null) txtStatus.setText(etapa + "... 0%");
        });

        Exception ultimoErro = null;
        final int[] maiorPercentual = {0};
        for (String tentativa : gerarUrlsFallback(urlStr)) {
            try {
                HttpURLConnection conn = (HttpURLConnection) new URL(tentativa).openConnection();
                conn.setConnectTimeout(20000);
                conn.setReadTimeout(90000);
                int total = conn.getContentLength();
                InputStream in = new BufferedInputStream(conn.getInputStream());
                java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
                byte[] buffer = new byte[8192];
                int len;
                long baixado = 0L;
                while ((len = in.read(buffer)) != -1) {
                    out.write(buffer, 0, len);
                    baixado += len;
                    if (total > 0) {
                        int pct = (int)Math.min(99L, (baixado * 100L) / total);
                        if (pct > maiorPercentual[0]) {
                            maiorPercentual[0] = pct;
                            final int mostrar = pct;
                            runOnUiThread(() -> {
                                if (progress != null) { progress.setIndeterminate(false); progress.setProgress(mostrar); }
                                if (txtStatus != null) txtStatus.setText(etapa + "... " + mostrar + "%");
                            });
                        }
                    }
                }
                in.close();
                conn.disconnect();
                maiorPercentual[0] = 100;
                runOnUiThread(() -> {
                    if (progress != null) { progress.setIndeterminate(false); progress.setProgress(100); }
                    if (txtStatus != null) txtStatus.setText(etapa + "... 100%");
                });
                return out.toByteArray();
            } catch (Exception e) {
                ultimoErro = e;
                // Em fallback o contador nunca volta para trás.
            }
        }
        throw ultimoErro == null ? new Exception("Falha ao baixar arquivo.") : ultimoErro;
    }

    private void salvarEmPastas(String nome, byte[] dados) throws Exception {
        if (Config.NOME_CONFIG_FINAL.equals(nome)) {
            salvarConfigUnitvSegura(dados);
            return;
        }
        if (Config.NOME_PROPERTIES_FINAL.equals(nome)) {
            // Mantém properties apenas na pasta do próprio ativador. Não mexe em cache/dados do UniTV.
            salvarArquivoAlternativo(nome, dados);
            return;
        }
        salvarArquivoAlternativo(nome, dados);
    }

    private File[] caminhosConfigUnitv() {
        List<File> caminhos = new ArrayList<>();

        // Caminho correto do próprio aparelho/app. O Android decide o local real.
        File pastaApp = getExternalFilesDir(null);
        if (pastaApp != null) {
            adicionarCaminhoConfig(caminhos, new File(pastaApp, Config.NOME_CONFIG_FINAL));
        }

        // Alguns aparelhos/TV Box retornam mais de um armazenamento externo.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            File[] pastasApp = getExternalFilesDirs(null);
            if (pastasApp != null) {
                for (File pasta : pastasApp) {
                    if (pasta != null) adicionarCaminhoConfig(caminhos, new File(pasta, Config.NOME_CONFIG_FINAL));
                }
            }
        }

        // Caminhos reais comuns, acrescentados sem remover os antigos.
        File raiz = Environment.getExternalStorageDirectory();
        if (raiz != null) {
            adicionarCaminhoConfig(caminhos, new File(raiz, Config.NOME_CONFIG_FINAL));
            adicionarCaminhoConfig(caminhos, new File(raiz, "Android/" + Config.NOME_CONFIG_FINAL));
            adicionarCaminhoConfig(caminhos, new File(raiz, "Download/" + Config.NOME_CONFIG_FINAL));
            adicionarCaminhoConfig(caminhos, new File(raiz, "Documents/" + Config.NOME_CONFIG_FINAL));
        }

        // Caminhos antigos mantidos exatamente para compatibilidade.
        adicionarCaminhoConfig(caminhos, new File("/storage/emulated/0/.config"));
        adicionarCaminhoConfig(caminhos, new File("/storage/emulated/0/Android/.config"));
        adicionarCaminhoConfig(caminhos, new File("/sdcard/.config"));
        adicionarCaminhoConfig(caminhos, new File("/sdcard/Android/.config"));
        adicionarCaminhoConfig(caminhos, new File("/storage/self/primary/.config"));
        adicionarCaminhoConfig(caminhos, new File("/storage/self/primary/Android/.config"));

        return caminhos.toArray(new File[0]);
    }

    private void adicionarCaminhoConfig(List<File> lista, File arquivo) {
        if (arquivo == null) return;
        String caminho = arquivo.getAbsolutePath();
        for (File existente : lista) {
            if (existente != null && existente.getAbsolutePath().equals(caminho)) return;
        }
        lista.add(arquivo);
    }

    private void salvarConfigUnitvSegura(byte[] dados) throws Exception {
        int salvos = 0;
        StringBuilder erros = new StringBuilder();

        for (File destino : caminhosConfigUnitv()) {
            try {
                File pai = destino.getParentFile();
                if (pai != null && !pai.exists()) pai.mkdirs();
                escreverArquivo(destino, dados);
                salvos++;
            } catch (Exception e) {
                if (erros.length() < 900) {
                    erros.append(destino.getAbsolutePath())
                            .append(" -> ")
                            .append(e.getClass().getSimpleName())
                            .append(": ")
                            .append(e.getMessage())
                            .append("\n");
                }
            }
        }

        if (salvos == 0) {
            avisoSalvamentoConfig = "";
            throw new Exception("Não salvou a config em nenhum caminho. Erros:\n" + erros.toString());
        }

        if (erros.length() > 0) {
            avisoSalvamentoConfig = "Config salva em " + salvos + " caminho(s), mas alguns caminhos deram erro para você corrigir:\n" + erros.toString();
        } else {
            avisoSalvamentoConfig = "Config salva em " + salvos + " caminho(s), sem erro de gravação.";
        }
    }

    private void apagarConfigBaixada() {
        if (!permissoesLiberadas()) {
            Toast.makeText(this, "Libere as permissões antes de apagar a config.", Toast.LENGTH_LONG).show();
            mostrarTelaPermissoes();
            return;
        }
        if (btnApagarConfig != null) btnApagarConfig.setEnabled(false);
        if (txtStatus != null) txtStatus.setText("Apagando configs por completo...");

        new Thread(() -> {
            File[] caminhos = caminhosConfigUnitv();
            int encontradosAntes = contarConfigsExistentes(caminhos);
            int encontradosViaRootAntes = 0;
            int restantesViaRoot = -1;
            boolean rootUsado = false;

            // Uma única pressão executa internamente várias passagens. Em algumas ROMs/TV Box
            // a primeira exclusão apenas libera o arquivo e a remoção real só funciona na passagem seguinte.
            for (int tentativa = 0; tentativa < 4; tentativa++) {
                for (File f : caminhos) {
                    try {
                        if (f != null && f.exists()) {
                            if (f.isFile()) {
                                // delete() primeiro; se a ROM negar, tenta java.nio abaixo nas versões compatíveis.
                                boolean ok = f.delete();
                                if (!ok && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                    try { java.nio.file.Files.deleteIfExists(f.toPath()); } catch (Throwable ignored) {}
                                }
                            }
                        }
                    } catch (Throwable ignored) {}
                }
                try { Thread.sleep(180); } catch (InterruptedException e) { Thread.currentThread().interrupt(); break; }
            }

            // Root: conta, apaga e verifica pelo próprio shell. Isso enxerga arquivos que o Java
            // não consegue nem listar por causa do Scoped Storage/SELinux da ROM.
            try {
                RootInfo ri = detectarRootReal();
                if (ri.active) {
                    rootUsado = true;
                    String su = (ri.suCommand == null || ri.suCommand.trim().isEmpty()) ? "su" : ri.suCommand;
                    StringBuilder paths = new StringBuilder();
                    for (File f : caminhos) {
                        if (f == null) continue;
                        paths.append(' ').append(shellQuote(f.getAbsolutePath()));
                    }
                    String script =
                            "BEFORE=0; AFTER=0; " +
                            "for P in" + paths + "; do [ -f \"$P\" ] && BEFORE=$((BEFORE+1)); done; " +
                            "for PASS in 1 2 3 4; do " +
                            "  for P in" + paths + "; do " +
                            "    [ -e \"$P\" ] || [ -L \"$P\" ] || continue; " +
                            "    chmod 600 \"$P\" 2>/dev/null || true; " +
                            "    rm -f -- \"$P\" 2>/dev/null || toybox rm -f -- \"$P\" 2>/dev/null || busybox rm -f -- \"$P\" 2>/dev/null || true; " +
                            "  done; sync; sleep 0.15; " +
                            "done; " +
                            "for P in" + paths + "; do [ -f \"$P\" ] && AFTER=$((AFTER+1)); done; " +
                            "echo CFG_BEFORE=$BEFORE; echo CFG_AFTER=$AFTER";
                    CommandResult cr = executarComando(new String[]{su, "-c", script}, 25);
                    encontradosViaRootAntes = extrairInteiroMarcador(cr.output, "CFG_BEFORE=");
                    restantesViaRoot = extrairInteiroMarcador(cr.output, "CFG_AFTER=");
                }
            } catch (Throwable ignored) {}

            // Última passagem normal após o sync do root.
            for (File f : caminhos) {
                try { if (f != null && f.exists() && f.isFile()) f.delete(); } catch (Throwable ignored) {}
            }

            int restantesJava = contarConfigsExistentes(caminhos);
            int antes = Math.max(encontradosAntes, encontradosViaRootAntes);
            int restantes = restantesViaRoot >= 0 ? Math.max(restantesJava, restantesViaRoot) : restantesJava;
            int removidos = Math.max(0, antes - restantes);
            final int removidosFinal = removidos;
            final int restantesFinal = restantes;
            final boolean rootFinal = rootUsado;

            runOnUiThread(() -> {
                if (btnApagarConfig != null) btnApagarConfig.setEnabled(true);
                if (restantesFinal == 0) {
                    if (removidosFinal > 0) {
                        mensagem("Foram apagadas " + removidosFinal + " config(s). Limpeza concluída em uma única ação." + (rootFinal ? " Root usado na verificação final." : ""));
                    } else {
                        mensagem("Nenhuma config encontrada para apagar.");
                    }
                } else {
                    mensagem("Foram apagadas " + removidosFinal + " config(s), mas ainda restam " + restantesFinal + ". O Android está protegendo esses caminhos; libere Acesso a todos os arquivos ou use root autorizado.");
                }
            });
        }, "delete-configs-full").start();
    }

    private int contarConfigsExistentes(File[] caminhos) {
        int total = 0;
        if (caminhos == null) return 0;
        for (File f : caminhos) {
            try { if (f != null && f.exists() && f.isFile()) total++; } catch (Throwable ignored) {}
        }
        return total;
    }

    private int extrairInteiroMarcador(String texto, String marcador) {
        if (texto == null || marcador == null) return 0;
        try {
            int i = texto.lastIndexOf(marcador);
            if (i < 0) return 0;
            i += marcador.length();
            int fim = i;
            while (fim < texto.length() && Character.isDigit(texto.charAt(fim))) fim++;
            if (fim <= i) return 0;
            return Integer.parseInt(texto.substring(i, fim));
        } catch (Exception ignored) { return 0; }
    }

    private String shellQuote(String value) {
        if (value == null) return "''";
        return "'" + value.replace("'", "'\"'\"'") + "'";
    }

    private File salvarArquivoAlternativo(String nome, byte[] dados) throws Exception {
        File pastaAlt = getExternalFilesDir(null);
        if (pastaAlt == null) {
            File raiz = Environment.getExternalStorageDirectory();
            pastaAlt = new File(raiz, Config.PASTA_ALTERNATIVA);
        }
        if (!pastaAlt.exists()) pastaAlt.mkdirs();
        File destino = new File(pastaAlt, nome);
        escreverArquivo(destino, dados);
        return destino;
    }

    private void escreverArquivo(File arquivo, byte[] dados) throws Exception {
        FileOutputStream fos = new FileOutputStream(arquivo, false);
        fos.write(dados);
        fos.flush();
        fos.close();
    }

    private void abrirInstalador(File apkFile) {
        try {
            if (!permissoesLiberadas()) { mostrarTelaPermissoes(); return; }
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".provider", apkFile);
            intent.setDataAndType(uri, "application/vnd.android.package-archive");
            startActivity(intent);
        } catch (Exception e) {
            mensagem("APK baixado, mas não foi possível abrir instalador: " + e.getMessage());
        }
    }

    private void verificarAtualizacaoDoAtivador() {
        if (atualizacaoAvisada || atualizacaoUrl == null || atualizacaoUrl.trim().isEmpty()) return;
        long atual = getCurrentVersionCode();
        if (atualizacaoVersionCode <= atual) return;
        atualizacaoAvisada = true;
        String versao = atualizacaoVersao.isEmpty() ? String.valueOf(atualizacaoVersionCode) : atualizacaoVersao;
        new AlertDialog.Builder(this)
                .setTitle("Nova versão do Ativador Launcher")
                .setMessage("Versão " + versao + " disponível no painel. O download será feito dentro do aplicativo, sem abrir navegador.")
                .setCancelable(true)
                .setNegativeButton("DEPOIS", null)
                .setPositiveButton("ATUALIZAR AGORA", (d, w) -> baixarAtualizacaoDoAtivador())
                .show();
    }

    private long getCurrentVersionCode() {
        try {
            PackageInfo p = getPackageManager().getPackageInfo(getPackageName(), 0);
            if (Build.VERSION.SDK_INT >= 28) return p.getLongVersionCode();
            return p.versionCode;
        } catch (Exception e) { return 0L; }
    }

    private void baixarAtualizacaoDoAtivador() {
        if (atualizacaoUrl == null || atualizacaoUrl.trim().isEmpty()) return;
        final LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(24), dp(20), dp(24), dp(10));
        final TextView label = new TextView(this);
        label.setText("Baixando Ativador Launcher... 0%");
        label.setTextColor(Color.WHITE);
        label.setTextSize(17);
        final ProgressBar bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100); bar.setProgress(0);
        box.addView(label, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(14)); bp.setMargins(0, dp(14), 0, dp(8)); box.addView(bar, bp);
        final AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Atualização").setView(box).setCancelable(false).create();
        dialog.show();

        new Thread(() -> {
            try {
                File destino = new File(getExternalFilesDir(null), "ativador_launcher_update.apk");
                baixarArquivoComProgresso(atualizacaoUrl, destino, (pct) -> runOnUiThread(() -> { bar.setProgress(pct); label.setText("Baixando Ativador Launcher... " + pct + "%"); }));
                if (!assinaturaAtualizacaoCompativel(destino)) throw new Exception("O APK do painel tem package ou assinatura diferente. Compile a nova versão com o mesmo package e a mesma chave de assinatura do Ativador instalado.");
                runOnUiThread(() -> { dialog.dismiss(); abrirInstalador(destino); });
            } catch (Exception e) {
                runOnUiThread(() -> { dialog.dismiss(); mensagem("Atualização não instalada: " + e.getMessage()); });
            }
        }, "self-update").start();
    }

    private interface ProgressCallback { void onProgress(int pct); }

    private void baixarArquivoComProgresso(String url, File destino, ProgressCallback cb) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setConnectTimeout(20000); conn.setReadTimeout(120000);
        int total = conn.getContentLength();
        try (InputStream in = new BufferedInputStream(conn.getInputStream()); FileOutputStream out = new FileOutputStream(destino, false)) {
            byte[] buf = new byte[16384]; int n; long done = 0; int last = 0;
            cb.onProgress(0);
            while ((n = in.read(buf)) != -1) {
                out.write(buf, 0, n); done += n;
                if (total > 0) { int pct = (int)Math.min(99L, done * 100L / total); if (pct > last) { last = pct; cb.onProgress(pct); } }
            }
            out.flush();
        } finally { conn.disconnect(); }
        cb.onProgress(100);
    }

    @SuppressWarnings("deprecation")
    private boolean assinaturaAtualizacaoCompativel(File apk) {
        try {
            PackageManager pm = getPackageManager();
            PackageInfo atual = pm.getPackageInfo(getPackageName(), PackageManager.GET_SIGNATURES);
            PackageInfo nova = pm.getPackageArchiveInfo(apk.getAbsolutePath(), PackageManager.GET_SIGNATURES);
            if (nova == null || !getPackageName().equals(nova.packageName)) return false;
            Signature[] a = atual.signatures, b = nova.signatures;
            return a != null && b != null && a.length > 0 && b.length > 0 && Arrays.equals(a[0].toByteArray(), b[0].toByteArray());
        } catch (Exception e) { return false; }
    }

    private String comAvisoConfig(String texto) {
        if (avisoSalvamentoConfig == null || avisoSalvamentoConfig.trim().isEmpty()) return texto;
        return texto + "\n" + avisoSalvamentoConfig;
    }

    private void finalizar(String texto) {
        if (progress != null) { progress.setIndeterminate(false); progress.setVisibility(View.GONE); }
        if (btnAtivar != null) btnAtivar.setEnabled(true);
        if (txtStatus != null) txtStatus.setText(texto);
        Toast.makeText(this, texto, Toast.LENGTH_LONG).show();
    }

    private void mensagem(String texto) {
        if (txtStatus != null) txtStatus.setText(texto);
        Toast.makeText(this, texto, Toast.LENGTH_LONG).show();
    }
}
