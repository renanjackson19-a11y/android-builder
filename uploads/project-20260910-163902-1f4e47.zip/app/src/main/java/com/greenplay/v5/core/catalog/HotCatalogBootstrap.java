package com.greenplay.v5.core.catalog;

import android.content.Context;
import com.greenplay.v5.core.ui.SpecialSections;
import com.greenplay.v5.data.model.movie.Movie;
import com.greenplay.v5.data.model.movie.MovieCategory;
import com.greenplay.v5.data.model.series.SeriesCategory;
import com.greenplay.v5.data.model.series.SeriesItem;
import com.greenplay.v5.data.repository.MovieRepository;
import com.greenplay.v5.data.repository.SeriesRepository;
import com.greenplay.v5.ui.special.HotCatalogCacheStore;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * V5.0.159 — prepara o catálogo +18 uma única vez fora das telas.
 *
 * O HOT deixa de fazer discovery/download ao ser aberto. A descoberta acontece no
 * bootstrap da sessão, em background, e grava um snapshot isolado do catálogo normal.
 * Isso evita ANR, elimina recarga ao navegar e preserva a separação do +18.
 */
public final class HotCatalogBootstrap {
    private static final ExecutorService WORK = Executors.newSingleThreadExecutor();
    private static String runningKey = "";
    private static String completedKey = "";

    private HotCatalogBootstrap() {}

    public static void start(Context context, String host, String user, String pass) {
        if (context == null) return;
        final String h = host == null ? "" : host.trim();
        final String u = user == null ? "" : user.trim();
        final String p = pass == null ? "" : pass;
        if (h.isEmpty() || u.isEmpty() || p.isEmpty()) return;
        final String key = h.toLowerCase(Locale.ROOT) + "|" + u;

        synchronized (HotCatalogBootstrap.class) {
            if (key.equals(runningKey)) return;
            if (key.equals(completedKey) && SpecialCatalogIndex.hasContent(
                    SpecialCatalogIndex.cachedScope(SpecialSections.HOT))) return;
            runningKey = key;
        }
        WORK.execute(() -> new Job(context.getApplicationContext(), h, u, p, key).start());
    }

    public static boolean isRunning(String host, String user) {
        String key = (host == null ? "" : host.trim().toLowerCase(Locale.ROOT)) + "|" +
                (user == null ? "" : user.trim());
        synchronized (HotCatalogBootstrap.class) { return key.equals(runningKey); }
    }

    private static void finish(String key, boolean completed) {
        synchronized (HotCatalogBootstrap.class) {
            if (key.equals(runningKey)) runningKey = "";
            if (completed) completedKey = key;
        }
    }

    private static final class Job {
        final Context app;
        final String host, user, pass, key;
        final MovieRepository moviesRepo;
        final SeriesRepository seriesRepo;
        final HotCatalogCacheStore cache;
        List<MovieCategory> movieCats = Collections.emptyList();
        List<SeriesCategory> seriesCats = Collections.emptyList();
        final LinkedHashMap<Long, Movie> movies = new LinkedHashMap<>();
        final LinkedHashMap<Long, SeriesItem> series = new LinkedHashMap<>();
        boolean moviesDone;
        boolean seriesDone;

        Job(Context app, String host, String user, String pass, String key) {
            this.app = app; this.host = host; this.user = user; this.pass = pass; this.key = key;
            this.moviesRepo = new MovieRepository(host, user, pass, true);
            this.seriesRepo = new SeriesRepository(host, user, pass, true);
            this.cache = new HotCatalogCacheStore(app, host, user);
        }

        void start() {
            // Primeiro reutiliza o +18 persistido. A rede só é necessária quando não há snapshot.
            HotCatalogCacheStore.Snapshot saved = cache.read();
            if (saved != null && saved.usable()) {
                SpecialCatalogIndex.Scope built = SpecialCatalogIndex.buildScope(
                        SpecialSections.HOT, saved.movieCategories, saved.movies,
                        saved.seriesCategories, saved.series);
                if (SpecialCatalogIndex.hasContent(built)) {
                    SpecialCatalogIndex.publishScope(SpecialSections.HOT, built);
                    finish(key, true);
                    return;
                }
            }
            loadMovieCategories();
            loadSeriesCategories();
        }

        void loadMovieCategories() {
            moviesRepo.categories(new MovieRepository.CategoriesResult() {
                @Override public void success(List<MovieCategory> rows) { WORK.execute(() -> {
                    movieCats = rows == null ? Collections.emptyList() : new ArrayList<>(rows);
                    List<String> ids = movieAdultIds(movieCats);
                    if (ids.isEmpty()) loadMovieAdultFallback(); else loadMovieAt(ids, 0);
                }); }
                @Override public void error(String message) { WORK.execute(Job.this::loadMovieAdultFallback); }
            });
        }

        void loadSeriesCategories() {
            seriesRepo.categories(new SeriesRepository.CategoriesResult() {
                @Override public void success(List<SeriesCategory> rows) { WORK.execute(() -> {
                    seriesCats = rows == null ? Collections.emptyList() : new ArrayList<>(rows);
                    List<String> ids = seriesAdultIds(seriesCats);
                    if (ids.isEmpty()) loadSeriesAdultFallback(); else loadSeriesAt(ids, 0);
                }); }
                @Override public void error(String message) { WORK.execute(Job.this::loadSeriesAdultFallback); }
            });
        }

        void loadMovieAt(List<String> ids, int index) {
            if (index >= ids.size()) { moviesDone = true; maybeSave(); return; }
            final String categoryId = ids.get(index);
            moviesRepo.movies(categoryId, new MovieRepository.MoviesResult() {
                @Override public void success(List<Movie> rows) { WORK.execute(() -> {
                    if (rows != null) for (Movie m : rows) {
                        if (m == null || m.id <= 0) continue;
                        if (m.categoryId == null || m.categoryId.trim().isEmpty()) m.categoryId = categoryId;
                        m.allCategoryIds = appendId(m.allCategoryIds, categoryId);
                        m.isAdult = true; // vindo de pasta +18 estrutural do servidor
                        movies.put(m.id, m);
                    }
                    loadMovieAt(ids, index + 1);
                }); }
                @Override public void error(String message) { WORK.execute(() -> loadMovieAt(ids, index + 1)); }
            });
        }

        void loadSeriesAt(List<String> ids, int index) {
            if (index >= ids.size()) { seriesDone = true; maybeSave(); return; }
            final String categoryId = ids.get(index);
            seriesRepo.series(categoryId, new SeriesRepository.SeriesResult() {
                @Override public void success(List<SeriesItem> rows) { WORK.execute(() -> {
                    if (rows != null) for (SeriesItem s : rows) {
                        if (s == null || s.id <= 0) continue;
                        if (s.categoryId == null || s.categoryId.trim().isEmpty()) s.categoryId = categoryId;
                        s.allCategoryIds = appendId(s.allCategoryIds, categoryId);
                        s.isAdult = true;
                        series.put(s.id, s);
                    }
                    loadSeriesAt(ids, index + 1);
                }); }
                @Override public void error(String message) { WORK.execute(() -> loadSeriesAt(ids, index + 1)); }
            });
        }

        // Compatibilidade com painéis que escondem/renomeiam a pasta, mas marcam os itens.
        // Esse scan pesado acontece SOMENTE no bootstrap, nunca ao tocar em HOT.
        void loadMovieAdultFallback() {
            moviesRepo.adultMovies(new MovieRepository.MoviesResult() {
                @Override public void success(List<Movie> rows) { WORK.execute(() -> {
                    if (rows != null) for (Movie m : rows) if (m != null && m.id > 0) movies.put(m.id, m);
                    moviesDone = true; maybeSave();
                }); }
                @Override public void error(String message) { WORK.execute(() -> { moviesDone = true; maybeSave(); }); }
            });
        }

        void loadSeriesAdultFallback() {
            seriesRepo.adultSeries(new SeriesRepository.SeriesResult() {
                @Override public void success(List<SeriesItem> rows) { WORK.execute(() -> {
                    if (rows != null) for (SeriesItem s : rows) if (s != null && s.id > 0) series.put(s.id, s);
                    seriesDone = true; maybeSave();
                }); }
                @Override public void error(String message) { WORK.execute(() -> { seriesDone = true; maybeSave(); }); }
            });
        }

        void maybeSave() {
            if (!moviesDone || !seriesDone) return;
            List<Movie> movieRows = new ArrayList<>(movies.values());
            List<SeriesItem> seriesRows = new ArrayList<>(series.values());
            SpecialCatalogIndex.Scope built = SpecialCatalogIndex.buildScope(
                    SpecialSections.HOT, movieCats, movieRows, seriesCats, seriesRows);
            if (SpecialCatalogIndex.hasContent(built)) {
                // V5.0.162: o +18 carregado por category_id também alimenta o catálogo
                // normal da sessão. Assim FILMES/SÉRIES > categoria adulta não fica vazia
                // só porque o preload global terminou antes de chegar nesses itens.
                CatalogMemory.mergeMovieCategories(movieCats);
                CatalogMemory.mergeMovies(movieRows);
                CatalogMemory.mergeSeriesCategories(seriesCats);
                CatalogMemory.mergeSeries(seriesRows);
                cache.save(movieCats, movieRows, seriesCats, seriesRows);
                SpecialCatalogIndex.publishScope(SpecialSections.HOT, built);
                finish(key, true);
            } else {
                finish(key, false);
            }
        }
    }

    private static List<String> movieAdultIds(List<MovieCategory> cats) {
        ArrayList<String> out = new ArrayList<>(); HashSet<String> seen = new HashSet<>();
        if (cats != null) for (MovieCategory c : cats) {
            if (c == null || c.id == null || c.id.trim().isEmpty()) continue;
            if (!(c.isAdult || SpecialSections.isAdultCategoryName(c.name))) continue;
            String id = c.id.trim(); if (seen.add(id)) out.add(id);
        }
        return out;
    }

    private static List<String> seriesAdultIds(List<SeriesCategory> cats) {
        ArrayList<String> out = new ArrayList<>(); HashSet<String> seen = new HashSet<>();
        if (cats != null) for (SeriesCategory c : cats) {
            if (c == null || c.id == null || c.id.trim().isEmpty()) continue;
            if (!(c.isAdult || SpecialSections.isAdultCategoryName(c.name))) continue;
            String id = c.id.trim(); if (seen.add(id)) out.add(id);
        }
        return out;
    }

    private static String appendId(String source, String id) {
        String s = source == null ? "" : source.trim();
        String v = id == null ? "" : id.trim();
        if (v.isEmpty()) return s;
        if (s.isEmpty()) return v;
        for (String p : s.split("[,|;]")) if (v.equals(p.trim())) return s;
        return s + "," + v;
    }
}
