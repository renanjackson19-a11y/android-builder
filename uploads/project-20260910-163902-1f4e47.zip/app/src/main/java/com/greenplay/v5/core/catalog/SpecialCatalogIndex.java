package com.greenplay.v5.core.catalog;

import com.greenplay.v5.core.ui.SpecialSections;
import com.greenplay.v5.data.model.movie.Movie;
import com.greenplay.v5.data.model.movie.MovieCategory;
import com.greenplay.v5.data.model.series.SeriesCategory;
import com.greenplay.v5.data.model.series.SeriesItem;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * V5.0.90 — Central special-catalog index.
 *
 * Velox-style behavior: KIDS / ANIME / HOT are resolved once into explicit media
 * indexes. The UI no longer re-guesses the catalog on every screen switch.
 *
 * Xtream does not expose a universal media_type=KIDS/ANIME field, so this class
 * converts the data available at login into a stable local type index. Explicit
 * server categories always win. Mixed generic series categories are admitted
 * only when the series metadata itself is strong enough to classify the item.
 */
public final class SpecialCatalogIndex {
    public static final class CategoryRow {
        public final String id;
        public final String name;
        public CategoryRow(String id, String name) {
            this.id = id == null ? "" : id;
            this.name = name == null ? "" : name;
        }
    }

    public static final class Scope {
        public final String mode;
        public final Set<Long> movieIds;
        public final Set<Long> seriesIds;
        public final List<CategoryRow> movieCategories;
        public final List<CategoryRow> seriesCategories;
        public final List<Movie> moviePreview;
        public final List<SeriesItem> seriesPreview;

        private Scope(String mode, Set<Long> movieIds, Set<Long> seriesIds,
                      List<CategoryRow> movieCategories, List<CategoryRow> seriesCategories,
                      List<Movie> moviePreview, List<SeriesItem> seriesPreview) {
            this.mode = mode;
            this.movieIds = Collections.unmodifiableSet(new HashSet<>(movieIds));
            this.seriesIds = Collections.unmodifiableSet(new HashSet<>(seriesIds));
            this.movieCategories = Collections.unmodifiableList(new ArrayList<>(movieCategories));
            this.seriesCategories = Collections.unmodifiableList(new ArrayList<>(seriesCategories));
            this.moviePreview = Collections.unmodifiableList(new ArrayList<>(moviePreview));
            this.seriesPreview = Collections.unmodifiableList(new ArrayList<>(seriesPreview));
        }
    }

    /**
     * V5.0.114 — o mapa inteiro é trocado de forma atômica depois que o índice
     * termina de ser montado. A UI nunca espera o monitor de um rebuild pesado.
     *
     * Antes, rebuild()/cachedScope() eram synchronized no MESMO monitor. Se o
     * catálogo tinha milhares de itens e o rebuild estava rodando em background,
     * tocar em KIDS/ANIMES podia bloquear a main thread por vários segundos e o
     * Android mostrava "GREEN PLAY não está respondendo".
     */
    private static volatile long builtFrom = Long.MIN_VALUE;
    private static volatile Map<String, Scope> SCOPES = Collections.emptyMap();

    /**
     * V5.0.140 — telas KIDS/ANIMES podem abrir antes do preload pesado terminar.
     * O índice continua sendo montado em background, mas agora publica um evento
     * leve quando o snapshot fica pronto. Isso evita a tela vazia que a V139
     * mostrava quando o usuário tocava em KIDS/ANIMES logo após a abertura rápida.
     */
    public interface ScopeListener {
        void onScopePublished(String mode);
    }

    private static final CopyOnWriteArrayList<ScopeListener> LISTENERS = new CopyOnWriteArrayList<>();

    public static void addScopeListener(ScopeListener listener) {
        if (listener != null) LISTENERS.addIfAbsent(listener);
    }

    public static void removeScopeListener(ScopeListener listener) {
        if (listener != null) LISTENERS.remove(listener);
    }

    private static void notifyScopePublished(String mode) {
        for (ScopeListener listener : LISTENERS) {
            try { listener.onScopePublished(mode); } catch (Exception ignored) { }
        }
    }

    private SpecialCatalogIndex() {}

    public static void clear() {
        SCOPES = Collections.emptyMap();
        builtFrom = Long.MIN_VALUE;
    }

    public static void rebuild() {
        // Copia os snapshots primeiro. Todo o processamento pesado acontece sem
        // segurar nenhum lock do SpecialCatalogIndex.
        final long source = CatalogMemory.updatedAt();
        final List<MovieCategory> movieCategories = CatalogMemory.movieCategories();
        final List<Movie> movies = CatalogMemory.movies();
        final List<SeriesCategory> seriesCategories = CatalogMemory.seriesCategories();
        final List<SeriesItem> series = CatalogMemory.series();

        final Map<String, Scope> fresh = new HashMap<>();
        fresh.put(SpecialSections.KIDS,
                buildScope(SpecialSections.KIDS, movieCategories, movies, seriesCategories, series));
        fresh.put(SpecialSections.ANIME,
                buildScope(SpecialSections.ANIME, movieCategories, movies, seriesCategories, series));
        fresh.put(SpecialSections.HOT,
                buildScope(SpecialSections.HOT, movieCategories, movies, seriesCategories, series));

        // Publicação atômica: cachedScope() continua instantâneo mesmo enquanto
        // outro rebuild está sendo calculado. Um refresh transitório nunca apaga um
        // escopo válido e troca por TODOS/vazio.
        Map<String, Scope> current = SCOPES;
        Map<String, Scope> published = new HashMap<>();
        for (String mode : new String[]{SpecialSections.KIDS, SpecialSections.ANIME, SpecialSections.HOT}) {
            Scope candidate = fresh.get(mode);
            Scope previous = current.get(mode);
            // V5.0.160: o catálogo geral preserva as pastas +18 autorizadas. Ainda assim,
            // um HOT adulto já publicado não deve ser substituído por um rebuild parcial
            // enquanto o bootstrap termina.
            if (SpecialSections.HOT.equals(mode) && hasContent(previous)) published.put(mode, previous);
            else published.put(mode, preferValid(candidate, previous));
        }
        SCOPES = Collections.unmodifiableMap(published);
        builtFrom = source;

        // Não bloqueia nenhuma tela: apenas sinaliza que já existe um novo snapshot.
        notifyScopePublished(SpecialSections.KIDS);
        notifyScopePublished(SpecialSections.ANIME);
        notifyScopePublished(SpecialSections.HOT);
    }

    /**
     * Publica somente um escopo já calculado em background. Usado pela correção
     * leve de categorias sem reconstruir KIDS+ANIMES+HOT completos.
     */
    public static void publishScope(String mode, Scope scope) {
        if (mode == null || scope == null) return;
        Map<String, Scope> current = SCOPES;
        Map<String, Scope> next = new HashMap<>(current);
        next.put(mode, preferValid(scope, current.get(mode)));
        SCOPES = Collections.unmodifiableMap(next);
        notifyScopePublished(mode);
    }

    /**
     * Acesso lock-free ao último índice pronto. Nunca monta nem espera catálogo.
     */
    /** V5.0.145: cria um snapshot vazio sem tocar no catálogo bruto. */
    public static Scope emptyScopeForMode(String mode) {
        return emptyScope(mode);
    }

    public static Scope cachedScope(String mode) {
        Scope s = SCOPES.get(mode);
        if (s != null) return s;
        return emptyScope(mode);
    }

    /**
     * Mantido por compatibilidade. Chamadores de UI recebem somente o último
     * snapshot pronto; rebuilds devem ser disparados por executores de background.
     */
    public static Scope scope(String mode) {
        return cachedScope(mode);
    }

    public static boolean hasContent(Scope scope) {
        return scope != null && (!scope.movieIds.isEmpty() || !scope.seriesIds.isEmpty());
    }

    /**
     * V5.0.141 — reconstrói um snapshot já classificado sem revarrer o catálogo inteiro.
     * Usado para abrir KIDS/ANIMES imediatamente depois de um cold start rápido.
     */
    public static Scope fromSnapshot(String mode,
                                     Set<Long> movieIds,
                                     Set<Long> seriesIds,
                                     List<CategoryRow> movieCategories,
                                     List<CategoryRow> seriesCategories,
                                     List<Movie> moviePreview,
                                     List<SeriesItem> seriesPreview) {
        return new Scope(mode,
                movieIds == null ? Collections.emptySet() : movieIds,
                seriesIds == null ? Collections.emptySet() : seriesIds,
                movieCategories == null ? Collections.singletonList(new CategoryRow("", "TODOS")) : movieCategories,
                seriesCategories == null ? Collections.singletonList(new CategoryRow("", "TODOS")) : seriesCategories,
                moviePreview == null ? Collections.emptyList() : moviePreview,
                seriesPreview == null ? Collections.emptyList() : seriesPreview);
    }

    private static Scope preferValid(Scope candidate, Scope previous) {
        if (hasContent(candidate)) return candidate;
        if (hasContent(previous)) return previous;
        return candidate == null ? emptyScope(previous == null ? "" : previous.mode) : candidate;
    }

    private static Scope emptyScope(String mode) {
        return new Scope(mode, Collections.emptySet(), Collections.emptySet(),
                Collections.singletonList(new CategoryRow("", "TODOS")),
                Collections.singletonList(new CategoryRow("", "TODOS")),
                Collections.emptyList(), Collections.emptyList());
    }

    /** Public builder is also used by HOT after its adult-inclusive catalog is fetched. */
    public static Scope buildScope(String mode,
                                   List<MovieCategory> movieCategories,
                                   List<Movie> movies,
                                   List<SeriesCategory> seriesCategories,
                                   List<SeriesItem> series) {
        LinkedHashMap<String,String> movieNames = new LinkedHashMap<>();
        LinkedHashMap<String,String> seriesNames = new LinkedHashMap<>();
        Set<String> explicitMovieCats = new HashSet<>();
        Set<String> explicitSeriesCats = new HashSet<>();

        // V5.0.135 — KIDS não trata mais Família/Disney/Animação como equivalentes
        // a uma pasta infantil explícita. A amostra real de vários Xtreams mostrou
        // que esses buckets são mistos. Mantemos três níveis para preservar catálogo
        // sem permitir que uma categoria ampla seja autoridade sobre o item.
        Set<String> directKidsMovieCats = new HashSet<>();
        Set<String> animationKidsMovieCats = new HashSet<>();
        Set<String> mixedKidsMovieCats = new HashSet<>();
        Set<String> directKidsSeriesCats = new HashSet<>();
        Set<String> animationKidsSeriesCats = new HashSet<>();
        Set<String> mixedKidsSeriesCats = new HashSet<>();

        if (movieCategories != null) {
            for (MovieCategory c : movieCategories) {
                if (c == null || blank(c.id)) continue;
                movieNames.put(c.id, safe(c.name));
                if (SpecialSections.matches(mode, c.name) || (SpecialSections.HOT.equals(mode) && (c.isAdult || SpecialSections.isAdultCategoryName(c.name)))) {
                    explicitMovieCats.add(c.id);
                    if (SpecialSections.KIDS.equals(mode)) {
                        if (directKidsMovieCategoryName(c.name)) directKidsMovieCats.add(c.id);
                        else if (animationKidsMovieCategoryName(c.name)) animationKidsMovieCats.add(c.id);
                        else mixedKidsMovieCats.add(c.id);
                    }
                }
            }
        }
        if (seriesCategories != null) {
            for (SeriesCategory c : seriesCategories) {
                if (c == null || blank(c.id)) continue;
                seriesNames.put(c.id, safe(c.name));
                if (SpecialSections.matches(mode, c.name) || (SpecialSections.HOT.equals(mode) && (c.isAdult || SpecialSections.isAdultCategoryName(c.name)))) {
                    explicitSeriesCats.add(c.id);
                    if (SpecialSections.KIDS.equals(mode)) {
                        if (directKidsSeriesCategoryName(c.name)) directKidsSeriesCats.add(c.id);
                        else if (safeKidsSeriesCategoryName(c.name)) animationKidsSeriesCats.add(c.id);
                        else mixedKidsSeriesCats.add(c.id);
                    }
                }
            }
        }

        Set<Long> movieIds = new HashSet<>();
        Set<Long> seriesIds = new HashSet<>();
        Set<String> visibleMovieCats = new HashSet<>();
        Set<String> visibleSeriesCats = new HashSet<>();
        ArrayList<Movie> moviePreview = new ArrayList<>();
        ArrayList<SeriesItem> seriesPreview = new ArrayList<>();

        if (movies != null) {
            for (Movie m : movies) {
                if (m == null || m.id <= 0) continue;
                String cat = combinedCategoryIds(m.categoryId, m.allCategoryIds);
                String tag = specialTag(m.mediaType, m.vodType, m.filterType);
                boolean match;
                if (!tag.isEmpty()) {
                    // Quando o backend fornece um tipo estrutural explícito, ele é autoridade.
                    match = mode.equals(tag);
                } else if (SpecialSections.KIDS.equals(mode)) {
                    boolean direct = matchesAnyCategory(cat, directKidsMovieCats);
                    boolean animationBroad = matchesAnyCategory(cat, animationKidsMovieCats);
                    boolean mixedBroad = matchesAnyCategory(cat, mixedKidsMovieCats);
                    if (direct) {
                        // Pasta realmente infantil: só bloqueios de alta confiança.
                        match = !hardRejectKidsMovieCore(m);
                    } else if (animationBroad) {
                        // Animação é candidata, não sinônimo de infantil. Se o servidor
                        // fornece gênero/sinopse/classificação, exigimos evidência positiva.
                        // Em painéis muito pobres em metadados, preservamos a pasta para
                        // não zerar KIDS, mas ainda aplicamos rejeições genéricas.
                        match = (movieMetadataSparse(m) || positiveKidsMovie(m)) && !hardRejectKidsMovie(m);
                    } else if (mixedBroad) {
                        // Família/Disney genérico nunca entra inteiro. Precisa do item.
                        match = positiveKidsMovie(m) && !hardRejectKidsMovie(m);
                    } else {
                        match = strictKidsMovie(m);
                    }
                } else if (SpecialSections.ANIME.equals(mode)) {
                    // Algumas origens escondem filmes de anime em Animação/KIDS em vez
                    // de criar uma categoria VOD "Anime". Aproveita metadados genéricos
                    // quando existirem, sem depender de nomes de títulos/franquias.
                    match = matchesAnyCategory(cat, explicitMovieCats) || strictAnime(m);
                } else {
                    // HOT é dirigido por categoria/flag estrutural. Nunca por título.
                    match = matchesAnyCategory(cat, explicitMovieCats)
                            || m.isAdult || strongAdultMetadata(m.mediaType, m.vodType, m.filterType);
                }
                if (!match) continue;
                movieIds.add(m.id);
                if (moviePreview.size() < 12) moviePreview.add(m);
                addVisibleCategoryIds(visibleMovieCats, cat, explicitMovieCats);
            }
        }

        if (series != null) {
            for (SeriesItem item : series) {
                if (item == null || item.id <= 0) continue;
                String cat = combinedCategoryIds(item.categoryId, item.allCategoryIds);
                String tag = specialTag(item.mediaType, item.vodType, item.filterType);
                boolean match;
                if (!tag.isEmpty()) {
                    match = mode.equals(tag);
                } else {
                    boolean explicit = matchesAnyCategory(cat, explicitSeriesCats);
                    if (SpecialSections.KIDS.equals(mode)) {
                        boolean direct = matchesAnyCategory(cat, directKidsSeriesCats);
                        boolean animationBroad = matchesAnyCategory(cat, animationKidsSeriesCats);
                        boolean mixedBroad = matchesAnyCategory(cat, mixedKidsSeriesCats);
                        if (direct) {
                            match = !hardRejectKidsSeriesCore(item);
                        } else if (animationBroad) {
                            // A amostra real encontrou conteúdo adulto/geral em categorias
                            // chamadas apenas "Animação". Com metadados, exige sinal KIDS;
                            // sem metadados, mantém o fallback antigo para não zerar a seção.
                            match = (seriesMetadataSparse(item) || positiveKidsSeries(item))
                                    && !hardRejectKidsSeries(item);
                        } else if (mixedBroad) {
                            // Disney+/Família é bucket misto nos servidores analisados.
                            match = positiveKidsSeries(item) && !hardRejectKidsSeries(item);
                        } else {
                            match = strictKids(item);
                        }
                    } else if (SpecialSections.ANIME.equals(mode)) {
                        match = explicit || strictAnime(item);
                    } else {
                        match = explicit || item.isAdult
                                || strongAdultMetadata(item.mediaType, item.vodType, item.filterType);
                    }
                }
                if (!match) continue;
                seriesIds.add(item.id);
                if (seriesPreview.size() < 12) seriesPreview.add(item);
                addVisibleCategoryIds(visibleSeriesCats, cat, explicitSeriesCats);
            }
        }

        // Uma categoria explícita pode estar vazia momentaneamente; mantém a navegação.
        visibleMovieCats.addAll(explicitMovieCats);
        visibleSeriesCats.addAll(explicitSeriesCats);

        List<CategoryRow> movieRows = rows(movieNames, visibleMovieCats);
        List<CategoryRow> seriesRows = rows(seriesNames, visibleSeriesCats);
        return new Scope(mode, movieIds, seriesIds, movieRows, seriesRows, moviePreview, seriesPreview);
    }

    private static String specialTag(String mediaType, String vodType, String filterType) {
        String n = " " + normalize(safe(mediaType) + " " + safe(vodType) + " " + safe(filterType)) + " ";
        if (SpecialSections.isKidsCategoryName(n)) return SpecialSections.KIDS;
        if (SpecialSections.isAnimeCategoryName(n)) return SpecialSections.ANIME;
        if (SpecialSections.isHotCategoryName(safe(mediaType) + " " + safe(vodType) + " " + safe(filterType))) return SpecialSections.HOT;
        return "";
    }


    /**
     * Fallback somente para METADADOS estruturais do backend (media_type/vod_type/filter_type).
     * Não olha título, sinopse ou gênero, para um filme comum com palavra sexual no nome
     * nunca entrar no HOT por engano.
     */
    private static boolean strongAdultMetadata(String... values) {
        StringBuilder raw = new StringBuilder();
        if (values != null) for (String v : values) raw.append(' ').append(safe(v));
        String original = raw.toString().toLowerCase(Locale.ROOT);
        if (original.contains("🔞") || original.contains("+18") || original.contains("18+")) return true;
        return SpecialSections.isHotCategoryName(original);
    }

    private static boolean matchesAnyCategory(String raw, Set<String> allowed) {
        if (allowed == null || allowed.isEmpty() || blank(raw)) return false;
        for (String id : categoryIds(raw)) if (allowed.contains(id)) return true;
        return false;
    }

    private static String combinedCategoryIds(String primary, String all) {
        String a = safe(primary);
        String b = safe(all);
        if (a.isEmpty()) return b;
        if (b.isEmpty()) return a;
        return a + "|" + b;
    }

    private static void addVisibleCategoryIds(Set<String> out, String raw, Set<String> allowed) {
        if (out == null || allowed == null || allowed.isEmpty()) return;
        for (String id : categoryIds(raw)) if (allowed.contains(id)) out.add(id);
    }

    /** Alguns painéis retornam mais de um category_id no mesmo campo. */
    private static List<String> categoryIds(String raw) {
        ArrayList<String> out = new ArrayList<>();
        if (raw == null) return out;
        String cleaned = raw.trim();
        if (cleaned.isEmpty()) return out;
        String[] parts = cleaned.split("[|,;]+");
        for (String part : parts) {
            String id = part == null ? "" : part.trim();
            if (!id.isEmpty() && !out.contains(id)) out.add(id);
        }
        if (out.isEmpty()) out.add(cleaned);
        return out;
    }

    private static List<CategoryRow> rows(LinkedHashMap<String,String> names, Set<String> allowed) {
        ArrayList<CategoryRow> out = new ArrayList<>();
        out.add(new CategoryRow("", "TODOS"));
        for (Map.Entry<String,String> e : names.entrySet()) {
            if (!allowed.contains(e.getKey())) continue;
            out.add(new CategoryRow(e.getKey(), cleanDisplay(e.getValue())));
        }
        return out;
    }

    /**
     * Strict KIDS rule for mixed provider categories.
     * Family alone is intentionally NOT enough: that was the source of normal series leaking into KIDS.
     */
    private static boolean strictKids(SeriesItem item) {
        if (item.isAdult) return false;
        String genre = " " + normalize(item.genre) + " ";
        String title = " " + normalize(item.name) + " ";
        if (genre.trim().isEmpty()) return false;

        boolean directKids = hasAny(genre,
                " kids ", " kid ", " children ", " childrens ", " child ",
                " infantil ", " infantis ", " infanto juvenil ", " infantojuvenil ",
                " preschool ", " pre school ", " educativo ", " educational ");
        boolean animation = hasAny(genre,
                " animation ", " animations ", " animacao ", " animacoes ", " animated ", " animado ", " animados ", " cartoon ", " cartoons ");
        boolean family = hasAny(genre, " family ", " familia ", " familiar ");

        // V5.0.129: muitos Xtreams publicam KIDS somente como ANIMAÇÃO ou FAMÍLIA.
        // Esses metadados são aceitos desde que não sejam anime/adulto/maduro.
        if (!directKids && !animation && !family) return false;

        // Anime belongs in ANIMES, not KIDS, unless the server explicitly classified the category as KIDS.
        if (hasAny(genre, " anime ", " manga ", " shonen ", " shoujo ", " seinen ", " isekai ")) return false;

        String mature = genre + title;
        return !hasAny(mature,
                " adult ", " adulto ", " adultos ", " erotic ", " erotico ", " porn ",
                " horror ", " terror ", " thriller ", " crime ", " slasher ", " gore ",
                " family guy ", " south park ", " rick and morty ", " american dad ",
                " bojack horseman ", " big mouth ", " paradise pd ", " brickleberry ",
                " archer ", " solar opposites ");
    }


    /** Categoria de filme inequivocamente infantil. */
    private static boolean directKidsMovieCategoryName(String raw) {
        String n = kidsCategoryNorm(raw);
        if (n.trim().isEmpty() || adultOrAnimeCategory(n)) return false;
        return hasAny(n,
                " kids ", " kid ", " infantil ", " infantis ", " crianca ", " criancas ",
                " infanto juvenil ", " infantojuvenil ", " desenho ", " desenhos ",
                " cartoon ", " cartoons ", " baby ", " bebe ", " children ", " childrens ",
                " child ", " preschool ", " pre school ", " discovery kids ",
                " disney junior ", " nickelodeon ", " nick jr ", " nick junior ",
                " gloobinho ", " cartoonito ", " pbs kids ", " family kids ",
                " animacao infantil ", " animation kids ", " animacao kids ");
    }

    /**
     * Animação/juvenil é uma pista, não uma autorização KIDS. Esses buckets podem
     * misturar anime ou animação adulta e por isso são avaliados no item.
     */
    private static boolean animationKidsMovieCategoryName(String raw) {
        String n = kidsCategoryNorm(raw);
        if (n.trim().isEmpty() || adultOrAnimeCategory(n) || directKidsMovieCategoryName(raw)) return false;
        return hasAny(n,
                " animacao ", " animacoes ", " animation ", " animations ", " animated ",
                " animado ", " animados ", " juvenil ", " pixar ", " dreamworks ",
                " illumination ");
    }

    private static boolean movieMetadataSparse(Movie item) {
        if (item == null) return true;
        return blank(item.genre) && blank(item.plot) && blank(item.contentRating)
                && blank(item.originalLanguage) && blank(item.country)
                && blank(item.mediaType) && blank(item.vodType) && blank(item.filterType);
    }

    private static boolean seriesMetadataSparse(SeriesItem item) {
        if (item == null) return true;
        return blank(item.genre) && blank(item.plot) && blank(item.contentRating)
                && blank(item.mediaType) && blank(item.vodType) && blank(item.filterType);
    }

    /** Sinal positivo KIDS vindo do próprio item VOD. */
    private static boolean positiveKidsMovie(Movie item) {
        if (item == null || item.isAdult) return false;
        if (kidsRatingVerdict(item.contentRating) > 0) return true;

        String genre = " " + normalize(item.genre) + " ";
        String plot = " " + normalize(item.plot) + " ";
        String structural = " " + normalize(safe(item.mediaType) + " " + safe(item.vodType) + " " + safe(item.filterType)) + " ";
        String all = genre + " " + plot + " " + structural;

        if (hasAny(all,
                " kids ", " kid ", " children ", " child ", " infantil ", " infantis ",
                " crianca ", " criancas ", " infanto juvenil ", " infantojuvenil ",
                " preschool ", " pre school ", " educativo ", " educational ",
                " desenho ", " desenhos ", " cartoon ", " cartoons ")) return true;

        // Família sozinha ainda é ampla demais. Na amostra real, pastas Family/Disney
        // continham documentários e dramas gerais. Exigimos Família + gênero leve.
        boolean family = hasAny(genre, " family ", " familia ", " familiar ");
        boolean lightGenre = hasAny(genre,
                " animation ", " animations ", " animacao ", " animacoes ", " animated ",
                " adventure ", " aventura ", " comedy ", " comedia ", " musical ",
                " music ", " musica ", " fantasy ", " fantasia ", " cartoon ", " desenhos ");
        if (family && lightGenre) return true;

        // Live-action/educativo com contexto claramente infantil/juvenil.
        return hasAny(plot,
                " para criancas ", " publico infantil ", " escola infantil ", " pre escolar ",
                " preschool ", " criancas ", " infancia ", " aventura infantil ",
                " educativo infantil ", " educacional infantil ", " young audience ",
                " youth audience ", " escola ", " escolar ", " estudante ", " estudantes ");
    }

    /** Bloqueios de alta confiança, inclusive dentro de uma pasta explicitamente KIDS. */
    private static boolean hardRejectKidsMovieCore(Movie item) {
        if (item == null || item.isAdult) return true;
        if (kidsRatingVerdict(item.contentRating) < 0) return true;
        String all = " " + normalize(safe(item.genre) + " " + safe(item.plot)
                + " " + safe(item.mediaType) + " " + safe(item.vodType) + " " + safe(item.filterType)) + " ";
        return hasAny(all,
                " adult ", " adults ", " adulto ", " adultos ", " erotic ", " erotico ",
                " erotica ", " porn ", " porno ", " pornografia ", " sexual ", " sexo ",
                " xxx ", " hentai ", " explicit sex ", " adults only ");
    }

    /** Rejeição adicional para buckets mistos (Família/Disney/Animação). */
    private static boolean hardRejectKidsMovie(Movie item) {
        if (hardRejectKidsMovieCore(item)) return true;
        String genre = " " + normalize(item.genre) + " ";
        String plot = " " + normalize(item.plot) + " ";
        String all = genre + " " + plot;

        // Documentário em Disney/Família não é automaticamente infantil.
        // Só passa quando o próprio item traz evidência infantil/juvenil estruturada.
        boolean documentary = hasAny(genre,
                " documentary ", " documentario ", " documentarios ", " documental ", " docuseries ");
        if (documentary && !strongChildEvidence(item)) return true;

        return hasAny(all,
                " horror ", " terror ", " slasher ", " gore ", " thriller ",
                " suspense ", " mystery ", " misterio ", " crime ", " criminal ", " police ", " policial ", " detective ", " detetive ",
                " murder ", " assassin ", " assassino ", " homicidio ", " serial killer ",
                " kidnapping ", " kidnapped ", " sequestro ", " sequestr ", " abduction ",
                " war ", " guerra ", " narcotic ", " droga ", " drogas ", " cartel ",
                " true crime ");
    }

    private static boolean strictKidsMovie(Movie item) {
        return positiveKidsMovie(item) && !hardRejectKidsMovie(item);
    }

    /**
     * Generic ANIME fallback for VOD. No title/franchise blacklist/whitelist is used.
     * If a provider exposes Japanese origin/language plus Animation, that is enough;
     * otherwise only explicit anime-style metadata is accepted.
     */
    private static boolean strictAnime(Movie item) {
        if (item == null || item.isAdult) return false;
        String genre = " " + normalize(item.genre) + " ";
        String plot = " " + normalize(item.plot) + " ";
        String structural = " " + normalize(safe(item.mediaType) + " " + safe(item.vodType) + " " + safe(item.filterType)) + " ";
        String all = genre + " " + plot + " " + structural;
        if (hasAny(all,
                " anime ", " manga ", " otaku ", " shonen ", " shoujo ", " shojo ",
                " seinen ", " isekai ", " japanese animation ", " animacao japonesa ")) return true;

        boolean animation = hasAny(genre,
                " animation ", " animations ", " animacao ", " animacoes ", " animated ");
        if (!animation) return false;
        String origin = " " + normalize(safe(item.originalLanguage) + " " + safe(item.country)) + " ";
        return hasAny(origin, " ja ", " jpn ", " japanese ", " japan ", " japao ");
    }

    /** Core-only rejection for a server category explicitly dedicated to children. */
    private static boolean hardRejectKidsSeriesCore(SeriesItem item) {
        if (item == null || item.isAdult) return true;
        if (kidsRatingVerdict(item.contentRating) < 0) return true;
        String all = " " + normalize(safe(item.genre) + " " + safe(item.plot)
                + " " + safe(item.mediaType) + " " + safe(item.vodType) + " " + safe(item.filterType)) + " ";
        return hasAny(all,
                " adult ", " adults ", " adulto ", " adultos ", " erotic ", " erotico ",
                " erotica ", " porn ", " porno ", " pornografia ", " sexual ", " sexo ",
                " xxx ", " hentai ", " adults only ");
    }

    /** Categoria de série inequivocamente infantil. */
    private static boolean directKidsSeriesCategoryName(String raw) {
        String n = kidsCategoryNorm(raw);
        if (n.trim().isEmpty() || adultOrAnimeCategory(n)) return false;
        return hasAny(n,
                " kids ", " kid ", " infantil ", " infantis ", " crianca ", " criancas ",
                " infanto juvenil ", " infantojuvenil ", " desenho ", " desenhos ",
                " cartoon ", " cartoons ", " baby ", " bebe ", " children ", " childrens ",
                " child ", " preschool ", " pre school ", " educativo ", " educativos ",
                " educacao ", " educational ", " discovery kids ", " cartoon network ",
                " disney junior ", " disney channel ", " nickelodeon ", " nick jr ",
                " nick junior ", " gloob ", " gloobinho ", " boomerang ", " tooncast ",
                " cartoonito ", " pbs kids ", " family kids ", " animacao infantil ",
                " animation kids ");
    }

    /**
     * Categoria ainda apropriada para KIDS, mas que pode conter exceções maduras.
     * Por isso passa pelo hardRejectKidsSeries().
     */
    private static boolean safeKidsSeriesCategoryName(String raw) {
        String n = kidsCategoryNorm(raw);
        if (n.trim().isEmpty() || adultOrAnimeCategory(n) || directKidsSeriesCategoryName(raw)) return false;
        return hasAny(n,
                " juvenil ", " animacao ", " animacoes ", " animation ", " animations ",
                " animated ", " animado ", " animados ", " pixar ", " dreamworks ",
                " illumination ");
    }

    /** Buckets mistos (Família/Disney genérico) exigem sinal positivo no item. */
    private static boolean positiveKidsSeries(SeriesItem item) {
        if (item == null || item.isAdult) return false;
        String genre = " " + normalize(item.genre) + " ";
        String title = " " + normalize(item.name) + " ";
        String plot = " " + normalize(item.plot) + " ";
        String structural = " " + normalize(safe(item.mediaType) + " " + safe(item.vodType) + " " + safe(item.filterType)) + " ";
        String all = genre + " " + title + " " + plot + " " + structural;

        // NovaEra/GoCine-style signal: when the provider exposes an age/content
        // classification, use it as structured evidence instead of guessing only
        // from the title. A child-safe rating is a positive KIDS signal.
        if (kidsRatingVerdict(item.contentRating) > 0) return true;

        if (hasAny(all,
                " kids ", " kid ", " children ", " child ", " infantil ", " infantis ",
                " crianca ", " criancas ", " infanto juvenil ", " infantojuvenil ",
                " preschool ", " pre school ", " educativo ", " educational ",
                " desenho ", " desenhos ", " cartoon ", " cartoons ")) return true;

        // V5.0.133 — bucket misto (ex.: Família/Disney+) não pode aceitar uma
        // série só porque o título/plot contém "garota", "garoto" ou "jovem".
        // Isso vazava dramas policiais/desaparecimentos para KIDS. Para live-action,
        // exigimos contexto juvenil concreto OU combinação Família + gênero leve.
        boolean youthContext = hasAny(all,
                " escola ", " escolar ", " colegio ", " estudante ", " estudantes ",
                " aluno ", " alunos ", " aluna ", " alunas ", " sala de aula ",
                " ensino medio ", " ensino fundamental ", " academia esportiva ",
                " academico esportivo ", " equipe juvenil ", " time juvenil ",
                " teen comedy ", " teen musical ", " teenager comedy ",
                " aventura juvenil ", " musical juvenil ", " serie juvenil ",
                " programa infantil ", " publico infantil ", " para criancas ");
        boolean family = hasAny(genre, " family ", " familia ", " familiar ");
        boolean lightGenre = hasAny(genre,
                " animation ", " animations ", " animacao ", " animacoes ", " animated ",
                " adventure ", " aventura ", " comedy ", " comedia ", " musical ",
                " music ", " musica ", " fantasy ", " fantasia ");
        // Importante: FAMÍLIA sozinho NÃO é sinal suficiente. Antes "family"
        // também estava dentro de lightGenre, tornando (family && lightGenre)
        // verdadeiro com um único rótulo e deixando dramas adultos vazarem.
        return youthContext || (family && lightGenre);
    }

    /**
     * Rejeição forte, usada só em SÉRIES KIDS. A regra é semântica/genérica;
     * não depende de nomes de programas específicos.
     */
    private static boolean hardRejectKidsSeries(SeriesItem item) {
        if (item == null || item.isAdult) return true;
        if (kidsRatingVerdict(item.contentRating) < 0) return true;
        String genre = " " + normalize(item.genre) + " ";
        String title = " " + normalize(item.name) + " ";
        String plot = " " + normalize(item.plot) + " ";
        String all = genre + " " + title + " " + plot;

        // Anime fica na seção ANIMES quando não veio de uma categoria infantil direta.
        if (hasAny(genre, " anime ", " manga ", " shonen ", " shoujo ", " shojo ", " seinen ", " isekai ")) return true;

        // Documentário/docuseries em uma pasta Disney/Família precisa de sinal
        // infantil/juvenil próprio; citar animação no texto não basta.
        boolean documentary = hasAny(genre,
                " documentary ", " documentario ", " documentarios ", " documental ", " docuseries ");
        if (documentary && !strongChildEvidence(item)) return true;

        return hasAny(all,
                " adult ", " adults ", " adulto ", " adultos ", " erotic ", " erotico ",
                " erotica ", " porn ", " porno ", " sexual ", " sexo ", " sexy ",
                " horror ", " terror ", " thriller ", " suspense ", " mystery ", " misterio ",
                " crime ", " criminal ",
                " police ", " policial ", " policia ", " detective ", " detetive ",
                " murder ", " assassin ", " assassino ", " homicidio ", " homicide ",
                " serial killer ", " assassino em serie ", " tueur en serie ",
                " sequestro ", " sequestr ", " kidnapping ", " kidnapped ", " kidnap ",
                " abduction ", " abducted ", " rapto ", " raptada ", " raptado ",
                " desaparecimento ", " desaparecida ", " desaparecido ", " desaparecidas ",
                " desaparecidos ", " missing person ", " missing persons ",
                " investigacao ", " investigation ", " investigateur ", " enquete ",
                " hospital ", " medical ", " medico ", " medica ", " firefighter ",
                " bombeiro ", " bombeiros ", " paramedic ", " paramedico ", " emergencia ",
                " emergency ", " war ", " guerra ", " narcotic ", " droga ", " drogas ",
                " cartel ", " true crime ", " reality show ", " news ", " noticias ",
                " namoro ", " namorar ", " dating ", " date ", " relationship ",
                " relacionamento ", " casamento ", " divorce ", " divorcio ",
                " boyfriend ", " girlfriend ", " marido ", " esposa ",
                // NovaEra exposes KIDS_BLOCKED_HINTS/isBlockedKidsTitle. We use
                // only generic crime/abduction semantics here, never a program
                // title blacklist. This is especially important in mixed Disney+/
                // Família buckets where providers sometimes place adult dramas.
                " roubada ", " roubado ", " roubo ", " assalto ", " stolen ",
                " theft ", " robbery ", " hostage ", " refem ", " refens ");
    }

    /** Evidência infantil forte; termos genéricos Family/Disney/Animation não contam. */
    private static boolean strongChildEvidence(Movie item) {
        if (item == null || item.isAdult) return false;
        if (kidsRatingVerdict(item.contentRating) > 0) return true;
        String all = " " + normalize(safe(item.genre) + " " + safe(item.plot)
                + " " + safe(item.mediaType) + " " + safe(item.vodType) + " " + safe(item.filterType)) + " ";
        return hasAny(all,
                " kids ", " kid ", " children ", " child ", " infantil ", " infantis ",
                " crianca ", " criancas ", " infanto juvenil ", " infantojuvenil ",
                " preschool ", " pre school ", " educativo infantil ", " educational for children ",
                " desenho infantil ", " cartoon infantil ", " publico infantil ", " para criancas ",
                " aventura infantil ", " serie juvenil ", " programa infantil ");
    }

    /** Evidência infantil forte para séries; evita documentário geral em Disney+. */
    private static boolean strongChildEvidence(SeriesItem item) {
        if (item == null || item.isAdult) return false;
        if (kidsRatingVerdict(item.contentRating) > 0) return true;
        String all = " " + normalize(safe(item.genre) + " " + safe(item.plot)
                + " " + safe(item.mediaType) + " " + safe(item.vodType) + " " + safe(item.filterType)) + " ";
        return hasAny(all,
                " kids ", " kid ", " children ", " child ", " infantil ", " infantis ",
                " crianca ", " criancas ", " infanto juvenil ", " infantojuvenil ",
                " preschool ", " pre school ", " educativo infantil ", " educational for children ",
                " desenho infantil ", " cartoon infantil ", " publico infantil ", " para criancas ",
                " aventura infantil ", " serie juvenil ", " programa infantil ",
                " escola ", " escolar ", " estudante ", " estudantes ", " equipe juvenil ");
    }

    /**
     * Returns +1 for clearly child-safe ratings, -1 for adolescent/adult ratings,
     * and 0 when the provider supplied no usable classification. Numeric values
     * here are AGE labels only (content_rating/age_rating/etc.), never the normal
     * Xtream popularity score in item.rating.
     */
    private static int kidsRatingVerdict(String raw) {
        String original = safe(raw).toLowerCase(Locale.ROOT).trim();
        if (original.isEmpty()) return 0;
        String n = " " + normalize(original).replace("+", " plus ") + " ";

        if (hasAny(n,
                " tv ma ", " tv 14 ", " nc 17 ", " nc17 ", " r rated ",
                " adults only ", " adult ", " adulto ", " 18 plus ", " 18 anos ",
                " 16 plus ", " 16 anos ", " 14 plus ", " 14 anos ",
                " 13 plus ", " 13 anos ")) return -1;

        // Common Brazilian/TV/MPAA child-safe labels. PG is intentionally not
        // considered decisive because it can include older-family material.
        if (hasAny(n,
                " livre ", " classificacao livre ", " all ages ", " todos ",
                " tv y ", " tv y7 ", " tv g ", " g rated ",
                " 0 plus ", " 6 plus ", " 7 plus ", " 9 plus ", " 10 plus ",
                " 0 anos ", " 6 anos ", " 7 anos ", " 9 anos ", " 10 anos ")) return 1;

        // Bare age values are common in custom Xtream payloads.
        String digits = original.replaceAll("[^0-9]", "");
        if (!digits.isEmpty() && digits.length() <= 2) {
            try {
                int age = Integer.parseInt(digits);
                if (age >= 14) return -1;
                if (age <= 10) return 1;
            } catch (Exception ignored) { }
        }
        return 0;
    }

    private static String kidsCategoryNorm(String raw) {
        return " " + normalize(raw).replace("+", " plus ").replaceAll("\\s+", " ").trim() + " ";
    }

    private static boolean adultOrAnimeCategory(String n) {
        return hasAny(n,
                " anime ", " animes ", " manga ", " shonen ", " shoujo ", " shojo ",
                " seinen ", " isekai ", " hentai ", " ecchi ", " adult ", " adults ",
                " adulto ", " adultos ", " hot ", " xxx ", " porn ", " porno ",
                " erotico ", " erotica ", " sexy ", " sex ", " 18 plus ", " plus 18 ");
    }

    private static boolean strictAnime(SeriesItem item) {
        if (item.isAdult) return false;
        String genre = " " + normalize(item.genre) + " ";
        return hasAny(genre,
                " anime ", " manga ", " shonen ", " shoujo ", " shojo ", " seinen ",
                " isekai ", " japanese animation ", " animacao japonesa ");
    }

    private static String cleanDisplay(String raw) {
        String s = safe(raw).replace("\\/", "/").replace("\n", " ").replace("\r", " ").trim();
        s = s.replaceAll("(?i)^(filmes|series|séries)\\s*[-|:]\\s*", "").trim();
        return s.isEmpty() ? "Categoria" : s;
    }

    private static boolean hasAny(String source, String... terms) {
        for (String t : terms) if (source.contains(t)) return true;
        return false;
    }

    private static String normalize(String raw) {
        if (raw == null) return "";
        String s = Normalizer.normalize(raw, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        return s.toLowerCase(Locale.ROOT)
                .replace('|', ' ').replace('/', ' ').replace(',', ' ').replace(';', ' ')
                .replaceAll("\\s+", " ").trim();
    }

    private static String safe(String s) { return s == null ? "" : s.trim(); }
    private static boolean blank(String s) { return s == null || s.trim().isEmpty(); }
}
