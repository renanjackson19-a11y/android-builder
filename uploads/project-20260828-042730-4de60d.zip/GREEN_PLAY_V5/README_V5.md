# GREEN PLAY V5 — BASE NOVA

Projeto Android criado do zero. Nenhuma Activity, Adapter, cache, player ou classe do V4 foi reutilizada.

## Alpha 02
- Contrato real do painel conectado (host + token do aplicativo configurados apenas como dados de compatibilidade).
- Login do painel corrigido: quando o painel não devolve `xtream_host`, o V5 usa a raiz oficial do painel como servidor Xtream, como exige o contrato atual.
- Sessão V5 continua independente.
- Primeiro módulo funcional criado: TV.
- TV carrega `get_live_categories` e `get_live_streams` diretamente pelo Xtream.
- Filtro por categoria.
- Pesquisa por nome do canal.
- Logos dos canais.
- Preview Media3 à direita.
- EPG curto (Agora / A seguir).
- OK/click abre player em tela cheia.
- Navegação focável para TV Box/controle remoto.

## Ainda não implementado nesta alpha
- Favoritos e recentes persistentes.
- Futebol.
- Filmes.
- Séries/temporadas/episódios.
- Kids.
- Anime.
- HOT + PIN.
- Conta e personalização completa do painel.

A regra permanece: cada módulo novo é isolado. Não remendar o V4.
