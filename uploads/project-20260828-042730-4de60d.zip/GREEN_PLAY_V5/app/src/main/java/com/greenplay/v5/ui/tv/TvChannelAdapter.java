package com.greenplay.v5.ui.tv;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.greenplay.v5.R;
import com.greenplay.v5.data.model.tv.TvChannel;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

final class TvChannelAdapter extends RecyclerView.Adapter<TvChannelAdapter.Holder> {
    interface Listener { void onFocus(TvChannel channel); void onOpen(TvChannel channel); }
    private final List<TvChannel> all = new ArrayList<>();
    private final List<TvChannel> rows = new ArrayList<>();
    private final Listener listener;
    TvChannelAdapter(Listener listener){this.listener=listener;}
    void setRows(List<TvChannel> data){all.clear();if(data!=null)all.addAll(data);filter("");}
    void filter(String q){rows.clear();String s=q==null?"":q.trim().toLowerCase(Locale.ROOT);for(TvChannel c:all)if(s.isEmpty()||c.name.toLowerCase(Locale.ROOT).contains(s))rows.add(c);notifyDataSetChanged();}
    TvChannel first(){return rows.isEmpty()?null:rows.get(0);}

    @NonNull @Override public Holder onCreateViewHolder(@NonNull ViewGroup parent,int viewType){return new Holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_tv_channel,parent,false));}
    @Override public void onBindViewHolder(@NonNull Holder h,int pos){
        TvChannel c=rows.get(pos); h.number.setText(String.valueOf(pos+1)); h.name.setText(c.name); h.logo.setImageDrawable(null);
        if(c.logo!=null&&!c.logo.trim().isEmpty())Picasso.get().load(c.logo).fit().centerInside().into(h.logo);
        h.itemView.setOnFocusChangeListener((v,focus)->{v.setSelected(focus);if(focus)listener.onFocus(c);});
        h.itemView.setOnClickListener(v->listener.onOpen(c));
    }
    @Override public int getItemCount(){return rows.size();}
    static final class Holder extends RecyclerView.ViewHolder{final TextView number,name;final ImageView logo;Holder(View v){super(v);number=v.findViewById(R.id.channelNumber);name=v.findViewById(R.id.channelName);logo=v.findViewById(R.id.channelLogo);}}
}
