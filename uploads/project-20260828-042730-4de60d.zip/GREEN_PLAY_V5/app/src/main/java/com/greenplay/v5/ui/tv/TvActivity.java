package com.greenplay.v5.ui.tv;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.greenplay.v5.core.network.StreamUrlFactory;
import com.greenplay.v5.core.session.SessionStore;
import com.greenplay.v5.data.model.tv.TvCategory;
import com.greenplay.v5.data.model.tv.TvChannel;
import com.greenplay.v5.data.model.tv.TvEpg;
import com.greenplay.v5.data.repository.TvRepository;
import com.greenplay.v5.databinding.ActivityTvBinding;
import com.greenplay.v5.ui.player.PlayerActivity;
import java.util.List;

public final class TvActivity extends AppCompatActivity {
    private ActivityTvBinding b;
    private SessionStore session;
    private TvRepository repo;
    private TvCategoryAdapter categories;
    private TvChannelAdapter channels;
    private ExoPlayer previewPlayer;
    private TvChannel current;

    @Override protected void onCreate(Bundle state){
        super.onCreate(state); b=ActivityTvBinding.inflate(getLayoutInflater());setContentView(b.getRoot());
        session=new SessionStore(this);
        if(!session.isLogged()||session.host().trim().isEmpty()){finish();return;}
        repo=new TvRepository(session.host(),session.user(),session.pass());
        setupLists(); setupSearch(); setupPlayer(); bindTopNav(); loadCategories();
    }

    private void setupLists(){
        categories=new TvCategoryAdapter(this::onCategory);
        b.categoryList.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false));b.categoryList.setAdapter(categories);
        channels=new TvChannelAdapter(new TvChannelAdapter.Listener(){
            @Override public void onFocus(TvChannel channel){showChannel(channel,true);}
            @Override public void onOpen(TvChannel channel){openFull(channel);}
        });
        b.channelList.setLayoutManager(new LinearLayoutManager(this));b.channelList.setAdapter(channels);
    }

    private void setupSearch(){b.search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){channels.filter(s.toString());}public void afterTextChanged(Editable e){}});}

    private void setupPlayer(){previewPlayer=new ExoPlayer.Builder(this).build();b.previewPlayer.setPlayer(previewPlayer);b.previewPlayer.setUseController(false);}

    private void bindTopNav(){
        b.navTv.setOnClickListener(v->b.search.requestFocus());
        b.navFootball.setOnClickListener(v->Toast.makeText(this,"Futebol é o próximo módulo",Toast.LENGTH_SHORT).show());
        b.navMovies.setOnClickListener(v->Toast.makeText(this,"Filmes entra depois da TV",Toast.LENGTH_SHORT).show());
        b.navSeries.setOnClickListener(v->Toast.makeText(this,"Séries entra depois de Filmes",Toast.LENGTH_SHORT).show());
        b.navKids.setOnClickListener(v->Toast.makeText(this,"Kids será isolado",Toast.LENGTH_SHORT).show());
        b.navAnime.setOnClickListener(v->Toast.makeText(this,"Anime será isolado",Toast.LENGTH_SHORT).show());
        b.navHot.setOnClickListener(v->Toast.makeText(this,"HOT será protegido por PIN",Toast.LENGTH_SHORT).show());
    }

    private void loadCategories(){
        b.loading.setVisibility(View.VISIBLE);b.error.setText("");
        repo.categories(new TvRepository.CategoriesResult(){
            @Override public void success(List<TvCategory> rows){runOnUiThread(()->{categories.setRows(rows);loadChannels("");});}
            @Override public void error(String message){runOnUiThread(()->{b.loading.setVisibility(View.GONE);b.error.setText(message);});}
        });
    }
    private void onCategory(TvCategory category,int position){loadChannels(category.id);}
    private void loadChannels(String categoryId){
        b.loading.setVisibility(View.VISIBLE);b.error.setText("");
        repo.channels(categoryId,new TvRepository.ChannelsResult(){
            @Override public void success(List<TvChannel> rows){runOnUiThread(()->{b.loading.setVisibility(View.GONE);channels.setRows(rows);b.total.setText(rows.size()+" canais");TvChannel f=channels.first();if(f!=null)showChannel(f,false);else stopPreview();});}
            @Override public void error(String message){runOnUiThread(()->{b.loading.setVisibility(View.GONE);b.error.setText(message);channels.setRows(null);stopPreview();});}
        });
    }

    private void showChannel(TvChannel c,boolean autoplay){
        current=c;b.previewName.setText(c.name);b.epgNow.setText("AGORA  •  carregando...");b.epgNext.setText("A SEGUIR  •  carregando...");
        repo.epg(c.id,new TvRepository.EpgResult(){@Override public void success(TvEpg epg){runOnUiThread(()->{if(current!=c)return;b.epgNow.setText("AGORA  •  "+epg.nowTitle);b.epgNext.setText("A SEGUIR  •  "+epg.nextTitle);});}@Override public void error(String m){}});
        if(autoplay)playPreview(c);
    }
    private void playPreview(TvChannel c){
        try{String url=StreamUrlFactory.live(session.host(),session.user(),session.pass(),c.id,c.extension);previewPlayer.setMediaItem(MediaItem.fromUri(url));previewPlayer.prepare();previewPlayer.play();}catch(Exception e){b.error.setText("Não foi possível abrir a prévia deste canal");}
    }
    private void stopPreview(){if(previewPlayer!=null){previewPlayer.stop();previewPlayer.clearMediaItems();}b.previewName.setText("Selecione um canal");b.epgNow.setText("AGORA");b.epgNext.setText("A SEGUIR");}
    private void openFull(TvChannel c){String url=StreamUrlFactory.live(session.host(),session.user(),session.pass(),c.id,c.extension);Intent i=new Intent(this, PlayerActivity.class);i.putExtra("url",url);i.putExtra("title",c.name);startActivity(i);}

    @Override public boolean onKeyDown(int keyCode,KeyEvent event){if(keyCode==KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE&&current!=null){playPreview(current);return true;}return super.onKeyDown(keyCode,event);}
    @Override protected void onStop(){super.onStop();if(previewPlayer!=null)previewPlayer.pause();}
    @Override protected void onDestroy(){if(previewPlayer!=null)previewPlayer.release();super.onDestroy();}
}
