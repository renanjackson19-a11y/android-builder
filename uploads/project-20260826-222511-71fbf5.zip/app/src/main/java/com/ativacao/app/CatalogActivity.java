package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class CatalogActivity extends Activity {
    private final List<ApiClient.Item> items = new ArrayList<>();
    private GridView grid;
    private Adapter adapter;
    private LinearLayout categoryList;
    private TextView status, title;
    private EditText search;
    private String type, category = "", smart = "", query = "";
    private int page = 1, pages = 1, total = 0;
    private boolean loading = false, phone;
    private boolean autoplay = false;
    private final Handler handler = new Handler();
    private Runnable searchTask;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.immersive(this);
        phone = Ui.phone(this);
        type = clean(getIntent().getStringExtra("type"), "live");
        category = clean(getIntent().getStringExtra("category"), "");
        smart = clean(getIntent().getStringExtra("smart"), "");
        autoplay = getIntent().getBooleanExtra("autoplay", false) && "live".equals(type);
        setContentView(build());
        if (!"live".equals(type)) { renderCategories(new ArrayList<>()); loadCategories(); }
        if (autoplay) {
            ApiClient.Item last = LocalStore.lastLive(this);
            if (last != null && last.id > 0) { autoplay=false; open(last); }
        }
        load(1, true);
    }

    @Override protected void onResume() { super.onResume(); Ui.immersive(this); }

    private View build() {
        LinearLayout root = Ui.column(this);
        root.setBackground(Ui.diagonalGradient(0xFF07160B,0xFF010402,0,this));

        String active = "movie".equals(type)?"FILMES":("series".equals(type)?"SÉRIES":"TV");
        root.addView(YellowNav.bar(this,active),new LinearLayout.LayoutParams(-1,Ui.dp(this,64)));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL); top.setPadding(Ui.dp(this,18),0,Ui.dp(this,18),0); top.setBackgroundColor(Color.TRANSPARENT);
        title=Ui.text(this,clean(getIntent().getStringExtra("title"),titleFor(type)),phone?16:21,Ui.TEXT,true); LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,Ui.dp(this,42),1);top.addView(title,tp);
        search=new EditText(this);search.setSingleLine(true);search.setHint("Buscar...");search.setHintTextColor(Ui.MUTED);search.setTextColor(Ui.TEXT);search.setTextSize(phone?10:12);search.setBackground(Ui.stroke(0xFF0E1710,0xFF2B3B2E,16,this));search.setPadding(Ui.dp(this,12),0,Ui.dp(this,12),0);
        top.addView(search,new LinearLayout.LayoutParams(Ui.dp(this,phone?190:230),Ui.dp(this,36)));
        TextView refresh=Ui.button(this,"movie".equals(type)?"↻":"↻ ATUALIZAR");
        LinearLayout.LayoutParams rfp=new LinearLayout.LayoutParams(Ui.dp(this,"movie".equals(type)?48:(phone?105:130)),Ui.dp(this,36));rfp.leftMargin=Ui.dp(this,8);top.addView(refresh,rfp);
        refresh.setOnClickListener(v->{if(!"movie".equals(type))status.setText("Atualizando catálogo...");CatalogPreloader.start(CatalogActivity.this,true,()->runOnUiThread(()->{items.clear();load(1,true);}));});
        root.addView(top,new LinearLayout.LayoutParams(-1,"movie".equals(type)?0:Ui.dp(this,52)));

        LinearLayout main = new LinearLayout(this);
        main.setPadding(Ui.dp(this,18),Ui.dp(this,8),Ui.dp(this,18),Ui.dp(this,12));

        LinearLayout right = Ui.column(this);

        if ("movie".equals(type) || "series".equals(type)) {
            // FILMES: menu vertical compacto à esquerda, como um app de streaming.
            LinearLayout movieRail = Ui.column(this);
            movieRail.setPadding(Ui.dp(this,10),Ui.dp(this,8),Ui.dp(this,10),Ui.dp(this,8));
            movieRail.setBackground(Ui.round(0xAA111315,12,this));

            search = new EditText(this);
            search.setSingleLine(true);
            search.setHint("⌕  Buscar");
            search.setHintTextColor(0xFFE5E5E5);
            search.setTextColor(Ui.TEXT);
            search.setTextSize(phone?11:13);
            search.setPadding(Ui.dp(this,14),0,Ui.dp(this,10),0);
            search.setBackground(Ui.stroke(0xFF3B3B3F,0xFF505055,7,this));
            movieRail.addView(search,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));

            TextView latest = Ui.text(this,"series".equals(type)?"SÉRIES RECENTES":"FILMES RECENTES",phone?9:10,Ui.GREEN,true);
            latest.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
            LinearLayout.LayoutParams ltp = new LinearLayout.LayoutParams(-1,Ui.dp(this,30));
            ltp.topMargin=Ui.dp(this,6);
            movieRail.addView(latest,ltp);

            ScrollView cs = new ScrollView(this);
            cs.setVerticalScrollBarEnabled(false);
            categoryList = Ui.column(this);
            cs.addView(categoryList,new ScrollView.LayoutParams(-1,-2));
            movieRail.addView(cs,new LinearLayout.LayoutParams(-1,0,1));

            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(Ui.dp(this,phone?142:158),-1);
            rp.rightMargin=Ui.dp(this,14);
            main.addView(movieRail,rp);

            status = Ui.text(this,"",1,Color.TRANSPARENT,false);
            status.setVisibility(View.GONE);
        } else if (!"live".equals(type)) {
            LinearLayout rail = Ui.column(this);
            rail.setPadding(Ui.dp(this,8),Ui.dp(this,8),Ui.dp(this,14),Ui.dp(this,8));
            rail.setBackground(Ui.round(0xAA09110B,12,this));
            TextView catTitle = Ui.text(this,categoryHeading(),10,Ui.GREEN,true);
            catTitle.setGravity(Gravity.CENTER);
            rail.addView(catTitle,new LinearLayout.LayoutParams(-1,Ui.dp(this,34)));
            ScrollView cs = new ScrollView(this);
            cs.setVerticalScrollBarEnabled(false);
            categoryList = Ui.column(this);
            cs.addView(categoryList,new ScrollView.LayoutParams(-1,-2));
            rail.addView(cs,new LinearLayout.LayoutParams(-1,0,1));
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(Ui.dp(this,phone?190:220),-1);
            rp.rightMargin=Ui.dp(this,14);
            main.addView(rail,rp);

            status = Ui.text(this,"Catálogo",10,Ui.MUTED,false);
            right.addView(status,new LinearLayout.LayoutParams(-1,Ui.dp(this,31)));
        } else {
            categoryList = Ui.column(this); category=""; smart="";
            status = Ui.text(this,"TV ao vivo",10,Ui.MUTED,false);
            right.addView(status,new LinearLayout.LayoutParams(-1,Ui.dp(this,31)));
        }

        grid = new GridView(this);
        int sw = Ui.sw(this); int cols;
        if ("live".equals(type)) cols = phone ? 4 : (sw < 1000 ? 5 : 6);
        else if ("movie".equals(type) || "series".equals(type)) cols = getResources().getConfiguration().orientation==android.content.res.Configuration.ORIENTATION_LANDSCAPE ? 6 : 3;
        else cols = phone ? 3 : (sw < 1100 ? 4 : 5);

        grid.setNumColumns(cols);
        grid.setHorizontalSpacing(Ui.dp(this,("movie".equals(type)||"series".equals(type))?7:8));
        grid.setVerticalSpacing(Ui.dp(this,("movie".equals(type)||"series".equals(type))?8:10));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setSelector(android.R.color.transparent);
        grid.setPadding(0,0,0,Ui.dp(this,8));
        adapter = new Adapter();
        grid.setAdapter(adapter);

        right.addView(grid,new LinearLayout.LayoutParams(-1,0,1));
        main.addView(right,new LinearLayout.LayoutParams(0,-1,1));
        root.addView(main,new LinearLayout.LayoutParams(-1,0,1));

        grid.setOnScrollListener(new AbsListView.OnScrollListener() {
            public void onScrollStateChanged(AbsListView v, int s) {}
            public void onScroll(AbsListView v, int first, int visible, int count) { if (count > 0 && !loading && page < pages && first + visible >= count - 5) load(page + 1, false); }
        });
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int b, int c) {
                query = s == null ? "" : s.toString().trim();
                if (searchTask != null) handler.removeCallbacks(searchTask);
                searchTask = () -> load(1, true); handler.postDelayed(searchTask, 420);
            }
            public void afterTextChanged(Editable e) {}
        });
        grid.requestFocus();
        return AppBackground.wrap(this,root);
    }

    private void loadCategories() {
        ApiClient.categories(type, new ApiClient.Callback<List<String>>() {
            @Override public void ok(List<String> cats) { runOnUiThread(() -> renderCategories(cats)); }
            @Override public void error(String m) { }
        });
    }

    private void renderCategories(List<String> cats) {
        categoryList.removeAllViews();
        // "Todos" é apenas um controle de visualização. Todas as categorias de conteúdo
        // abaixo vêm do painel/API; o APK não mantém nomes de categorias fixos.
        addCategory("Todos", "", "");
        int max = Math.min(cats == null ? 0 : cats.size(), 120);
        for (int i = 0; i < max; i++) {
            String c = clean(cats.get(i), "");
            if (!c.isEmpty()) addCategory(c, c, "");
        }
    }

    private void addCategory(String label, String cat, String smartKey) {
        boolean selected = cat.equals(category) && smartKey.equals(smart);
        TextView b = Ui.text(this,label,phone?9:11,selected?Color.BLACK:0xFFE7EBE8,selected);
        b.setMaxLines(1); b.setFocusable(true); b.setClickable(true);

        if("movie".equals(type)){
            b.setGravity(Gravity.CENTER);
            b.setPadding(Ui.dp(this,8),0,Ui.dp(this,8),0);
            Ui.focus(b,this,
                    selected?Ui.gradient(Ui.GREEN,Ui.GREEN_2,7,this):Ui.round(0xFF3A3A3E,7,this),
                    Ui.stroke(0xFF45454A,Ui.GREEN,7,this));
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,Ui.dp(this,40));
            p.topMargin=Ui.dp(this,4);
            categoryList.addView(b,p);
        }else{
            b.setGravity(Gravity.CENTER);
            b.setPadding(Ui.dp(this,8),0,Ui.dp(this,8),0);
            Ui.focus(b,this,
                    selected?Ui.gradient(Ui.GREEN,Ui.GREEN_2,14,this):Ui.round(0x22000000,14,this),
                    Ui.stroke(0xFF142018,Ui.GREEN,14,this));
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,Ui.dp(this,38));
            p.bottomMargin=Ui.dp(this,2);
            categoryList.addView(b,p);
        }

        b.setOnClickListener(v -> {
            if ("football_today".equals(smartKey)) { startActivity(new Intent(this, FootballActivity.class)); return; }
            category = cat; smart = smartKey; renderCategoriesSnapshot(); load(1, true);
        });
    }
    private void renderCategoriesSnapshot() { loadCategories(); }

    private void load(int target, boolean reset) {
        if (loading) return; loading = true;
        if (reset && items.isEmpty() && !"movie".equals(type) && !CatalogPreloader.isPrepared(this)) status.setText("Carregando conteúdo...");
        int limit = "series".equals(type) ? 60 : ("movie".equals(type) ? 72 : (phone ? 36 : 48));
        boolean preparedDefault = reset && target==1 && query.isEmpty() && category.isEmpty() && smart.isEmpty()
                && ("movie".equals(type)||"series".equals(type)) && CatalogPreloader.isPrepared(this);
        if(preparedDefault) {
            ApiClient.catalogPrepared(type,target,limit,query,category,smart,new ApiClient.Callback<ApiClient.CatalogPage>() {
            @Override public void ok(ApiClient.CatalogPage p) {
                runOnUiThread(() -> {
                    loading = false; page = p.page; pages = p.pages; total = p.total; if (reset) items.clear(); items.addAll(p.items);
                    if ("movie".equals(type) || "series".equals(type)) sortNewestWithCover(items);
                    adapter.notifyDataSetChanged();
                    prefetchArtwork(items);
                    if(page<pages) ApiClient.warmCatalog(type,page+1,limit,query,category,smart);
                    String prefix = !category.isEmpty() ? category + " • " : (!smart.isEmpty() ? smartLabel(smart) + " • " : "");
                    if(!"movie".equals(type) && !"series".equals(type)) status.setText(prefix + total + " itens" + (pages > 1 ? " • página " + page + "/" + pages : ""));
                    if (reset && !items.isEmpty()) {
                        grid.requestFocus();
                        if (autoplay && "live".equals(type)) { autoplay=false; open(items.get(0)); }
                    }
                    if (items.isEmpty() && reset && !"movie".equals(type)) status.setText(prefix + "Nenhum conteúdo encontrado");
                });
            }
            @Override public void error(String m) { runOnUiThread(() -> { loading = false; status.setText("Falha ao carregar • " + m); }); }
            });
        } else {
            ApiClient.catalog(type,target,limit,query,category,smart,new ApiClient.Callback<ApiClient.CatalogPage>() {
                @Override public void ok(ApiClient.CatalogPage p) {
                    runOnUiThread(() -> {
                        loading=false; page=p.page; pages=p.pages; total=p.total;
                        if(reset)items.clear(); items.addAll(p.items);
                        if("movie".equals(type)||"series".equals(type))sortNewestWithCover(items);
                        adapter.notifyDataSetChanged();
                        prefetchArtwork(items);
                        if(page<pages)ApiClient.warmCatalog(type,page+1,limit,query,category,smart);
                        String prefix=!category.isEmpty()?category+" • ":(!smart.isEmpty()?smartLabel(smart)+" • ":"");
                        if(!"movie".equals(type) && !"series".equals(type))status.setText(prefix+total+" itens"+(pages>1?" • página "+page+"/"+pages:""));
                        if(reset&&!items.isEmpty())grid.requestFocus();
                        if(items.isEmpty()&&reset&&!"movie".equals(type))status.setText(prefix+"Nenhum conteúdo encontrado");
                    });
                }
                @Override public void error(String m){runOnUiThread(()->{loading=false;status.setText("Falha ao carregar • "+m);});}
            });
        }
    }

    private void prefetchArtwork(List<ApiClient.Item> list){
        if(list==null)return;
        int max=Math.min(list.size(),36);
        for(int n=0;n<max;n++){
            ApiClient.Item i=list.get(n);
            if(i==null)continue;
            // A capa da grade não é mais trocada depois que o card aparece.
            // Isso evita o efeito de logos/capas "mudando" durante a navegação.
            ImageLoader.preload(this,clean(i.logo,i.backdrop));
        }
    }

    private void sortNewestWithCover(List<ApiClient.Item> list) {
        if (list == null || list.size() < 2) return;
        java.util.Collections.sort(list, new java.util.Comparator<ApiClient.Item>() {
            @Override public int compare(ApiClient.Item a, ApiClient.Item b) {
                int ca = hasCover(a) ? 1 : 0;
                int cb = hasCover(b) ? 1 : 0;
                if (ca != cb) return cb - ca;
                if (a.year != b.year) return b.year - a.year;
                return a.id < b.id ? 1 : (a.id > b.id ? -1 : 0);
            }
        });
    }

    private boolean hasCover(ApiClient.Item i) {
        if (i == null) return false;
        String v = i.logo;
        return v != null && !v.trim().isEmpty() && !"null".equalsIgnoreCase(v.trim());
    }

    private class Adapter extends BaseAdapter {
        public int getCount() { return items.size(); }
        public Object getItem(int p) { return items.get(p); }
        public long getItemId(int p) { return items.get(p).id; }

        public View getView(int p, View convert, android.view.ViewGroup parent) {
            boolean live = "live".equals(type);
            boolean movie = "movie".equals(type) || "series".equals(type);
            FrameLayout card;
            ImageView image;
            TextView name, meta;

            int imageH = live ? (phone ? 92 : 118) : (movie ? (getResources().getConfiguration().orientation==android.content.res.Configuration.ORIENTATION_LANDSCAPE ? 146 : 172) : (phone ? 176 : 224));
            int cardH  = live ? imageH : imageH + Ui.dp(CatalogActivity.this, movie ? 50 : 0);

            if (convert == null) {
                card = new FrameLayout(CatalogActivity.this);
                card.setFocusable(true);
                card.setClickable(true);
                card.setClipChildren(false);
                card.setClipToPadding(false);
                card.setPadding(Ui.dp(CatalogActivity.this,1),Ui.dp(CatalogActivity.this,1),Ui.dp(CatalogActivity.this,1),Ui.dp(CatalogActivity.this,1));
                Ui.focus(card, CatalogActivity.this,
                        Ui.round(0x10000000, 10, CatalogActivity.this),
                        Ui.stroke(0xFF0C1510, Ui.GREEN, 12, CatalogActivity.this));

                image = new ImageView(CatalogActivity.this);
                image.setId(601);
                image.setScaleType(live ? ImageView.ScaleType.CENTER_INSIDE : ImageView.ScaleType.CENTER_CROP);
                image.setBackgroundColor(Ui.PANEL_2);
                FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(-1, Ui.dp(CatalogActivity.this,imageH), Gravity.TOP);
                card.addView(image, ip);

                if(movie){
                    LinearLayout labels = Ui.column(CatalogActivity.this);
                    labels.setId(605);
                    labels.setPadding(Ui.dp(CatalogActivity.this,4),Ui.dp(CatalogActivity.this,4),Ui.dp(CatalogActivity.this,4),0);
                    name = Ui.text(CatalogActivity.this,"",phone?9:10,0xFFE8E8E8,false);
                    name.setId(602); name.setMaxLines(1);
                    meta = Ui.text(CatalogActivity.this,"",phone?8:9,0xFF9EAAA2,false);
                    meta.setId(603); meta.setMaxLines(1);
                    labels.addView(name,new LinearLayout.LayoutParams(-1,Ui.dp(CatalogActivity.this,23)));
                    labels.addView(meta,new LinearLayout.LayoutParams(-1,Ui.dp(CatalogActivity.this,18)));
                    FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1,Ui.dp(CatalogActivity.this,46),Gravity.BOTTOM);
                    card.addView(labels,lp);
                    card.setLayoutParams(new AbsListView.LayoutParams(-1,Ui.dp(CatalogActivity.this,imageH+50)));
                }else{
                    View shade = new View(CatalogActivity.this);
                    shade.setId(604);
                    shade.setBackground(Ui.verticalGradient(Color.TRANSPARENT,Color.argb(220,0,0,0),0,CatalogActivity.this));
                    FrameLayout.LayoutParams sh = new FrameLayout.LayoutParams(-1,Ui.dp(CatalogActivity.this,62),Gravity.BOTTOM);
                    card.addView(shade,sh);
                    LinearLayout labels = Ui.column(CatalogActivity.this);
                    labels.setId(605);
                    labels.setPadding(Ui.dp(CatalogActivity.this,7),0,Ui.dp(CatalogActivity.this,7),Ui.dp(CatalogActivity.this,5));
                    name = Ui.text(CatalogActivity.this,"",phone?9:11,Ui.TEXT,true);
                    name.setId(602); name.setMaxLines(1);
                    meta = Ui.text(CatalogActivity.this,"",9,0xFFC6D0C8,false);
                    meta.setId(603); meta.setMaxLines(1);
                    labels.addView(name,new LinearLayout.LayoutParams(-1,0,1));
                    labels.addView(meta,new LinearLayout.LayoutParams(-1,Ui.dp(CatalogActivity.this,18)));
                    FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1,Ui.dp(CatalogActivity.this,58),Gravity.BOTTOM);
                    card.addView(labels,lp);
                }
                convert = card;
            }

            card=(FrameLayout)convert;
            image=convert.findViewById(601);
            name=convert.findViewById(602);
            meta=convert.findViewById(603);

            ApiClient.Item i=items.get(p);
            name.setText(clean(i.name,"Sem nome"));

            if(movie){
                String m=i.year>0?String.valueOf(i.year):"";
                meta.setText(m);
            }else{
                meta.setText(meta(i));
            }

            if(live) ImageLoader.into(CatalogActivity.this,image,i.logo);
            else ImageLoader.intoPoster(CatalogActivity.this,image,clean(i.logo,i.backdrop));

            card.setTag(i.id);
            card.setOnClickListener(v->open(i));
            return convert;
        }
    }

    private void open(ApiClient.Item i) {
        if ("series".equals(i.type)) { Intent in = new Intent(this, SeriesActivity.class); in.putExtra("title", clean(i.seriesTitle, i.name)); in.putExtra("name", i.name); in.putExtra("logo", i.logo); in.putExtra("backdrop", i.backdrop); in.putExtra("synopsis", i.synopsis); in.putExtra("group", i.group); in.putExtra("year", i.year); startActivity(in); }
        else if ("movie".equals(i.type)) { Intent in = new Intent(this, DetailActivity.class); MainActivity.putItem(in, i); startActivity(in); }
        else { Intent in = new Intent(this, PlayerActivity.class); MainActivity.putItem(in, i); LocalStore.saveLastLive(this, i); LocalStore.addHistory(this, i); startActivity(in); }
    }

    private String meta(ApiClient.Item i) { String g = clean(i.group, ""); if (i.year > 0) g += (g.isEmpty() ? "" : " • ") + i.year; if ("series".equals(type) && i.episodeCount > 0) g += (g.isEmpty() ? "" : " • ") + i.episodeCount + " eps."; return g; }
    private String titleFor(String t) { return "live".equals(t) ? "TV ao Vivo" : ("movie".equals(t) ? "Filmes" : "Séries"); }
    private String categoryHeading() { return "live".equals(type) ? "CATEGORIAS DE TV" : ("movie".equals(type) ? "CATEGORIAS DE FILMES" : "CATEGORIAS DE SÉRIES"); }
    private String smartLabel(String s) { if ("launch".equals(s)) return "Lançamentos"; if ("football".equals(s)) return "Futebol"; if ("news".equals(s)) return "Notícias"; if ("kids".equals(s)) return "Kids"; if ("music".equals(s)) return "Música"; if ("anime".equals(s)) return "Anime"; if ("novela".equals(s)) return "Novelas"; return s; }

    private void goBack() {
        if(getIntent().getBooleanExtra("top_level",false)) AppExit.confirm(this);
        else finish();
    }
    @Override public void onBackPressed() { goBack(); }
    private String clean(String v, String f) { if (v == null) return f; String s = v.trim(); return s.isEmpty() || "null".equalsIgnoreCase(s) ? f : s; }

    private boolean isAdultCatalogItem(ApiClient.Item i){
        if(i==null)return false;
        String group=i.group==null?"":i.group.toLowerCase(java.util.Locale.ROOT);
        String name=i.name==null?"":i.name.toLowerCase(java.util.Locale.ROOT);
        String[] keys={"adulto","adultos","adult","18+","18 anos","+18","hot","sexy","privê","prive","erótico","erotico","xxx","porn"};
        for(String k:keys)if(group.contains(k))return true;
        return name.contains("+18")||name.contains("18+")||name.contains(" adulto")||name.startsWith("adulto")||name.startsWith("hot ")||name.startsWith("xxx");
    }
}
