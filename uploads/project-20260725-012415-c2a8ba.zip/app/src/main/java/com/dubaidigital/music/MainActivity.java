package com.dubaidigital.music;

import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.Player;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionToken;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.common.util.concurrent.ListenableFuture;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private final ArrayList<Song> songs = new ArrayList<>();
    private SongAdapter adapter;
    private TextView msg;
    private TextView nowTitle;
    private TextView nowArtist;
    private EditText search;
    private Button play;
    private ListenableFuture<MediaController> future;
    private MediaController controller;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main);

        search = findViewById(R.id.search);
        msg = findViewById(R.id.message);
        nowTitle = findViewById(R.id.nowTitle);
        nowArtist = findViewById(R.id.nowArtist);
        play = findViewById(R.id.playPause);

        RecyclerView list = findViewById(R.id.list);
        list.setLayoutManager(new LinearLayoutManager(this));
        adapter = new SongAdapter(songs, this::prepareSong);
        list.setAdapter(adapter);

        findViewById(R.id.searchBtn).setOnClickListener(view -> doSearch());
        findViewById(R.id.logout).setOnClickListener(view -> {
            getSharedPreferences("auth", MODE_PRIVATE).edit().clear().apply();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });

        play.setOnClickListener(view -> {
            if (controller == null) return;
            if (controller.isPlaying()) controller.pause();
            else controller.play();
            updatePlay();
        });

        findViewById(R.id.next).setOnClickListener(view -> {
            if (controller != null) controller.seekToNextMediaItem();
        });
        findViewById(R.id.prev).setOnClickListener(view -> {
            if (controller != null) controller.seekToPreviousMediaItem();
        });

        connect();
    }

    private void connect() {
        SessionToken token = new SessionToken(this, new ComponentName(this, MusicService.class));
        future = new MediaController.Builder(this, token).buildAsync();
        future.addListener(() -> {
            try {
                controller = future.get();
                controller.addListener(new Player.Listener() {
                    @Override
                    public void onIsPlayingChanged(boolean isPlaying) {
                        runOnUiThread(() -> updatePlay());
                    }

                    @Override
                    public void onMediaItemTransition(MediaItem item, int reason) {
                        runOnUiThread(() -> showCurrent(item));
                    }
                });
            } catch (Exception exception) {
                runOnUiThread(() -> msg.setText(exception.getMessage()));
            }
        }, Runnable::run);
    }

    private void doSearch() {
        String query = search.getText().toString().trim();
        if (query.isEmpty()) return;
        msg.setText("Buscando músicas...");

        new Thread(() -> {
            try {
                String url = BuildConfig.PIPED_API + "/search?q="
                        + URLEncoder.encode(query, "UTF-8") + "&filter=music_songs";
                JSONObject json = new JSONObject(Net.get(url));
                JSONArray items = json.optJSONArray("items");
                ArrayList<Song> found = new ArrayList<>();

                if (items != null) {
                    for (int i = 0; i < items.length(); i++) {
                        JSONObject item = items.optJSONObject(i);
                        if (item == null) continue;
                        String id = item.optString("url");
                        if (id.contains("v=")) id = id.substring(id.indexOf("v=") + 2);
                        if (id.startsWith("/watch?v=")) id = id.substring(9);
                        String artist = item.optString("uploaderName", item.optString("uploader", "Artista"));
                        found.add(new Song(
                                id,
                                item.optString("title", "Música"),
                                artist,
                                item.optString("thumbnail", "")
                        ));
                    }
                }

                runOnUiThread(() -> {
                    songs.clear();
                    songs.addAll(found);
                    adapter.notifyDataSetChanged();
                    msg.setText(found.isEmpty()
                            ? "Nenhum resultado encontrado."
                            : found.size() + " músicas encontradas");
                });
            } catch (Exception exception) {
                runOnUiThread(() -> msg.setText("Erro na busca: " + exception.getMessage()));
            }
        }).start();
    }

    private void prepareSong(int position) {
        if (controller == null || position < 0 || position >= songs.size()) return;
        msg.setText("Preparando áudio...");

        new Thread(() -> {
            try {
                ArrayList<MediaItem> queue = new ArrayList<>();
                for (int i = position; i < songs.size(); i++) {
                    Song song = songs.get(i);
                    String stream = resolve(song.id);
                    MediaMetadata metadata = new MediaMetadata.Builder()
                            .setTitle(song.title)
                            .setArtist(song.artist)
                            .build();
                    queue.add(new MediaItem.Builder()
                            .setUri(stream)
                            .setMediaId(song.id)
                            .setMediaMetadata(metadata)
                            .build());
                }

                runOnUiThread(() -> {
                    controller.setMediaItems(queue);
                    controller.prepare();
                    controller.play();
                    msg.setText("Reproduzindo");
                });
            } catch (Exception exception) {
                runOnUiThread(() -> msg.setText("Não foi possível tocar: " + exception.getMessage()));
            }
        }).start();
    }

    private String resolve(String id) throws Exception {
        JSONObject json = new JSONObject(Net.get(BuildConfig.PIPED_API + "/streams/" + id));
        JSONArray streams = json.optJSONArray("audioStreams");
        if (streams == null || streams.length() == 0) throw new Exception("áudio indisponível");

        JSONObject best = null;
        int bitrate = -1;
        for (int i = 0; i < streams.length(); i++) {
            JSONObject stream = streams.getJSONObject(i);
            int currentBitrate = stream.optInt("bitrate", 0);
            if (currentBitrate > bitrate) {
                bitrate = currentBitrate;
                best = stream;
            }
        }
        if (best == null) throw new Exception("stream não encontrado");
        return best.getString("url");
    }

    private void showCurrent(MediaItem item) {
        if (item == null) return;
        CharSequence title = item.mediaMetadata.title;
        CharSequence artist = item.mediaMetadata.artist;
        nowTitle.setText(title == null ? "Música" : title);
        nowArtist.setText(artist == null ? "" : artist);
        updatePlay();
    }

    private void updatePlay() {
        play.setText(controller != null && controller.isPlaying() ? "❚❚" : "▶");
    }

    @Override
    protected void onDestroy() {
        if (future != null) MediaController.releaseFuture(future);
        super.onDestroy();
    }
}
