package com.spotnet.music;

import android.Manifest;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.Player;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionToken;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.google.common.util.concurrent.ListenableFuture;
import org.json.*;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends AppCompatActivity {
    LinearLayout bannerBox, sectionsBox;
    View homeTab, searchTab, queueTab;
    TextView homeStatus, searchStatus, queueStatus, nowTitle, nowSub, navHome, navSearch, navQueue;
    EditText searchInput;
    ImageView nowThumb;
    Button playPause, previousBtn, nextBtn, shuffleBtn;
    final ArrayList<MusicItem> searchItems = new ArrayList<>();
    final ArrayList<MusicItem> queueItems = new ArrayList<>();
    SearchAdapter searchAdapter, queueAdapter;
    ListenableFuture<MediaController> controllerFuture;
    MediaController controller;
    final AtomicInteger queueGeneration = new AtomicInteger(0);
    boolean shuffleEnabled = false;

    private final ActivityResultLauncher<String> notificationPermission = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(), granted -> {});

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        bannerBox=findViewById(R.id.bannerBox); sectionsBox=findViewById(R.id.sectionsBox);
        homeTab=findViewById(R.id.homeTab); searchTab=findViewById(R.id.searchTab); queueTab=findViewById(R.id.queueTab);
        homeStatus=findViewById(R.id.homeStatus); searchStatus=findViewById(R.id.searchStatus); queueStatus=findViewById(R.id.queueStatus);
        nowTitle=findViewById(R.id.nowTitle); nowSub=findViewById(R.id.nowSub); nowThumb=findViewById(R.id.nowThumb);
        navHome=findViewById(R.id.navHome); navSearch=findViewById(R.id.navSearch); navQueue=findViewById(R.id.navQueue);
        searchInput=findViewById(R.id.searchInput); playPause=findViewById(R.id.playPause);
        previousBtn=findViewById(R.id.previousBtn); nextBtn=findViewById(R.id.nextBtn); shuffleBtn=findViewById(R.id.shuffleBtn);

        RecyclerView searchList=findViewById(R.id.searchList); searchList.setLayoutManager(new LinearLayoutManager(this));
        searchAdapter=new SearchAdapter(searchItems,x->playQueue(new ArrayList<>(searchItems), Math.max(0,searchItems.indexOf(x)))); searchList.setAdapter(searchAdapter);
        RecyclerView queueList=findViewById(R.id.queueList); queueList.setLayoutManager(new LinearLayoutManager(this));
        queueAdapter=new SearchAdapter(queueItems,x->jumpToQueueItem(Math.max(0,queueItems.indexOf(x)))); queueList.setAdapter(queueAdapter);

        navHome.setOnClickListener(v->tab(0)); navSearch.setOnClickListener(v->tab(1)); navQueue.setOnClickListener(v->tab(2));
        findViewById(R.id.searchBtn).setOnClickListener(v->search());
        findViewById(R.id.logout).setOnClickListener(v->{getSharedPreferences("auth",MODE_PRIVATE).edit().clear().apply();startActivity(new Intent(this,LoginActivity.class));finish();});
        playPause.setOnClickListener(v->toggle());
        previousBtn.setOnClickListener(v->{if(controller!=null&&controller.hasPreviousMediaItem())controller.seekToPreviousMediaItem();});
        nextBtn.setOnClickListener(v->{if(controller!=null&&controller.hasNextMediaItem())controller.seekToNextMediaItem();});
        shuffleBtn.setOnClickListener(v->toggleShuffle());
        findViewById(R.id.miniPlayer).setOnClickListener(v->tab(2));
        requestNotificationPermission(); connectPlayer(); loadBanners(); loadHome();
    }

    private void requestNotificationPermission(){
        if(android.os.Build.VERSION.SDK_INT>=33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS);
    }

    private void connectPlayer(){
        SessionToken token=new SessionToken(this,new ComponentName(this,PlaybackService.class));
        controllerFuture=new MediaController.Builder(this,token).buildAsync();
        controllerFuture.addListener(()->{
            try{
                controller=controllerFuture.get();
                controller.addListener(new Player.Listener(){
                    @Override public void onIsPlayingChanged(boolean isPlaying){runOnUiThread(()->playPause.setText(isPlaying?"Ⅱ":"▶"));}
                    @Override public void onMediaMetadataChanged(MediaMetadata m){runOnUiThread(()->updateNowPlaying(m));}
                    @Override public void onMediaItemTransition(MediaItem item,int reason){runOnUiThread(()->updateQueueStatus());}
                    @Override public void onPlaybackStateChanged(int state){runOnUiThread(()->updateQueueStatus());}
                });
                updateNowPlaying(controller.getMediaMetadata());
                playPause.setText(controller.isPlaying()?"Ⅱ":"▶");
                updateQueueStatus();
            }catch(Exception e){Toast.makeText(this,"Falha ao iniciar o player",Toast.LENGTH_SHORT).show();}
        },ContextCompat.getMainExecutor(this));
    }

    void updateNowPlaying(MediaMetadata m){
        if(m.title!=null)nowTitle.setText(m.title);
        if(m.artist!=null)nowSub.setText(m.artist);
        if(m.artworkUri!=null)Glide.with(this).load(m.artworkUri).into(nowThumb);
    }

    void updateQueueStatus(){
        if(controller==null){queueStatus.setText("Player iniciando...");return;}
        int total=controller.getMediaItemCount(); int current=controller.getCurrentMediaItemIndex();
        queueStatus.setText(total==0?"A fila está vazia.":"Tocando "+(current+1)+" de "+total+(shuffleEnabled?" • Aleatório ativado":""));
    }

    void tab(int selected){
        homeTab.setVisibility(selected==0?View.VISIBLE:View.GONE);
        searchTab.setVisibility(selected==1?View.VISIBLE:View.GONE);
        queueTab.setVisibility(selected==2?View.VISIBLE:View.GONE);
        navHome.setTextColor(getColor(selected==0?R.color.green:R.color.muted));
        navSearch.setTextColor(getColor(selected==1?R.color.green:R.color.muted));
        navQueue.setTextColor(getColor(selected==2?R.color.green:R.color.muted));
        if(selected==2)updateQueueStatus();
    }

    void loadBanners(){new Thread(()->{try{JSONArray a=new JSONObject(Net.get(BuildConfig.PANEL_URL+"/api/banners.php")).optJSONArray("banners");if(a==null)return;runOnUiThread(()->{bannerBox.removeAllViews();for(int i=0;i<a.length();i++){JSONObject b=a.optJSONObject(i);if(b==null)continue;LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(10,10,10,10);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(310),dp(175));cp.setMargins(5,0,5,0);card.setLayoutParams(cp);card.setBackgroundResource(R.drawable.card);ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);card.addView(im,new LinearLayout.LayoutParams(-1,dp(125)));Glide.with(this).load(b.optString("image")).into(im);TextView t=new TextView(this);t.setText(b.optString("title"));t.setTextColor(Color.WHITE);t.setTextSize(17);t.setTypeface(null,1);t.setPadding(8,8,8,0);card.addView(t);bannerBox.addView(card);}});}catch(Exception ignored){}}).start();}

    void loadHome(){homeStatus.setText("Atualizando músicas e artistas...");new Thread(()->{try{JSONObject j=new JSONObject(Net.get(BuildConfig.PANEL_URL+"/api/music/home.php?refresh="+(System.currentTimeMillis()/600000)));JSONArray secs=j.optJSONArray("sections");runOnUiThread(()->renderSections(secs,j.optJSONArray("items"),j.optJSONArray("categories")));}catch(Exception e){runOnUiThread(()->homeStatus.setText("Falha ao carregar a API: "+e.getMessage()));}}).start();}

    void renderSections(JSONArray secs,JSONArray fallback,JSONArray categories){sectionsBox.removeAllViews();addCategoryBar(categories);int made=0;if(secs!=null)for(int i=0;i<secs.length();i++){JSONObject s=secs.optJSONObject(i);if(s==null)continue;JSONArray items=s.optJSONArray("items");if(items==null||items.length()==0)continue;addSection(s.optString("title","Músicas"),items);made++;}if(made==0&&fallback!=null&&fallback.length()>0){addSection("Músicas",fallback);made++;}homeStatus.setText(made>0?"Atualizado automaticamente":"A API automática não retornou músicas agora.");}

    void addCategoryBar(JSONArray categories){
        if(categories==null||categories.length()==0)return;
        TextView h=new TextView(this);h.setText("Explore por categoria");h.setTextColor(Color.WHITE);h.setTextSize(22);h.setTypeface(null,1);h.setPadding(dp(16),dp(20),dp(8),dp(10));sectionsBox.addView(h);
        HorizontalScrollView sv=new HorizontalScrollView(this);sv.setHorizontalScrollBarEnabled(false);
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setPadding(dp(12),0,dp(12),dp(8));sv.addView(row);
        for(int i=0;i<categories.length();i++){String name=categories.optString(i);if(name.isEmpty())continue;TextView chip=new TextView(this);chip.setText(name);chip.setTextColor(Color.WHITE);chip.setTextSize(15);chip.setTypeface(null,1);chip.setGravity(android.view.Gravity.CENTER);chip.setPadding(dp(18),dp(11),dp(18),dp(11));chip.setBackgroundResource(R.drawable.search_bg);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,dp(46));lp.setMargins(dp(4),0,dp(4),0);chip.setLayoutParams(lp);chip.setOnClickListener(v->{tab(1);searchInput.setText(name+" mais tocadas");search();});row.addView(chip);}
        sectionsBox.addView(sv,new LinearLayout.LayoutParams(-1,dp(58)));
    }

    void addSection(String title,JSONArray arr){
        ArrayList<MusicItem> playlist=new ArrayList<>();
        for(int i=0;i<arr.length();i++){JSONObject x=arr.optJSONObject(i);if(x!=null){MusicItem item=parse(x);if(!item.videoId.isEmpty()||!item.id.isEmpty())playlist.add(item);}}
        if(playlist.isEmpty())return;
        LinearLayout heading=new LinearLayout(this);heading.setOrientation(LinearLayout.HORIZONTAL);heading.setGravity(android.view.Gravity.CENTER_VERTICAL);heading.setPadding(dp(16),dp(23),dp(10),dp(10));
        TextView h=new TextView(this);h.setText(title);h.setTextColor(Color.WHITE);h.setTextSize(22);h.setTypeface(null,1);heading.addView(h,new LinearLayout.LayoutParams(0,-2,1));
        Button playAll=new Button(this);playAll.setText("▶ Tocar");playAll.setTextSize(12);playAll.setOnClickListener(v->playQueue(new ArrayList<>(playlist),0));heading.addView(playAll,new LinearLayout.LayoutParams(dp(92),dp(42)));sectionsBox.addView(heading);
        HorizontalScrollView sv=new HorizontalScrollView(this);sv.setHorizontalScrollBarEnabled(false);LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setPadding(dp(9),0,dp(9),0);sv.addView(row);
        int max=Math.min(playlist.size(),24);for(int i=0;i<max;i++){MusicItem item=playlist.get(i);final int index=i;LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(7),dp(4),dp(7),dp(4));ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);card.addView(im,new LinearLayout.LayoutParams(dp(140),dp(140)));Glide.with(this).load(item.thumb).into(im);TextView t=new TextView(this);t.setText(item.title);t.setTextColor(Color.WHITE);t.setTypeface(null,1);t.setMaxLines(1);card.addView(t,new LinearLayout.LayoutParams(dp(140),-2));TextView sub=new TextView(this);sub.setText(item.subtitle);sub.setTextColor(getColor(R.color.muted));sub.setMaxLines(1);card.addView(sub,new LinearLayout.LayoutParams(dp(140),-2));card.setOnClickListener(v->playQueue(new ArrayList<>(playlist),index));row.addView(card,new LinearLayout.LayoutParams(dp(154),dp(205)));}sectionsBox.addView(sv,new LinearLayout.LayoutParams(-1,dp(210)));
    }

    MusicItem parse(JSONObject x){String id=x.optString("id",x.optString("video_id"));return new MusicItem(id,x.optString("type","song"),x.optString("title"),x.optString("subtitle",x.optString("artist")),x.optString("thumbnail"),x.optString("video_id",id));}

    void search(){String q=searchInput.getText().toString().trim();if(q.isEmpty())return;searchStatus.setText("Buscando músicas...");new Thread(()->{try{JSONObject j=new JSONObject(Net.get(BuildConfig.PANEL_URL+"/api/music/search.php?q="+URLEncoder.encode(q,"UTF-8")+"&limit=50"));JSONArray a=j.optJSONArray("items");ArrayList<MusicItem> n=new ArrayList<>();if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null){MusicItem item=parse(x);if(!item.videoId.isEmpty())n.add(item);}}runOnUiThread(()->{searchItems.clear();searchItems.addAll(n);searchAdapter.notifyDataSetChanged();searchStatus.setText(n.size()+" músicas encontradas • toque em uma para tocar todas em sequência");});}catch(Exception e){runOnUiThread(()->searchStatus.setText("Erro: "+e.getMessage()));}}).start();}

    void playQueue(ArrayList<MusicItem> source,int startIndex){
        if(controller==null){Toast.makeText(this,"Player iniciando. Toque novamente.",Toast.LENGTH_SHORT).show();return;}
        if(source.isEmpty())return;
        ArrayList<MusicItem> ordered=new ArrayList<>(source);
        if(shuffleEnabled){MusicItem first=ordered.remove(Math.min(startIndex,ordered.size()-1));Collections.shuffle(ordered);ordered.add(0,first);startIndex=0;}
        queueItems.clear();queueItems.addAll(ordered);queueAdapter.notifyDataSetChanged();
        int generation=queueGeneration.incrementAndGet();
        final int selected=Math.max(0,Math.min(startIndex,ordered.size()-1));
        queueStatus.setText("Preparando fila com "+ordered.size()+" músicas...");
        new Thread(()->{
            ArrayList<MediaItem> resolved=new ArrayList<>();
            for(int i=0;i<ordered.size();i++){
                if(queueGeneration.get()!=generation)return;
                MusicItem x=ordered.get(i);
                try{
                    String id=x.videoId.isEmpty()?x.id:x.videoId;
                    JSONObject src=new JSONObject(Net.get(BuildConfig.PANEL_URL+"/api/music/source.php?id="+URLEncoder.encode(id,"UTF-8")));
                    String url=src.optString("stream_url"); String videoId=src.optString("video_id",id);
                    if(url.isEmpty())url=StreamResolver.resolveAudio(videoId);
                    MediaMetadata metadata=new MediaMetadata.Builder().setTitle(x.title).setArtist(x.subtitle).setArtworkUri(x.thumb.isEmpty()?null:Uri.parse(x.thumb)).build();
                    MediaItem mediaItem=new MediaItem.Builder().setUri(url).setMediaId(x.id).setMediaMetadata(metadata).build();
                    resolved.add(mediaItem);
                    final int count=resolved.size();
                    if(i==selected){
                        ArrayList<MediaItem> initial=new ArrayList<>(resolved);
                        int initialIndex=initial.size()-1;
                        runOnUiThread(()->{if(queueGeneration.get()!=generation)return;controller.setMediaItems(initial,initialIndex,0);controller.prepare();controller.play();updateQueueStatus();});
                    }else if(i>selected){
                        runOnUiThread(()->{if(queueGeneration.get()!=generation)return;controller.addMediaItem(mediaItem);updateQueueStatus();});
                    }
                }catch(Exception ignored){}
                if(resolved.size()>=30)break;
            }
            runOnUiThread(()->{if(queueGeneration.get()==generation){queueStatus.setText(controller.getMediaItemCount()+" músicas prontas na fila"+(shuffleEnabled?" • Aleatório":""));}});
        }).start();
    }

    void jumpToQueueItem(int index){if(controller!=null&&index>=0&&index<controller.getMediaItemCount()){controller.seekToDefaultPosition(index);controller.play();}}
    void toggleShuffle(){shuffleEnabled=!shuffleEnabled;shuffleBtn.setText(shuffleEnabled?"🔀 ON":"🔀");shuffleBtn.setAlpha(shuffleEnabled?1f:.65f);updateQueueStatus();}
    void toggle(){if(controller==null)return;if(controller.isPlaying())controller.pause();else controller.play();}
    int dp(int v){return (int)(v*getResources().getDisplayMetrics().density);}

    @Override protected void onDestroy(){if(controllerFuture!=null)MediaController.releaseFuture(controllerFuture);super.onDestroy();}
}
