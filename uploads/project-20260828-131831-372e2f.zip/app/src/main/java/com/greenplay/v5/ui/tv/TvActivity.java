package com.greenplay.v5.ui.tv;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.exoplayer.ExoPlayer;
import com.greenplay.v5.core.player.GreenPlayerFactory;
import com.greenplay.v5.core.player.StreamInspector;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.greenplay.v5.core.network.StreamUrlFactory;
import com.greenplay.v5.core.session.SessionStore;
import com.greenplay.v5.data.model.tv.TvCategory;
import com.greenplay.v5.data.model.tv.TvChannel;
import com.greenplay.v5.data.model.tv.TvEpg;
import com.greenplay.v5.data.repository.TvRepository;
import com.greenplay.v5.databinding.ActivityTvBinding;
import com.greenplay.v5.ui.player.PlayerActivity;
import java.util.ArrayList;
import java.util.List;
import com.squareup.picasso.Picasso;

public final class TvActivity extends AppCompatActivity {
    private enum Mode { ALL, FAVORITES, RECENTS }

    private ActivityTvBinding b;
    private SessionStore session;
    private TvRepository repo;
    private TvCategoryAdapter categories;
    private TvChannelAdapter channels;
    private TvHistoryStore history;
    private ExoPlayer previewPlayer;
    private TvChannel current;
    private Mode mode = Mode.ALL;
    private String currentCategoryId = "";
    private String currentCategoryName = "TODOS";
    private final List<TvChannel> allChannels = new ArrayList<>();
    private final Handler previewHandler = new Handler(Looper.getMainLooper());
    private Runnable pendingPreview;
    private int playbackAttempt = 0;
    private int previewGeneration = 0;
    private long returnFocusChannelId = -1L;
    private boolean returningFromFullscreen = false;
    private boolean fullscreen = false;
    private ViewGroup previewOriginalParent;
    private ViewGroup.LayoutParams previewOriginalLayoutParams;
    private int previewOriginalIndex = -1;
    // Fullscreen do V5 segue o comportamento visual da referência antiga, mas com implementação nova:
    // o MESMO PlayerView é ampliado, OK/toque abre uma lista lateral e somente VOLTAR sai do fullscreen.
    private android.widget.FrameLayout fullscreenMenuLayer;
    private boolean fullscreenMenuVisible = false;
    private androidx.recyclerview.widget.RecyclerView fullscreenChannelList;
    private TvChannelAdapter fullscreenChannels;
    private android.widget.EditText fullscreenSearch;
    private android.widget.FrameLayout fullscreenLayer;
    private android.widget.LinearLayout fullscreenInfoPanel;
    private android.widget.ImageView fullscreenLogo;
    private android.widget.TextView fullscreenNumber;
    private android.widget.TextView fullscreenName;
    private android.widget.TextView fullscreenNow;
    private android.widget.TextView fullscreenNext;
    private android.widget.ProgressBar fullscreenProgress;
    private String fullscreenMode = "all";

    @Override protected void onCreate(Bundle state){
        super.onCreate(state);
        b=ActivityTvBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        session=new SessionStore(this);
        if(!session.isLogged()||session.host().trim().isEmpty()){finish();return;}
        repo=new TvRepository(session.host(),session.user(),session.pass());
        history=new TvHistoryStore(this);
        setupLists(); setupSearch(); setupPlayer(); bindTopNav(); bindModes(); selectMode(Mode.ALL); loadChannels("","TODOS");
    }

    private void setupLists(){
        channels=new TvChannelAdapter(new TvChannelAdapter.Listener(){
            @Override public void onFocus(TvChannel channel){
                // Apenas move o foco. Trocar de item com o D-pad NÃO abre nem troca o canal.
                if(current!=null && current.id==channel.id) b.previewStatus.setText("OK: tela cheia");
                else b.previewStatus.setText("OK: selecionar canal");
            }
            @Override public void onOpen(TvChannel channel){
                // Comportamento de TV: 1º OK seleciona/toca no preview; 2º OK abre tela cheia.
                if(current==null || current.id!=channel.id){
                    history.markRecent(channel.id);
                    returnFocusChannelId=channel.id;
                    showChannel(channel,true);
                    return;
                }
                history.markRecent(channel.id);
                returnFocusChannelId=channel.id;
                openFull(channel);
            }
            @Override public void onFavorite(TvChannel channel){history.toggleFavorite(channel.id);channels.refreshFavorite(channel.id);if(mode==Mode.FAVORITES)applyMode();}
            @Override public boolean isFavorite(TvChannel channel){return history.isFavorite(channel.id);}
        });
        b.channelList.setLayoutManager(new LinearLayoutManager(this));
        b.channelList.setAdapter(channels);
    }

    private void setupSearch(){
        b.search.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){channels.filter(s.toString());updateTotal();}
            public void afterTextChanged(Editable e){}
        });
    }

    private void setupPlayer(){
        previewPlayer=GreenPlayerFactory.create(this);
        b.previewPlayer.setPlayer(previewPlayer);
        b.previewPlayer.setUseController(false);
        b.previewPlayer.setFocusable(true);
        b.previewPlayer.setClickable(true);
        b.previewPlayer.setOnClickListener(v -> {
            if(fullscreen){
                // Igual à referência: toque/OK em tela cheia abre/fecha a lista lateral; não reduz o vídeo.
                toggleFullscreenMenu();
                return;
            }
            if(current!=null){
                history.markRecent(current.id);
                returnFocusChannelId=current.id;
                openFull(current);
            }
        });
        b.previewPlayer.setOnKeyListener((v,keyCode,event) -> {
            if(event.getAction()==KeyEvent.ACTION_UP && (keyCode==KeyEvent.KEYCODE_DPAD_CENTER || keyCode==KeyEvent.KEYCODE_ENTER)){
                if(fullscreen){
                    toggleFullscreenMenu();
                    return true;
                }
                if(current!=null){
                    history.markRecent(current.id);
                    returnFocusChannelId=current.id;
                    openFull(current);
                    return true;
                }
            }
            return false;
        });
        previewPlayer.addListener(new Player.Listener(){
            @Override public void onPlaybackStateChanged(int playbackState){
                if(playbackState==Player.STATE_BUFFERING)b.previewStatus.setText("Carregando canal...");
                else if(playbackState==Player.STATE_READY)b.previewStatus.setText("Canal selecionado • OK novamente: tela cheia");
            }
            @Override public void onPlayerError(@NonNull PlaybackException error){
                if(current!=null && playbackAttempt < 1){
                    playbackAttempt++;
                    String primaryExt = current.extension == null ? "" : current.extension.trim();
                    String alt = "m3u8".equalsIgnoreCase(primaryExt)
                            ? StreamUrlFactory.liveTs(session.host(),session.user(),session.pass(),current.id)
                            : StreamUrlFactory.liveHls(session.host(),session.user(),session.pass(),current.id);
                    b.previewStatus.setText("Alternando formato...");
                    playResolvedUrl(alt, alt.toLowerCase(java.util.Locale.US).contains(".m3u8") ? "hls" : "ts");
                }else{
                    b.previewStatus.setText("ERRO "+error.getErrorCodeName()+" • "+shortMessage(error));
                }
            }
        });
    }

    private void bindTopNav(){
        b.navTv.setOnClickListener(v->b.search.requestFocus());
        b.navFootball.setOnClickListener(v->Toast.makeText(this,"Futebol será aberto no módulo próprio",Toast.LENGTH_SHORT).show());
        b.navMovies.setOnClickListener(v->Toast.makeText(this,"Filmes entra depois da TV",Toast.LENGTH_SHORT).show());
        b.navSeries.setOnClickListener(v->Toast.makeText(this,"Séries entra depois de Filmes",Toast.LENGTH_SHORT).show());
        b.navKids.setOnClickListener(v->Toast.makeText(this,"Kids será isolado",Toast.LENGTH_SHORT).show());
        b.navAnime.setOnClickListener(v->Toast.makeText(this,"Anime será isolado",Toast.LENGTH_SHORT).show());
        b.navHot.setOnClickListener(v->Toast.makeText(this,"HOT será protegido por PIN",Toast.LENGTH_SHORT).show());
    }

    private void bindModes(){
        b.filterAll.setOnClickListener(v->{selectMode(Mode.ALL); applyMode();});
        b.filterFavorites.setOnClickListener(v->{selectMode(Mode.FAVORITES); ensureAllThenApply();});
        b.filterRecents.setOnClickListener(v->{selectMode(Mode.RECENTS); ensureAllThenApply();});
    }

    private void selectMode(Mode m){
        mode=m;
        b.filterAll.setSelected(m==Mode.ALL);
        b.filterFavorites.setSelected(m==Mode.FAVORITES);
        b.filterRecents.setSelected(m==Mode.RECENTS);
    }

    private void loadChannels(String categoryId,String categoryName){
        currentCategoryId=categoryId==null?"":categoryId;
        currentCategoryName=categoryName==null?"TODOS":categoryName;
        b.loading.setVisibility(View.VISIBLE);b.error.setText("");
        repo.channels(currentCategoryId,new TvRepository.ChannelsResult(){
            @Override public void success(List<TvChannel> rows){runOnUiThread(()->{
                b.loading.setVisibility(View.GONE);
                if(currentCategoryId.isEmpty()){allChannels.clear();allChannels.addAll(rows);}
                channels.setSectionLabel(currentCategoryName.equals("TODOS")?"TV AO VIVO":"CH: "+currentCategoryName);
                channels.setRows(rows);
                updateTotal();
                TvChannel f=channels.first();if(f!=null)showChannel(f,true);else stopPreview();
            });}
            @Override public void error(String message){runOnUiThread(()->{b.loading.setVisibility(View.GONE);b.error.setText(message);channels.setRows(null);updateTotal();stopPreview();});}
        });
    }

    private void ensureAllThenApply(){
        if(!allChannels.isEmpty()){applyMode();return;}
        b.loading.setVisibility(View.VISIBLE);
        repo.channels("",new TvRepository.ChannelsResult(){
            @Override public void success(List<TvChannel> rows){runOnUiThread(()->{b.loading.setVisibility(View.GONE);allChannels.clear();allChannels.addAll(rows);applyMode();});}
            @Override public void error(String message){runOnUiThread(()->{b.loading.setVisibility(View.GONE);b.error.setText(message);});}
        });
    }

    private void applyMode(){
        b.error.setText("");
        if(mode==Mode.FAVORITES){
            channels.setSectionLabel("FAVORITOS");
            channels.setRows(history.filterFavorites(allChannels));
        }else if(mode==Mode.RECENTS){
            channels.setSectionLabel("RECENTES");
            channels.setRows(history.filterRecents(allChannels));
        }else{
            if(currentCategoryId.isEmpty() && !allChannels.isEmpty()){
                channels.setSectionLabel("TV AO VIVO");channels.setRows(allChannels);
            }
        }
        updateTotal();
        TvChannel f=channels.first();if(f!=null)showChannel(f,true);else stopPreview();
    }

    private void updateTotal(){ b.total.setText(channels.getItemCount()+" canais"); }

    private void showChannel(TvChannel c,boolean autoplay){
        current=c;
        b.previewName.setText(c.name);
        int p = channels.positionOf(c.id);
        b.previewChannelNumber.setText(p >= 0 ? String.valueOf(p + 1) : "");
        b.previewLogo.setImageDrawable(null);
        if(c.logo!=null && !c.logo.trim().isEmpty()) Picasso.get().load(c.logo).fit().centerInside().noFade().into(b.previewLogo);
        syncFullscreenChannelHeader(c, p);
        b.epgNow.setText("Carregando...");
        b.epgNext.setText("Carregando...");
        b.epgProgress.setProgress(0);
        repo.epg(c.id,new TvRepository.EpgResult(){
            @Override public void success(TvEpg epg){runOnUiThread(()->{
                if(current!=c)return;
                b.epgNow.setText((epg.nowTime.isEmpty()?"":epg.nowTime+"  •  ")+epg.nowTitle);
                b.epgNext.setText((epg.nextTime.isEmpty()?"":epg.nextTime+"  •  ")+epg.nextTitle);
                int progress = epgProgress(epg);
                b.epgProgress.setProgress(progress);
                syncFullscreenEpg(epg, progress);
            });}
            @Override public void error(String m){}
        });
        if(autoplay){
            if(pendingPreview!=null)previewHandler.removeCallbacks(pendingPreview);
            playPreview(c);
        }
    }

    private int epgProgress(TvEpg epg){
        if(epg.nowStart<=0||epg.nowStop<=epg.nowStart)return 0;
        long now=System.currentTimeMillis()/1000L;
        long done=Math.max(0,Math.min(epg.nowStop-epg.nowStart,now-epg.nowStart));
        return (int)((done*100L)/(epg.nowStop-epg.nowStart));
    }

    private void playPreview(TvChannel c){
        playbackAttempt=0;
        previewGeneration++;
        String ext=c.extension==null?"":c.extension.trim();
        boolean hls="m3u8".equalsIgnoreCase(ext);
        String first=hls
                ? StreamUrlFactory.liveHls(session.host(),session.user(),session.pass(),c.id)
                : StreamUrlFactory.liveTs(session.host(),session.user(),session.pass(),c.id);
        b.previewStatus.setText("Carregando canal...");
        playResolvedUrl(first, hls ? "hls" : "ts");
    }

    private void inspectAndPlay(TvChannel c, String url, int generation){
        StreamInspector.inspect(url,new StreamInspector.Callback(){
            @Override public void success(StreamInspector.Result r){runOnUiThread(()->{
                if(current!=c || generation!=previewGeneration)return;
                b.previewStatus.setText("HTTP "+r.httpCode+" • "+(r.detected==null?"AUTO":r.detected.toUpperCase(java.util.Locale.US))+
                        (r.contentType.isEmpty()?"":" • "+trimType(r.contentType)));
                if(r.httpCode<200 || r.httpCode>=300){
                    if(playbackAttempt<1){playbackAttempt++;inspectAndPlay(c,StreamUrlFactory.liveHls(session.host(),session.user(),session.pass(),c.id),generation);}
                    else b.previewStatus.setText("STREAM HTTP "+r.httpCode);
                    return;
                }
                playResolvedUrl(r.finalUrl,r.detected);
            });}
            @Override public void error(String message){runOnUiThread(()->{
                if(current!=c || generation!=previewGeneration)return;
                b.previewStatus.setText("FALHA STREAM • "+shortText(message));
                if(playbackAttempt<1){playbackAttempt++;inspectAndPlay(c,StreamUrlFactory.liveHls(session.host(),session.user(),session.pass(),c.id),generation);}
            });}
        });
    }

    private void playResolvedUrl(String url,String detected){
        try{
            MediaItem.Builder item=new MediaItem.Builder().setUri(url);
            if("hls".equalsIgnoreCase(detected)) item.setMimeType(MimeTypes.APPLICATION_M3U8);
            else if("ts".equalsIgnoreCase(detected)) item.setMimeType(MimeTypes.VIDEO_MP2T);
            previewPlayer.stop();
            previewPlayer.clearMediaItems();
            previewPlayer.setMediaItem(item.build());
            previewPlayer.setPlayWhenReady(true);
            previewPlayer.prepare();
        }catch(Exception e){b.previewStatus.setText("ERRO AO ABRIR • "+shortMessage(e));}
    }

    private static String trimType(String t){
        String x=t==null?"":t;int p=x.indexOf(';');if(p>0)x=x.substring(0,p);return x.length()>28?x.substring(0,28):x;
    }
    private static String shortText(String m){if(m==null||m.trim().isEmpty())return "sem detalhe";m=m.replace('\n',' ').replace('\r',' ').trim();return m.length()>70?m.substring(0,70):m;}

    private static String shortMessage(Throwable e){
        String m=e==null?"sem detalhe":e.getMessage();
        if(m==null||m.trim().isEmpty())m=e==null?"sem detalhe":e.getClass().getSimpleName();
        m=m.replace('\n',' ').replace('\r',' ').trim();
        return m.length()>70?m.substring(0,70):m;
    }

    private void stopPreview(){
        if(previewPlayer!=null){previewPlayer.stop();previewPlayer.clearMediaItems();}
        b.previewName.setText("Selecione um canal");b.previewChannelNumber.setText("");b.previewLogo.setImageDrawable(null);b.epgNow.setText("Sem informação");b.epgNext.setText("Sem informação");b.epgProgress.setProgress(0);b.previewStatus.setText("OK: selecionar canal");
    }

    private void openFull(TvChannel c){
        if(fullscreen || c==null)return;
        ViewGroup parent=(ViewGroup)b.previewPlayer.getParent();
        if(parent==null)return;
        fullscreen=true;
        fullscreenMenuVisible=false;
        previewOriginalParent=parent;
        previewOriginalIndex=parent.indexOfChild(b.previewPlayer);
        previewOriginalLayoutParams=b.previewPlayer.getLayoutParams();
        parent.removeView(b.previewPlayer);

        // Mesmo PlayerView e mesmo stream: apenas mudamos a hierarquia visual.
        ViewGroup root=findViewById(android.R.id.content);
        fullscreenLayer=new android.widget.FrameLayout(this);
        fullscreenLayer.setBackgroundColor(android.graphics.Color.BLACK);
        root.addView(fullscreenLayer,new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));

        b.previewPlayer.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FILL);
        fullscreenLayer.addView(b.previewPlayer,new android.widget.FrameLayout.LayoutParams(-1,-1));
        buildFullscreenInfoPanel();
        buildFullscreenMenu();
        fullscreenLayer.bringToFront();
        b.previewPlayer.requestFocus();
        if(previewPlayer!=null)previewPlayer.play();
    }

    private void buildFullscreenInfoPanel(){
        if(fullscreenLayer==null)return;
        fullscreenInfoPanel=new android.widget.LinearLayout(this);
        fullscreenInfoPanel.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        fullscreenInfoPanel.setGravity(android.view.Gravity.CENTER_VERTICAL);
        fullscreenInfoPanel.setPadding(dp(24),dp(10),dp(24),dp(10));
        android.graphics.drawable.GradientDrawable bg=new android.graphics.drawable.GradientDrawable();
        bg.setColor(0xE80A0F0C);
        fullscreenInfoPanel.setBackground(bg);

        fullscreenLogo=new android.widget.ImageView(this);
        fullscreenLogo.setScaleType(android.widget.ImageView.ScaleType.CENTER_INSIDE);
        fullscreenInfoPanel.addView(fullscreenLogo,new android.widget.LinearLayout.LayoutParams(dp(90),dp(92)));

        android.widget.LinearLayout nameCol=new android.widget.LinearLayout(this);
        nameCol.setOrientation(android.widget.LinearLayout.VERTICAL);
        nameCol.setGravity(android.view.Gravity.CENTER_VERTICAL);
        fullscreenNumber=new android.widget.TextView(this);
        fullscreenNumber.setTextColor(0xFF29E76F); fullscreenNumber.setTextSize(20); fullscreenNumber.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);
        fullscreenName=new android.widget.TextView(this);
        fullscreenName.setTextColor(android.graphics.Color.WHITE); fullscreenName.setTextSize(20); fullscreenName.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD); fullscreenName.setMaxLines(1);
        android.widget.LinearLayout titleRow=new android.widget.LinearLayout(this); titleRow.setOrientation(android.widget.LinearLayout.HORIZONTAL); titleRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
        titleRow.addView(fullscreenNumber,new android.widget.LinearLayout.LayoutParams(dp(58),dp(38)));
        titleRow.addView(fullscreenName,new android.widget.LinearLayout.LayoutParams(0,dp(38),1));
        nameCol.addView(titleRow,new android.widget.LinearLayout.LayoutParams(-1,dp(42)));
        android.widget.TextView live=new android.widget.TextView(this); live.setText("• AO VIVO"); live.setTextColor(0xFFFF5A65); live.setTextSize(10); live.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);
        nameCol.addView(live,new android.widget.LinearLayout.LayoutParams(-1,dp(26)));
        fullscreenInfoPanel.addView(nameCol,new android.widget.LinearLayout.LayoutParams(0,-1,1.05f));

        android.widget.LinearLayout epgCol=new android.widget.LinearLayout(this);
        epgCol.setOrientation(android.widget.LinearLayout.VERTICAL); epgCol.setGravity(android.view.Gravity.CENTER_VERTICAL); epgCol.setPadding(dp(18),0,0,0);
        fullscreenNow=new android.widget.TextView(this); fullscreenNow.setTextColor(android.graphics.Color.WHITE); fullscreenNow.setTextSize(13); fullscreenNow.setMaxLines(1); fullscreenNow.setEllipsize(android.text.TextUtils.TruncateAt.END);
        fullscreenNext=new android.widget.TextView(this); fullscreenNext.setTextColor(0xFFD5DDD7); fullscreenNext.setTextSize(12); fullscreenNext.setMaxLines(1); fullscreenNext.setEllipsize(android.text.TextUtils.TruncateAt.END);
        epgCol.addView(fullscreenNow,new android.widget.LinearLayout.LayoutParams(-1,dp(32)));
        epgCol.addView(fullscreenNext,new android.widget.LinearLayout.LayoutParams(-1,dp(30)));
        fullscreenProgress=new android.widget.ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); fullscreenProgress.setMax(100); fullscreenProgress.setProgressTintList(android.content.res.ColorStateList.valueOf(0xFF29E76F)); fullscreenProgress.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF4B5550));
        android.widget.LinearLayout.LayoutParams pp=new android.widget.LinearLayout.LayoutParams(-1,dp(5)); pp.topMargin=dp(4); epgCol.addView(fullscreenProgress,pp);
        android.widget.TextView help=new android.widget.TextView(this); help.setText("OK: canais   •   VOLTAR: sair da tela cheia"); help.setTextColor(0xFF9AA59E); help.setTextSize(9); help.setGravity(android.view.Gravity.END|android.view.Gravity.CENTER_VERTICAL);
        epgCol.addView(help,new android.widget.LinearLayout.LayoutParams(-1,dp(26)));
        fullscreenInfoPanel.addView(epgCol,new android.widget.LinearLayout.LayoutParams(0,-1,2.3f));

        android.widget.FrameLayout.LayoutParams lp=new android.widget.FrameLayout.LayoutParams(-1,dp(150),android.view.Gravity.BOTTOM);
        fullscreenLayer.addView(fullscreenInfoPanel,lp);
        int p=current==null?-1:channels.positionOf(current.id);
        syncFullscreenChannelHeader(current,p);
    }

    private void syncFullscreenChannelHeader(TvChannel c,int pos){
        if(c==null)return;
        if(fullscreenName!=null)fullscreenName.setText(c.name==null?"Canal":c.name);
        if(fullscreenNumber!=null)fullscreenNumber.setText(pos>=0?String.valueOf(pos+1):"");
        if(fullscreenLogo!=null){
            fullscreenLogo.setImageDrawable(null);
            if(c.logo!=null && !c.logo.trim().isEmpty())Picasso.get().load(c.logo).fit().centerInside().noFade().into(fullscreenLogo);
        }
    }

    private void syncFullscreenEpg(TvEpg epg,int progress){
        if(epg==null)return;
        if(fullscreenNow!=null)fullscreenNow.setText("Atual: "+(epg.nowTime.isEmpty()?"":epg.nowTime+"  •  ")+epg.nowTitle);
        if(fullscreenNext!=null)fullscreenNext.setText("Próximo: "+(epg.nextTime.isEmpty()?"":epg.nextTime+"  •  ")+epg.nextTitle);
        if(fullscreenProgress!=null)fullscreenProgress.setProgress(progress);
    }

    private void buildFullscreenMenu(){
        if(fullscreenLayer==null)return;
        fullscreenMenuLayer=new android.widget.FrameLayout(this);
        fullscreenMenuLayer.setBackgroundColor(0x00000000);
        fullscreenMenuLayer.setVisibility(View.GONE);

        android.widget.LinearLayout menu=new android.widget.LinearLayout(this);
        menu.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        android.graphics.drawable.GradientDrawable menuBg=new android.graphics.drawable.GradientDrawable(); menuBg.setColor(0xF20A100D); menu.setBackground(menuBg);

        android.widget.LinearLayout rail=new android.widget.LinearLayout(this); rail.setOrientation(android.widget.LinearLayout.VERTICAL); rail.setGravity(android.view.Gravity.TOP|android.view.Gravity.CENTER_HORIZONTAL); rail.setPadding(0,dp(18),0,dp(10)); rail.setBackgroundColor(0xEE060A08);
        android.widget.TextView searchIcon=fullscreenRail("⌕");
        android.widget.TextView recentIcon=fullscreenRail("◷");
        android.widget.TextView favIcon=fullscreenRail("☆");
        android.widget.TextView allIcon=fullscreenRail("☷");
        rail.addView(searchIcon,new android.widget.LinearLayout.LayoutParams(-1,dp(58)));
        rail.addView(recentIcon,new android.widget.LinearLayout.LayoutParams(-1,dp(58)));
        rail.addView(favIcon,new android.widget.LinearLayout.LayoutParams(-1,dp(58)));
        rail.addView(allIcon,new android.widget.LinearLayout.LayoutParams(-1,dp(58)));
        menu.addView(rail,new android.widget.LinearLayout.LayoutParams(dp(62),-1));

        android.widget.LinearLayout content=new android.widget.LinearLayout(this); content.setOrientation(android.widget.LinearLayout.VERTICAL); content.setPadding(dp(14),dp(12),dp(10),dp(10));
        android.widget.TextView title=new android.widget.TextView(this); title.setText("Lista de canais"); title.setTextColor(android.graphics.Color.WHITE); title.setTextSize(16); title.setGravity(android.view.Gravity.CENTER_VERTICAL);
        content.addView(title,new android.widget.LinearLayout.LayoutParams(-1,dp(44)));
        View sep=new View(this); sep.setBackgroundColor(0xFF506157); content.addView(sep,new android.widget.LinearLayout.LayoutParams(-1,dp(1)));

        fullscreenSearch=new android.widget.EditText(this); fullscreenSearch.setSingleLine(true); fullscreenSearch.setHint("Pesquisar canal..."); fullscreenSearch.setHintTextColor(0xFF87938B); fullscreenSearch.setTextColor(android.graphics.Color.WHITE); fullscreenSearch.setTextSize(11); fullscreenSearch.setVisibility(View.GONE);
        android.graphics.drawable.GradientDrawable sBg=new android.graphics.drawable.GradientDrawable(); sBg.setColor(0xFF151D18); sBg.setCornerRadius(dp(8)); sBg.setStroke(dp(1),0xFF30483A); fullscreenSearch.setBackground(sBg); fullscreenSearch.setPadding(dp(12),0,dp(12),0);
        android.widget.LinearLayout.LayoutParams slp=new android.widget.LinearLayout.LayoutParams(-1,dp(42)); slp.topMargin=dp(8); slp.bottomMargin=dp(6); content.addView(fullscreenSearch,slp);

        fullscreenChannelList=new androidx.recyclerview.widget.RecyclerView(this); fullscreenChannelList.setLayoutManager(new androidx.recyclerview.widget.LinearLayoutManager(this));
        fullscreenChannels=new TvChannelAdapter(new TvChannelAdapter.Listener(){
            @Override public void onFocus(TvChannel channel){}
            @Override public void onOpen(TvChannel channel){
                if(channel==null)return;
                history.markRecent(channel.id); returnFocusChannelId=channel.id;
                if(current==null || current.id!=channel.id)showChannel(channel,true);
                hideFullscreenMenu();
            }
            @Override public void onFavorite(TvChannel channel){history.toggleFavorite(channel.id);fullscreenChannels.refreshFavorite(channel.id);channels.refreshFavorite(channel.id);}
            @Override public boolean isFavorite(TvChannel channel){return history.isFavorite(channel.id);}
        });
        fullscreenChannelList.setAdapter(fullscreenChannels); content.addView(fullscreenChannelList,new android.widget.LinearLayout.LayoutParams(-1,0,1));
        android.widget.TextView foot=new android.widget.TextView(this); foot.setText("☰   Pressione [OK] para assistir"); foot.setTextColor(0xFFD3DDD6); foot.setTextSize(10); foot.setGravity(android.view.Gravity.CENTER_VERTICAL); content.addView(foot,new android.widget.LinearLayout.LayoutParams(-1,dp(42)));
        menu.addView(content,new android.widget.LinearLayout.LayoutParams(0,-1,1));

        fullscreenMenuLayer.addView(menu,new android.widget.FrameLayout.LayoutParams(dp(430),-1,android.view.Gravity.START));
        fullscreenLayer.addView(fullscreenMenuLayer,new android.widget.FrameLayout.LayoutParams(-1,-1));

        searchIcon.setOnClickListener(v->{fullscreenSearch.setVisibility(View.VISIBLE);fullscreenSearch.requestFocus();});
        recentIcon.setOnClickListener(v->{fullscreenMode="recent";refreshFullscreenRows();});
        favIcon.setOnClickListener(v->{fullscreenMode="fav";refreshFullscreenRows();});
        allIcon.setOnClickListener(v->{fullscreenMode="all";refreshFullscreenRows();});
        fullscreenSearch.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int before,int count){refreshFullscreenRows();} public void afterTextChanged(Editable e){}});
        refreshFullscreenRows();
    }

    private android.widget.TextView fullscreenRail(String text){
        android.widget.TextView t=new android.widget.TextView(this); t.setText(text); t.setTextColor(android.graphics.Color.WHITE); t.setTextSize(24); t.setGravity(android.view.Gravity.CENTER); t.setFocusable(true); t.setClickable(true);
        t.setOnFocusChangeListener((v,has)->{((android.widget.TextView)v).setTextColor(has?0xFF29E76F:android.graphics.Color.WHITE); v.setBackgroundColor(has?0x3329E76F:0x00000000);});
        return t;
    }

    private void refreshFullscreenRows(){
        if(fullscreenChannels==null)return;
        List<TvChannel> base;
        if("fav".equals(fullscreenMode))base=history.filterFavorites(allChannels);
        else if("recent".equals(fullscreenMode))base=history.filterRecents(allChannels);
        else base=new ArrayList<>(allChannels);
        fullscreenChannels.setRows(base);
        if(fullscreenSearch!=null)fullscreenChannels.filter(fullscreenSearch.getText().toString());
    }

    private android.widget.TextView fullscreenFilter(String text,boolean selected){
        android.widget.TextView t=new android.widget.TextView(this);
        t.setText(text);t.setTextSize(11);t.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);
        t.setGravity(android.view.Gravity.CENTER);t.setFocusable(true);t.setClickable(true);
        styleFullscreenFilter(t,selected);return t;
    }
    private void styleFullscreenFilter(android.widget.TextView t,boolean selected){
        android.graphics.drawable.GradientDrawable bg=new android.graphics.drawable.GradientDrawable();
        bg.setCornerRadius(dp(20));
        if(selected){bg.setColor(0xFF29E76F);t.setTextColor(android.graphics.Color.BLACK);}else{bg.setColor(0x33131C17);bg.setStroke(dp(1),0xFF294134);t.setTextColor(android.graphics.Color.WHITE);}
        t.setBackground(bg);
    }
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}

    private void toggleFullscreenMenu(){
        if(!fullscreen)return;
        if(fullscreenMenuVisible)hideFullscreenMenu();else showFullscreenMenu();
    }
    private void showFullscreenMenu(){
        if(fullscreenMenuLayer==null)return;
        fullscreenMenuVisible=true;
        if(fullscreenInfoPanel!=null)fullscreenInfoPanel.setVisibility(View.GONE);
        refreshFullscreenRows();
        fullscreenMenuLayer.setVisibility(View.VISIBLE);
        fullscreenMenuLayer.bringToFront();
        if(fullscreenChannelList!=null)fullscreenChannelList.requestFocus();
    }
    private void hideFullscreenMenu(){
        fullscreenMenuVisible=false;
        if(fullscreenMenuLayer!=null)fullscreenMenuLayer.setVisibility(View.GONE);
        if(fullscreenInfoPanel!=null){fullscreenInfoPanel.setVisibility(View.VISIBLE);fullscreenInfoPanel.bringToFront();}
        b.previewPlayer.requestFocus();
    }

    private void exitFullscreen(){
        if(!fullscreen)return;
        if(fullscreenMenuVisible){hideFullscreenMenu();return;}
        fullscreen=false;
        if(fullscreenLayer!=null){
            ViewGroup currentParent=(ViewGroup)b.previewPlayer.getParent();
            if(currentParent!=null)currentParent.removeView(b.previewPlayer);
            ViewGroup layerParent=(ViewGroup)fullscreenLayer.getParent();
            if(layerParent!=null)layerParent.removeView(fullscreenLayer);
        }
        fullscreenLayer=null; fullscreenMenuLayer=null; fullscreenInfoPanel=null; fullscreenChannelList=null; fullscreenChannels=null; fullscreenSearch=null;
        fullscreenLogo=null; fullscreenNumber=null; fullscreenName=null; fullscreenNow=null; fullscreenNext=null; fullscreenProgress=null;
        if(previewOriginalParent!=null){
            int index=Math.max(0,Math.min(previewOriginalIndex,previewOriginalParent.getChildCount()));
            previewOriginalParent.addView(b.previewPlayer,index,previewOriginalLayoutParams);
        }
        b.previewPlayer.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FILL);
        if(previewPlayer!=null)previewPlayer.play();
        b.channelList.postDelayed(this::restoreChannelFocus,80);
    }

    @Override public boolean onKeyDown(int keyCode,KeyEvent event){
        if(keyCode==KeyEvent.KEYCODE_BACK && fullscreen){
            if(fullscreenMenuVisible){hideFullscreenMenu();return true;}
            exitFullscreen();return true;
        }
        if(keyCode==KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE&&current!=null){playPreview(current);return true;}
        return super.onKeyDown(keyCode,event);
    }
    @Override protected void onStop(){super.onStop();if(previewPlayer!=null)previewPlayer.pause();}
    @Override protected void onStart(){
        super.onStart();
        if(previewPlayer!=null&&current!=null&&previewPlayer.getMediaItemCount()>0)previewPlayer.play();
    }
    @Override protected void onResume(){
        super.onResume();
        if(returningFromFullscreen){
            returningFromFullscreen=false;
            b.channelList.postDelayed(this::restoreChannelFocus,160);
        }
    }
    private void restoreChannelFocus(){
        long id=returnFocusChannelId>0?returnFocusChannelId:(current==null?-1L:current.id);
        int pos=channels.positionOf(id);
        if(pos<0)return;
        b.channelList.scrollToPosition(pos);
        b.channelList.postDelayed(()->{
            androidx.recyclerview.widget.RecyclerView.ViewHolder vh=b.channelList.findViewHolderForAdapterPosition(pos);
            if(vh!=null)vh.itemView.requestFocus();
        },80);
    }
    @Override protected void onDestroy(){if(pendingPreview!=null)previewHandler.removeCallbacks(pendingPreview);if(previewPlayer!=null)previewPlayer.release();super.onDestroy();}
}
