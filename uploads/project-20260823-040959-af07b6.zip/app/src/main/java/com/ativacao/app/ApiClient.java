package com.ativacao.app;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class ApiClient {
    static final ExecutorService IO = Executors.newFixedThreadPool(4);

    interface Callback<T> { void ok(T value); void error(String message); }

    static class Item {
        long id;
        String name = "";
        String logo = "";
        String backdrop = "";
        String group = "";
        String synopsis = "";
        String type = "";
        String format = "auto";
        String seriesTitle = "";
        int year = 0;
        int episodeCount = 0;
        int seasonCount = 0;
        int seasonNumber = 0;
        int episodeNumber = 0;
    }

    static class HomeData {
        String name = "Dubai Play";
        int liveCount;
        int movieCount;
        int seriesCount;
        Item hero;
        final List<Item> live = new ArrayList<>();
        final List<Item> movies = new ArrayList<>();
        final List<Item> series = new ArrayList<>();
    }

    static class CatalogPage {
        int page = 1;
        int pages = 1;
        int total = 0;
        final List<Item> items = new ArrayList<>();
        final List<String> categories = new ArrayList<>();
    }

    static class SeriesData {
        String title = "";
        String logo = "";
        String backdrop = "";
        String synopsis = "";
        String group = "";
        int year = 0;
        final List<Season> seasons = new ArrayList<>();
    }

    static class Season {
        int number;
        final List<Item> episodes = new ArrayList<>();
    }

    static class EpgInfo {
        String nowTitle = "";
        String nowStart = "";
        String nowStop = "";
        String nextTitle = "";
        String nextStart = "";
    }

    static class Section {
        String title = "";
        String subtitle = "";
        String type = "live";
        String category = "";
        String smart = "";
        String action = "catalog";
        int count = 0;
    }

    static class FootballMatch {
        String league = "";
        String home = "";
        String away = "";
        String homeLogo = "";
        String awayLogo = "";
        String status = "";
        String clock = "";
        String score = "";
        String date = "";
    }


    static class LoginResult {
        String username = "";
        String expiresAt = "";
        String plan = "";
        int maxConnections = 1;
    }

    static class StreamProbe {
        String format = "auto";
        String contentType = "";
        int httpCode = 0;
    }


    static void login(String username, String password, String device, Callback<LoginResult> cb) {
        IO.execute(() -> {
            try {
                String body = "username=" + URLEncoder.encode(username, "UTF-8")
                        + "&password=" + URLEncoder.encode(password, "UTF-8")
                        + "&device=" + URLEncoder.encode(device == null ? "" : device, "UTF-8");
                JSONObject root = new JSONObject(post(Config.API_BASE_URL + "login.php", body));
                if (!root.optBoolean("ok", false)) throw new Exception(clean(root.optString("message", "Acesso negado"), "Acesso negado"));
                LoginResult r = new LoginResult();
                r.username = clean(root.optString("username", username), username);
                r.expiresAt = clean(root.optString("expires_at", ""), "");
                r.plan = clean(root.optString("plan", ""), "");
                r.maxConnections = root.optInt("max_connections", 1);
                cb.ok(r);
            } catch (Exception e) { cb.error(message(e)); }
        });
    }

    static void status(Callback<String> cb) {
        IO.execute(() -> {
            try {
                JSONObject o = new JSONObject(request(Config.API_BASE_URL + "status.php", false));
                cb.ok(o.optString("name", "Dubai Play"));
            } catch (Exception e) { cb.error(message(e)); }
        });
    }

    static void home(Callback<HomeData> cb) {
        IO.execute(() -> {
            try {
                JSONObject root = new JSONObject(request(Config.API_BASE_URL + "home.php", true));
                HomeData h = new HomeData();
                h.name = root.optString("name", "Dubai Play");
                JSONObject c = root.optJSONObject("counts");
                if (c != null) {
                    h.liveCount = c.optInt("live", 0);
                    h.movieCount = c.optInt("movie", 0);
                    h.seriesCount = c.optInt("series", 0);
                }
                h.hero = parseItem(root.optJSONObject("hero"));
                JSONObject featured = root.optJSONObject("featured");
                if (featured != null) {
                    parseArray(featured.optJSONArray("live"), h.live, "live");
                    parseArray(featured.optJSONArray("movie"), h.movies, "movie");
                    parseArray(featured.optJSONArray("series"), h.series, "series");
                }
                cb.ok(h);
            } catch (Exception e) { cb.error(message(e)); }
        });
    }

    static void catalog(String type, int page, int limit, String search, Callback<CatalogPage> cb) {
        catalog(type, page, limit, search, "", "", cb);
    }

    static void catalog(String type, int page, int limit, String search, String category, String smart, Callback<CatalogPage> cb) {
        IO.execute(() -> {
            try {
                StringBuilder url = new StringBuilder(Config.API_BASE_URL)
                        .append("catalog.php?type=").append(URLEncoder.encode(type, "UTF-8"))
                        .append("&page=").append(Math.max(1, page))
                        .append("&limit=").append(Math.max(12, Math.min(72, limit)));
                if (search != null && !search.trim().isEmpty()) url.append("&search=").append(URLEncoder.encode(search.trim(), "UTF-8"));
                if (category != null && !category.trim().isEmpty()) url.append("&category=").append(URLEncoder.encode(category.trim(), "UTF-8"));
                if (smart != null && !smart.trim().isEmpty()) url.append("&smart=").append(URLEncoder.encode(smart.trim(), "UTF-8"));
                JSONObject root = new JSONObject(request(url.toString(), true));
                CatalogPage out = new CatalogPage();
                out.page = root.optInt("page", 1);
                out.pages = root.optInt("pages", 1);
                out.total = root.optInt("total", 0);
                parseArray(root.optJSONArray("items"), out.items, root.optString("type", ""));
                JSONArray cats = root.optJSONArray("categories");
                if (cats != null) for (int i=0;i<cats.length();i++) out.categories.add(cats.optString(i, ""));
                cb.ok(out);
            } catch (Exception e) { cb.error(message(e)); }
        });
    }

    static void sections(Callback<List<Section>> cb) {
        IO.execute(() -> {
            try {
                JSONObject root = new JSONObject(request(Config.API_BASE_URL + "sections.php", true));
                JSONArray a = root.optJSONArray("sections");
                List<Section> out = new ArrayList<>();
                if (a != null) for (int i=0;i<a.length();i++) {
                    JSONObject o = a.optJSONObject(i); if (o == null) continue;
                    Section s = new Section();
                    s.title = clean(o.optString("title", ""), "Categoria");
                    s.subtitle = clean(o.optString("subtitle", ""), "");
                    s.type = clean(o.optString("type", "live"), "live");
                    s.category = clean(o.optString("category", ""), "");
                    s.smart = clean(o.optString("smart", ""), "");
                    s.action = clean(o.optString("action", "catalog"), "catalog");
                    s.count = o.optInt("count", 0);
                    out.add(s);
                }
                cb.ok(out);
            } catch (Exception e) { cb.error(message(e)); }
        });
    }

    static void football(Callback<List<FootballMatch>> cb) {
        IO.execute(() -> {
            try {
                JSONObject root = new JSONObject(request(Config.API_BASE_URL + "football.php", true));
                JSONArray a = root.optJSONArray("matches");
                List<FootballMatch> out = new ArrayList<>();
                if (a != null) for (int i=0;i<a.length();i++) {
                    JSONObject o = a.optJSONObject(i); if (o == null) continue;
                    FootballMatch m = new FootballMatch();
                    m.league = clean(o.optString("league", ""), "Futebol");
                    m.home = clean(o.optString("home", ""), "Casa");
                    m.away = clean(o.optString("away", ""), "Fora");
                    m.homeLogo = clean(o.optString("home_logo", ""), "");
                    m.awayLogo = clean(o.optString("away_logo", ""), "");
                    m.status = clean(o.optString("status", ""), "Agendado");
                    m.clock = clean(o.optString("clock", ""), "");
                    m.score = clean(o.optString("score", ""), "");
                    m.date = clean(o.optString("date", ""), "");
                    out.add(m);
                }
                cb.ok(out);
            } catch (Exception e) { cb.error(message(e)); }
        });
    }

    static void series(String title, Callback<SeriesData> cb) {
        IO.execute(() -> {
            try {
                String url = Config.API_BASE_URL + "series.php?title=" + URLEncoder.encode(title, "UTF-8");
                JSONObject root = new JSONObject(request(url, true));
                SeriesData out = new SeriesData();
                out.title = clean(root.optString("title", title), title);
                out.logo = clean(root.optString("logo", ""), "");
                out.backdrop = clean(root.optString("backdrop", ""), "");
                out.synopsis = clean(root.optString("synopsis", ""), "");
                out.group = clean(root.optString("group_title", ""), "");
                out.year = root.optInt("release_year", 0);
                JSONArray seasons = root.optJSONArray("seasons");
                if (seasons != null) {
                    for (int i=0;i<seasons.length();i++) {
                        JSONObject s = seasons.optJSONObject(i); if (s == null) continue;
                        Season season = new Season();
                        season.number = s.optInt("season", 0);
                        parseArray(s.optJSONArray("episodes"), season.episodes, "series");
                        out.seasons.add(season);
                    }
                }
                cb.ok(out);
            } catch (Exception e) { cb.error(message(e)); }
        });
    }

    static void epg(long streamId, Callback<EpgInfo> cb) {
        IO.execute(() -> {
            try {
                JSONObject root = new JSONObject(request(Config.API_BASE_URL + "epg.php?stream_id=" + streamId + "&limit=12", true));
                EpgInfo info = new EpgInfo();
                JSONObject now = root.optJSONObject("now"); JSONObject next = root.optJSONObject("next");
                if (now != null) { info.nowTitle = now.optString("title", ""); info.nowStart = now.optString("start_time", ""); info.nowStop = now.optString("stop_time", ""); }
                if (next != null) { info.nextTitle = next.optString("title", ""); info.nextStart = next.optString("start_time", ""); }
                cb.ok(info);
            } catch (Exception e) { cb.error(message(e)); }
        });
    }

    static void probeStream(long streamId, Callback<StreamProbe> cb) {
        IO.execute(() -> {
            try {
                JSONObject root = new JSONObject(request(Config.API_BASE_URL + "stream_probe.php?id=" + streamId, true));
                StreamProbe p = new StreamProbe();
                p.format = clean(root.optString("format", "auto"), "auto");
                p.contentType = clean(root.optString("content_type", ""), "");
                p.httpCode = root.optInt("http_code", 0);
                cb.ok(p);
            } catch (Exception e) { cb.error(message(e)); }
        });
    }

    static String streamUrl(long id) {
        try { return Config.API_BASE_URL + "stream.php?id=" + id + "&app_token=" + URLEncoder.encode(Config.APP_TOKEN, "UTF-8"); }
        catch (Exception e) { return ""; }
    }

    private static Item parseItem(JSONObject o) {
        if (o == null) return null;
        Item item = new Item();
        item.id = o.optLong("id"); item.name = clean(o.optString("name", ""), "Sem nome");
        item.logo = clean(o.optString("logo", ""), ""); item.backdrop = clean(o.optString("backdrop", o.optString("backdrop_url", "")), "");
        item.group = clean(o.optString("group_title", ""), ""); item.synopsis = clean(o.optString("synopsis", ""), "");
        item.type = clean(o.optString("type", ""), ""); item.format = clean(o.optString("stream_format", "auto"), "auto");
        item.seriesTitle = clean(o.optString("series_title", ""), ""); item.year = o.optInt("release_year", 0);
        item.episodeCount = o.optInt("episode_count", 0); item.seasonCount = o.optInt("season_count", 0);
        item.seasonNumber = o.optInt("season_number", 0); item.episodeNumber = o.optInt("episode_number", 0);
        return item;
    }

    private static void parseArray(JSONArray a, List<Item> out, String type) {
        if (a == null) return;
        for (int i=0;i<a.length();i++) { Item item = parseItem(a.optJSONObject(i)); if (item != null) { if (item.type == null || item.type.isEmpty()) item.type = type; out.add(item); } }
    }


    private static String post(String url, String body) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
        con.setConnectTimeout(8000); con.setReadTimeout(20000); con.setInstanceFollowRedirects(true);
        con.setRequestMethod("POST"); con.setDoOutput(true);
        con.setRequestProperty("Accept", "application/json");
        con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
        con.setRequestProperty("X-App-Token", Config.APP_TOKEN);
        con.setRequestProperty("User-Agent", "DubaiPlayTV/1.6 Android");
        byte[] data = body.getBytes("UTF-8");
        con.setFixedLengthStreamingMode(data.length);
        java.io.OutputStream out = con.getOutputStream(); out.write(data); out.flush(); out.close();
        int code = con.getResponseCode(); InputStream in = code >= 200 && code < 300 ? con.getInputStream() : con.getErrorStream();
        StringBuilder sb = new StringBuilder(); if (in != null) { BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8")); String line; while ((line = br.readLine()) != null) sb.append(line); br.close(); }
        con.disconnect();
        if (code == 401) throw new Exception("Usuário ou senha inválidos");
        if (code == 403) throw new Exception(sb.length() > 0 ? new JSONObject(sb.toString()).optString("message", "Acesso bloqueado") : "Acesso bloqueado");
        if (code < 200 || code >= 300) throw new Exception("Servidor respondeu HTTP " + code);
        return sb.toString();
    }

    private static String request(String url, boolean authenticated) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
        con.setConnectTimeout(8000); con.setReadTimeout(20000); con.setInstanceFollowRedirects(true);
        con.setRequestProperty("Accept", "application/json"); con.setRequestProperty("Connection", "keep-alive");
        con.setRequestProperty("User-Agent", "DubaiPlayTV/1.6 Android"); if (authenticated) con.setRequestProperty("X-App-Token", Config.APP_TOKEN);
        int code = con.getResponseCode(); InputStream in = code >= 200 && code < 300 ? con.getInputStream() : con.getErrorStream();
        StringBuilder sb = new StringBuilder(); if (in != null) { BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8")); String line; while ((line = br.readLine()) != null) sb.append(line); br.close(); }
        con.disconnect(); if (code == 401) throw new Exception("Painel precisa do patch V2.2"); if (code < 200 || code >= 300) throw new Exception("Servidor respondeu HTTP " + code); return sb.toString();
    }

    private static String clean(String value, String fallback) { if (value == null) return fallback; String s = value.trim(); return s.isEmpty() || "null".equalsIgnoreCase(s) ? fallback : s; }
    private static String message(Exception e) { String m = e.getMessage(); return m == null || m.trim().isEmpty() ? "Falha de conexão" : m; }
}
