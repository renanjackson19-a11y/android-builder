GreenPlay Android 5.28.6 / 52806

Correção definitiva do carregamento TMDB nos cards:
- filmes e séries herdam corretamente o tipo da seção antes de consultar TMDB;
- séries não são mais enviadas por engano como filme ao content_enrich/content_detail;
- ID do item aceita id/video_id/series_id/stream_id;
- primeiros 10 cards de cada seção são conferidos antes de abrir a Home;
- URL image.tmdb.org da fonte não é tratada como TMDB confirmado sem tmdb_id;
- fallback content_enrich -> content_detail para capas críticas;
- novo schema catalog52806 invalida snapshot antigo sem exigir limpar dados.
