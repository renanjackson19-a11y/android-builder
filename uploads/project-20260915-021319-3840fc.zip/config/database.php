<?php 
#informacoes banco de dados
define("DB_HOST", "localhost");
define("DB_NAME", "greenplay_dubai");
define("DB_USER", "greenplay_dubai");
define("DB_PASS", "santo1919");
define("DB_CON", "mysql:dbname=" . DB_NAME . ";host=" . DB_HOST . ";charset=utf8");