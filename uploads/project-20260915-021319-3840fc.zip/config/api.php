<?php
// GreenPlay API v1 - chave usada pelo aplicativo Android/TV.
// Mantenha este arquivo fora de repositórios públicos.
define('GREENPLAY_API_KEY', '454946ee403e82a9657eafc76091ccb6d8ccd4a8fadfca45');
