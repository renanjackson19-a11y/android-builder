<?php 
require_once $_SERVER['DOCUMENT_ROOT'].'/view_controller/painel-admin/premium_revendedor.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/view/painel-admin/header.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/view/painel-admin/navbar.php';
?>

<div class="page-content">
    <div class="container-fluid">
   
        <div class="card card-page-title">
            <div class="card-body">
                <h6>Planos Premium</h6>
                <small>Revendedor</small>
            </div>
        </div>
 
        <div class="d-flex justify-content-end mb-3">
            <button class="btn btn-sm btn-one btn-adicionar" data-bs-toggle="modal" data-bs-target="#modal-premium-add"><i class="far fa-plus"></i>Adicionar Plano</button>
        </div>
         
        <div class="card"> 
            <div class="card-body"> 
                <div class="table-responsive"> 
                    <table class="w-100 table border table-hover" id="dataTable">
                        <div class="table-responsive">
                        <thead>
                            <tr>
                            <th>Telas</th>
                            <th>Dias De Acesso</th>
                            <th>Consumo Créditos</th>
                            <th>Ação</th>
                            </tr> 
                        </thead> 
                        <tbody> 
                            <?php foreach($premium_revendedor as $item):?>
                                <tr> 
                                    <td><?php echo $item['premium_rev_config_telas'];?></td>
                                    <td><?php echo $item['premium_rev_config_dias'];?></td>
                                    <td><?php echo $item['premium_rev_config_creditos'];?></td>
                                   
                                    <td>
                                        <div class="d-flex">
                                            <button data-bs-toggle="modal" data-bs-target="#modal-excluir" class="btn btn-sm btn-two btn-excluir"
                                            data-id="<?php echo $item['premium_rev_config_id'];?>"
                                                    data-telas="<?php echo $item['premium_rev_config_telas'];?>"
                                                    data-dias="<?php echo $item['premium_rev_config_dias'];?>">
                                                    <i class="far fa-trash"></i>Excluir
                                            </button>
                                        </div>
                                    </td> 
                                </tr>
                            <?php endforeach;?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>


        </div>
</div>



<div class="modal" tabindex="-1" id="modal-premium-add" data-bs-backdrop="static">
    <form id="form-premium-add-editar" autocomplete="off">
        <div class="modal-dialog">
            <div class="modal-content"> 
            <div class="modal-header">
                <h5 class="modal-title">Adicionar Plano Premium Revendedor</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">

                <div class="form-group">
                    <label>Quantidade de telas</label>
                    <div class="input-group">
                        <input type="text" name="premium_rev_config_telas" class="form-control number_two">
                        <span class="input-group-text"><i class="far fa-tv-retro"></i></span>
                    </div>
                </div>

                <div class="form-group">
                    <label>Dias de acesso</label>
                    <div class="input-group">
                        <input type="text" name="premium_rev_config_dias" class="form-control number_three">
                        <span class="input-group-text"><i class="far fa-calendar"></i></span>
                    </div>
                </div>
    
                <div class="form-group">
                    <label>Créditos A Serem Consumidos</label> 
                    <div class="input-group">
                        <input type="text" name="premium_rev_config_creditos" class="form-control number_four">
                        <span class="input-group-text"><i class="far fa-usd-circle"></i></span>
                    </div>
                </div>

            </div>
            <div class="modal-footer"> 
                <input type="hidden" name="acao" value="premium-rev-config-adicionar">
                <button type="button" class="btn btn-sm btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-sm btn-one btn-sm"><i class="far fa-check"></i>Salvar</button>
            </div>
            </div>
        </div>
    </form>
</div>
 

<div class="modal" tabindex="-1" id="modal-excluir" data-bs-backdrop="static">
    <form id="form-premium-excluir">
        <div class="modal-dialog">
            <div class="modal-content"> 
            <div class="modal-header">
                <h5 class="modal-title">Excluir Plano Premium Revendedor</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center">
                <p class="mb-0">Tem certeza que deseja excluir o plano premium  do revendedor ?</p>
                <p class="mb-0 text-red">Todos os planos dos revendedores cadastrados nessa configuração seram excluídos.</p>
                <p class="text-excluir mb-0"></p>
                <p class="text-excluir-dois"></p>
            </div>
            <div class="modal-footer"> 
                <input type="hidden" name="acao" value="premium-rev-config-excluir">
                <input type="hidden" name="premium_rev_config_id" value="">
                <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-sm btn-two"><i class="far fa-trash"></i>Excluir</button>
            </div>
            </div>
        </div>
    </form>
</div>

<?php require_once $_SERVER['DOCUMENT_ROOT'].'/view/painel-admin/footer.php';?>


<script>
    $("#dataTable").on("click", ".btn-excluir", function(){
        $("#form-premium-excluir input[name=premium_rev_config_id]").val($(this).attr("data-id"));
        var  telas = $(this).attr("data-telas") == 1 ? $(this).attr("data-telas") + " Tela " : $(this).attr("data-telas") + " Telas ";
        var dias = $(this).attr("data-dias") == 1 ? $(this).attr("data-dias") + " Dia " : $(this).attr("data-dias") + " Dias ";
        $(".text-excluir-dois").html(telas + dias);
    });  
    controller_submit_form("#form-premium-excluir", "painel-admin/premium_revendedor.php");
    controller_submit_form("#form-premium-add-editar", "painel-admin/premium_revendedor.php");
</script>

</body>
</html>