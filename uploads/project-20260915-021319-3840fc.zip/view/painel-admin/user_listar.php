<?php 
require_once $_SERVER['DOCUMENT_ROOT'].'/view_controller/painel-admin/user_listar.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/view/painel-admin/header.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/view/painel-admin/navbar.php';

?>

<div class="page-content">
    <div class="container-fluid">
   
        <div class="card card-page-title">
            <div class="card-body">
                <h6>Usuários</h6>
                <small><?php echo user_tipo_tradutor($_GET['user_tipo'], "plural");?></small>
            </div>
        </div>


        <div class="card"> 
            <div class="card-body"> 
                <div class="table-responsive"> 
                    <table class="w-100 table border table-hover" id="dataTable">
                        <div class="table-responsive">
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>Email</th>
                                <?php echo $_GET['user_tipo'] == 'cliente' ? '<th>Revendedor</th>' : '';?>
                                <?php echo $_GET['user_tipo'] == 'cliente' ? '<th>Premium</th>' : '';?>
                                <?php echo $_GET['user_tipo'] == 'revendedor' ? '<th>Créditos</th>' : '';?>
                                <?php echo $_GET['user_tipo'] == 'revendedor' ? '<th>Clientes</th>' : '';?>
                                <th>Online</th>
                                <th>Perfil</th>
                            </tr> 
                        </thead> 
                        <tbody> 
                            <?php foreach($user_listar as $item):?>
                                <?php $revendedor = user_get_por_id($item['user_revendedor']);?>
                                <tr> 
                                    <td><?php echo $item['user_nome'];?></td>
                                    <td><?php echo $item['user_email'];?></td>
                                    <?php if($item['user_tipo'] == 'cliente'):?>
                                    <td><?php echo !empty($revendedor) ? $revendedor['user_email'] : 'Nenhum';?></td>    
                                    <td><?php echo cliente_is_premium($item['user_id']) ? 'Ativado' : 'Desativado';?></td>
                                    <?php endif;?>
                                    <?php if($item['user_tipo'] == 'revendedor'):?>
                                    <td><?php echo $item['user_credito'];?></td>
                                    <td><?php echo user_contar("cliente", $item['user_id']);?></td>
                                    <?php endif;?>
                                    <td><?php echo user_is_online($item['user_online']);?></td>
                                    <td><a href="<?php echo BASE_ADMIN.'user/perfil/'.$item['user_id'];?>" class="btn btn-one btn-sm"><i class="far fa-user"></i>Perfil</a></td>
                                </tr>
                            <?php endforeach;?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
</div>


<?php require_once $_SERVER['DOCUMENT_ROOT'].'/view/painel-admin/footer.php';?>



</body>
</html>