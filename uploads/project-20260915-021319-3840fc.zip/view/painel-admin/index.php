<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/view_controller/painel-admin/index.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/view/painel-admin/header.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/view/painel-admin/navbar.php';
$gpClients=(int)user_contar('cliente',''); $gpPremium=(int)cliente_premium_contar(''); $gpInactive=max(0,$gpClients-$gpPremium);
$gpToday=get_vendas_filtro_tempo(date('d'),date('m'),date('Y'),'premium','hoje',0); $gpMonth=get_vendas_filtro_tempo('',date('m'),date('Y'),'premium','este-mes',0);
$gpProv=greenplay_providers(); $gpActive=greenplay_provider_get((string)($gpProv['active_id']??'')); $gpSettings=function_exists('greenplay_app_settings')?greenplay_app_settings():array();
?>
<div class="page-content"><div class="container-fluid">
<div class="gp-dashboard-head"><div><span class="gp-eyebrow">GREENPLAY CONTROL</span><h1>Visão geral</h1><p>Controle usuários, assinaturas, aplicativo, provedores e pagamentos em um só lugar.</p></div><span class="gp-pill"><i class="far fa-circle-check me-1"></i> Sistema online</span></div>
<div class="gp-stat-grid">
<div class="card gp-stat"><div class="gp-stat-top"><span class="gp-stat-label">Clientes</span><span class="gp-stat-icon"><i class="far fa-users"></i></span></div><div class="gp-stat-value"><?php echo $gpClients;?></div><div class="gp-stat-foot">Contas cadastradas</div></div>
<div class="card gp-stat"><div class="gp-stat-top"><span class="gp-stat-label">Assinantes ativos</span><span class="gp-stat-icon"><i class="far fa-crown"></i></span></div><div class="gp-stat-value"><?php echo $gpPremium;?></div><div class="gp-stat-foot"><?php echo $gpInactive;?> sem premium ativo</div></div>
<div class="card gp-stat"><div class="gp-stat-top"><span class="gp-stat-label">Vendas hoje</span><span class="gp-stat-icon"><i class="far fa-bag-shopping"></i></span></div><div class="gp-stat-value">R$ <?php echo $gpToday;?></div><div class="gp-stat-foot">Receita premium de hoje</div></div>
<div class="card gp-stat"><div class="gp-stat-top"><span class="gp-stat-label">Vendas no mês</span><span class="gp-stat-icon"><i class="far fa-chart-line"></i></span></div><div class="gp-stat-value">R$ <?php echo $gpMonth;?></div><div class="gp-stat-foot">Acumulado do mês atual</div></div>
</div>
<div class="gp-quick-grid"><div class="card gp-panel-section"><div class="gp-section-title">Ações rápidas</div><div class="gp-quick-actions"><a class="gp-quick-action" href="<?php echo BASE_ADMIN;?>user/adicionar"><i class="far fa-user-plus"></i><span>Novo usuário</span></a><a class="gp-quick-action" href="<?php echo BASE_ADMIN;?>premium/cliente/adicionar"><i class="far fa-crown"></i><span>Ativar premium</span></a><a class="gp-quick-action" href="<?php echo BASE_ADMIN;?>aplicativo"><i class="far fa-mobile-screen-button"></i><span>Configurar aplicativo</span></a><a class="gp-quick-action" href="<?php echo BASE_ADMIN;?>servidor-iptv"><i class="far fa-server"></i><span>Gerenciar provedores</span></a></div></div>
<div class="card gp-panel-section"><div class="gp-section-title">Status do ecossistema</div><div class="gp-status-list"><div class="gp-status-row"><span>Provedor principal</span><strong><?php echo htmlspecialchars((string)($gpActive['name']??'Não definido'));?></strong></div><div class="gp-status-row"><span>Provedores habilitados</span><strong><?php echo count(greenplay_provider_public_list());?></strong></div><div class="gp-status-row"><span>Teste grátis</span><strong><?php echo (($gpSettings['trial_enabled']??'0')==='1' ? htmlspecialchars((string)($gpSettings['trial_hours']??'3')).'h':'Desativado');?></strong></div><div class="gp-status-row"><span>Pagamento</span><strong>MisticPay / PIX</strong></div></div></div></div>
</div></div>
<?php require_once $_SERVER['DOCUMENT_ROOT'].'/view/painel-admin/footer.php';?></body></html>
