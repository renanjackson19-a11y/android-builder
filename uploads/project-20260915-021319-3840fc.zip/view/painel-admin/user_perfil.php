<?php 
require_once $_SERVER['DOCUMENT_ROOT'].'/view_controller/painel-admin/user_perfil.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/view/painel-admin/header.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/view/painel-admin/navbar.php';

?>

<div class="page-content">
    <div class="container-fluid">
   
        <div class="card card-page-title">
            <div class="card-body">
                <h6>Perfil Usuário</h6>
                <small class="text-warning">Tipo de usuário: <?php echo user_tipo_tradutor($user_get['user_tipo']);?></small>
            </div>
        </div>

        <ul class="list-group">    
            <li class="list-group-item">
                <p class="mb-0">Nome</p>
                <small><?php echo $user_get['user_nome'];?></small>
            </li>
            <li class="list-group-item">
                <p class="mb-0">Email</p>
                <small><?php echo $user_get['user_email'];?></small>
            </li>
            <li class="list-group-item">
                <p class="mb-0">Whatsapp</p>
                <small><?php echo !empty($user_get['user_whatsapp']) ? $user_get['user_whatsapp'] : 'N/A';?></small>
            </li>
            <?php if($user_get['user_tipo'] == 'cliente'):?>
            <li class="list-group-item">
                <p class="mb-0">Premium</p>
                <small><?php echo cliente_is_premium($user_get['user_id']) ? '<span class="text-green">Ativado</span>' : '<span class="">Desativado</span>';?></small>
            </li>
            <li class="list-group-item">
                <p class="mb-0">Premium Data</p>
                <small><?php echo !empty($cliente_premium_get) ? date("d/m/Y H:i:s",strtotime($cliente_premium_get['cliente_premium_data'])) : 'N/A';?></small>
            </li>
            <li class="list-group-item">
                <p class="mb-0">Perfis</p>
                <small><?php echo cliente_perfil_contar($user_get['user_id']);?></small>
            </li>
            <?php endif;?>
            <?php if($user_get['user_tipo'] == 'revendedor'):?>
                <li class="list-group-item">
                    <p class="mb-0">Créditos</p>
                    <small><?php echo $user_get['user_credito'];?></small>
                </li>
                <li class="list-group-item"> 
                    <p class="mb-0">Clientes</p>
                    <small><?php echo user_contar("cliente", $user_get['user_id']);?></small>
                </li>
                <li class="list-group-item"> 
                    <p class="mb-0">Clientes Premium</p>
                    <small><?php echo cliente_premium_contar($user_get['user_id']);?></small>
                </li>
            <?php endif;?>    
            <li class="list-group-item">
                <p class="mb-0">Online</p>
                <small><?php echo user_is_online($user_get['user_online']);?></small>
            </li>
            <li class="list-group-item">
                <p class="mb-0">Data Cadastro</p>
                <small><?php echo date("d/m/Y",strtotime($user_get['user_data']));?></small>
            </li>
    </ul>  

    <div class="buttons-perfil-group mt-2">
        
        <?php if($user_get['user_tipo'] == 'cliente'):?>
                <button data-bs-toggle="modal" data-bs-target="#modal-premium" class="btn btn-sm btn-one me-2"><i class="far fa-crown"></i>Editar Premium</a>
        <?php endif;?>

        <?php if($user_get['user_tipo'] == 'admin' &&$user_get['user_id'] == $admin['user_id']):?>
            <button data-bs-toggle="modal" data-bs-target="#modal-perfil" class="btn btn-sm btn-one me-2"><i class="far fa-user-edit"></i>Editar Perfil</button>
            <button data-bs-toggle="modal" data-bs-target="#modal-senha" class="btn btn-sm btn-one me-2"><i class="far fa-key"></i>Alterar Senha</button>
        <?php endif;?>

        <?php if($user_get['user_tipo'] == 'revendedor'):?>
            <button data-bs-toggle="modal" data-bs-target="#modal-credito" class="btn btn-sm btn-one me-2"><i class="far fa-coins"></i>Atualizar Créditos</button>
        <?php endif;?>    

        <button class="btn btn-sm btn-one me-2" data-bs-toggle="modal" data-bs-target="#modal-excluir"><i class="far fa-trash"></i>Excluir <?php echo user_tipo_tradutor($user_get['user_tipo']);?></button>

    </div>   
    
    
    <?php if($user_get['user_tipo'] == 'cliente' && $revendedor):?>            
    <ul class="list-group pt-3 pb-3">    
            <li class="list-group-item">
                <p class="mb-0">Revendedor Nome</p>
                <small><?php echo $revendedor['user_nome'];?></small>
            </li>
            <li class="list-group-item">
                <p class="mb-0">Revendedor Email</p>
                <small><?php echo $revendedor['user_email'];?></small>
            </li>
            <li class="list-group-item">
                <p class="mb-0">Revendedor Whatsapp</p>
                <small><?php echo !empty($revendedor['user_whatsapp']) ? $revendedor['user_whatsapp'] : 'N/A';?></small>
            </li>
            <li class="list-group-item">
                <p class="mb-0">Revendedor Créditos</p>
                <small><?php echo $revendedor['user_credito'];?></small>
            </li>
            <li class="list-group-item">
                <p class="mb-0">Revendedor Online</p>
                <small><?php echo user_is_online($revendedor['user_online']);?></small>
            </li>
    </ul>  
    <?php endif;?>

    </div>
</div>

<?php if($user_get['user_tipo'] == 'cliente'):?>
<div class="modal" tabindex="-1" id="modal-premium" data-bs-backdrop="static">
    <form id="cliente-premium">
        <div class="modal-dialog">
            <div class="modal-content"> 
            <div class="modal-header">
                <h5 class="modal-title">Editar Premium</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                        <label>Premium Status</label>
                        <div class="input-group">
                            <input type="text" class="form-control disabled" disabled 
                            value="<?php echo cliente_is_premium($user_get['user_id']) ? 'Ativado' : 'Desativado';?> <?php echo !empty($cliente_premium_get) ? date("d/m/Y H:i:s",strtotime($cliente_premium_get['cliente_premium_data'])) : '';?>">
                            <span class="input-group-text"><i class="far fa-crown"></i></span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Plano Premium</label>
                        <select class="form-select" name="premium">
                            <option selected disabled>Selecione uma opção</option>
                            <?php foreach(premium_listar(0) as $p):?>
                                <option value="<?php echo $p['premium_id'];?>">
                                    <?php echo $p['premium_telas'] == 1 ? $p['premium_telas'] . ' Tela ' : $p['premium_telas'] . ' Telas ';?>
                                    <?php echo $p['premium_dias'] == 1 ? $p['premium_dias'] . ' Dia ' : $p['premium_dias'] . ' Dias ';?> 
                                    R$ <?php echo number_format($p['premium_preco'], 2 , ',' , '.');?> 
                                </option>
                            <?php endforeach;?>    
                            <option value="0">Remover Premium</option>
                        </select>
                    </div>
            </div>
            <div class="modal-footer"> 
                <input type="hidden" name="acao" value="admin-cliente-premium-editar">
                <input type="hidden" name="user_id" value="<?php echo $user_get['user_id'];?>">
                <button type="button" class="btn btn-sm btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-sm btn-one btn-sm"><i class="far fa-check"></i>Salvar</button>
            </div>
            </div>
        </div>
    </form>
</div>

<?php endif;?>


<?php if($user_get['user_tipo'] == 'admin' && $user_get['user_id'] == $admin['user_id']):?>    

<div class="modal" tabindex="-1" id="modal-perfil" data-bs-backdrop="static">
    <form id="form-perfil" autocomplete="off">
        <div class="modal-dialog">
            <div class="modal-content"> 
            <div class="modal-header">
                <h5 class="modal-title">Editar Perfil</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                    <div class="form-group">
                        <label>Nome Completo</label>
                        <div class="input-group">
                            <input type="text" name="user_nome" class="form-control" required value="<?php echo $user_get['user_nome'];?>">
                            <span class="input-group-text"><i class="far fa-address-card"></i></span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Whatsapp (opcional)</label>
                        <div class="input-group">
                            <input type="text" name="user_whatsapp" class="form-control whatsapp_telegram" value="<?php echo $user_get['user_whatsapp'];?>">
                            <span class="input-group-text"><i class="fab fa-whatsapp"></i></span>
                        </div>
                    </div>
            </div>
            <div class="modal-footer"> 
                <input type="hidden" name="acao" value="admin-editar-perfil">
                <button type="button" class="btn btn-sm btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-sm btn-one btn-sm"><i class="far fa-check"></i>Salvar</button>
            </div>
            </div>
        </div>
    </form>
</div>


<div class="modal" tabindex="-1" id="modal-senha" data-bs-backdrop="static">
    <form id="form-senha">
        <div class="modal-dialog">
            <div class="modal-content"> 
            <div class="modal-header">
                <h5 class="modal-title">Alterar Senha</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label>Senha Atual</label>
                    <div class="input-group">
                        <input type="password" name="user_senha" class="form-control input-senha-um" required>
                        <span class="input-group-text ver-senha-um"><i class="far fa-eye"></i></span>
                    </div>
                </div>
                <div class="form-group">
                    <label>Nova Senha</label>
                    <div class="input-group">
                        <input type="password" name="user_senha_nova" class="form-control input-senha-dois" required>
                        <span class="input-group-text ver-senha-dois"><i class="far fa-eye"></i></span>
                    </div>
                </div>
                <div class="form-group">
                    <label>Confirmar Nova Senha</label> 
                    <div class="input-group">
                        <input type="password" name="user_senha_confirma" class="form-control input-senha-tres" required>
                        <span class="input-group-text ver-senha-tres"><i class="far fa-eye"></i></span>
                    </div>
                </div>
            </div>
            <div class="modal-footer"> 
                <input type="hidden" name="acao" value="admin-alterar-senha">
                <button type="button" class="btn btn-sm btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-sm btn-one btn-sm"><i class="far fa-check"></i>Alterar Senha</button>
            </div>
            </div>
        </div>
    </form>
</div>



<?php endif;?>

<div class="modal" tabindex="-1" id="modal-excluir" data-bs-backdrop="static">
    <form id="form-excluir">
        <div class="modal-dialog">
            <div class="modal-content"> 
            <div class="modal-header">
                <h5 class="modal-title">Excluir <?php echo user_tipo_tradutor($user_get['user_tipo']);?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center">
                <p class="mb-0">Tem certeza que deseja excluir o <?php echo strtolower(user_tipo_tradutor($user_get['user_tipo']));?> ?</p>
                <p class="text-excluir mb-0"><?php echo $user_get['user_nome'];?></p>
            </div>
            <div class="modal-footer"> 
                <input type="hidden" name="acao" value="admin-excluir-user">
                <input type="hidden" name="user_id" value="<?php echo $user_get['user_id'];?>">
                <button type="button" class="btn btn-sm btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-sm btn-one btn-sm"><i class="far fa-trash"></i>Excluir</button>
            </div>
            </div>
        </div>
    </form>
</div>

<?php if($user_get['user_tipo'] == 'revendedor'):?>


    <div class="modal" tabindex="-1" id="modal-credito" data-bs-backdrop="static">
    <form id="form-credito">
        <div class="modal-dialog">
            <div class="modal-content"> 
            <div class="modal-header">
                <h5 class="modal-title">Atualizar Creditos</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                    <div class="form-group">
                        <label>Total De Créditos</label>
                        <div class="input-group">
                            <input type="text" class="form-control disabled" value="<?php echo $user_get['user_credito'];?>" disabled>
                            <span class="input-group-text"><i class="far fa-coins"></i></span>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Quantidade de créditos</label>
                        <div class="input-group">
                            <input type="number" name="user_credito" class="form-control" placeholder="Use o sinal de menos para remover ex: -5">
                            <span class="input-group-text"><i class="far fa-coins"></i></span>
                        </div>
                    </div>
            </div>
            <div class="modal-footer"> 
                <input type="hidden" name="acao" value="admin-revendedor-credito-atualizar">
                <input type="hidden" name="user_id" value="<?php echo $user_get['user_id'];?>">
                <button type="button" class="btn btn-sm btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-sm btn-one btn-sm"><i class="far fa-check"></i>Salvar</button>
            </div>
            </div>
        </div>
    </form>
</div>


<?php endif;?>    



<?php require_once $_SERVER['DOCUMENT_ROOT'].'/view/painel-admin/footer.php';?>

<script>
    controller_submit_form("#form-excluir", "user/user_excluir.php");
    controller_submit_form("#cliente-premium", "global/cliente.php");
    controller_submit_form("#form-perfil", "user/user_perfil.php"); 
    controller_submit_form("#form-senha", "user/alterar_senha.php");
    controller_submit_form("#form-credito", "painel-admin/credito.php");
</script>

</body>
</html>