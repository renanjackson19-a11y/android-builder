<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/view_controller/painel-admin/app_greenplay.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/view/painel-admin/header.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/view/painel-admin/navbar.php';
function gpcheck($v){ echo $v==='1'?'checked':''; }
?>
<div class="page-content"><div class="container-fluid">
<div class="card card-page-title gp-hero"><div class="card-body"><div><small class="gp-kicker">CENTRAL DO APLICATIVO</small><h4 class="mb-1">GreenPlay</h4><small>Teste grátis, assinaturas, recursos e pagamentos em um só lugar.</small></div><span class="gp-badge">ONLINE</span></div></div>
<div class="row mb-3">
 <div class="col-6 col-lg-3"><div class="card"><div class="card-body"><small>Clientes</small><h4><?php echo (int)$stats['clientes'];?></h4></div></div></div>
 <div class="col-6 col-lg-3"><div class="card"><div class="card-body"><small>Em teste</small><h4><?php echo (int)$stats['teste'];?></h4></div></div></div>
 <div class="col-6 col-lg-3"><div class="card"><div class="card-body"><small>Assinantes</small><h4><?php echo (int)$stats['premium'];?></h4></div></div></div>
 <div class="col-6 col-lg-3"><div class="card"><div class="card-body"><small>Sem acesso</small><h4><?php echo (int)$stats['vencidos'];?></h4></div></div></div>
</div>
<div class="card"><div class="card-body"><form id="app-greenplay" autocomplete="off">
<h6 class="mb-3">Acesso e teste grátis</h6>
<div class="form-group"><label>Nome do aplicativo</label><input class="form-control" name="app_name" value="<?php echo htmlspecialchars($app_settings['app_name']);?>"></div>
<hr><h6 class="mb-3">Identidade visual do aplicativo</h6>
<div class="alert alert-info"><strong>Sem recompilar o APK:</strong> logo, fundo do login/cadastro, cor, teste, conteúdo e pagamentos são enviados ao aplicativo pela API. O fundo não é aplicado na Home/Perfil para preservar a leitura.</div>
<div class="row"><div class="col-md-6"><div class="form-group"><label>Logo do aplicativo</label><input class="form-control-file" type="file" name="app_logo_file" accept="image/png,image/jpeg,image/webp"><small class="text-muted">PNG, JPG ou WEBP. Recomendado: logo transparente.</small><?php if(!empty($app_settings['app_logo'])){?><div class="mt-2"><img src="<?php echo htmlspecialchars($app_settings['app_logo']);?>" style="max-height:90px;max-width:220px"></div><?php }?></div></div>
<div class="col-md-6"><div class="form-group"><label>Fundo do login/cadastro</label><input class="form-control-file" type="file" name="app_background_file" accept="image/png,image/jpeg,image/webp"><small class="text-muted">Recomendado: imagem vertical 1080x1920.</small><?php if(!empty($app_settings['app_background'])){?><div class="mt-2"><img src="<?php echo htmlspecialchars($app_settings['app_background']);?>" style="max-height:110px;max-width:180px"></div><?php }?></div></div></div>
<div class="form-group"><label>Cor principal GreenPlay</label><input class="form-control" type="color" name="app_primary_color" value="<?php echo htmlspecialchars($app_settings['app_primary_color']?:'#20E070');?>" style="max-width:120px;padding:5px"></div>
<div class="form-group form-check"><input class="form-check-input" type="checkbox" name="trial_enabled" id="trial_enabled" <?php gpcheck($app_settings['trial_enabled']);?>><label class="form-check-label" for="trial_enabled">Ativar teste grátis</label></div>
<div class="form-group"><label>Duração do teste (horas)</label><input class="form-control" type="number" step="0.5" min="0" max="720" name="trial_hours" value="<?php echo htmlspecialchars($app_settings['trial_hours']);?>"><small class="text-muted">Exemplo: 3 = três horas. A contagem usa a data de criação da conta.</small></div>
<div class="form-group form-check"><input class="form-check-input" type="checkbox" name="subscription_enabled" id="subscription_enabled" <?php gpcheck($app_settings['subscription_enabled']);?>><label class="form-check-label" for="subscription_enabled">Exigir assinatura após o teste</label></div>
<hr><h6 class="mb-3">Conteúdo do aplicativo</h6>
<?php foreach(array('show_movies'=>'Filmes','show_series'=>'Séries','show_live'=>'Canais ao vivo','watchlist_enabled'=>'Favoritos / Watchlist','downloads_enabled'=>'Downloads','continue_watching_enabled'=>'Continuar assistindo') as $k=>$label){ ?>
<div class="form-group form-check"><input class="form-check-input" type="checkbox" name="<?php echo $k;?>" id="<?php echo $k;?>" <?php gpcheck($app_settings[$k]);?>><label class="form-check-label" for="<?php echo $k;?>"><?php echo $label;?></label></div>
<?php } ?>
<hr><div class="d-flex align-items-center justify-content-between mb-3"><div><h6 class="mb-0">MisticPay</h6><small class="text-muted">Gateway exclusivo para assinaturas via PIX.</small></div><span class="gp-pay">PIX</span></div>
<div class="alert alert-success"><strong>Mercado Pago removido do painel.</strong> As novas cobranças do aplicativo usam somente MisticPay.</div>
<div class="form-group"><label>URL da API</label><input class="form-control" name="misticpay_base_url" value="<?php echo htmlspecialchars($app_settings['misticpay_base_url']);?>"></div>
<div class="row"><div class="col-md-6"><div class="form-group"><label>Client ID / Public Key</label><input class="form-control" name="misticpay_client_id" autocomplete="off" value="<?php echo htmlspecialchars($app_settings['misticpay_client_id']);?>"></div></div>
<div class="col-md-6"><div class="form-group"><label>Client Secret</label><input class="form-control" type="password" name="misticpay_client_secret" autocomplete="new-password" value="<?php echo htmlspecialchars($app_settings['misticpay_client_secret']);?>"></div></div></div>
<div class="form-group"><label>Webhook</label><input class="form-control" name="misticpay_webhook_url" placeholder="<?php echo SITE_URL;?>/api/misticpay/webhook" value="<?php echo htmlspecialchars($app_settings['misticpay_webhook_url']);?>"><small class="text-muted">Se ficar vazio, o GreenPlay usa automaticamente /api/misticpay/webhook.</small></div>
<input type="hidden" name="acao" value="app-greenplay-salvar"><button type="submit" class="btn btn-one"><i class="fas fa-check"></i>Salvar e aplicar no aplicativo</button>
</form></div></div>
</div></div>
<?php require_once $_SERVER['DOCUMENT_ROOT'].'/view/painel-admin/footer.php';?>
<script>controller_submit_form('#app-greenplay','painel-admin/app_greenplay.php');</script>
<style>
.gp-hero{border:0;background:linear-gradient(135deg,rgba(23,30,45,.98),rgba(35,50,75,.95));box-shadow:0 10px 30px rgba(0,0,0,.16)}.gp-hero .card-body{display:flex;align-items:center;justify-content:space-between;padding:24px}.gp-kicker{letter-spacing:1.6px;opacity:.65}.gp-badge,.gp-pay{font-size:11px;font-weight:700;padding:7px 11px;border-radius:20px;background:rgba(40,200,120,.15);color:#35d58b;border:1px solid rgba(53,213,139,.3)}.gp-pay{background:rgba(60,150,255,.12);color:#62a9ff;border-color:rgba(98,169,255,.25)}#app-greenplay .form-control{min-height:44px;border-radius:9px}#app-greenplay hr{margin:28px 0}.page-content .card{border-radius:12px;box-shadow:0 5px 18px rgba(0,0,0,.08)}
</style></body></html>
