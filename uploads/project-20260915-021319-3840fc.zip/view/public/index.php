<?php require_once $_SERVER['DOCUMENT_ROOT'].'/view_controller/public/index.php';?>

<!doctype html>
<html lang="PT-br">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8">
    <meta name="description" content="<?php echo SITE_DESCRICAO;?>">
    <meta name="keywords" content="<?php echo SITE_KEYWORDS;?>">
    <link rel="icon" href="<?php echo BASE_IMAGES_URL.'system/'.SITE_FAVICON;?>">
    <!-- PLUGINS --> 
    <link rel="stylesheet" href="<?php echo BASE_PLUGINS;?>bootstrap/css/bootstrap.css?site_cache=<?php echo SITE_CACHE;?>"/>
    <link rel="stylesheet" href="<?php echo BASE_PLUGINS;?>fontawesome/css/all.css?site_cache=<?php echo SITE_CACHE;?>"/>
    <link rel="stylesheet" href="<?php echo BASE_PLUGINS;?>splide/splide.min.css?site_cache=<?php echo SITE_CACHE;?>"/>
    <!-- PLUGINS --> 
    <!-- CSS --> 
    <link rel="stylesheet" href="<?php echo BASE_CSS;?>global/global.css?site_cache=<?php echo SITE_CACHE;?>"/>
    <link rel="stylesheet" href="<?php echo BASE_CSS;?>global/navbar.css?site_cache=<?php echo SITE_CACHE;?>"/>
    <link rel="stylesheet" href="<?php echo BASE_CSS;?>global/button.css?site_cache=<?php echo SITE_CACHE;?>"/>
    <link rel="stylesheet" href="<?php echo BASE_CSS;?>public/public.css?site_cache=<?php echo SITE_CACHE;?>&v=<?php echo @filemtime($_SERVER['DOCUMENT_ROOT'].'/assets/css/public/public.css');?>"/>
    <!-- CSS -->
    <title><?php echo isset($page_title) ? $page_title . ' ' . SITE_NOME : SITE_NOME;?></title>
</head>
<body class="body" style="background-image: url(<?php echo BASE_IMAGES_URL.'system/'.SITE_BACKGROUND_PUBLIC;?>); background-color: rgba(0, 0, 0, 0.8); background-blend-mode: overlay;min-height: 100vh; height:100vh;background-size: cover; background-repeat:no-repeat;">
 
<nav class="navbar navbar-one navbar-public fixed-top m-0">
  <div class="container">
    <div class="items">
        <a href="<?php echo BASE_PUBLIC;?>"><img src="<?php echo BASE_IMAGES_URL.'system/'.SITE_LOGO;?>"></a>
        <ul class="list-group list-group-horizontal">
          <a href="<?php echo BASE_USER;?>login" class="list-group-item pe-3 fw-bold"><i class="fas fa-user-shield me-1"></i>Login</a>
          <a href="<?php echo BASE_USER;?>cadastro" class="list-group-item pe-0 fw-bold"><i class="fas fa-user-plus me-1"></i>Cadastro</a>
        </ul>
    </div>
  </div> 
</nav>      
 

<section class="public-hero">
  <div class="container">
    <div class="public-hero-inner">
      <div class="public-kicker"><i class="fas fa-bolt"></i> Entretenimento em um só lugar</div>
      <h1>Filmes, séries e canais para assistir do seu jeito.</h1>
      <p>Crie sua conta, aproveite seu acesso e assista em uma experiência GreenPlay mais rápida, organizada e feita para celular, TV e navegador.</p>
      <div class="public-actions">
        <a href="<?php echo BASE_USER;?>cadastro" class="btn btn-one"><i class="fas fa-user-plus me-2"></i>Criar conta</a>
        <a href="<?php echo BASE_USER;?>login" class="btn btn-outline-light"><i class="fas fa-sign-in-alt me-2"></i>Já tenho conta</a>
      </div>
      <div class="public-features">
        <div class="public-feature"><i class="fas fa-play-circle"></i><div><strong>Catálogo completo</strong><span>Filmes, séries e canais organizados por categoria.</span></div></div>
        <div class="public-feature"><i class="fas fa-mobile-alt"></i><div><strong>Multiplataforma</strong><span>Acesse pelo navegador e pelo aplicativo GreenPlay.</span></div></div>
        <div class="public-feature"><i class="fas fa-shield-alt"></i><div><strong>Acesso seguro</strong><span>Conta, assinatura e perfil gerenciados em um só lugar.</span></div></div>
      </div>
    </div>
  </div>
</section>

<div class="container pb-3">
    <div class="section-1">
        <h1 class="text-center mb-2">Escolha seu plano</h1>
        <p class="plans-subtitle">Planos simples para começar e continuar assistindo sem complicação.</p>
        <div class="splide premium_home">
            <div class="splide__track" style="border-radius: 5px;">
                <ul class="splide__list">
            
                        <?php foreach($premium_listar as $item):?>
                            <div class="premium-item splide__slide">
                                <div class="top-circle">
                                    <h4>R$ <?php echo number_format($item['premium_preco'], 2, ',', '.');?></h4>
                                </div>
                                <h5 class="tela"><?php echo $item['premium_telas'] == 1 ? $item['premium_telas'] . " Tela " : $item['premium_telas'] . " Telas " ;?></h5>
                                <ul class="list-group">
                                    <li class="list-group-item"><?php echo $item['premium_dias'] == 1 ? $item['premium_dias'] . " Dia Acesso Premium " : $item['premium_dias'] . " Dias Acesso Premium " ;?></li>
                                    <li class="list-group-item">Assista em <?php echo $item['premium_telas'] == 1 ? $item['premium_telas'] . " Dispositivo " : $item['premium_telas'] . " Dispositivos ";?></li>
                                    <li class="list-group-item">Canais Filmes Séries Ilimitados</li>
                                    <li class="list-group-item">Qualidade HD, FULL HD, 4K</li>
                                </ul>
                                <div class="footer">
                                    <a href="<?php echo BASE_USER;?>login" class="btn btn-one btn-comprar" data-id="<?php echo $item['premium_id'];?>"><i class="far fa-shopping-bag me-2"></i>Comece agora mesmo</a>
                                    <?php if(!empty($comprar_no_whatsapp)):?>
                                        <a class="btn btn-success" href="<?php echo whatsapp_url($comprar_no_whatsapp);?>&text=*Informações Acesso Premium:*%0A%0A<?php echo $item['premium_telas'] == 1 ? $item['premium_telas'] . " Tela" : $item['premium_telas'] . " Telas";?>%0A<?php echo $item['premium_dias'] == 1 ? $item['premium_dias'] . " Dia" : $item['premium_dias'] . " Dias" ;?>%0AR$ <?php echo number_format($item['premium_preco'], 2, ',', '.');?>%0A%0A**Site:*%0A<?php echo SITE_URL;?>" target="_blank"><i class="fab fa-whatsapp me-2"></i>Chamar No Whatsapp</a>
                                    <?php endif;?>        
                                </div>
                            </div>      
                        <?php endforeach;?>
                </ul>
            </div>
        </div>
    </div>
</div> 



<script src="<?php echo BASE_PLUGINS;?>bootstrap/js/bootstrap.bundle.min.js?site_cache=<?php echo SITE_CACHE;?>"></script>
<script src="<?php echo BASE_PLUGINS;?>jquery/jquery.js?site_cache=<?php echo SITE_CACHE;?>"></script>
<script src="<?php echo BASE_PLUGINS;?>splide/splide.min.js?site_cache=<?php echo SITE_CACHE;?>"></script>
<script src="<?php echo BASE_PLUGINS;?>splide/splide-public.js?site_cache=<?php echo SITE_CACHE;?>"></script>

</body>
</html>