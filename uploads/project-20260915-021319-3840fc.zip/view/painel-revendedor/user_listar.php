<?php require_once $_SERVER['DOCUMENT_ROOT'].'/view_controller/painel-revendedor/user_listar.php';?>

<div class="page-content">
    <div class="container-fluid">
   
        <div class="card card-page-title">
            <div class="card-body">
                <h6>Usuários</h6>
                <small><?php echo user_tipo_tradutor($_GET['user_tipo'], "plural");?></small>
            </div>
        </div>


        <div class="card"> 
            <div class="card-body"> 
                <div class="table-responsive"> 
                    <table class="w-100 table border table-hover" id="dataTable">
                        <div class="table-responsive">
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>Email</th>
                                <?php echo $_GET['user_tipo'] == 'cliente' ? '<th>Premium</th>' : '';?>
                                <?php echo $_GET['user_tipo'] == 'revendedor' ? '<th>Créditos</th>' : '';?>
                                <th>Online</th>
                                <th>Perfil</th>
                            </tr> 
                        </thead> 
                        <tbody> 
                            <?php foreach($user_listar as $item):?>
                                <tr> 
                                    <td><?php echo $item['user_nome'];?></td>
                                    <td><?php echo $item['user_email'];?></td>
                                    <?php if($item['user_tipo'] == 'cliente'):?>
                                    <td><?php echo cliente_is_premium($item['user_id']) ? 'Ativado' : 'Desativado';?></td>
                                    <?php endif;?>
                                    <?php if($item['user_tipo'] == 'revendedor'):?>
                                    <td><?php echo $item['user_credito'];?></td>
                                    <?php endif;?>
                                    <td><?php echo user_is_online($item['user_online']);?></td>
                                    <td><a href="<?php echo BASE_REVENDEDOR.'user/perfil/'.$item['user_id'];?>" class="btn btn-one btn-sm"><i class="far fa-user"></i>Perfil</a></td>
                                </tr>
                            <?php endforeach;?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
</div>


<?php require_once $_SERVER['DOCUMENT_ROOT'].'/view/painel-revendedor/footer.php';?>



</body>
</html>