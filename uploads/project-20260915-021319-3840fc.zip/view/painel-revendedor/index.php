<?php require_once $_SERVER['DOCUMENT_ROOT'].'/view_controller/painel-revendedor/index.php';?>


<div class="page-content">
    <div class="container-fluid">
   
        <div class="card card-page-title">
            <div class="card-body">
                <h6>Compartilhe o seu link!</h6>
                <small>Cada cadastro feito pelo seu link gera um novo cliente para você.</small>
                <small class="text-break"><?php echo SITE_URL.'/'.$revendedor['user_id'];?></small>
            </div>
        </div>
        <div class="dashboard_page">

            <div class="box">
                <div class="card">
                    <div class="card-body">
                        <div class="icon">
                            <i class="far fa-user-check"></i>
                            <p>Online</p>
                        </div>
                        <div class="info">
                            <p>Clientes</p>
                            <h5><?php echo user_online_total("cliente", $revendedor['user_id']);?></h5>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-body">
                        <div class="icon">
                            <i class="far fa-users-class"></i>
                            <p>Clientes</p>
                        </div>
                        <div class="info">
                            <div><p>Total</p></div>
                            <h5><?php echo user_contar("cliente", $revendedor['user_id']);?></h5>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-body">
                        <div class="icon">
                            <i class="far fa-users-class"></i>
                            <p>Clientes</p>
                        </div>
                        <div class="info">
                            <div><p>Premium Ativo</p></div>
                            <h5><?php echo cliente_premium_contar($revendedor['user_id']);?></h5>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>
</div>


<?php require_once $_SERVER['DOCUMENT_ROOT'].'/view/painel-revendedor/footer.php';?>