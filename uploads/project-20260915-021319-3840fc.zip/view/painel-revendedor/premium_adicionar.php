<?php require_once $_SERVER['DOCUMENT_ROOT'].'/view_controller/painel-revendedor/premium_adicionar.php';?>

<div class="page-content">
    <div class="container-fluid">
   
        <div class="card card-page-title">
            <div class="card-body">
                <h6>Planos Premium</h6> 
                <small>Adicionar Novo Plano</small>
            </div>
        </div>
 
        <div class="card">
            <div class="card-body">
                <form id="form-premium" autocomplete="off">

                    <div class="form-group">
                        <label>Quantidade de telas E Dias De Acesso</label>
                        <select class="form-select" name="premium_rev_config_id">
                            <option value="">Selecione uma opção</option>       
                            <?php foreach($premium_rev_config_listar as $item):?>
                                <option value="<?php echo $item['premium_rev_config_id'];?>">
                                    <?php echo $item['premium_rev_config_dias'] == 1 ? $item['premium_rev_config_dias'] . " Dia " : $item['premium_rev_config_dias'] . " Dias " ;?> :
                                    <?php echo $item['premium_rev_config_telas'] == 1 ? $item['premium_rev_config_telas'] . " Tela " : $item['premium_rev_config_telas'] . " Telas ";?> :
                                    <?php echo $item['premium_rev_config_creditos'] == 1 ? $item['premium_rev_config_creditos'] . " Crédito " : $item['premium_rev_config_creditos'] . " Créditos";?>
                                </option>
                            <?php endforeach;?>   
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Preço</label> 
                        <div class="input-group">
                            <input type="text" name="premium_preco" class="form-control preco">
                            <span class="input-group-text"><i class="far fa-usd-circle"></i></span>
                        </div>
                    </div>

                    <div class="form-group">
                        <input type="hidden" name="acao" value="revendedor-premium-adicionar">
                        <button type="submit" class="btn btn-one"><i class="fas fa-check"></i>Salvar</button>
                    </div>

                </form>
            </div>
        </div>


        </div>
</div>

<?php require_once $_SERVER['DOCUMENT_ROOT'].'/view/painel-revendedor/footer.php';?>


<script>
    controller_submit_form("#form-premium", "painel-revendedor/premium_cliente.php");
</script>

</body>
</html>  