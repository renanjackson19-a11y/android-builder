<div class="sidebar-one">
    <div class="top"> 
        <div class="avatar">
            <a href="<?php echo BASE_REVENDEDOR;?>"><img src="<?php echo BASE_IMAGES_URL.'system/'.SITE_AVATAR;?>"></a>
        </div>
        <div class="info">
            <small class="text-center">Revendedor</small>
            <small><?php echo $revendedor['user_nome'];?></small>
        </div>
    </div>
    <div class="content" id="accordion-group">
      <ul class="list-group child-one list-group-flush">

          <!-- ITEM --> 
          <a href="<?php echo BASE_REVENDEDOR;?>" class="list-group-item"><i class="far fa-home"></i>Início</a>
          
          <!-- ITEM --> 
          <div class="accordion accordion-flush" id="accordion-users"> 
              <div class="accordion-item border-0">
                  <div class="accordion-header">
                      <div class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-users" aria-expanded="false" aria-controls="collapse-users">
                          <div class="icon"><i class="far fa-users"></i></div>
                          <div class="title">Usuários</div>
                      </div>
                  </div>
                  <div id="collapse-users" class="accordion-collapse collapse" data-bs-parent="#accordion-group">
                      <div class="accordion-body">
                          <ul class="list-group child-two list-group-flush">
                              <a href="<?php echo BASE_REVENDEDOR;?>user/cliente" class="list-group-item">Listar Clientes</a>
                              <a href="<?php echo BASE_REVENDEDOR;?>user/adicionar" class="list-group-item">Adicionar Cliente</a>
                              <a href="<?php echo BASE_REVENDEDOR;?>user/perfil/<?php echo $revendedor['user_id'];?>" class="list-group-item">Meu Perfil</a>
                          </ul>
                      </div>
                  </div>
              </div>
          </div>

          <!-- ITEM --> 
          <div class="accordion accordion-flush" id="accordion-plpr"> 
              <div class="accordion-item border-0">
                  <div class="accordion-header">
                      <div class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-plpr" aria-expanded="false" aria-controls="collapse-plpr">
                          <div class="icon"><i class="far fa-crown"></i></div>
                          <div class="title">Planos Premium</div>
                      </div>
                  </div>
                  <div id="collapse-plpr" class="accordion-collapse collapse" data-bs-parent="#accordion-group">
                      <div class="accordion-body">
                          <ul class="list-group child-two list-group-flush">
                              <a href="<?php echo BASE_REVENDEDOR;?>premium/cliente/adicionar" class="list-group-item">Adicionar Plano</a>
                              <a href="<?php echo BASE_REVENDEDOR;?>premium/cliente/listar" class="list-group-item">Listar Planos</a>
                          </ul>
                      </div>
                  </div>
              </div>
          </div>

          <!-- ITEM --> 
          <a href="<?php echo BASE_REVENDEDOR;?>venda/premium/listar" class="list-group-item"><i class="far fa-sack-dollar"></i>Vendas</a>

          <?php if(!empty(SITE_WHATSAPP)):?>

          <!-- ITEM --> 
          <a target="_blank" href="<?php echo whatsapp_url(SITE_WHATSAPP);?>&text=*Suporte Revendedor:*%0ANome:<?php echo $revendedor['user_nome'];?>%0AEmail:<?php echo $revendedor['user_email'];?>%0A*Site:*%0A<?php echo SITE_URL;?>" class="list-group-item"><i class="fab fa-whatsapp"></i>Suporte No Whatsapp</a>

          <?php endif;?>

          <!-- ITEM --> 
          <a href="<?php echo BASE_STREAM;?>" target="_blank" class="list-group-item"><i class="far fa-external-link"></i>Ver Site</a>

          <!-- ITEM --> 
          <a href="<?php echo BASE_REVENDEDOR;?>encerrar-sessao" class="list-group-item"><i class="far fa-power-off"></i>Encerrar Sessão</a>
          
      </ul>      
    </div>
</div>

<nav class="navbar navbar-one fixed-top"> 
  <div class="container-fluid">
    <div class="items">
        <a href="<?php echo BASE_REVENDEDOR;?>"><img src="<?php echo BASE_IMAGES_URL.'system/'.SITE_LOGO;?>"></a>
        <ul class="list-group list-group-horizontal">
            <li class="list-group-item">
                <a href="<?php echo BASE_REVENDEDOR;?>" class="btn btn-one me-2"><i class="far fa-coins me-2"></i> <?php echo $revendedor['user_credito'];?></a>
            </li>
            <li class="list-group-item">
                <a href="<?php echo BASE_REVENDEDOR;?>" class="btn btn-one me-2"><i class="far fa-home m-0"></i></a>
            </li>
            <li class="list-group-item hide">
                <button class="btn btn-one open-sidebar-one" type="button"><i class="far fa-bars open-sidebar-left-icon m-0"></i></button>
            </li>
            
        </ul>
    </div>
  </div> 
</nav>   


 