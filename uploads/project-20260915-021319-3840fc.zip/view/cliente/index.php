<?php 
require_once $_SERVER['DOCUMENT_ROOT'].'/view_controller/cliente/index.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/view/cliente/header.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/view/stream/navbar.php';

?>

<div class="page-content gp-account-page">
    <div class="container-fluid pb-4">
      <div class="gp-page-hero gp-account-hero">
        <div><span class="gp-eyebrow">CONTA GREENPLAY</span><h2>Minha conta</h2><p>Gerencie seus dados, perfil, senha e assinatura.</p></div>
        <div class="gp-account-avatar"><i class="far fa-user"></i></div>
      </div>
      <div class="gp-account-grid">
        <div class="gp-account-card"><span>Nome</span><strong><?php echo htmlspecialchars($cliente['user_nome']);?></strong></div>
        <div class="gp-account-card"><span>Email</span><strong><?php echo htmlspecialchars($cliente['user_email']);?></strong></div>
        <div class="gp-account-card"><span>WhatsApp</span><strong><?php echo !empty($cliente['user_whatsapp']) ? htmlspecialchars($cliente['user_whatsapp']) : 'Não informado';?></strong></div>
        <div class="gp-account-card"><span>Cadastro</span><strong><?php echo date("d/m/Y",strtotime($cliente['user_data']));?></strong></div>
        <div class="gp-account-card"><span>Assinatura</span><strong class="<?php echo cliente_is_premium($cliente['user_id'])?'gp-status-ok':'gp-status-off';?>"><?php echo cliente_is_premium($cliente['user_id'])?'Premium ativo':'Sem assinatura';?></strong></div>
        <div class="gp-account-card"><span>Vencimento</span><strong><?php echo !empty($cliente_premium) ? date("d/m/Y H:i",strtotime($cliente_premium['cliente_premium_data'])) : '—';?></strong></div>
        <div class="gp-account-card"><span>Perfis</span><strong><?php echo cliente_perfil_contar($cliente['user_id']);?></strong></div>
      </div>
      <div class="gp-account-actions">
        <button data-bs-toggle="modal" data-bs-target="#modal-perfil" class="btn gp-btn-secondary"><i class="far fa-pencil"></i><span>Editar perfil</span></button>
        <button data-bs-toggle="modal" data-bs-target="#modal-conta" class="btn gp-btn-secondary"><i class="far fa-user-cog"></i><span>Editar conta</span></button>
        <button data-bs-toggle="modal" data-bs-target="#modal-senha" class="btn gp-btn-secondary"><i class="far fa-key"></i><span>Alterar senha</span></button>
        <a href="<?php echo BASE_CLIENTE.'pagamentos';?>" class="btn gp-btn-primary"><i class="far fa-receipt"></i><span>Meus pagamentos</span></a>
      </div>
    </div>
</div>

<div class="modal" tabindex="-1" id="modal-perfil" data-bs-backdrop="static">
    <form id="cliente-perfil" autocomplete="off">
        <div class="modal-dialog">
            <div class="modal-content"> 
            <div class="modal-header">
                <h5 class="modal-title">Editar Perfil</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                    
                    <div class="form-group">
                        <label>Apelido</label>
                        <div class="input-group">
                            <input type="text" name="cliente_perfil_apelido" class="form-control" required value="<?php echo $cliente_perfil['cliente_perfil_apelido'];?>">
                            <span class="input-group-text"><i class="far fa-address-card"></i></span>
                        </div>
                    </div>

            </div>
            <div class="modal-footer"> 
                <input type="hidden" name="acao" value="cliente-editar-perfil">
                <button type="button" class="btn btn-sm btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-sm btn-one btn-sm"><i class="far fa-check"></i>Salvar</button>
            </div>
            </div>
        </div>
    </form>
</div>


<div class="modal" tabindex="-1" id="modal-conta" data-bs-backdrop="static">
    <form id="cliente-conta" autocomplete="off">
        <div class="modal-dialog">
            <div class="modal-content"> 
            <div class="modal-header">
                <h5 class="modal-title">Editar Conta</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                    
                    <div class="form-group">
                        <label>Nome Completo</label>
                        <div class="input-group">
                            <input type="text" name="user_nome" class="form-control" required value="<?php echo $cliente['user_nome'];?>">
                            <span class="input-group-text"><i class="far fa-address-card"></i></span>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Whatsapp (opcional)</label>
                        <div class="input-group">
                            <input type="text" name="user_whatsapp" class="form-control whatsapp_telegram" value="<?php echo $cliente['user_whatsapp'];?>">
                            <span class="input-group-text"><i class="fab fa-whatsapp"></i></span>
                        </div>
                    </div> 
    
            </div>
            <div class="modal-footer"> 
                <input type="hidden" name="acao" value="cliente-editar-conta">
                <button type="button" class="btn btn-sm btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-sm btn-two btn-sm"><i class="far fa-check"></i>Editar Conta</button>
            </div>
            </div>
        </div>
    </form>
</div>


<div class="modal" tabindex="-1" id="modal-senha" data-bs-backdrop="static">
    <form id="cliente-senha" autocomplete="off">
        <div class="modal-dialog">
            <div class="modal-content"> 
            <div class="modal-header">
                <h5 class="modal-title">Alterar Senha</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <label class="text-center d-block mb-2">Atenção todos os perfis serão desconectados.</label>
                <div class="form-group">
                    <label>Senha Atual</label>
                    <div class="input-group">
                        <input type="password" name="user_senha" class="form-control input-senha-um" required>
                        <span class="input-group-text ver-senha-um"><i class="far fa-eye"></i></span>
                    </div>
                </div>
                <div class="form-group">
                    <label>Nova Senha</label>
                    <div class="input-group">
                        <input type="password" name="user_senha_nova" class="form-control input-senha-dois" required>
                        <span class="input-group-text ver-senha-dois"><i class="far fa-eye"></i></span>
                    </div>
                </div>
                <div class="form-group">
                    <label>Confirmar Nova Senha</label> 
                    <div class="input-group">
                        <input type="password" name="user_senha_confirma" class="form-control input-senha-tres" required>
                        <span class="input-group-text ver-senha-tres"><i class="far fa-eye"></i></span>
                    </div>
                </div>
            </div>
            <div class="modal-footer"> 
                <input type="hidden" name="acao" value="cliente-alterar-senha">
                <button type="button" class="btn btn-sm btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-sm btn-three btn-sm"><i class="far fa-check"></i>Alterar Senha</button>
            </div>
            </div>
        </div>
    </form>
</div>
 


<?php require_once $_SERVER['DOCUMENT_ROOT'].'/view/cliente/footer.php';?>

<script>
    controller_submit_form("#cliente-perfil", "cliente/cliente_conta.php");
    controller_submit_form("#cliente-conta", "cliente/cliente_conta.php");
    controller_submit_form("#cliente-senha", "cliente/cliente_conta.php");
</script>