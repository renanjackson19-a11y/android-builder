<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/view_controller/stream/premium.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/config/app_settings.php';
$appPay = greenplay_app_settings();
require_once $_SERVER['DOCUMENT_ROOT'].'/view/stream/header.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/view/stream/navbar.php';
?>
<div class="page-content gp-premium-page">
  <div class="container-fluid mb-5">
    <div class="gp-page-hero">
      <div><span class="gp-eyebrow">ASSINATURAS GREENPLAY</span><h2>Escolha seu plano</h2><p>Libere filmes, séries e canais com uma assinatura simples e segura.</p></div>
      <div class="gp-hero-icon"><i class="far fa-crown"></i></div>
    </div>

    <div class="gp-plan-grid">
      <?php foreach($premium_listar as $item):?>
      <article class="gp-plan-card">
        <div class="gp-plan-top">
          <span class="gp-plan-pill"><?php echo (int)$item['premium_telas'];?> <?php echo (int)$item['premium_telas']===1?'tela':'telas';?></span>
          <div class="gp-price"><small>R$</small><strong><?php echo number_format($item['premium_preco'],2,',','.');?></strong></div>
          <div class="gp-period"><?php echo (int)$item['premium_dias'];?> dias de acesso</div>
        </div>
        <ul class="gp-feature-list">
          <li><i class="far fa-check-circle"></i><?php echo (int)$item['premium_telas'];?> dispositivo<?php echo (int)$item['premium_telas']===1?'':'s';?> simultâneo<?php echo (int)$item['premium_telas']===1?'':'s';?></li>
          <li><i class="far fa-check-circle"></i>Filmes e séries</li>
          <li><i class="far fa-check-circle"></i>Canais ao vivo</li>
          <li><i class="far fa-check-circle"></i>Qualidade conforme a fonte disponível</li>
          <li><i class="far fa-shield-check"></i>Pagamento via PIX pela MisticPay</li>
        </ul>
        <div class="gp-plan-actions">
          <button type="button" class="btn gp-btn-primary btn-misticpay" data-id="<?php echo (int)$item['premium_id'];?>"><i class="far fa-qrcode"></i> Gerar PIX</button>
          <?php if(!empty($comprar_no_whatsapp)):?>
          <a class="btn gp-btn-secondary" href="<?php echo whatsapp_url($comprar_no_whatsapp);?>&text=*GreenPlay - Assinatura:*%0A%0A<?php echo (int)$item['premium_telas'];?> tela(s)%0A<?php echo (int)$item['premium_dias'];?> dias%0AR$ <?php echo number_format($item['premium_preco'],2,',','.');?>%0A%0A*Email:* <?php echo $cliente['user_email'];?>" target="_blank"><i class="fab fa-whatsapp"></i> Falar no WhatsApp</a>
          <?php endif;?>
        </div>
      </article>
      <?php endforeach;?>
    </div>
  </div>
</div>

<div class="modal fade" id="modalPix" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered"><div class="modal-content gp-pix-modal">
    <div class="modal-header"><div><span class="gp-eyebrow">MISTICPAY</span><h5 class="modal-title">Pagar com PIX</h5></div><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
    <div class="modal-body">
      <div id="gpPixForm">
        <label class="form-label">CPF ou CNPJ do pagador</label>
        <input type="text" id="gpPayerDocument" class="form-control" inputmode="numeric" placeholder="Somente números">
        <small class="gp-help">O documento é solicitado pela operadora para gerar a cobrança PIX.</small>
        <button type="button" class="btn gp-btn-primary w-100 mt-3" id="gpGerarPix"><i class="far fa-qrcode"></i> Gerar PIX</button>
      </div>
      <div id="gpPixResult" class="d-none text-center">
        <div id="gpQrWrap" class="gp-qr-wrap d-none"><img id="gpQrImg" alt="QR Code PIX"></div>
        <p class="mt-3 mb-2">PIX copia e cola</p>
        <textarea id="gpPixCode" class="form-control gp-pix-code" rows="4" readonly></textarea>
        <button type="button" class="btn gp-btn-primary w-100 mt-3" id="gpCopyPix"><i class="far fa-copy"></i> Copiar código PIX</button>
        <small class="gp-help d-block mt-2">Após a confirmação do pagamento, seu acesso é atualizado automaticamente.</small>
      </div>
      <div id="gpPixError" class="alert alert-danger d-none mt-3 mb-0"></div>
    </div>
  </div></div>
</div>

<?php require_once $_SERVER['DOCUMENT_ROOT'].'/view/stream/footer.php';?>
<script>
(function(){
 let planId=0; const modalEl=document.getElementById('modalPix'); const modal=new bootstrap.Modal(modalEl);
 $('.btn-misticpay').on('click',function(){ planId=$(this).data('id'); $('#gpPayerDocument').val(''); $('#gpPixResult').addClass('d-none'); $('#gpPixForm').removeClass('d-none'); $('#gpPixError').addClass('d-none').text(''); modal.show(); });
 $('#gpGerarPix').on('click',function(){
   const btn=$(this), doc=$('#gpPayerDocument').val(); btn.prop('disabled',true).html('<i class="far fa-spinner fa-spin"></i> Gerando...');
   $.ajax({url:SITE_URL+'/controller/stream/misticpay_checkout.php?ajax=ajax',method:'POST',data:{acao:'checkout-misticpay',premium_id:planId,payer_document:doc},dataType:'json'})
   .done(function(r){
      if(r.status!=='pix'){ $('#gpPixError').removeClass('d-none').text(r.msg||'Não foi possível gerar o PIX.'); return; }
      $('#gpPixCode').val(r.pix_copy_paste||'');
      let src=''; if(r.qr_code_base64){ src=r.qr_code_base64.indexOf('data:')===0?r.qr_code_base64:'data:image/png;base64,'+r.qr_code_base64; } else if(r.qr_code_url){src=r.qr_code_url;}
      if(src){$('#gpQrImg').attr('src',src);$('#gpQrWrap').removeClass('d-none');}else{$('#gpQrWrap').addClass('d-none');}
      $('#gpPixForm').addClass('d-none'); $('#gpPixResult').removeClass('d-none');
   }).fail(function(){ $('#gpPixError').removeClass('d-none').text('Falha de comunicação. Tente novamente.'); })
   .always(function(){btn.prop('disabled',false).html('<i class="far fa-qrcode"></i> Gerar PIX');});
 });
 $('#gpCopyPix').on('click',async function(){ const txt=$('#gpPixCode').val(); try{await navigator.clipboard.writeText(txt); $(this).html('<i class="far fa-check"></i> PIX copiado'); setTimeout(()=>$(this).html('<i class="far fa-copy"></i> Copiar código PIX'),1800);}catch(e){$('#gpPixCode').trigger('select');document.execCommand('copy');} });
})();
</script>
