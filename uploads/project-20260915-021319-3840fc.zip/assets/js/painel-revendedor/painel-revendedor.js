$(document).ready(function(){

    user_online_cad("revendedor");

});