$(document).ready(function(){
    $("#form-public-busca").on("submit", function(e){
        e.preventDefault(); 

        const sti = $("input[name=input-public-busca]").val();

        var esp = "";
        for(var ei = 0; ei<sti.length; ei++){
            esp += " ";
        }
        if(sti == esp){
            return false;
        }
        const parsed = sti.normalize('NFD').replace(/([\u0300-\u036f]|[^0-9a-zA-Z ])/g, '');

        var str = parsed.replace(/[ ]/g,"-");
    
        var busca = str.toLowerCase(); 
        window.location.href = SITE_URL+ "/stream/busca/"+busca+"/pagina/1"; 
    });

    $("#submit-public-busca").on("click", function(){
        $("#form-public-busca").trigger("submit");           
    });
}) 