$("#videojs-player").on('contextmenu', function(e) { e.preventDefault(); });

var acao = $("#stream-info").attr("data-acao");
var stream_assistindo_type = $("#stream-info").attr("data-type");
var stream_id = $("#stream-info").attr("data-id");
var episodio = $("#stream-info").attr("data-episodio");
var currentTime = 0;

function gpMime(ext){
  ext = String(ext || '').toLowerCase();
  if(ext === 'm3u8') return 'application/x-mpegURL';
  if(ext === 'webm') return 'video/webm';
  if(ext === 'mp4' || ext === 'm4v') return 'video/mp4';
  if(ext === 'ts') return 'video/mp2t';
  return '';
}

function gpShowMessage(msg){
  var box = document.getElementById('gp-player-diagnostic');
  if(!box){
    box = document.createElement('div');
    box.id = 'gp-player-diagnostic';
    box.style.cssText = 'padding:12px 20px;background:#111;color:#fff;font-size:16px;line-height:1.5;';
    var v = document.getElementById('videojs-player');
    if(v && v.parentNode) v.parentNode.parentNode.insertBefore(box, v.parentNode.nextSibling);
  }
  box.textContent = msg;
}

$.ajax({
  url: SITE_URL + '/controller/stream/stream_play.php?ajax=ajax',
  method: 'POST',
  cache: false,
  data: {acao:acao, stream_id:stream_id, episodio:episodio},
  success: function(res){
    try{
      var play = (typeof res === 'string') ? JSON.parse(res) : res;
      if(play.status !== 'ok'){
        ajax_error('Não foi possível carregar o player de vídeo');
        return;
      }

      var isHttpSource = /^http:\/\//i.test(play.player_url);
      if(window.location.protocol === 'https:' && isHttpSource){
        gpShowMessage('A fonte ainda foi retornada em HTTP. Verifique se o provedor possui HTTPS/porta TLS configurada. Esta versão tenta automaticamente o HTTPS informado pela API Xtream.');
        return;
      }

      var player = videojs('videojs-player', {
        controls: true,
        autoplay: false,
        preload: 'metadata',
        fluid: true,
        responsive: true,
        aspectRatio: '16:9',
        enableSmoothSeeking: true,
        html5: { vhs: { overrideNative: !videojs.browser.IS_SAFARI } },
        controlBar: { skipButtons: { forward: 10, backward: 10 } },
        userActions: { click: true }
      });

      // Não usa o poster nativo do Video.js. Em alguns Chromes Android ele cria
      // um <img> interno que pode exibir o pequeno ícone de imagem quebrada.
      try {
        player.poster('');
        var initialTech = player.tech(true);
        if(initialTech && initialTech.el()){
          initialTech.el().removeAttribute('poster');
          initialTech.el().poster = '';
        }
      } catch(e){}

      // Poster próprio: só é criado depois de validar a capa. Se a imagem falhar,
      // nada é renderizado e o player permanece com fundo preto, sem ícone quebrado.
      var posterUrl = $("#stream-info").attr("data-image") || '';
      var customPoster = null;
      function gpHideCustomPoster(){
        if(customPoster) customPoster.style.display = 'none';
      }
      if(/^https?:\/\//i.test(posterUrl)){
        var posterProbe = new Image();
        posterProbe.onload = function(){
          try {
            var root = player.el();
            if(!root) return;
            customPoster = document.createElement('div');
            customPoster.className = 'gp-custom-poster';
            var bg = document.createElement('div');
            bg.className = 'gp-custom-poster-bg';
            bg.style.backgroundImage = 'url("' + posterUrl.replace(/"/g, '%22') + '")';
            var fg = document.createElement('div');
            fg.className = 'gp-custom-poster-fg';
            fg.style.backgroundImage = 'url("' + posterUrl.replace(/"/g, '%22') + '")';
            customPoster.appendChild(bg);
            customPoster.appendChild(fg);
            root.insertBefore(customPoster, root.firstChild);
          } catch(e){}
        };
        posterProbe.onerror = function(){ customPoster = null; };
        posterProbe.src = posterUrl;
      }
      // Esconde a capa imediatamente quando o usuário inicia a reprodução.
      // Alguns Chromes Android demoram para disparar 'playing', então cobrimos
      // também firstplay/timeupdate e o clique no botão grande.
      player.on('play firstplay playing', gpHideCustomPoster);
      player.on('timeupdate', function(){
        try { if(player.currentTime() > 0) gpHideCustomPoster(); } catch(e){}
      });
      try {
        var bigPlay = player.getChild('BigPlayButton');
        if(bigPlay) bigPlay.on('click', function(){ gpHideCustomPoster(); });
      } catch(e){}


      var mime = gpMime(play.container_extension);
      if(mime) player.src({src: play.player_url, type: mime});
      else player.src(play.player_url);

      if(play.stream_assistindo_time !== ''){
        player.one('loadedmetadata', function(){
          try { player.currentTime(parseInt(play.stream_assistindo_time, 10) || 0); } catch(e){}
        });
      }


      // Filmes: se a API não informa a duração (ou devolve 00:00:00),
      // usa a duração real do próprio arquivo assim que os metadados carregarem.
      player.on('loadedmetadata loadeddata durationchange', function(){
        if(stream_assistindo_type !== 'movie') return;
        var d = Number(player.duration());
        if(!isFinite(d) || d <= 0) return;
        var totalSecs = Math.max(1, Math.round(d));
        var totalMins = Math.max(1, Math.round(totalSecs / 60));
        var h = Math.floor(totalMins / 60), m = totalMins % 60;
        var durationText = h > 0 ? (h + 'h' + (m > 0 ? ' ' + m + 'min' : '')) : (m + 'min');
        var el = document.getElementById('movie-duration');
        if(el){
          var value = el.querySelector('.gp-duration-value');
          if(value) value.textContent = durationText;
          else {
            var icon = el.querySelector('i');
            el.textContent = '';
            if(icon) el.appendChild(icon);
            el.appendChild(document.createTextNode(durationText));
          }
          el.style.display = '';
        }
      });

      player.on('error', function(){
        var er = player.error();
        var extra = (er && er.message) ? er.message : 'falha ao abrir a mídia';
        gpShowMessage('Fonte direta: ' + play.player_url.replace(/\/[^/]+\/[^/]+\/(\d+\.)/, '/***/***/$1') + ' — ' + extra);
      });

      setInterval(function(){
        if(!player.paused()){
          currentTime = parseInt(player.currentTime(), 10) || 0;
          $.ajax({
            url: SITE_URL + '/controller/stream/stream_assistindo.php?ajax=ajax',
            method: 'POST',
            data: {acao:'stream_assistindo_cad',stream_assistindo_type:stream_assistindo_type,stream_assistindo_stream:stream_id,stream_assistindo_episodio:episodio,stream_assistindo_time:currentTime}
          });
        }
      },30000);
    }catch(error){
      gpShowMessage('Erro ao iniciar o player: ' + error.message);
    }
  },
  error: function(xhr){
    gpShowMessage('Falha ao obter a URL da mídia. HTTP ' + xhr.status + '.');
  }
});

// v21: video tech sem position/z-index customizado para compatibilidade Android.
