(function(){
  function markMissing(img){
    img.classList.remove('gp-cover-loaded');
    img.style.visibility='hidden';
    if(img.parentElement) img.parentElement.classList.add('gp-cover-missing');
  }
  function markLoaded(img){
    img.style.visibility='visible';
    img.classList.add('gp-cover-loaded');
    if(img.parentElement) img.parentElement.classList.remove('gp-cover-missing');
  }
  function proxify(url){
    if(!url) return '';
    if(/^http:\/\//i.test(url)) return SITE_URL+'/controller/stream/cover_proxy.php?url='+encodeURIComponent(url);
    return url;
  }
  function fallback(img){
    if(img.dataset.gpFallbackTried==='1'){ markMissing(img); return; }
    img.dataset.gpFallbackTried='1';
    var title=img.dataset.title||'';
    if(!title){ markMissing(img); return; }
    var type=img.dataset.type==='series'?'series':'movie';
    var year=img.dataset.year||'';
    fetch(SITE_URL+'/controller/stream/poster_fallback.php?type='+encodeURIComponent(type)+'&title='+encodeURIComponent(title)+'&year='+encodeURIComponent(year),{credentials:'same-origin'})
      .then(function(r){ return r.ok?r.json():null; })
      .then(function(j){
        if(j&&j.status==='ok'&&j.poster){
          img.onload=function(){ markLoaded(img); };
          img.onerror=function(){ markMissing(img); };
          img.src=proxify(j.poster);
        } else markMissing(img);
      }).catch(function(){ markMissing(img); });
  }
  function init(img){
    if(!img || img.dataset.gpBound==='1') return;
    img.dataset.gpBound='1';
    img.style.visibility='hidden';
    img.addEventListener('load',function(){ if(img.naturalWidth>0) markLoaded(img); });
    img.addEventListener('error',function(){ fallback(img); });
    if(!img.getAttribute('src')) fallback(img);
    else if(img.complete){
      if(img.naturalWidth>0) markLoaded(img); else fallback(img);
    }
  }
  document.querySelectorAll('img.gp-cover-img').forEach(init);
  window.gpCoverInit=function(root){ (root||document).querySelectorAll('img.gp-cover-img').forEach(init); };
})();
