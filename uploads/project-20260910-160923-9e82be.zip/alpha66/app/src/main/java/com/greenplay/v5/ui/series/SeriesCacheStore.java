package com.greenplay.v5.ui.series;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.greenplay.v5.data.model.series.SeriesCategory;
import com.greenplay.v5.data.model.series.SeriesItem;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/** Last-known series catalog for instant opening while a fresh Xtream sync runs. */
public final class SeriesCacheStore {
    private static final String PREF = "green_play_v5_series_cache_v2_plus18";
    private final SharedPreferences prefs;
    private final Gson gson = new Gson();
    private final String scope;
    private static final Type SERIES = new TypeToken<List<SeriesItem>>(){}.getType();
    private static final Type CATEGORIES = new TypeToken<List<SeriesCategory>>(){}.getType();

    public SeriesCacheStore(Context context, String host, String user) {
        prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        scope = Integer.toHexString(((host == null ? "" : host) + "|" + (user == null ? "" : user)).hashCode());
    }

    public List<SeriesItem> series() {
        try {
            List<SeriesItem> rows = gson.fromJson(prefs.getString(scope + "_series", "[]"), SERIES);
            return rows == null ? new ArrayList<>() : rows;
        } catch (Exception e) { return new ArrayList<>(); }
    }

    public List<SeriesCategory> categories() {
        try {
            List<SeriesCategory> rows = gson.fromJson(prefs.getString(scope + "_categories", "[]"), CATEGORIES);
            return rows == null ? new ArrayList<>() : rows;
        } catch (Exception e) { return new ArrayList<>(); }
    }

    public void saveSeries(List<SeriesItem> rows) {
        prefs.edit().putString(scope + "_series", gson.toJson(rows == null ? java.util.Collections.emptyList() : rows)).apply();
    }

    public void saveCategories(List<SeriesCategory> rows) {
        prefs.edit().putString(scope + "_categories", gson.toJson(rows == null ? java.util.Collections.emptyList() : rows)).apply();
    }
}
