package com.greenplay.v5.data.repository;

import android.util.Base64;
import android.os.Handler;
import android.os.Looper;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.greenplay.v5.core.network.NetworkProvider;
import com.greenplay.v5.core.network.XtreamApi;
import com.greenplay.v5.data.model.tv.TvCategory;
import com.greenplay.v5.data.model.tv.TvChannel;
import com.greenplay.v5.data.model.tv.TvEpg;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public final class TvRepository {
    private static final ExecutorService PARSER = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    public interface CategoriesResult { void success(List<TvCategory> rows); void error(String message); }
    public interface ChannelsResult { void success(List<TvChannel> rows); void error(String message); }
    public interface EpgResult { void success(TvEpg epg); void error(String message); }

    private final XtreamApi api;
    private final String user;
    private final String pass;
    private final String host;

    public TvRepository(String host, String user, String pass) {
        this.host = com.greenplay.v5.core.network.HostNormalizer.normalize(host);
        api = NetworkProvider.xtream(host); this.user = user; this.pass = pass;
    }

    public void categories(CategoriesResult result) { categoriesAttempt(result, 0); }

    private void categoriesAttempt(CategoriesResult result, int attempt) {
        api.list(user, pass, "get_live_categories").enqueue(new Callback<JsonArray>() {
            @Override public void onResponse(Call<JsonArray> call, Response<JsonArray> response) {
                if (!response.isSuccessful() || response.body() == null) {
                    retryCategories(result, attempt, "Categorias de TV indisponíveis");
                    return;
                }
                List<TvCategory> out = new ArrayList<>(); out.add(new TvCategory("", "TODOS"));
                for (JsonElement e : response.body()) {
                    if (!e.isJsonObject()) continue; JsonObject o=e.getAsJsonObject();
                    String id=first(str(o,"category_id"),str(o,"id"),str(o,"cat_id"),str(o,"categoryId"));
                    String name=first(str(o,"category_name"),str(o,"name"),str(o,"title"),str(o,"category"),str(o,"group_title"));
                    if(!id.isEmpty()&&!name.isEmpty()) out.add(new TvCategory(id,name));
                }
                result.success(out);
            }
            @Override public void onFailure(Call<JsonArray> call, Throwable t) {
                retryCategories(result, attempt, "Falha ao carregar categorias");
            }
        });
    }

    private void retryCategories(CategoriesResult result, int attempt, String message) {
        if (attempt < 1) { MAIN.postDelayed(() -> categoriesAttempt(result, attempt + 1), 420L); }
        else result.error(message);
    }

    public void channels(String categoryId, ChannelsResult result) { channelsAttempt(categoryId, result, 0); }

    private void channelsAttempt(String categoryId, ChannelsResult result, int attempt) {
        Call<JsonArray> call = categoryId == null || categoryId.isEmpty()
                ? api.list(user, pass, "get_live_streams")
                : api.listByCategory(user, pass, "get_live_streams", categoryId);
        call.enqueue(new Callback<JsonArray>() {
            @Override public void onResponse(Call<JsonArray> c, Response<JsonArray> response) {
                final JsonArray body = response.body();
                if (!response.isSuccessful() || body == null) {
                    retryChannels(categoryId, result, attempt, "Canais indisponíveis");
                    return;
                }
                PARSER.execute(() -> {
                    List<TvChannel> out = new ArrayList<>();
                    for (JsonElement e : body) {
                        if (!e.isJsonObject()) continue;
                        JsonObject o=e.getAsJsonObject();
                        long id = longVal(o,"stream_id"); if (id<=0) continue;
                        String ext=str(o,"container_extension");
                        if(ext.isEmpty()) ext="ts";
                        out.add(new TvChannel(id,str(o,"name"),normalizeLogo(str(o,"stream_icon")),str(o,"category_id"),str(o,"epg_channel_id"),ext));
                    }
                    if (out.isEmpty() && attempt < 1) MAIN.postDelayed(() -> channelsAttempt(categoryId, result, attempt + 1), 520L);
                    else MAIN.post(() -> { if (out.isEmpty()) result.error("Nenhum canal recebido"); else result.success(out); });
                });
            }
            @Override public void onFailure(Call<JsonArray> c, Throwable t) {
                retryChannels(categoryId, result, attempt, "Falha ao carregar canais");
            }
        });
    }

    private void retryChannels(String categoryId, ChannelsResult result, int attempt, String message) {
        if (attempt < 1) { MAIN.postDelayed(() -> channelsAttempt(categoryId, result, attempt + 1), 520L); }
        else result.error(message);
    }

    public void epg(long streamId, EpgResult result) {
        api.shortEpg(user, pass, "get_short_epg", streamId, 6).enqueue(new Callback<JsonObject>() {
            @Override public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                TvEpg epg = new TvEpg();
                try {
                    JsonObject root=response.body(); JsonArray rows=root==null?null:root.getAsJsonArray("epg_listings");
                    if(rows!=null && rows.size()>0){
                        long now=System.currentTimeMillis()/1000L;
                        int currentIndex=0;
                        for(int i=0;i<rows.size();i++){
                            JsonObject row=rows.get(i).getAsJsonObject();
                            long start=epoch(row,"start_timestamp");
                            long stop=epoch(row,"stop_timestamp");
                            if(start>0 && stop>0 && now>=start && now<stop){currentIndex=i;break;}
                            if(start>0 && start<=now) currentIndex=i;
                        }
                        JsonObject n=rows.get(currentIndex).getAsJsonObject();
                        epg.nowTitle=decode(str(n,"title"));
                        epg.nowTime=clock(n);
                        epg.nowStart=epoch(n,"start_timestamp");
                        epg.nowStop=epoch(n,"stop_timestamp");
                        if(currentIndex+1<rows.size()){
                            JsonObject nx=rows.get(currentIndex+1).getAsJsonObject();
                            epg.nextTitle=decode(str(nx,"title"));
                            epg.nextTime=clock(nx);
                        }
                    }
                } catch(Exception ignored){}
                result.success(epg);
            }
            @Override public void onFailure(Call<JsonObject> call, Throwable t) { result.success(new TvEpg()); }
        });
    }


    private String normalizeLogo(String raw){
        if(raw==null)return "";
        String u=raw.trim();
        if(u.isEmpty())return "";
        u=u.replace("\\/", "/").replace(" ", "%20");
        if(u.startsWith("//")){
            String scheme=host.startsWith("https://")?"https:":"http:";
            return scheme+u;
        }
        if(u.startsWith("http://")||u.startsWith("https://"))return u;
        if(u.startsWith("/"))return host+u;
        return host+"/"+u;
    }

    private static String clock(JsonObject o){
        String raw=str(o,"start");
        if(raw.length()>=16) return raw.substring(11,16);
        return raw;
    }
    private static long epoch(JsonObject o,String k){
        try{
            JsonElement e=o.get(k); if(e==null||e.isJsonNull()) return 0L;
            if(e.getAsJsonPrimitive().isNumber()) return e.getAsLong();
            return Long.parseLong(e.getAsString());
        }catch(Exception e){return 0L;}
    }
    private static String decode(String raw){
        if(raw==null||raw.trim().isEmpty())return "Sem informação";
        try{
            byte[] decoded=Base64.decode(raw,Base64.DEFAULT);
            String text=new String(decoded, StandardCharsets.UTF_8).trim();
            if(!text.isEmpty() && text.chars().filter(ch->ch==0xFFFD).count()==0) return text;
        }catch(Exception ignored){}
        return raw.trim();
    }
    private static String first(String... values){ if(values!=null) for(String v:values) if(v!=null&&!v.trim().isEmpty()) return v.trim(); return ""; }
    private static String str(JsonObject o,String k){try{JsonElement e=o.get(k);return e==null||e.isJsonNull()?"":e.getAsString();}catch(Exception e){return "";}}
    private static long longVal(JsonObject o,String k){try{return o.get(k).getAsLong();}catch(Exception e){return 0;}}
}
