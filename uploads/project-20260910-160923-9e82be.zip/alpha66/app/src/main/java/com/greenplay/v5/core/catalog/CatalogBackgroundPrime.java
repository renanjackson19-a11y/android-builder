package com.greenplay.v5.core.catalog;

import android.content.Context;
import com.greenplay.v5.data.model.movie.Movie;
import com.greenplay.v5.data.model.movie.MovieCategory;
import com.greenplay.v5.data.model.series.SeriesItem;
import com.greenplay.v5.data.model.series.SeriesCategory;
import com.greenplay.v5.data.repository.MovieRepository;
import com.greenplay.v5.data.repository.SeriesRepository;
import com.greenplay.v5.ui.movies.MovieCacheStore;
import com.greenplay.v5.ui.series.SeriesCacheStore;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Prepara Filmes e Séries enquanto o usuário está na TV.
 *
 * O primeiro bloco do catálogo já é publicado em memória assim que chega, em vez
 * de esperar o JSON Xtream inteiro. O catálogo completo é salvo como último estado
 * válido para que a próxima abertura seja instantânea, mesmo depois de fechar o app.
 */
public final class CatalogBackgroundPrime {
    private static String activeKey = "";
    private static boolean moviesRunning = false;
    private static boolean seriesRunning = false;
    private static final ExecutorService PRIME_IO = Executors.newSingleThreadExecutor();

    private CatalogBackgroundPrime() {}

    /** Invalidates callbacks still arriving from a previous DNS/account. */
    public static synchronized void reset() {
        activeKey = "";
        moviesRunning = false;
        seriesRunning = false;
    }

    private static synchronized boolean current(String key) { return key.equals(activeKey); }

    public static void start(Context context, String host, String user, String pass) {
        final Context app = context.getApplicationContext();
        PRIME_IO.execute(() -> startInternal(app, host, user, pass));
    }

    private static synchronized void startInternal(Context context, String host, String user, String pass) {
        String key = (host == null ? "" : host.trim()) + "|" + (user == null ? "" : user.trim());
        if (!key.equals(activeKey)) {
            activeKey = key;
            moviesRunning = false;
            seriesRunning = false;
        }

        final Context app = context;
        final String requestKey = key;

        if (CatalogMemory.movies().isEmpty() && !moviesRunning) {
            moviesRunning = true;
            MovieRepository movieRepo = new MovieRepository(host, user, pass, true);
            MovieCacheStore movieCache = new MovieCacheStore(app, host, user);

            List<MovieCategory> cachedCategories = movieCache.categories();
            if (!cachedCategories.isEmpty()) CatalogMemory.setMovieCategories(cachedCategories);
            if (CatalogMemory.movieCategories().isEmpty()) {
                movieRepo.categories(new MovieRepository.CategoriesResult() {
                    @Override public void success(List<MovieCategory> rows) { PRIME_IO.execute(() -> {
                        if (!current(requestKey)) return;
                        CatalogMemory.setMovieCategories(rows);
                        movieCache.saveCategories(rows);
                    }); }
                    @Override public void error(String message) { }
                });
            }

            List<Movie> cachedMovies = movieCache.movies();
            if (!cachedMovies.isEmpty()) {
                CatalogMemory.setMovies(cachedMovies);
                warmMovies(cachedMovies, true);
            }

            movieRepo.moviesProgressive("", 24, 240, new MovieRepository.ProgressiveMoviesResult() {
                @Override public void partial(List<Movie> rows) { PRIME_IO.execute(() -> {
                    if (!current(requestKey)) return;
                    if (rows == null || rows.isEmpty()) return;
                    CatalogMemory.setMovies(rows);
                    warmMovies(rows, true);
                }); }

                @Override public void success(List<Movie> rows) { PRIME_IO.execute(() -> {
                    if (!current(requestKey)) return;
                    synchronized (CatalogBackgroundPrime.class) { moviesRunning = false; }
                    CatalogMemory.setMovies(rows);
                    movieCache.saveMovies(rows);
                    warmMovies(rows, false);
                }); }

                @Override public void error(String message) {
                    if (!current(requestKey)) return;
                    synchronized (CatalogBackgroundPrime.class) { moviesRunning = false; }
                }
            });
        }

        if (CatalogMemory.series().isEmpty() && !seriesRunning) {
            seriesRunning = true;
            SeriesRepository seriesRepo = new SeriesRepository(host, user, pass, true);
            SeriesCacheStore seriesCache = new SeriesCacheStore(app, host, user);

            List<SeriesCategory> cachedSeriesCategories = seriesCache.categories();
            if (!cachedSeriesCategories.isEmpty()) CatalogMemory.setSeriesCategories(cachedSeriesCategories);
            if (cachedSeriesCategories.isEmpty()) {
                seriesRepo.categories(new SeriesRepository.CategoriesResult() {
                    @Override public void success(List<SeriesCategory> rows) { PRIME_IO.execute(() -> { if (current(requestKey)) { CatalogMemory.setSeriesCategories(rows); seriesCache.saveCategories(rows); } }); }
                    @Override public void error(String message) { }
                });
            }

            List<SeriesItem> cachedSeries = seriesCache.series();
            if (!cachedSeries.isEmpty()) {
                CatalogMemory.setSeries(cachedSeries);
                warmSeries(cachedSeries, true);
            }

            seriesRepo.seriesProgressive("", 24, 240, new SeriesRepository.ProgressiveSeriesResult() {
                @Override public void partial(List<SeriesItem> rows) { PRIME_IO.execute(() -> {
                    if (!current(requestKey)) return;
                    if (rows == null || rows.isEmpty()) return;
                    CatalogMemory.setSeries(rows);
                    warmSeries(rows, true);
                }); }

                @Override public void success(List<SeriesItem> rows) { PRIME_IO.execute(() -> {
                    if (!current(requestKey)) return;
                    synchronized (CatalogBackgroundPrime.class) { seriesRunning = false; }
                    CatalogMemory.setSeries(rows);
                    seriesCache.saveSeries(rows);
                    warmSeries(rows, false);
                }); }

                @Override public void error(String message) {
                    if (!current(requestKey)) return;
                    synchronized (CatalogBackgroundPrime.class) { seriesRunning = false; }
                }
            });
        }
    }

    private static void warmMovies(List<Movie> rows, boolean priority) {
        ArrayList<String> art = new ArrayList<>();
        if (rows != null) {
            int max = priority ? Math.min(rows.size(), 48) : Math.min(rows.size(), 180);
            for (int i = 0; i < max; i++) {
                Movie m = rows.get(i);
                if (m != null && m.poster != null && !m.poster.trim().isEmpty()) art.add(m.poster);
            }
        }
        if (priority) CatalogCoverWarmer.warmPriority(art, 48, null);
        else CatalogCoverWarmer.enqueue(art);
    }

    private static void warmSeries(List<SeriesItem> rows, boolean priority) {
        ArrayList<String> art = new ArrayList<>();
        if (rows != null) {
            int max = priority ? Math.min(rows.size(), 48) : Math.min(rows.size(), 180);
            for (int i = 0; i < max; i++) {
                SeriesItem x = rows.get(i);
                if (x != null && x.cover != null && !x.cover.trim().isEmpty()) art.add(x.cover);
            }
        }
        if (priority) CatalogCoverWarmer.warmPriority(art, 48, null);
        else CatalogCoverWarmer.enqueue(art);
    }
}
