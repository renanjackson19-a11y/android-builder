package com.greenplay.v5.ui.movies;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.greenplay.v5.core.network.StreamUrlFactory;
import com.greenplay.v5.core.config.BrandingStore;
import com.greenplay.v5.core.config.BrandingUi;
import com.greenplay.v5.core.config.AppControlStore;
import com.greenplay.v5.core.player.VodProgressStore;
import com.greenplay.v5.core.session.SessionStore;
import com.greenplay.v5.data.model.movie.MovieDetails;
import com.greenplay.v5.data.repository.MovieRepository;
import com.greenplay.v5.databinding.ActivityMovieDetailBinding;
import com.greenplay.v5.ui.player.PlayerActivity;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

public final class MovieDetailActivity extends AppCompatActivity {
    private ActivityMovieDetailBinding b;
    private SessionStore session;
    private MovieRepository repo;
    private MovieFavoritesStore favorites;
    private long movieId;
    private String name;
    private String poster;
    private String year;
    private String rating;
    private String extension;
    private String directSource;
    private MovieDetails loaded;
    private VodProgressStore progressStore;
    private BrandingStore branding;
    private Target brandingBackgroundTarget;
    private AppControlStore control;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        b = ActivityMovieDetailBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        com.greenplay.v5.core.ui.UniversalUi.apply(this, b.getRoot());
        session = new SessionStore(this);
        branding = new BrandingStore(this);
        control = new AppControlStore(this);
        brandingBackgroundTarget = BrandingUi.applyBackground(b.getRoot(), branding);
        if (!session.isLogged()) { finish(); return; }
        movieId = getIntent().getLongExtra("id", 0L);
        if (movieId <= 0) { finish(); return; }
        name = safe(getIntent().getStringExtra("name"));
        poster = safe(getIntent().getStringExtra("poster"));
        year = safe(getIntent().getStringExtra("year"));
        rating = safe(getIntent().getStringExtra("rating"));
        extension = safe(getIntent().getStringExtra("extension"));
        directSource = safe(getIntent().getStringExtra("direct_source"));
        if (extension.isEmpty()) extension = "mp4";
        repo = new MovieRepository(session.host(), session.user(), session.pass(), true);
        favorites = new MovieFavoritesStore(this, session.host(), session.user());
        progressStore = new VodProgressStore(this);
        renderBase();
        b.movieDetailPlay.setOnClickListener(v -> chooseResumeAndPlay());
        b.movieDetailFavorite.setOnClickListener(v -> {
            favorites.toggle(movieId);
            updateFavorite();
        });
        loadDetails();
    }

    private void renderBase() {
        b.movieDetailTitle.setText(name.isEmpty() ? "FILME" : name);
        b.movieDetailMeta.setText(meta(year, rating, ""));
        String posterUrl=poster;
        if (posterUrl.isEmpty()) { String fallback=branding.movieCover(); if(fallback==null||fallback.trim().isEmpty()) fallback=branding.fallback(); posterUrl=branding.absolute(fallback); }
        if (!posterUrl.isEmpty()) Picasso.get().load(posterUrl).fit().centerCrop().noFade().into(b.movieDetailPoster);
        updateFavorite();
    }

    private void loadDetails() {
        b.movieDetailLoading.setVisibility(View.VISIBLE);
        repo.detail(movieId, new MovieRepository.DetailResult() {
            @Override public void success(MovieDetails detail) {
                loaded = detail;
                b.movieDetailLoading.setVisibility(View.GONE);
                if (!detail.name.isEmpty()) name = detail.name;
                if (!detail.poster.isEmpty()) poster = detail.poster;
                if (!detail.year.isEmpty()) year = detail.year;
                if (!detail.rating.isEmpty()) rating = detail.rating;
                if (!detail.extension.isEmpty()) extension = detail.extension;
                if (!detail.directSource.isEmpty()) directSource = detail.directSource;
                b.movieDetailTitle.setText(name);
                b.movieDetailPlot.setText(detail.plot.isEmpty() ? "Sinopse não informada." : detail.plot);
                b.movieDetailMeta.setText(meta(year, rating, detail.duration));
                b.movieDetailGenre.setText(line("Gênero", detail.genre));
                b.movieDetailRelease.setText(line("Lançamento", detail.releaseDate));
                b.movieDetailDirector.setText(line("Direção", detail.director));
                b.movieDetailCast.setText(line("Elenco", detail.cast));
                b.movieDetailCountry.setText(line("País", detail.country));
                if (!poster.isEmpty()) Picasso.get().load(poster).fit().centerCrop().noFade().into(b.movieDetailPoster);
                if (!detail.backdrop.isEmpty()) {
                    Picasso.get().load(detail.backdrop).fit().centerCrop().noFade().into(b.movieDetailBackdrop);
                }
            }
            @Override public void error(String message) {
                b.movieDetailLoading.setVisibility(View.GONE);
                b.movieDetailPlot.setText("Detalhes completos indisponíveis. O filme ainda pode ser reproduzido.");
            }
        });
    }

    private void chooseResumeAndPlay() {
        String key = progressKey();
        long saved = control.resumeEnabled() ? progressStore.position(key) : 0L;
        long duration = progressStore.duration(key);
        boolean valid = saved >= 15_000L && (duration <= 0L || saved < duration - 45_000L);
        if (!valid || !control.resumePrompt()) {
            play(valid ? saved : 0L);
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Continuar assistindo?")
                .setMessage("Você parou em " + clock(saved) + ".")
                .setPositiveButton("CONTINUAR", (dialog, which) -> play(saved))
                .setNegativeButton("COMEÇAR DO INÍCIO", (dialog, which) -> {
                    progressStore.clear(key);
                    play(0L);
                })
                .setNeutralButton("CANCELAR", null)
                .show();
    }

    private void play(long resumeMs) {
        String constructed = StreamUrlFactory.movie(session.host(), session.user(), session.pass(), movieId, extension);
        String primary = directSource.isEmpty() ? constructed : directSource;
        String fallback = primary.equals(constructed) ? "" : constructed;
        Intent i = new Intent(this, PlayerActivity.class);
        i.putExtra("url", primary);
        i.putExtra("fallback_url", fallback);
        i.putExtra("title", name);
        i.putExtra("media_type", "vod");
        i.putExtra("progress_key", progressKey());
        i.putExtra("resume_position", resumeMs);
        startActivity(i);
    }

    private String progressKey() {
        String raw = session.host() + "|" + session.user() + "|movie|" + movieId;
        return Integer.toHexString(raw.hashCode());
    }

    private static String clock(long millis) {
        long total = Math.max(0L, millis / 1000L);
        long h = total / 3600L;
        long m = (total % 3600L) / 60L;
        long s = total % 60L;
        return h > 0L
                ? String.format(java.util.Locale.US, "%02d:%02d:%02d", h, m, s)
                : String.format(java.util.Locale.US, "%02d:%02d", m, s);
    }

    private void updateFavorite() {
        boolean fav = favorites.isFavorite(movieId);
        b.movieDetailFavorite.setText(fav ? "★ FAVORITO" : "☆ FAVORITAR");
        b.movieDetailFavorite.setSelected(fav);
    }

    private static String meta(String year, String rating, String duration) {
        StringBuilder s = new StringBuilder();
        if (year != null && !year.trim().isEmpty() && !"0".equals(year.trim()) && !"0000".equals(year.trim())) s.append(year.trim());
        if (rating != null && !rating.trim().isEmpty() && !"0".equals(rating.trim()) && !"0.0".equals(rating.trim())) {
            if (s.length() > 0) s.append("   •   ");
            s.append("★ ").append(rating.trim());
        }
        if (duration != null && !duration.trim().isEmpty() && !"00:00:00".equals(duration.trim())) {
            if (s.length() > 0) s.append("   •   ");
            s.append(duration.trim());
        }
        return s.toString();
    }

    private static String line(String label, String value) {
        return value == null || value.trim().isEmpty() ? "" : label + ":  " + value.trim();
    }

    private static String safe(String v) { return v == null ? "" : v.trim(); }
}
