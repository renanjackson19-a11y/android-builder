package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * V189 — Kids e HOT com a mesma linguagem visual de Filmes/Séries:
 * menu lateral, busca, Todos, Favoritos, categorias e grade de capas.
 *
 * KIDS: mistura Filmes + Séries do painel, sem chamadas a cada clique.
 * HOT: "Todos" mostra as categorias +18 vindas do painel; ao clicar numa
 * categoria carrega Filmes + Séries daquela fonte. Não inclui TV ao vivo.
 */
public class SmartCatalogActivity extends Activity {
    private final ArrayList<ApiClient.Item> master=new ArrayList<>();
    private final ArrayList<ApiClient.Item> visible=new ArrayList<>();
    private final ArrayList<ApiClient.HotCategory> hotCategories=new ArrayList<>();

    private GridView grid;
    private Adapter adapter;
    private LinearLayout categoryList;
    private EditText search;
    private TextView status;
    private String mode="kids";
    private String selectedCategory="";
    private String query="";
    private boolean phone;
    private final Handler handler=new Handler();
    private Runnable searchTask;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        Ui.immersive(this);
        phone=Ui.phone(this);
        mode=clean(getIntent().getStringExtra("mode"),"kids").toLowerCase(Locale.ROOT);
        if(!"hot".equals(mode))mode="kids";
        setContentView(AppBackground.wrap(this,build()));
        if("hot".equals(mode))loadHotCategories();
        else loadKids();
    }

    @Override protected void onResume(){
        super.onResume();
        Ui.immersive(this);
        // Atualiza somente o estado dos favoritos; não recarrega o painel.
        if("__favorites".equals(selectedCategory))showFavorites();
    }

    private View build(){
        LinearLayout root=Ui.column(this);
        root.setBackgroundColor(Color.TRANSPARENT);
        root.addView(YellowNav.bar(this,"hot".equals(mode)?"HOT":"KIDS"),
                new LinearLayout.LayoutParams(-1,Ui.dp(this,64)));

        LinearLayout main=new LinearLayout(this);
        main.setPadding(Ui.dp(this,18),Ui.dp(this,8),Ui.dp(this,18),Ui.dp(this,12));

        LinearLayout rail=Ui.column(this);
        rail.setPadding(Ui.dp(this,10),Ui.dp(this,8),Ui.dp(this,10),Ui.dp(this,8));
        rail.setBackground(Ui.round(0xAA111315,12,this));

        search=new EditText(this);
        search.setSingleLine(true);
        search.setHint("⌕  Buscar");
        search.setHintTextColor(0xFFE5E5E5);
        search.setTextColor(Ui.TEXT);
        search.setTextSize(phone?11:13);
        search.setPadding(Ui.dp(this,14),0,Ui.dp(this,10),0);
        search.setBackground(Ui.stroke(0xFF3B3B3F,0xFF505055,7,this));
        rail.addView(search,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));

        TextView heading=Ui.text(this,
                "hot".equals(mode)?"HOT • CATEGORIAS":"KIDS • RECENTES",
                phone?9:10,Ui.GREEN,true);
        heading.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,Ui.dp(this,30));
        hp.topMargin=Ui.dp(this,6);
        rail.addView(heading,hp);

        ScrollView sc=new ScrollView(this);
        sc.setVerticalScrollBarEnabled(false);
        categoryList=Ui.column(this);
        sc.addView(categoryList,new ScrollView.LayoutParams(-1,-2));
        rail.addView(sc,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(Ui.dp(this,phone?142:158),-1);
        rp.rightMargin=Ui.dp(this,14);
        main.addView(rail,rp);

        LinearLayout right=Ui.column(this);
        status=Ui.text(this,"CARREGANDO",phone?10:11,0xFFE9F7EE,true);
        status.setGravity(Gravity.CENTER);
        status.setLetterSpacing(0.08f);
        status.setBackground(Ui.round(0x520A1510,16,this));
        LinearLayout.LayoutParams stp=new LinearLayout.LayoutParams(Ui.dp(this,190),Ui.dp(this,32));
        stp.gravity=Gravity.CENTER_HORIZONTAL;
        stp.bottomMargin=Ui.dp(this,7);
        right.addView(status,stp);

        grid=new GridView(this);
        grid.setNumColumns(phone?5:6);
        grid.setHorizontalSpacing(Ui.dp(this,phone?7:9));
        grid.setVerticalSpacing(Ui.dp(this,phone?8:10));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setClipToPadding(false);
        grid.setPadding(Ui.dp(this,2),0,Ui.dp(this,2),Ui.dp(this,8));
        adapter=new Adapter();
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((p,v,pos,id)->{
            if(pos>=0 && pos<visible.size())open(visible.get(pos));
        });
        right.addView(grid,new LinearLayout.LayoutParams(-1,0,1));
        main.addView(right,new LinearLayout.LayoutParams(0,-1,1));
        root.addView(main,new LinearLayout.LayoutParams(-1,0,1));

        search.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){
                query=s==null?"":s.toString().trim();
                if(searchTask!=null)handler.removeCallbacks(searchTask);
                searchTask=()->applyFilter();
                handler.postDelayed(searchTask,120);
            }
            public void afterTextChanged(Editable e){}
        });
        return root;
    }

    // ------------------------------------------------------
    // KIDS
    // ------------------------------------------------------
    private void loadKids(){
        renderKidsCategories(new ArrayList<>());
        final ArrayList<ApiClient.Item> all=new ArrayList<>();
        final AtomicInteger pending=new AtomicInteger(2);

        ApiClient.catalogPrepared("movie",1,120,"","","kids",new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){
                synchronized(all){if(p!=null)all.addAll(p.items);}
                finishKids(all,pending);
            }
            public void error(String m){finishKids(all,pending);}
        });
        ApiClient.catalogPrepared("series",1,100,"","","kids",new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){
                synchronized(all){if(p!=null)all.addAll(p.items);}
                finishKids(all,pending);
            }
            public void error(String m){finishKids(all,pending);}
        });
    }

    private void finishKids(ArrayList<ApiClient.Item> all,AtomicInteger pending){
        if(pending.decrementAndGet()!=0)return;
        runOnUiThread(()->{
            master.clear();
            master.addAll(dedupe(all));
            sortNewest(master);
            ArrayList<String> cats=new ArrayList<>();
            Set<String> seen=new LinkedHashSet<>();
            for(ApiClient.Item i:master){
                String g=clean(i.group,"");
                if(!g.isEmpty() && seen.add(g.toLowerCase(Locale.ROOT)))cats.add(g);
            }
            renderKidsCategories(cats);
            selectedCategory="";
            applyFilter();
            status.setVisibility(master.isEmpty()?View.VISIBLE:View.GONE);
            if(master.isEmpty())status.setText("Nenhum conteúdo Kids encontrado");
        });
    }

    private void renderKidsCategories(List<String> cats){
        categoryList.removeAllViews();
        addSide("Todos","");
        addSide("★ FAVORITOS","__favorites");
        if(cats!=null)for(String c:cats)addSide(c,c);
    }

    // ------------------------------------------------------
    // HOT
    // ------------------------------------------------------
    private void loadHotCategories(){
        categoryList.removeAllViews();
        addSide("Todos","");
        addSide("★ FAVORITOS","__favorites");

        ApiClient.hotCategories(new ApiClient.Callback<List<ApiClient.HotCategory>>(){
            public void ok(List<ApiClient.HotCategory> cats){
                runOnUiThread(()->{
                    hotCategories.clear();
                    if(cats!=null)hotCategories.addAll(cats);
                    categoryList.removeAllViews();
                    addSide("Todos","");
                    addSide("★ FAVORITOS","__favorites");
                    for(ApiClient.HotCategory h:hotCategories)
                        addSide(clean(h.name,"HOT"),"hot:"+h.sourceId+":"+clean(h.name,"HOT"));

                    showHotCategoryCovers();
                });
            }
            public void error(String m){
                runOnUiThread(()->{
                    status.setText("Não foi possível carregar HOT");
                    status.setVisibility(View.VISIBLE);
                });
            }
        });
    }

    private void showHotCategoryCovers(){
        selectedCategory="";
        master.clear();
        long sid=-100000L;
        for(ApiClient.HotCategory h:hotCategories){
            ApiClient.Item i=new ApiClient.Item();
            i.id=sid--;
            i.type="hot_category";
            i.name=clean(h.name,"HOT");
            i.group=i.name;
            i.logo=h.cover;
            i.backdrop=h.cover;
            i.sourceId=h.sourceId;
            master.add(i);
        }
        applyFilter();
        status.setVisibility(master.isEmpty()?View.VISIBLE:View.GONE);
        if(master.isEmpty())status.setText("Nenhuma categoria HOT disponível");
        renderSelected();
    }

    private void loadHotCategory(ApiClient.HotCategory h){
        if(h==null)return;
        status.setText("CARREGANDO");
        status.setVisibility(View.VISIBLE);
        final ArrayList<ApiClient.Item> all=new ArrayList<>();
        final AtomicInteger pending=new AtomicInteger(2);

        ApiClient.catalogAdult("movie",1,100,h.name,h.sourceId,new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){
                synchronized(all){if(p!=null)all.addAll(p.items);}
                finishHotContent(all,pending);
            }
            public void error(String m){finishHotContent(all,pending);}
        });
        ApiClient.catalogAdult("series",1,100,h.name,h.sourceId,new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){
                synchronized(all){if(p!=null)all.addAll(p.items);}
                finishHotContent(all,pending);
            }
            public void error(String m){finishHotContent(all,pending);}
        });
    }

    private void finishHotContent(ArrayList<ApiClient.Item> all,AtomicInteger pending){
        if(pending.decrementAndGet()!=0)return;
        runOnUiThread(()->{
            master.clear();
            master.addAll(dedupe(all));
            sortNewest(master);
            applyFilter();
            status.setVisibility(master.isEmpty()?View.VISIBLE:View.GONE);
            if(master.isEmpty())status.setText("Nenhum conteúdo nesta categoria");
        });
    }

    // ------------------------------------------------------
    // SIDEBAR / FILTERS
    // ------------------------------------------------------
    private void addSide(String label,String key){
        boolean selected=key.equals(selectedCategory);
        TextView b=Ui.text(this,label,phone?9:11,selected?Color.BLACK:0xFFE7EBE8,selected);
        b.setGravity(Gravity.CENTER);
        b.setMaxLines(1);
        b.setFocusable(true); b.setClickable(true);
        b.setPadding(Ui.dp(this,8),0,Ui.dp(this,8),0);
        Ui.focus(b,this,
                selected?Ui.gradient(Ui.GREEN,Ui.GREEN_2,7,this):Ui.round(0xFF3A3A3E,7,this),
                Ui.stroke(0xFF45454A,Ui.GREEN,7,this));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,Ui.dp(this,40));
        p.topMargin=Ui.dp(this,4);
        categoryList.addView(b,p);
        b.setOnClickListener(v->select(key));
    }

    private void select(String key){
        selectedCategory=clean(key,"");
        if("__favorites".equals(selectedCategory)){showFavorites();return;}

        if("hot".equals(mode)){
            if(selectedCategory.isEmpty()){showHotCategoryCovers();return;}
            if(selectedCategory.startsWith("hot:")){
                String[] parts=selectedCategory.split(":",3);
                int source=0;try{source=Integer.parseInt(parts[1]);}catch(Exception ignored){}
                String name=parts.length>2?parts[2]:"";
                for(ApiClient.HotCategory h:hotCategories){
                    if(h.sourceId==source && clean(h.name,"").equals(name)){loadHotCategory(h);break;}
                }
                renderSelected();
            }
            return;
        }
        applyFilter();
        renderSelected();
    }

    private void showFavorites(){
        master.clear();
        for(ApiClient.Item i:LocalStore.favorites(this)){
            if(i==null)continue;
            String t=clean(i.type,"");
            if(!"movie".equals(t)&&!"series".equals(t))continue;
            if("kids".equals(mode) && !kidsMatch(i))continue;
            master.add(i);
        }
        sortNewest(master);
        applyFilter();
        status.setVisibility(master.isEmpty()?View.VISIBLE:View.GONE);
        if(master.isEmpty())status.setText("Nenhum favorito aqui");
        renderSelected();
    }

    private void applyFilter(){
        visible.clear();
        String q=query.toLowerCase(Locale.ROOT);
        for(ApiClient.Item i:master){
            if(i==null)continue;
            if("kids".equals(mode) && !selectedCategory.isEmpty()
                    && !"__favorites".equals(selectedCategory)
                    && !clean(i.group,"").equalsIgnoreCase(selectedCategory))continue;

            if(!q.isEmpty()){
                String hay=(clean(i.name,"")+" "+clean(i.group,"")).toLowerCase(Locale.ROOT);
                if(!hay.contains(q))continue;
            }
            visible.add(i);
        }
        adapter.notifyDataSetChanged();
        if(!visible.isEmpty())grid.requestFocus();
    }

    private void renderSelected(){
        if("kids".equals(mode)){
            ArrayList<String> cats=new ArrayList<>();
            Set<String> seen=new LinkedHashSet<>();
            // categorias atuais são derivadas do snapshot principal quando necessário
            for(ApiClient.Item i:master){
                String g=clean(i.group,"");
                if(!g.isEmpty()&&seen.add(g.toLowerCase(Locale.ROOT)))cats.add(g);
            }
            // Não reduz o menu ao abrir favoritos.
            if(!"__favorites".equals(selectedCategory) && selectedCategory.isEmpty())
                renderKidsCategories(cats);
        }else{
            categoryList.removeAllViews();
            addSide("Todos","");
            addSide("★ FAVORITOS","__favorites");
            for(ApiClient.HotCategory h:hotCategories)
                addSide(clean(h.name,"HOT"),"hot:"+h.sourceId+":"+clean(h.name,"HOT"));
        }
    }

    private boolean kidsMatch(ApiClient.Item i){
        String g=(clean(i.group,"")+" "+clean(i.name,"")).toLowerCase(Locale.ROOT);
        return g.contains("kids")||g.contains("infantil")||g.contains("desenho")
                ||g.contains("criança")||g.contains("crianca")||g.contains("family");
    }

    // ------------------------------------------------------
    // OPEN
    // ------------------------------------------------------
    private void open(ApiClient.Item i){
        if(i==null)return;
        if("hot_category".equals(i.type)){
            for(ApiClient.HotCategory h:hotCategories)
                if(h.sourceId==i.sourceId && clean(h.name,"").equals(clean(i.name,""))){
                    selectedCategory="hot:"+h.sourceId+":"+clean(h.name,"HOT");
                    loadHotCategory(h); renderSelected(); return;
                }
            return;
        }
        if("series".equals(i.type)){
            Intent in=new Intent(this,SeriesActivity.class);
            in.putExtra("id",i.id);
            in.putExtra("title",clean(i.seriesTitle,i.name));
            in.putExtra("name",i.name);
            in.putExtra("logo",i.logo);
            in.putExtra("backdrop",i.backdrop);
            in.putExtra("synopsis",i.synopsis);
            in.putExtra("group",i.group);
            in.putExtra("year",i.year);
            startActivity(in);
        }else{
            Intent in=new Intent(this,DetailActivity.class);
            MainActivity.putItem(in,i);
            startActivity(in);
        }
    }

    private ArrayList<ApiClient.Item> dedupe(List<ApiClient.Item> in){
        LinkedHashMap<String,ApiClient.Item> m=new LinkedHashMap<>();
        if(in!=null)for(ApiClient.Item i:in){
            if(i==null)continue;
            String key=i.id>0?"id:"+i.id:
                    clean(i.type,"")+"|"+clean(i.name,"").toLowerCase(Locale.ROOT)+"|"+i.year;
            ApiClient.Item old=m.get(key);
            if(old==null || score(i)>score(old))m.put(key,i);
        }
        return new ArrayList<>(m.values());
    }

    private int score(ApiClient.Item i){
        return (clean(i.logo,"").isEmpty()?0:2)+(clean(i.backdrop,"").isEmpty()?0:3)
                +(clean(i.synopsis,"").isEmpty()?0:1);
    }

    private void sortNewest(List<ApiClient.Item> list){
        Collections.sort(list,(a,b)->{
            int ay=a==null?0:a.year,by=b==null?0:b.year;
            if(ay!=by)return Integer.compare(by,ay);
            return Long.compare(b==null?0:b.id,a==null?0:a.id);
        });
    }

    private String clean(String s,String fallback){
        if(s==null)return fallback;
        String x=s.trim();
        return x.isEmpty()||"null".equalsIgnoreCase(x)?fallback:x;
    }

    @Override public void onBackPressed(){AppExit.confirm(this);}

    private class Adapter extends BaseAdapter {
        public int getCount(){return visible.size();}
        public Object getItem(int p){return visible.get(p);}
        public long getItemId(int p){return visible.get(p).id;}

        public View getView(int pos,View reuse,android.view.ViewGroup parent){
            ApiClient.Item i=visible.get(pos);
            LinearLayout card=reuse instanceof LinearLayout?(LinearLayout)reuse:Ui.column(SmartCatalogActivity.this);
            card.removeAllViews();
            card.setFocusable(true);card.setClickable(true);
            card.setPadding(Ui.dp(SmartCatalogActivity.this,2),Ui.dp(SmartCatalogActivity.this,2),
                    Ui.dp(SmartCatalogActivity.this,2),Ui.dp(SmartCatalogActivity.this,3));
            Ui.focus(card,SmartCatalogActivity.this,
                    Ui.round(0x20000000,5,SmartCatalogActivity.this),
                    Ui.stroke(0x33182218,Ui.GREEN,5,SmartCatalogActivity.this));

            ImageView img=new ImageView(SmartCatalogActivity.this);
            img.setScaleType(ImageView.ScaleType.CENTER_CROP);
            img.setBackgroundColor(0xFF101612);
            ImageLoader.intoPoster(SmartCatalogActivity.this,img,clean(i.logo,i.backdrop));
            int imageH=Ui.dp(SmartCatalogActivity.this,phone?150:198);
            card.addView(img,new LinearLayout.LayoutParams(-1,imageH));

            TextView name=Ui.text(SmartCatalogActivity.this,clean(i.name,"Conteúdo"),phone?9:11,Color.WHITE,false);
            name.setMaxLines(1);
            name.setPadding(Ui.dp(SmartCatalogActivity.this,5),Ui.dp(SmartCatalogActivity.this,4),Ui.dp(SmartCatalogActivity.this,4),0);
            card.addView(name,new LinearLayout.LayoutParams(-1,Ui.dp(SmartCatalogActivity.this,phone?27:30)));

            String meta="hot_category".equals(i.type)?"ABRIR CATEGORIA":
                    (i.year>0?String.valueOf(i.year):clean(i.group,""));
            TextView sub=Ui.text(SmartCatalogActivity.this,meta,phone?8:9,
                    "hot_category".equals(i.type)?Ui.GREEN:0xFFAEB8B1,false);
            sub.setMaxLines(1);
            sub.setPadding(Ui.dp(SmartCatalogActivity.this,5),0,0,0);
            card.addView(sub,new LinearLayout.LayoutParams(-1,Ui.dp(SmartCatalogActivity.this,phone?22:25)));

            card.setOnClickListener(v->open(i));
            return card;
        }
    }
}
