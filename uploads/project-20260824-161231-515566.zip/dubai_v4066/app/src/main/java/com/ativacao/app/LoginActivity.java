package com.ativacao.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class LoginActivity extends Activity {
    private EditText user,pass; private TextView message,serverBadge,enter,trial; private ImageView bgImage; private boolean phone; private int trialHours=3;
    @Override public void onCreate(Bundle b){super.onCreate(b);ApiClient.setUserToken(Session.token(this));getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);Ui.immersive(this);if(Session.isLogged(this)){openHome();return;}phone=Ui.phone(this);setContentView(build());checkServer();}
    @Override protected void onResume(){super.onResume();Ui.immersive(this);}

    private View build(){
        FrameLayout root=new FrameLayout(this); root.setBackgroundColor(Color.BLACK);
        bgImage=new ImageView(this); bgImage.setScaleType(ImageView.ScaleType.CENTER_CROP); bgImage.setBackgroundColor(Color.rgb(2,10,6)); root.addView(bgImage,new FrameLayout.LayoutParams(-1,-1));
        View shade=new View(this); shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0xE9000C06,0xB7000805,0xD9000000})); root.addView(shade,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout shell=new LinearLayout(this); shell.setOrientation(LinearLayout.HORIZONTAL); shell.setGravity(Gravity.CENTER_VERTICAL); shell.setPadding(Ui.dp(this,phone?28:52),Ui.dp(this,22),Ui.dp(this,phone?28:52),Ui.dp(this,22)); root.addView(shell,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout brand=Ui.column(this); brand.setGravity(Gravity.CENTER); brand.setPadding(Ui.dp(this,12),0,Ui.dp(this,32),0);
        TextView mark=Ui.text(this,"▷  DUBAI PLAY",phone?28:40,Color.WHITE,true); mark.setGravity(Gravity.CENTER); brand.addView(mark,new LinearLayout.LayoutParams(-1,Ui.dp(this,70)));
        TextView tag=Ui.text(this,"TV, FILMES E SÉRIES SEM COMPLICAÇÃO.",phone?12:15,0xFF35E86B,true); tag.setGravity(Gravity.CENTER); brand.addView(tag,new LinearLayout.LayoutParams(-1,Ui.dp(this,36)));
        TextView dev=Ui.text(this,"ID Dispositivo: "+DeviceInfo.macOrId(this)+"\nVersão: 4.0.66",9,0xFFB3BAB5,false); dev.setLineSpacing(0,1.35f); LinearLayout.LayoutParams dv=new LinearLayout.LayoutParams(-1,Ui.dp(this,58));dv.topMargin=Ui.dp(this,70);brand.addView(dev,dv);
        shell.addView(brand,new LinearLayout.LayoutParams(0,-1,0.95f));

        LinearLayout right=Ui.column(this); right.setGravity(Gravity.CENTER_VERTICAL); right.setPadding(Ui.dp(this,24),Ui.dp(this,10),0,Ui.dp(this,10));
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL); TextView head=Ui.text(this,"Entre na sua conta",phone?23:30,Color.WHITE,true);top.addView(head,new LinearLayout.LayoutParams(0,Ui.dp(this,48),1)); serverBadge=Ui.text(this,"● VERIFICANDO",9,Ui.GOLD,true);serverBadge.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);top.addView(serverBadge,new LinearLayout.LayoutParams(Ui.dp(this,160),Ui.dp(this,40)));right.addView(top,new LinearLayout.LayoutParams(-1,Ui.dp(this,52)));
        TextView desc=Ui.text(this,"Digite seu usuário e senha para acessar o aplicativo.",10,0xFFB4B8B6,false);right.addView(desc,new LinearLayout.LayoutParams(-1,Ui.dp(this,34)));
        right.addView(label("Usuário"),new LinearLayout.LayoutParams(-1,Ui.dp(this,24)));user=field("Por favor insira seu usuário",false);right.addView(user,new LinearLayout.LayoutParams(-1,Ui.dp(this,52)));
        TextView sl=label("Senha");LinearLayout.LayoutParams slp=new LinearLayout.LayoutParams(-1,Ui.dp(this,24));slp.topMargin=Ui.dp(this,9);right.addView(sl,slp);pass=field("Por favor insira sua senha",true);right.addView(pass,new LinearLayout.LayoutParams(-1,Ui.dp(this,52)));

        enter=Ui.primaryButton(this,"ENTRAR");LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,Ui.dp(this,50));ep.topMargin=Ui.dp(this,16);right.addView(enter,ep);
        TextView test=Ui.button(this,"◉   TESTAR CONEXÃO");LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,Ui.dp(this,46));tp.topMargin=Ui.dp(this,10);right.addView(test,tp);
        trial=Ui.button(this,"TESTE AUTOMÁTICO • 3 HORAS");LinearLayout.LayoutParams trp=new LinearLayout.LayoutParams(-1,Ui.dp(this,40));trp.topMargin=Ui.dp(this,9);right.addView(trial,trp);
        message=Ui.text(this,"",10,Ui.MUTED,false);message.setGravity(Gravity.CENTER);right.addView(message,new LinearLayout.LayoutParams(-1,Ui.dp(this,28)));
        TextView help=Ui.text(this,"Problemas para acessar? Teste sua conexão.",9,0xFF9EA4A0,false);help.setGravity(Gravity.CENTER);right.addView(help,new LinearLayout.LayoutParams(-1,Ui.dp(this,26)));

        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(0,-1,1.05f);rp.leftMargin=Ui.dp(this,24);shell.addView(right,rp);
        enter.setOnClickListener(v->doLogin()); trial.setOnClickListener(v->doTrial()); test.setOnClickListener(v->showDiagnostic()); pass.setOnEditorActionListener((v,a,e)->{doLogin();return true;}); user.requestFocus(); return root;
    }
    private TextView label(String s){return Ui.text(this,s,10,Color.WHITE,true);}
    private EditText field(String hint,boolean password){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(0xFF727B86);e.setTextColor(Color.WHITE);e.setTextSize(phone?12:14);e.setSingleLine(true);e.setPadding(Ui.dp(this,18),0,Ui.dp(this,18),0);e.setBackground(Ui.stroke(0xD9141921,0xFF31404B,20,this));if(password)e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);e.setOnFocusChangeListener((v,f)->e.setBackground(Ui.stroke(0xD9141921,f?Ui.GREEN:0xFF31404B,20,this)));return e;}
    private void doLogin(){String u=user.getText().toString().trim(),p=pass.getText().toString();if(u.isEmpty()||p.isEmpty()){message.setText("Informe usuário e senha.");message.setTextColor(Ui.RED);return;}enter.setEnabled(false);enter.setText("ENTRANDO...");message.setText("Validando acesso...");message.setTextColor(Ui.MUTED);ApiClient.login(u,p,DeviceInfo.macOrId(this),new ApiClient.Callback<ApiClient.LoginResult>(){public void ok(ApiClient.LoginResult r){runOnUiThread(()->{Session.save(LoginActivity.this,r.username,r.expiresAt,r.plan,r.adultAccess,r.bouquet,r.userToken);ApiClient.setUserToken(r.userToken);message.setText("Preparando catálogo e capas...");CatalogPreloader.start(LoginActivity.this,true,()->runOnUiThread(()->openHome()));});}public void error(String m){runOnUiThread(()->{enter.setEnabled(true);enter.setText("ENTRAR");message.setText(m);message.setTextColor(Ui.RED);});}});}
    private void checkServer(){ApiClient.statusInfo(new ApiClient.Callback<ApiClient.AppStatus>(){public void ok(ApiClient.AppStatus st){runOnUiThread(()->{serverBadge.setText("● SERVIDOR ONLINE");serverBadge.setTextColor(Ui.GREEN);trialHours=Math.max(1,st.trialHours);trial.setVisibility(View.VISIBLE);trial.setEnabled(st.trialEnabled);trial.setText((st.trialEnabled?"TESTE AUTOMÁTICO • ":"TESTE INDISPONÍVEL • ")+trialHours+(trialHours==1?" HORA":" HORAS"));if(st.loginBackground!=null&&!st.loginBackground.trim().isEmpty())ImageLoader.into(LoginActivity.this,bgImage,st.loginBackground);});}public void error(String m){runOnUiThread(()->{serverBadge.setText("● SERVIDOR OFFLINE");serverBadge.setTextColor(Ui.RED);trial.setEnabled(false);trial.setText("TESTE AUTOMÁTICO • SERVIDOR OFFLINE");});}});}
    private void doTrial(){if(trial==null)return;trial.setEnabled(false);trial.setText("CRIANDO TESTE...");message.setText("Gerando acesso de teste...");message.setTextColor(Ui.MUTED);ApiClient.trial(DeviceInfo.macOrId(this),new ApiClient.Callback<ApiClient.LoginResult>(){public void ok(ApiClient.LoginResult r){runOnUiThread(()->{Session.save(LoginActivity.this,r.username,r.expiresAt,r.plan,r.adultAccess,r.bouquet,r.userToken);ApiClient.setUserToken(r.userToken);message.setText("Preparando catálogo e capas...");CatalogPreloader.start(LoginActivity.this,true,()->runOnUiThread(()->openHome()));});}public void error(String m){runOnUiThread(()->{trial.setEnabled(true);trial.setText("TESTE AUTOMÁTICO • "+trialHours+(trialHours==1?" HORA":" HORAS"));message.setText(m);message.setTextColor(Ui.RED);});}});}
    private boolean hasNetwork(){try{ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);NetworkInfo n=cm==null?null:cm.getActiveNetworkInfo();return n!=null&&n.isConnected();}catch(Throwable e){return false;}}
    private void showDiagnostic(){final Dialog d=new Dialog(this);d.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout box=Ui.column(this);box.setPadding(Ui.dp(this,24),Ui.dp(this,20),Ui.dp(this,24),Ui.dp(this,20));box.setBackground(Ui.stroke(Ui.PANEL,Ui.BORDER,18,this));TextView t=Ui.text(this,"Diagnóstico de rede",18,Ui.TEXT,true);t.setGravity(Gravity.CENTER);box.addView(t,new LinearLayout.LayoutParams(-1,Ui.dp(this,40)));LinearLayout steps=new LinearLayout(this);steps.setGravity(Gravity.CENTER);TextView a=step("BOX",Ui.GREEN),b=step("REDE",hasNetwork()?Ui.GREEN:Ui.RED),c=step("INTERNET",hasNetwork()?Ui.GREEN:Ui.RED),s=step("SERVIDOR",Ui.MUTED);for(TextView v:new TextView[]{a,b,c,s}){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(Ui.dp(this,95),Ui.dp(this,60));p.leftMargin=Ui.dp(this,5);p.rightMargin=Ui.dp(this,5);steps.addView(v,p);}box.addView(steps,new LinearLayout.LayoutParams(-1,Ui.dp(this,72)));TextView result=Ui.text(this,"Testando servidor...",11,Ui.MUTED,true);result.setGravity(Gravity.CENTER);box.addView(result,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));TextView close=Ui.button(this,"FECHAR");close.setOnClickListener(v->d.dismiss());box.addView(close,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));d.setContentView(box);Window w=d.getWindow();d.show();if(w!=null){w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));w.setLayout(Math.min(Ui.dp(this,520),getResources().getDisplayMetrics().widthPixels-Ui.dp(this,24)),WindowManager.LayoutParams.WRAP_CONTENT);}ApiClient.status(new ApiClient.Callback<String>(){public void ok(String x){runOnUiThread(()->{s.setTextColor(Ui.GREEN);result.setText("✓ Servidor online e acessível");result.setTextColor(Ui.GREEN);});}public void error(String m){runOnUiThread(()->{s.setTextColor(Ui.RED);result.setText("Falha: "+m);result.setTextColor(Ui.RED);});}});}
    private TextView step(String txt,int color){TextView v=Ui.text(this,"●\n"+txt,10,color,true);v.setGravity(Gravity.CENTER);v.setBackground(Ui.stroke(Color.rgb(12,16,20),color,11,this));return v;}
    private void openHome(){Intent in=new Intent(this,LiveTvActivity.class);in.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(in);finish();}
}
