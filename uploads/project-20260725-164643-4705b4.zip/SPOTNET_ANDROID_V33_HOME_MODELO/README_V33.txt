SPOTNET MUSIC V33 — HOME MODELO PREMIUM

Alterações:
- Home reconstruída no padrão da referência enviada.
- Cabeçalho com menu, Spotnet Music, notificação e conta.
- Banner grande vindo do painel.
- Busca premium na tela inicial.
- Categorias em cards com ícones e subtítulos.
- Seções com botão Ver todas e cards verticais.
- Toque curto na música inicia a reprodução e prepara a fila.
- Toque longo abre a lista completa da seção.
- Navegação inferior: Início, Buscar, Biblioteca e Conta.
- Mini player com anterior, play/pausa e próxima.

Base preservada:
- API automática do painel.
- Reprodução em segundo plano.
- Conta, plano, renovação e indicação.
- Logo, splash e identidade visual via painel.

Validação:
- XML validado.
- Estrutura e chaves Java verificadas.
- APK não compilado neste ambiente porque o gradlew tenta acessar services.gradle.org.
