package com.ativacao.app;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class ApiClient {
    static final ExecutorService IO = Executors.newFixedThreadPool(4);

    interface Callback<T> { void ok(T value); void error(String message); }

    static class Item {
        long id;
        String name = "";
        String logo = "";
        String backdrop = "";
        String group = "";
        String synopsis = "";
        String type = "";
        int year = 0;
    }

    static class HomeData {
        String name = "Dubai Play";
        int liveCount;
        int movieCount;
        int seriesCount;
        Item hero;
        final List<Item> live = new ArrayList<>();
        final List<Item> movies = new ArrayList<>();
        final List<Item> series = new ArrayList<>();
    }

    static class CatalogPage {
        int page = 1;
        int pages = 1;
        int total = 0;
        final List<Item> items = new ArrayList<>();
        final List<String> categories = new ArrayList<>();
    }

    static class EpgInfo {
        String nowTitle = "";
        String nowStart = "";
        String nowStop = "";
        String nextTitle = "";
        String nextStart = "";
    }

    static void status(Callback<String> cb) {
        IO.execute(() -> {
            try {
                JSONObject o = new JSONObject(request(Config.API_BASE_URL + "status.php", false));
                cb.ok(o.optString("name", "Dubai Play"));
            } catch (Exception e) { cb.error(message(e)); }
        });
    }

    static void home(Callback<HomeData> cb) {
        IO.execute(() -> {
            try {
                JSONObject root = new JSONObject(request(Config.API_BASE_URL + "home.php", true));
                HomeData h = new HomeData();
                h.name = root.optString("name", "Dubai Play");
                JSONObject c = root.optJSONObject("counts");
                if (c != null) {
                    h.liveCount = c.optInt("live", 0);
                    h.movieCount = c.optInt("movie", 0);
                    h.seriesCount = c.optInt("series", 0);
                }
                h.hero = parseItem(root.optJSONObject("hero"));
                JSONObject featured = root.optJSONObject("featured");
                if (featured != null) {
                    parseArray(featured.optJSONArray("live"), h.live, "live");
                    parseArray(featured.optJSONArray("movie"), h.movies, "movie");
                    parseArray(featured.optJSONArray("series"), h.series, "series");
                }
                cb.ok(h);
            } catch (Exception e) { cb.error(message(e)); }
        });
    }

    static void catalog(String type, int page, int limit, String search, Callback<CatalogPage> cb) {
        IO.execute(() -> {
            try {
                StringBuilder url = new StringBuilder(Config.API_BASE_URL)
                        .append("catalog.php?type=").append(URLEncoder.encode(type, "UTF-8"))
                        .append("&page=").append(Math.max(1, page))
                        .append("&limit=").append(Math.max(12, Math.min(100, limit)));
                if (search != null && !search.trim().isEmpty()) {
                    url.append("&search=").append(URLEncoder.encode(search.trim(), "UTF-8"));
                }
                JSONObject root = new JSONObject(request(url.toString(), true));
                CatalogPage out = new CatalogPage();
                out.page = root.optInt("page", 1);
                out.pages = root.optInt("pages", 1);
                out.total = root.optInt("total", 0);
                parseArray(root.optJSONArray("items"), out.items, root.optString("type", ""));
                JSONArray cats = root.optJSONArray("categories");
                if (cats != null) for (int i=0;i<cats.length();i++) out.categories.add(cats.optString(i, ""));
                cb.ok(out);
            } catch (Exception e) { cb.error(message(e)); }
        });
    }

    static void epg(long streamId, Callback<EpgInfo> cb) {
        IO.execute(() -> {
            try {
                JSONObject root = new JSONObject(request(Config.API_BASE_URL + "epg.php?stream_id=" + streamId + "&limit=12", true));
                EpgInfo info = new EpgInfo();
                JSONObject now = root.optJSONObject("now");
                JSONObject next = root.optJSONObject("next");
                if (now != null) {
                    info.nowTitle = now.optString("title", "");
                    info.nowStart = now.optString("start_time", "");
                    info.nowStop = now.optString("stop_time", "");
                }
                if (next != null) {
                    info.nextTitle = next.optString("title", "");
                    info.nextStart = next.optString("start_time", "");
                }
                cb.ok(info);
            } catch (Exception e) { cb.error(message(e)); }
        });
    }

    static String streamUrl(long id) {
        try {
            return Config.API_BASE_URL + "stream.php?id=" + id + "&app_token=" + URLEncoder.encode(Config.APP_TOKEN, "UTF-8");
        } catch (Exception e) { return ""; }
    }

    private static Item parseItem(JSONObject o) {
        if (o == null) return null;
        Item item = new Item();
        item.id = o.optLong("id");
        item.name = o.optString("name", "Sem nome");
        item.logo = o.optString("logo", "");
        item.backdrop = o.optString("backdrop", o.optString("backdrop_url", ""));
        item.group = o.optString("group_title", "");
        item.synopsis = o.optString("synopsis", "");
        item.type = o.optString("type", "");
        item.year = o.optInt("release_year", 0);
        return item;
    }

    private static void parseArray(JSONArray a, List<Item> out, String type) {
        if (a == null) return;
        for (int i = 0; i < a.length(); i++) {
            Item item = parseItem(a.optJSONObject(i));
            if (item != null) { if (item.type == null || item.type.isEmpty()) item.type = type; out.add(item); }
        }
    }

    private static String request(String url, boolean authenticated) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
        con.setConnectTimeout(12000);
        con.setReadTimeout(30000);
        con.setInstanceFollowRedirects(true);
        con.setRequestProperty("Accept", "application/json");
        con.setRequestProperty("User-Agent", "DubaiPlayTV/1.2 Android");
        if (authenticated) con.setRequestProperty("X-App-Token", Config.APP_TOKEN);
        int code = con.getResponseCode();
        InputStream in = code >= 200 && code < 300 ? con.getInputStream() : con.getErrorStream();
        StringBuilder sb = new StringBuilder();
        if (in != null) {
            BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();
        }
        con.disconnect();
        if (code == 401) throw new Exception("Painel ainda não recebeu o patch de conexão automática");
        if (code < 200 || code >= 300) throw new Exception("Servidor respondeu HTTP " + code);
        return sb.toString();
    }

    private static String message(Exception e) {
        String m = e.getMessage();
        return m == null || m.trim().isEmpty() ? "Falha de conexão" : m;
    }
}
