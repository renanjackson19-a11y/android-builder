package com.ativacao.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

public class SettingsActivity extends Activity {
    @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(build());}

    private View build(){
        LinearLayout root=Ui.column(this);root.setBackgroundColor(Ui.BG);root.setPadding(Ui.dp(this,38),Ui.dp(this,30),Ui.dp(this,38),Ui.dp(this,30));
        TextView title=Ui.text(this,"Configurações",28,Ui.TEXT,true);root.addView(title,new LinearLayout.LayoutParams(-1,Ui.dp(this,52)));
        TextView sub=Ui.text(this,"Dubai Play conectado automaticamente ao seu painel",14,Ui.MUTED,false);root.addView(sub,new LinearLayout.LayoutParams(-1,Ui.dp(this,40)));

        LinearLayout card=Ui.column(this);card.setPadding(Ui.dp(this,22),Ui.dp(this,18),Ui.dp(this,22),Ui.dp(this,18));card.setBackground(Ui.stroke(Ui.PANEL,Ui.BORDER,16,this));
        card.addView(Ui.text(this,"SERVIDOR",11,Ui.PURPLE,true),new LinearLayout.LayoutParams(-1,Ui.dp(this,28)));
        card.addView(Ui.text(this,Config.PANEL_URL,17,Ui.TEXT,true),new LinearLayout.LayoutParams(-1,Ui.dp(this,36)));
        TextView auto=Ui.text(this,"● Conexão automática • sem chave manual",13,Ui.GREEN,true);card.addView(auto,new LinearLayout.LayoutParams(-1,Ui.dp(this,32)));
        root.addView(card,new LinearLayout.LayoutParams(-1,Ui.dp(this,120)));

        LinearLayout actions=new LinearLayout(this);actions.setPadding(0,Ui.dp(this,20),0,0);
        TextView test=Ui.primaryButton(this,"TESTAR CONEXÃO");TextView clear=Ui.button(this,"LIMPAR CAPAS");TextView back=Ui.button(this,"VOLTAR");
        actions.addView(test,new LinearLayout.LayoutParams(Ui.dp(this,190),Ui.dp(this,52)));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(Ui.dp(this,170),Ui.dp(this,52));cp.leftMargin=Ui.dp(this,12);actions.addView(clear,cp);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(Ui.dp(this,130),Ui.dp(this,52));bp.leftMargin=Ui.dp(this,12);actions.addView(back,bp);root.addView(actions);
        TextView result=Ui.text(this,"",14,Ui.MUTED,false);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,Ui.dp(this,60));rp.topMargin=Ui.dp(this,12);root.addView(result,rp);
        TextView about=Ui.text(this,"Dubai Play TV • versão 1.2.0 • Android TV / TV Box",12,Color.rgb(92,106,130),false);root.addView(about,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));

        test.setOnClickListener(v->{result.setText("Testando conexão...");result.setTextColor(Ui.MUTED);ApiClient.home(new ApiClient.Callback<ApiClient.HomeData>(){public void ok(ApiClient.HomeData h){runOnUiThread(()->{result.setText("✓ Conectado • "+h.liveCount+" canais • "+h.movieCount+" filmes • "+h.seriesCount+" séries");result.setTextColor(Ui.GREEN);});}public void error(String m){runOnUiThread(()->{result.setText("Falha: "+m);result.setTextColor(Ui.RED);});}});});
        clear.setOnClickListener(v->{ImageLoader.clear();result.setText("Capas em memória limpas.");result.setTextColor(Ui.GREEN);});
        back.setOnClickListener(v->finish());test.requestFocus();return root;
    }
}
