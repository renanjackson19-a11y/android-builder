package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class CatalogActivity extends Activity {
    private final List<ApiClient.Item> items = new ArrayList<>();
    private GridView grid;
    private TextView status;
    private Adapter adapter;
    private String type;
    private String query = "";
    private int page = 1;
    private int pages = 1;
    private int total = 0;
    private boolean loading = false;
    private final Handler handler = new Handler();
    private Runnable searchTask;

    @Override public void onCreate(Bundle b) { super.onCreate(b); immersive(); type=getIntent().getStringExtra("type");if(type==null)type="live";setContentView(build());load(1,true); }

    private View build(){
        LinearLayout root=Ui.column(this);root.setBackgroundColor(Ui.BG);root.setPadding(Ui.dp(this,28),Ui.dp(this,18),Ui.dp(this,28),Ui.dp(this,18));
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);
        TextView back=Ui.button(this,"‹  VOLTAR");back.setOnClickListener(v->finish());
        TextView title=Ui.text(this,getIntent().getStringExtra("title")==null?"Conteúdos":getIntent().getStringExtra("title"),24,Ui.TEXT,true);
        EditText search=new EditText(this);search.setHint("Pesquisar no catálogo...");search.setHintTextColor(Ui.MUTED);search.setTextColor(Ui.TEXT);search.setTextSize(14);search.setSingleLine(true);search.setPadding(Ui.dp(this,16),0,Ui.dp(this,16),0);search.setBackground(Ui.stroke(Ui.PANEL_2,Ui.BORDER,12,this));
        bar.addView(back,new LinearLayout.LayoutParams(Ui.dp(this,145),Ui.dp(this,48)));
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,Ui.dp(this,48),1);tp.leftMargin=Ui.dp(this,18);bar.addView(title,tp);
        bar.addView(search,new LinearLayout.LayoutParams(Ui.dp(this,330),Ui.dp(this,46)));
        root.addView(bar);
        status=Ui.text(this,"Carregando...",12,Ui.MUTED,false);root.addView(status,new LinearLayout.LayoutParams(-1,Ui.dp(this,38)));

        grid=new GridView(this);int sw=getResources().getConfiguration().screenWidthDp;grid.setNumColumns(sw>=1000?6:5);grid.setHorizontalSpacing(Ui.dp(this,12));grid.setVerticalSpacing(Ui.dp(this,12));grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);grid.setSelector(android.R.color.transparent);grid.setPadding(0,Ui.dp(this,4),0,Ui.dp(this,14));
        adapter=new Adapter();grid.setAdapter(adapter);root.addView(grid,new LinearLayout.LayoutParams(-1,0,1));
        grid.setOnScrollListener(new AbsListView.OnScrollListener(){public void onScrollStateChanged(AbsListView v,int s){}public void onScroll(AbsListView v,int first,int visible,int count){if(count>0&&!loading&&page<pages&&first+visible>=count-8)load(page+1,false);}});
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){query=s==null?"":s.toString();if(searchTask!=null)handler.removeCallbacks(searchTask);searchTask=()->load(1,true);handler.postDelayed(searchTask,500);}public void afterTextChanged(Editable e){}});
        back.requestFocus();return root;
    }

    private void load(int target,boolean reset){if(loading)return;loading=true;if(reset)status.setText("Buscando no catálogo...");ApiClient.catalog(type,target,72,query,new ApiClient.Callback<ApiClient.CatalogPage>(){public void ok(ApiClient.CatalogPage p){runOnUiThread(()->{loading=false;page=p.page;pages=p.pages;total=p.total;if(reset)items.clear();items.addAll(p.items);adapter.notifyDataSetChanged();status.setText(items.size()+" de "+total+" itens"+(pages>1?" • página "+page+"/"+pages:""));if(reset&&!items.isEmpty())grid.requestFocus();});}public void error(String m){runOnUiThread(()->{loading=false;status.setText("Não foi possível carregar • "+m);});}});}

    private class Adapter extends BaseAdapter {
        public int getCount(){return items.size();}public Object getItem(int p){return items.get(p);}public long getItemId(int p){return items.get(p).id;}
        public View getView(int p,View convert,android.view.ViewGroup parent){
            LinearLayout card;ImageView image;TextView title,meta;
            if(convert==null){card=Ui.column(CatalogActivity.this);card.setPadding(Ui.dp(CatalogActivity.this,7),Ui.dp(CatalogActivity.this,7),Ui.dp(CatalogActivity.this,7),Ui.dp(CatalogActivity.this,7));card.setFocusable(true);card.setClickable(true);Ui.focus(card,CatalogActivity.this);image=new ImageView(CatalogActivity.this);image.setId(101);image.setScaleType(ImageView.ScaleType.CENTER_CROP);image.setBackgroundColor(Ui.PANEL_2);card.addView(image,new LinearLayout.LayoutParams(-1,Ui.dp(CatalogActivity.this,"live".equals(type)?112:165)));title=Ui.text(CatalogActivity.this,"",13,Ui.TEXT,true);title.setId(102);title.setMaxLines(1);card.addView(title,new LinearLayout.LayoutParams(-1,Ui.dp(CatalogActivity.this,30)));meta=Ui.text(CatalogActivity.this,"",10,Ui.MUTED,false);meta.setId(103);meta.setMaxLines(1);card.addView(meta,new LinearLayout.LayoutParams(-1,Ui.dp(CatalogActivity.this,22)));convert=card;}else card=(LinearLayout)convert;
            image=convert.findViewById(101);title=convert.findViewById(102);meta=convert.findViewById(103);ApiClient.Item item=items.get(p);title.setText(item.name);String m=item.group==null||item.group.isEmpty()?"Dubai Play":item.group;if(item.year>0)m+=" • "+item.year;meta.setText(m);ImageLoader.into(CatalogActivity.this,image,item.logo);card.setOnClickListener(v->{Intent in=new Intent(CatalogActivity.this,PlayerActivity.class);in.putExtra("id",item.id);in.putExtra("name",item.name);in.putExtra("group",item.group);in.putExtra("type",type);in.putExtra("synopsis",item.synopsis);startActivity(in);});return convert;
        }
    }

    private void immersive(){getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);}
}
