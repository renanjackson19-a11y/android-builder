package com.ativacao.app;

import android.app.Activity;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

public class PlayerActivity extends Activity {
    private VideoView video;private ProgressBar loading;private TextView epgNow;private TextView epgNext;
    @Override public void onCreate(Bundle b){super.onCreate(b);immersive();FrameLayout root=new FrameLayout(this);root.setBackgroundColor(Color.BLACK);video=new VideoView(this);root.addView(video,new FrameLayout.LayoutParams(-1,-1));loading=new ProgressBar(this);root.addView(loading,new FrameLayout.LayoutParams(Ui.dp(this,52),Ui.dp(this,52),Gravity.CENTER));
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);top.setPadding(Ui.dp(this,22),0,Ui.dp(this,22),0);top.setBackgroundColor(0x99040911);TextView name=Ui.text(this,getIntent().getStringExtra("name")==null?"Dubai Play":getIntent().getStringExtra("name"),16,Color.WHITE,true);top.addView(name,new LinearLayout.LayoutParams(0,Ui.dp(this,54),1));TextView brand=Ui.text(this,"DUBAI PLAY",12,Color.rgb(205,193,255),true);brand.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);top.addView(brand,new LinearLayout.LayoutParams(Ui.dp(this,150),Ui.dp(this,54)));root.addView(top,new FrameLayout.LayoutParams(-1,Ui.dp(this,54),Gravity.TOP));
        String type=getIntent().getStringExtra("type");long id=getIntent().getLongExtra("id",0);if("live".equals(type)){LinearLayout guide=Ui.column(this);guide.setPadding(Ui.dp(this,22),Ui.dp(this,10),Ui.dp(this,22),Ui.dp(this,10));guide.setBackground(Ui.stroke(0xDD091321,0x553C4F6C,14,this));epgNow=Ui.text(this,"AGORA  Carregando programação...",14,Color.WHITE,true);epgNext=Ui.text(this,"A SEGUIR  —",12,Ui.MUTED,false);guide.addView(epgNow,new LinearLayout.LayoutParams(-1,Ui.dp(this,28)));guide.addView(epgNext,new LinearLayout.LayoutParams(-1,Ui.dp(this,24)));FrameLayout.LayoutParams gp=new FrameLayout.LayoutParams(-1,Ui.dp(this,70),Gravity.BOTTOM);gp.leftMargin=Ui.dp(this,18);gp.rightMargin=Ui.dp(this,18);gp.bottomMargin=Ui.dp(this,16);root.addView(guide,gp);}setContentView(root);
        String url=ApiClient.streamUrl(id);MediaController controls=new MediaController(this);controls.setAnchorView(video);video.setMediaController(controls);video.setOnPreparedListener(mp->{loading.setVisibility(View.GONE);mp.setScreenOnWhilePlaying(true);video.start();});video.setOnErrorListener((mp,what,extra)->{loading.setVisibility(View.GONE);Toast.makeText(this,"Não foi possível reproduzir este conteúdo.",Toast.LENGTH_LONG).show();return true;});video.setVideoURI(Uri.parse(url));video.requestFocus();if("live".equals(type))loadEpg(id);}
    private void loadEpg(long id){ApiClient.epg(id,new ApiClient.Callback<ApiClient.EpgInfo>(){public void ok(ApiClient.EpgInfo i){runOnUiThread(()->{if(epgNow!=null)epgNow.setText(i.nowTitle.isEmpty()?"AGORA  Programação não disponível":"AGORA  "+i.nowTitle);if(epgNext!=null)epgNext.setText(i.nextTitle.isEmpty()?"A SEGUIR  —":"A SEGUIR  "+i.nextTitle);});}public void error(String m){runOnUiThread(()->{if(epgNow!=null)epgNow.setText("AGORA  Programação não disponível");if(epgNext!=null)epgNext.setText("A SEGUIR  —");});}});}
    @Override protected void onStop(){if(video!=null)video.stopPlayback();super.onStop();}private void immersive(){getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);}
}
