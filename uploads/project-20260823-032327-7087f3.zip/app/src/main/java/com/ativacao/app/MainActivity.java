package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private TextView server;
    private TextView liveCount;
    private TextView movieCount;
    private TextView seriesCount;
    private TextView heroTitle;
    private TextView heroMeta;
    private TextView heroText;
    private ImageView heroImage;
    private TextView heroPlay;
    private LinearLayout featuredRow;
    private ApiClient.Item heroItem;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        immersive();
        setContentView(build());
        refresh();
    }

    @Override protected void onResume() { super.onResume(); immersive(); }

    private View build() {
        LinearLayout root = Ui.column(this);
        root.setBackgroundColor(Ui.BG);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(Ui.dp(this,32),Ui.dp(this,14),Ui.dp(this,32),Ui.dp(this,10));
        header.setBackgroundColor(Ui.BG_2);

        TextView logo = Ui.text(this,"▶",18,Color.WHITE,true);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(Ui.gradient(Ui.PURPLE, Ui.BLUE, 12, this));
        header.addView(logo,new LinearLayout.LayoutParams(Ui.dp(this,42),Ui.dp(this,42)));
        TextView brand=Ui.text(this,"DUBAI PLAY",22,Ui.TEXT,true);
        LinearLayout.LayoutParams brandP=new LinearLayout.LayoutParams(Ui.dp(this,190),Ui.dp(this,48));brandP.leftMargin=Ui.dp(this,12);header.addView(brand,brandP);

        TextView navHome=nav("INÍCIO");
        TextView navLive=nav("AO VIVO");
        TextView navMovie=nav("FILMES");
        TextView navSeries=nav("SÉRIES");
        navLive.setOnClickListener(v->open("live","Canais ao Vivo"));
        navMovie.setOnClickListener(v->open("movie","Filmes"));
        navSeries.setOnClickListener(v->open("series","Séries"));
        header.addView(navHome,new LinearLayout.LayoutParams(Ui.dp(this,90),Ui.dp(this,42)));
        header.addView(navLive,new LinearLayout.LayoutParams(Ui.dp(this,100),Ui.dp(this,42)));
        header.addView(navMovie,new LinearLayout.LayoutParams(Ui.dp(this,90),Ui.dp(this,42)));
        header.addView(navSeries,new LinearLayout.LayoutParams(Ui.dp(this,90),Ui.dp(this,42)));

        View spacer=new View(this);header.addView(spacer,new LinearLayout.LayoutParams(0,1,1));
        server=Ui.text(this,"● CONECTANDO",12,Ui.MUTED,true);server.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);header.addView(server,new LinearLayout.LayoutParams(Ui.dp(this,180),Ui.dp(this,42)));
        TextView settings=Ui.button(this,"⚙");settings.setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class)));LinearLayout.LayoutParams setP=new LinearLayout.LayoutParams(Ui.dp(this,52),Ui.dp(this,42));setP.leftMargin=Ui.dp(this,10);header.addView(settings,setP);
        root.addView(header,new LinearLayout.LayoutParams(-1,Ui.dp(this,68)));

        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);
        LinearLayout content=Ui.column(this);content.setPadding(Ui.dp(this,32),Ui.dp(this,22),Ui.dp(this,32),Ui.dp(this,30));

        FrameLayout hero=new FrameLayout(this);hero.setBackground(Ui.stroke(Ui.PANEL,Ui.BORDER,20,this));
        heroImage=new ImageView(this);heroImage.setScaleType(ImageView.ScaleType.CENTER_CROP);heroImage.setAlpha(.42f);heroImage.setBackgroundColor(Color.rgb(18,26,43));hero.addView(heroImage,new FrameLayout.LayoutParams(-1,-1));
        View shade=new View(this);shade.setBackground(new ColorDrawable(0x55000000));hero.addView(shade,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout heroInfo=Ui.column(this);heroInfo.setPadding(Ui.dp(this,34),Ui.dp(this,26),Ui.dp(this,34),Ui.dp(this,24));
        TextView badge=Ui.text(this,"DUBAI PLAY • DESTAQUE",12,Color.rgb(197,183,255),true);heroInfo.addView(badge,new LinearLayout.LayoutParams(-1,Ui.dp(this,32)));
        heroTitle=Ui.text(this,"Sua TV. Seus filmes. Suas séries.",31,Color.WHITE,true);heroTitle.setMaxLines(1);heroInfo.addView(heroTitle,new LinearLayout.LayoutParams(Ui.dp(this,720),Ui.dp(this,54)));
        heroMeta=Ui.text(this,"Conteúdo carregado diretamente do seu painel",13,Color.rgb(214,220,233),true);heroInfo.addView(heroMeta,new LinearLayout.LayoutParams(Ui.dp(this,720),Ui.dp(this,30)));
        heroText=Ui.text(this,"Uma experiência feita para Android TV e TV Box, com navegação rápida por controle remoto.",14,Color.rgb(200,208,223),false);heroText.setMaxLines(2);heroInfo.addView(heroText,new LinearLayout.LayoutParams(Ui.dp(this,700),Ui.dp(this,54)));
        LinearLayout heroActions=new LinearLayout(this);heroActions.setPadding(0,Ui.dp(this,10),0,0);
        heroPlay=Ui.primaryButton(this,"▶  ASSISTIR AGORA");heroPlay.setOnClickListener(v->playHero());
        TextView movies=Ui.button(this,"VER FILMES");movies.setOnClickListener(v->open("movie","Filmes"));
        heroActions.addView(heroPlay,new LinearLayout.LayoutParams(Ui.dp(this,190),Ui.dp(this,50)));
        LinearLayout.LayoutParams mvP=new LinearLayout.LayoutParams(Ui.dp(this,150),Ui.dp(this,50));mvP.leftMargin=Ui.dp(this,12);heroActions.addView(movies,mvP);
        heroInfo.addView(heroActions);
        hero.addView(heroInfo,new FrameLayout.LayoutParams(-1,-1));
        content.addView(hero,new LinearLayout.LayoutParams(-1,Ui.dp(this,250)));

        LinearLayout stats=new LinearLayout(this);stats.setPadding(0,Ui.dp(this,18),0,0);
        liveCount=statCard(stats,"AO VIVO","0",Ui.BLUE,"live");
        movieCount=statCard(stats,"FILMES","0",Ui.PURPLE,"movie");
        seriesCount=statCard(stats,"SÉRIES","0",Ui.GREEN,"series");
        content.addView(stats,new LinearLayout.LayoutParams(-1,Ui.dp(this,116)));

        TextView section=Ui.text(this,"Destaques para você",20,Ui.TEXT,true);LinearLayout.LayoutParams secP=new LinearLayout.LayoutParams(-1,Ui.dp(this,46));secP.topMargin=Ui.dp(this,14);content.addView(section,secP);
        HorizontalScrollView h=new HorizontalScrollView(this);h.setHorizontalScrollBarEnabled(false);featuredRow=new LinearLayout(this);featuredRow.setOrientation(LinearLayout.HORIZONTAL);h.addView(featuredRow);content.addView(h,new LinearLayout.LayoutParams(-1,Ui.dp(this,220)));

        scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        navHome.requestFocus();
        return root;
    }

    private TextView nav(String label){TextView t=Ui.text(this,label,12,Ui.MUTED,true);t.setGravity(Gravity.CENTER);t.setFocusable(true);t.setClickable(true);Ui.focus(t,this,Ui.round(Color.TRANSPARENT,10,this),Ui.stroke(Ui.PANEL_2,Ui.PURPLE,10,this));return t;}

    private TextView statCard(LinearLayout row,String title,String value,int accent,String type){
        LinearLayout card=Ui.column(this);card.setPadding(Ui.dp(this,20),Ui.dp(this,16),Ui.dp(this,20),Ui.dp(this,12));card.setFocusable(true);card.setClickable(true);Ui.focus(card,this);card.setOnClickListener(v->open(type,titleFor(type)));
        TextView t=Ui.text(this,title,12,accent,true);card.addView(t,new LinearLayout.LayoutParams(-1,Ui.dp(this,25)));
        TextView count=Ui.text(this,value,27,Ui.TEXT,true);card.addView(count,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));
        TextView sub=Ui.text(this,"disponíveis no catálogo",11,Ui.MUTED,false);card.addView(sub,new LinearLayout.LayoutParams(-1,Ui.dp(this,24)));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,Ui.dp(this,100),1);p.rightMargin=Ui.dp(this,14);row.addView(card,p);return count;
    }

    private void refresh(){
        ApiClient.status(new ApiClient.Callback<String>(){public void ok(String s){runOnUiThread(()->{server.setText("● SERVIDOR ONLINE");server.setTextColor(Ui.GREEN);});}public void error(String m){runOnUiThread(()->{server.setText("● SERVIDOR OFFLINE");server.setTextColor(Ui.RED);});}});
        ApiClient.home(new ApiClient.Callback<ApiClient.HomeData>(){
            public void ok(ApiClient.HomeData h){runOnUiThread(()->applyHome(h));}
            public void error(String m){runOnUiThread(()->{server.setText("● ATUALIZE O PAINEL");server.setTextColor(Ui.RED);heroTitle.setText("Conexão automática pendente");heroMeta.setText(m);heroText.setText("Instale o PATCH V1.7 no painel e abra o aplicativo novamente. Não é necessário digitar chave de API.");});}
        });
    }

    private void applyHome(ApiClient.HomeData h){
        liveCount.setText(String.valueOf(h.liveCount));movieCount.setText(String.valueOf(h.movieCount));seriesCount.setText(String.valueOf(h.seriesCount));
        heroItem=h.hero;
        if(h.hero!=null){heroTitle.setText(h.hero.name);String meta=(h.hero.group==null||h.hero.group.isEmpty()?"Destaque Dubai Play":h.hero.group);if(h.hero.year>0)meta+=" • "+h.hero.year;heroMeta.setText(meta);heroText.setText(h.hero.synopsis==null||h.hero.synopsis.trim().isEmpty()?"Assista agora no Dubai Play.":h.hero.synopsis);String img=h.hero.backdrop==null||h.hero.backdrop.isEmpty()?h.hero.logo:h.hero.backdrop;ImageLoader.into(this,heroImage,img);heroPlay.setVisibility(View.VISIBLE);}else{heroTitle.setText("Dubai Play");heroMeta.setText("Seu catálogo está conectado");heroText.setText("Adicione capas e destaques no painel para deixar esta tela ainda mais completa.");heroPlay.setVisibility(View.GONE);}
        List<ApiClient.Item> mix=new ArrayList<>();mix.addAll(h.movies);mix.addAll(h.series);mix.addAll(h.live);renderFeatured(mix);
    }

    private void renderFeatured(List<ApiClient.Item> items){featuredRow.removeAllViews();int max=Math.min(items.size(),18);for(int i=0;i<max;i++){ApiClient.Item item=items.get(i);LinearLayout card=Ui.column(this);card.setFocusable(true);card.setClickable(true);card.setPadding(Ui.dp(this,8),Ui.dp(this,8),Ui.dp(this,8),Ui.dp(this,8));Ui.focus(card,this);ImageView image=new ImageView(this);image.setScaleType(ImageView.ScaleType.CENTER_CROP);image.setBackgroundColor(Ui.PANEL_2);card.addView(image,new LinearLayout.LayoutParams(-1,Ui.dp(this,142)));TextView n=Ui.text(this,item.name,12,Ui.TEXT,true);n.setMaxLines(1);card.addView(n,new LinearLayout.LayoutParams(-1,Ui.dp(this,31)));TextView g=Ui.text(this,item.group==null||item.group.isEmpty()?"Dubai Play":item.group,10,Ui.MUTED,false);g.setMaxLines(1);card.addView(g,new LinearLayout.LayoutParams(-1,Ui.dp(this,24)));ImageLoader.into(this,image,item.logo);card.setOnClickListener(v->{Intent in=new Intent(this,PlayerActivity.class);in.putExtra("id",item.id);in.putExtra("name",item.name);in.putExtra("group",item.group);in.putExtra("type",item.type==null||item.type.isEmpty()?"movie":item.type);in.putExtra("synopsis",item.synopsis);startActivity(in);});LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(Ui.dp(this,190),Ui.dp(this,205));p.rightMargin=Ui.dp(this,12);featuredRow.addView(card,p);}}


    private void playHero(){if(heroItem==null)return;Intent in=new Intent(this,PlayerActivity.class);in.putExtra("id",heroItem.id);in.putExtra("name",heroItem.name);in.putExtra("group",heroItem.group);in.putExtra("type",heroItem.type==null||heroItem.type.isEmpty()?"movie":heroItem.type);in.putExtra("synopsis",heroItem.synopsis);startActivity(in);}
    private void open(String type,String title){Intent i=new Intent(this,CatalogActivity.class);i.putExtra("type",type);i.putExtra("title",title);startActivity(i);}
    private String titleFor(String type){if("live".equals(type))return "Canais ao Vivo";if("movie".equals(type))return "Filmes";return "Séries";}
    private void immersive(){getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);}
}
