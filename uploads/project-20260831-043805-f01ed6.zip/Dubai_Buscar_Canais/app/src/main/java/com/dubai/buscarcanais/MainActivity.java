package com.dubai.buscarcanais;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    private static final String PREFS = "dubai_buscar_canais";
    private static final String KEY_TARGETS = "targets";

    private final int bg = Color.rgb(10, 10, 14);
    private final int panel = Color.rgb(15, 16, 23);
    private final int panel2 = Color.rgb(20, 22, 30);
    private final int accent = Color.rgb(210, 42, 243);
    private final int accent2 = Color.rgb(144, 71, 255);
    private final int white = Color.rgb(242, 242, 242);
    private final int muted = Color.rgb(176, 176, 182);

    private LinearLayout statusTab;
    private LinearLayout connectionsTab;
    private Button statusBtn;
    private Button connectionsBtn;
    private TextView circleLabel;
    private TextView targetSummary;
    private TextView connText;
    private Switch httpSwitch;
    private Switch allAppsSwitch;
    private Button startStopBtn;

    private boolean capturing = false;
    private final Set<String> selectedPackages = new HashSet<>();
    private final List<String> connectionLog = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadPrefs();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);
        root.setPadding(0, statusBarTop(), 0, 0);

        root.addView(makeToolbar());
        root.addView(makeTabs());

        statusTab = buildStatusTab();
        connectionsTab = buildConnectionsTab();
        root.addView(statusTab, new LinearLayout.LayoutParams(-1, 0, 1f));
        root.addView(connectionsTab, new LinearLayout.LayoutParams(-1, 0, 1f));

        setContentView(root);
        showStatusTab();
        refreshSelections();
        refreshConnections();
        refreshCaptureUi();
    }

    private View makeToolbar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(14), dp(10), dp(14), dp(10));
        bar.setBackgroundColor(Color.rgb(11,11,16));

        TextView menu = icon("☰", 22);
        TextView title = tv("Dubai Buscar Canais", 20, white, true);
        title.setPadding(dp(14), 0, 0, 0);

        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.HORIZONTAL);
        left.setGravity(Gravity.CENTER_VERTICAL);
        left.addView(menu);
        left.addView(title);

        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.HORIZONTAL);
        right.setGravity(Gravity.CENTER_VERTICAL);
        right.addView(icon("▶", 20));
        TextView gear = icon("⚙", 20); gear.setPadding(dp(26),0,0,0); right.addView(gear);
        TextView more = icon("⋮", 22); more.setPadding(dp(26),0,0,0); right.addView(more);

        bar.addView(left, new LinearLayout.LayoutParams(0, -2, 1f));
        bar.addView(right);
        return bar;
    }

    private View makeTabs() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setBackgroundColor(Color.rgb(11,11,16));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(dp(8), dp(10), dp(8), 0);

        statusBtn = tabBtn("STATUS");
        connectionsBtn = tabBtn("CONEXÕES");
        statusBtn.setOnClickListener(v -> showStatusTab());
        connectionsBtn.setOnClickListener(v -> showConnectionsTab());

        row.addView(statusBtn, new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(connectionsBtn, new LinearLayout.LayoutParams(0, -2, 1f));

        wrap.addView(row);
        return wrap;
    }

    private LinearLayout buildStatusTab() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(24), dp(16), dp(16));

        LinearLayout circleWrap = new LinearLayout(this);
        circleWrap.setGravity(Gravity.CENTER_HORIZONTAL);
        circleWrap.setPadding(0, dp(8), 0, dp(18));
        circleLabel = new TextView(this);
        circleLabel.setTextColor(white);
        circleLabel.setTextSize(24);
        circleLabel.setGravity(Gravity.CENTER);
        circleLabel.setTypeface(Typeface.DEFAULT_BOLD);
        circleLabel.setBackground(circleBg(false));
        circleLabel.setLayoutParams(new LinearLayout.LayoutParams(dp(200), dp(200)));
        circleWrap.addView(circleLabel);
        content.addView(circleWrap);

        content.addView(sectionTitle("Servidor HTTP"));
        content.addView(sectionSub("Inicia um servidor HTTP para exportar o PCAP do seu próprio monitoramento."));
        LinearLayout httpRow = sectionCard();
        httpSwitch = new Switch(this);
        httpSwitch.setText("Ativado");
        httpSwitch.setTextColor(white);
        httpRow.addView(httpSwitch);
        content.addView(httpRow);

        content.addView(space(14));
        content.addView(sectionTitle("Aplicativos de destino"));
        content.addView(sectionSub("Escolha somente os seus aplicativos de TV/IPTV para acompanhar o tráfego visível."));
        LinearLayout appCard = sectionCard();
        appCard.setOrientation(LinearLayout.VERTICAL);
        targetSummary = tv("Nenhum aplicativo selecionado", 16, white, true);
        Button pickApps = actionBtn("SELECIONAR APLICATIVOS");
        pickApps.setOnClickListener(v -> showAppPicker());
        allAppsSwitch = new Switch(this);
        allAppsSwitch.setText("Capturar todos os apps (não recomendado)");
        allAppsSwitch.setTextColor(muted);
        allAppsSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> refreshSelections());
        appCard.addView(targetSummary);
        appCard.addView(space(10));
        appCard.addView(pickApps);
        appCard.addView(space(6));
        appCard.addView(allAppsSwitch);
        content.addView(appCard);

        content.addView(space(18));
        startStopBtn = actionBtn("INICIAR CAPTURA");
        startStopBtn.setOnClickListener(v -> toggleCapture());
        content.addView(startStopBtn);

        TextView hint = sectionSub("Base visual no estilo PCAPdroid. Esta versão prepara o fluxo, seleciona apps e organiza a interface do monitoramento.");
        hint.setPadding(0, dp(14), 0, dp(4));
        content.addView(hint);

        scroll.addView(content, new ScrollView.LayoutParams(-1, -1));

        LinearLayout holder = new LinearLayout(this);
        holder.setOrientation(LinearLayout.VERTICAL);
        holder.addView(scroll, new LinearLayout.LayoutParams(-1, -1));
        return holder;
    }

    private LinearLayout buildConnectionsTab() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(18), dp(16), dp(18));

        TextView title = sectionTitle("Conexões capturadas");
        content.addView(title);
        content.addView(sectionSub("Aqui aparecem os domínios, portas e observações do monitoramento iniciado."));

        LinearLayout card = sectionCard();
        card.setOrientation(LinearLayout.VERTICAL);
        connText = tv("Nenhuma conexão ainda.", 15, white, false);
        connText.setLineSpacing(0, 1.15f);
        card.addView(connText);
        content.addView(card);

        scroll.addView(content, new ScrollView.LayoutParams(-1, -1));
        LinearLayout holder = new LinearLayout(this);
        holder.setOrientation(LinearLayout.VERTICAL);
        holder.addView(scroll, new LinearLayout.LayoutParams(-1, -1));
        return holder;
    }

    private void showStatusTab() {
        statusTab.setVisibility(View.VISIBLE);
        connectionsTab.setVisibility(View.GONE);
        setTabState(true);
    }

    private void showConnectionsTab() {
        statusTab.setVisibility(View.GONE);
        connectionsTab.setVisibility(View.VISIBLE);
        setTabState(false);
    }

    private void setTabState(boolean statusActive) {
        styleTab(statusBtn, statusActive);
        styleTab(connectionsBtn, !statusActive);
    }

    private void styleTab(Button b, boolean active) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.TRANSPARENT);
        gd.setStroke(0, Color.TRANSPARENT);
        b.setBackground(gd);
        b.setTextColor(active ? white : muted);
        b.setAlpha(active ? 1f : 0.75f);
        b.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, active ? android.R.drawable.bottom_bar : 0);
    }

    private void toggleCapture() {
        capturing = !capturing;
        if (capturing) {
            connectionLog.clear();
            String time = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
            connectionLog.add("• " + time + "  Monitoramento iniciado");
            if (allAppsSwitch.isChecked()) {
                connectionLog.add("• Aplicativos de destino: todos os apps do aparelho");
            } else if (selectedPackages.isEmpty()) {
                connectionLog.add("• Nenhum aplicativo selecionado. Escolha seus apps de TV/IPTV.");
            } else {
                connectionLog.add("• Aplicativos selecionados: " + selectedPackages.size());
                for (String pkg : selectedPackages) {
                    connectionLog.add("    - " + pkg);
                }
            }
            if (httpSwitch.isChecked()) {
                connectionLog.add("• Servidor HTTP habilitado");
            } else {
                connectionLog.add("• Servidor HTTP desligado");
            }
            connectionLog.add("• Aguardando conexões visíveis...");
            showConnectionsTab();
        } else {
            String time = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
            connectionLog.add("• " + time + "  Monitoramento parado");
            Toast.makeText(this, "Captura parada", Toast.LENGTH_SHORT).show();
        }
        refreshCaptureUi();
        refreshConnections();
    }

    private void refreshCaptureUi() {
        circleLabel.setText(capturing ? "Capturando" : "Pronto");
        circleLabel.setBackground(circleBg(capturing));
        startStopBtn.setText(capturing ? "PARAR CAPTURA" : "INICIAR CAPTURA");
    }

    private GradientDrawable circleBg(boolean running) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(bg);
        g.setStroke(dp(2), running ? accent : Color.rgb(159, 79, 203));
        return g;
    }

    private void refreshSelections() {
        if (targetSummary == null) return;
        if (allAppsSwitch != null && allAppsSwitch.isChecked()) {
            targetSummary.setText("Modo amplo: todos os aplicativos do aparelho");
            return;
        }
        if (selectedPackages.isEmpty()) {
            targetSummary.setText("Nenhum aplicativo selecionado");
        } else {
            List<String> names = new ArrayList<>();
            PackageManager pm = getPackageManager();
            for (String pkg : selectedPackages) {
                try {
                    ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
                    names.add(pm.getApplicationLabel(ai) + "\n" + pkg);
                } catch (Exception e) {
                    names.add(pkg);
                }
            }
            Collections.sort(names);
            String txt = selectedPackages.size() + " app(s) selecionado(s)\n\n" + TextUtils.join("\n\n", names);
            targetSummary.setText(txt);
        }
    }

    private void refreshConnections() {
        if (connText == null) return;
        if (connectionLog.isEmpty()) {
            connText.setText("Nenhuma conexão ainda.\n\nInicie a captura, abra seu aplicativo de TV/IPTV e volte aqui para acompanhar o status.");
        } else {
            connText.setText(TextUtils.join("\n", connectionLog));
        }
    }

    private void showAppPicker() {
        try {
            PackageManager pm = getPackageManager();
            Intent launchIntent = new Intent(Intent.ACTION_MAIN, null);
            launchIntent.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ApplicationInfo> apps = pm.getInstalledApplications(PackageManager.GET_META_DATA);
            List<AppEntry> entries = new ArrayList<>();
            for (ApplicationInfo ai : apps) {
                if (pm.getLaunchIntentForPackage(ai.packageName) == null) continue;
                String label = String.valueOf(pm.getApplicationLabel(ai));
                if (label == null) label = ai.packageName;
                entries.add(new AppEntry(label, ai.packageName));
            }
            Collections.sort(entries, Comparator.comparing(a -> a.label.toLowerCase(Locale.ROOT)));

            ScrollView scroll = new ScrollView(this);
            LinearLayout wrap = new LinearLayout(this);
            wrap.setOrientation(LinearLayout.VERTICAL);
            wrap.setPadding(dp(8), dp(8), dp(8), dp(8));

            List<CheckBox> boxes = new ArrayList<>();
            for (AppEntry e : entries) {
                CheckBox cb = new CheckBox(this);
                cb.setText(e.label + "\n" + e.pkg);
                cb.setTextColor(white);
                cb.setChecked(selectedPackages.contains(e.pkg));
                cb.setTag(e.pkg);
                boxes.add(cb);
                wrap.addView(cb);
            }
            scroll.addView(wrap);

            new AlertDialog.Builder(this)
                    .setTitle("Selecionar aplicativos")
                    .setView(scroll)
                    .setPositiveButton("Salvar", (d, w) -> {
                        selectedPackages.clear();
                        for (CheckBox cb : boxes) {
                            if (cb.isChecked()) selectedPackages.add((String) cb.getTag());
                        }
                        savePrefs();
                        refreshSelections();
                    })
                    .setNegativeButton("Cancelar", null)
                    .show();
        } catch (Exception e) {
            Toast.makeText(this, "Falha ao listar apps: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void loadPrefs() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        selectedPackages.clear();
        selectedPackages.addAll(sp.getStringSet(KEY_TARGETS, new HashSet<>()));
    }

    private void savePrefs() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        sp.edit().putStringSet(KEY_TARGETS, new HashSet<>(selectedPackages)).apply();
    }

    private LinearLayout sectionCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        GradientDrawable g = new GradientDrawable();
        g.setColor(panel);
        g.setCornerRadius(dp(8));
        card.setBackground(g);
        return card;
    }

    private TextView sectionTitle(String s) {
        TextView t = tv(s, 18, white, true);
        t.setPadding(0, 0, 0, dp(2));
        return t;
    }

    private TextView sectionSub(String s) {
        TextView t = tv(s, 14, muted, false);
        return t;
    }

    private Button tabBtn(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setPadding(0, dp(10), 0, dp(12));
        b.setGravity(Gravity.CENTER);
        return b;
    }

    private Button actionBtn(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextColor(white);
        b.setAllCaps(false);
        b.setTextSize(15);
        GradientDrawable g = new GradientDrawable();
        g.setColor(panel2);
        g.setCornerRadius(dp(6));
        g.setStroke(dp(1), Color.rgb(61, 61, 84));
        b.setBackground(g);
        b.setPadding(dp(14), dp(12), dp(14), dp(12));
        return b;
    }

    private TextView tv(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView icon(String s, int sp) {
        TextView t = tv(s, sp, white, false);
        return t;
    }

    private View space(int dp) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(dp)));
        return v;
    }

    private int dp(int x) {
        return (int) (x * getResources().getDisplayMetrics().density + 0.5f);
    }

    private int statusBarTop() {
        return dp(4);
    }

    static class AppEntry {
        final String label;
        final String pkg;
        AppEntry(String label, String pkg) {
            this.label = label;
            this.pkg = pkg;
        }
    }
}
