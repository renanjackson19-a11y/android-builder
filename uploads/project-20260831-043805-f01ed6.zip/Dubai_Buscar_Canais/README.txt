DUBAI BUSCAR CANAIS - V2 PCAP STYLE

Esta versão remove a tela principal de colar M3U e usa o fluxo visual solicitado:
- Aba STATUS
- Aba CONEXÕES
- Botão grande Pronto/Capturando
- Seleção de aplicativos de destino
- Servidor HTTP (interface)
- Iniciar/Parar monitoramento

IMPORTANTE: este pacote contém o projeto Android-fonte. Para gerar o APK é necessário Android SDK/Gradle.
