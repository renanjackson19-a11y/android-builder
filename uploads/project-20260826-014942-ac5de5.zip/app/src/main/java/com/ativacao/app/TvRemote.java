package com.ativacao.app;

import android.app.Activity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

/** Navegação consistente por controle remoto / D-pad em TV Box e Android TV. */
final class TvRemote {
    private TvRemote() {}

    static void prepare(View root) {
        if (root == null) return;
        makeFocusableTree(root);
    }

    private static void makeFocusableTree(View v) {
        if (v == null) return;
        if (v.isClickable()) {
            v.setFocusable(true);
            v.setFocusableInTouchMode(false);
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            g.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS);
            for (int i = 0; i < g.getChildCount(); i++) makeFocusableTree(g.getChildAt(i));
        }
    }

    static boolean dispatch(Activity a, KeyEvent e) {
        if (a == null || e == null || e.getAction() != KeyEvent.ACTION_DOWN) return false;
        int key = e.getKeyCode();
        int direction = 0;
        switch (key) {
            case KeyEvent.KEYCODE_DPAD_UP:
            case KeyEvent.KEYCODE_CHANNEL_UP:
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                direction = View.FOCUS_UP; break;
            case KeyEvent.KEYCODE_DPAD_DOWN:
            case KeyEvent.KEYCODE_CHANNEL_DOWN:
            case KeyEvent.KEYCODE_MEDIA_NEXT:
                direction = View.FOCUS_DOWN; break;
            case KeyEvent.KEYCODE_DPAD_LEFT:
                direction = View.FOCUS_LEFT; break;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                direction = View.FOCUS_RIGHT; break;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
            case KeyEvent.KEYCODE_BUTTON_A: {
                View f = a.getCurrentFocus();
                if (f != null && !(f instanceof EditText)) {
                    f.performClick();
                    return true;
                }
                return false;
            }
            default: return false;
        }

        View current = a.getCurrentFocus();
        View root = a.getWindow() == null ? null : a.getWindow().getDecorView();
        if (current == null) {
            View first = findFirstFocusable(root);
            if (first != null) { first.requestFocus(); return true; }
            return false;
        }
        // EditText continua aceitando esquerda/direita para mover o cursor.
        if (current instanceof EditText && (direction == View.FOCUS_LEFT || direction == View.FOCUS_RIGHT)) return false;
        View next = current.focusSearch(direction);
        if (next != null && next != current && next.getVisibility() == View.VISIBLE && next.isEnabled()) {
            next.requestFocus();
            next.sendAccessibilityEvent(android.view.accessibility.AccessibilityEvent.TYPE_VIEW_FOCUSED);
            return true;
        }
        return false;
    }

    private static View findFirstFocusable(View v) {
        if (v == null || v.getVisibility() != View.VISIBLE || !v.isEnabled()) return null;
        if (v.isFocusable() && !(v instanceof ViewGroup)) return v;
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                View r = findFirstFocusable(g.getChildAt(i));
                if (r != null) return r;
            }
        }
        return v.isFocusable() ? v : null;
    }
}
