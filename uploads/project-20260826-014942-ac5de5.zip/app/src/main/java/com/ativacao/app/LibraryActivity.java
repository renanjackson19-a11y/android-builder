package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class LibraryActivity extends Activity {
    private boolean phone;
    private String mode;
    private final List<ApiClient.Item> items=new ArrayList<>();
    private GridView grid;
    private Adapter adapter;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);Ui.immersive(this);phone=Ui.phone(this);
        mode=getIntent().getStringExtra("mode");if(mode==null)mode="history";
        setContentView(build());
        TvRemote.prepare(getWindow().getDecorView());load();
    }

    private View build(){
        LinearLayout root=Ui.column(this);root.setBackgroundColor(Ui.BG);
        root.addView(YellowNav.bar(this,""),new LinearLayout.LayoutParams(-1,Ui.dp(this,64)));

        LinearLayout body=Ui.column(this);
        body.setPadding(Ui.dp(this,phone?18:30),Ui.dp(this,18),Ui.dp(this,phone?18:30),Ui.dp(this,20));
        TextView title=Ui.text(this,"favorites".equals(mode)?"MEUS FAVORITOS":"HISTÓRICO",phone?22:30,Ui.GREEN,true);
        body.addView(title,new LinearLayout.LayoutParams(-1,Ui.dp(this,52)));

        grid=new GridView(this);grid.setNumColumns(phone?4:6);grid.setHorizontalSpacing(Ui.dp(this,10));grid.setVerticalSpacing(Ui.dp(this,12));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);grid.setSelector(android.R.color.transparent);
        adapter=new Adapter();grid.setAdapter(adapter);
        body.addView(grid,new LinearLayout.LayoutParams(-1,0,1));
        root.addView(Ui.centered(this,body,1450),new LinearLayout.LayoutParams(-1,0,1));
        return root;
    }

    private void load(){
        items.clear();
        List<ApiClient.Item> src="favorites".equals(mode)?LocalStore.favorites(this):LocalStore.history(this);
        if(src!=null)items.addAll(src);
        adapter.notifyDataSetChanged();
        if(!items.isEmpty())grid.requestFocus();
    }

    private class Adapter extends BaseAdapter{
        public int getCount(){return items.size();}public Object getItem(int p){return items.get(p);}public long getItemId(int p){return items.get(p).id;}
        public View getView(int p,View cv,android.view.ViewGroup parent){
            FrameLayout card;ImageView img;TextView name,meta;
            if(cv==null){
                card=new FrameLayout(LibraryActivity.this);card.setFocusable(true);card.setClickable(true);card.setClipToOutline(true);
                Ui.focus(card,LibraryActivity.this,Ui.round(Ui.PANEL,5,LibraryActivity.this),Ui.stroke(Ui.PANEL_2,Ui.GREEN,5,LibraryActivity.this));
                img=new ImageView(LibraryActivity.this);img.setId(741);img.setScaleType(ImageView.ScaleType.CENTER_CROP);img.setBackgroundColor(Ui.PANEL_2);card.addView(img,new FrameLayout.LayoutParams(-1,-1));
                View shade=new View(LibraryActivity.this);shade.setBackground(Ui.verticalGradient(Color.TRANSPARENT,0xE5000000,0,LibraryActivity.this));card.addView(shade,new FrameLayout.LayoutParams(-1,-1));
                LinearLayout labels=Ui.column(LibraryActivity.this);labels.setPadding(Ui.dp(LibraryActivity.this,7),0,Ui.dp(LibraryActivity.this,7),Ui.dp(LibraryActivity.this,6));
                name=Ui.text(LibraryActivity.this,"",phone?10:12,Color.WHITE,true);name.setId(742);name.setMaxLines(2);labels.addView(name,new LinearLayout.LayoutParams(-1,0,1));
                meta=Ui.text(LibraryActivity.this,"",8,Ui.GREEN,true);meta.setId(743);labels.addView(meta,new LinearLayout.LayoutParams(-1,Ui.dp(LibraryActivity.this,18)));
                card.addView(labels,new FrameLayout.LayoutParams(-1,Ui.dp(LibraryActivity.this,56),Gravity.BOTTOM));cv=card;
            }else card=(FrameLayout)cv;
            img=cv.findViewById(741);name=cv.findViewById(742);meta=cv.findViewById(743);
            ApiClient.Item i=items.get(p);name.setText(clean(i.name,"Sem nome"));meta.setText(type(i));ImageLoader.into(LibraryActivity.this,img,clean(i.logo,i.backdrop));
            card.setOnClickListener(v->open(i));return cv;
        }
    }

    private String type(ApiClient.Item i){if("series".equals(i.type))return"SÉRIE";if("live".equals(i.type))return"CANAL";return"FILME";}
    private void open(ApiClient.Item i){
        if("series".equals(i.type)){Intent in=new Intent(this,SeriesActivity.class);in.putExtra("title",clean(i.seriesTitle,i.name));startActivity(in);}
        else if("live".equals(i.type)){Intent in=new Intent(this,PlayerActivity.class);MainActivity.putItem(in,i);startActivity(in);}
        else{Intent in=new Intent(this,DetailActivity.class);MainActivity.putItem(in,i);startActivity(in);}
    }
    private String clean(String v,String f){if(v==null)return f;String s=v.trim();return s.isEmpty()||"null".equalsIgnoreCase(s)?f:s;}
    @Override protected void onResume(){super.onResume();Ui.immersive(this);load();}

    @Override public boolean dispatchKeyEvent(android.view.KeyEvent event) {
        if (TvRemote.dispatch(this,event)) return true;
        return super.dispatchKeyEvent(event);
    }
}
