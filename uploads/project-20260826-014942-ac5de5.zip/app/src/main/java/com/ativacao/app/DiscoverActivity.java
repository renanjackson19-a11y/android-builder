package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class DiscoverActivity extends Activity {
    private final ArrayList<ApiClient.Item> hotLive=new ArrayList<>();
    private final ArrayList<ApiClient.Item> hotMovies=new ArrayList<>();
    private final ArrayList<ApiClient.Item> hotSeries=new ArrayList<>();

    private boolean phone; private LinearLayout body; private String smart,title;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);Ui.immersive(this);phone=Ui.phone(this);
        smart=clean(getIntent().getStringExtra("smart"),"kids");title=clean(getIntent().getStringExtra("title"),smart.toUpperCase());
        setContentView(build());
        TvRemote.prepare(getWindow().getDecorView());
        if("hot".equals(smart)){
            renderExplore();
        } else load();
    }

    private View build(){
        LinearLayout root=Ui.column(this);root.setBackground(Ui.diagonalGradient(0xFF07160B,0xFF010402,0,this));
        root.addView(header(),new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?56:64)));
        ScrollView s=new ScrollView(this);s.setVerticalScrollBarEnabled(false);s.setFillViewport(true);
        body=Ui.column(this);body.setPadding(Ui.dp(this,phone?14:26),Ui.dp(this,10),Ui.dp(this,phone?14:26),Ui.dp(this,24));
        s.addView(Ui.centered(this,body,1480),new ScrollView.LayoutParams(-1,-2));root.addView(s,new LinearLayout.LayoutParams(-1,0,1));return root;
    }

    private View header(){
        String active="HOT";
        if("kids".equals(smart)) active="KIDS";
        else if("anime".equals(smart)) active="ANIMES";
        else if("shows".equals(smart)) active="SHOWS";
        else if("games".equals(smart)||"retro".equals(smart)) active="GAMES";
        return YellowNav.bar(this,active);
    }

    private void addNav(LinearLayout row,String label,boolean selected,Runnable run){TextView v=Ui.nav(this,label,selected);v.setOnClickListener(x->run.run());row.addView(v,new LinearLayout.LayoutParams(Ui.dp(this,phone?72:96),Ui.dp(this,44)));}

    private void renderExplore(){
        // Igual ao app de referência: HOT é só uma visão protegida das categorias adultas.
        // O servidor decide o que é adulto; a tela não fica vazia esperando uma segunda permissão.
        renderExploreContent();
    }

    private void renderHotUnavailable(String text){
        body.removeAllViews();
        LinearLayout empty=Ui.column(this);
        empty.setGravity(Gravity.CENTER);
        ImageView logo=new ImageView(this);
        logo.setImageResource(R.drawable.hot_menu_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        empty.addView(logo,new LinearLayout.LayoutParams(Ui.dp(this,phone?145:190),Ui.dp(this,phone?62:76)));
        TextView title=Ui.text(this,"HOT +18",phone?16:22,Color.WHITE,true);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2);tp.topMargin=Ui.dp(this,12);empty.addView(title,tp);
        TextView txt=Ui.text(this,text,phone?10:12,Ui.MUTED,false);
        txt.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams xp=new LinearLayout.LayoutParams(phone?Ui.dp(this,420):Ui.dp(this,700),-2);xp.topMargin=Ui.dp(this,8);empty.addView(txt,xp);
        body.addView(empty,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?260:340)));
    }

    private void renderExploreContent(){
        body.removeAllViews();
        TextView loading=Ui.text(this,"Carregando categorias HOT...",phone?11:13,Ui.MUTED,true);
        loading.setGravity(Gravity.CENTER); body.addView(loading,new LinearLayout.LayoutParams(-1,Ui.dp(this,120)));
        ApiClient.hotCategories(new ApiClient.Callback<List<ApiClient.HotCategory>>(){
            @Override public void ok(List<ApiClient.HotCategory> cats){
                runOnUiThread(()->{
                    ArrayList<ApiClient.Item> covers=new ArrayList<>();
                    if(cats!=null) for(ApiClient.HotCategory h:cats){
                        ApiClient.Item i=new ApiClient.Item(); i.name=h.name; i.group=h.name; i.logo=h.cover; i.backdrop=h.cover; i.type="live"; i.sourceId=h.sourceId; i.sourceName=h.sourceName; covers.add(i);
                    }
                    hotLive.clear();hotMovies.clear();hotSeries.clear();hotLive.addAll(covers);
                    renderHotReference(hotLive,hotMovies,hotSeries);
                });
            }
            @Override public void error(String m){runOnUiThread(()->renderHotUnavailable("Não foi possível carregar as categorias +18: "+m));}
        });
    }

    private static class HotGroup {
        String name;
        int sourceId;
        ApiClient.Item cover;
        HotGroup(String n, int sid, ApiClient.Item c){ name=n; sourceId=sid; cover=c; }
    }

    private ArrayList<HotGroup> hotGroups(List<ApiClient.Item> live,List<ApiClient.Item> movies,List<ApiClient.Item> series){
        ArrayList<HotGroup> out=new ArrayList<>();
        java.util.HashSet<String> seen=new java.util.HashSet<>();
        ArrayList<ApiClient.Item> all=new ArrayList<>();
        if(movies!=null)all.addAll(movies);
        if(series!=null)all.addAll(series);
        if(live!=null)all.addAll(live);
        for(ApiClient.Item item:all){
            if(item==null)continue;
            String g=clean(item.group,clean(item.name,"HOT"));
            String key=item.sourceId+"|"+g.trim().toLowerCase(java.util.Locale.ROOT);
            if(key.isEmpty()||seen.contains(key))continue;
            seen.add(key);
            out.add(new HotGroup(g,item.sourceId,item));
        }
        return out;
    }

    private void renderHotReference(List<ApiClient.Item> live,List<ApiClient.Item> movies,List<ApiClient.Item> series){
        body.removeAllViews();

        ArrayList<HotGroup> groups=hotGroups(live,movies,series);
        if(groups.isEmpty()){
            renderHotUnavailable("Nenhuma categoria +18 disponível para este cliente.");
            return;
        }

        // O layout se adapta à quantidade REAL de categorias recebidas do painel.
        // Nenhum card/nome é inventado dentro do APK.
        LinearLayout top=new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL);

        HotGroup heroGroup=groups.get(0);
        FrameLayout feature=new FrameLayout(this);
        feature.setFocusable(true);feature.setClickable(true);
        Ui.focus(feature,this,Ui.round(0xFF120505,5,this),Ui.stroke(0xFF2A1010,0xFFFFC107,5,this));

        ImageView bg=new ImageView(this);
        bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        bg.setImageResource(R.drawable.hot_hero_banner);
        bg.setBackground(Ui.gradient(0xFF5A0A0A,0xFF110404,0,this));
        feature.addView(bg,new FrameLayout.LayoutParams(-1,-1));
        String heroUrl=clean(heroGroup.cover.backdrop,clean(heroGroup.cover.logo,""));
        if(!heroUrl.isEmpty()) ImageLoader.into(this,bg,heroUrl);

        View shade=new View(this);
        shade.setBackground(Ui.verticalGradient(0x00000000,0xA9000000,0,this));
        feature.addView(shade,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout heroCaption=Ui.column(this);
        heroCaption.setGravity(Gravity.BOTTOM|Gravity.LEFT);
        heroCaption.setPadding(Ui.dp(this,phone?16:24),Ui.dp(this,12),Ui.dp(this,16),Ui.dp(this,phone?12:16));
        TextView categoryName=Ui.text(this,hotLabel(heroGroup.name),phone?12:16,Color.WHITE,true);
        heroCaption.addView(categoryName,new LinearLayout.LayoutParams(-1,-2));
        feature.addView(heroCaption,new FrameLayout.LayoutParams(-1,-1));
        feature.setOnClickListener(v->renderHotCategory(heroGroup));

        // 1 categoria = banner ocupa toda a largura. 2+ = composição da referência.
        float heroWeight=groups.size()==1?1f:2.05f;
        LinearLayout.LayoutParams featureP=new LinearLayout.LayoutParams(0,Ui.dp(this,phone?250:365),heroWeight);
        top.addView(feature,featureP);

        if(groups.size()>1){
            LinearLayout right=new LinearLayout(this);
            right.setOrientation(LinearLayout.HORIZONTAL);
            right.setGravity(Gravity.CENTER);
            addHotReferencePoster(right,groups.get(1));
            if(groups.size()>2)addHotReferencePoster(right,groups.get(2));

            float rightWeight=groups.size()>2?1.55f:0.82f;
            LinearLayout.LayoutParams rightP=new LinearLayout.LayoutParams(0,Ui.dp(this,phone?250:365),rightWeight);
            rightP.leftMargin=Ui.dp(this,8);
            top.addView(right,rightP);
        }

        FrameLayout center=new FrameLayout(this);
        int sw=getResources().getDisplayMetrics().widthPixels;
        int contentW=phone?(int)(sw*0.96f):(int)(sw*0.94f);
        FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(contentW,-2,Gravity.TOP|Gravity.CENTER_HORIZONTAL);
        center.addView(top,cp);
        body.addView(center,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?260:375)));

        // Da quarta categoria em diante, cria automaticamente uma faixa rolável.
        if(groups.size()>3){
            HorizontalScrollView hsv=new HorizontalScrollView(this);
            hsv.setHorizontalScrollBarEnabled(false);
            LinearLayout shelf=new LinearLayout(this);
            shelf.setGravity(Gravity.LEFT);
            for(int i=3;i<groups.size();i++)addHotCategoryPosterFixed(shelf,groups.get(i));
            hsv.addView(shelf,new HorizontalScrollView.LayoutParams(-2,Ui.dp(this,phone?165:205)));
            LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?170:212));sp.topMargin=Ui.dp(this,8);body.addView(hsv,sp);
        }
    }

    private void addHotReferencePoster(LinearLayout row,HotGroup group){
        if(group==null)return;
        FrameLayout card=new FrameLayout(this);
        card.setFocusable(true);card.setClickable(true);
        Ui.focus(card,this,Ui.round(0xFF120505,4,this),Ui.stroke(0xFF26100E,0xFFFFC107,4,this));

        ImageView img=new ImageView(this);
        img.setScaleType(ImageView.ScaleType.CENTER_CROP);
        img.setBackground(Ui.gradient(0xFF3B0808,0xFF100303,0,this));
        card.addView(img,new FrameLayout.LayoutParams(-1,-1));

        String url=clean(group.cover.logo,clean(group.cover.backdrop,""));
        if(!url.isEmpty()) ImageLoader.into(this,img,url);

        View shade=new View(this);
        shade.setBackground(Ui.verticalGradient(0x00000000,0xC9000000,0,this));
        card.addView(shade,new FrameLayout.LayoutParams(-1,-1));

        TextView title=Ui.text(this,hotLabel(group.name),phone?10:13,Color.WHITE,true);
        title.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(-1,Ui.dp(this,phone?42:54),Gravity.BOTTOM);
        card.addView(title,tp);
        card.setOnClickListener(v->renderHotCategory(group));

        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1);
        p.leftMargin=Ui.dp(this,4);p.rightMargin=Ui.dp(this,4);
        row.addView(card,p);
    }

    private void addHotCategoryPosterFixed(LinearLayout row,HotGroup group){
        FrameLayout card=new FrameLayout(this);card.setFocusable(true);card.setClickable(true);
        Ui.focus(card,this,Ui.round(0xFF140706,6,this),Ui.stroke(0xFF26100E,0xFFFFC107,6,this));
        ImageView img=new ImageView(this);img.setScaleType(ImageView.ScaleType.CENTER_CROP);card.addView(img,new FrameLayout.LayoutParams(-1,-1));
        ImageLoader.into(this,img,clean(group.cover.logo,clean(group.cover.backdrop,"")));
        View shade=new View(this);shade.setBackground(Ui.verticalGradient(0x00000000,0xD7000000,0,this));card.addView(shade,new FrameLayout.LayoutParams(-1,-1));
        TextView title=Ui.text(this,hotLabel(group.name),phone?10:12,Color.WHITE,true);title.setGravity(Gravity.CENTER);card.addView(title,new FrameLayout.LayoutParams(-1,Ui.dp(this,48),Gravity.BOTTOM));
        card.setOnClickListener(v->renderHotCategory(group));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(Ui.dp(this,phone?120:170),-1);p.rightMargin=Ui.dp(this,8);row.addView(card,p);
    }

    private void renderHotCategory(HotGroup group){
        if(group==null)return;
        final String category=group.name;
        final int sourceId=group.sourceId;
        body.removeAllViews();
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);
        TextView t=Ui.text(this,hotLabel(category),phone?18:24,Color.WHITE,true);head.addView(t,new LinearLayout.LayoutParams(0,-2,1));
        TextView back=Ui.button(this,"← CATEGORIAS");head.addView(back,new LinearLayout.LayoutParams(Ui.dp(this,phone?125:160),Ui.dp(this,38)));
        back.setOnClickListener(v->renderExploreContent());
        body.addView(head,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?58:66)));
        TextView loading=Ui.text(this,"Carregando conteúdo...",11,Ui.MUTED,true);loading.setGravity(Gravity.CENTER);body.addView(loading,new LinearLayout.LayoutParams(-1,Ui.dp(this,90)));

        ArrayList<ApiClient.Item> all=new ArrayList<>();
        java.util.concurrent.atomic.AtomicInteger pending=new java.util.concurrent.atomic.AtomicInteger(3);
        final boolean[] failed={false};
        String[] types={"movie","series","live"};
        for(String type:types){
            ApiClient.catalogAdult(type,1,72,category,sourceId,new ApiClient.Callback<ApiClient.CatalogPage>(){
                public void ok(ApiClient.CatalogPage p){ synchronized(all){ if(p!=null) all.addAll(p.items); } finishHotCategoryLoad(category,all,pending); }
                public void error(String m){ failed[0]=true; finishHotCategoryLoad(category,all,pending); }
            });
        }
    }

    private void finishHotCategoryLoad(String category,ArrayList<ApiClient.Item> all,java.util.concurrent.atomic.AtomicInteger pending){
        if(pending.decrementAndGet()!=0)return;
        runOnUiThread(()->{
            body.removeAllViews();
            LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);
            TextView t=Ui.text(this,hotLabel(category),phone?18:24,Color.WHITE,true);head.addView(t,new LinearLayout.LayoutParams(0,-2,1));
            TextView back=Ui.button(this,"← CATEGORIAS");head.addView(back,new LinearLayout.LayoutParams(Ui.dp(this,phone?125:160),Ui.dp(this,38)));
            back.setOnClickListener(v->renderExploreContent()); body.addView(head,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?58:66)));
            if(all.isEmpty()){TextView e=Ui.text(this,"Nenhum conteúdo nesta categoria.",12,Ui.MUTED,false);e.setGravity(Gravity.CENTER);body.addView(e,new LinearLayout.LayoutParams(-1,Ui.dp(this,120)));return;}
            int cols=phone?4:6; int cardH=Ui.dp(this,phone?145:178);
            for(int i=0;i<all.size();i+=cols){
                LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_HORIZONTAL);
                for(int c=0;c<cols;c++){int n=i+c;if(n>=all.size())break;ApiClient.Item item=all.get(n);addHotInlineCard(row,item,clean(item.type,"movie"));}
                LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,cardH);rp.bottomMargin=Ui.dp(this,7);body.addView(row,rp);
            }
        });
    }

    private void addHotGroupItems(ArrayList<ApiClient.Item> out,List<ApiClient.Item> src,String category){
        if(src==null)return;
        for(ApiClient.Item i:src){if(i==null)continue;String g=clean(i.group,clean(i.name,"HOT"));if(g.equalsIgnoreCase(category))out.add(i);}
    }

    private void addHotPoster(LinearLayout row,ApiClient.Item item){
        if(item==null)return;
        FrameLayout card=new FrameLayout(this);
        card.setFocusable(true);card.setClickable(true);
        Ui.focus(card,this,Ui.round(0xFF140706,7,this),Ui.stroke(0xFF26100E,0xFFFF3B30,7,this));

        ImageView img=new ImageView(this);
        img.setScaleType(ImageView.ScaleType.CENTER_CROP);
        img.setBackground(Ui.gradient(0xFF47100C,0xFF110504,0,this));
        card.addView(img,new FrameLayout.LayoutParams(-1,-1));
        ImageLoader.into(this,img,clean(item.logo,clean(item.backdrop,"")));

        View shade=new View(this);
        shade.setBackground(Ui.verticalGradient(0x00000000,0xD9000000,0,this));
        card.addView(shade,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout caption=Ui.column(this);
        caption.setGravity(Gravity.CENTER);
        TextView title=Ui.text(this,hotLabel(clean(item.name,"HOT")),phone?9:11,Color.WHITE,true);
        title.setGravity(Gravity.CENTER);
        TextView source=Ui.text(this,clean(item.sourceName,"Fonte Principal"),phone?7:9,0xFFFF6B5E,true);
        source.setGravity(Gravity.CENTER);
        caption.addView(title,new LinearLayout.LayoutParams(-1,0,1));
        caption.addView(source,new LinearLayout.LayoutParams(-1,Ui.dp(this,18)));
        card.addView(caption,new FrameLayout.LayoutParams(-1,Ui.dp(this,58),Gravity.BOTTOM));

        final String type=clean(item.type,"live");
        card.setOnClickListener(v->renderHotInline(type));

        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1);
        p.leftMargin=Ui.dp(this,4);p.rightMargin=Ui.dp(this,4);
        row.addView(card,p);
    }

    private void addHotMini(LinearLayout row,String icon,String title,String type){
        LinearLayout b=Ui.column(this);
        b.setFocusable(true);b.setClickable(true);b.setGravity(Gravity.CENTER);
        Ui.focus(b,this,Ui.round(0xFF17100F,7,this),Ui.stroke(0xFF261816,0xFFFF3B30,7,this));
        TextView i=Ui.text(this,icon,phone?18:24,0xFFFF5648,true);i.setGravity(Gravity.CENTER);
        b.addView(i,new LinearLayout.LayoutParams(-1,0,1));
        TextView t=Ui.text(this,title,phone?8:10,Color.WHITE,true);t.setGravity(Gravity.CENTER);
        b.addView(t,new LinearLayout.LayoutParams(-1,Ui.dp(this,22)));
        b.setOnClickListener(v->renderHotInline(type));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1);
        p.rightMargin=Ui.dp(this,5);row.addView(b,p);
    }

    private void renderHotInline(String type){
        body.removeAllViews();

        LinearLayout head=new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);

        ImageView logo=new ImageView(this);
        logo.setImageResource(R.drawable.hot_menu_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        head.addView(logo,new LinearLayout.LayoutParams(Ui.dp(this,phone?110:145),Ui.dp(this,phone?46:54)));

        String title="live".equals(type)?"Canais adultos":"series".equals(type)?"Séries adultas":"Filmes adultos";
        TextView t=Ui.text(this,title,phone?17:22,Color.WHITE,true);
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,-2,1);tp.leftMargin=Ui.dp(this,12);head.addView(t,tp);

        TextView back=Ui.button(this,"← DESTAQUES");
        head.addView(back,new LinearLayout.LayoutParams(Ui.dp(this,phone?120:150),Ui.dp(this,38)));
        back.setOnClickListener(v->renderHotReference(hotLive,hotMovies,hotSeries));

        body.addView(head,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?62:70)));

        // Filtros permanecem dentro do HOT.
        LinearLayout filters=new LinearLayout(this);
        filters.setGravity(Gravity.CENTER);
        if(!hotLive.isEmpty()) addHotFilter(filters,"📺 CANAIS","live","live".equals(type));
        if(!hotMovies.isEmpty()) addHotFilter(filters,"▶ FILMES","movie","movie".equals(type));
        if(!hotSeries.isEmpty()) addHotFilter(filters,"▣ SÉRIES","series","series".equals(type));
        LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,Ui.dp(this,44));fp.bottomMargin=Ui.dp(this,10);body.addView(filters,fp);

        List<ApiClient.Item> src="live".equals(type)?hotLive:("series".equals(type)?hotSeries:hotMovies);
        if(src==null||src.isEmpty()){
            TextView empty=Ui.text(this,"Nenhum conteúdo disponível nesta seção.",12,Ui.MUTED,false);
            empty.setGravity(Gravity.CENTER);
            body.addView(empty,new LinearLayout.LayoutParams(-1,Ui.dp(this,120)));
            return;
        }

        // Grade real dentro da própria aba HOT.
        int cols=phone?3:5;
        int cardH=Ui.dp(this,phone?160:205);
        for(int i=0;i<src.size();i+=cols){
            LinearLayout row=new LinearLayout(this);
            row.setGravity(Gravity.LEFT);
            for(int c=0;c<cols;c++){
                int n=i+c;
                if(n>=src.size())break;
                ApiClient.Item item=src.get(n);
                addHotInlineCard(row,item,type);
            }
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,cardH);
            rp.bottomMargin=Ui.dp(this,8);
            body.addView(row,rp);
        }
    }

    private void addHotFilter(LinearLayout row,String text,String type,boolean selected){
        TextView b=Ui.text(this,text,phone?10:12,selected?Color.WHITE:0xFFB9A4A0,true);
        b.setGravity(Gravity.CENTER);
        b.setFocusable(true);b.setClickable(true);
        b.setBackground(selected?Ui.gradient(0xFFFF3B30,0xFFB91512,7,this):Ui.stroke(0xFF17100F,0xFF4A2723,7,this));
        b.setOnClickListener(v->renderHotInline(type));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,Ui.dp(this,38),1);
        p.leftMargin=Ui.dp(this,4);p.rightMargin=Ui.dp(this,4);
        row.addView(b,p);
    }

    private void addHotInlineCard(LinearLayout row,ApiClient.Item item,String sectionType){
        FrameLayout card=new FrameLayout(this);
        card.setFocusable(true);card.setClickable(true);
        Ui.focus(card,this,Ui.round(0xFF140706,7,this),Ui.stroke(0xFF24100F,0xFFFF3B30,7,this));

        ImageView img=new ImageView(this);
        img.setScaleType(ImageView.ScaleType.CENTER_CROP);
        img.setBackground(Ui.gradient(0xFF40100D,0xFF100403,0,this));
        card.addView(img,new FrameLayout.LayoutParams(-1,-1));
        ImageLoader.into(this,img,clean(item.logo,clean(item.backdrop,"")));

        View shade=new View(this);
        shade.setBackground(Ui.verticalGradient(0x00000000,0xDF000000,0,this));
        card.addView(shade,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout caption=Ui.column(this);
        caption.setGravity(Gravity.CENTER);
        TextView name=Ui.text(this,clean(item.name,"HOT"),phone?9:11,Color.WHITE,true);
        name.setGravity(Gravity.CENTER);
        TextView source=Ui.text(this,clean(item.sourceName,"Fonte Principal"),phone?7:8,0xFFFF6B5E,true);
        source.setGravity(Gravity.CENTER);
        caption.addView(name,new LinearLayout.LayoutParams(-1,0,1));
        caption.addView(source,new LinearLayout.LayoutParams(-1,Ui.dp(this,18)));
        card.addView(caption,new FrameLayout.LayoutParams(-1,Ui.dp(this,58),Gravity.BOTTOM));

        // Não muda de categoria. Para canais abre o player do item;
        // filme/série abre o detalhe do próprio item, mantendo retorno para HOT.
        card.setOnClickListener(v->{
            if("live".equals(sectionType)){
                try{
                    Intent in=new Intent(this,PlayerActivity.class);
                    in.putExtra("id",item.id);
                    in.putExtra("name",clean(item.name,"Canal"));
                    in.putExtra("url",ApiClient.streamUrl(item.id));
                    startActivity(in);
                }catch(Exception ignored){}
            }else{
                renderHotInline(sectionType);
            }
        });

        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1);
        p.leftMargin=Ui.dp(this,4);p.rightMargin=Ui.dp(this,4);
        row.addView(card,p);
    }


    private void addExploreMosaic(LinearLayout row,String name,String desc,String target,float weight,int fill){
        FrameLayout card=new FrameLayout(this);card.setFocusable(true);card.setClickable(true);Ui.focus(card,this,Ui.gradient(fill,Ui.PANEL,7,this),Ui.stroke(Ui.PANEL_2,Ui.GREEN,7,this));
        LinearLayout text=Ui.column(this);text.setPadding(Ui.dp(this,18),Ui.dp(this,15),Ui.dp(this,18),Ui.dp(this,14));
        TextView n=Ui.text(this,name,phone?18:24,Ui.TEXT,true);text.addView(n,new LinearLayout.LayoutParams(-1,0,1));
        TextView d=Ui.text(this,desc,10,Ui.MUTED,false);text.addView(d,new LinearLayout.LayoutParams(-1,Ui.dp(this,28)));card.addView(text,new FrameLayout.LayoutParams(-1,-1));
        card.setOnClickListener(v->{if("adult".equals(target))startActivity(new Intent(this,AdultPinActivity.class));else if("movies".equals(target)||"series".equals(target))openCatalog("movies".equals(target)?"movie":"series",name,"");else openDiscover(target,name);});
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,weight);p.rightMargin=Ui.dp(this,7);p.bottomMargin=Ui.dp(this,7);row.addView(card,p);
    }

    private void load(){
        if(body.getChildCount()==0 && CatalogPreloader.isReady()) { /* cache já preparado; sem tela de carregamento */ }
        ApiClient.catalog("movie",1,36,"","",smart,new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage movies){ApiClient.catalog("series",1,36,"","",smart,new ApiClient.Callback<ApiClient.CatalogPage>(){
                public void ok(ApiClient.CatalogPage series){runOnUiThread(()->{body.removeAllViews();sortNewestWithCover(movies.items);sortNewestWithCover(series.items);if("kids".equals(smart)){renderKidsMosaic(onlyKids(movies.items),onlyKids(series.items));}else if("shows".equals(smart)){List<ApiClient.Item> mm=onlyMusic(movies.items),ss=onlyMusic(series.items);shelf("Shows musicais e concertos",mm,"movie");shelf("Festivais, artistas e especiais",ss,"series");if(mm.isEmpty()&&ss.isEmpty())body.addView(Ui.text(DiscoverActivity.this,"Nenhum show musical disponível",12,Ui.MUTED,false));}else if("anime".equals(smart)){List<ApiClient.Item> mm=onlyAnime(movies.items),ss=onlyAnime(series.items);renderAnime(mm,ss);}else if("games".equals(smart)){List<ApiClient.Item> mm=onlyGames(movies.items),ss=onlyGames(series.items);shelf("Jogos",mm,"movie");shelf("Coleções de jogos",ss,"series");if(mm.isEmpty()&&ss.isEmpty())body.addView(Ui.text(DiscoverActivity.this,"Nenhum jogo disponível no painel",12,Ui.MUTED,false));}else if("retro".equals(smart)){List<ApiClient.Item> mm=onlyRetro(movies.items),ss=onlyRetro(series.items);shelf("Jogos Retrô",mm,"movie");shelf("Coleções Retrô",ss,"series");if(mm.isEmpty()&&ss.isEmpty())body.addView(Ui.text(DiscoverActivity.this,"Nenhum jogo retrô disponível no painel",12,Ui.MUTED,false));}else{shelf("Filmes",movies.items,"movie");shelf("Séries",series.items,"series");}});}
                public void error(String m){runOnUiThread(()->{body.removeAllViews();sortNewestWithCover(movies.items);if("kids".equals(smart))renderKidsMosaic(onlyKids(movies.items),new ArrayList<>());else shelf("Filmes",movies.items,"movie");});}
            });}
            public void error(String m){runOnUiThread(()->{body.removeAllViews();body.addView(Ui.text(DiscoverActivity.this,"Não foi possível carregar • "+m,12,Ui.RED,false),new LinearLayout.LayoutParams(-1,Ui.dp(DiscoverActivity.this,70)));});}
        });
    }


    private void sortNewestWithCover(List<ApiClient.Item> list){
        if(list==null||list.size()<2)return;
        java.util.Collections.sort(list,new java.util.Comparator<ApiClient.Item>(){
            @Override public int compare(ApiClient.Item a,ApiClient.Item b){
                int ca=hasCover(a)?1:0, cb=hasCover(b)?1:0;
                if(ca!=cb)return cb-ca;
                if(a.year!=b.year)return b.year-a.year;
                return a.id<b.id?1:(a.id>b.id?-1:0);
            }
        });
    }

    private boolean hasCover(ApiClient.Item i){
        if(i==null)return false;
        String v=i.logo;
        return v!=null&&!v.trim().isEmpty()&&!"null".equalsIgnoreCase(v.trim());
    }

    private void renderAnime(List<ApiClient.Item> movies,List<ApiClient.Item> series){
        ArrayList<ApiClient.Item> all=new ArrayList<>();
        if(movies!=null)for(ApiClient.Item i:movies)if(i!=null)all.add(i);
        if(series!=null)for(ApiClient.Item i:series)if(i!=null)all.add(i);
        if(all.isEmpty()){body.addView(Ui.text(this,"Nenhum anime disponível",12,Ui.MUTED,false));return;}

        ArrayList<ApiClient.Item> good=new ArrayList<>();
        for(ApiClient.Item i:all){
            String n=safeTitle(i.name,"");
            if(!n.isEmpty()&&!"Anime".equalsIgnoreCase(n))good.add(i);
        }
        if(good.isEmpty())good.addAll(all);

        // Estrutura inspirada na referência: bloco principal à esquerda,
        // quatro atalhos embaixo e dois posters grandes à direita.
        LinearLayout whole=new LinearLayout(this); whole.setOrientation(LinearLayout.HORIZONTAL); whole.setGravity(Gravity.TOP);
        LinearLayout left=Ui.column(this);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1.9f); whole.addView(left,lp);

        ApiClient.Item hero=item(good,0);
        FrameLayout feature=new FrameLayout(this); feature.setFocusable(true); feature.setClickable(true); feature.setClipToOutline(true);
        Ui.focus(feature,this,Ui.round(0xFF101510,10,this),Ui.stroke(0xFF192019,Ui.GREEN,10,this));

        ImageView heroBg=new ImageView(this); heroBg.setScaleType(ImageView.ScaleType.CENTER_CROP); heroBg.setBackgroundColor(Color.BLACK); feature.addView(heroBg,new FrameLayout.LayoutParams(-1,-1));
        ImageLoader.into(this,heroBg,clean(hero.backdrop,clean(hero.logo,"")));
        View dark=new View(this); dark.setBackground(Ui.gradient(Color.argb(235,0,0,0),Color.argb(45,0,0,0),0,this)); feature.addView(dark,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout heroContent=new LinearLayout(this); heroContent.setGravity(Gravity.CENTER_VERTICAL); heroContent.setPadding(Ui.dp(this,phone?10:16),Ui.dp(this,12),Ui.dp(this,12),Ui.dp(this,12));
        ImageView poster=new ImageView(this); poster.setScaleType(ImageView.ScaleType.CENTER_CROP); poster.setBackgroundColor(Ui.PANEL_2); heroContent.addView(poster,new LinearLayout.LayoutParams(Ui.dp(this,phone?118:170),-1));
        ImageLoader.into(this,poster,clean(hero.logo,clean(hero.backdrop,"")));

        LinearLayout info=Ui.column(this); info.setGravity(Gravity.CENTER_VERTICAL); info.setPadding(Ui.dp(this,phone?12:18),0,0,0); heroContent.addView(info,new LinearLayout.LayoutParams(0,-1,3f));
        TextView titleView=Ui.text(this,safeTitle(hero.name,"Anime em destaque"),phone?17:23,Color.WHITE,true); titleView.setMaxLines(2); info.addView(titleView,new LinearLayout.LayoutParams(-1,-2));
        TextView meta=Ui.text(this,hero.year>0?("LANÇAMENTO   "+hero.year):"ANIME EM DESTAQUE",phone?9:10,0xFFCFE64B,true); LinearLayout.LayoutParams metap=new LinearLayout.LayoutParams(-1,-2);metap.topMargin=Ui.dp(this,6);info.addView(meta,metap);
        TextView lab=Ui.text(this,"SINOPSE",phone?9:10,0xFFCFE64B,true);LinearLayout.LayoutParams labp=new LinearLayout.LayoutParams(-1,-2);labp.topMargin=Ui.dp(this,8);info.addView(lab,labp);
        TextView syn=Ui.text(this,clean(hero.synopsis,"Seleção especial de anime disponível no Dubai Play."),phone?9:11,0xFFE4E4E4,false);syn.setMaxLines(phone?4:5);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=Ui.dp(this,3);info.addView(syn,sp);
        TextView play=Ui.text(this,"▶  ASSISTIR AGORA",phone?9:11,Color.WHITE,true);play.setGravity(Gravity.CENTER);play.setBackground(Ui.round(0xEE08A844,7,this));LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(Ui.dp(this,phone?145:175),Ui.dp(this,38));pp.topMargin=Ui.dp(this,10);info.addView(play,pp);
        feature.addView(heroContent,new FrameLayout.LayoutParams(-1,-1)); feature.setOnClickListener(v->openItem(hero));
        left.addView(feature,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?205:276)));
        refreshAnimeHeroFromTmdb(hero,heroBg,poster,titleView,meta,syn);

        LinearLayout miniRow=new LinearLayout(this); miniRow.setGravity(Gravity.CENTER_VERTICAL);
        for(int n=1;n<=4;n++){
            ApiClient.Item it=item(good,n);
            FrameLayout mini=animeMiniTile(it);
            LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(0,Ui.dp(this,phone?82:105),1);mp.topMargin=Ui.dp(this,6);if(n<4)mp.rightMargin=Ui.dp(this,6);miniRow.addView(mini,mp);
        }
        left.addView(miniRow,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?88:111)));

        LinearLayout right=new LinearLayout(this); right.setGravity(Gravity.TOP);
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(0,Ui.dp(this,phone?304:402),1.15f);rp.leftMargin=Ui.dp(this,10);whole.addView(right,rp);
        for(int n=5;n<=6;n++){
            ApiClient.Item it=item(good,n);
            FrameLayout tall=animePosterOnlyTile(it);
            LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,-1,3f);if(n==6)tp.leftMargin=Ui.dp(this,6);right.addView(tall,tp);
        }
        body.addView(whole,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?304:402)));

        ArrayList<ApiClient.Item> movieGood=new ArrayList<>(); if(movies!=null)for(ApiClient.Item i:movies)if(i!=null&&!"Anime".equalsIgnoreCase(safeTitle(i.name,"Anime")))movieGood.add(i);
        ArrayList<ApiClient.Item> seriesGood=new ArrayList<>(); if(series!=null)for(ApiClient.Item i:series)if(i!=null&&!"Anime".equalsIgnoreCase(safeTitle(i.name,"Anime")))seriesGood.add(i);
        shelf("Animes em destaque",movieGood,"movie");
        shelf("Séries de anime",seriesGood,"series");
    }

    private void loadAnimeArtwork(ImageView view,ApiClient.Item item,boolean backdrop){
        if(item==null)return;
        String first=backdrop?clean(item.backdrop,clean(item.logo,"")):clean(item.logo,clean(item.backdrop,""));
        ImageLoader.into(this,view,first);
        ApiClient.tmdbEnrich(item,new ApiClient.Callback<ApiClient.Item>(){
            public void ok(ApiClient.Item x){runOnUiThread(()->ImageLoader.into(DiscoverActivity.this,view,backdrop?clean(x.backdrop,clean(x.logo,"")):clean(x.logo,clean(x.backdrop,""))));}
            public void error(String m){}
        });
    }

    private void refreshAnimeHeroFromTmdb(ApiClient.Item item,ImageView bg,ImageView poster,TextView title,TextView meta,TextView syn){
        if(item==null)return;
        ApiClient.tmdbEnrich(item,new ApiClient.Callback<ApiClient.Item>(){
            public void ok(ApiClient.Item x){runOnUiThread(()->{
                ImageLoader.into(DiscoverActivity.this,bg,clean(x.backdrop,clean(x.logo,"")));
                ImageLoader.into(DiscoverActivity.this,poster,clean(x.logo,clean(x.backdrop,"")));
                title.setText(safeTitle(x.name,"Anime em destaque"));
                meta.setText(x.year>0?("LANÇAMENTO   "+x.year):"ANIME EM DESTAQUE");
                syn.setText(clean(x.synopsis,"Seleção especial de anime disponível no Dubai Play."));
            });}
            public void error(String m){}
        });
    }

    private FrameLayout animePosterOnlyTile(ApiClient.Item i){
        FrameLayout box=new FrameLayout(this);box.setFocusable(true);box.setClickable(true);box.setClipToOutline(true);
        Ui.focus(box,this,Ui.round(Ui.PANEL,9,this),Ui.stroke(Ui.PANEL_2,Ui.GREEN,9,this));
        ImageView img=new ImageView(this);img.setScaleType(ImageView.ScaleType.CENTER_CROP);img.setBackgroundColor(Ui.PANEL_2);box.addView(img,new FrameLayout.LayoutParams(-1,-1));loadAnimeArtwork(img,i,false);
        View shade=new View(this);shade.setBackground(Ui.verticalGradient(Color.TRANSPARENT,Color.argb(185,0,0,0),0,this));box.addView(shade,new FrameLayout.LayoutParams(-1,-1));
        TextView t=Ui.text(this,safeTitle(i.name,"Anime"),phone?10:12,Color.WHITE,true);t.setGravity(Gravity.CENTER);t.setMaxLines(2);t.setBackgroundColor(0x99000000);box.addView(t,new FrameLayout.LayoutParams(-1,Ui.dp(this,48),Gravity.BOTTOM));
        box.setOnClickListener(v->openItem(i));return box;
    }

    private FrameLayout animeMiniTile(ApiClient.Item i){
        FrameLayout box=new FrameLayout(this);box.setFocusable(true);box.setClickable(true);box.setClipToOutline(true);
        Ui.focus(box,this,Ui.round(Ui.PANEL,8,this),Ui.stroke(Ui.PANEL_2,Ui.GREEN,8,this));
        ImageView img=new ImageView(this);img.setScaleType(ImageView.ScaleType.CENTER_CROP);img.setBackgroundColor(Ui.PANEL_2);box.addView(img,new FrameLayout.LayoutParams(-1,-1));loadAnimeArtwork(img,i,true);
        View shade=new View(this);shade.setBackground(Ui.verticalGradient(Color.TRANSPARENT,Color.argb(205,0,0,0),0,this));box.addView(shade,new FrameLayout.LayoutParams(-1,-1));
        TextView t=Ui.text(this,safeTitle(i.name,"Anime"),phone?9:11,Color.WHITE,true);t.setGravity(Gravity.CENTER);t.setMaxLines(1);t.setBackgroundColor(0x88000000);box.addView(t,new FrameLayout.LayoutParams(-1,Ui.dp(this,32),Gravity.BOTTOM));
        box.setOnClickListener(v->openItem(i));return box;
    }

    private ApiClient.Item bestAnimeHero(List<ApiClient.Item> items){
        if(items==null)return null;
        ApiClient.Item fallback=null;
        for(ApiClient.Item i:items){
            if(i==null)continue;
            String back=clean(i.backdrop,"");
            if(back.isEmpty())continue;
            if(fallback==null)fallback=i;
            String n=safeTitle(i.name,""); String sy=clean(i.synopsis,"");
            if(!n.isEmpty()&&!sy.isEmpty()&&i.year>=2020)return i;
        }
        return fallback;
    }
    private String safeTitle(String v,String fallback){String x=clean(v,fallback);int q=0;for(int i=0;i<x.length();i++)if(x.charAt(i)=='?')q++;return q>=3?fallback:x;}

    private void renderKidsMosaic(List<ApiClient.Item> movies,List<ApiClient.Item> series){
        ArrayList<ApiClient.Item> all=new ArrayList<>();
        if(movies!=null)all.addAll(movies);
        if(series!=null)all.addAll(series);
        if(all.isEmpty()){
            body.addView(Ui.text(this,"Nenhum conteúdo Kids disponível",12,Ui.MUTED,false));
            return;
        }

        LinearLayout kidsHead=new LinearLayout(this);
        kidsHead.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo=Ui.text(this,"KIDS",phone?24:34,Ui.GREEN,true);
        kidsHead.addView(logo,new LinearLayout.LayoutParams(0,Ui.dp(this,50),1));
        TextView badge=Ui.text(this,"MUNDO DA DIVERSÃO",phone?10:12,Ui.GREEN,true);
        badge.setGravity(Gravity.CENTER);
        badge.setBackground(Ui.stroke(0xFF111611,Ui.GREEN,18,this));
        kidsHead.addView(badge,new LinearLayout.LayoutParams(Ui.dp(this,phone?125:175),Ui.dp(this,34)));
        body.addView(kidsHead,new LinearLayout.LayoutParams(-1,Ui.dp(this,56)));

        // Mosaico visual no estilo dos apps de TV: conteúdo real como fundo.
        LinearLayout mosaic=new LinearLayout(this);
        mosaic.setGravity(Gravity.CENTER_VERTICAL);

        FrameLayout main=kidsImageTile(item(all,0),"DESTAQUE",true,()->openItem(item(all,0)));
        mosaic.addView(main,new LinearLayout.LayoutParams(0,Ui.dp(this,phone?310:410),1.8f));

        LinearLayout middle=Ui.column(this);
        LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(0,Ui.dp(this,phone?310:410),1f);
        mp.leftMargin=Ui.dp(this,8);
        mosaic.addView(middle,mp);

        FrameLayout anim=kidsImageTile(item(all,1),"DESENHOS",false,()->openCatalog("movie","Kids • Animações","kids"));
        middle.addView(anim,new LinearLayout.LayoutParams(-1,0,1));
        FrameLayout adv=kidsImageTile(item(all,2),"AVENTURAS KIDS",false,()->openCatalog("movie","Kids • Aventuras","kids"));
        LinearLayout.LayoutParams advp=new LinearLayout.LayoutParams(-1,0,1);advp.topMargin=Ui.dp(this,8);
        middle.addView(adv,advp);

        LinearLayout right=Ui.column(this);
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(0,Ui.dp(this,phone?310:410),1f);
        rp.leftMargin=Ui.dp(this,10);
        mosaic.addView(right,rp);

        FrameLayout allCard=kidsImageTile(item(all,3),"TODOS",false,()->openCatalog("movie","Kids • Todos","kids"));
        right.addView(allCard,new LinearLayout.LayoutParams(-1,0,1));
        FrameLayout music=kidsImageTile(item(all,4),"MÚSICA KIDS",false,()->openCatalog("movie","Kids • Música","kids"));
        LinearLayout.LayoutParams mup=new LinearLayout.LayoutParams(-1,0,1);mup.topMargin=Ui.dp(this,8);
        right.addView(music,mup);

        body.addView(mosaic,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?310:410)));

        LinearLayout quick=new LinearLayout(this);
        quick.setGravity(Gravity.CENTER_VERTICAL);
        addKidsMini(quick,"MAIS VISTOS",item(all,5),()->openItem(item(all,5)));
        addKidsMini(quick,"PARA VOCÊ",item(all,6),()->openItem(item(all,6)));
        addKidsMini(quick,"FAVORITOS",item(all,7),()->startActivity(new Intent(this,ProfileActivity.class)));
        body.addView(quick,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?105:130)));

        shelf("Filmes infantis",movies==null?new ArrayList<>():movies,"movie");
        shelf("Desenhos e séries",series==null?new ArrayList<>():series,"series");
    }

    private FrameLayout kidsImageTile(ApiClient.Item i,String label,boolean hero,Runnable run){
        FrameLayout box=new FrameLayout(this);
        box.setFocusable(true);box.setClickable(true);box.setClipToOutline(true);
        Ui.focus(box,this,Ui.round(Ui.PANEL,12,this),Ui.stroke(Ui.PANEL_2,Ui.GREEN,12,this));

        ImageView img=new ImageView(this);
        img.setScaleType(ImageView.ScaleType.CENTER_CROP);
        img.setBackgroundColor(Ui.PANEL_2);
        box.addView(img,new FrameLayout.LayoutParams(-1,-1));
        ImageLoader.into(this,img,clean(i.backdrop,clean(i.logo,"")));

        View shade=new View(this);
        shade.setBackground(Ui.verticalGradient(Color.TRANSPARENT,Color.argb(220,0,0,0),0,this));
        box.addView(shade,new FrameLayout.LayoutParams(-1,-1));

        TextView t=Ui.text(this,label,hero?(phone?16:21):(phone?12:15),Color.WHITE,true);
        t.setGravity(Gravity.CENTER);
        t.setBackgroundColor(0xAA000000);
        FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(-1,Ui.dp(this,hero?48:40),Gravity.BOTTOM);
        box.addView(t,tp);

        box.setOnClickListener(v->run.run());
        return box;
    }

    private void addKidsMini(LinearLayout row,String label,ApiClient.Item i,Runnable run){
        FrameLayout card=kidsImageTile(i,label,false,run);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,3f);
        p.topMargin=Ui.dp(this,8);p.rightMargin=Ui.dp(this,8);
        row.addView(card,p);
    }

    private FrameLayout kidsTile(ApiClient.Item i,String label,int accent,boolean hero){
        FrameLayout box=new FrameLayout(this); box.setFocusable(true); box.setClickable(true); box.setClipToOutline(true);
        Ui.focus(box,this,Ui.round(Ui.PANEL,12,this),Ui.stroke(Ui.PANEL_2,accent,12,this));
        ImageView img=new ImageView(this); img.setScaleType(ImageView.ScaleType.CENTER_CROP); img.setBackgroundColor(Ui.PANEL_2); box.addView(img,new FrameLayout.LayoutParams(-1,-1)); ImageLoader.into(this,img,clean(i.backdrop,i.logo));
        View shade=new View(this); shade.setBackground(Ui.verticalGradient(Color.TRANSPARENT,Color.argb(225,0,0,0),0,this)); box.addView(shade,new FrameLayout.LayoutParams(-1,-1));
        TextView t=Ui.text(this,label,hero?17:13,Color.BLACK,true); t.setGravity(Gravity.CENTER); t.setBackground(Ui.round(accent,12,this)); FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(hero?Ui.dp(this,200):Ui.dp(this,150),Ui.dp(this,hero?48:40),Gravity.LEFT|Gravity.BOTTOM); tp.leftMargin=Ui.dp(this,12); tp.bottomMargin=Ui.dp(this,12); box.addView(t,tp);
        box.setOnClickListener(v->openItem(i)); return box;
    }

    private ApiClient.Item item(List<ApiClient.Item> x,int n){return x.get(Math.min(n,x.size()-1));}

    private FrameLayout mediaTile(ApiClient.Item i,String label,boolean hero){
        FrameLayout box=new FrameLayout(this);box.setFocusable(true);box.setClickable(true);Ui.focus(box,this,Ui.round(Ui.PANEL,10,this),Ui.stroke(Ui.PANEL_2,Ui.GREEN,10,this));
        ImageView img=new ImageView(this);img.setScaleType(ImageView.ScaleType.CENTER_CROP);img.setBackgroundColor(Ui.PANEL_2);box.addView(img,new FrameLayout.LayoutParams(-1,-1));ImageLoader.into(this,img,clean(i.backdrop,i.logo));
        View shade=new View(this);shade.setBackground(Ui.verticalGradient(Color.TRANSPARENT,Color.argb(210,0,0,0),0,this));box.addView(shade,new FrameLayout.LayoutParams(-1,-1));
        TextView t=Ui.text(this,label,hero?16:13,Ui.TEXT,true);t.setGravity(Gravity.CENTER);t.setBackgroundColor(0x99101810);FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(-1,Ui.dp(this,hero?46:38),Gravity.BOTTOM);box.addView(t,tp);
        box.setOnClickListener(v->openItem(i));return box;
    }

    private void shelf(String label,List<ApiClient.Item> items,String type){
        if(items==null||items.isEmpty())return;LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);head.addView(Ui.text(this,label,phone?17:22,Ui.TEXT,true),new LinearLayout.LayoutParams(0,Ui.dp(this,44),1));
        TextView all=Ui.ghostButton(this,"VER TODOS");all.setOnClickListener(v->{Intent in=new Intent(this,CatalogActivity.class);in.putExtra("type",type);in.putExtra("title",label+" • "+title);in.putExtra("smart",smart);startActivity(in);});head.addView(all,new LinearLayout.LayoutParams(Ui.dp(this,100),Ui.dp(this,34)));body.addView(head,new LinearLayout.LayoutParams(-1,Ui.dp(this,48)));
        HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setHorizontalScrollBarEnabled(false);LinearLayout row=new LinearLayout(this);
        for(ApiClient.Item i:items){
            FrameLayout card;
            if("anime".equals(smart) && "movie".equals(type)){
                card=animeMovieTile(i);
            }else{
                card=mediaTile(i,clean(i.name,"Sem nome"),false);
            }
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(Ui.dp(this,phone?130:165),Ui.dp(this,phone?180:225));
            cp.rightMargin=Ui.dp(this,8);
            row.addView(card,cp);
        }
        hsv.addView(row);
        body.addView(hsv,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?185:230)));
    }

    private FrameLayout animeMovieTile(ApiClient.Item i){
        FrameLayout box=new FrameLayout(this);
        box.setFocusable(true);
        box.setClickable(true);
        box.setClipToOutline(true);
        Ui.focus(box,this,Ui.round(Ui.PANEL,10,this),Ui.stroke(Ui.PANEL_2,Ui.GREEN,10,this));

        ImageView img=new ImageView(this);
        img.setScaleType(ImageView.ScaleType.CENTER_CROP);
        img.setBackgroundColor(Ui.PANEL_2);
        box.addView(img,new FrameLayout.LayoutParams(-1,-1));

        // Na grade usamos o poster/logo, igual à tela de detalhes.
        // O backdrop horizontal fica reservado para hero/fundo.
        ImageLoader.into(this,img,clean(i.logo,clean(i.backdrop,"")));

        View shade=new View(this);
        shade.setBackground(Ui.verticalGradient(Color.TRANSPARENT,Color.argb(225,0,0,0),0,this));
        box.addView(shade,new FrameLayout.LayoutParams(-1,-1));

        String initial=safeTitle(i.name,"Carregando...");
        TextView t=Ui.text(this,initial,13,Ui.TEXT,true);
        t.setGravity(Gravity.CENTER);
        t.setMaxLines(2);
        t.setBackgroundColor(0xAA101810);
        FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(-1,Ui.dp(this,54),Gravity.BOTTOM);
        box.addView(t,tp);

        box.setOnClickListener(v->openItem(i));

        // O catálogo resumido pode vir com título/capa incompletos.
        // Busca o mesmo detail.php usado ao entrar no filme e atualiza o card.
        if(i.id>0){
            ApiClient.details(i.id,new ApiClient.Callback<ApiClient.Item>(){
                @Override public void ok(ApiClient.Item full){
                    runOnUiThread(()->{
                        if(full==null)return;
                        if(full.name!=null&&!full.name.trim().isEmpty())i.name=full.name;
                        if(full.logo!=null&&!full.logo.trim().isEmpty())i.logo=full.logo;
                        if(full.backdrop!=null&&!full.backdrop.trim().isEmpty())i.backdrop=full.backdrop;
                        if(full.group!=null&&!full.group.trim().isEmpty())i.group=full.group;
                        if(full.synopsis!=null&&!full.synopsis.trim().isEmpty())i.synopsis=full.synopsis;
                        if(full.type!=null&&!full.type.trim().isEmpty())i.type=full.type;
                        if(full.year>0)i.year=full.year;
                        if(full.tmdbId>0)i.tmdbId=full.tmdbId;

                        t.setText(safeTitle(i.name,"Anime"));
                        ImageLoader.into(DiscoverActivity.this,img,clean(i.logo,clean(i.backdrop,"")));
                    });
                }
                @Override public void error(String m){
                    runOnUiThread(()->{
                        t.setText(safeTitle(i.name,"Anime"));
                    });
                }
            });
        }
        return box;
    }

    private List<ApiClient.Item> onlyAdult(List<ApiClient.Item> src){
        // A API já retorna somente categorias marcadas como HOT +18 no painel.
        // Não filtra novamente pelo nome, porque categorias válidas podem se chamar
        // "Gay", "Hetero", "Brasileirinhas", etc.
        return src==null?new ArrayList<>():new ArrayList<>(src);
    }

    private List<ApiClient.Item> onlyKids(List<ApiClient.Item> src){
        ArrayList<ApiClient.Item> out=new ArrayList<>();
        if(src==null)return out;

        String[] allowGroup={
            "kids","infantil","infantis","criança","crianca","crianças","criancas",
            "family","família","familia","disney","pixar","nickelodeon",
            "discovery kids","cartoon network","junior","preschool","pré-escolar","pre-escolar"
        };

        String[] deny={
            "anime","animê","animes","adulto","adult","18+","hot","sexy","xxx",
            "terror","horror","crime","guerra","war","erótico","erotico"
        };

        for(ApiClient.Item i:src){
            if(i==null)continue;
            String group=clean(i.group,"").toLowerCase(java.util.Locale.ROOT);
            String name=clean(i.name,"").toLowerCase(java.util.Locale.ROOT);

            boolean blocked=false;
            for(String k:deny){
                if(group.contains(k)||name.contains(k)){blocked=true;break;}
            }
            if(blocked)continue;

            boolean kids=false;
            for(String k:allowGroup){
                if(group.contains(k)){kids=true;break;}
            }

            // Só entra se a categoria do painel realmente indicar infantil.
            if(kids)out.add(i);
        }
        return out;
    }

    private List<ApiClient.Item> onlyMusic(List<ApiClient.Item> src){ArrayList<ApiClient.Item> out=new ArrayList<>();if(src==null)return out;String[] keys={"music","musical","música","musica","show","concert","concerto","festival","artist","artista","acústico","acustico","tour","turnê","turne","singer","cantor","banda"};for(ApiClient.Item i:src){if(i==null)continue;String hay=(clean(i.name,"")+" "+clean(i.group,"")+" "+clean(i.synopsis,"")).toLowerCase(java.util.Locale.ROOT);for(String k:keys)if(hay.contains(k)){out.add(i);break;}}return out;}
    private List<ApiClient.Item> onlyAnime(List<ApiClient.Item> src){ArrayList<ApiClient.Item> out=new ArrayList<>();if(src==null)return out;String[] keys={"anime","animê","animes","japon","mangá","manga","shonen","shounen","seinen","isekai","otaku"};for(ApiClient.Item i:src){if(i==null)continue;String hay=(clean(i.name,"")+" "+clean(i.group,"")+" "+clean(i.synopsis,"")).toLowerCase(java.util.Locale.ROOT);for(String k:keys)if(hay.contains(k)){out.add(i);break;}}return out;}
    private List<ApiClient.Item> onlyGames(List<ApiClient.Item> src){ArrayList<ApiClient.Item> out=new ArrayList<>();if(src==null)return out;String[] keys={"game","games","jogo","jogos","gaming","arcade","console","videogame","video game"};for(ApiClient.Item i:src){if(i==null)continue;String hay=(clean(i.name,"")+" "+clean(i.group,"")+" "+clean(i.synopsis,"")).toLowerCase(java.util.Locale.ROOT);for(String k:keys)if(hay.contains(k)){out.add(i);break;}}return out;}
    private List<ApiClient.Item> onlyRetro(List<ApiClient.Item> src){ArrayList<ApiClient.Item> out=new ArrayList<>();if(src==null)return out;String[] keys={"retro","retrô","arcade","atari","nintendo","super nintendo","snes","mega drive","genesis","master system","game boy","playstation 1","ps1","jogo clássico","jogo classico"};for(ApiClient.Item i:src){if(i==null)continue;String hay=(clean(i.name,"")+" "+clean(i.group,"")+" "+clean(i.synopsis,"")).toLowerCase(java.util.Locale.ROOT);for(String k:keys)if(hay.contains(k)){out.add(i);break;}}return out;}

    private void openItem(ApiClient.Item i){if(i==null)return;if("series".equals(i.type)){Intent in=new Intent(this,SeriesActivity.class);in.putExtra("title",clean(i.seriesTitle,i.name));startActivity(in);}else{Intent in=new Intent(this,DetailActivity.class);MainActivity.putItem(in,i);startActivity(in);}}
    private void openCatalog(String type,String name,String smartKey){Intent in=new Intent(this,CatalogActivity.class);in.putExtra("type",type);in.putExtra("title",name);in.putExtra("smart",smartKey);startActivity(in);}
    private void openDiscover(String key,String name){Intent in=new Intent(this,DiscoverActivity.class);in.putExtra("smart",key);in.putExtra("title",name);startActivity(in);}
    private String hotLabel(String raw){
        String x=clean(raw,"HOT").replaceFirst("^[?\\s]+","").trim();
        x=x.replaceAll("(?i)\\[(xxx|adulto|adult|\\+18)\\]","").trim();
        x=x.replaceAll("(?i)^(xxx\\s*[-:|]?\\s*)+","").trim();
        x=x.replaceAll("\\s{2,}"," ");
        return x.isEmpty()?"HOT +18":x;
    }

    private String clean(String v,String f){if(v==null)return f;String s=v.trim();return s.isEmpty()||"null".equalsIgnoreCase(s)?f:s;}

    @Override public boolean dispatchKeyEvent(android.view.KeyEvent event) {
        if (TvRemote.dispatch(this,event)) return true;
        return super.dispatchKeyEvent(event);
    }
}
