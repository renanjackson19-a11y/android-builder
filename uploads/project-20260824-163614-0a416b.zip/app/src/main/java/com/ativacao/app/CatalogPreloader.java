package com.ativacao.app;

import android.app.Activity;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/** Pré-carrega silenciosamente as primeiras telas após o login. */
final class CatalogPreloader {
    private static volatile boolean running=false;
    private static volatile boolean ready=false;
    private static volatile long lastRun=0L;

    static boolean isReady(){ return ready; }

    static void start(Activity a, boolean force, Runnable done){
        if(a==null){ if(done!=null)done.run(); return; }
        long now=System.currentTimeMillis();
        if(!force && ready && now-lastRun<8L*60L*1000L){ if(done!=null)done.run(); return; }
        if(running){ if(done!=null)done.run(); return; }
        running=true;
        if(force) ApiClient.clearCatalogCache();

        // Primeiras páginas apenas. Isso aquece a navegação sem travar o login
        // nem disparar dezenas de chamadas/TMDB antes de mostrar a interface.
        final List<String[]> jobs=Arrays.asList(
            new String[]{"live",""},
            new String[]{"movie",""},
            new String[]{"series",""},
            new String[]{"movie","adult"},
            new String[]{"series","adult"}
        );
        AtomicInteger pending=new AtomicInteger(jobs.size()+1);
        for(String[] job:jobs){
            String type=job[0], smart=job[1];
            int limit="live".equals(type)?72:48;
            ApiClient.catalog(type,1,limit,"","",smart,new ApiClient.Callback<ApiClient.CatalogPage>(){
                public void ok(ApiClient.CatalogPage p){ warmImagesFast(a,p); finishOne(pending,a,done); }
                public void error(String m){ finishOne(pending,a,done); }
            });
        }
        ApiClient.hotCategories(new ApiClient.Callback<List<ApiClient.HotCategory>>(){
            public void ok(List<ApiClient.HotCategory> x){ finishOne(pending,a,done); }
            public void error(String m){ finishOne(pending,a,done); }
        });
    }

    private static void finishOne(AtomicInteger pending,Activity a,Runnable done){
        if(pending.decrementAndGet()!=0)return;
        running=false;ready=true;lastRun=System.currentTimeMillis();
        if(done!=null)done.run();
        backgroundWarm(a);
    }

    private static void backgroundWarm(Activity a){
        String[][] jobs={{"movie","kids"},{"series","kids"},{"movie","anime"},{"series","anime"}};
        for(String[] j:jobs){
            ApiClient.catalog(j[0],1,36,"","",j[1],new ApiClient.Callback<ApiClient.CatalogPage>(){
                public void ok(ApiClient.CatalogPage p){ warmImagesFast(a,p); }
                public void error(String m){}
            });
        }
    }

    private static void warmImagesFast(Activity a,ApiClient.CatalogPage p){
        if(p==null)return;
        int max=Math.min(p.items.size(),12);
        for(int n=0;n<max;n++){
            ApiClient.Item i=p.items.get(n); if(i==null)continue;
            ImageLoader.preload(a,clean(i.logo,i.backdrop));
        }
    }

    private static String clean(String a,String b){
        String x=a==null?"":a.trim();
        return x.isEmpty()?(b==null?"":b.trim()):x;
    }
}
