GreenPlay 5.28.28 - estabilidade + Shorts portrait

Base estável: 5.28.26.
A mudança agressiva de snapshot atômico da 5.28.27 foi revertida.
No celular, conteúdo GreenShorts/Reels Shorts abre em retrato.
TV/TV Box continua landscape.
