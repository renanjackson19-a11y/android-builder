package com.ativacao.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        Context app = context.getApplicationContext();
        PolicyScheduler.schedule(app);
        if (DeviceControl.isDeviceOwner(app)) DeviceControl.enforceManagedState(app);
    }
}
