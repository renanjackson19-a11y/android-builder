GreenPlay v16.171

Correção específica do modo TV ao vivo:
- vídeo principal volta a FIT: sem esticar e sem cortar logos/bordas;
- as sobras da tela são preenchidas por uma cópia ampliada/diminuída do próprio quadro do canal ao fundo;
- nenhum fundo verde sólido;
- fullscreen mantém o canal principal inteiro;
- remove o overscan/crop agressivo da v16.170.
