GreenPlay v16.172
- remove completamente o fundo/cópia do próprio canal
- player ocupa 100% da área com RESIZE_MODE_ZOOM (center-crop)
- mantém proporção original, sem esticar a imagem
- sem escala extra/overscan de 1.08, para minimizar corte de logo/GC
- fullscreen e preview usam a mesma regra
