GreenPlay v16.165

Base: v16.164

Ajustes desta etapa:
- barra de busca da lista de canais redesenhada e mais limpa;
- busca filtra automaticamente enquanto digita e pesquisa globalmente quando há texto;
- EPG inferior redesenhado com fundo quase opaco, cantos arredondados e textos com até duas linhas;
- proteção contra títulos EPG falsamente interpretados como Base64, evitando letras/gibberish ocasionais;
- fullscreen força preto puro em todas as superfícies ao redor do vídeo para eliminar faixas verdes nas laterais;
- player continua preenchendo a largura e o EPG permanece dentro do vídeo.
