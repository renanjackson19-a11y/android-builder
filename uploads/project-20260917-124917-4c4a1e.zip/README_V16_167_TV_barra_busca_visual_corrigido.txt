GreenPlay v16.167

Ajustes desta versão:
- corrigido o visual da barra de pesquisa lateral da TV;
- removido o contorno verde interno errado do campo de busca;
- foco do campo e do botão OK agora destaca apenas o contêiner de forma limpa;
- botão OK redesenhado para combinar com o painel.
