v16.170
- força preenchimento total do canal ao vivo com crop agressivo/overscan
- remove qualquer sobra verde/área vazia ao redor do player
- mantém preto apenas como shutter temporário durante troca/carregamento, sem barras persistentes
