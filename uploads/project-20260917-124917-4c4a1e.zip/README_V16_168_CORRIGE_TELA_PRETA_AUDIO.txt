GreenPlay v16.168

Base: v16.167

Correção desta versão:
- corrige regressão de tela preta com áudio introduzida nas v16.166/v16.167;
- restaura somente a renderização do player ao método estável da v16.165;
- remove alteração direta da SurfaceView que podia cobrir o vídeo;
- mantém a barra de pesquisa visual corrigida da v16.167;
- mantém o EPG ampliado e demais ajustes já realizados.

versionCode 188 / versionName 1.16.168.0
