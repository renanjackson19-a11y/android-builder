GreenPlay Android Nativo v16.165

Base: v16.164

Ajustes solicitados:
- melhorado o bloco superior da lista de canais;
- título e busca com mais espaçamento e proporção melhor;
- barra "Buscar canal" refinada;
- overlay/EPG inferior do player ficou mais compacto e menos alto;
- mantido preenchimento lateral e fullscreen ao toque.
