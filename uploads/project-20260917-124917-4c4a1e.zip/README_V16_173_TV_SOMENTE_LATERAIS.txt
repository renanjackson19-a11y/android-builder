GreenPlay v16.173

Ajuste desta etapa:
- remove somente as sobras/margens esquerda e direita no modo TV;
- não usa fundo duplicado;
- não usa zoom/crop do quadro do canal;
- preserva logos e grafismos do canal;
- mantém a altura/topo/rodapé do player sem overscan adicional;
- remove padding lateral que podia reaparecer ao entrar/sair do cinema/fullscreen.
