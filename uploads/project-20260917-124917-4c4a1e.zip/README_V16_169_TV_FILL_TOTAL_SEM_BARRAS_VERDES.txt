v16.169
- força o player da TV ao vivo a preencher 100% da área do vídeo com crop controlado (ZOOM + SCALE_TO_FIT_WITH_CROPPING)
- remove o fundo verde remanescente ao redor do player, usando preto no stage/split
- mantém a correção da tela preta com áudio da v16.168
- amplia e rebalanceia o overlay EPG para evitar corte de textos
