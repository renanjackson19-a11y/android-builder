GreenPlay v16.174

Base: v16.173

Ajuste somente no overlay do canal/EPG no modo TV:
- faixa inferior agora ocupa toda a largura, encostada nas laterais e no rodapé;
- nome do canal com área maior e sem corte;
- logo maior e melhor enquadrada;
- ATUAL e PRÓXIMO com mais espaço e fonte maior;
- divisórias e acabamento em verde discreto;
- mantido o player e o preenchimento lateral corrigido da v16.173.
