GreenPlay Android Nativo v16.164

Ajustes realizados na tela TV (layout wide / TV Box):
- Melhorado o painel lateral esquerdo.
- Adicionada barra de pesquisa "Buscar canal" abaixo do título LISTA DE CANAIS.
- Pesquisa filtra os canais da categoria atual.
- Busca pode ser acionada pela lupa, ENTER/OK no teclado/controle.
- Ao limpar o campo de busca, a lista volta automaticamente.
- Mantido o restante do comportamento do player e da lista.
