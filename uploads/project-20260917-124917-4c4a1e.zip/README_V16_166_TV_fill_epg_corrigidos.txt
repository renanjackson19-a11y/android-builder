GreenPlay v16.166

Ajustes desta versão:
- força preenchimento total do vídeo em fullscreen e na prévia TV usando RESIZE_MODE_ZOOM;
- reforço de fundo preto em window/root/contentFrame/player/surface para eliminar bordas laterais verdes;
- manutenção do modo de preenchimento ao trocar de canal, evitando voltar para FIT após alguns canais;
- overlay EPG aumentado e reespaçado para reduzir textos cortados;
- versionCode 186 / versionName 1.16.166.0.
