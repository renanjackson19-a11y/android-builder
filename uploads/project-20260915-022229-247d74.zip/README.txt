GreenPlay Android Nativo v12
Home e seleção de servidores redesenhadas com base na referência visual enviada pelo cliente.
Mantém login, revendas, MisticPay, catálogo e player existentes.
