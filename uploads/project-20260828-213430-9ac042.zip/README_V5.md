# GREEN PLAY V5 — Alpha 15 TV Fullscreen estilo referência V4

Esta versão mantém a base V5 nova e usa o V4 apenas como referência de comportamento visual.

## TV — fullscreen refeito
- O mesmo PlayerView/stream do preview é movido para fullscreen; não recria URL nem dá prepare novamente ao abrir/fechar.
- Fullscreen normal: vídeo + painel inferior fixo com logo, número/nome, AO VIVO, EPG atual/próximo e progresso.
- OK/toque no fullscreen: abre a lista lateral de canais sobre o vídeo, no formato da referência antiga.
- Lista lateral: trilho estreito com busca/recentes/favoritos/todos + lista de canais.
- Selecionar outro canal pela lista lateral troca o canal e volta ao fullscreen normal.
- VOLTAR com lista aberta: fecha somente a lista.
- VOLTAR no fullscreen normal: retorna para a tela principal de TV.
- Mesmo applicationId/assinatura das Alphas anteriores para atualização por cima.

VersionCode: 5015


## Alpha 16 – ajustes TV
- Painel EPG fullscreen na altura proporcional à referência (~25% da tela).
- EPG cacheado aparece imediatamente ao entrar em tela cheia.
- Ao voltar do segundo plano, mantém o mesmo canal mas reconecta no ponto AO VIVO.
- Indicador de consumo/velocidade de rede no canto superior direito em tela cheia.
- Removido RECENTES da barra lateral fullscreen; permanecem busca, favoritos e todos.


## Alpha 17 — polimento TV
- painel EPG normal mais compacto;
- painel inferior fullscreen reduzido para ~20% da altura real da tela;
- lista lateral limitada a 40% da largura;
- lista permanece aberta ao trocar canal e BACK fecha a lista;
- indicador de rede menor e separado;
- linhas de canais mais compactas;
- sem mudanças na camada de login, API ou núcleo do player.


## Alpha 18 - TV refinada
- Lista de canais com título centralizado e sem botão TODOS redundante.
- Favoritos compacto e estrelas verdes.
- Fullscreen: EPG/info some automaticamente após ~4,2 s.
- Barra de progresso do EPG atualiza a cada 5 s e renova o EPG ao virar o programa.
- Lateral mais estreita com Busca, EPG, Favoritos e Lista.
- Hora + consumo de rede em bloco próprio no canto superior direito.
- Mesmo player/stream preservado ao abrir e fechar os overlays.


## Alpha 20 — TV / EPG compacto
- remove contador de quantidade da lista de canais;
- Favoritos permanece na barra superior, compacto e em uma linha;
- EPG pequeno e tela cheia usam o mesmo desenho compacto;
- Atual em vermelho, Próximo em branco e progresso real em verde;
- carregamento central verde ao trocar de canal;
- mantém o mesmo player e não altera o contrato do painel.


## ALPHA21 — TV refinada
- Retirada a exibição da quantidade total de canais.
- Favoritos permanece no menu superior e estrelas em verde.
- EPG inferior padronizado entre preview e tela cheia, mais baixo/limpo e com barra de progresso ocupando toda a largura útil.
- Barra de EPG continua avançando em tempo real e atualiza o programa quando o horário vira.
- Overlay de troca de canal reduzido para um carregamento discreto.
- Painel EPG da tela cheia some automaticamente após 3,5 s.
- Medidor de tráfego continua no topo e o canal ao vivo é reconectado ao retornar do segundo plano.


## Alpha 22 — foco visível em TV/TV Box
- Foco forte em verde neon nos canais ao navegar com D-pad/controle remoto.
- Marcador ▶ aparece no canal que está sob o foco.
- Leve aumento/elevacão do item focado para ficar claro em qualquer Android TV/TV Box.
- Menu superior e Favoritos também ganham contorno/fundo verde ao receber foco.
- Não altera player, EPG, login ou contrato do painel.

## Alpha 23 - TVBox: canal selecionado, EPG na lista e zap rápido
- O canal confirmado com OK fica marcado de forma persistente na lista, mesmo quando o foco do controle sai dele.
- O texto "TV AO VIVO" das linhas foi substituído pela programação EPG atual quando disponível.
- O mesmo EPG aparece nas linhas da lista lateral em tela cheia.
- Em tela cheia, DPAD CIMA/BAIXO e CHANNEL UP/DOWN trocam para o canal anterior/próximo sem abrir a lista.
- Troca de stream ficou mais direta: o Media3 recebe a nova mídia sem ciclo extra de stop/clear antes do prepare.
- Nenhuma alteração visual adicional foi feita fora desses comportamentos.


## Alpha 24 — correção TV Box / lista fullscreen
- Tela cheia: CIMA/BAIXO e CHANNEL UP/DOWN não trocam mais o stream imediatamente.
- Ao usar essas teclas, a lista lateral abre já no canal que está tocando, marcado.
- CIMA/BAIXO apenas move o foco; o canal só troca ao confirmar com OK.
- Após confirmar outro canal, a lista continua aberta e o novo canal permanece marcado/focado.
- Layout, EPG, player e demais funções da Alpha 23 foram preservados.


## Alpha 25 — navegação D-pad estável
- Remove I/O de EPG do evento de foco para suportar subir/descer rapidamente.
- Atualizações de EPG no RecyclerView são coalescidas e reagendadas se a lista estiver calculando layout.
- Remove animações de escala por item durante rajadas do controle.
- Mantém troca de canal somente no OK.

## Alpha 26 — diagnóstico temporário de rebuffer
- Adiciona indicador temporário no player para diferenciar BUFFERING da fonte de novo PREPARE disparado pelo app.
- Bloqueia re-prepare do mesmo URL quando o stream já está ativo.
- Exibe contadores P (prepare) e B (buffer) durante o teste.
- Mensagem "BUFFER DA FONTE • sem novo prepare" indica rebuffer sem reinicialização pelo app.
- Mensagem "APP ABRINDO STREAM" / "PREPARE" indica que o aplicativo iniciou/reiniciou o stream.
- O indicador é apenas de diagnóstico e deve ser removido depois do teste.


## Alpha 27
- Remove o diagnóstico temporário do player (READY/BUFFER/PREPARE/P/B).
- Sessão salva abre diretamente em TvActivity, sem passar pela tela Home vazia.
- Login bem-sucedido também entra diretamente em TV.
- Mantém a proteção contra reprepare do mesmo stream.


## Alpha 28 — Ícones das categorias no topo
- Aplicadas as artes fornecidas pelo usuário na barra superior de TV: Futebol, Filmes, Séries, Kids, Anime e HOT.
- Mantidos TV, Favoritos, relógio, consumo de rede, player, EPG e navegação exatamente como na Alpha 27.
- As artes foram preparadas com fundo transparente para integração no cabeçalho escuro.
- versionCode: 5028
- versionName: 5.0.28-alpha-icones-topo

## Alpha 30 - TV rápida + logos completas
- Cache local do catálogo de canais: a lista abre imediatamente com o último catálogo e atualiza Xtream em segundo plano.
- Resposta nova da API não reinicia o mesmo canal que já está tocando.
- URLs de `stream_icon` agora são normalizadas (absoluta, relativa, `//`, espaços e barras escapadas).
- Pré-carregamento das primeiras logos visíveis para reduzir logos vazias durante a navegação.
- EPG continua carregando depois da lista, sem bloquear a abertura dos canais.
