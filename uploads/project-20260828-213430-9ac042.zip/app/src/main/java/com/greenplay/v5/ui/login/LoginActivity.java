package com.greenplay.v5.ui.login;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import com.greenplay.v5.core.network.NetworkProvider;
import com.greenplay.v5.core.network.PanelHost;
import com.greenplay.v5.core.session.SessionStore;
import com.greenplay.v5.data.model.LoginResponse;
import com.greenplay.v5.data.model.StatusResponse;
import com.greenplay.v5.data.repository.AuthRepository;
import com.greenplay.v5.databinding.ActivityLoginBinding;
import com.greenplay.v5.ui.tv.TvActivity;
import com.squareup.picasso.Picasso;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public final class LoginActivity extends AppCompatActivity {
    private ActivityLoginBinding b;
    private AuthRepository auth;
    private int trialHours = 3;
    private boolean trialEnabled = false;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        b = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        auth = new AuthRepository(this);

        SessionStore session = new SessionStore(this);
        if (session.isLogged() && !session.host().trim().isEmpty() && !session.user().trim().isEmpty() && !session.pass().isEmpty()) {
            openTv();
            return;
        }

        b.btnEnter.setOnClickListener(v -> login());
        b.btnTrial.setOnClickListener(v -> createTrial());
        loadPanelBranding();
    }

    private void loadPanelBranding() {
        NetworkProvider.panel().status().enqueue(new Callback<StatusResponse>() {
            @Override public void onResponse(Call<StatusResponse> call, Response<StatusResponse> response) {
                StatusResponse st = response.body();
                if (!response.isSuccessful() || st == null) return;
                runOnUiThread(() -> applyStatus(st));
            }
            @Override public void onFailure(Call<StatusResponse> call, Throwable t) { }
        });
    }

    private void applyStatus(StatusResponse st) {
        if (st.name != null && !st.name.trim().isEmpty()) b.welcomeTitle.setText("BEM-VINDO!");

        String logo = absoluteAsset(st.appLogo);
        if (!logo.isEmpty()) {
            Picasso.get().load(logo).fit().centerInside().into(b.appLogo, new com.squareup.picasso.Callback() {
                @Override public void onSuccess() { b.appLogo.setVisibility(View.VISIBLE); b.fallbackLogo.setVisibility(View.GONE); }
                @Override public void onError(Exception e) { b.appLogo.setVisibility(View.GONE); b.fallbackLogo.setVisibility(View.VISIBLE); }
            });
        }

        String bg = absoluteAsset(st.loginBackground);
        if (!bg.isEmpty()) {
            b.loginBackground.setVisibility(View.VISIBLE);
            Picasso.get().load(bg).fit().centerCrop().into(b.loginBackground);
        }

        trialEnabled = st.trialEnabled;
        trialHours = Math.max(1, st.trialHours);
        if (trialEnabled) {
            b.btnTrial.setVisibility(View.VISIBLE);
            b.btnTrial.setText("⚡ TESTE AUTOMÁTICO  •  " + trialHours + (trialHours == 1 ? " HORA" : " HORAS"));
        } else {
            b.btnTrial.setVisibility(View.GONE);
        }
    }

    private String absoluteAsset(String raw) {
        if (raw == null) return "";
        String s = raw.trim();
        if (s.isEmpty()) return "";
        if (s.startsWith("http://") || s.startsWith("https://")) return s;
        String root = PanelHost.root();
        if (root.endsWith("/")) root = root.substring(0, root.length() - 1);
        return root + (s.startsWith("/") ? s : "/" + s);
    }

    private void setLoading(boolean loading, String text) {
        b.progress.setVisibility(loading ? View.VISIBLE : View.GONE);
        b.btnEnter.setEnabled(!loading);
        b.btnTrial.setEnabled(!loading && trialEnabled);
        if (text != null) b.txtError.setText(text);
    }

    private void login() {
        String user = b.inputUser.getText().toString().trim();
        String pass = b.inputPass.getText().toString();
        if (user.isEmpty() || pass.isEmpty()) { b.txtError.setText("Digite usuário e senha"); return; }
        setLoading(true, "");
        String device = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        auth.login(user, pass, device, new AuthRepository.Result() {
            @Override public void success(LoginResponse login) { runOnUiThread(() -> openTv()); }
            @Override public void error(String message) { runOnUiThread(() -> setLoading(false, message)); }
        });
    }

    private void createTrial() {
        if (!trialEnabled) return;
        setLoading(true, "Criando teste de " + trialHours + (trialHours == 1 ? " hora..." : " horas..."));
        String device = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        NetworkProvider.panel().trial(device).enqueue(new Callback<LoginResponse>() {
            @Override public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                LoginResponse body = response.body();
                if (!response.isSuccessful() || body == null || !body.ok) {
                    String msg = body != null && body.message != null ? body.message : "Teste indisponível no momento";
                    runOnUiThread(() -> setLoading(false, msg));
                    return;
                }
                String user = body.username == null ? "" : body.username.trim();
                String pass = body.xtreamPassword == null ? "" : body.xtreamPassword;
                String host = body.xtreamHost == null || body.xtreamHost.trim().isEmpty() ? PanelHost.root() : body.xtreamHost.trim();
                new SessionStore(LoginActivity.this).save(host, user, pass, body.expiresAt, body.plan, body.adultAccess, body.userToken);
                runOnUiThread(() -> openTv());
            }
            @Override public void onFailure(Call<LoginResponse> call, Throwable t) {
                runOnUiThread(() -> setLoading(false, "Sem conexão com o painel"));
            }
        });
    }

    private void openTv() {
        startActivity(new Intent(LoginActivity.this, TvActivity.class));
        finish();
    }
}
