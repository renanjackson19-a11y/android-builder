package com.ativacao.app;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.text.Editable;
import android.text.TextWatcher;

import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.PlayerView;
import androidx.media3.ui.AspectRatioFrameLayout;

import java.util.ArrayList;
import java.util.List;

/** TV: lista/categorias à esquerda + preview à direita. Primeiro OK seleciona; segundo OK abre tela cheia. */
public class LiveTvActivity extends android.app.Activity {
    private final List<ApiClient.Item> allChannels = new ArrayList<>();
    private LinearLayout rows;
    private GridLayout categoryRow;
    private PlayerView preview;
    private FrameLayout playerCard;
    private FrameLayout shell, fullscreenLayer;
    private LinearLayout content;
    private LinearLayout.LayoutParams playerNormalLp;
    private boolean fullscreen = false;
    private ExoPlayer player;
    private TextView title, epgNow, epgNext, hint;
    private ProgressBar loading;
    private EditText searchField;
    private String searchQuery = "";
    private ApiClient.Item current;
    private View currentRow;
    private long armedChannelId = -1L;
    private String activeCategory = "";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        immersive();
        setContentView(build());
        loadChannels();
    }

    private View build() {
        shell = new FrameLayout(this);
        LinearLayout root = Ui.column(this);
        root.setBackground(Ui.diagonalGradient(Color.rgb(6, 10, 7), Color.rgb(2, 4, 3), 0, this));
        shell.addView(root, new FrameLayout.LayoutParams(-1,-1));

        fullscreenLayer = new FrameLayout(this);
        fullscreenLayer.setBackgroundColor(Color.BLACK);
        fullscreenLayer.setVisibility(View.GONE);
        shell.addView(fullscreenLayer, new FrameLayout.LayoutParams(-1,-1));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(Ui.dp(this, 18), Ui.dp(this, 4), Ui.dp(this, 18), 0);
        TextView brand = Ui.text(this, "▣  DUBAI PLAY", Ui.phone(this)?13:16, Color.WHITE, true);
        header.addView(brand, new LinearLayout.LayoutParams(Ui.dp(this, 190), -1));
        LinearLayout nav = new LinearLayout(this); nav.setGravity(Gravity.CENTER_VERTICAL);
        addNav(nav,"TV",true, null);
        addNav(nav,"DESTAQUES",false, this::openMain);
        addNav(nav,"FILMES",false, () -> openCatalog("movie","Filmes"));
        addNav(nav,"SÉRIES",false, () -> openCatalog("series","Séries"));
        addNav(nav,"KIDS",false, () -> openDiscover("kids","Kids"));
        addNav(nav,"ANIME",false, () -> openDiscover("anime","Anime"));
        addNav(nav,"EXPLORAR",false, () -> openDiscover("explore","Explorar"));
        header.addView(nav, new LinearLayout.LayoutParams(0,-1,1));
        TextView tools = Ui.ghostButton(this,"⌕");
        tools.setContentDescription("Pesquisar canais");
        tools.setOnClickListener(v -> { if(searchField!=null){ searchField.requestFocus(); } });
        header.addView(tools,new LinearLayout.LayoutParams(Ui.dp(this,44),Ui.dp(this,38)));
        root.addView(header,new LinearLayout.LayoutParams(-1,Ui.dp(this,58)));

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.HORIZONTAL);
        content.setPadding(Ui.dp(this, 18), Ui.dp(this, 7), Ui.dp(this, 18), Ui.dp(this, 14));

        LinearLayout left = Ui.column(this);
        TextView lh=Ui.text(this,"Lista de Canais",14,Color.WHITE,true); lh.setPadding(Ui.dp(this,8),0,0,0);
        left.addView(lh,new LinearLayout.LayoutParams(-1,Ui.dp(this,34)));

        searchField = new EditText(this);
        searchField.setSingleLine(true);
        searchField.setHint("Pesquisar canal...");
        searchField.setHintTextColor(Ui.MUTED);
        searchField.setTextColor(Color.WHITE);
        searchField.setTextSize(10);
        searchField.setPadding(Ui.dp(this,12),0,Ui.dp(this,12),0);
        searchField.setBackground(Ui.stroke(0x45151E16,0x664B5F4D,12,this));
        searchField.setOnFocusChangeListener((v,has)->searchField.setBackground(Ui.stroke(0x45151E16,has?Ui.GREEN:0x664B5F4D,12,this)));
        searchField.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){
                searchQuery=s==null?"":s.toString().trim().toLowerCase();
                armedChannelId=-1L;
                renderRows();
            }
            public void afterTextChanged(Editable e){}
        });
        LinearLayout.LayoutParams searchLp=new LinearLayout.LayoutParams(-1,Ui.dp(this,38));
        searchLp.setMargins(Ui.dp(this,4),Ui.dp(this,2),Ui.dp(this,4),Ui.dp(this,5));
        left.addView(searchField,searchLp);

        categoryRow = new GridLayout(this);
        categoryRow.setColumnCount(1);
        categoryRow.setAlignmentMode(GridLayout.ALIGN_BOUNDS);
        categoryRow.setUseDefaultMargins(false);
        categoryRow.setPadding(Ui.dp(this, 4), Ui.dp(this, 2), Ui.dp(this, 4), Ui.dp(this, 4));
        left.addView(categoryRow,new LinearLayout.LayoutParams(-1,Ui.dp(this,48)));

        ScrollView sc=new ScrollView(this); sc.setVerticalScrollBarEnabled(false);
        rows=Ui.column(this); sc.addView(rows,new ScrollView.LayoutParams(-1,-2));
        left.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout.LayoutParams lpLeft=new LinearLayout.LayoutParams(Ui.dp(this,Ui.phone(this)?285:345),-1);
        lpLeft.rightMargin=Ui.dp(this,14); content.addView(left,lpLeft);

        playerCard=new FrameLayout(this);
        playerCard.setFocusable(true); playerCard.setClickable(true);
        Ui.focus(playerCard,this,Ui.stroke(Color.BLACK,0x334B5F4D,6,this),Ui.stroke(Color.BLACK,Ui.GREEN,6,this));
        preview=new PlayerView(this); preview.setUseController(false); preview.setBackgroundColor(Color.BLACK); preview.setKeepScreenOn(true); preview.setFocusable(false); preview.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        playerCard.addView(preview,new FrameLayout.LayoutParams(-1,-1));
        loading=new ProgressBar(this); playerCard.addView(loading,new FrameLayout.LayoutParams(Ui.dp(this,42),Ui.dp(this,42),Gravity.CENTER));

        LinearLayout info=Ui.column(this); info.setPadding(Ui.dp(this,16),Ui.dp(this,9),Ui.dp(this,16),Ui.dp(this,8)); info.setBackgroundColor(0xC20B0E0B);
        title=Ui.text(this,"Carregando canal...",13,Color.WHITE,true); title.setMaxLines(1); info.addView(title,new LinearLayout.LayoutParams(-1,Ui.dp(this,27)));
        epgNow=Ui.text(this,"AGORA  —",9,Color.WHITE,true); epgNow.setMaxLines(1); info.addView(epgNow,new LinearLayout.LayoutParams(-1,Ui.dp(this,22)));
        epgNext=Ui.text(this,"A SEGUIR  —",9,Ui.MUTED,false); epgNext.setMaxLines(1); info.addView(epgNext,new LinearLayout.LayoutParams(-1,Ui.dp(this,22)));
        hint=Ui.text(this,"OK no preview: tela cheia",9,Ui.GREEN,true); hint.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); info.addView(hint,new LinearLayout.LayoutParams(-1,Ui.dp(this,22)));
        FrameLayout.LayoutParams ip=new FrameLayout.LayoutParams(-1,Ui.dp(this,96),Gravity.BOTTOM); playerCard.addView(info,ip);
        playerCard.setOnClickListener(v -> openFullscreen());
        playerNormalLp = new LinearLayout.LayoutParams(0,-1,1);
        content.addView(playerCard,playerNormalLp);
        root.addView(content,new LinearLayout.LayoutParams(-1,0,1));
        return shell;
    }

    private void addNav(LinearLayout row,String label,boolean selected,Runnable action){
        TextView v=Ui.nav(this,label,selected); if(action!=null)v.setOnClickListener(x->action.run());
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1); row.addView(v,p);
    }

    private void loadChannels(){
        ApiClient.catalog("live",1,300,"","","",new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){runOnUiThread(()->renderAll(p==null?null:p.items));}
            public void error(String m){runOnUiThread(()->Toast.makeText(LiveTvActivity.this,"Não foi possível carregar os canais",Toast.LENGTH_LONG).show());}
        });
    }

    private void renderAll(List<ApiClient.Item> list){
        allChannels.clear(); if(list!=null)allChannels.addAll(list);
        renderCategories(); renderRows();
    }

    private void renderCategories(){
        categoryRow.removeAllViews();
        activeCategory = "";
        addCategoryChip("Todos","");
    }

    private void addCategoryChip(String label,String value){
        String compact = label == null ? "" : label.replace("CH: ", "").trim();
        TextView chip=Ui.text(this,compact,8,value.equals(activeCategory)?Color.BLACK:Ui.TEXT,true);
        chip.setGravity(Gravity.CENTER); chip.setFocusable(true); chip.setClickable(true); chip.setMaxLines(1); chip.setEllipsize(android.text.TextUtils.TruncateAt.END);
        chip.setBackground(value.equals(activeCategory)?Ui.round(Ui.GREEN,14,this):Ui.round(0x55202A21,14,this));
        chip.setPadding(Ui.dp(this,8),0,Ui.dp(this,8),0);
        chip.setOnClickListener(v->{activeCategory=value;armedChannelId=-1;renderCategories();renderRows();});
        GridLayout.LayoutParams p=new GridLayout.LayoutParams();
        p.width=0; p.height=Ui.dp(this,32);
        p.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);
        p.setMargins(Ui.dp(this,3),Ui.dp(this,2),Ui.dp(this,3),Ui.dp(this,2));
        categoryRow.addView(chip,p);
    }

    private void renderRows(){
        rows.removeAllViews();
        List<ApiClient.Item> visible=new ArrayList<>();
        for(ApiClient.Item i:allChannels){
            if(!activeCategory.isEmpty()&&!activeCategory.equals(clean(i.group,""))) continue;
            String nm=clean(i.name,"").toLowerCase();
            if(!searchQuery.isEmpty()&&!nm.contains(searchQuery)) continue;
            visible.add(i);
        }
        if(visible.isEmpty()){rows.addView(Ui.text(this,"Nenhum canal nesta categoria",10,Ui.MUTED,false));return;}

        ApiClient.Item last=LocalStore.lastLive(this); ApiClient.Item initial=null;
        if(current!=null) for(ApiClient.Item x:visible)if(x.id==current.id){initial=x;break;}
        if(initial==null&&last!=null)for(ApiClient.Item x:visible)if(x.id==last.id){initial=x;break;}
        if(initial==null)initial=visible.get(0);
        View focus=null; int n=1;
        for(ApiClient.Item i:visible){
            LinearLayout r=new LinearLayout(this); r.setGravity(Gravity.CENTER_VERTICAL); r.setPadding(Ui.dp(this,7),Ui.dp(this,4),Ui.dp(this,8),Ui.dp(this,4)); r.setFocusable(true); r.setClickable(true);
            TextView num=Ui.text(this,String.valueOf(n++),9,Ui.MUTED,true); num.setGravity(Gravity.CENTER); r.addView(num,new LinearLayout.LayoutParams(Ui.dp(this,28),-1));
            ImageView logo=new ImageView(this);logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);logo.setBackground(Ui.round(0x25FFFFFF,7,this));ImageLoader.into(this,logo,i.logo);
            LinearLayout.LayoutParams lip=new LinearLayout.LayoutParams(Ui.dp(this,40),Ui.dp(this,40));lip.rightMargin=Ui.dp(this,9);r.addView(logo,lip);
            TextView name=Ui.text(this,clean(i.name,"Canal"),10,Color.WHITE,true);name.setMaxLines(1);name.setGravity(Gravity.CENTER_VERTICAL);
            r.addView(name,new LinearLayout.LayoutParams(0,-1,1));
            android.graphics.drawable.Drawable normal=Ui.round(0x25131B14,7,this), focused=Ui.stroke(0xB3233024,Ui.GREEN,7,this);
            r.setBackground(normal);
            r.setOnFocusChangeListener((v,has)->{
                v.animate().scaleX(has?1.015f:1f).scaleY(has?1.015f:1f).setDuration(90).start();
                v.setBackground(has?focused:normal);
                if(has){
                    if(current==null || current.id!=i.id){
                        armedChannelId=-1L;
                        previewChannel(i,v);
                    } else {
                        currentRow=v;
                    }
                }
            });
            r.setOnClickListener(v->{
                // OK em OUTRO canal: troca o preview uma única vez e arma o canal.
                // OK no MESMO canal: não recarrega; segundo OK abre tela cheia.
                if(current==null || current.id!=i.id){
                    armedChannelId=i.id;
                    previewChannel(i,v);
                    currentRow=v;
                    hint.setText("OK novamente: tela cheia  •  ou OK no preview");
                    return;
                }
                if(armedChannelId==i.id){
                    openFullscreen();
                    return;
                }
                armedChannelId=i.id;
                currentRow=v;
                hint.setText("OK novamente: tela cheia  •  ou OK no preview");
            });
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,Ui.dp(this,52)); rp.bottomMargin=Ui.dp(this,4); rows.addView(r,rp);
            if(i.id==initial.id)focus=r;
        }
        previewChannel(initial,focus); if(focus!=null)focus.requestFocus();
    }

    private void previewChannel(ApiClient.Item i, View row){
        if(i==null)return;
        if(current!=null && current.id==i.id){currentRow=row;return;}
        current=i; currentRow=row; LocalStore.saveLastLive(this,i);
        title.setText(clean(i.name,"Canal")); epgNow.setText("AGORA  Carregando programação..."); epgNext.setText("A SEGUIR  —"); hint.setText("1º OK seleciona • 2º OK abre tela cheia");
        loadEpg(i.id); startPreview(i.id);
    }

    private void startPreview(long id){
        loading.setVisibility(View.VISIBLE);
        if(player!=null){try{player.release();}catch(Exception ignored){}}
        DefaultHttpDataSource.Factory http=new DefaultHttpDataSource.Factory().setUserAgent("DubaiPlayTV/2.6.5 Android").setConnectTimeoutMs(6000).setReadTimeoutMs(30000).setAllowCrossProtocolRedirects(true);
        player=new ExoPlayer.Builder(this).setMediaSourceFactory(new DefaultMediaSourceFactory(this).setDataSourceFactory(http)).build();
        preview.setPlayer(player);
        player.addListener(new Player.Listener(){@Override public void onPlaybackStateChanged(int state){if(state==Player.STATE_READY)loading.setVisibility(View.GONE);}});
        player.setMediaItem(MediaItem.fromUri(ApiClient.streamUrl(id))); player.prepare(); player.play();
    }

    private void loadEpg(long id){
        ApiClient.epg(id,new ApiClient.Callback<ApiClient.EpgInfo>(){
            public void ok(ApiClient.EpgInfo e){runOnUiThread(()->{if(current==null||current.id!=id)return;epgNow.setText("AGORA  "+clean(e.nowTitle,"Sem informação"));epgNext.setText("A SEGUIR  "+clean(e.nextTitle,"—"));});}
            public void error(String m){runOnUiThread(()->{if(current!=null&&current.id==id){epgNow.setText("AGORA  Sem informação");epgNext.setText("A SEGUIR  —");}});}
        });
    }

    private void openFullscreen(){
        if(current==null || fullscreen)return;
        fullscreen=true;
        if(playerCard.getParent() instanceof android.view.ViewGroup){
            ((android.view.ViewGroup)playerCard.getParent()).removeView(playerCard);
        }
        fullscreenLayer.removeAllViews();
        preview.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_ZOOM);
        fullscreenLayer.addView(playerCard,new FrameLayout.LayoutParams(-1,-1));
        fullscreenLayer.setVisibility(View.VISIBLE);
        fullscreenLayer.bringToFront();
        hint.setText("VOLTAR: lista de canais");
        playerCard.requestFocus();
        immersive();
    }

    private void closeFullscreen(){
        if(!fullscreen)return;
        fullscreen=false;
        if(playerCard.getParent() instanceof android.view.ViewGroup){
            ((android.view.ViewGroup)playerCard.getParent()).removeView(playerCard);
        }
        fullscreenLayer.setVisibility(View.GONE);
        preview.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        content.addView(playerCard,playerNormalLp);
        hint.setText("1º OK seleciona • 2º OK abre tela cheia");
        if(currentRow!=null) currentRow.requestFocus();
        immersive();
    }

    private void openMain(){Intent in=new Intent(this,MainActivity.class);in.putExtra("show_highlights",true);startActivity(in);finish();}
    private void openCatalog(String type,String name){Intent in=new Intent(this,CatalogActivity.class);in.putExtra("type",type);in.putExtra("title",name);startActivity(in);}
    private void openDiscover(String smart,String name){Intent in=new Intent(this,DiscoverActivity.class);in.putExtra("smart",smart);in.putExtra("title",name);startActivity(in);}

    @Override public void onBackPressed(){if(fullscreen){closeFullscreen();return;}finish();}
    @Override protected void onResume(){super.onResume();immersive();if(player!=null)player.play();}
    @Override protected void onPause(){if(player!=null)player.pause();super.onPause();}
    @Override protected void onDestroy(){super.onDestroy();if(player!=null){try{player.release();}catch(Exception ignored){}}}
    private void immersive(){WindowCompat.setDecorFitsSystemWindows(getWindow(),false);WindowInsetsControllerCompat c=WindowCompat.getInsetsController(getWindow(),getWindow().getDecorView());c.hide(WindowInsetsCompat.Type.systemBars());c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);}
    private String clean(String v,String f){if(v==null)return f;String s=v.trim();return s.isEmpty()||"null".equalsIgnoreCase(s)?f:s;}
}
