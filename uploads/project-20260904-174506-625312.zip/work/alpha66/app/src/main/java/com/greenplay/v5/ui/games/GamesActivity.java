package com.greenplay.v5.ui.games;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

import com.greenplay.v5.databinding.ActivityGamesBinding;

/**
 * GREEN PLAY - Jogos de hoje.
 *
 * O item de Futebol/Jogos da barra superior abre o provedor fornecido pelo
 * administrador dentro do próprio aplicativo. Não depende do servidor Xtream
 * do cliente e não altera TV, Filmes ou Séries.
 */
public final class GamesActivity extends AppCompatActivity {
    private static final String GAMES_URL = "https://infynix.spanel.space/jogos/index.php";

    private ActivityGamesBinding b;
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        b = ActivityGamesBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        com.greenplay.v5.core.ui.UniversalUi.apply(this, b.getRoot());
        configureWebView();

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                if (customView != null) {
                    hideCustomView();
                } else if (b.gamesWeb.canGoBack()) {
                    b.gamesWeb.goBack();
                } else {
                    finish();
                }
            }
        });

        if (state == null) b.gamesWeb.loadUrl(GAMES_URL);
        else b.gamesWeb.restoreState(state);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configureWebView() {
        WebSettings s = b.gamesWeb.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(false);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        }

        CookieManager.getInstance().setAcceptCookie(true);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(b.gamesWeb, true);
        }

        b.gamesWeb.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, Bitmap favicon) {
                b.gamesLoading.setVisibility(View.VISIBLE);
                b.gamesError.setVisibility(View.GONE);
            }

            @Override public void onPageFinished(WebView view, String url) {
                b.gamesLoading.setVisibility(View.GONE);
                b.gamesWeb.requestFocus();
            }

            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(view, request.getUrl());
            }

            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(view, Uri.parse(url));
            }

            @Override public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                b.gamesLoading.setVisibility(View.GONE);
                if (failingUrl != null && failingUrl.equals(view.getUrl())) showLoadError();
            }
        });

        b.gamesWeb.setWebChromeClient(new WebChromeClient() {
            @Override public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) {
                    callback.onCustomViewHidden();
                    return;
                }
                customView = view;
                customViewCallback = callback;
                b.gamesWeb.setVisibility(View.GONE);
                b.gamesCustom.addView(view);
                b.gamesCustom.setVisibility(View.VISIBLE);
            }

            @Override public void onHideCustomView() {
                hideCustomView();
            }
        });

        b.gamesRetry.setOnClickListener(v -> {
            b.gamesError.setVisibility(View.GONE);
            b.gamesWeb.loadUrl(GAMES_URL);
        });
    }

    private boolean handleUrl(WebView view, Uri uri) {
        if (uri == null) return false;
        String scheme = uri.getScheme();
        if (scheme == null || "http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
            view.loadUrl(uri.toString());
            return true;
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível abrir este link", Toast.LENGTH_SHORT).show();
        }
        return true;
    }

    private void showLoadError() {
        b.gamesError.setVisibility(View.VISIBLE);
    }

    private void hideCustomView() {
        if (customView == null) return;
        b.gamesCustom.removeView(customView);
        b.gamesCustom.setVisibility(View.GONE);
        b.gamesWeb.setVisibility(View.VISIBLE);
        customView = null;
        if (customViewCallback != null) customViewCallback.onCustomViewHidden();
        customViewCallback = null;
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        b.gamesWeb.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override protected void onDestroy() {
        if (b != null) {
            b.gamesWeb.stopLoading();
            b.gamesWeb.setWebChromeClient(null);
            b.gamesWeb.setWebViewClient(null);
            b.gamesWeb.destroy();
        }
        super.onDestroy();
    }
}
