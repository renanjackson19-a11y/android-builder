package com.ativacao.app;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.LruCache;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class ImageLoader {
    private static final ExecutorService IMAGES = Executors.newFixedThreadPool(6);
    private static final Set<String> IN_FLIGHT = Collections.synchronizedSet(new HashSet<>());
    private static final int CACHE_KB = 24 * 1024;
    private static final LruCache<String, Bitmap> CACHE = new LruCache<String, Bitmap>(CACHE_KB) {
        @Override protected int sizeOf(String key, Bitmap value) {
            return Math.max(1, value.getByteCount() / 1024);
        }
    };

    static void into(Activity a, ImageView target, String url) {
        if (url == null || url.trim().isEmpty()) return;
        final String u = url.trim();
        target.setTag(u);

        Bitmap hit = CACHE.get(u);
        if (hit != null) {
            target.setImageBitmap(hit);
            return;
        }

        // Cache persistente: mostra imediatamente a capa já vista, sem depender da rede.
        Bitmap disk = readDisk(a, u);
        if (disk != null) {
            CACHE.put(u, disk);
            target.setImageBitmap(disk);
            return;
        }

        if (!IN_FLIGHT.add(u)) return;
        IMAGES.execute(() -> download(a, u, target));
    }

    static void prefetch(Context c, String url) {
        if (c == null || url == null || url.trim().isEmpty()) return;
        final String u = url.trim();
        if (CACHE.get(u) != null || diskFile(c, u).exists() || !IN_FLIGHT.add(u)) return;
        IMAGES.execute(() -> download(c, u, null));
    }

    private static void download(Context c, String u, ImageView target) {
        HttpURLConnection con = null;
        try {
            con = (HttpURLConnection) new URL(u).openConnection();
            con.setConnectTimeout(4500);
            con.setReadTimeout(8000);
            con.setInstanceFollowRedirects(true);
            con.setRequestProperty("User-Agent", "DubaiPlayTV/1.4 Android");
            con.setRequestProperty("Accept", "image/avif,image/webp,image/apng,image/*,*/*;q=0.8");
            int code = con.getResponseCode();
            if (code < 200 || code >= 300) return;

            InputStream in = con.getInputStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream(96 * 1024);
            byte[] buf = new byte[16 * 1024];
            int n;
            int max = 3 * 1024 * 1024;
            while ((n = in.read(buf)) > 0 && out.size() < max) out.write(buf, 0, n);
            in.close();
            byte[] data = out.toByteArray();
            if (data.length == 0) return;

            Bitmap bmp = decode(data);
            if (bmp != null) {
                CACHE.put(u, bmp);
                writeDisk(c, u, data);
                if (target != null && c instanceof Activity) {
                    Activity a = (Activity)c;
                    a.runOnUiThread(() -> {
                        Object tag = target.getTag();
                        if (tag != null && u.equals(tag.toString())) target.setImageBitmap(bmp);
                    });
                }
            }
        } catch (Exception ignored) {
        } finally {
            IN_FLIGHT.remove(u);
            if (con != null) con.disconnect();
        }
    }

    private static Bitmap decode(byte[] data) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(data, 0, data.length, bounds);
            int sample = 1;
            while (bounds.outWidth / sample > 720 || bounds.outHeight / sample > 960) sample *= 2;
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = Math.max(1, sample);
            opts.inPreferredConfig = Bitmap.Config.RGB_565;
            return BitmapFactory.decodeByteArray(data, 0, data.length, opts);
        } catch (Exception e) { return null; }
    }

    private static File diskDir(Context c) {
        File d = new File(c.getCacheDir(), "covers_v2");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    private static File diskFile(Context c, String u) {
        return new File(diskDir(c), Integer.toHexString(u.hashCode()) + ".img");
    }

    private static Bitmap readDisk(Context c, String u) {
        try {
            File f = diskFile(c, u);
            if (!f.exists() || f.length() <= 0) return null;
            FileInputStream in = new FileInputStream(f);
            Bitmap b = BitmapFactory.decodeStream(in);
            in.close();
            return b;
        } catch (Exception e) { return null; }
    }

    private static void writeDisk(Context c, String u, byte[] data) {
        try {
            File f = diskFile(c, u);
            FileOutputStream fos = new FileOutputStream(f);
            fos.write(data);
            fos.flush();
            fos.close();
        } catch (Exception ignored) {}
    }

    static void clear() { CACHE.evictAll(); }
}
