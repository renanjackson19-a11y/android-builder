package com.ativacao.app;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class OpenGameCatalog {
    interface Callback{void ok(List<Game> data);void error(String msg);}
    interface GameCallback{void ok(Game g);}
    static class Game{
        String name="",platform="",folder="",year="",synopsis="",serial="",cover="";
        Game(String n,String p,String f){name=n;platform=p;folder=f;}
    }
    private static final ExecutorService IO=Executors.newFixedThreadPool(4);
    private static final String RAW="https://raw.githubusercontent.com/0u73r-h34v3n/opengamesdatabase/master/platforms/";

    static void load(String mode,Callback cb){
        IO.execute(()->{
            try{
                ArrayList<Game> out=new ArrayList<>();
                if("retro".equals(mode)){loadMap("DS","Nintendo DS",out,48);loadMap("3DS","Nintendo 3DS",out,36);loadMap("PS2","PlayStation 2",out,48);}
                else if("ps2".equals(mode))loadMap("PS2","PlayStation 2",out,120);
                else if("ds".equals(mode))loadMap("DS","Nintendo DS",out,120);
                else if("3ds".equals(mode))loadMap("3DS","Nintendo 3DS",out,120);
                cb.ok(out);
            }catch(Exception e){cb.error("Não foi possível carregar o catálogo agora.");}
        });
    }

    static void enrich(Game g,GameCallback cb){
        if(g==null){return;} if(!g.synopsis.isEmpty()||!g.cover.isEmpty()){cb.ok(g);return;}
        IO.execute(()->{
            try{
                String folder=g.platform.equals("PlayStation 2")?"PS2":g.platform.equals("Nintendo 3DS")?"3DS":"DS";
                String path=enc(g.folder.isEmpty()?g.name:g.folder);
                JSONObject m=new JSONObject(get(RAW+folder+"/"+path+"/metadata.json"));
                g.name=m.optString("name",g.name);
                g.synopsis=m.optString("synopsis","");
                String rd=m.optString("release_date",""); if(rd.length()>=4)g.year=rd.substring(0,4);
                Object sn=m.opt("serial_number");
                if(sn instanceof JSONArray && ((JSONArray)sn).length()>0)g.serial=((JSONArray)sn).optString(0,"");
                else if(sn!=null)g.serial=String.valueOf(sn);
                g.serial=g.serial.replace("[","").replace("]","").replace("\"","").trim();
                String id=g.serial;
                if(g.platform.equals("PlayStation 2")&&!id.isEmpty()){
                    String clean=id.replace("-", "_").replace(" ","");
                    g.cover="https://raw.githubusercontent.com/xlenore/ps2-covers/main/covers/"+clean+".jpg";
                }else if(g.platform.equals("Nintendo DS")&&!id.isEmpty()){
                    g.cover="https://art.gametdb.com/ds/cover/US/"+id+".png";
                }else if(g.platform.equals("Nintendo 3DS")&&!id.isEmpty()){
                    g.cover="https://art.gametdb.com/3ds/cover/US/"+id+".png";
                }
            }catch(Exception ignored){}
            cb.ok(g);
        });
    }

    private static void loadMap(String folder,String platform,List<Game> out,int limit)throws Exception{
        String raw=get(RAW+folder+"/map.json"); Object parsed=new org.json.JSONTokener(raw).nextValue();
        if(parsed instanceof JSONObject){JSONObject o=(JSONObject)parsed;Iterator<String> it=o.keys();while(it.hasNext()&&countPlatform(out,platform)<limit){String k=it.next();Object val=o.opt(k);String n=k;String f=k;if(val instanceof String&&!((String)val).trim().isEmpty())n=(String)val;else if(val instanceof JSONObject)n=((JSONObject)val).optString("name",k);if(!n.trim().isEmpty())out.add(new Game(n.trim(),platform,f));}}
        else if(parsed instanceof JSONArray){JSONArray a=(JSONArray)parsed;for(int i=0;i<a.length()&&countPlatform(out,platform)<limit;i++){Object val=a.opt(i);String n="",f="";if(val instanceof String){n=(String)val;f=n;}else if(val instanceof JSONObject){n=((JSONObject)val).optString("name","");f=((JSONObject)val).optString("folder",n);}if(!n.trim().isEmpty())out.add(new Game(n.trim(),platform,f));}}
    }
    private static int countPlatform(List<Game>a,String p){int c=0;for(Game g:a)if(p.equals(g.platform))c++;return c;}
    private static String enc(String s)throws Exception{return URLEncoder.encode(s,"UTF-8").replace("+","%20");}
    private static String get(String u)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(9000);c.setRequestProperty("User-Agent","DubaiPlayTV/3.0.5");BufferedReader b=new BufferedReader(new InputStreamReader(c.getInputStream()));StringBuilder s=new StringBuilder();String l;while((l=b.readLine())!=null)s.append(l);b.close();c.disconnect();return s.toString();}
}
