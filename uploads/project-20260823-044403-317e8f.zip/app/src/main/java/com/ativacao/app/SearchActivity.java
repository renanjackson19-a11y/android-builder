package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class SearchActivity extends Activity {
    private final List<ApiClient.Item> items=new ArrayList<>();
    private GridView grid;private ResultAdapter adapter;private EditText query;private TextView title,status;private final Handler handler=new Handler();private Runnable searchTask;private boolean phone;
    @Override public void onCreate(Bundle b){super.onCreate(b);Ui.immersive(this);phone=Ui.phone(this);setContentView(build());loadPopular();}
    private View build(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.HORIZONTAL);root.setBackgroundColor(Ui.BG);root.setPadding(Ui.dp(this,phone?14:24),Ui.dp(this,12),Ui.dp(this,phone?14:24),Ui.dp(this,12));
        LinearLayout left=Ui.column(this);left.setPadding(Ui.dp(this,14),Ui.dp(this,10),Ui.dp(this,14),Ui.dp(this,10));left.setBackground(Ui.stroke(Ui.PANEL,Ui.BORDER,16,this));
        TextView back=Ui.button(this,"‹ VOLTAR");back.setOnClickListener(v->finish());left.addView(back,new LinearLayout.LayoutParams(Ui.dp(this,110),Ui.dp(this,40)));
        TextView h=Ui.text(this,"Buscar",phone?20:26,Ui.TEXT,true);LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,Ui.dp(this,50));hp.topMargin=Ui.dp(this,8);left.addView(h,hp);
        query=new EditText(this);query.setSingleLine(true);query.setHint("Filme, série ou canal...");query.setHintTextColor(Ui.MUTED);query.setTextColor(Ui.TEXT);query.setTextSize(phone?12:14);query.setImeOptions(EditorInfo.IME_ACTION_SEARCH);query.setBackground(Ui.stroke(Ui.PANEL_2,Ui.BORDER,12,this));query.setPadding(Ui.dp(this,14),0,Ui.dp(this,14),0);left.addView(query,new LinearLayout.LayoutParams(-1,Ui.dp(this,48)));
        TextView help=Ui.text(this,"Use a busca ou navegue pelas letras",10,Ui.MUTED,false);LinearLayout.LayoutParams hlp=new LinearLayout.LayoutParams(-1,Ui.dp(this,32));hlp.topMargin=Ui.dp(this,8);left.addView(help,hlp);
        String letters="ABCDEFGHIJKLMNOPQRSTUVWXYZ";LinearLayout letterWrap=Ui.column(this);for(int r=0;r<4;r++){LinearLayout line=new LinearLayout(this);for(int c=0;c<7;c++){int idx=r*7+c;if(idx>=letters.length())break;String s=String.valueOf(letters.charAt(idx));TextView b=Ui.ghostButton(this,s);b.setOnClickListener(v->{query.setText(s);query.setSelection(query.length());doSearch(s);});LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,Ui.dp(this,36),1);p.rightMargin=Ui.dp(this,3);p.bottomMargin=Ui.dp(this,3);line.addView(b,p);}letterWrap.addView(line,new LinearLayout.LayoutParams(-1,Ui.dp(this,39)));}left.addView(letterWrap,new LinearLayout.LayoutParams(-1,-2));
        TextView clear=Ui.button(this,"LIMPAR");clear.setOnClickListener(v->{query.setText("");loadPopular();});LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,Ui.dp(this,40));cp.topMargin=Ui.dp(this,8);left.addView(clear,cp);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(Ui.dp(this,phone?270:340),-1);lp.rightMargin=Ui.dp(this,14);root.addView(left,lp);
        LinearLayout right=Ui.column(this);title=Ui.text(this,"Buscas populares",phone?20:26,Ui.TEXT,true);right.addView(title,new LinearLayout.LayoutParams(-1,Ui.dp(this,46)));status=Ui.text(this,"",10,Ui.MUTED,false);right.addView(status,new LinearLayout.LayoutParams(-1,Ui.dp(this,28)));
        grid=new GridView(this);grid.setNumColumns(phone?5:6);grid.setHorizontalSpacing(Ui.dp(this,9));grid.setVerticalSpacing(Ui.dp(this,9));grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);grid.setSelector(android.R.color.transparent);adapter=new ResultAdapter();grid.setAdapter(adapter);right.addView(grid,new LinearLayout.LayoutParams(-1,0,1));root.addView(right,new LinearLayout.LayoutParams(0,-1,1));
        query.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){if(searchTask!=null)handler.removeCallbacks(searchTask);String q=s==null?"":s.toString().trim();if(q.isEmpty()){searchTask=SearchActivity.this::loadPopular;}else searchTask=()->doSearch(q);handler.postDelayed(searchTask,450);}public void afterTextChanged(Editable e){}});
        back.requestFocus();return root;
    }
    private void loadPopular(){title.setText("Buscas populares");status.setText("Atualizando destaques...");ApiClient.catalog("movie",1,12,"",new ApiClient.Callback<ApiClient.CatalogPage>(){public void ok(ApiClient.CatalogPage p){runOnUiThread(()->{items.clear();items.addAll(p.items);adapter.notifyDataSetChanged();status.setText(items.size()+" títulos em destaque");});}public void error(String m){runOnUiThread(()->status.setText("Falha: "+m));}});}
    private void doSearch(String q){title.setText("Resultados para “"+q+"”");status.setText("Pesquisando filmes e séries...");ApiClient.catalog("movie",1,18,q,new ApiClient.Callback<ApiClient.CatalogPage>(){public void ok(ApiClient.CatalogPage m){ApiClient.catalog("series",1,18,q,new ApiClient.Callback<ApiClient.CatalogPage>(){public void ok(ApiClient.CatalogPage s){runOnUiThread(()->{items.clear();items.addAll(m.items);items.addAll(s.items);adapter.notifyDataSetChanged();status.setText(items.size()+" resultados");if(!items.isEmpty())grid.requestFocus();});}public void error(String e){runOnUiThread(()->{items.clear();items.addAll(m.items);adapter.notifyDataSetChanged();status.setText(items.size()+" resultados");});}});}public void error(String e){runOnUiThread(()->status.setText("Não foi possível pesquisar • "+e));}});}
    private class ResultAdapter extends BaseAdapter{public int getCount(){return items.size();}public Object getItem(int p){return items.get(p);}public long getItemId(int p){return items.get(p).id;}public View getView(int p,View convert,android.view.ViewGroup parent){LinearLayout card;ImageViewHolder h;if(convert==null){card=Ui.column(SearchActivity.this);card.setPadding(Ui.dp(SearchActivity.this,5),Ui.dp(SearchActivity.this,5),Ui.dp(SearchActivity.this,5),Ui.dp(SearchActivity.this,5));card.setFocusable(true);card.setClickable(true);Ui.focus(card,SearchActivity.this);android.widget.ImageView img=new android.widget.ImageView(SearchActivity.this);img.setId(501);img.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);img.setBackgroundColor(Ui.PANEL_2);card.addView(img,new LinearLayout.LayoutParams(-1,Ui.dp(SearchActivity.this,phone?120:155)));TextView n=Ui.text(SearchActivity.this,"",phone?10:11,Ui.TEXT,true);n.setId(502);n.setMaxLines(2);card.addView(n,new LinearLayout.LayoutParams(-1,Ui.dp(SearchActivity.this,34)));TextView meta=Ui.text(SearchActivity.this,"",8,Ui.MUTED,false);meta.setId(503);card.addView(meta,new LinearLayout.LayoutParams(-1,Ui.dp(SearchActivity.this,18)));convert=card;}card=(LinearLayout)convert;android.widget.ImageView img=convert.findViewById(501);TextView n=convert.findViewById(502),meta=convert.findViewById(503);ApiClient.Item i=items.get(p);n.setText(clean(i.name,"Sem nome"));meta.setText(("series".equals(i.type)?"Série":"Filme")+(i.year>0?" • "+i.year:""));ImageLoader.into(SearchActivity.this,img,i.logo);card.setOnClickListener(v->{if("series".equals(i.type)){Intent in=new Intent(SearchActivity.this,SeriesActivity.class);in.putExtra("title",clean(i.seriesTitle,i.name));startActivity(in);}else{Intent in=new Intent(SearchActivity.this,DetailActivity.class);MainActivity.putItem(in,i);startActivity(in);}});return convert;}}
    private static class ImageViewHolder{}
    private String clean(String v,String f){if(v==null)return f;String s=v.trim();return s.isEmpty()||"null".equalsIgnoreCase(s)?f:s;}
}
