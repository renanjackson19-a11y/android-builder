package com.ativacao.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

final class Ui {
    static final int BG = Color.rgb(5, 7, 12);
    static final int BG_2 = Color.rgb(9, 12, 19);
    static final int PANEL = Color.rgb(17, 20, 28);
    static final int PANEL_2 = Color.rgb(24, 28, 38);
    static final int PANEL_3 = Color.rgb(32, 37, 49);
    static final int TEXT = Color.rgb(248, 249, 252);
    static final int MUTED = Color.rgb(158, 164, 177);
    static final int GREEN = Color.rgb(42, 220, 104);
    static final int GREEN_2 = Color.rgb(17, 146, 69);
    static final int GOLD = Color.rgb(255, 190, 67);
    static final int PURPLE = Color.rgb(122, 92, 255);
    static final int RED = Color.rgb(245, 87, 111);
    static final int BLUE = Color.rgb(63, 151, 255);
    static final int BORDER = Color.rgb(48, 54, 70);

    static int dp(Context c, int n) { return (int)(n * c.getResources().getDisplayMetrics().density + .5f); }
    static boolean phone(Context c) { return c.getResources().getConfiguration().smallestScreenWidthDp < 600; }
    static int sw(Context c) { return c.getResources().getConfiguration().screenWidthDp; }

    static GradientDrawable round(int color, int radiusDp, Context c) {
        GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(c, radiusDp)); return g;
    }
    static GradientDrawable stroke(int fill, int stroke, int radiusDp, Context c) {
        GradientDrawable g = round(fill, radiusDp, c); g.setStroke(dp(c, 1), stroke); return g;
    }
    static GradientDrawable gradient(int start, int end, int radiusDp, Context c) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{start, end});
        g.setCornerRadius(dp(c, radiusDp)); return g;
    }
    static GradientDrawable verticalGradient(int top, int bottom, int radiusDp, Context c) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{top, bottom});
        g.setCornerRadius(dp(c, radiusDp)); return g;
    }
    static TextView text(Context c, String s, int sp, int color, boolean bold) {
        TextView t = new TextView(c); t.setText(s); t.setTextSize(sp); t.setTextColor(color); t.setGravity(Gravity.CENTER_VERTICAL);
        t.setIncludeFontPadding(false); t.setTypeface(Typeface.create("sans", bold ? Typeface.BOLD : Typeface.NORMAL)); return t;
    }
    static TextView button(Context c, String s) {
        TextView b = text(c, s, phone(c) ? 11 : 13, TEXT, true); b.setGravity(Gravity.CENTER); b.setFocusable(true); b.setClickable(true);
        b.setPadding(dp(c, 12), dp(c, 7), dp(c, 12), dp(c, 7)); focus(b, c, stroke(PANEL_2, BORDER, 11, c), stroke(PANEL_3, GREEN, 11, c)); return b;
    }
    static TextView ghostButton(Context c, String s) {
        TextView b = text(c, s, phone(c) ? 10 : 12, MUTED, true); b.setGravity(Gravity.CENTER); b.setFocusable(true); b.setClickable(true);
        b.setPadding(dp(c, 10), dp(c, 6), dp(c, 10), dp(c, 6)); focus(b, c, round(Color.TRANSPARENT, 10, c), stroke(PANEL_2, GREEN, 10, c)); return b;
    }
    static TextView primaryButton(Context c, String s) {
        TextView b = text(c, s, phone(c) ? 11 : 13, Color.WHITE, true); b.setGravity(Gravity.CENTER); b.setFocusable(true); b.setClickable(true);
        b.setPadding(dp(c, 12), dp(c, 7), dp(c, 12), dp(c, 7)); focus(b, c, gradient(GREEN, GREEN_2, 11, c), gradient(Color.rgb(83,240,130), GREEN_2, 11, c)); return b;
    }
    static TextView nav(Context c, String s, boolean selected) {
        TextView t = text(c, s, phone(c) ? 10 : 12, selected ? TEXT : MUTED, true); t.setGravity(Gravity.CENTER); t.setFocusable(true); t.setClickable(true);
        if (selected) t.setBackground(verticalGradient(Color.argb(80, 42,220,104), Color.TRANSPARENT, 0, c));
        t.setOnFocusChangeListener((v, f) -> { t.setTextColor(f || selected ? TEXT : MUTED); if (f) v.animate().scaleX(1.04f).scaleY(1.04f).setDuration(100).start(); else v.animate().scaleX(1f).scaleY(1f).setDuration(100).start(); });
        return t;
    }
    static void focus(View v, Context c) { focus(v, c, stroke(PANEL, BORDER, 12, c), stroke(PANEL_3, GREEN, 12, c)); }
    static void focus(View v, Context c, android.graphics.drawable.Drawable normal, android.graphics.drawable.Drawable focused) {
        v.setBackground(normal); v.setOnFocusChangeListener((view, hasFocus) -> {
            view.animate().scaleX(hasFocus ? 1.035f : 1f).scaleY(hasFocus ? 1.035f : 1f).translationZ(hasFocus ? dp(c,7) : 0).setDuration(120).start();
            view.setBackground(hasFocus ? focused : normal);
        });
    }
    static LinearLayout column(Context c) { LinearLayout l = new LinearLayout(c); l.setOrientation(LinearLayout.VERTICAL); return l; }
    static FrameLayout centered(Context c, View child, int maxDp) {
        FrameLayout box = new FrameLayout(c); int w = Math.min(c.getResources().getDisplayMetrics().widthPixels, dp(c, maxDp));
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(w, -1, Gravity.CENTER_HORIZONTAL); box.addView(child, p); return box;
    }
    static void immersive(android.app.Activity a) {
        a.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }
}
