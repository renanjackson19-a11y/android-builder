package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private boolean phone;
    private TextView online, clock;
    private LinearLayout body;
    private final Handler handler=new Handler();
    private final Runnable clockTask=new Runnable(){public void run(){if(clock!=null)clock.setText(new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date()));handler.postDelayed(this,30000);}};

    @Override public void onCreate(Bundle b){super.onCreate(b);if(!Session.isLogged(this)){startActivity(new Intent(this,LoginActivity.class));finish();return;}phone=Ui.phone(this);getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);Ui.immersive(this);setContentView(build());load();handler.post(clockTask);}
    @Override protected void onResume(){super.onResume();Ui.immersive(this);renderHistory();}
    @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);super.onDestroy();}

    private View build(){
        LinearLayout root=Ui.column(this);root.setBackgroundColor(Ui.BG);root.addView(header(),new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?54:62)));
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setClipToPadding(false);body=Ui.column(this);int side=phone?14:26;body.setPadding(Ui.dp(this,side),Ui.dp(this,12),Ui.dp(this,side),Ui.dp(this,24));
        FrameLayout centered=Ui.centered(this,body,1320);scroll.addView(centered,new ScrollView.LayoutParams(-1,-2));root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));return root;
    }

    private View header(){
        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(Ui.dp(this,phone?14:22),0,Ui.dp(this,phone?14:22),0);row.setBackgroundColor(Ui.BG_2);
        TextView mark=Ui.text(this,"▶",phone?14:18,Color.WHITE,true);mark.setGravity(Gravity.CENTER);mark.setBackground(Ui.gradient(Ui.GREEN,Ui.GREEN_2,13,this));row.addView(mark,new LinearLayout.LayoutParams(Ui.dp(this,40),Ui.dp(this,40)));
        TextView brand=Ui.text(this,"DUBAI PLAY",phone?16:20,Ui.TEXT,true);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(Ui.dp(this,phone?138:180),Ui.dp(this,44));bp.leftMargin=Ui.dp(this,10);row.addView(brand,bp);
        addNav(row,"TV",()->openCatalog("live","TV ao Vivo","",""));
        TextView home=Ui.nav(this,"DESTAQUES",true);home.setOnClickListener(v->{});row.addView(home,new LinearLayout.LayoutParams(Ui.dp(this,phone?88:110),Ui.dp(this,44)));
        addNav(row,"FILMES",()->openCatalog("movie","Filmes","",""));
        addNav(row,"SÉRIES",()->openCatalog("series","Séries","",""));
        addNav(row,"KIDS",()->openDiscover("kids","Kids"));
        addNav(row,"ANIME",()->openDiscover("anime","Anime"));
        row.addView(new View(this),new LinearLayout.LayoutParams(0,1,1));
        TextView search=Ui.ghostButton(this,"⌕");search.setContentDescription("Buscar");search.setOnClickListener(v->startActivity(new Intent(this,SearchActivity.class)));row.addView(search,new LinearLayout.LayoutParams(Ui.dp(this,42),Ui.dp(this,38)));
        TextView profile=Ui.ghostButton(this,"●");profile.setContentDescription("Perfil");profile.setOnClickListener(v->startActivity(new Intent(this,ProfileActivity.class)));LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(Ui.dp(this,42),Ui.dp(this,38));pp.leftMargin=Ui.dp(this,4);row.addView(profile,pp);
        online=Ui.text(this,"●",10,Ui.MUTED,true);online.setGravity(Gravity.CENTER);LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(Ui.dp(this,24),Ui.dp(this,40));op.leftMargin=Ui.dp(this,4);row.addView(online,op);
        clock=Ui.text(this,"--:--",phone?11:13,Ui.TEXT,true);clock.setGravity(Gravity.CENTER);row.addView(clock,new LinearLayout.LayoutParams(Ui.dp(this,55),Ui.dp(this,40)));
        return row;
    }
    private void addNav(LinearLayout row,String label,Runnable action){TextView n=Ui.nav(this,label,false);n.setOnClickListener(v->action.run());row.addView(n,new LinearLayout.LayoutParams(Ui.dp(this,phone?66:88),Ui.dp(this,44)));}

    private void load(){
        body.removeAllViews();TextView loading=Ui.text(this,"Preparando sua experiência...",12,Ui.MUTED,false);loading.setGravity(Gravity.CENTER);body.addView(loading,new LinearLayout.LayoutParams(-1,Ui.dp(this,150)));
        ApiClient.home(new ApiClient.Callback<ApiClient.HomeData>(){public void ok(ApiClient.HomeData h){runOnUiThread(()->render(h));}public void error(String m){runOnUiThread(()->renderError(m));}});
        ApiClient.status(new ApiClient.Callback<String>(){public void ok(String s){runOnUiThread(()->{online.setText("●");online.setTextColor(Ui.GREEN);});}public void error(String m){runOnUiThread(()->online.setTextColor(Ui.RED));}});
    }

    private void render(ApiClient.HomeData h){
        body.removeAllViews();online.setTextColor(Ui.GREEN);
        ApiClient.Item hero=h.hero!=null?h.hero:(!h.movies.isEmpty()?h.movies.get(0):(!h.series.isEmpty()?h.series.get(0):null));
        body.addView(buildMosaic(hero,h),new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?220:285)));
        renderHistory();
        addShelf("Canais agora",h.live,"live",phone?120:150);
        addShelf("Filmes em destaque",h.movies,"movie",phone?170:210);
        addShelf("Séries para maratonar",h.series,"series",phone?170:210);
    }

    private void renderHistory(){
        if(body==null||body.getChildCount()==0)return;
        View old=body.findViewWithTag("history_block");if(old!=null)body.removeView(old);
        List<ApiClient.Item> list=LocalStore.history(this);if(list.isEmpty())return;
        LinearLayout block=Ui.column(this);block.setTag("history_block");addShelfInto(block,"Continuar / vistos recentemente",list,"",phone?145:180);body.addView(block,Math.min(1,body.getChildCount()),new LinearLayout.LayoutParams(-1,-2));
    }

    private View buildMosaic(ApiClient.Item hero,ApiClient.HomeData h){
        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);
        FrameLayout big=feature(hero);row.addView(big,new LinearLayout.LayoutParams(0,-1,2.05f));
        LinearLayout right=Ui.column(this);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(0,-1,1);rp.leftMargin=Ui.dp(this,8);row.addView(right,rp);
        ApiClient.Item movie=h.movies.size()>1?h.movies.get(1):(h.movies.isEmpty()?hero:h.movies.get(0));
        ApiClient.Item series=h.series.isEmpty()?hero:h.series.get(0);
        View launch=miniTile(movie,"LANÇAMENTOS","Filmes novos",()->openCatalog("movie","Lançamentos","","launch"));right.addView(launch,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,0,1);sp.topMargin=Ui.dp(this,8);right.addView(miniTile(series,"KIDS + ANIME","Coleções para explorar",()->openDiscover("kids","Kids & Anime")),sp);
        return row;
    }

    private FrameLayout feature(ApiClient.Item item){
        FrameLayout box=new FrameLayout(this);box.setBackground(Ui.stroke(Ui.PANEL,Ui.BORDER,16,this));box.setClipToOutline(true);
        ImageView img=new ImageView(this);img.setScaleType(ImageView.ScaleType.CENTER_CROP);img.setAlpha(.72f);box.addView(img,new FrameLayout.LayoutParams(-1,-1));if(item!=null)ImageLoader.into(this,img,clean(item.backdrop,clean(item.logo,"")));
        View shade=new View(this);shade.setBackground(Ui.gradient(0xE7000000,0x24000000,0,this));box.addView(shade,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout info=Ui.column(this);info.setPadding(Ui.dp(this,phone?18:28),Ui.dp(this,phone?18:28),Ui.dp(this,20),Ui.dp(this,16));
        info.addView(Ui.text(this,"DUBAI PLAY • DESTAQUE",9,Ui.GREEN,true),new LinearLayout.LayoutParams(-1,Ui.dp(this,22)));
        TextView title=Ui.text(this,item==null?"Seu conteúdo em um só lugar":clean(item.name,"Destaque"),phone?22:32,Color.WHITE,true);title.setMaxLines(2);info.addView(title,new LinearLayout.LayoutParams(-1,0,1));
        TextView meta=Ui.text(this,item==null?"TV • Filmes • Séries":meta(item),phone?10:12,Color.rgb(222,225,230),true);info.addView(meta,new LinearLayout.LayoutParams(-1,Ui.dp(this,28)));
        LinearLayout actions=new LinearLayout(this);TextView play=Ui.primaryButton(this,"▶  ASSISTIR");play.setOnClickListener(v->{if(item!=null)openItem(item);});actions.addView(play,new LinearLayout.LayoutParams(Ui.dp(this,phone?130:165),Ui.dp(this,40)));TextView fav=Ui.button(this,"+ MINHA LISTA");fav.setOnClickListener(v->{if(item!=null){LocalStore.toggleFavorite(this,item);fav.setText(LocalStore.isFavorite(this,item.id)?"✓ NA MINHA LISTA":"+ MINHA LISTA");}});LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(Ui.dp(this,phone?130:165),Ui.dp(this,40));fp.leftMargin=Ui.dp(this,8);actions.addView(fav,fp);info.addView(actions,new LinearLayout.LayoutParams(-1,Ui.dp(this,44)));
        box.addView(info,new FrameLayout.LayoutParams(-1,-1));return box;
    }

    private View miniTile(ApiClient.Item item,String label,String sub,Runnable action){
        FrameLayout box=new FrameLayout(this);box.setFocusable(true);box.setClickable(true);Ui.focus(box,this,Ui.stroke(Ui.PANEL,Ui.BORDER,14,this),Ui.stroke(Ui.PANEL_2,Ui.GREEN,14,this));
        ImageView img=new ImageView(this);img.setScaleType(ImageView.ScaleType.CENTER_CROP);img.setAlpha(.48f);box.addView(img,new FrameLayout.LayoutParams(-1,-1));if(item!=null)ImageLoader.into(this,img,clean(item.backdrop,clean(item.logo,"")));
        View shade=new View(this);shade.setBackgroundColor(0x66000000);box.addView(shade,new FrameLayout.LayoutParams(-1,-1));LinearLayout text=Ui.column(this);text.setPadding(Ui.dp(this,16),Ui.dp(this,12),Ui.dp(this,12),Ui.dp(this,10));text.addView(Ui.text(this,label,phone?14:18,Color.WHITE,true),new LinearLayout.LayoutParams(-1,0,1));text.addView(Ui.text(this,sub,9,Color.rgb(210,214,221),false),new LinearLayout.LayoutParams(-1,Ui.dp(this,22)));box.addView(text,new FrameLayout.LayoutParams(-1,-1));box.setOnClickListener(v->action.run());return box;
    }

    private void addShelf(String title,List<ApiClient.Item> items,String type,int h){addShelfInto(body,title,items,type,h);}
    private void addShelfInto(LinearLayout parent,String title,List<ApiClient.Item> items,String type,int h){
        if(items==null||items.isEmpty())return;LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);TextView t=Ui.text(this,title,phone?15:20,Ui.TEXT,true);head.addView(t,new LinearLayout.LayoutParams(0,Ui.dp(this,42),1));TextView all=Ui.ghostButton(this,"VER TODOS");all.setOnClickListener(v->{String openType=type.isEmpty()?items.get(0).type:type;if(!openType.isEmpty())openCatalog(openType,title,"","");});head.addView(all,new LinearLayout.LayoutParams(Ui.dp(this,100),Ui.dp(this,34)));LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,Ui.dp(this,44));hp.topMargin=Ui.dp(this,10);parent.addView(head,hp);
        HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setHorizontalScrollBarEnabled(false);LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.TOP);int max=Math.min(items.size(),16);for(int i=0;i<max;i++){ApiClient.Item item=items.get(i);View card=poster(item,h);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(Ui.dp(this,"live".equals(item.type)?phone?150:180:phone?125:155),Ui.dp(this,h));cp.rightMargin=Ui.dp(this,8);row.addView(card,cp);}hsv.addView(row);parent.addView(hsv,new LinearLayout.LayoutParams(-1,Ui.dp(this,h)));
    }

    private View poster(ApiClient.Item item,int h){
        LinearLayout card=Ui.column(this);card.setFocusable(true);card.setClickable(true);card.setPadding(Ui.dp(this,5),Ui.dp(this,5),Ui.dp(this,5),Ui.dp(this,5));Ui.focus(card,this);ImageView img=new ImageView(this);img.setScaleType("live".equals(item.type)?ImageView.ScaleType.CENTER_INSIDE:ImageView.ScaleType.CENTER_CROP);img.setBackgroundColor(Ui.PANEL_2);int imageH=h-(phone?42:46);card.addView(img,new LinearLayout.LayoutParams(-1,Ui.dp(this,imageH)));ImageLoader.into(this,img,item.logo);TextView name=Ui.text(this,clean(item.name,"Sem nome"),phone?10:11,Ui.TEXT,true);name.setMaxLines(1);card.addView(name,new LinearLayout.LayoutParams(-1,Ui.dp(this,22)));TextView sub=Ui.text(this,meta(item),8,Ui.MUTED,false);sub.setMaxLines(1);card.addView(sub,new LinearLayout.LayoutParams(-1,Ui.dp(this,18)));card.setOnClickListener(v->openItem(item));return card;
    }

    private void openItem(ApiClient.Item i){if(i==null)return;if("series".equals(i.type)){Intent in=new Intent(this,SeriesActivity.class);in.putExtra("title",clean(i.seriesTitle,i.name));in.putExtra("name",i.name);in.putExtra("logo",i.logo);in.putExtra("backdrop",i.backdrop);startActivity(in);}else if("movie".equals(i.type)){Intent in=new Intent(this,DetailActivity.class);putItem(in,i);startActivity(in);}else{Intent in=new Intent(this,PlayerActivity.class);putItem(in,i);startActivity(in);LocalStore.addHistory(this,i);}}
    static void putItem(Intent in,ApiClient.Item i){in.putExtra("id",i.id);in.putExtra("name",i.name);in.putExtra("logo",i.logo);in.putExtra("backdrop",i.backdrop);in.putExtra("group",i.group);in.putExtra("synopsis",i.synopsis);in.putExtra("type",i.type);in.putExtra("format",i.format);in.putExtra("year",i.year);in.putExtra("series_title",i.seriesTitle);}
    private void openCatalog(String type,String title,String category,String smart){Intent in=new Intent(this,CatalogActivity.class);in.putExtra("type",type);in.putExtra("title",title);in.putExtra("category",category);in.putExtra("smart",smart);startActivity(in);}
    private void openDiscover(String smart,String title){Intent in=new Intent(this,DiscoverActivity.class);in.putExtra("smart",smart);in.putExtra("title",title);startActivity(in);}
    private void renderError(String m){body.removeAllViews();LinearLayout card=Ui.column(this);card.setPadding(Ui.dp(this,28),Ui.dp(this,28),Ui.dp(this,28),Ui.dp(this,22));card.setBackground(Ui.stroke(Ui.PANEL,Ui.RED,16,this));card.addView(Ui.text(this,"Não foi possível atualizar o catálogo",phone?20:26,Ui.TEXT,true),new LinearLayout.LayoutParams(-1,Ui.dp(this,46)));TextView msg=Ui.text(this,clean(m,"Falha de conexão"),11,Ui.MUTED,false);card.addView(msg,new LinearLayout.LayoutParams(-1,Ui.dp(this,50)));TextView retry=Ui.primaryButton(this,"TENTAR NOVAMENTE");retry.setOnClickListener(v->load());card.addView(retry,new LinearLayout.LayoutParams(Ui.dp(this,190),Ui.dp(this,42)));body.addView(card,new LinearLayout.LayoutParams(-1,Ui.dp(this,170)));online.setTextColor(Ui.RED);}
    private String meta(ApiClient.Item i){String m=clean(i.group,"");if(i.year>0)m+=(m.isEmpty()?"":" • ")+i.year;if("series".equals(i.type)&&i.episodeCount>0)m+=(m.isEmpty()?"":" • ")+i.episodeCount+" eps.";return m.isEmpty()?"Dubai Play":m;}
    private String clean(String v,String fallback){if(v==null)return fallback;String s=v.trim();return s.isEmpty()||"null".equalsIgnoreCase(s)?fallback:s;}
}
