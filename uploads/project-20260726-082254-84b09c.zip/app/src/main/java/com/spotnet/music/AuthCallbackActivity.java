package com.spotnet.music;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AuthCallbackActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Uri data = getIntent().getData();
        if (data != null) {
            boolean ok = "1".equals(data.getQueryParameter("ok")) || "true".equalsIgnoreCase(data.getQueryParameter("ok"));
            String token = safe(data.getQueryParameter("token"));
            String user = safe(data.getQueryParameter("user"));
            String message = safe(data.getQueryParameter("message"));
            if (ok || !token.isEmpty()) {
                getSharedPreferences("auth", MODE_PRIVATE).edit()
                        .putBoolean("ok", true)
                        .putString("token", token)
                        .putString("user", user)
                        .apply();
                Intent i = new Intent(this, MainActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(i);
                finish();
                return;
            }
            if (!message.isEmpty()) Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        }
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    }
    private static String safe(String s){ return s == null ? "" : s; }
}
