SPOTNET MUSIC V55 - REPRODUÇÃO CORRIGIDA

- Serviço MediaSession registrado corretamente no Manifest.
- ExoPlayer configurado com redirecionamento, timeouts e User-Agent compatível.
- Seleção do melhor stream de áudio no resolvedor.
- Nova tentativa automática quando um link temporário expira ou retorna erro.
- Cache do link inválido é removido antes da tentativa.
- VersionCode 55 para garantir instalação da nova versão.
