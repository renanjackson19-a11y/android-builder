SPOTNET MUSIC V51

- Navegação inferior flutuante, arredondada e mais profissional.
- Perfil da conta centralizado com avatar, nome e usuário.
- Ícone de pausa corrigido para duas barras limpas.
- Mini player refinado e com melhor proporção.
- Tela de busca com topo e espaçamentos mais compactos.
- Mantidas as correções da V50: Google, crash pós-login e integrações.
