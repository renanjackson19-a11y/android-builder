SPOTNET ANDROID V54

- Removidos todos os avisos de inicialização do player.
- Falha temporária do serviço não exibe popup/Toast sobre o mini player.
- VersionCode aumentado para 54 para impedir instalação/cache da versão anterior.
- Para teste correto: desinstale o APK antigo antes de instalar a V54, pois versões debug e release podem usar pacotes diferentes.
