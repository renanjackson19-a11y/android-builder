SPOTNET MUSIC V49

Correções sobre a mesma base V48:
- Cabeçalho da tela Início voltou ao tamanho compacto.
- Menu, nome Spotnet Music, sino e conta alinhados ao centro.
- Mini player inferior mais fino e sem cobrir o conteúdo.
- Capa e botões anterior/play/próxima reduzidos.
- Barra de navegação inferior mais compacta.
- Mantida a correção de crash pós-login da V48.
- Mantido login centralizado, Google, APIs e estrutura do projeto.
