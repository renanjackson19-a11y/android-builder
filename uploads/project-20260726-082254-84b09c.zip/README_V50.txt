SPOTNET MUSIC V50

Correções:
- Removido o espaço inferior exagerado das telas Início, Buscar, Biblioteca, detalhes e Conta.
- Mini player e barra de navegação mais compactos.
- Pesquisas recentes somem quando não há histórico.
- Tela Buscar carrega sugestões automaticamente para não ficar vazia.
- Login Google abre em aba segura integrada (Custom Tab), com retorno por spotnetmusic://google-auth.
- Adicionada AuthCallbackActivity para receber token/usuário do painel.

IMPORTANTE PARA O PAINEL GOOGLE:
A rota /auth/google.php deve redirecionar, após sucesso, para:
spotnetmusic://google-auth?ok=1&token=TOKEN&user=USUARIO
Em caso de erro:
spotnetmusic://google-auth?ok=0&message=MENSAGEM
