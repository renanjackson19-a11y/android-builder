V48 - correção de fechamento após login
- conexão do Media3 adiada até a Activity estar pronta
- proteção contra falhas ao vincular PlaybackService
- inicialização segura do player
- mantém layout centralizado da V47
