GreenPlay v16.234 — base limpa v16.228

- v16.233 descartada conforme solicitado; esta versão parte da v16.228.
- TV usa o snapshot completo recebido no loading inicial (bootstrap_home) e não substitui a lista enriquecida por get_channel ao trocar de categoria.
- Todas as categorias mostram todos os canais do snapshot, sem corte em 16 canais.
- Todas as logos são ligadas aos cards, sem condição order<=16.
- Na troca de categoria, a lista sempre volta ao topo.
- Navegação horizontal das categorias não usa smoothScroll/recentralização em cada toque; rola somente quando o chip sai da área visível.
- Navegação vertical não dispara consulta EPG a cada foco e não cria novos cards durante o D-pad.
- Paginação de fallback usa offset + quantidade realmente devolvida pela fonte, evitando pular canais quando o servidor impõe página menor que o limit solicitado.
- Mantidas as correções da v16.228 para o modal Assistir/Baixar e estabilidade.
