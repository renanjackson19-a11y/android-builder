GreenPlay v16.234 — TV / logos da fonte em tempo real

BASE
- Parte da v16.228. A v16.233 foi descartada conforme solicitado.

CORREÇÕES
- O app usa o snapshot completo recebido no carregamento inicial e não substitui a lista por get_channel ao trocar de categoria.
- Todas as categorias mostram todos os canais do snapshot, sem corte no 16º canal.
- Todas as logos são ligadas aos cards.
- A logo atual da própria fonte (provider_icon / stream_icon) tem prioridade.
- Se a logo da fonte falhar, o app tenta automaticamente epg_logo/tvg_logo e demais alternativas enviadas pelo painel.
- Na troca de categoria a lista volta ao topo.
- A faixa de categorias não usa smoothScroll/recentralização em cada toque.
- O D-pad não dispara consulta EPG de rede a cada foco e não cria novos cards enquanto navega.
- A paginação de fallback avança pela quantidade realmente devolvida pelo servidor.
- Mantidas as correções da v16.228 do modal Assistir/Baixar e estabilidade.

INTEGRAÇÃO PAINEL
- Requer o patch de painel v87 para receber provider_icon e epg_logo separadamente.
- O bootstrap do painel consulta get_live_streams da fonte em cada sincronização inicial; portanto a URL atual da logo vem da fonte no carregamento do aplicativo.
