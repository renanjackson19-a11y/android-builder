package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class DetailActivity extends Activity {
    private ApiClient.Item item;
    private TextView fav, title, meta, synopsis;
    private ImageView backdrop, poster;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.immersive(this);
        item = readItem();
        setContentView(build());
        refresh();
        loadFullMetadata();
    }

    @Override protected void onResume() { super.onResume(); Ui.immersive(this); }

    private View build() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Ui.BG);

        backdrop = new ImageView(this);
        backdrop.setScaleType(ImageView.ScaleType.CENTER_CROP);
        backdrop.setAlpha(.62f);
        root.addView(backdrop, new FrameLayout.LayoutParams(-1,-1));

        View shade = new View(this);
        shade.setBackground(Ui.gradient(0xF5000000,0x33000000,0,this));
        root.addView(shade,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout content = new LinearLayout(this);
        content.setGravity(Gravity.CENTER_VERTICAL);
        content.setPadding(Ui.dp(this,32),Ui.dp(this,24),Ui.dp(this,32),Ui.dp(this,24));

        poster = new ImageView(this);
        poster.setScaleType(ImageView.ScaleType.CENTER_CROP);
        poster.setBackgroundColor(0xFF101712); poster.setClipToOutline(true); poster.setOutlineProvider(android.view.ViewOutlineProvider.BACKGROUND);
        content.addView(poster,new LinearLayout.LayoutParams(Ui.dp(this,Ui.phone(this)?175:220),Ui.dp(this,Ui.phone(this)?255:320)));

        LinearLayout info = Ui.column(this);
        info.setPadding(Ui.dp(this,26),0,0,0);
        TextView badge = Ui.text(this,"FILME • DUBAI PLAY",10,Ui.GREEN,true);
        info.addView(badge,new LinearLayout.LayoutParams(-1,Ui.dp(this,28)));

        title = Ui.text(this,"",Ui.phone(this)?27:38,Color.WHITE,true);
        title.setMaxLines(2);
        info.addView(title,new LinearLayout.LayoutParams(-1,Ui.dp(this,95)));

        meta = Ui.text(this,"",12,Color.rgb(224,227,232),true);
        info.addView(meta,new LinearLayout.LayoutParams(-1,Ui.dp(this,34)));

        synopsis = Ui.text(this,"",Ui.phone(this)?11:13,Color.rgb(196,201,210),false);
        synopsis.setMaxLines(9); synopsis.setLineSpacing(0,1.08f);
        info.addView(synopsis,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout actions = new LinearLayout(this);
        long savedPos=LocalStore.resumePosition(this,item.id);
        TextView play = Ui.primaryButton(this,savedPos>10000?"▶  CONTINUAR":"▶  REPRODUZIR");
        play.setOnClickListener(v->play(savedPos>10000?savedPos:0));
        actions.addView(play,new LinearLayout.LayoutParams(Ui.dp(this,170),Ui.dp(this,44)));
        if(savedPos>10000){TextView restart=Ui.button(this,"↺ DO INÍCIO");restart.setOnClickListener(v->{LocalStore.clearResume(this,item.id);play(0);});LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(Ui.dp(this,145),Ui.dp(this,44));rp.leftMargin=Ui.dp(this,10);actions.addView(restart,rp);}

        fav = Ui.button(this, LocalStore.isFavorite(this,item.id)?"★ FAVORITO":"☆ FAVORITAR");
        fav.setOnClickListener(v->{
            LocalStore.toggleFavorite(this,item);
            fav.setText(LocalStore.isFavorite(this,item.id)?"★ FAVORITO":"☆ FAVORITAR");
        });
        LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(Ui.dp(this,170),Ui.dp(this,44)); fp.leftMargin=Ui.dp(this,10); actions.addView(fav,fp);

        TextView back=Ui.button(this,"VOLTAR");
        back.setOnClickListener(v->finish());
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(Ui.dp(this,110),Ui.dp(this,44)); bp.leftMargin=Ui.dp(this,10); actions.addView(back,bp);
        info.addView(actions,new LinearLayout.LayoutParams(-1,Ui.dp(this,50)));

        content.addView(info,new LinearLayout.LayoutParams(0,Ui.dp(this,Ui.phone(this)?280:345),1));
        root.addView(content,new FrameLayout.LayoutParams(-1,-1));
        play.requestFocus();
        return root;
    }

    private void loadFullMetadata() {
        if (!"movie".equals(item.type)) return;
        ApiClient.tmdbEnrich(item, new ApiClient.Callback<ApiClient.Item>() {
            @Override public void ok(ApiClient.Item full) {
                runOnUiThread(() -> { merge(full); refresh(); });
            }
            @Override public void error(String m) { }
        });
    }

    private void merge(ApiClient.Item full) {
        if (full == null) return;
        item.name = prefer(full.name,item.name);
        item.logo = prefer(full.logo,item.logo);
        item.backdrop = prefer(full.backdrop,item.backdrop);
        item.group = prefer(full.group,item.group);
        item.synopsis = prefer(full.synopsis,item.synopsis);
        item.type = prefer(full.type,item.type);
        item.format = prefer(full.format,item.format);
        if (full.year > 0) item.year = full.year;
        if (full.tmdbId > 0) item.tmdbId = full.tmdbId;
    }

    private void refresh() {
        title.setText(clean(item.name,"Filme"));
        String m = clean(item.group,"Filmes");
        if (item.year > 0) m += " • " + item.year;
        if (item.tmdbId > 0) m += " • TMDB";
        meta.setText(m);
        synopsis.setText(clean(item.synopsis,"Sinopse indisponível."));
        ImageLoader.into(this,poster,clean(item.logo,""));
        ImageLoader.into(this,backdrop,clean(item.backdrop,clean(item.logo,"")));
    }

    private void play(long resume){LocalStore.addHistory(this,item);Intent in=new Intent(this,PlayerActivity.class);MainActivity.putItem(in,item);if(resume>0)in.putExtra("resume_pos",resume);startActivity(in);}


    private ApiClient.Item readItem() {
        ApiClient.Item i=new ApiClient.Item();
        i.id=getIntent().getLongExtra("id",0);
        i.name=getIntent().getStringExtra("name");
        i.logo=getIntent().getStringExtra("logo");
        i.backdrop=getIntent().getStringExtra("backdrop");
        i.group=getIntent().getStringExtra("group");
        i.synopsis=getIntent().getStringExtra("synopsis");
        i.type=clean(getIntent().getStringExtra("type"),"movie");
        i.format=clean(getIntent().getStringExtra("format"),"auto");
        i.year=getIntent().getIntExtra("year",0);
        i.seriesTitle=getIntent().getStringExtra("series_title");
        i.tmdbId=getIntent().getIntExtra("tmdb_id",0);
        return i;
    }

    private String prefer(String a,String b){return clean(a,clean(b,""));}
    private String clean(String v,String f){if(v==null)return f;String s=v.trim();return s.isEmpty()||"null".equalsIgnoreCase(s)?f:s;}
}
