package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;

final class YellowNav {
    private YellowNav(){}

    static View bar(Activity a,String active){
        boolean phone=Ui.phone(a);
        LinearLayout root=new LinearLayout(a);
        root.setGravity(Gravity.CENTER_VERTICAL);
        root.setPadding(Ui.dp(a,phone?14:28),0,Ui.dp(a,phone?14:26),0);
        root.setBackgroundColor(0xF8000502);

        // Brand block closer to the reference application: compact, no giant pill.
        LinearLayout brand=new LinearLayout(a);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        brand.setPadding(Ui.dp(a,phone?8:12),0,Ui.dp(a,phone?16:22),0);

        TextView mark=Ui.text(a,"▶",phone?11:14,Color.BLACK,true);
        mark.setGravity(Gravity.CENTER);
        mark.setBackground(Ui.gradient(Ui.GREEN,Ui.GREEN_2,9,a));
        brand.addView(mark,new LinearLayout.LayoutParams(Ui.dp(a,phone?34:42),Ui.dp(a,phone?34:42)));

        TextView name=Ui.text(a,"DUBAI PLAY",phone?12:16,Color.WHITE,true);
        LinearLayout.LayoutParams nameLp=new LinearLayout.LayoutParams(-2,-1);
        nameLp.leftMargin=Ui.dp(a,10);
        brand.addView(name,nameLp);
        root.addView(brand,new LinearLayout.LayoutParams(Ui.dp(a,phone?170:215),-1));

        LinearLayout tabs=new LinearLayout(a);
        tabs.setGravity(Gravity.CENTER);
        tab(a,tabs,"TV",active,()->open(a,LiveTvActivity.class));
        tab(a,tabs,"DESTAQUES",active,()->{
            Intent i=new Intent(a,MainActivity.class);
            i.putExtra("show_highlights",true);
            a.startActivity(i);
        });
        tab(a,tabs,"FILMES",active,()->catalog(a,"movie","Filmes",""));
        tab(a,tabs,"SÉRIES",active,()->catalog(a,"series","Séries",""));
        tab(a,tabs,"SHOWS",active,()->discover(a,"shows","Shows"));
        kidsTab(a,tabs,active,()->discover(a,"kids","Kids"));
        tab(a,tabs,"ANIMES",active,()->discover(a,"anime","Animes"));
        tab(a,tabs,"GAMES",active,()->open(a,GamesActivity.class));
        tab(a,tabs,"EXPLORAR",active,()->discover(a,"explore","Explorar"));
        root.addView(tabs,new LinearLayout.LayoutParams(0,-1,1));

        TextView search=roundAction(a,"⌕");
        search.setOnClickListener(v->open(a,SearchActivity.class));
        root.addView(search,new LinearLayout.LayoutParams(Ui.dp(a,phone?42:48),Ui.dp(a,phone?42:48)));

        TextView profile=roundAction(a,"♙");
        profile.setOnClickListener(v->open(a,ProfileActivity.class));
        LinearLayout.LayoutParams plp=new LinearLayout.LayoutParams(Ui.dp(a,phone?42:48),Ui.dp(a,phone?42:48));
        plp.leftMargin=Ui.dp(a,8);
        root.addView(profile,plp);
        return root;
    }

    private static TextView roundAction(Activity a,String s){
        TextView b=Ui.text(a,s,Ui.phone(a)?13:16,Color.WHITE,true);
        b.setGravity(Gravity.CENTER);b.setFocusable(true);b.setClickable(true);
        Ui.focus(b,a,Ui.round(0xFF202420,32,a),Ui.stroke(0xFF17241B,Ui.GREEN,32,a));
        return b;
    }

    private static void tab(Activity a,LinearLayout row,String label,String active,Runnable action){
        boolean selected=label.equalsIgnoreCase(active==null?"":active);
        FrameLayout box=new FrameLayout(a);
        box.setFocusable(true);box.setClickable(true);

        TextView t=Ui.text(a,label,Ui.phone(a)?10:14,selected?Ui.GREEN:0xFFD8DDD9,selected);
        t.setGravity(Gravity.CENTER);
        box.addView(t,new FrameLayout.LayoutParams(-1,-1));

        if(selected){
            View line=new View(a);line.setBackgroundColor(Ui.GREEN);
            FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(Ui.dp(a,30),Ui.dp(a,3),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
            lp.bottomMargin=Ui.dp(a,3);box.addView(line,lp);
        }

        Ui.focus(box,a,Ui.round(Color.TRANSPARENT,8,a),Ui.round(0x161CFF78,8,a));
        box.setOnClickListener(v->action.run());

        int w=("DESTAQUES".equals(label)||"EXPLORAR".equals(label))?(Ui.phone(a)?84:112):(Ui.phone(a)?66:88);
        row.addView(box,new LinearLayout.LayoutParams(Ui.dp(a,w),Ui.dp(a,46)));
    }


    private static void kidsTab(Activity a,LinearLayout row,String active,Runnable action){
        boolean selected="KIDS".equalsIgnoreCase(active==null?"":active);
        FrameLayout box=new FrameLayout(a);
        box.setFocusable(true);box.setClickable(true);

        ImageView logo=new ImageView(a);
        logo.setImageResource(com.ativacao.app.R.drawable.kids_menu_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        logo.setAdjustViewBounds(true);
        int pad=Ui.dp(a,Ui.phone(a)?5:4);
        logo.setPadding(pad,pad,pad,pad);
        box.addView(logo,new FrameLayout.LayoutParams(-1,-1));

        if(selected){
            View line=new View(a);line.setBackgroundColor(Ui.GREEN);
            FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(Ui.dp(a,32),Ui.dp(a,3),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
            lp.bottomMargin=Ui.dp(a,1);box.addView(line,lp);
        }

        Ui.focus(box,a,Ui.round(Color.TRANSPARENT,8,a),Ui.round(0x161CFF78,8,a));
        box.setOnClickListener(v->action.run());
        row.addView(box,new LinearLayout.LayoutParams(Ui.dp(a,Ui.phone(a)?78:104),Ui.dp(a,46)));
    }

    private static void open(Activity a,Class<?> c){a.startActivity(new Intent(a,c));}
    private static void catalog(Activity a,String type,String title,String smart){
        Intent i=new Intent(a,CatalogActivity.class);i.putExtra("type",type);i.putExtra("title",title);i.putExtra("smart",smart);a.startActivity(i);
    }
    private static void discover(Activity a,String smart,String title){
        Intent i=new Intent(a,DiscoverActivity.class);i.putExtra("smart",smart);i.putExtra("title",title);a.startActivity(i);
    }
}
