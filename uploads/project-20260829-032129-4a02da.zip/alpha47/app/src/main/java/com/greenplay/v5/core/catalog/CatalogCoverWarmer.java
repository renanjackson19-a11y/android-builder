package com.greenplay.v5.core.catalog;

import android.os.Handler;
import android.os.Looper;
import com.squareup.picasso.Picasso;
import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Gradually warms Picasso's image cache without blocking the UI or flooding the network. */
public final class CatalogCoverWarmer {
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final ArrayDeque<String> QUEUE = new ArrayDeque<>();
    private static final Set<String> SEEN = new HashSet<>();
    private static boolean running = false;

    private CatalogCoverWarmer() {}

    public static synchronized void enqueue(List<String> urls) {
        if (urls == null) return;
        for (String raw : urls) {
            if (raw == null) continue;
            String url = raw.trim();
            if (url.isEmpty() || !SEEN.add(url)) continue;
            QUEUE.add(url);
        }
        if (!running && !QUEUE.isEmpty()) {
            running = true;
            MAIN.post(CatalogCoverWarmer::drainBatch);
        }
    }

    private static void drainBatch() {
        int count = 0;
        while (count < 10) {
            String url;
            synchronized (CatalogCoverWarmer.class) { url = QUEUE.poll(); }
            if (url == null) break;
            try { Picasso.get().load(url).fetch(); } catch (Exception ignored) {}
            count++;
        }
        synchronized (CatalogCoverWarmer.class) {
            if (QUEUE.isEmpty()) {
                running = false;
                return;
            }
        }
        MAIN.postDelayed(CatalogCoverWarmer::drainBatch, 140L);
    }
}
