package com.greenplay.v5.ui.series;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.greenplay.v5.core.config.AppControlStore;
import com.greenplay.v5.core.config.BrandingStore;
import com.greenplay.v5.core.network.StreamUrlFactory;
import com.greenplay.v5.core.player.VodProgressStore;
import com.greenplay.v5.core.session.SessionStore;
import com.greenplay.v5.data.model.series.SeriesDetails;
import com.greenplay.v5.data.model.series.SeriesEpisode;
import com.greenplay.v5.data.repository.SeriesRepository;
import com.greenplay.v5.databinding.ActivitySeriesDetailBinding;
import com.greenplay.v5.ui.player.PlayerActivity;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public final class SeriesDetailActivity extends AppCompatActivity {
    private ActivitySeriesDetailBinding b; private SessionStore session; private BrandingStore branding; private AppControlStore control; private SeriesRepository repo; private long seriesId; private String name="",cover="",year="",rating=""; private SeriesDetails details; private SeasonAdapter seasonAdapter; private EpisodeAdapter episodeAdapter; private VodProgressStore progress;
    @Override protected void onCreate(Bundle state){super.onCreate(state);b=ActivitySeriesDetailBinding.inflate(getLayoutInflater());setContentView(b.getRoot());
        com.greenplay.v5.core.ui.UniversalUi.apply(this, b.getRoot());session=new SessionStore(this);if(!session.isLogged()){finish();return;}branding=new BrandingStore(this);control=new AppControlStore(this);seriesId=getIntent().getLongExtra("id",0L);if(seriesId<=0){finish();return;}name=safe(getIntent().getStringExtra("name"));cover=safe(getIntent().getStringExtra("cover"));year=safe(getIntent().getStringExtra("year"));rating=safe(getIntent().getStringExtra("rating"));repo=new SeriesRepository(session.host(),session.user(),session.pass());progress=new VodProgressStore(this);setupLists();renderBase();load();}
    private void setupLists(){seasonAdapter=new SeasonAdapter(this::showSeason);b.seasonList.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false));b.seasonList.setAdapter(seasonAdapter);episodeAdapter=new EpisodeAdapter(this::chooseResume);b.episodeList.setLayoutManager(new GridLayoutManager(this,2));b.episodeList.setAdapter(episodeAdapter);b.episodeList.setItemAnimator(null);}
    private void renderBase(){b.seriesDetailTitle.setText(name.isEmpty()?"SÉRIE":name);b.seriesDetailMeta.setText(meta(year,rating));String c=cover.isEmpty()?branding.absolute(branding.fallback()):cover;if(!c.isEmpty())Picasso.get().load(c).fit().centerCrop().noFade().into(b.seriesDetailPoster);}
    private void load(){b.seriesDetailLoading.setVisibility(View.VISIBLE);repo.detail(seriesId,new SeriesRepository.DetailResult(){public void success(SeriesDetails d){runOnUiThread(()->{details=d;b.seriesDetailLoading.setVisibility(View.GONE);if(!d.name.isEmpty())name=d.name;if(!d.cover.isEmpty())cover=d.cover;b.seriesDetailTitle.setText(name);b.seriesDetailPlot.setText(d.plot.isEmpty()?"Sinopse não informada.":d.plot);b.seriesDetailGenre.setText(d.genre.isEmpty()?"":d.genre);b.seriesDetailMeta.setText(meta(year,first(d.rating,rating)));if(!cover.isEmpty())Picasso.get().load(cover).fit().centerCrop().noFade().into(b.seriesDetailPoster);if(!d.backdrop.isEmpty())Picasso.get().load(d.backdrop).fit().centerCrop().noFade().into(b.seriesDetailBackdrop);Set<Integer> set=new LinkedHashSet<>();for(SeriesEpisode e:d.episodes)if(e.season>0)set.add(e.season);List<Integer> seasons=new ArrayList<>(set);if(seasons.isEmpty()){b.seriesDetailError.setText("Nenhum episódio informado por este servidor.");return;}int selected=seasons.get(0);seasonAdapter.submit(seasons,selected);showSeason(selected);});}public void error(String m){runOnUiThread(()->{b.seriesDetailLoading.setVisibility(View.GONE);b.seriesDetailError.setText(m);});}});}
    private void showSeason(int season){if(details==null)return;List<SeriesEpisode> rows=new ArrayList<>();for(SeriesEpisode e:details.episodes)if(e.season==season)rows.add(e);seasonAdapter.select(season);episodeAdapter.submit(rows);b.episodeHeader.setText("EPISÓDIOS • TEMPORADA "+season+" • "+rows.size());}
    private void chooseResume(SeriesEpisode ep){String key=progressKey(ep);long saved=control.resumeEnabled()?progress.position(key):0L;long duration=progress.duration(key);boolean valid=saved>=15000L&&(duration<=0L||saved<duration-45000L);if(!valid||!control.resumePrompt()){play(ep,valid?saved:0L);return;}new AlertDialog.Builder(this).setTitle("Continuar assistindo?").setMessage("Você parou em "+clock(saved)+".").setPositiveButton("CONTINUAR",(d,w)->play(ep,saved)).setNegativeButton("COMEÇAR DO INÍCIO",(d,w)->{progress.clear(key);play(ep,0L);}).setNeutralButton("CANCELAR",null).show();}
    private void play(SeriesEpisode ep,long resume){String url=StreamUrlFactory.episode(session.host(),session.user(),session.pass(),ep.id,ep.extension);Intent i=new Intent(this,PlayerActivity.class);i.putExtra("url",url);i.putExtra("title",name+" • T"+ep.season+" E"+ep.episode);i.putExtra("media_type","vod");i.putExtra("progress_key",progressKey(ep));i.putExtra("resume_position",resume);startActivity(i);}
    private String progressKey(SeriesEpisode ep){String raw=session.host()+"|"+session.user()+"|series|"+seriesId+"|episode|"+ep.id;return Integer.toHexString(raw.hashCode());}
    private static String meta(String y,String r){StringBuilder s=new StringBuilder();if(y!=null&&!y.isEmpty()&&!"0".equals(y))s.append(y);if(r!=null&&!r.isEmpty()&&!"0".equals(r)&&!"0.0".equals(r)){if(s.length()>0)s.append("  •  ");s.append("★ ").append(r);}return s.toString();}
    private static String clock(long ms){long t=Math.max(0,ms/1000),h=t/3600,m=(t%3600)/60,s=t%60;return h>0?String.format(Locale.US,"%02d:%02d:%02d",h,m,s):String.format(Locale.US,"%02d:%02d",m,s);}
    private static String safe(String s){return s==null?"":s.trim();}private static String first(String a,String b){return a!=null&&!a.trim().isEmpty()?a.trim():(b==null?"":b.trim());}
}
