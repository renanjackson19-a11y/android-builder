package com.ativacao.app;

import android.app.Activity;
import android.content.Context;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Sincronização geral do conteúdo exibido no menu.
 * Após login/atualização, a Home só abre quando as primeiras telas de
 * TV, Filmes, Séries, Kids, Anime e HOT estiverem realmente preparadas.
 */
final class CatalogPreloader {
    private static final String PREF="dubai_content_preload";
    private static final int CACHE_SCHEMA=4;
    private static volatile boolean running=false;
    private static volatile boolean ready=false;

    interface Progress { void onProgress(String text,int done,int total); }

    static void init(Context c){
        if(c==null)return;
        ready=c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getBoolean(key(Session.token(c)),false);
    }
    static boolean isReady(){ return ready; }
    static boolean isPrepared(Context c){
        if(c==null)return ready;
        return c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getBoolean(key(Session.token(c)),false);
    }
    private static String key(String token){ return "ready_v"+CACHE_SCHEMA+"_"+Integer.toHexString((token==null?"":token).hashCode()); }
    private static void markReady(Context c,boolean value){
        if(c==null)return;
        c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putBoolean(key(Session.token(c)),value).apply();
        ready=value;
    }

    static void start(Activity a, boolean force, Runnable done){ start(a,force,null,done); }

    static void start(Activity a, boolean force, Progress progress, Runnable done){
        if(a==null){ if(done!=null)done.run(); return; }
        if(!force && isPrepared(a)){ ready=true; if(done!=null)done.run(); return; }
        if(running) return;
        running=true;
        markReady(a,false);
        if(force) ApiClient.clearCatalogCache();

        final boolean phone=Ui.phone(a);
        final int movieLimit=phone?36:48;
        final int seriesLimit=30;
        final int liveLimit=72;
        // 3 catálogos-base + 4 vitrines Kids/Anime + 3 HOT + categorias movie/series + hotCategories
        final int total=13;
        final AtomicInteger pending=new AtomicInteger(total);
        final AtomicInteger doneCount=new AtomicInteger(0);
        final AtomicInteger failures=new AtomicInteger(0);

        notify(progress,"Carregando conteúdo, aguarde...",0,total);

        // Telas principais
        preloadRequired(a,"live",liveLimit,"","TV ao vivo",pending,doneCount,total,failures,progress,done);
        preloadRequired(a,"movie",movieLimit,"","Filmes",pending,doneCount,total,failures,progress,done);
        preloadRequired(a,"series",seriesLimit,"","Séries",pending,doneCount,total,failures,progress,done);

        // Telas que antes ficavam vazias ao entrar pelo menu.
        preloadRequired(a,"movie",movieLimit,"kids","Kids • filmes",pending,doneCount,total,failures,progress,done);
        preloadRequired(a,"series",seriesLimit,"kids","Kids • séries",pending,doneCount,total,failures,progress,done);
        preloadRequired(a,"movie",movieLimit,"anime","Anime • filmes",pending,doneCount,total,failures,progress,done);
        preloadRequired(a,"series",seriesLimit,"anime","Anime • séries",pending,doneCount,total,failures,progress,done);

        // HOT completo para a primeira tela e para entrada nas categorias adultas.
        preloadOptional(a,"live",liveLimit,"adult","HOT • canais",pending,doneCount,total,failures,progress,done);
        preloadOptional(a,"movie",movieLimit,"adult","HOT • filmes",pending,doneCount,total,failures,progress,done);
        preloadOptional(a,"series",seriesLimit,"adult","HOT • séries",pending,doneCount,total,failures,progress,done);

        ApiClient.categories("movie",new ApiClient.Callback<List<String>>(){
            public void ok(List<String>x){finishOne(a,"Categorias de filmes",true,pending,doneCount,total,failures,progress,done);}
            public void error(String m){finishOne(a,"Categorias de filmes",false,pending,doneCount,total,failures,progress,done);}
        });
        ApiClient.categories("series",new ApiClient.Callback<List<String>>(){
            public void ok(List<String>x){finishOne(a,"Categorias de séries",true,pending,doneCount,total,failures,progress,done);}
            public void error(String m){finishOne(a,"Categorias de séries",false,pending,doneCount,total,failures,progress,done);}
        });
        ApiClient.hotCategories(new ApiClient.Callback<List<ApiClient.HotCategory>>(){
            public void ok(List<ApiClient.HotCategory>x){finishOne(a,"Categorias HOT",true,pending,doneCount,total,failures,progress,done);}
            public void error(String m){finishOne(a,"Categorias HOT",false,pending,doneCount,total,failures,progress,done);}
        });
    }

    private static void preloadRequired(Activity a,String type,int limit,String smart,String label,
                                        AtomicInteger pending,AtomicInteger doneCount,int total,
                                        AtomicInteger failures,Progress progress,Runnable done){
        preload(a,type,limit,smart,label,true,pending,doneCount,total,failures,progress,done);
    }
    private static void preloadOptional(Activity a,String type,int limit,String smart,String label,
                                        AtomicInteger pending,AtomicInteger doneCount,int total,
                                        AtomicInteger failures,Progress progress,Runnable done){
        preload(a,type,limit,smart,label,false,pending,doneCount,total,failures,progress,done);
    }

    private static void preload(Activity a,String type,int limit,String smart,String label,boolean requireItems,
                                AtomicInteger pending,AtomicInteger doneCount,int total,AtomicInteger failures,
                                Progress progress,Runnable done){
        ApiClient.invalidateCatalog(type,1,limit,"","",smart);
        ApiClient.catalog(type,1,limit,"","",smart,new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){
                boolean valid=p!=null && (!requireItems || p.total>0 || (p.items!=null && !p.items.isEmpty()));
                if(valid){ warmImages(a,p); finishOne(a,label,true,pending,doneCount,total,failures,progress,done); }
                else retry(a,type,limit,smart,label,requireItems,pending,doneCount,total,failures,progress,done);
            }
            public void error(String m){ retry(a,type,limit,smart,label,requireItems,pending,doneCount,total,failures,progress,done); }
        });
    }

    private static void retry(Activity a,String type,int limit,String smart,String label,boolean requireItems,
                              AtomicInteger pending,AtomicInteger doneCount,int total,AtomicInteger failures,
                              Progress progress,Runnable done){
        ApiClient.invalidateCatalog(type,1,limit,"","",smart);
        ApiClient.catalog(type,1,limit,"","",smart,new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){
                boolean valid=p!=null && (!requireItems || p.total>0 || (p.items!=null && !p.items.isEmpty()));
                if(valid) warmImages(a,p);
                finishOne(a,label,valid,pending,doneCount,total,failures,progress,done);
            }
            public void error(String m){ finishOne(a,label,false,pending,doneCount,total,failures,progress,done); }
        });
    }

    private static void finishOne(Activity a,String label,boolean ok,AtomicInteger pending,AtomicInteger doneCount,int total,
                                  AtomicInteger failures,Progress progress,Runnable done){
        if(!ok) failures.incrementAndGet();
        int d=doneCount.incrementAndGet();
        notify(progress,(ok?"Preparado: ":"Tentando concluir: ")+label,d,total);
        if(pending.decrementAndGet()!=0)return;
        running=false;
        boolean allOk=failures.get()==0;
        markReady(a,allOk);
        notify(progress,allOk?"Conteúdo pronto":"Não foi possível preparar todo o conteúdo",total,total);
        if(done!=null)done.run();
    }

    private static void notify(Progress p,String text,int done,int total){ if(p!=null) p.onProgress(text,done,total); }

    private static void warmImages(Activity a,ApiClient.CatalogPage p){
        if(p==null||p.items==null)return;
        int max=Math.min(p.items.size(),32);
        for(int n=0;n<max;n++){
            ApiClient.Item i=p.items.get(n); if(i==null)continue;
            ImageLoader.preload(a,clean(i.logo,i.backdrop));
        }
    }
    private static String clean(String a,String b){ String x=a==null?"":a.trim(); return x.isEmpty()?(b==null?"":b.trim()):x; }
}
