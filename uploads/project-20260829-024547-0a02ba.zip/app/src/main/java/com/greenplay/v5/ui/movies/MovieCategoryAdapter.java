package com.greenplay.v5.ui.movies;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.greenplay.v5.R;
import com.greenplay.v5.data.model.movie.MovieCategory;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public final class MovieCategoryAdapter extends RecyclerView.Adapter<MovieCategoryAdapter.Holder> {
    public interface Listener { void onOpen(MovieCategory category); }
    private final Listener listener;
    private final List<MovieCategory> rows = new ArrayList<>();
    private String selectedId = "";

    public MovieCategoryAdapter(Listener listener) {
        this.listener = listener;
        setHasStableIds(true);
    }

    public void submit(List<MovieCategory> items, String selectedId) {
        rows.clear();
        if (items != null) rows.addAll(unique(items));
        this.selectedId = selectedId == null ? "" : selectedId;
        notifyDataSetChanged();
    }

    public void select(String id) {
        selectedId = id == null ? "" : id;
        notifyDataSetChanged();
    }

    private static List<MovieCategory> unique(List<MovieCategory> items) {
        List<MovieCategory> out = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (MovieCategory item : items) {
            if (item == null) continue;
            String name = cleanLabel(item.name);
            String id = item.id == null ? "" : item.id.trim();
            if (name.isEmpty()) continue;
            String key = name.toLowerCase(Locale.ROOT);
            if (!seen.add(key)) continue;
            out.add(new MovieCategory(id, name));
        }
        return out;
    }

    private static String cleanLabel(String raw) {
        if (raw == null) return "";
        String s = raw.replace("\\/", "/").replace("\n", " ").replace("\r", " ").trim();
        s = s.replaceAll("^[^\\p{L}\\p{N}(]+", "");
        s = s.replaceAll("\\s{2,}", " ").trim();
        return s;
    }

    @Override public long getItemId(int position) {
        String id = rows.get(position).id;
        try { return Long.parseLong(id); } catch (Exception e) { return id.hashCode(); }
    }

    @NonNull @Override public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new Holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_movie_category, parent, false));
    }

    @Override public void onBindViewHolder(@NonNull Holder h, int position) {
        MovieCategory c = rows.get(position);
        h.name.setText(cleanName(c.name));
        boolean selected = selectedId.equals(c.id);
        h.itemView.setSelected(selected);
        h.itemView.setOnFocusChangeListener((v, focused) -> v.setSelected(focused || selectedId.equals(c.id)));
        h.itemView.setOnClickListener(v -> listener.onOpen(c));
    }

    @Override public int getItemCount() { return rows.size(); }

    private static String cleanName(String value) {
        if (value == null) return "";
        String s = value.replace("\n", " ").replace("\r", " ").trim();
        s = s.replaceAll("^[^\p{L}\p{N}(]+", "");
        return s.replaceAll("\s{2,}", " ").trim();
    }

    static final class Holder extends RecyclerView.ViewHolder {
        final TextView name;
        Holder(View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.movieCategoryName);
        }
    }
}
