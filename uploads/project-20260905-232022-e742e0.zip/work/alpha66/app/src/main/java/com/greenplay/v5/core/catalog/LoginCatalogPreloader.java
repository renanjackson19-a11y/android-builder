package com.greenplay.v5.core.catalog;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import com.greenplay.v5.data.model.movie.Movie;
import com.greenplay.v5.data.model.movie.MovieCategory;
import com.greenplay.v5.data.model.series.SeriesCategory;
import com.greenplay.v5.data.model.series.SeriesItem;
import com.greenplay.v5.data.model.tv.TvChannel;
import com.greenplay.v5.data.repository.MovieRepository;
import com.greenplay.v5.data.repository.SeriesRepository;
import com.greenplay.v5.data.repository.TvRepository;
import com.greenplay.v5.ui.movies.MovieCacheStore;
import com.greenplay.v5.ui.series.SeriesCacheStore;
import com.greenplay.v5.ui.tv.TvCacheStore;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Loads the complete Xtream catalogs before the first app screen opens.
 *
 * V5.0.105: transient network failures no longer discard the whole login.
 * Each large request gets one controlled retry and can fall back to the last
 * valid catalog for the SAME host/account when the origin is momentarily slow.
 */
public final class LoginCatalogPreloader {
    public interface Listener { void status(String text); void success(); void error(String message); }

    private final Context app;
    private final String host, user, pass;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final MovieCacheStore movieCache;
    private final SeriesCacheStore seriesCache;
    private final TvCacheStore tvCache;

    private boolean tvDone = false;
    private boolean moviesDone = false;
    private boolean seriesDone = false;
    private boolean movieCategoriesDone = false;
    private boolean seriesCategoriesDone = false;
    private boolean failed = false;
    private boolean finishing = false;
    private boolean moviePhaseStarted = false;
    private boolean seriesPhaseStarted = false;

    private int tvAttempt = 0;
    private int moviesAttempt = 0;
    private int seriesAttempt = 0;
    private int movieCategoriesAttempt = 0;
    private int seriesCategoriesAttempt = 0;

    private List<Movie> moviePartial = Collections.emptyList();
    private List<SeriesItem> seriesPartial = Collections.emptyList();

    private static final ExecutorService CACHE_IO = Executors.newSingleThreadExecutor();
    private static final ExecutorService INDEX_IO = Executors.newSingleThreadExecutor();
    private static final String SPECIAL_MAP_PREF = "green_play_special_category_map_v121";

    private boolean specialMapMovieDone = false;
    private boolean specialMapSeriesDone = false;
    private boolean specialMapMovieOk = false;
    private boolean specialMapSeriesOk = false;
    private boolean cachedOpenFinished = false;

    public LoginCatalogPreloader(Context context, String host, String user, String pass, Listener listener) {
        this.app = context.getApplicationContext();
        this.host = host;
        this.user = user;
        this.pass = pass;
        this.listener = listener;
        this.movieCache = new MovieCacheStore(app, host, user);
        this.seriesCache = new SeriesCacheStore(app, host, user);
        this.tvCache = new TvCacheStore(app, host, user);
    }

    public void start() {
        CatalogBackgroundPrime.reset();
        final CatalogRefreshPolicy policy = new CatalogRefreshPolicy(app, host, user);
        final long idleBeforeOpen = policy.consumeIdleAndTouch();

        // V5.0.109: se já existe catálogo completo para a MESMA conta/servidor,
        // abre imediatamente pelo cache. Não baixa tudo de novo a cada entrada.
        CACHE_IO.execute(() -> {
            List<TvChannel> cachedTv = tvCache.channels();
            List<Movie> cachedMovies = movieCache.movies();
            List<SeriesItem> cachedSeries = seriesCache.series();
            List<MovieCategory> cachedMovieCats = movieCache.categories();
            List<SeriesCategory> cachedSeriesCats = seriesCache.categories();
            boolean usable = cachedTv != null && !cachedTv.isEmpty()
                    && cachedMovies != null && !cachedMovies.isEmpty()
                    && cachedSeries != null && !cachedSeries.isEmpty();

            if (usable) {
                CatalogMemory.clear();
                CatalogMemory.setChannels(cachedTv);
                CatalogMemory.setMovies(cachedMovies);
                CatalogMemory.setSeries(cachedSeries);
                if (cachedMovieCats != null && !cachedMovieCats.isEmpty()) CatalogMemory.setMovieCategories(cachedMovieCats);
                else {
                    ArrayList<MovieCategory> all = new ArrayList<>();
                    all.add(new MovieCategory("", "TODOS"));
                    CatalogMemory.setMovieCategories(all);
                }
                if (cachedSeriesCats != null && !cachedSeriesCats.isEmpty()) CatalogMemory.setSeriesCategories(cachedSeriesCats);
                else {
                    ArrayList<SeriesCategory> all = new ArrayList<>();
                    all.add(allSeriesCategory());
                    CatalogMemory.setSeriesCategories(all);
                }

                // V5.0.121: migração única e leve das listas de categorias.
                // Versões antigas deduplicavam categorias de FILMES pelo nome e
                // descartavam category_id diferentes. A correção é feita uma vez
                // antes de abrir o app; depois volta a abrir 100% pelo cache.
                main.post(() -> ensureSpecialCategoryMapsBeforeCachedOpen(policy, idleBeforeOpen));
                return;
            }

            // Primeira utilização desta conta/servidor: aí sim baixa tudo.
            CatalogMemory.clear();
            main.post(() -> {
                listener.status("Carregando canais...");
                loadTv();
            });
        });
    }

    private void loadTv() {
        final int attempt = ++tvAttempt;
        new TvRepository(host, user, pass).channels("", new TvRepository.ChannelsResult() {
            @Override public void success(List<TvChannel> rows) {
                synchronized (LoginCatalogPreloader.this) {
                    if (failed || tvDone) return;
                    if (rows == null || rows.isEmpty()) {
                        handleTvError("Nenhum canal recebido do servidor", attempt);
                        return;
                    }
                    CatalogMemory.setChannels(rows);
                    tvDone = true;
                    progress();
                    CACHE_IO.execute(() -> tvCache.saveChannels(rows));
                }
            }
            @Override public void error(String message) { handleTvError(message, attempt); }
        });
    }

    private void handleTvError(String message, int attempt) {
        synchronized (this) {
            if (failed || tvDone || attempt != tvAttempt) return;
            if (attempt < 2) {
                listener.status("Canais demoraram a responder • tentando novamente...");
                main.postDelayed(this::loadTv, 650L);
                return;
            }
        }
        CACHE_IO.execute(() -> {
            List<TvChannel> cached = tvCache.channels();
            main.post(() -> {
                synchronized (LoginCatalogPreloader.this) {
                    if (failed || tvDone) return;
                    if (cached != null && !cached.isEmpty()) {
                        CatalogMemory.setChannels(cached);
                        tvDone = true;
                        listener.status("Canais recuperados • continuando...");
                        progress();
                    } else {
                        fail(nonEmpty(message, "Falha ao carregar canais"));
                    }
                }
            });
        });
    }

    private void loadMovieCategories() {
        final int attempt = ++movieCategoriesAttempt;
        new MovieRepository(host, user, pass).categories(new MovieRepository.CategoriesResult() {
            @Override public void success(List<MovieCategory> rows) {
                synchronized (LoginCatalogPreloader.this) {
                    if (failed || movieCategoriesDone) return;
                    List<MovieCategory> safe = rows == null ? new ArrayList<>() : rows;
                    if (safe.isEmpty()) safe.add(new MovieCategory("", "TODOS"));
                    CatalogMemory.setMovieCategories(safe);
                    movieCategoriesDone = true;
                    progress();
                    final List<MovieCategory> save = safe;
                    CACHE_IO.execute(() -> movieCache.saveCategories(save));
                }
            }
            @Override public void error(String message) { handleMovieCategoriesError(attempt); }
        });
    }

    private void handleMovieCategoriesError(int attempt) {
        synchronized (this) {
            if (failed || movieCategoriesDone || attempt != movieCategoriesAttempt) return;
            if (attempt < 2) {
                main.postDelayed(this::loadMovieCategories, 450L);
                return;
            }
        }
        CACHE_IO.execute(() -> {
            List<MovieCategory> cached = movieCache.categories();
            if (cached == null || cached.isEmpty()) {
                cached = new ArrayList<>();
                cached.add(new MovieCategory("", "TODOS"));
            }
            final List<MovieCategory> fallback = cached;
            main.post(() -> {
                synchronized (LoginCatalogPreloader.this) {
                    if (failed || movieCategoriesDone) return;
                    CatalogMemory.setMovieCategories(fallback);
                    movieCategoriesDone = true;
                    progress();
                }
            });
        });
    }

    private void loadMovies() {
        final int attempt = ++moviesAttempt;
        MovieRepository repo = new MovieRepository(host, user, pass);
        repo.moviesProgressive("", 48, 240, new MovieRepository.ProgressiveMoviesResult() {
            @Override public void partial(List<Movie> rows) {
                synchronized (LoginCatalogPreloader.this) {
                    if (failed || moviesDone || attempt != moviesAttempt || rows == null || rows.isEmpty()) return;
                    moviePartial = new ArrayList<>(rows);
                    CatalogMemory.setMovies(rows);
                }
            }

            @Override public void success(List<Movie> rows) {
                synchronized (LoginCatalogPreloader.this) {
                    if (failed || moviesDone || attempt != moviesAttempt) return;
                    if (rows == null || rows.isEmpty()) {
                        handleMoviesError("Filmes indisponíveis", attempt);
                        return;
                    }
                    CatalogMemory.setMovies(rows);
                    moviesDone = true;
                    moviePartial = Collections.emptyList();
                    progress();
                    CACHE_IO.execute(() -> movieCache.saveMovies(rows));
                }
            }

            @Override public void error(String message) { handleMoviesError(message, attempt); }
        });
    }

    private void handleMoviesError(String message, int attempt) {
        List<Movie> partial;
        synchronized (this) {
            if (failed || moviesDone || attempt != moviesAttempt) return;
            partial = moviePartial == null ? Collections.emptyList() : new ArrayList<>(moviePartial);
            if (attempt < 2) {
                listener.status("Filmes demoraram a responder • tentando novamente...");
                main.postDelayed(this::loadMovies, 650L);
                return;
            }
        }
        final List<Movie> partialSnapshot = partial;
        CACHE_IO.execute(() -> {
            List<Movie> cached = movieCache.movies();
            List<Movie> fallback = chooseLarger(cached, partialSnapshot);
            main.post(() -> {
                synchronized (LoginCatalogPreloader.this) {
                    if (failed || moviesDone) return;
                    if (fallback != null && !fallback.isEmpty()) {
                        CatalogMemory.setMovies(fallback);
                        moviesDone = true;
                        listener.status("Filmes recuperados • continuando...");
                        progress();
                    } else {
                        fail(nonEmpty(message, "Falha ao carregar filmes"));
                    }
                }
            });
        });
    }

    private void loadSeriesCategories() {
        final int attempt = ++seriesCategoriesAttempt;
        new SeriesRepository(host, user, pass).categories(new SeriesRepository.CategoriesResult() {
            @Override public void success(List<SeriesCategory> rows) {
                synchronized (LoginCatalogPreloader.this) {
                    if (failed || seriesCategoriesDone) return;
                    List<SeriesCategory> safe = rows == null ? new ArrayList<>() : rows;
                    if (safe.isEmpty()) safe.add(allSeriesCategory());
                    CatalogMemory.setSeriesCategories(safe);
                    seriesCategoriesDone = true;
                    progress();
                    final List<SeriesCategory> save = safe;
                    CACHE_IO.execute(() -> seriesCache.saveCategories(save));
                }
            }
            @Override public void error(String message) { handleSeriesCategoriesError(attempt); }
        });
    }

    private void handleSeriesCategoriesError(int attempt) {
        synchronized (this) {
            if (failed || seriesCategoriesDone || attempt != seriesCategoriesAttempt) return;
            if (attempt < 2) {
                main.postDelayed(this::loadSeriesCategories, 450L);
                return;
            }
        }
        CACHE_IO.execute(() -> {
            List<SeriesCategory> cached = seriesCache.categories();
            if (cached == null || cached.isEmpty()) {
                cached = new ArrayList<>();
                cached.add(allSeriesCategory());
            }
            final List<SeriesCategory> fallback = cached;
            main.post(() -> {
                synchronized (LoginCatalogPreloader.this) {
                    if (failed || seriesCategoriesDone) return;
                    CatalogMemory.setSeriesCategories(fallback);
                    seriesCategoriesDone = true;
                    progress();
                }
            });
        });
    }

    private void loadSeries() {
        final int attempt = ++seriesAttempt;
        SeriesRepository repo = new SeriesRepository(host, user, pass);
        repo.seriesProgressive("", 48, 240, new SeriesRepository.ProgressiveSeriesResult() {
            @Override public void partial(List<SeriesItem> rows) {
                synchronized (LoginCatalogPreloader.this) {
                    if (failed || seriesDone || attempt != seriesAttempt || rows == null || rows.isEmpty()) return;
                    seriesPartial = new ArrayList<>(rows);
                    CatalogMemory.setSeries(rows);
                }
            }

            @Override public void success(List<SeriesItem> rows) {
                synchronized (LoginCatalogPreloader.this) {
                    if (failed || seriesDone || attempt != seriesAttempt) return;
                    if (rows == null || rows.isEmpty()) {
                        handleSeriesError("Séries indisponíveis", attempt);
                        return;
                    }
                    CatalogMemory.setSeries(rows);
                    seriesDone = true;
                    seriesPartial = Collections.emptyList();
                    progress();
                    CACHE_IO.execute(() -> seriesCache.saveSeries(rows));
                }
            }

            @Override public void error(String message) { handleSeriesError(message, attempt); }
        });
    }

    private void handleSeriesError(String message, int attempt) {
        List<SeriesItem> partial;
        synchronized (this) {
            if (failed || seriesDone || attempt != seriesAttempt) return;
            partial = seriesPartial == null ? Collections.emptyList() : new ArrayList<>(seriesPartial);
            if (attempt < 2) {
                listener.status("Séries demoraram a responder • tentando novamente...");
                main.postDelayed(this::loadSeries, 650L);
                return;
            }
        }
        final List<SeriesItem> partialSnapshot = partial;
        CACHE_IO.execute(() -> {
            List<SeriesItem> cached = seriesCache.series();
            List<SeriesItem> fallback = chooseLarger(cached, partialSnapshot);
            main.post(() -> {
                synchronized (LoginCatalogPreloader.this) {
                    if (failed || seriesDone) return;
                    if (fallback != null && !fallback.isEmpty()) {
                        CatalogMemory.setSeries(fallback);
                        seriesDone = true;
                        listener.status("Séries recuperadas • continuando...");
                        progress();
                    } else {
                        fail(nonEmpty(message, "Falha ao carregar séries"));
                    }
                }
            });
        });
    }

    private void progress() {
        if (failed) return;

        // Primeira carga: uma etapa grande por vez para não sobrecarregar painéis
        // mais lentos (evita timeout de Filmes/Séries disputando a mesma origem).
        if (tvDone && !moviePhaseStarted) {
            moviePhaseStarted = true;
            listener.status("Canais carregados • carregando filmes...");
            main.post(this::loadMovieCategories);
            main.postDelayed(this::loadMovies, 180L);
            return;
        }
        if (tvDone && moviesDone && movieCategoriesDone && !seriesPhaseStarted) {
            seriesPhaseStarted = true;
            listener.status("Canais e filmes carregados • carregando séries...");
            main.post(this::loadSeriesCategories);
            main.postDelayed(this::loadSeries, 180L);
            return;
        }

        if (tvDone && moviesDone && seriesDone && movieCategoriesDone && seriesCategoriesDone) {
            if (finishing) return;
            finishing = true;
            listener.status("Organizando catálogo...");
            INDEX_IO.execute(() -> {
                try { SpecialCatalogIndex.rebuild(); }
                catch (Exception ignored) { }
                synchronized (LoginCatalogPreloader.this) {
                    if (failed) return;
                }
                new CatalogRefreshPolicy(app, host, user).markFullRefresh();
                markSpecialCategoryMapsReady();
                listener.status("Tudo carregado. Entrando...");
                listener.success();
            });
            return;
        }

        if (!tvDone) listener.status("Carregando canais...");
        else if (!moviesDone && !seriesDone) listener.status("Canais carregados • carregando filmes e séries...");
        else if (!moviesDone) listener.status("Canais e séries carregados • carregando filmes...");
        else if (!seriesDone) listener.status("Canais e filmes carregados • carregando séries...");
        else if (!movieCategoriesDone || !seriesCategoriesDone) listener.status("Finalizando categorias...");
    }

    private void ensureSpecialCategoryMapsBeforeCachedOpen(final CatalogRefreshPolicy policy, final long idleBeforeOpen) {
        if (specialCategoryMapsReady()) {
            finishCachedOpen(policy, idleBeforeOpen);
            return;
        }
        listener.status("Organizando catálogo...");
        specialMapMovieDone = false;
        specialMapSeriesDone = false;
        specialMapMovieOk = false;
        specialMapSeriesOk = false;

        new MovieRepository(host, user, pass, false).categories(new MovieRepository.CategoriesResult() {
            @Override public void success(List<MovieCategory> rows) {
                synchronized (LoginCatalogPreloader.this) {
                    if (cachedOpenFinished) return;
                    if (rows != null && rows.size() > 1) {
                        CatalogMemory.setMovieCategories(rows);
                        final List<MovieCategory> save = new ArrayList<>(rows);
                        CACHE_IO.execute(() -> movieCache.saveCategories(save));
                        specialMapMovieOk = true;
                    }
                    specialMapMovieDone = true;
                }
                maybeFinishSpecialMapMigration(policy, idleBeforeOpen);
            }
            @Override public void error(String message) {
                synchronized (LoginCatalogPreloader.this) {
                    if (cachedOpenFinished) return;
                    specialMapMovieDone = true;
                }
                maybeFinishSpecialMapMigration(policy, idleBeforeOpen);
            }
        });

        new SeriesRepository(host, user, pass, false).categories(new SeriesRepository.CategoriesResult() {
            @Override public void success(List<SeriesCategory> rows) {
                synchronized (LoginCatalogPreloader.this) {
                    if (cachedOpenFinished) return;
                    if (rows != null && rows.size() > 1) {
                        CatalogMemory.setSeriesCategories(rows);
                        final List<SeriesCategory> save = new ArrayList<>(rows);
                        CACHE_IO.execute(() -> seriesCache.saveCategories(save));
                        specialMapSeriesOk = true;
                    }
                    specialMapSeriesDone = true;
                }
                maybeFinishSpecialMapMigration(policy, idleBeforeOpen);
            }
            @Override public void error(String message) {
                synchronized (LoginCatalogPreloader.this) {
                    if (cachedOpenFinished) return;
                    specialMapSeriesDone = true;
                }
                maybeFinishSpecialMapMigration(policy, idleBeforeOpen);
            }
        });
    }

    private void maybeFinishSpecialMapMigration(CatalogRefreshPolicy policy, long idleBeforeOpen) {
        synchronized (this) {
            if (cachedOpenFinished || !specialMapMovieDone || !specialMapSeriesDone) return;
            if (specialMapMovieOk && specialMapSeriesOk) markSpecialCategoryMapsReady();
        }
        finishCachedOpen(policy, idleBeforeOpen);
    }

    private void finishCachedOpen(final CatalogRefreshPolicy policy, final long idleBeforeOpen) {
        synchronized (this) {
            if (cachedOpenFinished) return;
            cachedOpenFinished = true;
        }
        INDEX_IO.execute(() -> {
            try { SpecialCatalogIndex.rebuild(); } catch (Exception ignored) { }
            listener.success();
            if (policy.shouldSilentRefresh(idleBeforeOpen)) {
                CatalogSilentRefresh.start(app, host, user, pass);
            }
        });
    }

    private boolean specialCategoryMapsReady() {
        String key = Integer.toHexString((host + "|" + user).hashCode());
        return app.getSharedPreferences(SPECIAL_MAP_PREF, Context.MODE_PRIVATE)
                .getBoolean("ready_" + key, false);
    }

    private void markSpecialCategoryMapsReady() {
        String key = Integer.toHexString((host + "|" + user).hashCode());
        app.getSharedPreferences(SPECIAL_MAP_PREF, Context.MODE_PRIVATE)
                .edit().putBoolean("ready_" + key, true).apply();
    }

    private synchronized void fail(String message) {
        if (failed) return;
        failed = true;
        CatalogMemory.clear();
        listener.error(nonEmpty(message, "Falha ao preparar o catálogo"));
    }

    private static SeriesCategory allSeriesCategory() {
        SeriesCategory c = new SeriesCategory();
        c.id = "";
        c.name = "TODOS";
        return c;
    }

    private static String nonEmpty(String value, String fallback) {
        return value == null || value.trim().isEmpty() ? fallback : value.trim();
    }

    private static <T> List<T> chooseLarger(List<T> a, List<T> b) {
        int as = a == null ? 0 : a.size();
        int bs = b == null ? 0 : b.size();
        if (as == 0 && bs == 0) return Collections.emptyList();
        return as >= bs ? new ArrayList<>(a) : new ArrayList<>(b);
    }
}
