package com.ativacao.app;

import android.app.Activity;
import android.app.role.RoleManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Base64;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

public class LauncherActivity extends Activity {
    private final android.os.Handler handler = new android.os.Handler(android.os.Looper.getMainLooper());
    private JSONObject state;
    private boolean syncing=false;
    private int primary=Color.rgb(233,31,53);
    private final int BG=Color.rgb(10,10,14);
    private final int CARD=Color.rgb(24,24,32);
    private final int TEXT=Color.rgb(248,248,250);
    private final int MUTED=Color.rgb(180,180,195);

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        if(DeviceControl.isDeviceOwner(this)) DeviceControl.enforceManagedState(this);
        renderBoot();
    }
    @Override protected void onResume(){
        super.onResume();
        if(DeviceControl.isDeviceOwner(this)) DeviceControl.enforceManagedState(this);
        if(!LauncherStore.isActivationComplete(this)){openActivator(false);return;}
        if(isLauncherRequired()&&!isDefaultHome()){renderDefaultLauncherGate();return;}
        syncLauncher();
    }

    @Override public void onBackPressed(){
        if(LauncherStore.isActivationComplete(this) && isLauncherRequired() && !isDefaultHome()){
            renderDefaultLauncherGate();
            return;
        }
        super.onBackPressed();
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==901){
            handler.postDelayed(()->{
                if(isDefaultHome()) syncLauncher(); else renderDefaultLauncherGate();
            },350);
        }
    }

    private boolean isLauncherRequired(){
        try{String c=LauncherStore.getCachedJson(this);if(!c.isEmpty())return new JSONObject(c).optBoolean("launcher_required",true);}catch(Exception ignored){}
        return true;
    }

    private void renderBoot(){
        ScrollView s=baseScroll();LinearLayout root=container(s);title(root,"ATIVADOR UNITV","Carregando sua Launcher...");ProgressBar p=new ProgressBar(this);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(54),dp(54));lp.gravity=Gravity.CENTER_HORIZONTAL;root.addView(p,lp);setContentView(s);
    }

    private boolean isDefaultHome(){
        try{Intent i=new Intent(Intent.ACTION_MAIN);i.addCategory(Intent.CATEGORY_HOME);ResolveInfo ri=getPackageManager().resolveActivity(i,PackageManager.MATCH_DEFAULT_ONLY);return ri!=null&&ri.activityInfo!=null&&getPackageName().equals(ri.activityInfo.packageName);}catch(Exception e){return false;}
    }

    private void requestDefaultHome(){
        try{
            if(DeviceControl.isDeviceOwner(this) && DeviceControl.setAsPersistentHome(this)){ Toast.makeText(this,"Launcher definida como padrão.",Toast.LENGTH_LONG).show(); handler.postDelayed(this::syncLauncher,600); return; }
            if(Build.VERSION.SDK_INT>=29){ RoleManager rm=(RoleManager)getSystemService(Context.ROLE_SERVICE); if(rm!=null&&rm.isRoleAvailable(RoleManager.ROLE_HOME)&&!rm.isRoleHeld(RoleManager.ROLE_HOME)){startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_HOME),901);return;} }
            Intent i=new Intent(Settings.ACTION_HOME_SETTINGS);startActivity(i);
        }catch(Exception e){
            try{Intent i=new Intent(Intent.ACTION_MAIN);i.addCategory(Intent.CATEGORY_HOME);startActivity(Intent.createChooser(i,"Escolha Ativador Launcher como Launcher padrão"));}catch(Exception ignored){Toast.makeText(this,"Abra Configurações > Aplicativos padrão > Tela inicial e escolha Ativador Launcher.",Toast.LENGTH_LONG).show();}
        }
    }

    private void renderDefaultLauncherGate(){
        ScrollView s=baseScroll();
        LinearLayout root=container(s);
        title(root,"CONFIGURAR LAUNCHER","Para continuar, o Ativador Launcher precisa ser a tela inicial padrão da TV Box.");
        TextView t=info("ETAPA OBRIGATÓRIA\n\nSelecione “Ativador Launcher” como Tela inicial / Home / Launcher padrão. O aplicativo não libera a tela principal enquanto outro Launcher estiver definido como padrão.",true);
        root.addView(t);

        if(DeviceControl.isDeviceOwner(this)){
            DeviceControl.enforceManagedState(this);
            TextView managed=info(DeviceControl.isUninstallProtectionActive(this)
                    ? "PROTEÇÃO COMPLETA ATIVA • Launcher fixada como Home • desinstalação protegida pelo gerenciamento do Android."
                    : "Modo gerenciado detectado. Aplicando proteção do aplicativo...",true);
            root.addView(managed);
        }else{
            TextView note=info("Proteção contra desinstalação: para impedir a remoção de verdade, este aparelho precisa estar provisionado como Device Owner. Em modo comum o Android não concede essa permissão a aplicativos normais.",false);
            root.addView(note);
        }

        Button b=button("DEFINIR COMO LAUNCHER PADRÃO");
        root.addView(b,new LinearLayout.LayoutParams(-1,dp(68)));
        b.setOnClickListener(v->requestDefaultHome());
        b.requestFocus();
        setContentView(s);
    }

    private void syncLauncher(){
        if(syncing)return; syncing=true;String code=LauncherStore.getDeviceCode(this);if(code.isEmpty()){renderNoCode();syncing=false;return;} renderCachedOrLoading();
        new Thread(()->{
            try{
                String did=Settings.Secure.getString(getContentResolver(),Settings.Secure.ANDROID_ID);String model=Build.MANUFACTURER+" "+Build.MODEL;
                String url=Config.BASE_URL+"/api/launcher_sync.php?device_code="+enc(code)+"&device_id="+enc(did==null?"":did)+"&model="+enc(model)+"&android="+enc(String.valueOf(Build.VERSION.SDK_INT))+"&app_version=3.0&default_launcher="+(isDefaultHome()?"1":"0")+"&device_owner="+(DeviceControl.isDeviceOwner(this)?"1":"0");
                String json=httpGet(url);JSONObject o=new JSONObject(json);if(!"ok".equalsIgnoreCase(o.optString("status")))throw new Exception(o.optString("mensagem","Falha de sincronização."));
                LauncherStore.setCachedJson(this,json);state=o;applyPolicy(o);runOnUiThread(()->renderState(o,false));
            }catch(Exception e){String c=LauncherStore.getCachedJson(this);try{if(!c.isEmpty()){JSONObject o=new JSONObject(c);state=o;applyOfflineExpiry(o);applyPolicy(o);runOnUiThread(()->renderState(o,true));}else runOnUiThread(()->renderOfflineEmpty(e.getMessage()));}catch(Exception x){runOnUiThread(()->renderOfflineEmpty(e.getMessage()));}}
            finally{syncing=false;}
        },"launcher-sync").start();
    }

    private void applyOfflineExpiry(JSONObject o){long exp=o.optLong("expires_epoch",0L);if(exp>0&&System.currentTimeMillis()/1000L>exp){try{o.put("block_unitv",true);o.put("client_status","expired");}catch(Exception ignored){}}}
    private void applyPolicy(JSONObject o){String pkg=o.optString("unitv_package","");boolean block=o.optBoolean("block_unitv",true);if(DeviceControl.isDeviceOwner(this)&&!pkg.isEmpty()){DeviceControl.protectActivator(this);DeviceControl.setPackageBlocked(this,pkg,block);}}

    private void renderCachedOrLoading(){String c=LauncherStore.getCachedJson(this);if(c.isEmpty()){renderBoot();return;}try{renderState(new JSONObject(c),true);}catch(Exception e){renderBoot();}}
    private void renderNoCode(){ScrollView s=baseScroll();LinearLayout r=container(s);title(r,"ATIVAÇÃO NECESSÁRIA","Primeiro conclua a ativação e a instalação do UniTV.");Button b=button("ABRIR ATIVADOR");r.addView(b,new LinearLayout.LayoutParams(-1,dp(64)));b.setOnClickListener(v->openActivator(true));setContentView(s);}
    private void renderOfflineEmpty(String err){ScrollView s=baseScroll();LinearLayout r=container(s);title(r,"SEM CONEXÃO","A primeira sincronização da Launcher precisa de internet.");r.addView(info(err==null?"Conecte à internet e tente novamente.":err,true));Button b=button("TENTAR NOVAMENTE");r.addView(b,new LinearLayout.LayoutParams(-1,dp(64)));b.setOnClickListener(v->syncLauncher());setContentView(s);}

    private void renderState(JSONObject o,boolean offline){
        if(isLauncherRequired()&&!isDefaultHome()){renderDefaultLauncherGate();return;}
        JSONObject brand=o.optJSONObject("branding");if(brand==null)brand=new JSONObject();String color=brand.optString("primary_color","#e91f35");try{primary=Color.parseColor(color);}catch(Exception ignored){primary=Color.rgb(233,31,53);}
        ScrollView s=baseScroll();String bg=brand.optString("background_url","");if(!bg.isEmpty())loadBackground(s,bg);LinearLayout r=container(s);
        String logo=brand.optString("logo_url","");if(!logo.isEmpty()){ImageView iv=new ImageView(this);iv.setAdjustViewBounds(true);iv.setScaleType(ImageView.ScaleType.FIT_CENTER);LinearLayout.LayoutParams ilp=new LinearLayout.LayoutParams(dp(180),dp(92));ilp.gravity=Gravity.CENTER_HORIZONTAL;ilp.setMargins(0,0,0,10);r.addView(iv,ilp);loadImage(iv,logo,"logo.cache");}
        title(r,brand.optString("launcher_title","UniTV"),offline?"Modo offline — usando a última liberação salva":"Conectado ao painel");
        if(!o.optBoolean("assigned",false)){renderUnassigned(r,o,offline);setContentView(s);return;}
        boolean blocked=o.optBoolean("block_unitv",true);String status=o.optString("client_status","");String exp=o.optString("expires_at","");
        TextView badge=info((blocked?"BLOQUEADO":"LIBERADO")+(exp.isEmpty()?"":"  •  vence em "+exp),true);badge.setTextColor(blocked?Color.rgb(255,115,120):Color.rgb(110,235,160));r.addView(badge);
        if(blocked){TextView m=info(o.optString("message","Seu plano venceu. Renove para continuar."),true);r.addView(m);Button pay=button("RENOVAR AGORA");LinearLayout.LayoutParams pl=new LinearLayout.LayoutParams(-1,dp(70));pl.setMargins(0,dp(14),0,0);r.addView(pay,pl);pay.setOnClickListener(v->renderPlans(o));pay.requestFocus();}
        else{Button u=button("ABRIR UNITV");LinearLayout.LayoutParams ul=new LinearLayout.LayoutParams(-1,dp(76));ul.setMargins(0,dp(14),0,0);r.addView(u,ul);u.setOnClickListener(v->launchUnitv(o));u.requestFocus();Button renew=buttonSecondary("RENOVAR / VER PLANOS");LinearLayout.LayoutParams rl=new LinearLayout.LayoutParams(-1,dp(58));rl.setMargins(0,dp(10),0,0);r.addView(renew,rl);renew.setOnClickListener(v->renderPlans(o));}
        renderApps(r,o);renderTutorialButton(r,o);renderFooter(r,o,offline);setContentView(s);
    }

    private void renderUnassigned(LinearLayout r,JSONObject o,boolean offline){String code=o.optString("device_code",LauncherStore.getDeviceCode(this));TextView h=info("ENVIE ESTE CÓDIGO PARA O SEU REVENDEDOR",true);r.addView(h);TextView c=new TextView(this);c.setText(code);c.setTextColor(Color.WHITE);c.setTextSize(42);c.setTypeface(Typeface.MONOSPACE,Typeface.BOLD);c.setGravity(Gravity.CENTER);c.setPadding(10,22,10,22);c.setBackground(border(Color.argb(220,25,25,34),primary,18,2));r.addView(c,new LinearLayout.LayoutParams(-1,-2));TextView d=info(offline?"Sem conexão. Assim que a internet voltar, a Launcher consultará o painel novamente.":"O revendedor entra no painel, informa este código e escolhe o seu plano. A tela libera automaticamente.",true);r.addView(d);Button b=button("ATUALIZAR LIBERAÇÃO");LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(64));lp.setMargins(0,dp(14),0,0);r.addView(b,lp);b.setOnClickListener(v->syncLauncher());b.requestFocus();}

    private void launchUnitv(JSONObject o){if(o.optBoolean("block_unitv",true)){Toast.makeText(this,o.optString("message","Plano bloqueado."),Toast.LENGTH_LONG).show();return;}String pkg=o.optString("unitv_package","");if(pkg.isEmpty()){Toast.makeText(this,"Package do UniTV não configurado no painel.",Toast.LENGTH_LONG).show();return;}try{Intent i=getPackageManager().getLaunchIntentForPackage(pkg);if(i==null){Toast.makeText(this,"UniTV não está instalado.",Toast.LENGTH_LONG).show();return;}startActivity(i);}catch(Exception e){Toast.makeText(this,"Não foi possível abrir o UniTV.",Toast.LENGTH_LONG).show();}}

    private void renderApps(LinearLayout r,JSONObject o){JSONArray arr=o.optJSONArray("apps");if(arr==null||arr.length()==0)return;TextView h=section("APLICATIVOS");r.addView(h);for(int i=0;i<arr.length();i++){JSONObject a=arr.optJSONObject(i);if(a==null||!a.optBoolean("launcher_visible",true)||a.optBoolean("is_unitv",false))continue;String name=a.optString("name","Aplicativo"),pkg=a.optString("package_name","");boolean blocked=a.optBoolean("blocked",false);Button b=buttonSecondary((blocked?"🔒 ":"")+name);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(58));lp.setMargins(0,dp(7),0,0);r.addView(b,lp);b.setEnabled(!blocked);b.setOnClickListener(v->{if(isInstalled(pkg))openPackage(pkg);else downloadAndInstall(a.optString("download_url",""),name);});}}
    private void renderTutorialButton(LinearLayout r,JSONObject o){JSONArray t=o.optJSONArray("tutorials");if(t==null||t.length()==0)return;Button b=buttonSecondary("TUTORIAIS");LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(58));lp.setMargins(0,dp(16),0,0);r.addView(b,lp);b.setOnClickListener(v->renderTutorials(o));}
    private void renderFooter(LinearLayout r,JSONObject o,boolean offline){TextView f=info("Código do aparelho: "+o.optString("device_code",LauncherStore.getDeviceCode(this))+(offline?"  •  OFF-LINE":""),false);r.addView(f);Button a=buttonSecondary("ATIVADOR / CONFIGURAÇÃO");LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(50));lp.setMargins(0,dp(10),0,0);r.addView(a,lp);a.setOnClickListener(v->openActivator(true));}

    private void renderPlans(JSONObject o){JSONArray plans=o.optJSONArray("plans");JSONArray gateways=o.optJSONArray("gateways");ScrollView s=baseScroll();LinearLayout r=container(s);title(r,"RENOVAR PLANO","O pagamento Pix é gerado e exibido aqui, sem abrir navegador.");if(plans==null||plans.length()==0){r.addView(info("Seu revendedor ainda não cadastrou planos.",true));backButton(r,()->renderState(o,false));setContentView(s);return;}if(gateways==null||gateways.length()==0){r.addView(info("Seu revendedor ainda não ativou Mercado Pago ou MisticPay.",true));backButton(r,()->renderState(o,false));setContentView(s);return;}for(int i=0;i<plans.length();i++){JSONObject p=plans.optJSONObject(i);if(p==null)continue;String label=p.optString("name")+" — R$ "+String.format(java.util.Locale.forLanguageTag("pt-BR"),"%.2f",p.optDouble("price"));Button b=button(label);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(66));lp.setMargins(0,dp(8),0,0);r.addView(b,lp);b.setOnClickListener(v->renderPayer(o,p));}backButton(r,()->renderState(o,false));setContentView(s);}

    private void renderPayer(JSONObject o,JSONObject plan){ScrollView s=baseScroll();LinearLayout r=container(s);title(r,"DADOS DO PAGADOR",plan.optString("name")+" — R$ "+String.format(java.util.Locale.forLanguageTag("pt-BR"),"%.2f",plan.optDouble("price")));EditText n=input("Nome completo",LauncherStore.getPayerName(this));EditText e=input("E-mail",LauncherStore.getPayerEmail(this));EditText d=input("CPF/CNPJ",LauncherStore.getPayerDoc(this));d.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);r.addView(n);r.addView(e);r.addView(d);configureDone(n,e);configureDone(e,d);JSONArray g=o.optJSONArray("gateways");for(int i=0;i<(g==null?0:g.length());i++){String provider=g.optString(i);Button b=button(provider.equals("mercadopago")?"PAGAR COM MERCADO PAGO PIX":"PAGAR COM MISTICPAY PIX");LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(64));lp.setMargins(0,dp(10),0,0);r.addView(b,lp);b.setOnClickListener(v->{String name=n.getText().toString().trim(),email=e.getText().toString().trim(),doc=d.getText().toString().replaceAll("\\D","");if(name.isEmpty()||doc.length()<11){Toast.makeText(this,"Preencha nome e CPF/CNPJ.",Toast.LENGTH_LONG).show();return;}if(provider.equals("mercadopago")&&email.isEmpty()){Toast.makeText(this,"Mercado Pago exige o e-mail do pagador.",Toast.LENGTH_LONG).show();return;}LauncherStore.setPayer(this,name,email,doc);createPix(o,plan,provider,name,email,doc);});}backButton(r,()->renderPlans(o));setContentView(s);n.requestFocus();}

    private void createPix(JSONObject o,JSONObject plan,String provider,String name,String email,String doc){renderPaymentLoading("Gerando Pix...");new Thread(()->{try{String body="device_code="+enc(LauncherStore.getDeviceCode(this))+"&plan_id="+plan.optInt("id")+"&provider="+enc(provider)+"&payer_name="+enc(name)+"&payer_email="+enc(email)+"&payer_document="+enc(doc);String json=httpPostForm(Config.BASE_URL+"/api/create_pix.php",body);JSONObject p=new JSONObject(json);if(!"ok".equalsIgnoreCase(p.optString("status")))throw new Exception(p.optString("mensagem","Falha ao gerar Pix."));runOnUiThread(()->renderPix(o,p));}catch(Exception ex){runOnUiThread(()->{Toast.makeText(this,ex.getMessage(),Toast.LENGTH_LONG).show();renderPlans(o);});}},"create-pix").start();}

    private void renderPaymentLoading(String txt){ScrollView s=baseScroll();LinearLayout r=container(s);title(r,"PAGAMENTO",txt);ProgressBar p=new ProgressBar(this);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(55),dp(55));lp.gravity=Gravity.CENTER_HORIZONTAL;r.addView(p,lp);setContentView(s);}
    private void renderPix(JSONObject launcher,JSONObject pay){ScrollView s=baseScroll();LinearLayout r=container(s);title(r,"PIX GERADO","Pague pelo aplicativo do seu banco. A liberação é automática após a confirmação.");String qr64=pay.optString("qr_base64","");if(qr64.startsWith("data:")){int comma=qr64.indexOf(',');if(comma>=0)qr64=qr64.substring(comma+1);}try{byte[] b=Base64.decode(qr64,Base64.DEFAULT);Bitmap bmp=BitmapFactory.decodeByteArray(b,0,b.length);if(bmp!=null){ImageView iv=new ImageView(this);iv.setImageBitmap(bmp);iv.setScaleType(ImageView.ScaleType.FIT_CENTER);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(300),dp(300));lp.gravity=Gravity.CENTER_HORIZONTAL;r.addView(iv,lp);}}catch(Exception ignored){}
        String code=pay.optString("pix_code","");EditText pix=input("Pix Copia e Cola",code);pix.setFocusable(false);r.addView(pix);Button copy=button("COPIAR PIX");r.addView(copy,new LinearLayout.LayoutParams(-1,dp(62)));copy.setOnClickListener(v->{ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);cm.setPrimaryClip(ClipData.newPlainText("Pix",code));Toast.makeText(this,"Pix copiado.",Toast.LENGTH_SHORT).show();});TextView st=info("Aguardando pagamento...",true);r.addView(st);Button check=buttonSecondary("VERIFICAR PAGAMENTO");LinearLayout.LayoutParams cl=new LinearLayout.LayoutParams(-1,dp(56));cl.setMargins(0,dp(10),0,0);r.addView(check,cl);Runnable poll=new Runnable(){@Override public void run(){checkPayment(pay.optInt("payment_id"),launcher,st,this);}};check.setOnClickListener(v->poll.run());handler.postDelayed(poll,5000);setContentView(s);copy.requestFocus();}
    private void checkPayment(int id,JSONObject launcher,TextView status,Runnable again){new Thread(()->{try{String json=httpGet(Config.BASE_URL+"/api/payment_status.php?payment_id="+id+"&device_code="+enc(LauncherStore.getDeviceCode(this)));JSONObject o=new JSONObject(json);String ps=o.optString("payment_status","");runOnUiThread(()->{if("paid".equals(ps)){status.setText("PAGAMENTO CONFIRMADO. Liberando...");handler.postDelayed(this::syncLauncher,1200);}else if("failed".equals(ps)){status.setText("Pagamento não aprovado.");}else{status.setText("Aguardando pagamento...");handler.postDelayed(again,5000);}});}catch(Exception e){runOnUiThread(()->handler.postDelayed(again,8000));}},"pay-check").start();}

    private void renderTutorials(JSONObject launcher){ScrollView s=baseScroll();LinearLayout r=container(s);title(r,"TUTORIAIS","Conteúdo enviado pelo seu revendedor.");JSONArray arr=launcher.optJSONArray("tutorials");for(int i=0;i<(arr==null?0:arr.length());i++){JSONObject t=arr.optJSONObject(i);if(t==null)continue;TextView h=section(t.optString("title","Tutorial"));r.addView(h);TextView b=info(t.optString("body",""),false);r.addView(b);String url=t.optString("video_url","");if(!url.isEmpty()){Button v=buttonSecondary("ABRIR VÍDEO");r.addView(v,new LinearLayout.LayoutParams(-1,dp(54)));v.setOnClickListener(x->{try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception ignored){}});}}backButton(r,()->renderState(launcher,false));setContentView(s);}

    private void downloadAndInstall(String url,String name){if(url.isEmpty()){Toast.makeText(this,"APK indisponível.",Toast.LENGTH_LONG).show();return;}renderPaymentLoading("Baixando "+name+"...");new Thread(()->{try{byte[] data=downloadBytes(url);File f=new File(getExternalFilesDir(null),"launcher_app_"+System.currentTimeMillis()+".apk");try(FileOutputStream os=new FileOutputStream(f)){os.write(data);}runOnUiThread(()->{try{Uri uri=FileProvider.getUriForFile(this,getPackageName()+".provider",f);Intent i=new Intent(Intent.ACTION_VIEW);i.setDataAndType(uri,"application/vnd.android.package-archive");i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);}catch(Exception e){Toast.makeText(this,"Não foi possível abrir o instalador.",Toast.LENGTH_LONG).show();}handler.postDelayed(this::syncLauncher,1000);});}catch(Exception e){runOnUiThread(()->{Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();syncLauncher();});}},"download-app").start();}

    private boolean isInstalled(String pkg){try{getPackageManager().getPackageInfo(pkg,0);return true;}catch(Exception e){return false;}}
    private void openPackage(String pkg){try{Intent i=getPackageManager().getLaunchIntentForPackage(pkg);if(i!=null)startActivity(i);}catch(Exception ignored){}}
    private void openActivator(boolean force){Intent i=new Intent(this,MainActivity.class);if(force)i.putExtra("force_activation_ui",true);startActivity(i);}

    private ScrollView baseScroll(){ScrollView s=new ScrollView(this);s.setFillViewport(true);s.setBackgroundColor(BG);return s;}
    private LinearLayout container(ScrollView s){LinearLayout out=new LinearLayout(this);out.setOrientation(LinearLayout.VERTICAL);out.setGravity(Gravity.CENTER);out.setPadding(dp(18),dp(26),dp(18),dp(26));s.addView(out,new ScrollView.LayoutParams(-1,-1));LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setGravity(Gravity.CENTER_HORIZONTAL);r.setPadding(dp(28),dp(26),dp(28),dp(28));r.setBackground(border(Color.argb(225,18,18,25),Color.argb(110,255,255,255),22,1));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(isTv()?dp(820):-1,-2);lp.gravity=Gravity.CENTER;out.addView(r,lp);return r;}
    private boolean isTv(){int mode=getResources().getConfiguration().uiMode&android.content.res.Configuration.UI_MODE_TYPE_MASK;return mode==android.content.res.Configuration.UI_MODE_TYPE_TELEVISION||!getPackageManager().hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN);}
    private void title(LinearLayout r,String t,String sub){TextView a=new TextView(this);a.setText(t);a.setTextColor(TEXT);a.setTextSize(isTv()?30:24);a.setTypeface(Typeface.DEFAULT_BOLD);a.setGravity(Gravity.CENTER);r.addView(a,new LinearLayout.LayoutParams(-1,-2));TextView b=info(sub,false);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(8),0,dp(18));r.addView(b,lp);}
    private TextView section(String s){TextView t=new TextView(this);t.setText(s);t.setTextColor(TEXT);t.setTextSize(isTv()?21:17);t.setTypeface(Typeface.DEFAULT_BOLD);t.setPadding(0,dp(22),0,dp(8));return t;}
    private TextView info(String s,boolean box){TextView t=new TextView(this);t.setText(s);t.setTextColor(MUTED);t.setTextSize(isTv()?18:15);t.setGravity(Gravity.CENTER);t.setPadding(dp(14),dp(14),dp(14),dp(14));if(box)t.setBackground(border(Color.argb(110,30,30,40),Color.argb(100,255,255,255),14,1));return t;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(isTv()?19:16);b.setTypeface(Typeface.DEFAULT_BOLD);b.setAllCaps(false);b.setBackground(border(primary,primary,14,1));b.setFocusable(true);return b;}
    private Button buttonSecondary(String s){Button b=button(s);b.setBackground(border(Color.rgb(42,42,54),Color.argb(100,255,255,255),14,1));return b;}
    private EditText input(String hint,String value){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(Color.rgb(130,130,145));e.setTextColor(Color.WHITE);e.setText(value);e.setSingleLine(true);e.setTextSize(isTv()?18:16);e.setPadding(dp(15),dp(13),dp(15),dp(13));e.setBackground(border(Color.rgb(17,17,24),Color.rgb(65,65,82),12,1));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(isTv()?66:58));lp.setMargins(0,dp(7),0,dp(7));e.setLayoutParams(lp);return e;}
    private void configureDone(EditText a,View next){a.setImeOptions(EditorInfo.IME_ACTION_NEXT);a.setOnEditorActionListener((v,id,event)->{if(id==EditorInfo.IME_ACTION_NEXT||(event!=null&&event.getKeyCode()==KeyEvent.KEYCODE_ENTER)){next.requestFocus();return true;}return false;});}
    private void backButton(LinearLayout r,Runnable run){Button b=buttonSecondary("VOLTAR");LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(54));lp.setMargins(0,dp(16),0,0);r.addView(b,lp);b.setOnClickListener(v->run.run());}
    private GradientDrawable border(int bg,int stroke,int radius,int sw){GradientDrawable g=new GradientDrawable();g.setColor(bg);g.setCornerRadius(dp(radius));g.setStroke(dp(sw),stroke);return g;}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}

    private void loadImage(ImageView v,String url,String cacheName){new Thread(()->{try{File f=new File(getFilesDir(),cacheName);Bitmap b=null;try{b=BitmapFactory.decodeStream(new URL(url).openStream());if(b!=null){try(FileOutputStream o=new FileOutputStream(f)){b.compress(Bitmap.CompressFormat.PNG,90,o);}}}catch(Exception ignored){}if(b==null&&f.isFile())b=BitmapFactory.decodeFile(f.getAbsolutePath());Bitmap finalB=b;if(finalB!=null)runOnUiThread(()->v.setImageBitmap(finalB));}catch(Exception ignored){}},"img").start();}
    private void loadBackground(ScrollView s,String url){new Thread(()->{try{File f=new File(getFilesDir(),"background.cache");Bitmap b=null;try{b=BitmapFactory.decodeStream(new URL(url).openStream());if(b!=null){try(FileOutputStream o=new FileOutputStream(f)){b.compress(Bitmap.CompressFormat.JPEG,85,o);}}}catch(Exception ignored){}if(b==null&&f.isFile())b=BitmapFactory.decodeFile(f.getAbsolutePath());Bitmap finalB=b;if(finalB!=null)runOnUiThread(()->{BitmapDrawable bd=new BitmapDrawable(getResources(),finalB);bd.setGravity(Gravity.CENTER);s.setBackground(bd);});}catch(Exception ignored){}},"bg").start();}
    private String enc(String v)throws Exception{return URLEncoder.encode(v==null?"":v,"UTF-8");}
    private String httpGet(String url)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(15000);c.setReadTimeout(25000);c.setRequestMethod("GET");InputStream is=c.getResponseCode()>=400?c.getErrorStream():c.getInputStream();if(is==null)throw new Exception("Servidor não respondeu.");BufferedReader br=new BufferedReader(new InputStreamReader(is));StringBuilder sb=new StringBuilder();String l;while((l=br.readLine())!=null)sb.append(l);br.close();c.disconnect();return sb.toString();}
    private String httpPostForm(String url,String body)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(15000);c.setReadTimeout(30000);c.setRequestMethod("POST");c.setDoOutput(true);c.setRequestProperty("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");try(java.io.OutputStream os=c.getOutputStream()){os.write(body.getBytes("UTF-8"));}InputStream is=c.getResponseCode()>=400?c.getErrorStream():c.getInputStream();if(is==null)throw new Exception("Servidor não respondeu.");BufferedReader br=new BufferedReader(new InputStreamReader(is));StringBuilder sb=new StringBuilder();String l;while((l=br.readLine())!=null)sb.append(l);br.close();c.disconnect();return sb.toString();}
    private byte[] downloadBytes(String url)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(20000);c.setReadTimeout(60000);InputStream is=c.getInputStream();java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=is.read(b))>0)out.write(b,0,n);is.close();c.disconnect();return out.toByteArray();}
}
