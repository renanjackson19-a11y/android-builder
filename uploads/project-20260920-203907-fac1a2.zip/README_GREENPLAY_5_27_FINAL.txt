GREENPLAY 5.27 — HOTFIX 52702

Base atual corrigida: GreenPlay 5.27 / versionCode 52701.
Entrega: versionName 5.27 / versionCode 52702.

Correções desta build:
- A abertura confia no snapshot completo de canais enviado pelo painel (live_complete), evitando refazer toda a paginação e ficar presa em "Carregando canais...".
- Atualização do aplicativo passa a ser decidida somente por versionCode maior.
- SHA-256 continua sendo usado apenas para validar o APK baixado.
- Mantém a preparação leve de logos na abertura; a biblioteca pesada fica no painel.

Usar junto com o PATCH do painel v131.9 desta mesma entrega.

- 52702: limpa snapshot antigo que podia misturar TV em Filmes após mudança da fonte para M3U.
- Cards reaproveitam metadados/capas TMDB já enriquecidos sem bloquear a abertura.
