package com.ativacao.app;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class OpenGameCatalog {
    interface Callback{void ok(List<Game> data);void error(String msg);}
    static class Game{String name="",platform="",year="";Game(String n,String p){name=n;platform=p;}}
    private static final ExecutorService IO=Executors.newSingleThreadExecutor();
    private static final String RAW="https://raw.githubusercontent.com/0u73r-h34v3n/opengamesdatabase/master/platforms/";

    static void load(String mode,Callback cb){
        IO.execute(()->{
            try{
                ArrayList<Game> out=new ArrayList<>();
                if("retro".equals(mode)){
                    loadMap("DS","Nintendo DS",out,70);
                    loadMap("3DS","Nintendo 3DS",out,50);
                    loadMap("PS2","PlayStation 2",out,70);
                }else if("ps2".equals(mode))loadMap("PS2","PlayStation 2",out,120);
                else if("ds".equals(mode))loadMap("DS","Nintendo DS",out,120);
                else if("3ds".equals(mode))loadMap("3DS","Nintendo 3DS",out,120);
                if(out.isEmpty())fallback(out);
                cb.ok(out);
            }catch(Exception e){
                ArrayList<Game> out=new ArrayList<>();fallback(out);
                if(out.isEmpty())cb.error(e.getMessage()==null?"erro de rede":e.getMessage());else cb.ok(out);
            }
        });
    }

    private static void loadMap(String folder,String platform,List<Game> out,int limit)throws Exception{
        String raw=get(RAW+folder+"/map.json");
        Object parsed=new org.json.JSONTokener(raw).nextValue();
        if(parsed instanceof JSONObject){
            JSONObject o=(JSONObject)parsed;Iterator<String> it=o.keys();
            while(it.hasNext()&&countPlatform(out,platform)<limit){
                String k=it.next();Object val=o.opt(k);String n=k;
                if(val instanceof String&&!((String)val).trim().isEmpty())n=(String)val;
                else if(val instanceof JSONObject)n=((JSONObject)val).optString("name",k);
                if(!n.trim().isEmpty())out.add(new Game(n.trim(),platform));
            }
        }else if(parsed instanceof JSONArray){
            JSONArray a=(JSONArray)parsed;
            for(int i=0;i<a.length()&&countPlatform(out,platform)<limit;i++){
                Object val=a.opt(i);String n="";
                if(val instanceof String)n=(String)val;
                else if(val instanceof JSONObject)n=((JSONObject)val).optString("name","");
                if(!n.trim().isEmpty())out.add(new Game(n.trim(),platform));
            }
        }
    }
    private static int countPlatform(List<Game> a,String p){int c=0;for(Game g:a)if(p.equals(g.platform))c++;return c;}
    private static String get(String u)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();
        c.setConnectTimeout(7000);c.setReadTimeout(9000);c.setRequestProperty("User-Agent","DubaiPlayTV/3.0.3");
        BufferedReader b=new BufferedReader(new InputStreamReader(c.getInputStream()));
        StringBuilder s=new StringBuilder();String l;while((l=b.readLine())!=null)s.append(l);b.close();return s.toString();
    }
    private static void fallback(List<Game> a){
        String[] n={"2048","OpenTyrian","Cave Story","Freedoom","SuperTux","SuperTuxKart","Sonic Robo Blast 2","Xonotic","The Battle for Wesnoth","Minetest / Luanti"};
        for(String x:n)a.add(new Game(x,"Open/Homebrew"));
    }
}