package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

final class YellowNav {
    private YellowNav(){}

    static View bar(Activity a, String active){
        boolean phone=Ui.phone(a);
        LinearLayout row=new LinearLayout(a);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(Ui.dp(a,18),0,Ui.dp(a,14),0);
        row.setBackgroundColor(Color.BLACK);

        TextView brand=Ui.text(a,"DUBAI PLAY",phone?14:17,Ui.GREEN,true);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(brand,new LinearLayout.LayoutParams(Ui.dp(a,phone?145:170),-1));

        tab(a,row,"TV",active,()->open(a,LiveTvActivity.class));
        tab(a,row,"DESTAQUES",active,()->{Intent i=new Intent(a,MainActivity.class);i.putExtra("show_highlights",true);a.startActivity(i);});
        tab(a,row,"FILMES",active,()->catalog(a,"movie","Filmes",""));
        tab(a,row,"SÉRIES",active,()->catalog(a,"series","Séries",""));
        tab(a,row,"SHOWS",active,()->discover(a,"shows","Shows"));
        tab(a,row,"KIDS",active,()->discover(a,"kids","Kids"));
        tab(a,row,"ANIMES",active,()->discover(a,"anime","Animes"));
        tab(a,row,"GAMES",active,()->open(a,GamesActivity.class));
        tab(a,row,"EXPLORAR",active,()->discover(a,"explore","Explorar"));

        row.addView(new View(a),new LinearLayout.LayoutParams(0,1,1));
        TextView search=Ui.ghostButton(a,"⌕");
        search.setContentDescription("Buscar");
        search.setOnClickListener(v->open(a,SearchActivity.class));
        row.addView(search,new LinearLayout.LayoutParams(Ui.dp(a,40),Ui.dp(a,38)));
        TextView profile=Ui.ghostButton(a,"♙");
        profile.setContentDescription("Minha conta");
        profile.setOnClickListener(v->open(a,ProfileActivity.class));
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(Ui.dp(a,40),Ui.dp(a,38));pp.leftMargin=Ui.dp(a,5);row.addView(profile,pp);
        return row;
    }

    private static void tab(Activity a,LinearLayout row,String label,String active,Runnable run){
        boolean sel=label.equalsIgnoreCase(active==null?"":active);
        TextView v=Ui.nav(a,label,sel);
        v.setTextSize(Ui.phone(a)?8:10);
        v.setOnClickListener(x->run.run());
        int w;
        if("DESTAQUES".equals(label)||"EXPLORAR".equals(label)) w=Ui.phone(a)?72:88;
        else w=Ui.phone(a)?58:72;
        row.addView(v,new LinearLayout.LayoutParams(Ui.dp(a,w),Ui.dp(a,44)));
    }

    private static void open(Activity a,Class<?> c){a.startActivity(new Intent(a,c));}
    private static void catalog(Activity a,String type,String title,String smart){Intent i=new Intent(a,CatalogActivity.class);i.putExtra("type",type);i.putExtra("title",title);i.putExtra("smart",smart);a.startActivity(i);}
    private static void discover(Activity a,String smart,String title){Intent i=new Intent(a,DiscoverActivity.class);i.putExtra("smart",smart);i.putExtra("title",title);a.startActivity(i);}
}
