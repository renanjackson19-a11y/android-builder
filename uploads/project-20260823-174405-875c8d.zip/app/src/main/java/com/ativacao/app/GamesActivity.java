package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class GamesActivity extends Activity {
    private boolean phone;
    private GridView grid;
    private TextView status,title;
    private final List<OpenGameCatalog.Game> games=new ArrayList<>();
    private GameAdapter adapter;
    private String mode="retro";

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        Ui.immersive(this);
        phone=Ui.phone(this);
        mode=getIntent().getStringExtra("mode");
        if(mode==null||mode.isEmpty())mode="retro";
        setContentView(build());
        load();
    }

    private View build(){
        LinearLayout root=Ui.column(this);
        root.setBackgroundColor(Ui.BG);
        root.addView(YellowNav.bar(this,"GAMES"),new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?56:64)));

        LinearLayout body=Ui.column(this);
        body.setPadding(Ui.dp(this,phone?14:24),Ui.dp(this,12),Ui.dp(this,phone?14:24),Ui.dp(this,14));

        LinearLayout tabs=new LinearLayout(this);
        tabs.setGravity(Gravity.CENTER_VERTICAL);
        tabs.addView(tab("JOGOS RETRÔ","retro"),new LinearLayout.LayoutParams(Ui.dp(this,phone?145:185),Ui.dp(this,44)));
        LinearLayout.LayoutParams p2=new LinearLayout.LayoutParams(Ui.dp(this,phone?125:160),Ui.dp(this,44));p2.leftMargin=Ui.dp(this,8);
        tabs.addView(tab("PS2","ps2"),p2);
        LinearLayout.LayoutParams p3=new LinearLayout.LayoutParams(Ui.dp(this,phone?125:160),Ui.dp(this,44));p3.leftMargin=Ui.dp(this,8);
        tabs.addView(tab("NINTENDO DS","ds"),p3);
        LinearLayout.LayoutParams p4=new LinearLayout.LayoutParams(Ui.dp(this,phone?125:160),Ui.dp(this,44));p4.leftMargin=Ui.dp(this,8);
        tabs.addView(tab("3DS","3ds"),p4);
        LinearLayout.LayoutParams p5=new LinearLayout.LayoutParams(Ui.dp(this,phone?125:160),Ui.dp(this,44));p5.leftMargin=Ui.dp(this,8);
        tabs.addView(tab("FUTEBOL","football"),p5);
        body.addView(tabs,new LinearLayout.LayoutParams(-1,Ui.dp(this,48)));

        title=Ui.text(this,"JOGOS RETRÔ",phone?21:28,Ui.TEXT,true);
        body.addView(title,new LinearLayout.LayoutParams(-1,Ui.dp(this,44)));
        status=Ui.text(this,"Carregando catálogo aberto...",10,Ui.MUTED,false);
        body.addView(status,new LinearLayout.LayoutParams(-1,Ui.dp(this,28)));

        grid=new GridView(this);
        grid.setNumColumns(phone?3:5);
        grid.setHorizontalSpacing(Ui.dp(this,10));
        grid.setVerticalSpacing(Ui.dp(this,10));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setSelector(android.R.color.transparent);
        adapter=new GameAdapter();
        grid.setAdapter(adapter);
        body.addView(grid,new LinearLayout.LayoutParams(-1,0,1));

        root.addView(Ui.centered(this,body,1380),new LinearLayout.LayoutParams(-1,0,1));
        return root;
    }

    private TextView tab(String label,String target){
        TextView v=Ui.button(this,label);
        v.setOnClickListener(x->{
            if("football".equals(target)){startActivity(new Intent(this,FootballActivity.class));return;}
            mode=target;load();
        });
        return v;
    }

    private void load(){
        title.setText("retro".equals(mode)?"JOGOS RETRÔ":mode.toUpperCase());
        status.setText("Carregando catálogo aberto • "+mode.toUpperCase());
        OpenGameCatalog.load(mode,new OpenGameCatalog.Callback(){
            public void ok(List<OpenGameCatalog.Game> data){
                runOnUiThread(()->{
                    games.clear();games.addAll(data);adapter.notifyDataSetChanged();
                    status.setText(games.isEmpty()?"Catálogo sem itens nesta plataforma.":games.size()+" jogos encontrados • catálogo aberto");
                    if(!games.isEmpty())grid.requestFocus();
                });
            }
            public void error(String msg){runOnUiThread(()->status.setText("Não foi possível carregar • "+msg));}
        });
    }

    private class GameAdapter extends BaseAdapter{
        public int getCount(){return games.size();}
        public Object getItem(int p){return games.get(p);}
        public long getItemId(int p){return p;}
        public View getView(int p,View cv,android.view.ViewGroup parent){
            LinearLayout card;
            TextView name,meta;
            if(cv==null){
                card=Ui.column(GamesActivity.this);
                card.setPadding(Ui.dp(GamesActivity.this,12),Ui.dp(GamesActivity.this,12),Ui.dp(GamesActivity.this,12),Ui.dp(GamesActivity.this,10));
                Ui.focus(card,GamesActivity.this);
                card.setFocusable(true);
                name=Ui.text(GamesActivity.this,"",phone?11:13,Color.WHITE,true);name.setId(801);name.setMaxLines(2);
                card.addView(name,new LinearLayout.LayoutParams(-1,0,1));
                meta=Ui.text(GamesActivity.this,"",9,Ui.GREEN,true);meta.setId(802);
                card.addView(meta,new LinearLayout.LayoutParams(-1,Ui.dp(GamesActivity.this,26)));
                cv=card;
            }else card=(LinearLayout)cv;
            name=cv.findViewById(801);meta=cv.findViewById(802);
            OpenGameCatalog.Game g=games.get(p);
            name.setText(g.name);meta.setText(g.platform+(g.year.isEmpty()?"":" • "+g.year));
            card.setOnClickListener(v->status.setText(g.name+" • metadados do catálogo aberto"));
            return cv;
        }
    }

    @Override protected void onResume(){super.onResume();Ui.immersive(this);}
}
