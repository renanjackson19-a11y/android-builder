package com.spotnet.music;
import android.content.*;import android.os.*;import android.provider.Settings;import android.view.*;import android.widget.*;import android.text.InputType;import androidx.appcompat.app.AppCompatActivity;import com.bumptech.glide.Glide;import org.json.JSONObject;import java.net.URLEncoder;
public class LoginActivity extends AppCompatActivity{
 protected void onCreate(Bundle b){super.onCreate(b);if(getSharedPreferences("auth",MODE_PRIVATE).getBoolean("ok",false)){open();return;}setContentView(R.layout.activity_login);loadBrand();EditText u=findViewById(R.id.user),p=findViewById(R.id.pass);TextView s=findViewById(R.id.status);Button bt=findViewById(R.id.loginBtn); View overlay=findViewById(R.id.accessOverlay); TextView accessTitle=findViewById(R.id.accessTitle), accessMessage=findViewById(R.id.accessMessage);
  findViewById(R.id.socialDivider).setVisibility(View.VISIBLE);findViewById(R.id.socialButtons).setVisibility(View.VISIBLE);findViewById(R.id.googleLogin).setVisibility(View.VISIBLE);findViewById(R.id.appleLogin).setVisibility(View.GONE);findViewById(R.id.googleLogin).setOnClickListener(v->openGoogle());findViewById(R.id.createAccount).setOnClickListener(v->showRegister());findViewById(R.id.forgotPassword).setOnClickListener(v->showForgot());
  p.setCompoundDrawablePadding(14);p.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_UP&&p.getCompoundDrawables()[2]!=null&&e.getX()>=p.getWidth()-p.getPaddingEnd()-p.getCompoundDrawables()[2].getBounds().width()){int pos=p.getSelectionStart();boolean visible=(p.getInputType()&InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD)!=0;p.setInputType(InputType.TYPE_CLASS_TEXT|(visible?InputType.TYPE_TEXT_VARIATION_PASSWORD:InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD));p.setSelection(Math.max(0,pos));return true;}return false;});
  bt.setOnClickListener(v->{String username=u.getText().toString().trim();String password=p.getText().toString();if(username.isEmpty()||password.isEmpty()){s.setText("Informe usuário e senha.");return;}bt.setEnabled(false);s.setText("");overlay.setVisibility(View.VISIBLE);accessTitle.setText("Liberando seu acesso…");accessMessage.setText("Validando sua assinatura com segurança");new Thread(()->{try{String d=Settings.Secure.getString(getContentResolver(),Settings.Secure.ANDROID_ID);String body="user="+URLEncoder.encode(username,"UTF-8")+"&pass="+URLEncoder.encode(password,"UTF-8")+"&device="+URLEncoder.encode(d,"UTF-8");JSONObject j=new JSONObject(Net.post(BuildConfig.PANEL_URL+"/api/login.php",body));if(j.optBoolean("ok")){getSharedPreferences("auth",MODE_PRIVATE).edit().putBoolean("ok",true).putString("user",username).putString("device",d).putString("token",j.optString("token","")).apply();runOnUiThread(()->{accessTitle.setText("Acesso liberado!");accessMessage.setText("Tudo pronto. Bem-vindo à Spotnet Music.");new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(this::open,550);});}else runOnUiThread(()->{overlay.setVisibility(View.GONE);s.setText(j.optString("message","Acesso negado"));bt.setEnabled(true);});}catch(Exception e){runOnUiThread(()->{overlay.setVisibility(View.GONE);s.setText("Não foi possível conectar. Tente novamente.");bt.setEnabled(true);});}}).start();});}
 void showRegister(){
  View v=getLayoutInflater().inflate(R.layout.dialog_register,null);
  EditText name=v.findViewById(R.id.regName),email=v.findViewById(R.id.regEmail),user=v.findViewById(R.id.regUser),pass=v.findViewById(R.id.regPass),ref=v.findViewById(R.id.regRef);
  TextView error=v.findViewById(R.id.regError); Button cancel=v.findViewById(R.id.regCancel),submit=v.findViewById(R.id.regSubmit);
  androidx.appcompat.app.AlertDialog dlg=new androidx.appcompat.app.AlertDialog.Builder(this).setView(v).create();
  if(dlg.getWindow()!=null)dlg.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
  pass.setOnTouchListener((x,e)->{if(e.getAction()==MotionEvent.ACTION_UP&&pass.getCompoundDrawables()[2]!=null&&e.getX()>=pass.getWidth()-pass.getPaddingEnd()-pass.getCompoundDrawables()[2].getBounds().width()){boolean vis=(pass.getInputType()&InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD)!=0;int pos=pass.getSelectionStart();pass.setInputType(InputType.TYPE_CLASS_TEXT|(vis?InputType.TYPE_TEXT_VARIATION_PASSWORD:InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD));pass.setSelection(Math.max(0,pos));return true;}return false;});
  cancel.setOnClickListener(x->dlg.dismiss());
  submit.setOnClickListener(x->{String n=name.getText().toString().trim(),em=email.getText().toString().trim(),us=user.getText().toString().trim(),pw=pass.getText().toString();if(n.length()<3||!android.util.Patterns.EMAIL_ADDRESS.matcher(em).matches()||us.length()<4||pw.length()<6){error.setVisibility(View.VISIBLE);error.setText("Preencha nome, e-mail válido, usuário com 4 caracteres e senha com 6 ou mais.");return;}error.setVisibility(View.GONE);submit.setEnabled(false);submit.setText("Enviando...");postRegister(name,email,user,pass,ref,dlg,submit,error);});
  dlg.show(); if(dlg.getWindow()!=null){dlg.getWindow().setBackgroundDrawableResource(android.R.color.transparent);dlg.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels*.92f),WindowManager.LayoutParams.WRAP_CONTENT);}
 }
 EditText f(String hint,boolean password){EditText e=new EditText(this);e.setHint(hint);e.setSingleLine(true);if(password)e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);return e;}
 void postRegister(EditText name,EditText email,EditText user,EditText pass,EditText ref,androidx.appcompat.app.AlertDialog dlg,Button submit,TextView error){new Thread(()->{try{String body="name="+URLEncoder.encode(name.getText().toString().trim(),"UTF-8")+"&email="+URLEncoder.encode(email.getText().toString().trim(),"UTF-8")+"&user="+URLEncoder.encode(user.getText().toString().trim(),"UTF-8")+"&pass="+URLEncoder.encode(pass.getText().toString(),"UTF-8")+"&ref="+URLEncoder.encode(ref.getText().toString().trim(),"UTF-8");JSONObject j=new JSONObject(Net.post(BuildConfig.PANEL_URL+"/api/register.php",body));runOnUiThread(()->{if(j.optBoolean("ok")){dlg.dismiss();new androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Cadastro recebido").setMessage(j.optString("message","Conta criada. Aguarde a liberação do acesso.")).setPositiveButton("Entendi",null).show();}else{error.setVisibility(View.VISIBLE);error.setText(j.optString("message","Não foi possível cadastrar."));submit.setEnabled(true);submit.setText("Criar conta");}});}catch(Exception e){runOnUiThread(()->{error.setVisibility(View.VISIBLE);error.setText("Falha de conexão. Tente novamente.");submit.setEnabled(true);submit.setText("Criar conta");});}}).start();}
 void showForgot(){
  View v=getLayoutInflater().inflate(R.layout.dialog_forgot,null); EditText id=v.findViewById(R.id.forgotLogin);TextView error=v.findViewById(R.id.forgotError);Button cancel=v.findViewById(R.id.forgotCancel),submit=v.findViewById(R.id.forgotSubmit);
  androidx.appcompat.app.AlertDialog dlg=new androidx.appcompat.app.AlertDialog.Builder(this).setView(v).create(); cancel.setOnClickListener(x->dlg.dismiss());
  submit.setOnClickListener(x->{String login=id.getText().toString().trim();if(login.length()<3){error.setVisibility(View.VISIBLE);error.setText("Informe seu usuário ou e-mail.");return;}submit.setEnabled(false);submit.setText("Enviando...");new Thread(()->{try{String body="login="+URLEncoder.encode(login,"UTF-8");JSONObject j=new JSONObject(Net.post(BuildConfig.PANEL_URL+"/api/forgot_password.php",body));runOnUiThread(()->{dlg.dismiss();new androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Pedido enviado").setMessage(j.optString("message","O suporte recebeu sua solicitação.")).setPositiveButton("Entendi",null).show();});}catch(Exception e){runOnUiThread(()->{error.setVisibility(View.VISIBLE);error.setText("Falha de conexão. Tente novamente.");submit.setEnabled(true);submit.setText("Enviar pedido");});}}).start();});
  dlg.show();if(dlg.getWindow()!=null){dlg.getWindow().setBackgroundDrawableResource(android.R.color.transparent);dlg.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels*.92f),WindowManager.LayoutParams.WRAP_CONTENT);}
 }

 void openGoogle(){
  try{
   String url=BuildConfig.PANEL_URL+"/auth/google.php?source=android";
   Intent i=new Intent(Intent.ACTION_VIEW,android.net.Uri.parse(url));
   startActivity(i);
  }catch(Exception e){Toast.makeText(this,"Login com Google ainda não configurado no painel.",Toast.LENGTH_LONG).show();}
 }

 void loadBrand(){
  ImageView logo=findViewById(R.id.loginLogo); View fallback=findViewById(R.id.loginBrandFallback);
  android.content.SharedPreferences cache=getSharedPreferences("ui_cache",MODE_PRIVATE);
  String cached=cache.getString("app_logo_url","");
  if(!cached.isEmpty()){Glide.with(this).load(cached).fitCenter().into(logo);fallback.setVisibility(View.GONE);}
  new Thread(()->{try{
    JSONObject r=new JSONObject(Net.getFast(BuildConfig.PANEL_URL+"/api/branding.php?t="+System.currentTimeMillis()));
    JSONObject cfg=r.optJSONObject("branding"); if(cfg==null)return;
    String url=cfg.optString("logo_url",""); String version=cfg.optString("version","0");
    if(!url.isEmpty()) url=url+(url.contains("?")?"&":"?")+"v="+version;
    final String finalUrl=url;
    cache.edit().putString("app_logo_url",finalUrl).putString("branding_version",version).apply();
    runOnUiThread(()->{if(!finalUrl.isEmpty()){Glide.with(this).load(finalUrl).fitCenter().into(logo);fallback.setVisibility(View.GONE);}else{fallback.setVisibility(View.VISIBLE);}});
  }catch(Exception ignored){}}).start();
 }
 void open(){startActivity(new Intent(this,MainActivity.class));finish();}
}