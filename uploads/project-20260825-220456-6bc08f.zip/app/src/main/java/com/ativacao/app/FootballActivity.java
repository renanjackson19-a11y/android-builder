package com.ativacao.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class FootballActivity extends Activity {
    private final List<ApiClient.FootballMatch> matches=new ArrayList<>();
    private final List<ApiClient.FootballMatch> allMatches=new ArrayList<>();
    private final List<TextView> filterButtons=new ArrayList<>();
    private GridView grid;private MatchAdapter adapter;private TextView status;private boolean phone;
    private String loadedDay="";private boolean loadingFootball=false;private String currentFilter="TODOS";

    @Override public void onCreate(Bundle b){super.onCreate(b);immersive();phone=Ui.phone(this);setContentView(build());load();}
    @Override protected void onResume(){super.onResume();immersive();String d=todayKey();if(!d.equals(loadedDay)&&!loadingFootball)load();}
    private String todayKey(){return new java.text.SimpleDateFormat("yyyy-MM-dd",java.util.Locale.US).format(new java.util.Date());}

    private View build(){
        LinearLayout root=Ui.column(this);root.setBackground(Ui.diagonalGradient(0xFF061109,0xFF010302,0,this));
        root.addView(YellowNav.bar(this,"FUTEBOL"),new LinearLayout.LayoutParams(-1,Ui.dp(this,64)));

        LinearLayout content=Ui.column(this);
        content.setPadding(Ui.dp(this,phone?14:24),Ui.dp(this,10),Ui.dp(this,phone?14:24),Ui.dp(this,12));

        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        TextView back=Ui.button(this,"‹  VOLTAR");back.setOnClickListener(v->finish());
        top.addView(back,new LinearLayout.LayoutParams(Ui.dp(this,phone?118:145),Ui.dp(this,44)));

        LinearLayout titleBox=Ui.column(this);
        TextView title=Ui.text(this,"GUIA DE JOGOS",phone?19:25,Ui.TEXT,true);
        TextView sub=Ui.text(this,"Futebol de hoje • horários no seu fuso",10,Ui.MUTED,false);
        titleBox.addView(title,new LinearLayout.LayoutParams(-1,Ui.dp(this,30)));
        titleBox.addView(sub,new LinearLayout.LayoutParams(-1,Ui.dp(this,20)));
        LinearLayout.LayoutParams tbp=new LinearLayout.LayoutParams(0,Ui.dp(this,54),1);tbp.leftMargin=Ui.dp(this,14);top.addView(titleBox,tbp);
        content.addView(top,new LinearLayout.LayoutParams(-1,Ui.dp(this,58)));

        LinearLayout info=new LinearLayout(this);info.setGravity(Gravity.CENTER_VERTICAL);
        status=Ui.text(this,"Carregando jogos...",11,Ui.MUTED,false);
        info.addView(status,new LinearLayout.LayoutParams(0,Ui.dp(this,30),1));
        TextView hint=Ui.text(this,"OK: detalhes  •  VOLTAR: menu",9,0xFF7F8A83,false);hint.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        info.addView(hint,new LinearLayout.LayoutParams(Ui.dp(this,phone?190:300),Ui.dp(this,30)));
        content.addView(info,new LinearLayout.LayoutParams(-1,Ui.dp(this,34)));

        LinearLayout filters=new LinearLayout(this);filters.setGravity(Gravity.CENTER_VERTICAL);
        String[] fs={"TODOS","AO VIVO","PRÓXIMOS","ENCERRADOS"};
        for(int i=0;i<fs.length;i++){
            final String filterName=fs[i];
            TextView f=Ui.text(this,filterName,10,i==0?Color.BLACK:Ui.TEXT,true);f.setGravity(Gravity.CENTER);
            f.setFocusable(true);f.setClickable(true);
            f.setBackground(i==0?Ui.round(Ui.GREEN,18,this):Ui.stroke(0xFF111713,0xFF263229,18,this));
            f.setOnClickListener(v->applyFilter(filterName,true));
            filterButtons.add(f);
            LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(Ui.dp(this,phone?90:125),Ui.dp(this,34));if(i>0)fp.leftMargin=Ui.dp(this,8);filters.addView(f,fp);
        }
        TextView date=Ui.text(this,new java.text.SimpleDateFormat("dd MMM yyyy",new Locale("pt","BR")).format(new java.util.Date()).toUpperCase(Locale.ROOT),10,Ui.GREEN,true);
        date.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);filters.addView(date,new LinearLayout.LayoutParams(0,Ui.dp(this,34),1));
        LinearLayout.LayoutParams flp=new LinearLayout.LayoutParams(-1,Ui.dp(this,42));flp.bottomMargin=Ui.dp(this,6);content.addView(filters,flp);

        grid=new GridView(this);grid.setNumColumns(1);grid.setHorizontalSpacing(0);grid.setVerticalSpacing(Ui.dp(this,7));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);grid.setSelector(android.R.color.transparent);
        adapter=new MatchAdapter();grid.setAdapter(adapter);
        content.addView(grid,new LinearLayout.LayoutParams(-1,0,1));

        FrameLayout centered=Ui.centered(this,content,1450);root.addView(centered,new LinearLayout.LayoutParams(-1,-1));
        back.requestFocus();return root;
    }

    private void load(){
        if(loadingFootball)return;loadingFootball=true;loadedDay=todayKey();status.setText("Atualizando guia de jogos...");
        FreeFootballSource.load(new ApiClient.Callback<List<ApiClient.FootballMatch>>(){
            public void ok(List<ApiClient.FootballMatch> d){
                if(d==null||d.isEmpty()){loadPanelFallback();return;}
                runOnUiThread(()->{loadingFootball=false;allMatches.clear();allMatches.addAll(d);applyFilter(currentFilter,false);if(!matches.isEmpty())grid.requestFocus();});
            }
            public void error(String m){loadPanelFallback();}
        });
    }

    private void loadPanelFallback(){
        status.setText("Buscando programação alternativa...");
        ApiClient.football(new ApiClient.Callback<List<ApiClient.FootballMatch>>(){
            public void ok(List<ApiClient.FootballMatch> d){runOnUiThread(()->{loadingFootball=false;allMatches.clear();if(d!=null)allMatches.addAll(d);applyFilter(currentFilter,false);if(!matches.isEmpty())grid.requestFocus();});}
            public void error(String m){runOnUiThread(()->{loadingFootball=false;allMatches.clear();matches.clear();adapter.notifyDataSetChanged();status.setText("Nenhuma partida programada para hoje.");});}
        });
    }


    private void applyFilter(String filter,boolean moveFocus){
        currentFilter=filter==null?"TODOS":filter;
        matches.clear();
        for(ApiClient.FootballMatch m:allMatches){
            if(matchesFilter(m,currentFilter))matches.add(m);
        }
        if(adapter!=null)adapter.notifyDataSetChanged();
        updateFilterButtons();
        if(allMatches.isEmpty()){
            status.setText("Nenhuma partida programada para hoje.");
        }else if("TODOS".equals(currentFilter)){
            status.setText(allMatches.size()+" jogos hoje • atualizado automaticamente");
        }else{
            status.setText(allMatches.size()+" jogos hoje • "+matches.size()+" em "+currentFilter.toLowerCase(new Locale("pt","BR")));
        }
        if(moveFocus){
            if(!matches.isEmpty())grid.requestFocus();
            else status.announceForAccessibility("Nenhum jogo neste filtro");
        }
    }

    private boolean matchesFilter(ApiClient.FootballMatch m,String filter){
        if("TODOS".equals(filter))return true;
        String x=m==null||m.status==null?"":m.status.toLowerCase(Locale.ROOT);
        if("AO VIVO".equals(filter))return x.contains("live")||x.contains("progress")||x.equals("in")||x.contains("half")||x.contains("interval");
        if("PRÓXIMOS".equals(filter))return x.contains("scheduled")||x.equals("pre")||x.contains("not started")||x.contains("fixture")||x.contains("upcoming")||x.contains("agend");
        if("ENCERRADOS".equals(filter))return x.contains("final")||x.contains("ended")||x.contains("full time")||x.equals("ft")||x.contains("finish")||x.contains("encerr");
        return true;
    }

    private void updateFilterButtons(){
        for(TextView b:filterButtons){
            boolean selected=b.getText().toString().equals(currentFilter);
            b.setTextColor(selected?Color.BLACK:Ui.TEXT);
            b.setBackground(selected?Ui.round(Ui.GREEN,18,this):Ui.stroke(0xFF111713,0xFF263229,18,this));
        }
    }

    private class MatchAdapter extends BaseAdapter{
        public int getCount(){return matches.size();}public Object getItem(int p){return matches.get(p);}public long getItemId(int p){return p;}

        public View getView(int p,View convert,android.view.ViewGroup parent){
            LinearLayout card;ImageView leagueLogo,hLogo,aLogo;TextView league,home,away,score,time,state,channel;
            if(convert==null){
                card=new LinearLayout(FootballActivity.this);card.setGravity(Gravity.CENTER_VERTICAL);card.setOrientation(LinearLayout.HORIZONTAL);
                card.setPadding(Ui.dp(FootballActivity.this,18),Ui.dp(FootballActivity.this,10),Ui.dp(FootballActivity.this,18),Ui.dp(FootballActivity.this,10));
                Ui.focus(card,FootballActivity.this,Ui.stroke(0xFF111713,0xFF233128,12,FootballActivity.this),Ui.stroke(0xFF142219,Ui.GREEN,12,FootballActivity.this));
                card.setFocusable(true);card.setClickable(true);

                LinearLayout comp=Ui.column(FootballActivity.this);comp.setGravity(Gravity.CENTER_VERTICAL);
                leagueLogo=new ImageView(FootballActivity.this);leagueLogo.setId(501);leagueLogo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                comp.addView(leagueLogo,new LinearLayout.LayoutParams(Ui.dp(FootballActivity.this,48),Ui.dp(FootballActivity.this,42)));
                league=Ui.text(FootballActivity.this,"",9,Ui.GREEN,true);league.setId(502);league.setMaxLines(2);league.setGravity(Gravity.CENTER_VERTICAL);
                comp.addView(league,new LinearLayout.LayoutParams(-1,Ui.dp(FootballActivity.this,34)));
                card.addView(comp,new LinearLayout.LayoutParams(Ui.dp(FootballActivity.this,phone?150:190),Ui.dp(FootballActivity.this,82)));

                LinearLayout homeBox=new LinearLayout(FootballActivity.this);homeBox.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
                home=Ui.text(FootballActivity.this,"",12,Ui.TEXT,true);home.setId(503);home.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);home.setMaxLines(2);
                homeBox.addView(home,new LinearLayout.LayoutParams(0,Ui.dp(FootballActivity.this,64),1));
                hLogo=new ImageView(FootballActivity.this);hLogo.setId(504);hLogo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                LinearLayout.LayoutParams hlp=new LinearLayout.LayoutParams(Ui.dp(FootballActivity.this,58),Ui.dp(FootballActivity.this,58));hlp.leftMargin=Ui.dp(FootballActivity.this,10);homeBox.addView(hLogo,hlp);
                card.addView(homeBox,new LinearLayout.LayoutParams(0,Ui.dp(FootballActivity.this,76),1));

                LinearLayout center=Ui.column(FootballActivity.this);center.setGravity(Gravity.CENTER);
                time=Ui.text(FootballActivity.this,"",19,Ui.TEXT,true);time.setId(505);time.setGravity(Gravity.CENTER);center.addView(time,new LinearLayout.LayoutParams(-1,Ui.dp(FootballActivity.this,26)));
                score=Ui.text(FootballActivity.this,"",16,Ui.TEXT,true);score.setId(506);score.setGravity(Gravity.CENTER);center.addView(score,new LinearLayout.LayoutParams(-1,Ui.dp(FootballActivity.this,22)));
                state=Ui.text(FootballActivity.this,"",9,Ui.GREEN,true);state.setBackground(Ui.stroke(0x1600FF66,0xFF235B35,12,FootballActivity.this));state.setId(507);state.setGravity(Gravity.CENTER);center.addView(state,new LinearLayout.LayoutParams(-1,Ui.dp(FootballActivity.this,20)));
                card.addView(center,new LinearLayout.LayoutParams(Ui.dp(FootballActivity.this,phone?95:125),Ui.dp(FootballActivity.this,76)));

                LinearLayout awayBox=new LinearLayout(FootballActivity.this);awayBox.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
                aLogo=new ImageView(FootballActivity.this);aLogo.setId(508);aLogo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                awayBox.addView(aLogo,new LinearLayout.LayoutParams(Ui.dp(FootballActivity.this,58),Ui.dp(FootballActivity.this,58)));
                away=Ui.text(FootballActivity.this,"",12,Ui.TEXT,true);away.setId(509);away.setMaxLines(2);
                LinearLayout.LayoutParams alp=new LinearLayout.LayoutParams(0,Ui.dp(FootballActivity.this,64),1);alp.leftMargin=Ui.dp(FootballActivity.this,10);awayBox.addView(away,alp);
                card.addView(awayBox,new LinearLayout.LayoutParams(0,Ui.dp(FootballActivity.this,76),1));

                channel=Ui.text(FootballActivity.this,"",9,Ui.GREEN,true);channel.setId(510);channel.setGravity(Gravity.CENTER);channel.setPadding(Ui.dp(FootballActivity.this,8),0,Ui.dp(FootballActivity.this,8),0);
                channel.setBackground(Ui.stroke(0x1600FF66,Ui.GREEN,18,FootballActivity.this));
                LinearLayout.LayoutParams clp=new LinearLayout.LayoutParams(Ui.dp(FootballActivity.this,phone?130:185),Ui.dp(FootballActivity.this,34));clp.leftMargin=Ui.dp(FootballActivity.this,10);card.addView(channel,clp);

                convert=card;
            } else card=(LinearLayout)convert;

            leagueLogo=convert.findViewById(501);league=convert.findViewById(502);home=convert.findViewById(503);hLogo=convert.findViewById(504);time=convert.findViewById(505);score=convert.findViewById(506);state=convert.findViewById(507);aLogo=convert.findViewById(508);away=convert.findViewById(509);channel=convert.findViewById(510);
            ApiClient.FootballMatch m=matches.get(p);
            league.setText(cleanLeague(m.league));home.setText(m.home);away.setText(m.away);
            time.setText(m.clock==null||m.clock.isEmpty()?"--:--":m.clock);
            score.setText(m.score==null||m.score.isEmpty()?"×":m.score);
            state.setText(ptStatus(m.status));
            if(m.channel!=null&&!m.channel.trim().isEmpty()){channel.setVisibility(View.VISIBLE);channel.setText("CANAL: "+m.channel);}else{channel.setVisibility(View.INVISIBLE);channel.setText("");}
            ImageLoader.into(FootballActivity.this,hLogo,m.homeLogo);ImageLoader.into(FootballActivity.this,aLogo,m.awayLogo);
            if(m.leagueLogo!=null&&!m.leagueLogo.trim().isEmpty()){leagueLogo.setVisibility(View.VISIBLE);ImageLoader.into(FootballActivity.this,leagueLogo,m.leagueLogo);}else leagueLogo.setVisibility(View.INVISIBLE);
            return convert;
        }
    }

    private String ptStatus(String s){
        if(s==null)return "Agendado";String x=s.toLowerCase(Locale.ROOT);
        if(x.contains("scheduled")||x.equals("pre")||x.contains("not started"))return "Agendado";
        if(x.contains("live")||x.contains("progress"))return "AO VIVO";
        if(x.contains("half"))return "Intervalo";
        if(x.contains("final")||x.contains("ended")||x.contains("full time"))return "Encerrado";
        if(x.contains("postpon"))return "Adiado";if(x.contains("cancel"))return "Cancelado";if(x.contains("suspend"))return "Suspenso";
        return s;
    }

    private String cleanLeague(String s){
        if(s==null)return "Futebol";
        if(s.equalsIgnoreCase("German Cup"))return "Copa da Alemanha";
        if(s.equalsIgnoreCase("English Premier League"))return "Premier League";
        if(s.equalsIgnoreCase("Spanish LALIGA"))return "LaLiga";
        return s;
    }

    private void immersive(){getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);}
}
