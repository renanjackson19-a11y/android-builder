package com.ativacao.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class GameDetailActivity extends Activity {
    @Override public void onCreate(Bundle b){
        super.onCreate(b); Ui.immersive(this);
        LinearLayout root=Ui.column(this); root.setBackgroundColor(Ui.BG);
        root.addView(YellowNav.bar(this,"GAMES"),new LinearLayout.LayoutParams(-1,Ui.dp(this,64)));

        LinearLayout body=new LinearLayout(this);
        body.setPadding(Ui.dp(this,34),Ui.dp(this,24),Ui.dp(this,34),Ui.dp(this,28));
        body.setGravity(Gravity.CENTER_VERTICAL);

        ImageView cover=new ImageView(this); cover.setScaleType(ImageView.ScaleType.CENTER_CROP);
        String res=getIntent().getStringExtra("cover_res");
        int rid=getResources().getIdentifier(res,"drawable",getPackageName());
        if(rid!=0) cover.setImageResource(rid);
        body.addView(cover,new LinearLayout.LayoutParams(Ui.dp(this,300),Ui.dp(this,400)));

        LinearLayout info=Ui.column(this); info.setPadding(Ui.dp(this,30),Ui.dp(this,18),0,0);
        TextView badge=Ui.text(this,getIntent().getStringExtra("platform"),12,Ui.GREEN,true);
        info.addView(badge,new LinearLayout.LayoutParams(-1,Ui.dp(this,34)));
        TextView title=Ui.text(this,getIntent().getStringExtra("name"),28,Color.WHITE,true);
        title.setMaxLines(3); info.addView(title,new LinearLayout.LayoutParams(-1,0,1));
        TextView desc=Ui.text(this,getIntent().getStringExtra("synopsis"),13,Ui.MUTED,false);
        desc.setMaxLines(5); info.addView(desc,new LinearLayout.LayoutParams(-1,Ui.dp(this,120)));
        TextView note=Ui.text(this,"Catálogo de jogos • ROM não incluída",11,Ui.GREEN,true);
        info.addView(note,new LinearLayout.LayoutParams(-1,Ui.dp(this,34)));
        TextView back=Ui.button(this,"‹ VOLTAR"); back.setOnClickListener(v->finish());
        info.addView(back,new LinearLayout.LayoutParams(Ui.dp(this,170),Ui.dp(this,44)));

        body.addView(info,new LinearLayout.LayoutParams(0,-1,1));
        root.addView(Ui.centered(this,body,1220),new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
        back.requestFocus();
    }
    @Override protected void onResume(){super.onResume();Ui.immersive(this);}
}
