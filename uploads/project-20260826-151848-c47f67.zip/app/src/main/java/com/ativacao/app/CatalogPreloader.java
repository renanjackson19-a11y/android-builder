package com.ativacao.app;

import android.app.Activity;
import android.content.Context;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Faz a preparação inicial uma única vez por cliente/token.
 * A interface só abre depois que TV, Filmes e Séries possuem a primeira página salva.
 */
final class CatalogPreloader {
    private static final String PREF="dubai_content_preload";
    private static final int CACHE_SCHEMA=3;
    private static volatile boolean running=false;
    private static volatile boolean ready=false;

    interface Progress { void onProgress(String text,int done,int total); }

    static void init(Context c){
        if(c==null)return;
        ready=c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getBoolean(key(Session.token(c)),false);
    }
    static boolean isReady(){ return ready; }
    static boolean isPrepared(Context c){
        if(c==null)return ready;
        return c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getBoolean(key(Session.token(c)),false);
    }
    private static String key(String token){ return "ready_v"+CACHE_SCHEMA+"_"+Integer.toHexString((token==null?"":token).hashCode()); }
    private static void markReady(Context c,boolean value){
        if(c==null)return;
        c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putBoolean(key(Session.token(c)),value).apply();
        ready=value;
    }

    static void start(Activity a, boolean force, Runnable done){ start(a,force,null,done); }

    static void start(Activity a, boolean force, Progress progress, Runnable done){
        if(a==null){ if(done!=null)done.run(); return; }
        if(!force && isPrepared(a)){ ready=true; if(done!=null)done.run(); return; }
        if(running) return;
        running=true;
        // Uma versão nova da carga inicial nunca reaproveita cache antigo/vazio.
        // Isso evita marcar Filmes/TV/Séries como prontos sem itens.
        ApiClient.clearCatalogCache();
        markReady(a,false);

        final boolean phone=Ui.phone(a);
        final int liveLimit=72;
        final int movieLimit=72;
        final int seriesLimit=60;
        final int total=7;
        final AtomicInteger pending=new AtomicInteger(total);
        final AtomicInteger doneCount=new AtomicInteger(0);
        final AtomicInteger primaryFailures=new AtomicInteger(0);

        notify(progress,"Preparando TV ao vivo...",0,total);
        preloadPrimary(a,"live",liveLimit,"TV ao vivo",pending,doneCount,total,primaryFailures,progress,done);
        preloadPrimary(a,"movie",movieLimit,"Filmes",pending,doneCount,total,primaryFailures,progress,done);
        preloadPrimary(a,"series",seriesLimit,"Séries",pending,doneCount,total,primaryFailures,progress,done);

        ApiClient.categories("movie",new ApiClient.Callback<List<String>>(){
            public void ok(List<String>x){finishOne(a,"Categorias de filmes",pending,doneCount,total,primaryFailures,progress,done);}
            public void error(String m){finishOne(a,"Categorias de filmes",pending,doneCount,total,primaryFailures,progress,done);}
        });
        ApiClient.categories("series",new ApiClient.Callback<List<String>>(){
            public void ok(List<String>x){finishOne(a,"Categorias de séries",pending,doneCount,total,primaryFailures,progress,done);}
            public void error(String m){finishOne(a,"Categorias de séries",pending,doneCount,total,primaryFailures,progress,done);}
        });
        ApiClient.hotCategories(new ApiClient.Callback<List<ApiClient.HotCategory>>(){
            public void ok(List<ApiClient.HotCategory>x){finishOne(a,"HOT +18",pending,doneCount,total,primaryFailures,progress,done);}
            public void error(String m){finishOne(a,"HOT +18",pending,doneCount,total,primaryFailures,progress,done);}
        });
        // Pré-carrega as principais artes sem alterar a arte depois que o card já apareceu.
        ApiClient.catalog("movie",1,movieLimit,"","","launch",new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){warmImages(a,p);finishOne(a,"Capas",pending,doneCount,total,primaryFailures,progress,done);}
            public void error(String m){finishOne(a,"Capas",pending,doneCount,total,primaryFailures,progress,done);}
        });
    }

    private static void preloadPrimary(Activity a,String type,int limit,String label,
                                       AtomicInteger pending,AtomicInteger doneCount,int total,
                                       AtomicInteger failures,Progress progress,Runnable done){
        ApiClient.catalog(type,1,limit,"","","",new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){
                if(valid(p)){ warmImages(a,p); finishOne(a,label,pending,doneCount,total,failures,progress,done); return; }
                retryFresh(a,type,limit,label,pending,doneCount,total,failures,progress,done);
            }
            public void error(String first){ retryFresh(a,type,limit,label,pending,doneCount,total,failures,progress,done); }
        });
    }

    private static boolean valid(ApiClient.CatalogPage p){ return p!=null && (p.total>0 || !p.items.isEmpty()); }

    private static void retryFresh(Activity a,String type,int limit,String label,
                                   AtomicInteger pending,AtomicInteger doneCount,int total,AtomicInteger failures,
                                   Progress progress,Runnable done){
        ApiClient.invalidateCatalog(type,1,limit,"","","");
        ApiClient.catalog(type,1,limit,"","","",new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){
                if(valid(p)){ warmImages(a,p); finishOne(a,label,pending,doneCount,total,failures,progress,done); }
                else { failures.incrementAndGet(); finishOne(a,label,pending,doneCount,total,failures,progress,done); }
            }
            public void error(String m){ failures.incrementAndGet(); finishOne(a,label,pending,doneCount,total,failures,progress,done); }
        });
    }

    private static void finishOne(Activity a,String label,AtomicInteger pending,AtomicInteger doneCount,int total,
                                  AtomicInteger failures,Progress progress,Runnable done){
        int d=doneCount.incrementAndGet();
        notify(progress,"Atualizando "+label+"...",d,total);
        if(pending.decrementAndGet()!=0)return;
        running=false;
        boolean ok=failures.get()==0;
        markReady(a,ok);
        notify(progress,ok?"Conteúdo pronto":"Conteúdo parcialmente atualizado",total,total);
        if(done!=null)done.run();
        if(ok) backgroundWarm(a);
    }

    private static void notify(Progress p,String text,int done,int total){ if(p!=null) p.onProgress(text,done,total); }

    private static void backgroundWarm(Activity a){
        String[][] jobs={{"movie","kids"},{"series","kids"},{"movie","anime"},{"series","anime"}};
        for(String[] j:jobs){
            int limit="series".equals(j[0])?30:(Ui.phone(a)?36:48);
            ApiClient.catalog(j[0],1,limit,"","",j[1],new ApiClient.Callback<ApiClient.CatalogPage>(){
                public void ok(ApiClient.CatalogPage p){ warmImages(a,p); }
                public void error(String m){}
            });
        }
    }

    private static void warmImages(Activity a,ApiClient.CatalogPage p){
        if(p==null)return;
        int max=Math.min(p.items.size(),24);
        for(int n=0;n<max;n++){
            ApiClient.Item i=p.items.get(n); if(i==null)continue;
            ImageLoader.preload(a,clean(i.logo,i.backdrop));
        }
    }
    private static String clean(String a,String b){ String x=a==null?"":a.trim(); return x.isEmpty()?(b==null?"":b.trim()):x; }
}
