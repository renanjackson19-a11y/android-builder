package com.ativacao.app;

import android.content.Context;
import android.content.SharedPreferences;

final class Session {
    private static final String PREF = "dubai_play_session";
    private static final String LOGGED = "logged";
    private static final String USER = "user";
    private static final String EXPIRES = "expires";
    private static final String ADULT = "adult_access";
    private static final String BOUQUET = "bouquet";
    private static final String USER_TOKEN = "user_token";
    private Session() {}

    static boolean isLogged(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean(LOGGED, false);
    }

    static void save(Context c, String user, String expires) { save(c,user,expires,false,"",""); }

    static void save(Context c, String user, String expires, boolean adultAccess, String bouquet, String userToken) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putBoolean(LOGGED, true)
                .putString(USER, user == null ? "" : user)
                .putString(EXPIRES, expires == null ? "" : expires)
                .putBoolean(ADULT, adultAccess)
                .putString(BOUQUET, bouquet == null ? "" : bouquet)
                .putString(USER_TOKEN, userToken == null ? "" : userToken)
                .apply();
        ApiClient.setUserToken(userToken);
    }

    static String user(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(USER, "");
    }

    static String expires(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(EXPIRES, "");
    }

    static void clear(Context c) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().apply();
    }

    static boolean adultAccess(Context c) { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean(ADULT, false); }
    static String bouquet(Context c) { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(BOUQUET, ""); }
    static String userToken(Context c) { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(USER_TOKEN, ""); }
    static void restoreApiToken(Context c) { ApiClient.setUserToken(userToken(c)); }
}
