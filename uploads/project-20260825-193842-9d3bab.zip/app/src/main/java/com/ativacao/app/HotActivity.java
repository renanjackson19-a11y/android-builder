package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class HotActivity extends Activity {
    private final List<ApiClient.HotCategory> categories = new ArrayList<>();
    private LinearLayout showcase;
    private LinearLayout extraRow;
    private TextView status;
    private boolean phone;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        phone = Ui.phone(this);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        immersive();
        setContentView(build());
        load();
    }

    @Override protected void onResume(){ super.onResume(); immersive(); }

    private View build(){
        LinearLayout root=Ui.column(this);
        root.setBackgroundColor(Color.rgb(3,5,8));

        LinearLayout header=new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(Ui.dp(this,phone?14:22),Ui.dp(this,8),Ui.dp(this,phone?14:22),Ui.dp(this,8));
        header.setBackgroundColor(Color.rgb(4,7,11));

        TextView back=Ui.button(this,"‹  VOLTAR");
        back.setOnClickListener(v->finish());
        header.addView(back,new LinearLayout.LayoutParams(Ui.dp(this,phone?118:138),Ui.dp(this,42)));

        TextView brand=Ui.text(this,"DUBAI PLAY",phone?17:20,Ui.TEXT,true);
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(Ui.dp(this,phone?150:190),Ui.dp(this,42));
        bp.leftMargin=Ui.dp(this,12); header.addView(brand,bp);

        HorizontalScrollView navScroll=new HorizontalScrollView(this);
        navScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout nav=new LinearLayout(this); nav.setGravity(Gravity.CENTER_VERTICAL);
        String[] labels={"AO VIVO","FUTEBOL","FILMES","SÉRIES","KIDS","ANIMES","HOT"};
        for(String label:labels){
            TextView n=nav(label,"HOT".equals(label));
            if("AO VIVO".equals(label))n.setOnClickListener(v->openCatalog("live","Ao Vivo",""));
            else if("FILMES".equals(label))n.setOnClickListener(v->openCatalog("movie","Filmes",""));
            else if("SÉRIES".equals(label))n.setOnClickListener(v->openCatalog("series","Séries",""));
            else if("FUTEBOL".equals(label))n.setOnClickListener(v->startActivity(new Intent(this,FootballActivity.class)));
            else if("KIDS".equals(label))n.setOnClickListener(v->openSmart("movie","Kids","kids"));
            else if("ANIMES".equals(label))n.setOnClickListener(v->openSmart("series","Animes","anime"));
            LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(Ui.dp(this,phone?92:104),Ui.dp(this,40));np.rightMargin=Ui.dp(this,4);nav.addView(n,np);
        }
        navScroll.addView(nav);
        header.addView(navScroll,new LinearLayout.LayoutParams(0,Ui.dp(this,44),1));
        root.addView(header,new LinearLayout.LayoutParams(-1,Ui.dp(this,60)));

        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setClipToPadding(false);
        LinearLayout content=Ui.column(this);int side=phone?14:30;
        content.setPadding(Ui.dp(this,side),Ui.dp(this,18),Ui.dp(this,side),Ui.dp(this,24));

        LinearLayout titleRow=new LinearLayout(this);titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=Ui.text(this,"HOT",phone?24:29,Color.rgb(255,190,35),true);
        titleRow.addView(title,new LinearLayout.LayoutParams(Ui.dp(this,100),Ui.dp(this,40)));
        TextView badge=Ui.text(this,"+18",phone?13:15,Color.WHITE,true);badge.setGravity(Gravity.CENTER);badge.setBackground(Ui.stroke(Color.rgb(28,18,4),Color.rgb(255,181,24),18,this));
        titleRow.addView(badge,new LinearLayout.LayoutParams(Ui.dp(this,62),Ui.dp(this,36)));
        status=Ui.text(this,"Carregando categorias...",11,Ui.MUTED,false);status.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        titleRow.addView(status,new LinearLayout.LayoutParams(0,Ui.dp(this,40),1));
        content.addView(titleRow,new LinearLayout.LayoutParams(-1,Ui.dp(this,48)));

        showcase=new LinearLayout(this);showcase.setOrientation(LinearLayout.HORIZONTAL);showcase.setGravity(Gravity.CENTER_VERTICAL);
        content.addView(showcase,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?310:390)));

        TextView more=Ui.text(this,"Mais conteúdo HOT",phone?17:20,Ui.TEXT,true);
        LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,Ui.dp(this,46));mp.topMargin=Ui.dp(this,12);content.addView(more,mp);
        HorizontalScrollView extras=new HorizontalScrollView(this);extras.setHorizontalScrollBarEnabled(false);
        extraRow=new LinearLayout(this);extraRow.setOrientation(LinearLayout.HORIZONTAL);extras.addView(extraRow);
        content.addView(extras,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?215:245)));

        FrameLayout centered=Ui.centered(this,content,1360);scroll.addView(centered,new ScrollView.LayoutParams(-1,-2));
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        back.requestFocus();
        return root;
    }

    private TextView nav(String label,boolean active){
        int color=active?Color.rgb(255,190,35):Ui.MUTED;
        TextView t=Ui.text(this,label,phone?10:12,color,true);t.setGravity(Gravity.CENTER);t.setFocusable(true);t.setClickable(true);
        if(active) Ui.focus(t,this,Ui.stroke(Color.rgb(17,13,5),Color.rgb(255,181,24),20,this),Ui.stroke(Color.rgb(38,25,5),Color.rgb(255,211,77),20,this));
        else Ui.focus(t,this,Ui.round(Color.TRANSPARENT,10,this),Ui.stroke(Color.rgb(24,24,26),Color.rgb(255,181,24),10,this));
        return t;
    }

    private void load(){
        if(!Session.adultAccess(this)){ status.setText("HOT não liberado para este perfil"); return; }
        ApiClient.hotCategories(new ApiClient.Callback<List<ApiClient.HotCategory>>(){
            public void ok(List<ApiClient.HotCategory> data){ runOnUiThread(()->render(data)); }
            public void error(String m){ runOnUiThread(()->status.setText("Não foi possível carregar • "+m)); }
        });
    }

    private void render(List<ApiClient.HotCategory> data){
        categories.clear();categories.addAll(data);showcase.removeAllViews();extraRow.removeAllViews();
        if(categories.isEmpty()){status.setText("Nenhuma categoria HOT disponível");return;}
        status.setText(categories.size()+" categorias disponíveis");

        ApiClient.HotCategory first=categories.get(0);
        View hero=hotCard(first,true);
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(0,-1,2.0f);hp.rightMargin=Ui.dp(this,8);showcase.addView(hero,hp);

        int rightCount=Math.min(2,Math.max(0,categories.size()-1));
        for(int i=0;i<rightCount;i++){
            View card=hotCard(categories.get(i+1),false);
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,-1,1f);cp.leftMargin=Ui.dp(this,4);cp.rightMargin=Ui.dp(this,4);showcase.addView(card,cp);
        }
        if(rightCount==0){
            FrameLayout filler=new FrameLayout(this);filler.setBackground(Ui.stroke(Color.rgb(9,10,12),Color.rgb(38,38,40),8,this));
            LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(0,-1,1f);showcase.addView(filler,fp);
        }

        for(int i=3;i<categories.size();i++){
            View card=hotCard(categories.get(i),false);
            LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(Ui.dp(this,phone?180:230),-1);ep.rightMargin=Ui.dp(this,10);extraRow.addView(card,ep);
        }
        if(categories.size()<=3){
            TextView hint=Ui.text(this,"Os próximos banners configurados no painel aparecerão aqui.",12,Ui.MUTED,false);hint.setGravity(Gravity.CENTER);
            extraRow.addView(hint,new LinearLayout.LayoutParams(Ui.dp(this,420),-1));
        }
    }

    private View hotCard(ApiClient.HotCategory c,boolean hero){
        FrameLayout card=new FrameLayout(this);card.setFocusable(true);card.setClickable(true);card.setClipToPadding(false);
        Ui.focus(card,this,Ui.stroke(Color.rgb(11,9,10),Color.rgb(41,31,32),8,this),Ui.stroke(Color.rgb(19,12,9),Color.rgb(255,179,22),8,this));

        ImageView image=new ImageView(this);image.setScaleType(ImageView.ScaleType.CENTER_CROP);image.setBackgroundColor(Color.rgb(28,5,7));
        card.addView(image,new FrameLayout.LayoutParams(-1,-1));ImageLoader.into(this,image,c.cover);
        View shade=new View(this);shade.setBackground(new ColorDrawable(hero?0x3A000000:0x52000000));card.addView(shade,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout text=Ui.column(this);text.setGravity(Gravity.BOTTOM);text.setPadding(Ui.dp(this,hero?24:16),Ui.dp(this,12),Ui.dp(this,hero?24:16),Ui.dp(this,hero?22:16));
        TextView hot=Ui.text(this,hero?"HOT +18":"CONTEÚDO ADULTO",hero?(phone?14:17):(phone?10:12),Color.rgb(255,187,31),true);text.addView(hot,new LinearLayout.LayoutParams(-1,Ui.dp(this,28)));
        TextView name=Ui.text(this,c.name,hero?(phone?30:40):(phone?19:24),Color.WHITE,true);name.setMaxLines(hero?2:3);text.addView(name,new LinearLayout.LayoutParams(-1,hero?0:Ui.dp(this,90),hero?1f:0f));
        String meta=meta(c);TextView sub=Ui.text(this,meta,hero?(phone?11:13):(phone?10:11),Color.rgb(232,226,226),false);sub.setMaxLines(2);text.addView(sub,new LinearLayout.LayoutParams(-1,Ui.dp(this,38)));
        card.addView(text,new FrameLayout.LayoutParams(-1,-1));
        card.setOnClickListener(v->openHot(c));
        return card;
    }

    private String meta(ApiClient.HotCategory c){
        List<String> parts=new ArrayList<>();
        if(c.live>0)parts.add(c.live+" ao vivo");if(c.movie>0)parts.add(c.movie+" filmes");if(c.series>0)parts.add(c.series+" séries");
        if(parts.isEmpty())return c.count+" itens";return android.text.TextUtils.join("  •  ",parts);
    }

    private void openHot(ApiClient.HotCategory c){
        String type=c.movie>0?"movie":(c.series>0?"series":"live");
        Intent in=new Intent(this,CatalogActivity.class);in.putExtra("type",type);in.putExtra("title","HOT • "+c.name);in.putExtra("category",c.name);in.putExtra("smart","adult");startActivity(in);
    }
    private void openCatalog(String type,String title,String category){Intent in=new Intent(this,CatalogActivity.class);in.putExtra("type",type);in.putExtra("title",title);in.putExtra("category",category);startActivity(in);}
    private void openSmart(String type,String title,String smart){Intent in=new Intent(this,CatalogActivity.class);in.putExtra("type",type);in.putExtra("title",title);in.putExtra("smart",smart);startActivity(in);}
    private void immersive(){getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);}
}
