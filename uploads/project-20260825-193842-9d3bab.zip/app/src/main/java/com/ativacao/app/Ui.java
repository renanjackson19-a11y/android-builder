package com.ativacao.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

final class Ui {
    static final int BG = Color.rgb(4, 8, 17);
    static final int BG_2 = Color.rgb(7, 13, 25);
    static final int PANEL = Color.rgb(13, 22, 37);
    static final int PANEL_2 = Color.rgb(18, 29, 48);
    static final int PANEL_3 = Color.rgb(23, 36, 58);
    static final int TEXT = Color.rgb(248, 249, 253);
    static final int MUTED = Color.rgb(143, 155, 178);
    static final int PURPLE = Color.rgb(48, 214, 79);
    static final int PURPLE_2 = Color.rgb(18, 143, 51);
    static final int BLUE = Color.rgb(110, 235, 90);
    static final int GREEN = Color.rgb(42, 220, 104);
    static final int RED = Color.rgb(255, 91, 112);
    static final int BORDER = Color.rgb(36, 54, 80);

    static int dp(Context c, int n) { return (int)(n * c.getResources().getDisplayMetrics().density + .5f); }
    static boolean phone(Context c) { return c.getResources().getConfiguration().smallestScreenWidthDp < 600; }
    static boolean portrait(Context c) { return c.getResources().getConfiguration().orientation == android.content.res.Configuration.ORIENTATION_PORTRAIT; }
    static int sw(Context c) { return c.getResources().getConfiguration().screenWidthDp; }

    static GradientDrawable round(int color, int radiusDp, Context c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    static GradientDrawable stroke(int fill, int stroke, int radiusDp, Context c) {
        GradientDrawable g = round(fill, radiusDp, c);
        g.setStroke(dp(c, 1), stroke);
        return g;
    }

    static GradientDrawable gradient(int start, int end, int radiusDp, Context c) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{start, end});
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    static TextView text(Context c, String s, int sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setIncludeFontPadding(false);
        t.setTypeface(Typeface.create("sans", bold ? Typeface.BOLD : Typeface.NORMAL));
        return t;
    }

    static TextView button(Context c, String s) {
        TextView b = text(c, s, phone(c) ? 13 : 14, TEXT, true);
        b.setGravity(Gravity.CENTER);
        b.setFocusable(true);
        b.setClickable(true);
        b.setPadding(dp(c, 14), dp(c, 8), dp(c, 14), dp(c, 8));
        focus(b, c, stroke(PANEL_2, BORDER, 13, c), stroke(PANEL_3, PURPLE, 13, c));
        return b;
    }

    static TextView primaryButton(Context c, String s) {
        TextView b = text(c, s, phone(c) ? 13 : 14, Color.WHITE, true);
        b.setGravity(Gravity.CENTER);
        b.setFocusable(true);
        b.setClickable(true);
        b.setPadding(dp(c, 14), dp(c, 8), dp(c, 14), dp(c, 8));
        focus(b, c, gradient(PURPLE, PURPLE_2, 13, c), gradient(Color.rgb(147,100,255), PURPLE, 13, c));
        return b;
    }

    static void focus(View v, Context c) {
        focus(v, c, stroke(PANEL, BORDER, 14, c), stroke(PANEL_3, PURPLE, 14, c));
    }

    static void focus(View v, Context c, android.graphics.drawable.Drawable normal, android.graphics.drawable.Drawable focused) {
        v.setBackground(normal);
        v.setOnFocusChangeListener((view, hasFocus) -> {
            view.animate().scaleX(hasFocus ? 1.025f : 1f).scaleY(hasFocus ? 1.025f : 1f).translationZ(hasFocus ? dp(c,6) : 0).setDuration(120).start();
            view.setBackground(hasFocus ? focused : normal);
        });
    }

    static LinearLayout column(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    static FrameLayout centered(Context c, View child, int maxDp) {
        FrameLayout box = new FrameLayout(c);
        int w = Math.min(c.getResources().getDisplayMetrics().widthPixels, dp(c, maxDp));
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(w, -1, Gravity.CENTER_HORIZONTAL);
        box.addView(child, p);
        return box;
    }
}
