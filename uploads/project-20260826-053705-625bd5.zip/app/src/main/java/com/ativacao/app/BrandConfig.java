package com.ativacao.app;

import android.content.Context;
import android.content.SharedPreferences;

final class BrandConfig {
    private static final String PREF="dubai_brand";
    static void save(Context c,String logo){
        if(c==null)return;
        c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putString("logo",logo==null?"":logo.trim()).apply();
    }
    static String logo(Context c){
        if(c==null)return "";
        return c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("logo","");
    }
}
