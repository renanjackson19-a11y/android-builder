package com.ativacao.app;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;

final class ContentRules {
    static List<ApiClient.Item> clean(String type,List<ApiClient.Item> src){
        ArrayList<ApiClient.Item> out=new ArrayList<>();
        if(src==null)return out;
        HashSet<String> seen=new HashSet<>();

        for(ApiClient.Item raw:src){
            if(raw==null||raw.id<=0)continue;
            if(StreamHealthStore.isHidden(raw.id))continue;

            ApiClient.Item i=FastCatalogCache.copyItem(raw);
            if("series".equals(type)){
                // A grade mostra apenas a pasta/série. Episódios individuais ficam dentro de SeriesActivity.
                if(i.episodeNumber>0)continue;
                if(good(i.seriesTitle)){
                    // Quando o backend manda o episódio com nome separado, consolida pela pasta da série.
                    if(i.seasonNumber>0 && good(i.name) && !same(i.name,i.seriesTitle)) continue;
                    i.name=i.seriesTitle;
                }
            }

            String key=norm(good(i.seriesTitle)&&"series".equals(type)?i.seriesTitle:i.name);
            if(key.isEmpty())key=String.valueOf(i.id);
            if(seen.contains(key))continue;
            seen.add(key);
            out.add(i);
        }

        Collections.sort(out,new Comparator<ApiClient.Item>(){
            @Override public int compare(ApiClient.Item a,ApiClient.Item b){
                int va=visualScore(a),vb=visualScore(b);
                // Primeiro qualidade visual; depois mais novos.
                if(va!=vb)return Integer.compare(vb,va);
                if(a.year!=b.year)return Integer.compare(b.year,a.year);
                return Long.compare(b.id,a.id);
            }
        });
        return out;
    }

    static void prioritizeAnime(List<ApiClient.Item> list){
        if(list==null)return;
        Collections.sort(list,new Comparator<ApiClient.Item>(){
            @Override public int compare(ApiClient.Item a,ApiClient.Item b){
                int va=visualScore(a),vb=visualScore(b);
                if(va!=vb)return Integer.compare(vb,va);
                int ta=titleScore(a),tb=titleScore(b);
                if(ta!=tb)return Integer.compare(tb,ta);
                if(a.year!=b.year)return Integer.compare(b.year,a.year);
                return Long.compare(b.id,a.id);
            }
        });
    }

    static ApiClient.Item firstHero(List<ApiClient.Item> a,List<ApiClient.Item> b){
        ApiClient.Item best=null;int score=-1;
        if(a!=null)for(ApiClient.Item i:a){int s=heroScore(i);if(s>score){best=i;score=s;}}
        if(b!=null)for(ApiClient.Item i:b){int s=heroScore(i);if(s>score){best=i;score=s;}}
        return best;
    }

    static boolean hasVisual(ApiClient.Item i){return i!=null&&(good(i.logo)||good(i.backdrop));}
    static boolean titleLooksGood(ApiClient.Item i){return i!=null&&good(i.name)&&!badTitle(i.name);}

    private static int heroScore(ApiClient.Item i){
        if(i==null)return -1;int s=0;
        if(good(i.backdrop))s+=6;if(good(i.logo))s+=3;if(titleLooksGood(i))s+=4;if(good(i.synopsis))s+=2;if(i.year>0)s+=1;
        return s;
    }
    private static int visualScore(ApiClient.Item i){
        if(i==null)return 0;int s=0;if(good(i.logo))s+=3;if(good(i.backdrop))s+=2;if(titleLooksGood(i))s+=2;return s;
    }
    private static int titleScore(ApiClient.Item i){return titleLooksGood(i)?1:0;}
    private static boolean badTitle(String s){
        String x=s==null?"":s.trim();if(x.isEmpty())return true;
        int q=0;for(int n=0;n<x.length();n++)if(x.charAt(n)=='?')q++;
        return q>=3||"anime".equalsIgnoreCase(x)||"sem nome".equalsIgnoreCase(x);
    }
    private static boolean good(String s){return s!=null&&!s.trim().isEmpty()&&!"null".equalsIgnoreCase(s.trim());}
    private static boolean same(String a,String b){return norm(a).equals(norm(b));}
    private static String norm(String s){
        if(s==null)return "";
        String x=java.text.Normalizer.normalize(s.toLowerCase(Locale.ROOT),java.text.Normalizer.Form.NFD).replaceAll("\\p{M}","");
        return x.replaceAll("[^a-z0-9]","");
    }
}
