package com.ativacao.app;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

final class FastCatalogCache {
    private static final String PREF="dubai_fast_catalog_v1";
    private static final Map<String,ApiClient.CatalogPage> MEM=new HashMap<>();

    static String key(String type,int page,String query,String category,String smart){
        return clean(type)+"|"+Math.max(1,page)+"|"+clean(query)+"|"+clean(category)+"|"+clean(smart);
    }

    static synchronized void put(Context c,String key,ApiClient.CatalogPage p){
        if(c==null||p==null||key==null)return;
        ApiClient.CatalogPage copy=copyPage(p);
        MEM.put(key,copy);
        try{
            JSONObject root=new JSONObject();
            root.put("page",copy.page);root.put("pages",copy.pages);root.put("total",copy.total);
            JSONArray a=new JSONArray();
            int max=Math.min(copy.items.size(),96);
            for(int n=0;n<max;n++)a.put(toJson(copy.items.get(n)));
            root.put("items",a);
            c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putString(key,root.toString()).apply();
        }catch(Exception ignored){}
    }

    static synchronized ApiClient.CatalogPage get(Context c,String key){
        ApiClient.CatalogPage m=MEM.get(key);
        if(m!=null)return copyPage(m);
        if(c==null||key==null)return null;
        try{
            SharedPreferences sp=c.getSharedPreferences(PREF,Context.MODE_PRIVATE);
            String raw=sp.getString(key,"");
            if(raw==null||raw.isEmpty())return null;
            JSONObject root=new JSONObject(raw);
            ApiClient.CatalogPage p=new ApiClient.CatalogPage();
            p.page=root.optInt("page",1);p.pages=root.optInt("pages",1);p.total=root.optInt("total",0);
            JSONArray a=root.optJSONArray("items");
            if(a!=null)for(int i=0;i<a.length();i++){ApiClient.Item x=fromJson(a.optJSONObject(i));if(x!=null)p.items.add(x);}
            MEM.put(key,copyPage(p));
            return p;
        }catch(Exception ignored){return null;}
    }

    static synchronized void removeItemEverywhere(Context c,long id){
        if(id<=0)return;
        for(ApiClient.CatalogPage p:MEM.values()){
            for(int i=p.items.size()-1;i>=0;i--)if(p.items.get(i)!=null&&p.items.get(i).id==id)p.items.remove(i);
        }
        // cache de disco será naturalmente renovado; não varremos todas as chaves para manter rápido.
    }

    private static ApiClient.CatalogPage copyPage(ApiClient.CatalogPage p){
        ApiClient.CatalogPage q=new ApiClient.CatalogPage();
        q.page=p.page;q.pages=p.pages;q.total=p.total;
        q.categories.addAll(p.categories);
        for(ApiClient.Item i:p.items)q.items.add(copyItem(i));
        return q;
    }
    static ApiClient.Item copyItem(ApiClient.Item i){
        if(i==null)return null;
        ApiClient.Item x=new ApiClient.Item();
        x.id=i.id;x.name=i.name;x.logo=i.logo;x.backdrop=i.backdrop;x.group=i.group;x.synopsis=i.synopsis;
        x.type=i.type;x.format=i.format;x.seriesTitle=i.seriesTitle;x.year=i.year;x.episodeCount=i.episodeCount;
        x.seasonCount=i.seasonCount;x.seasonNumber=i.seasonNumber;x.episodeNumber=i.episodeNumber;x.tmdbId=i.tmdbId;
        return x;
    }
    private static JSONObject toJson(ApiClient.Item i)throws Exception{
        JSONObject o=new JSONObject();if(i==null)return o;
        o.put("id",i.id);o.put("name",i.name);o.put("logo",i.logo);o.put("backdrop",i.backdrop);o.put("group",i.group);
        o.put("synopsis",i.synopsis);o.put("type",i.type);o.put("format",i.format);o.put("seriesTitle",i.seriesTitle);
        o.put("year",i.year);o.put("episodeCount",i.episodeCount);o.put("seasonCount",i.seasonCount);
        o.put("seasonNumber",i.seasonNumber);o.put("episodeNumber",i.episodeNumber);o.put("tmdbId",i.tmdbId);return o;
    }
    private static ApiClient.Item fromJson(JSONObject o){
        if(o==null)return null;ApiClient.Item i=new ApiClient.Item();
        i.id=o.optLong("id");i.name=o.optString("name","");i.logo=o.optString("logo","");i.backdrop=o.optString("backdrop","");
        i.group=o.optString("group","");i.synopsis=o.optString("synopsis","");i.type=o.optString("type","");
        i.format=o.optString("format","auto");i.seriesTitle=o.optString("seriesTitle","");i.year=o.optInt("year",0);
        i.episodeCount=o.optInt("episodeCount",0);i.seasonCount=o.optInt("seasonCount",0);
        i.seasonNumber=o.optInt("seasonNumber",0);i.episodeNumber=o.optInt("episodeNumber",0);i.tmdbId=o.optInt("tmdbId",0);return i;
    }
    private static String clean(String s){return s==null?"":s.trim();}
}
