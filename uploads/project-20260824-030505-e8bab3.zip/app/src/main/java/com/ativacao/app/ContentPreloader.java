package com.ativacao.app;

import android.content.Context;
import java.util.List;

final class ContentPreloader {
    private static volatile boolean started=false;

    static synchronized void start(Context c){
        if(c==null||started)return;started=true;
        final Context app=c.getApplicationContext();
        StreamHealthStore.init(app);
        StreamHealthStore.recheckKnown(app);

        warm(app,"live",1,72,"","","");
        warm(app,"movie",1,60,"","","");
        warm(app,"series",1,60,"","","");
        warm(app,"movie",1,36,"","","kids");
        warm(app,"series",1,36,"","","kids");
        warm(app,"movie",1,36,"","","anime");
        warm(app,"series",1,36,"","","anime");
        FreeFootballSource.preload();
    }

    private static void warm(Context c,String type,int page,int limit,String q,String cat,String smart){
        final String key=FastCatalogCache.key(type,page,q,cat,smart);
        ApiClient.catalog(type,page,limit,q,cat,smart,new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){
                if(p==null)return;
                List<ApiClient.Item> cleaned=ContentRules.clean(type,p.items);
                p.items.clear();p.items.addAll(cleaned);
                FastCatalogCache.put(c,key,p);
            }
            public void error(String m){}
        });
    }
}
