package com.ativacao.app;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.List;

final class StreamHealthStore {
    private static Context app;
    private static final String PREF="dubai_stream_health_v1";
    private static final long AUTO_RETRY_MS=30L*60L*1000L;

    static void init(Context c){if(c!=null)app=c.getApplicationContext();}
    static void markBroken(Context c,long id){
        init(c);if(app==null||id<=0)return;
        app.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putLong("bad_"+id,System.currentTimeMillis()).apply();
        FastCatalogCache.removeItemEverywhere(app,id);
    }
    static void markGood(Context c,long id){
        init(c);if(app==null||id<=0)return;
        app.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().remove("bad_"+id).apply();
    }
    static boolean isHidden(long id){
        if(app==null||id<=0)return false;
        long t=app.getSharedPreferences(PREF,Context.MODE_PRIVATE).getLong("bad_"+id,0L);
        return t>0 && System.currentTimeMillis()-t<AUTO_RETRY_MS;
    }
    static List<Long> badIds(Context c){
        init(c);ArrayList<Long> out=new ArrayList<>();if(app==null)return out;
        for(String k:app.getSharedPreferences(PREF,Context.MODE_PRIVATE).getAll().keySet()){
            if(!k.startsWith("bad_"))continue;
            try{out.add(Long.parseLong(k.substring(4)));}catch(Exception ignored){}
            if(out.size()>=30)break;
        }
        return out;
    }
    static void recheckKnown(Context c){
        init(c);
        for(Long id:badIds(c)){
            ApiClient.resolveStream(id,new ApiClient.Callback<ApiClient.ResolvedStream>(){
                public void ok(ApiClient.ResolvedStream r){
                    if(r!=null&&r.httpCode>=200&&r.httpCode<400)markGood(app,id);
                }
                public void error(String m){}
            });
        }
    }
}
