package com.ativacao.app;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.common.PlaybackException;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.PlayerView;
import androidx.media3.ui.AspectRatioFrameLayout;

import java.util.ArrayList;
import java.util.List;

/** TV: lista/categorias à esquerda + preview à direita. Primeiro OK seleciona; segundo OK abre tela cheia. */
public class LiveTvActivity extends android.app.Activity {
    private final List<ApiClient.Item> allChannels = new ArrayList<>();
    private LinearLayout rows;
    private PlayerView preview;
    private FrameLayout playerCard;
    private FrameLayout shell, fullscreenLayer;
    private LinearLayout fullscreenMenu, fullscreenRows;
    private EditText fullscreenSearch;
    private boolean fullscreenMenuVisible = false;
    private LinearLayout content, rightColumn;
    private LinearLayout.LayoutParams playerNormalLp;
    private boolean fullscreen = false;
    private ExoPlayer player;
    private TextView title, epgNow, epgNext, hint;
    private ProgressBar loading;
    private ApiClient.Item current;
    private View currentRow;
    private long armedChannelId = -1L;
    private int channelLoadToken = 0;
    private String listMode = "all";
    private String searchQuery = "";
    private boolean adultOnly = false;
    private TextView tabAll, tabFav, tabRecent;
    private ProgressBar epgProgress;
    private TextView epgNowTitle, epgNowTime, epgNextTitle, epgNextTime, epgChannelNo, epgDate;
    private ImageView epgLogo;
    private String requestedChannelName="";
    private boolean refreshLiveOnResume = false;
    private EditText searchBox;
    private View previewOverlay;
    private final Handler overlayHandler = new Handler(Looper.getMainLooper());
    private final Runnable hideOverlayTask = () -> { if (previewOverlay != null) previewOverlay.setVisibility(View.GONE); };
    private boolean launchedDirectPlayer = false;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        adultOnly=getIntent().getBooleanExtra("adult_only",false);
        requestedChannelName=getIntent().getStringExtra("open_channel_name"); if(requestedChannelName==null)requestedChannelName="";
        FreeFootballSource.preload();
        immersive();
        setContentView(build());
        loadChannels();
    }

    private void warmMediaCatalog(){
        warmMediaType("movie",48);
        warmMediaType("series",30);
    }

    private void warmMediaType(String type,int limit){
        ApiClient.catalog(type,1,limit,"","","",new ApiClient.Callback<ApiClient.CatalogPage>(){
            @Override public void ok(ApiClient.CatalogPage p){
                if(p==null)return;
                int max=Math.min(p.items.size(),24);
                for(int n=0;n<max;n++){
                    ApiClient.Item i=p.items.get(n);
                    if(i==null)continue;
            if(isAdultChannelName(i.name))continue;
                    if(!i.tmdbLoaded){
                        ApiClient.tmdbEnrich(i,new ApiClient.Callback<ApiClient.Item>(){
                            @Override public void ok(ApiClient.Item x){
                                ImageLoader.preload(LiveTvActivity.this,cleanWarm(x.logo,x.backdrop));
                            }
                            @Override public void error(String m){ ImageLoader.preload(LiveTvActivity.this,cleanWarm(i.logo,i.backdrop)); }
                        });
                    }else ImageLoader.preload(LiveTvActivity.this,cleanWarm(i.logo,i.backdrop));
                }
            }
            @Override public void error(String m){}
        });
    }

    private String cleanWarm(String a,String b){
        String x=a==null?"":a.trim();
        if(!x.isEmpty()&&!"null".equalsIgnoreCase(x))return x;
        x=b==null?"":b.trim();
        return "null".equalsIgnoreCase(x)?"":x;
    }

    private View build() {
        shell=new FrameLayout(this);

        LinearLayout root=Ui.column(this);
        root.setBackground(Ui.diagonalGradient(0xFF061109,0xFF010302,0,this));
        shell.addView(root,new FrameLayout.LayoutParams(-1,-1));

        fullscreenLayer=new FrameLayout(this);
        fullscreenLayer.setBackgroundColor(Color.BLACK);
        fullscreenLayer.setVisibility(View.GONE);
        shell.addView(fullscreenLayer,new FrameLayout.LayoutParams(-1,-1));

        root.addView(YellowNav.bar(this,"TV"),new LinearLayout.LayoutParams(-1,Ui.dp(this,64)));

        // Busca fica no topo, separada da lista de canais, como em players IPTV profissionais.
        LinearLayout searchTop=new LinearLayout(this);
        searchTop.setOrientation(LinearLayout.HORIZONTAL);
        searchTop.setGravity(Gravity.CENTER_VERTICAL);
        searchTop.setPadding(Ui.dp(this,26),Ui.dp(this,7),Ui.dp(this,18),Ui.dp(this,5));
        EditText search=new EditText(this);
        searchBox=search;
        search.setSingleLine(true);
        search.setHint("Pesquisar canais...");
        search.setHintTextColor(0xFF8E9890);
        search.setTextColor(Color.WHITE);
        search.setTextSize(12);
        search.setPadding(Ui.dp(this,16),0,Ui.dp(this,16),0);
        search.setBackground(Ui.stroke(0xD908100B,Ui.GREEN,18,this));
        searchTop.addView(search,new LinearLayout.LayoutParams(Ui.dp(this,355),Ui.dp(this,42)));
        View searchSpacer=new View(this);
        searchTop.addView(searchSpacer,new LinearLayout.LayoutParams(0,Ui.dp(this,42),1));
        root.addView(searchTop,new LinearLayout.LayoutParams(-1,Ui.dp(this,54)));

        LinearLayout main=new LinearLayout(this);
        main.setOrientation(LinearLayout.HORIZONTAL);
        main.setPadding(Ui.dp(this,18),Ui.dp(this,2),Ui.dp(this,18),Ui.dp(this,8));

        // LEFT
        LinearLayout left=Ui.column(this);
        left.setPadding(Ui.dp(this,8),0,Ui.dp(this,10),0);
        left.setBackground(Ui.round(0xCC08100B,10,this));

        TextView section=Ui.text(this,"LISTA DE CANAIS",13,0xFFEAF1EC,true);
        section.setGravity(Gravity.CENTER_VERTICAL);
        left.addView(section,new LinearLayout.LayoutParams(-1,Ui.dp(this,30)));

        LinearLayout filters=new LinearLayout(this);
        filters.setGravity(Gravity.CENTER_VERTICAL);
        tabAll=filterButton("TODOS",true);
        tabFav=filterButton("FAVORITOS",false);
        tabRecent=filterButton("RECENTES",false);
        filters.addView(tabAll,new LinearLayout.LayoutParams(0,Ui.dp(this,36),1));
        filters.addView(tabFav,new LinearLayout.LayoutParams(0,Ui.dp(this,36),1));
        filters.addView(tabRecent,new LinearLayout.LayoutParams(0,Ui.dp(this,36),1));
        TextView refresh=filterButton("↻",false);
        filters.addView(refresh,new LinearLayout.LayoutParams(Ui.dp(this,42),Ui.dp(this,36)));
        refresh.setOnClickListener(v->{CatalogPreloader.start(LiveTvActivity.this,true,()->runOnUiThread(()->{allChannels.clear();loadChannels();}));});
        LinearLayout.LayoutParams flp=new LinearLayout.LayoutParams(-1,Ui.dp(this,42));
        flp.topMargin=Ui.dp(this,7);flp.bottomMargin=Ui.dp(this,4);
        left.addView(filters,flp);

        tabAll.setOnClickListener(v->{listMode="all";updateFilterButtons();renderRowsFiltered(searchQuery);});
        tabFav.setOnClickListener(v->{listMode="fav";updateFilterButtons();renderRowsFiltered(searchQuery);});
        tabRecent.setOnClickListener(v->{listMode="recent";updateFilterButtons();renderRowsFiltered(searchQuery);});

        ScrollView sc=new ScrollView(this);
        sc.setVerticalScrollBarEnabled(false);
        sc.setFillViewport(true);
        rows=Ui.column(this);
        sc.addView(rows,new ScrollView.LayoutParams(-1,-2));
        left.addView(sc,new LinearLayout.LayoutParams(-1,0,1));

        search.addTextChangedListener(new android.text.TextWatcher(){
            public void beforeTextChanged(CharSequence cs,int st,int c,int a){}
            public void onTextChanged(CharSequence cs,int st,int b,int c){
                searchQuery=cs==null?"":cs.toString();
                renderRowsFiltered(searchQuery);
            }
            public void afterTextChanged(android.text.Editable e){}
        });

        LinearLayout.LayoutParams llp=new LinearLayout.LayoutParams(Ui.dp(this,380),-1);
        llp.rightMargin=Ui.dp(this,10);
        main.addView(left,llp);

        // RIGHT / PLAYER
        rightColumn=Ui.column(this);
        playerCard=new FrameLayout(this);
        playerCard.setFocusable(true);playerCard.setClickable(true);
        playerCard.setBackground(Ui.round(Color.BLACK,8,this));

        preview=new PlayerView(this);
        preview.setUseController(false);preview.setKeepScreenOn(true);preview.setFocusable(false);
        preview.setBackgroundColor(Color.BLACK);
        preview.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_ZOOM);
        playerCard.addView(preview,new FrameLayout.LayoutParams(-1,-1));

        loading=new ProgressBar(this);
        playerCard.addView(loading,new FrameLayout.LayoutParams(Ui.dp(this,42),Ui.dp(this,42),Gravity.CENTER));

        LinearLayout overlay=Ui.column(this);
        previewOverlay=overlay;
        overlay.setPadding(Ui.dp(this,14),Ui.dp(this,8),Ui.dp(this,14),Ui.dp(this,7));
        // EPG PRO: identidade do canal + agora/a seguir + progresso em um cartão compacto.
        overlay.setBackground(Ui.round(0xE30A100C,14,this));

        LinearLayout topLine=new LinearLayout(this);
        topLine.setGravity(Gravity.CENTER_VERTICAL);

        epgLogo=new ImageView(this);
        epgLogo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        LinearLayout.LayoutParams logoLp=new LinearLayout.LayoutParams(Ui.dp(this,46),Ui.dp(this,38));
        logoLp.rightMargin=Ui.dp(this,10);
        topLine.addView(epgLogo,logoLp);

        LinearLayout idBox=Ui.column(this);
        LinearLayout nameLine=new LinearLayout(this);
        nameLine.setGravity(Gravity.CENTER_VERTICAL);
        epgChannelNo=Ui.text(this,"",11,Ui.GREEN,true);
        epgChannelNo.setGravity(Gravity.CENTER_VERTICAL);
        nameLine.addView(epgChannelNo,new LinearLayout.LayoutParams(Ui.dp(this,34),Ui.dp(this,22)));
        title=Ui.text(this,"Canal",15,Color.WHITE,true);
        title.setMaxLines(1);
        nameLine.addView(title,new LinearLayout.LayoutParams(0,Ui.dp(this,22),1));
        idBox.addView(nameLine,new LinearLayout.LayoutParams(-1,Ui.dp(this,22)));
        TextView liveMini=Ui.text(this,"● AO VIVO",7,0xFFFF626F,true);
        idBox.addView(liveMini,new LinearLayout.LayoutParams(-1,Ui.dp(this,13)));
        topLine.addView(idBox,new LinearLayout.LayoutParams(0,Ui.dp(this,38),1));

        epgDate=Ui.text(this,new java.text.SimpleDateFormat("dd/MM",java.util.Locale.getDefault()).format(new java.util.Date()),7,0xFFAEB8B1,false);
        epgDate.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        topLine.addView(epgDate,new LinearLayout.LayoutParams(Ui.dp(this,64),Ui.dp(this,38)));
        overlay.addView(topLine,new LinearLayout.LayoutParams(-1,Ui.dp(this,38)));

        LinearLayout epgRow=new LinearLayout(this);
        epgRow.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout nowBox=Ui.column(this);
        epgNow=Ui.text(this,"AGORA",7,Ui.GREEN,true);
        nowBox.addView(epgNow,new LinearLayout.LayoutParams(-1,Ui.dp(this,13)));
        epgNowTitle=Ui.text(this,"Sem informação",9,Color.WHITE,true);
        epgNowTitle.setMaxLines(1);
        nowBox.addView(epgNowTitle,new LinearLayout.LayoutParams(-1,Ui.dp(this,17)));
        epgNowTime=Ui.text(this,"",7,0xFF9EA9A2,false);
        nowBox.addView(epgNowTime,new LinearLayout.LayoutParams(-1,Ui.dp(this,13)));
        epgRow.addView(nowBox,new LinearLayout.LayoutParams(0,Ui.dp(this,43),1));

        View divider=new View(this);divider.setBackgroundColor(0x55354A3E);
        LinearLayout.LayoutParams dlp=new LinearLayout.LayoutParams(Ui.dp(this,1),Ui.dp(this,31));
        dlp.leftMargin=Ui.dp(this,10);dlp.rightMargin=Ui.dp(this,12);
        epgRow.addView(divider,dlp);

        LinearLayout nextBox=Ui.column(this);
        epgNext=Ui.text(this,"A SEGUIR",7,0xFFC5CEC8,true);
        nextBox.addView(epgNext,new LinearLayout.LayoutParams(-1,Ui.dp(this,13)));
        epgNextTitle=Ui.text(this,"—",9,Color.WHITE,false);
        epgNextTitle.setMaxLines(1);
        nextBox.addView(epgNextTitle,new LinearLayout.LayoutParams(-1,Ui.dp(this,17)));
        epgNextTime=Ui.text(this,"",7,0xFF9EA9A2,false);
        nextBox.addView(epgNextTime,new LinearLayout.LayoutParams(-1,Ui.dp(this,13)));
        epgRow.addView(nextBox,new LinearLayout.LayoutParams(0,Ui.dp(this,43),1));
        overlay.addView(epgRow,new LinearLayout.LayoutParams(-1,Ui.dp(this,43)));

        epgProgress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        epgProgress.setMax(100);
        epgProgress.setProgressTintList(ColorStateList.valueOf(Ui.GREEN));
        epgProgress.setProgressBackgroundTintList(ColorStateList.valueOf(0xFF243129));
        LinearLayout.LayoutParams ppl=new LinearLayout.LayoutParams(-1,Ui.dp(this,3));
        ppl.topMargin=Ui.dp(this,2);
        overlay.addView(epgProgress,ppl);

        hint=Ui.text(this,"OK: canais",6,0xFF78857D,false);
        hint.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        overlay.addView(hint,new LinearLayout.LayoutParams(-1,Ui.dp(this,12)));

        FrameLayout.LayoutParams olp=new FrameLayout.LayoutParams(-1,Ui.dp(this,112),Gravity.BOTTOM);
        olp.leftMargin=Ui.dp(this,12);olp.rightMargin=Ui.dp(this,12);olp.bottomMargin=Ui.dp(this,8);
        playerCard.addView(overlay,olp);

        playerCard.setOnClickListener(v->{
            // No modo normal, o primeiro toque apenas amplia o MESMO player, sem recarregar o canal.
            if(!fullscreen){
                openFullscreen();
                return;
            }
            // Em tela cheia, OK/toque abre/fecha a lista lateral sobre o vídeo.
            toggleFullscreenMenu();
        });
        playerNormalLp=new LinearLayout.LayoutParams(-1,-1);
        rightColumn.addView(playerCard,playerNormalLp);
        main.addView(rightColumn,new LinearLayout.LayoutParams(0,-1,1));

        root.addView(main,new LinearLayout.LayoutParams(-1,0,1));

        // Bottom category strip: same composition as target mockup.
        // Navegação inferior removida: o menu superior já concentra as categorias.

        return shell;
    }

    private TextView filterButton(String text,boolean selected){
        TextView t=Ui.text(this,text,9,selected?Color.BLACK:0xFFDDE5DF,true);
        t.setGravity(Gravity.CENTER);t.setFocusable(true);t.setClickable(true);
        t.setBackground(selected?Ui.gradient(Ui.GREEN,Ui.GREEN_2,20,this):Ui.round(Color.TRANSPARENT,20,this));
        return t;
    }

    private void updateFilterButtons(){
        TextView[] bs={tabAll,tabFav,tabRecent};
        String[] ms={"all","fav","recent"};
        for(int i=0;i<bs.length;i++){
            boolean on=ms[i].equals(listMode);
            bs[i].setTextColor(on?Color.BLACK:0xFFDDE5DF);
            bs[i].setBackground(on?Ui.gradient(Ui.GREEN,Ui.GREEN_2,20,this):Ui.round(Color.TRANSPARENT,20,this));
        }
    }

    private void addCategoryTile(LinearLayout row,String label,String type,String smart,Runnable click){
        FrameLayout card=new FrameLayout(this);
        card.setFocusable(true);card.setClickable(true);card.setClipToOutline(true);
        Ui.focus(card,this,Ui.round(0xFF102018,9,this),Ui.stroke(0xFF102018,Ui.GREEN,9,this));

        ImageView img=new ImageView(this);img.setScaleType(ImageView.ScaleType.CENTER_CROP);img.setBackgroundColor(0xFF122018);
        card.addView(img,new FrameLayout.LayoutParams(-1,-1));

        View shade=new View(this);shade.setBackground(Ui.verticalGradient(0x22000000,0xE8000000,0,this));
        card.addView(shade,new FrameLayout.LayoutParams(-1,-1));

        TextView t=Ui.text(this,label,10,Color.WHITE,true);t.setGravity(Gravity.CENTER);
        card.addView(t,new FrameLayout.LayoutParams(-1,Ui.dp(this,34),Gravity.BOTTOM));
        card.setOnClickListener(v->click.run());

        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,1);
        lp.rightMargin=Ui.dp(this,8);row.addView(card,lp);

        ApiClient.catalog(type,1,1,"","",smart,new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){
                if(p!=null&&p.items!=null&&!p.items.isEmpty()){
                    ApiClient.Item it=p.items.get(0);
                    runOnUiThread(()->ImageLoader.into(LiveTvActivity.this,img,clean(it.backdrop,it.logo)));
                }
            }
            public void error(String m){}
        });
    }

    private void openCatalog(String type,String title,String smart){
        Intent i=new Intent(this,CatalogActivity.class);i.putExtra("type",type);i.putExtra("title",title);i.putExtra("smart",smart);startActivity(i);
    }
    private void openDiscover(String smart,String title){
        Intent i=new Intent(this,DiscoverActivity.class);i.putExtra("smart",smart);i.putExtra("title",title);startActivity(i);
    }

    private int phonePad(){return Ui.phone(this)?12:24;}
    private int phoneLeftWidth(){return Ui.phone(this)?315:380;}

    private void addNav(LinearLayout row,String label,boolean selected,Runnable action){
        TextView v=Ui.nav(this,label,selected); if(action!=null)v.setOnClickListener(x->action.run());
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1); row.addView(v,p);
    }

    private void loadChannels(){
        int token=++channelLoadToken;
        loadChannelPage(1, new ArrayList<>(), token);
    }

    private void loadChannelPage(int page, List<ApiClient.Item> acc, int token){
        if(token!=channelLoadToken || isFinishing() || isDestroyed()) return;
        ApiClient.catalog("live",page,72,"","","",new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){
                if(token!=channelLoadToken) return;
                int before=acc.size();
                if(p!=null && p.items!=null){
                    java.util.HashSet<Long> ids=new java.util.HashSet<>();
                    for(ApiClient.Item old:acc) ids.add(old.id);
                    for(ApiClient.Item item:p.items) if(item!=null && !ids.contains(item.id)){acc.add(item);ids.add(item.id);}
                }
                // Mostra a primeira página imediatamente. As demais entram em segundo plano,
                // então a tela não fica vazia esperando o catálogo inteiro.
                if(page==1 || page%3==0){
                    java.util.ArrayList<ApiClient.Item> snapshot=new java.util.ArrayList<>(acc);
                    runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())renderAll(snapshot);});
                }
                int pages=p==null?1:Math.max(1,p.pages);
                boolean apiHasNext=page<pages;
                boolean fullPage=p!=null && p.items!=null && p.items.size()>=72 && acc.size()>before;
                if(page<30 && (apiHasNext || fullPage)){ loadChannelPage(page+1,acc,token); return; }
                java.util.ArrayList<ApiClient.Item> snapshot=new java.util.ArrayList<>(acc);
                runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())renderAll(snapshot);});
            }
            public void error(String m){
                if(!acc.isEmpty()){java.util.ArrayList<ApiClient.Item> snapshot=new java.util.ArrayList<>(acc);runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())renderAll(snapshot);});return;}
                runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())Toast.makeText(LiveTvActivity.this,"Não foi possível carregar os canais",Toast.LENGTH_LONG).show();});
            }
        });
    }

    private void renderAll(List<ApiClient.Item> list){
        allChannels.clear(); if(list!=null)allChannels.addAll(list);
        renderRows();
    }


    private void renderRows(){ renderRowsFiltered(""); }

    private void renderRowsFiltered(String query){
        if(rows==null)return;
        rows.removeAllViews();
        String q=query==null?"":query.trim().toLowerCase(java.util.Locale.ROOT);

        List<ApiClient.Item> source=new ArrayList<>();
        if("fav".equals(listMode)){
            for(ApiClient.Item i:LocalStore.favorites(this))if(i!=null&&"live".equals(i.type))source.add(i);
        }else if("recent".equals(listMode)){
            for(ApiClient.Item i:LocalStore.history(this))if(i!=null&&"live".equals(i.type))source.add(i);
            ApiClient.Item last=LocalStore.lastLive(this);
            if(last!=null){
                boolean exists=false;for(ApiClient.Item x:source)if(x.id==last.id){exists=true;break;}
                if(!exists)source.add(0,last);
            }
        }else source.addAll(allChannels);

        List<ApiClient.Item> visible=new ArrayList<>();
        for(ApiClient.Item i:source){
            if(i==null)continue;
            boolean adult=isAdultChannelName(i.name)||isAdultChannelName(i.group);
            if(adultOnly && !adult)continue;
            if(!adultOnly && adult)continue;
            String nm=clean(i.name,"Canal").toLowerCase(java.util.Locale.ROOT);
            if(q.isEmpty()||nm.contains(q))visible.add(i);
        }

        if(visible.isEmpty()){
            TextView empty=Ui.text(this,"Nenhum canal encontrado",10,Ui.MUTED,false);
            empty.setGravity(Gravity.CENTER);
            rows.addView(empty,new LinearLayout.LayoutParams(-1,Ui.dp(this,90)));
            return;
        }

        boolean typedSearch=!q.isEmpty();
        ApiClient.Item last=LocalStore.lastLive(this);
        ApiClient.Item initial=null;
        if(!typedSearch){
            if(!requestedChannelName.trim().isEmpty()){
                String wanted=normalizeChannelName(requestedChannelName);
                for(ApiClient.Item x:visible){String nm=normalizeChannelName(x.name);if(nm.contains(wanted)||wanted.contains(nm)){initial=x;break;}}
            }
            if(initial==null&&current!=null)for(ApiClient.Item x:visible)if(x.id==current.id){initial=x;break;}
            if(initial==null&&last!=null)for(ApiClient.Item x:visible)if(x.id==last.id){initial=x;break;}
            if(initial==null)initial=visible.get(0);
        }

        View focus=null;
        int n=1;
        for(ApiClient.Item i:visible){
            LinearLayout r=new LinearLayout(this);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(Ui.dp(this,4),Ui.dp(this,3),Ui.dp(this,8),Ui.dp(this,3));
            r.setFocusable(true);r.setClickable(true);

            TextView num=Ui.text(this,String.valueOf(n++),11,Ui.GREEN,true);
            num.setGravity(Gravity.CENTER);
            r.addView(num,new LinearLayout.LayoutParams(Ui.dp(this,28),-1));

            ImageView logo=new ImageView(this);
            logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            logo.setBackground(Ui.round(0x20FFFFFF,7,this));
            ImageLoader.into(this,logo,i.logo);
            LinearLayout.LayoutParams lip=new LinearLayout.LayoutParams(Ui.dp(this,42),Ui.dp(this,42));
            lip.rightMargin=Ui.dp(this,10);
            r.addView(logo,lip);

            LinearLayout names=Ui.column(this);
            TextView nm=Ui.text(this,clean(i.name,"Canal"),12,Color.WHITE,true);
            nm.setMaxLines(1);
            names.addView(nm,new LinearLayout.LayoutParams(-1,0,1));

            if(i.group!=null&&!i.group.trim().isEmpty()){
                TextView grp=Ui.text(this,i.group,8,0xFF8F9991,false);
                grp.setMaxLines(1);
                names.addView(grp,new LinearLayout.LayoutParams(-1,Ui.dp(this,18)));
            }
            r.addView(names,new LinearLayout.LayoutParams(0,-1,1));

            TextView fav=Ui.text(this,LocalStore.isFavorite(this,i.id)?"★":"☆",16,
                    LocalStore.isFavorite(this,i.id)?Ui.GREEN:0xFF6F7771,true);
            fav.setGravity(Gravity.CENTER);fav.setFocusable(true);fav.setClickable(true);
            fav.setOnClickListener(v->{
                LocalStore.toggleFavorite(this,i);
                boolean yes=LocalStore.isFavorite(this,i.id);
                fav.setText(yes?"★":"☆");fav.setTextColor(yes?Ui.GREEN:0xFF6F7771);
            });
            r.addView(fav,new LinearLayout.LayoutParams(Ui.dp(this,38),-1));

            android.graphics.drawable.Drawable normal=Ui.round(0x18000000,7,this);
            android.graphics.drawable.Drawable focused=Ui.stroke(0xFF102016,Ui.GREEN,7,this);
            r.setBackground(normal);

            r.setOnFocusChangeListener((v,has)->{
                v.animate().scaleX(has?1.018f:1f).scaleY(has?1.018f:1f).setDuration(90).start();
                v.setBackground(has?focused:normal);
                if(has){
                    if(current==null||current.id!=i.id){armedChannelId=-1L;previewChannel(i,v);}
                    else currentRow=v;
                }
            });

            r.setOnClickListener(v->{
                if(current==null||current.id!=i.id){
                    armedChannelId=i.id;
                    previewChannel(i,v);
                    currentRow=v;
                    hint.setText("OK novamente: tela cheia");
                    return;
                }
                if(armedChannelId==i.id){openFullscreen();return;}
                armedChannelId=i.id;currentRow=v;hint.setText("OK novamente: tela cheia");
                showPreviewOverlay();
            });

            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,Ui.dp(this,56));
            rp.bottomMargin=Ui.dp(this,2);
            rows.addView(r,rp);
            if(initial!=null && i.id==initial.id)focus=r;
        }

        // Enquanto o usuário digita, apenas filtre a lista. Não troque o canal automaticamente.
        if(!typedSearch && initial!=null){
            previewChannel(initial,focus);
            if(focus!=null)focus.requestFocus();
            requestedChannelName="";
        }
    }

    private void previewChannel(ApiClient.Item i, View row){
        if(i==null)return;
        if(current!=null && current.id==i.id){currentRow=row;return;}
        current=i; currentRow=row; LocalStore.saveLastLive(this,i); LocalStore.addHistory(this,i);
        title.setText(clean(i.name,"Canal"));
        if(epgLogo!=null) ImageLoader.into(this,epgLogo,clean(i.logo,""));
        if(epgChannelNo!=null) epgChannelNo.setText(String.valueOf(currentChannelNumber(i)));
        if(epgDate!=null) epgDate.setText(new java.text.SimpleDateFormat("dd/MM",java.util.Locale.getDefault()).format(new java.util.Date()));
        epgNow.setText("AGORA"); epgNext.setText("A SEGUIR");
        epgNowTitle.setText("Carregando programação...");epgNextTitle.setText("—");
        epgNowTime.setText("");epgNextTime.setText("");epgProgress.setProgress(35);
        hint.setText("OK seleciona • OK novamente abre tela cheia");
        showPreviewOverlay();
        loadEpg(i.id); startPreview(i.id);
    }

    private void showPreviewOverlay(){
        if(previewOverlay==null)return;
        previewOverlay.setVisibility(View.VISIBLE);
        schedulePreviewOverlayHide();
    }

    private void schedulePreviewOverlayHide(){
        overlayHandler.removeCallbacks(hideOverlayTask);
        overlayHandler.postDelayed(hideOverlayTask,4500);
    }

    private void hidePreviewOverlay(){
        overlayHandler.removeCallbacks(hideOverlayTask);
        if(previewOverlay!=null)previewOverlay.setVisibility(View.GONE);
    }

    private void startPreview(long id){
        if(isFinishing() || isDestroyed()) return;
        loading.setVisibility(View.VISIBLE);
        if(player!=null){try{preview.setPlayer(null);player.release();}catch(Exception ignored){} player=null;}
        try{
            String url=ApiClient.streamUrl(id);
            if(url==null || url.trim().isEmpty()) throw new IllegalArgumentException("URL do canal vazia");
            DefaultHttpDataSource.Factory http=new DefaultHttpDataSource.Factory().setUserAgent("VLC/3.0.20 LibVLC/3.0.20").setConnectTimeoutMs(8000).setReadTimeoutMs(30000).setAllowCrossProtocolRedirects(true);
            player=new ExoPlayer.Builder(this).setMediaSourceFactory(new DefaultMediaSourceFactory(this).setDataSourceFactory(http)).build();
            preview.setPlayer(player);
            player.addListener(new Player.Listener(){
                @Override public void onPlaybackStateChanged(int state){if(state==Player.STATE_READY && loading!=null)loading.setVisibility(View.GONE);}
                @Override public void onPlayerError(PlaybackException error){
                    if(loading!=null)loading.setVisibility(View.GONE);
                    if(epgNowTitle!=null)epgNowTitle.setText("Sinal indisponível");
                }
            });
            player.setMediaItem(MediaItem.fromUri(url)); player.prepare(); player.play();
        }catch(Throwable e){
            loading.setVisibility(View.GONE);
            epgNowTitle.setText("Sinal indisponível");
        }
    }

    private void loadEpg(long id){
        ApiClient.epg(id,new ApiClient.Callback<ApiClient.EpgInfo>(){
            public void ok(ApiClient.EpgInfo e){runOnUiThread(()->{
                if(current==null||current.id!=id)return;
                epgNow.setText("AGORA");epgNext.setText("A SEGUIR");
                epgNowTitle.setText(clean(e.nowTitle,"Sem informação"));
                epgNextTitle.setText(clean(e.nextTitle,"—"));
                epgNowTime.setText(timeRange(e.nowStart,e.nowStop));
                epgNextTime.setText(clean(e.nextStart,""));
                epgProgress.setProgress(epgPercent(e.nowStart,e.nowStop));
            });}
            public void error(String m){runOnUiThread(()->{
                if(current!=null&&current.id==id){
                    epgNowTitle.setText("Sem informação");epgNextTitle.setText("—");
                    epgNowTime.setText("");epgNextTime.setText("");epgProgress.setProgress(40);
                }
            });}
        });
    }

    private String timeRange(String a,String b){
        String x=clean(a,""),y=clean(b,"");
        if(x.isEmpty()&&y.isEmpty())return "";
        return x+(y.isEmpty()?"":" - "+y);
    }

    private int epgPercent(String a,String b){
        try{
            java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("HH:mm",java.util.Locale.getDefault());
            java.util.Date s=f.parse(a),e=f.parse(b),n=f.parse(f.format(new java.util.Date()));
            if(s==null||e==null||n==null)return 42;
            long total=e.getTime()-s.getTime(),done=n.getTime()-s.getTime();
            if(total<=0)return 42;
            return Math.max(3,Math.min(97,(int)(done*100/total)));
        }catch(Exception ex){return 42;}
    }


    private int currentChannelNumber(ApiClient.Item item){
        if(item==null)return 1;
        int n=0;
        for(ApiClient.Item x:allChannels){
            if(x==null || !"live".equals(x.type))continue;
            n++;
            if(x.id==item.id)return n;
        }
        return Math.max(1,n);
    }

    private void setOverlayFullscreenSize(boolean full){
        if(previewOverlay==null)return;
        android.view.ViewGroup.LayoutParams base=previewOverlay.getLayoutParams();
        if(!(base instanceof FrameLayout.LayoutParams))return;
        FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)base;
        lp.height=Ui.dp(this,full?122:112);
        lp.leftMargin=Ui.dp(this,full?22:12);
        lp.rightMargin=Ui.dp(this,full?22:12);
        lp.bottomMargin=Ui.dp(this,full?12:8);
        previewOverlay.setLayoutParams(lp);
    }


    private void openOverlayPlayer(){
        if(current==null)return;
        Intent in=new Intent(this,PlayerActivity.class);
        in.putExtra("id",current.id);
        in.putExtra("type","live");
        in.putExtra("name",clean(current.name,"Canal"));
        in.putExtra("logo",clean(current.logo,""));
        in.putExtra("backdrop",clean(current.backdrop,""));
        in.putExtra("group",clean(current.group,""));
        in.putExtra("format",clean(current.format,"auto"));
        in.putExtra("from_home_tv",true);
        startActivity(in);
    }

    private void openFullscreen(){
        if(current==null || fullscreen)return;
        fullscreen=true;
        if(playerCard.getParent() instanceof android.view.ViewGroup){
            ((android.view.ViewGroup)playerCard.getParent()).removeView(playerCard);
        }
        fullscreenLayer.removeAllViews();
        preview.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FILL);
        fullscreenLayer.addView(playerCard,new FrameLayout.LayoutParams(-1,-1));
        buildFullscreenMenu();
        fullscreenLayer.setVisibility(View.VISIBLE);
        fullscreenLayer.bringToFront();
        hint.setText("OK: canais");
        setOverlayFullscreenSize(true);
        showPreviewOverlay();
        playerCard.requestFocus();
        immersive();
    }

    private void buildFullscreenMenu(){
        fullscreenMenu=new LinearLayout(this);
        fullscreenMenu.setOrientation(LinearLayout.HORIZONTAL);
        fullscreenMenu.setBackground(Ui.round(0xE70A100D,0,this));
        fullscreenMenu.setVisibility(View.GONE);
        fullscreenMenuVisible=false;

        LinearLayout rail=Ui.column(this);
        rail.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL);
        rail.setPadding(0,Ui.dp(this,18),0,Ui.dp(this,12));
        rail.setBackground(Ui.round(0xB8070C09,0,this));

        TextView searchIcon=fullscreenRail("⌕");
        TextView recentIcon=fullscreenRail("◷");
        TextView favIcon=fullscreenRail("☆");
        TextView allIcon=fullscreenRail("☷");
        rail.addView(searchIcon,new LinearLayout.LayoutParams(-1,Ui.dp(this,58)));
        rail.addView(recentIcon,new LinearLayout.LayoutParams(-1,Ui.dp(this,58)));
        rail.addView(favIcon,new LinearLayout.LayoutParams(-1,Ui.dp(this,58)));
        rail.addView(allIcon,new LinearLayout.LayoutParams(-1,Ui.dp(this,58)));
        fullscreenMenu.addView(rail,new LinearLayout.LayoutParams(Ui.dp(this,62),-1));

        LinearLayout content=Ui.column(this);
        content.setPadding(Ui.dp(this,14),Ui.dp(this,14),Ui.dp(this,12),Ui.dp(this,12));

        TextView head=Ui.text(this,"Canais ao vivo",14,0xFFEAF1EC,true);
        head.setGravity(Gravity.CENTER_VERTICAL);
        content.addView(head,new LinearLayout.LayoutParams(-1,Ui.dp(this,32)));

        fullscreenSearch=new EditText(this);
        fullscreenSearch.setSingleLine(true);
        fullscreenSearch.setHint("Pesquisar canal...");
        fullscreenSearch.setHintTextColor(0xFF8D9891);
        fullscreenSearch.setTextColor(Color.WHITE);
        fullscreenSearch.setTextSize(11);
        fullscreenSearch.setPadding(Ui.dp(this,12),0,Ui.dp(this,10),0);
        fullscreenSearch.setBackground(Ui.stroke(0xA60F1712,0xFF2B4937,12,this));
        LinearLayout.LayoutParams slp=new LinearLayout.LayoutParams(-1,Ui.dp(this,38));
        slp.bottomMargin=Ui.dp(this,8);
        content.addView(fullscreenSearch,slp);

        LinearLayout statusLine=new LinearLayout(this);
        statusLine.setGravity(Gravity.CENTER_VERTICAL);
        TextView modeLabel=Ui.text(this,"TODOS OS CANAIS",8,Ui.GREEN,true);
        TextView helper=Ui.text(this,"OK: assistir",7,0xFF89938D,false);
        helper.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        statusLine.addView(modeLabel,new LinearLayout.LayoutParams(0,Ui.dp(this,24),1));
        statusLine.addView(helper,new LinearLayout.LayoutParams(0,Ui.dp(this,24),1));
        LinearLayout.LayoutParams stlp=new LinearLayout.LayoutParams(-1,Ui.dp(this,26));
        stlp.bottomMargin=Ui.dp(this,2);
        content.addView(statusLine,stlp);

        View line=new View(this);
        line.setBackgroundColor(0x334F6A58);
        LinearLayout.LayoutParams llp=new LinearLayout.LayoutParams(-1,Ui.dp(this,1));
        llp.bottomMargin=Ui.dp(this,3);
        content.addView(line,llp);

        ScrollView fsc=new ScrollView(this);
        fsc.setVerticalScrollBarEnabled(false);
        fsc.setFillViewport(true);
        fullscreenRows=Ui.column(this);
        fsc.addView(fullscreenRows,new ScrollView.LayoutParams(-1,-2));
        content.addView(fsc,new LinearLayout.LayoutParams(-1,0,1));

        TextView foot=Ui.text(this,"VOLTAR: fechar menu",7,0xFF7F8A83,false);
        foot.setGravity(Gravity.CENTER_VERTICAL);
        content.addView(foot,new LinearLayout.LayoutParams(-1,Ui.dp(this,25)));

        fullscreenMenu.addView(content,new LinearLayout.LayoutParams(0,-1,1));

        FrameLayout.LayoutParams mlp=new FrameLayout.LayoutParams(Ui.dp(this,390),-1,Gravity.LEFT);
        fullscreenLayer.addView(fullscreenMenu,mlp);

        final String[] mode={"all"};
        Runnable redraw=()->{
            renderFullscreenRows(fullscreenSearch==null?"":fullscreenSearch.getText().toString(),mode[0]);
            if("fav".equals(mode[0])) modeLabel.setText("FAVORITOS");
            else if("recent".equals(mode[0])) modeLabel.setText("RECENTES");
            else modeLabel.setText("TODOS OS CANAIS");
        };

        searchIcon.setOnClickListener(v->{
            if(fullscreenSearch!=null){
                fullscreenSearch.requestFocus();
                android.view.inputmethod.InputMethodManager imm=(android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
                if(imm!=null) imm.showSoftInput(fullscreenSearch,android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT);
            }
        });
        recentIcon.setOnClickListener(v->{mode[0]="recent"; redraw.run();});
        favIcon.setOnClickListener(v->{mode[0]="fav"; redraw.run();});
        allIcon.setOnClickListener(v->{mode[0]="all"; redraw.run();});

        fullscreenSearch.addTextChangedListener(new android.text.TextWatcher(){
            public void beforeTextChanged(CharSequence cs,int st,int c,int a){}
            public void onTextChanged(CharSequence cs,int st,int b,int c){redraw.run();}
            public void afterTextChanged(android.text.Editable e){}
        });
        redraw.run();
    }

    private TextView fullscreenRail(String text){
        TextView t=Ui.text(this,text,22,0xFFE8EEE9,false);
        t.setGravity(Gravity.CENTER);
        t.setFocusable(true);
        t.setClickable(true);
        t.setBackground(Ui.round(0x00101813,0,this));
        t.setOnFocusChangeListener((v,has)->{
            ((TextView)v).setTextColor(has?Ui.GREEN:0xFFE8EEE9);
            v.setBackground(has?Ui.round(0x5528E46B,10,this):Ui.round(0x00101813,0,this));
        });
        return t;
    }

    private TextView fullscreenQuick(String text,boolean on){
        TextView t=Ui.text(this,text,8,on?Color.BLACK:0xFFD9E2DC,true);
        t.setGravity(Gravity.CENTER);t.setFocusable(true);t.setClickable(true);
        t.setBackground(on?Ui.gradient(Ui.GREEN,Ui.GREEN_2,16,this):Ui.round(0x66131C17,16,this));
        return t;
    }

    private void renderFullscreenRows(String query,String mode){
        if(fullscreenRows==null)return;
        fullscreenRows.removeAllViews();
        String q=query==null?"":normalizeChannelName(query);
        List<ApiClient.Item> src=new ArrayList<>();
        if("fav".equals(mode)) src.addAll(LocalStore.favorites(this));
        else if("recent".equals(mode)) src.addAll(LocalStore.history(this));
        else src.addAll(allChannels);

        int visibleNo=0;
        for(ApiClient.Item i:src){
            if(i==null || !"live".equals(i.type))continue;
            if(!q.isEmpty() && !normalizeChannelName(i.name).contains(q))continue;
            visibleNo++;

            LinearLayout row=new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(Ui.dp(this,4),0,Ui.dp(this,4),0);
            row.setFocusable(true);
            row.setClickable(true);
            boolean selected=current!=null && current.id==i.id;
            row.setBackground(selected?Ui.stroke(0x66152A1C,Ui.GREEN,6,this):Ui.round(0x00101813,0,this));

            TextView no=Ui.text(this,String.valueOf(visibleNo),9,selected?Ui.GREEN:0xFF9AA59E,true);
            no.setGravity(Gravity.CENTER);
            row.addView(no,new LinearLayout.LayoutParams(Ui.dp(this,28),Ui.dp(this,50)));

            ImageView logo=new ImageView(this);
            logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            LinearLayout.LayoutParams ilp=new LinearLayout.LayoutParams(Ui.dp(this,48),Ui.dp(this,44));
            ilp.leftMargin=Ui.dp(this,2);
            ilp.rightMargin=Ui.dp(this,8);
            row.addView(logo,ilp);
            ImageLoader.into(this,logo,clean(i.logo,""));

            LinearLayout tx=Ui.column(this);
            TextView nm=Ui.text(this,clean(i.name,"Canal"),11,Color.WHITE,true);
            nm.setMaxLines(1);
            tx.addView(nm,new LinearLayout.LayoutParams(-1,Ui.dp(this,24)));
            TextView gp=Ui.text(this,clean(i.group,"TV ao vivo"),7,0xFF9EA8A1,false);
            gp.setMaxLines(1);
            tx.addView(gp,new LinearLayout.LayoutParams(-1,Ui.dp(this,17)));
            row.addView(tx,new LinearLayout.LayoutParams(0,Ui.dp(this,44),1));

            TextView mark=Ui.text(this,selected?"▶":"",10,Ui.GREEN,true);
            mark.setGravity(Gravity.CENTER);
            row.addView(mark,new LinearLayout.LayoutParams(Ui.dp(this,26),Ui.dp(this,44)));

            row.setOnFocusChangeListener((v,has)->{
                if(has){
                    v.setBackground(Ui.stroke(0x551B2A20,Ui.GREEN,6,this));
                }else{
                    boolean isSel=current!=null && current.id==i.id;
                    v.setBackground(isSel?Ui.stroke(0x66152A1C,Ui.GREEN,6,this):Ui.round(0x00101813,0,this));
                }
            });

            row.setOnClickListener(v->{
                if(current==null || current.id!=i.id){
                    previewChannel(i,v);
                }
                hideFullscreenMenu();
            });

            LinearLayout.LayoutParams rlp=new LinearLayout.LayoutParams(-1,Ui.dp(this,51));
            rlp.bottomMargin=Ui.dp(this,1);
            fullscreenRows.addView(row,rlp);

            View sep=new View(this);
            sep.setBackgroundColor(0x223A4D41);
            fullscreenRows.addView(sep,new LinearLayout.LayoutParams(-1,Ui.dp(this,1)));

            if(selected) row.requestFocus();
        }
    }

    private void toggleFullscreenMenu(){
        if(!fullscreen || fullscreenMenu==null)return;
        if(fullscreenMenuVisible) hideFullscreenMenu(); else showFullscreenMenu();
    }

    private void showFullscreenMenu(){
        if(fullscreenMenu==null)return;
        fullscreenMenuVisible=true;
        hidePreviewOverlay();
        fullscreenMenu.setVisibility(View.VISIBLE);
        fullscreenMenu.bringToFront();
        renderFullscreenRows(fullscreenSearch==null?"":fullscreenSearch.getText().toString(),"all");
        if(fullscreenSearch!=null) fullscreenSearch.requestFocus();
    }

    private void hideFullscreenMenu(){
        if(fullscreenMenu==null)return;
        fullscreenMenuVisible=false;
        fullscreenMenu.setVisibility(View.GONE);
        playerCard.requestFocus();
        showPreviewOverlay();
    }

    private void closeFullscreen(){
        if(!fullscreen)return;
        fullscreen=false;
        fullscreenMenuVisible=false;
        if(fullscreenMenu!=null) fullscreenMenu.setVisibility(View.GONE);
        if(playerCard.getParent() instanceof android.view.ViewGroup){
            ((android.view.ViewGroup)playerCard.getParent()).removeView(playerCard);
        }
        fullscreenLayer.setVisibility(View.GONE);
        preview.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_ZOOM);
        if(rightColumn!=null) rightColumn.addView(playerCard,0,playerNormalLp);
        hint.setText("OK: informações");
        setOverlayFullscreenSize(false);
        showPreviewOverlay();
        if(currentRow!=null) currentRow.requestFocus();
        immersive();
    }

    private void openMain(){Intent in=new Intent(this,MainActivity.class);in.putExtra("show_highlights",true);startActivity(in);finish();}
    private void openCatalog(String type,String name){Intent in=new Intent(this,CatalogActivity.class);in.putExtra("type",type);in.putExtra("title",name);startActivity(in);}

    @Override public void onBackPressed(){if(fullscreen && fullscreenMenuVisible){hideFullscreenMenu();return;}if(fullscreen){closeFullscreen();return;}finish();}

    /**
     * TV ao vivo não deve continuar do ponto onde ficou pausada ao sair da tela.
     * Ao voltar de Filmes/Séries/Kids/etc., recriamos o stream do canal atual para
     * entrar novamente na borda AO VIVO e atualizamos o EPG.
     */
    @Override protected void onResume(){
        super.onResume();
        immersive();
        if(refreshLiveOnResume && current!=null){
            refreshLiveOnResume=false;
            startPreview(current.id);
            loadEpg(current.id);
            return;
        }
        try{if(player!=null)player.play();}catch(Throwable ignored){}
    }

    @Override protected void onPause(){
        if(current!=null) refreshLiveOnResume=true;
        try{if(player!=null)player.pause();}catch(Throwable ignored){}
        super.onPause();
    }

    @Override protected void onDestroy(){super.onDestroy();if(player!=null){try{player.release();}catch(Exception ignored){}}}
    private String normalizeChannelName(String s){
        if(s==null)return "";String x=java.text.Normalizer.normalize(s,java.text.Normalizer.Form.NFD).replaceAll("\\p{M}+","").toLowerCase(java.util.Locale.ROOT);
        x=x.replace("hd","").replace("fhd","").replace("4k","").replace("canal","").replace("tv","").replaceAll("[^a-z0-9]+"," ").trim();
        return x;
    }

    private void immersive(){WindowCompat.setDecorFitsSystemWindows(getWindow(),false);WindowInsetsControllerCompat c=WindowCompat.getInsetsController(getWindow(),getWindow().getDecorView());c.hide(WindowInsetsCompat.Type.systemBars());c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);}
    private String clean(String v,String f){if(v==null)return f;String s=v.trim();return s.isEmpty()||"null".equalsIgnoreCase(s)?f:s;}

    private boolean isAdultChannelName(String name){
        if(name==null)return false;
        String x=name.toLowerCase(java.util.Locale.ROOT);
        String[] keys={"adulto","adultos","adult","18+","hot","sexy","privê","prive","erótico","erotico","porn","xxx"};
        for(String k:keys)if(x.contains(k))return true;
        return false;
    }
}
