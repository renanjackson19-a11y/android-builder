package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public class GamesActivity extends Activity {
    private boolean phone;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        Ui.immersive(this);
        phone=Ui.phone(this);
        setContentView(build());
    }

    private View build(){
        LinearLayout root=Ui.column(this);
        root.setBackgroundColor(Ui.BG);
        root.addView(YellowNav.bar(this,"GAMES"),new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?56:64)));

        LinearLayout body=Ui.column(this);
        body.setPadding(Ui.dp(this,phone?18:30),Ui.dp(this,16),Ui.dp(this,phone?18:30),Ui.dp(this,24));

        TextView title=Ui.text(this,"GAMES",phone?24:32,Ui.GREEN,true);
        body.addView(title,new LinearLayout.LayoutParams(-1,Ui.dp(this,48)));

        TextView sub=Ui.text(this,"Jogos, Jogos Retrô e Esportes em áreas separadas.",phone?10:13,Ui.MUTED,false);
        body.addView(sub,new LinearLayout.LayoutParams(-1,Ui.dp(this,34)));

        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(tile("JOGOS","Biblioteca de jogos","games",0xFF11160F),new LinearLayout.LayoutParams(0,-1,1));

        LinearLayout.LayoutParams r2=new LinearLayout.LayoutParams(0,-1,1);
        r2.leftMargin=Ui.dp(this,10);
        row.addView(tile("JOGOS RETRÔ","Clássicos e coleções retrô","retro",0xFF17130B),r2);

        LinearLayout.LayoutParams r3=new LinearLayout.LayoutParams(0,-1,1);
        r3.leftMargin=Ui.dp(this,10);
        row.addView(tile("ESPORTES","Jogos do dia, ligas e placares","sports",0xFF0E1518),r3);

        body.addView(row,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?200:270)));

        TextView info=Ui.text(this,"Games não abre mais direto em futebol. Jogos Retrô tem biblioteca própria.",10,Ui.MUTED,false);
        LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,Ui.dp(this,44));
        ip.topMargin=Ui.dp(this,16);
        body.addView(info,ip);

        root.addView(Ui.centered(this,body,1380),new LinearLayout.LayoutParams(-1,0,1));
        return root;
    }

    private FrameLayout tile(String name,String desc,String target,int fill){
        FrameLayout card=new FrameLayout(this);
        card.setFocusable(true); card.setClickable(true);
        Ui.focus(card,this,Ui.gradient(fill,Ui.PANEL,10,this),Ui.stroke(Ui.PANEL_2,Ui.GREEN,10,this));

        LinearLayout text=Ui.column(this);
        text.setPadding(Ui.dp(this,20),Ui.dp(this,18),Ui.dp(this,20),Ui.dp(this,16));
        TextView n=Ui.text(this,name,phone?18:25,Color.WHITE,true);
        text.addView(n,new LinearLayout.LayoutParams(-1,0,1));
        TextView d=Ui.text(this,desc,phone?10:12,Ui.MUTED,false);
        text.addView(d,new LinearLayout.LayoutParams(-1,Ui.dp(this,38)));
        TextView open=Ui.text(this,"ABRIR  ›",10,Ui.GREEN,true);
        text.addView(open,new LinearLayout.LayoutParams(-1,Ui.dp(this,28)));
        card.addView(text,new FrameLayout.LayoutParams(-1,-1));
        card.setOnClickListener(v->open(target));
        return card;
    }

    private void open(String target){
        if("sports".equals(target)){
            startActivity(new Intent(this,FootballActivity.class));
            return;
        }
        Intent in=new Intent(this,DiscoverActivity.class);
        in.putExtra("smart",target);
        in.putExtra("title","retro".equals(target)?"Jogos Retrô":"Jogos");
        startActivity(in);
    }

    @Override protected void onResume(){super.onResume();Ui.immersive(this);}
}
