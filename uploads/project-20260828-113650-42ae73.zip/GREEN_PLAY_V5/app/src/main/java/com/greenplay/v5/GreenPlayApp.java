package com.greenplay.v5;

import android.app.Application;
import com.greenplay.v5.core.network.NetworkProvider;

public final class GreenPlayApp extends Application {
    @Override public void onCreate() {
        super.onCreate();
        NetworkProvider.init(this);
    }
}
