package com.greenplay.v5.ui.tv;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.greenplay.v5.R;
import com.greenplay.v5.data.model.tv.TvCategory;
import java.util.ArrayList;
import java.util.List;

final class TvCategoryAdapter extends RecyclerView.Adapter<TvCategoryAdapter.Holder> {
    interface Listener { void onCategory(TvCategory category, int position); }
    private final List<TvCategory> rows = new ArrayList<>();
    private final Listener listener;
    private int selected = 0;
    TvCategoryAdapter(Listener listener){this.listener=listener;}
    void setRows(List<TvCategory> data){rows.clear(); if(data!=null)rows.addAll(data); selected=0; notifyDataSetChanged();}

    @NonNull @Override public Holder onCreateViewHolder(@NonNull ViewGroup parent,int viewType){
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.item_tv_category,parent,false); return new Holder(v);
    }
    @Override public void onBindViewHolder(@NonNull Holder h,int pos){
        TvCategory row=rows.get(pos); h.text.setText(row.name); h.itemView.setSelected(pos==selected);
        h.itemView.setOnClickListener(v->select(h.getBindingAdapterPosition()));
        h.itemView.setOnFocusChangeListener((v,focus)->{ if(focus)v.setScaleX(1.03f); else v.setScaleX(1f); });
    }
    private void select(int p){if(p<0||p>=rows.size())return; int old=selected;selected=p;notifyItemChanged(old);notifyItemChanged(selected);listener.onCategory(rows.get(p),p);}
    @Override public int getItemCount(){return rows.size();}
    static final class Holder extends RecyclerView.ViewHolder{ final TextView text; Holder(View v){super(v);text=v.findViewById(R.id.categoryName);} }
}
