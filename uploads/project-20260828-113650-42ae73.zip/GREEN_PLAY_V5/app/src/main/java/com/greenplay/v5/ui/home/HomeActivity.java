package com.greenplay.v5.ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.greenplay.v5.databinding.ActivityHomeBinding;
import com.greenplay.v5.ui.tv.TvActivity;

public final class HomeActivity extends AppCompatActivity {
    private ActivityHomeBinding b;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state); b=ActivityHomeBinding.inflate(getLayoutInflater());setContentView(b.getRoot());bindNav();
        b.navTv.postDelayed(()->startActivity(new Intent(this,TvActivity.class)),120);
    }
    private void bindNav(){
        b.navTv.setOnClickListener(v->startActivity(new Intent(this,TvActivity.class)));
        b.navFootball.setOnClickListener(v->pending("FUTEBOL"));b.navMovies.setOnClickListener(v->pending("FILMES"));b.navSeries.setOnClickListener(v->pending("SÉRIES"));b.navKids.setOnClickListener(v->pending("KIDS"));b.navAnime.setOnClickListener(v->pending("ANIME"));b.navHot.setOnClickListener(v->pending("HOT"));
    }
    private void pending(String name){Toast.makeText(this,name+" será criado depois da TV",Toast.LENGTH_SHORT).show();}
}
