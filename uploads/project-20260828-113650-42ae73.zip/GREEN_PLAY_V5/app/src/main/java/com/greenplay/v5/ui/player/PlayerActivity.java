package com.greenplay.v5.ui.player;

import android.net.Uri;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import com.greenplay.v5.databinding.ActivityPlayerBinding;

public final class PlayerActivity extends AppCompatActivity {
    private ActivityPlayerBinding b;
    private ExoPlayer player;
    private String fallbackUrl;
    private boolean fallbackTried;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        b = ActivityPlayerBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        String url = getIntent().getStringExtra("url");
        fallbackUrl = getIntent().getStringExtra("fallback_url");
        if (url == null || url.trim().isEmpty()) { finish(); return; }
        player = new ExoPlayer.Builder(this).build();
        b.playerView.setPlayer(player);
        player.addListener(new Player.Listener(){
            @Override public void onPlayerError(@NonNull PlaybackException error){
                if(!fallbackTried && fallbackUrl!=null && !fallbackUrl.trim().isEmpty()){
                    fallbackTried=true;
                    startUrl(fallbackUrl);
                }
            }
        });
        startUrl(url);
    }

    private void startUrl(String url){
        if(player==null)return;
        player.setMediaItem(MediaItem.fromUri(Uri.parse(url)));
        player.prepare();
        player.play();
    }

    @Override protected void onStop() { super.onStop(); if (player != null) { player.release(); player = null; } }
}
