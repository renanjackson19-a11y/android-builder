package com.greenplay.v5.ui.tv;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.greenplay.v5.R;
import com.greenplay.v5.data.model.tv.TvChannel;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

final class TvChannelAdapter extends RecyclerView.Adapter<TvChannelAdapter.Holder> {
    interface Listener {
        void onFocus(TvChannel channel);
        void onOpen(TvChannel channel);
        void onFavorite(TvChannel channel);
        boolean isFavorite(TvChannel channel);
    }

    private final List<TvChannel> all = new ArrayList<>();
    private final List<TvChannel> rows = new ArrayList<>();
    private final Listener listener;
    private String sectionLabel = "TV AO VIVO";

    TvChannelAdapter(Listener listener){this.listener=listener;}
    void setRows(List<TvChannel> data){all.clear();if(data!=null)all.addAll(data);filter("");}
    void setSectionLabel(String label){sectionLabel=(label==null||label.trim().isEmpty())?"TV AO VIVO":label;notifyDataSetChanged();}
    List<TvChannel> snapshot(){return new ArrayList<>(all);}
    void filter(String q){rows.clear();String s=q==null?"":q.trim().toLowerCase(Locale.ROOT);for(TvChannel c:all)if(s.isEmpty()||c.name.toLowerCase(Locale.ROOT).contains(s))rows.add(c);notifyDataSetChanged();}
    TvChannel first(){return rows.isEmpty()?null:rows.get(0);}
    void refreshFavorite(long id){for(int i=0;i<rows.size();i++)if(rows.get(i).id==id){notifyItemChanged(i);break;}}

    @NonNull @Override public Holder onCreateViewHolder(@NonNull ViewGroup parent,int viewType){return new Holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_tv_channel,parent,false));}
    @Override public void onBindViewHolder(@NonNull Holder h,int pos){
        TvChannel c=rows.get(pos);
        h.number.setText(String.valueOf(pos+1));
        h.name.setText(c.name);
        h.subtitle.setText(sectionLabel);
        h.favorite.setText(listener.isFavorite(c)?"★":"☆");
        h.logo.setImageDrawable(null);
        if(c.logo!=null&&!c.logo.trim().isEmpty()){
            Picasso.get().load(c.logo).fit().centerInside().noFade().into(h.logo);
        }
        h.itemView.setOnFocusChangeListener((v,focus)->{v.setSelected(focus);if(focus)listener.onFocus(c);});
        h.itemView.setOnClickListener(v->listener.onOpen(c));
        h.favorite.setOnClickListener(v->{listener.onFavorite(c);h.favorite.setText(listener.isFavorite(c)?"★":"☆");});
    }
    @Override public int getItemCount(){return rows.size();}
    static final class Holder extends RecyclerView.ViewHolder{
        final TextView number,name,subtitle,favorite;final ImageView logo;
        Holder(View v){super(v);number=v.findViewById(R.id.channelNumber);name=v.findViewById(R.id.channelName);subtitle=v.findViewById(R.id.channelSubtitle);favorite=v.findViewById(R.id.channelFavorite);logo=v.findViewById(R.id.channelLogo);}
    }
}
