package com.greenplay.v5.core.network;

import com.greenplay.v5.BuildConfig;
import java.net.URL;

public final class PanelHost {
    private PanelHost() {}
    public static String root() {
        try {
            URL u = new URL(BuildConfig.PANEL_BASE_URL);
            int p = u.getPort();
            return u.getProtocol() + "://" + u.getHost() + (p > 0 ? ":" + p : "");
        } catch (Exception e) {
            return "";
        }
    }
}
