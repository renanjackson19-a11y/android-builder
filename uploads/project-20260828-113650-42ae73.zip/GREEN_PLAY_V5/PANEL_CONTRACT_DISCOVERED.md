# Contrato do painel observado no V4 (somente referência de compatibilidade)

O V5 não copia a implementação do V4. Esta lista existe só para não quebrar o painel já implantado.

## Autenticação / aparência
- `status.php`: nome, teste automático, horas de teste, logo/fundos.
- `login.php` POST: username, password, device.
- `trial.php` POST: device.

## Conteúdo/painel observado
- `catalog.php`
- `sections.php`
- `football.php`
- `hot_categories.php`
- `stream_probe.php`
- `stream_failure.php`

## Xtream padrão usado pelo servidor final
- `player_api.php`
- actions: `get_live_categories`, `get_live_streams`, `get_vod_categories`, `get_vod_streams`, `get_series_categories`, `get_series`, `get_series_info`, `get_vod_info`, `get_short_epg`.
- streams: `/live/<user>/<pass>/<id>.<ext>`, `/movie/...`, `/series/...`.

## Segurança
O host, token de aplicativo e chave de assinatura encontrados no V4 NÃO foram copiados para o V5. Eles devem entrar por configuração segura na etapa de integração.
