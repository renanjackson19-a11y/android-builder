package com.greenplay.v5.data.model;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public final class AppConfigResponse {
    public boolean ok;
    public Branding branding;
    public Universal universal;
    public Update update;

    public static final class Branding {
        @SerializedName("app_name") public String appName;
        @SerializedName("support_whatsapp") public String supportWhatsapp;
        @SerializedName("accent_color") public String accentColor;
        public String logo;
        public String background;
        public String banner;
        @SerializedName("fallback_cover") public String fallbackCover;
        @SerializedName("account_title") public String accountTitle;
        @SerializedName("about_text") public String aboutText;
        @SerializedName("show_parental") public boolean showParental;
        @SerializedName("show_favorites") public boolean showFavorites;
        @SerializedName("show_update") public boolean showUpdate;
        @SerializedName("show_clear_cache") public boolean showClearCache;
        @SerializedName("show_support") public boolean showSupport;
        @SerializedName("show_about") public boolean showAbout;
        @SerializedName("branding_version") public long brandingVersion;
    }

    public static final class Universal {
        public boolean enabled;
        public List<Server> servers;
        @SerializedName("login_mode") public String loginMode;
    }

    public static final class Server {
        public int id;
        public String name;
        public String host;
        public String type;
        @SerializedName("default") public boolean isDefault;
        public int priority;
    }

    public static final class Update {
        @SerializedName("latest_version") public String latestVersion;
        @SerializedName("version_code") public int versionCode;
        @SerializedName("apk_url") public String apkUrl;
        @SerializedName("force_update") public boolean forceUpdate;
        public String message;
    }
}
