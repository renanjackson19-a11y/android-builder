APP DE TESTE DO COMPILADOR

Envie este ZIP no painel e escolha:
APK de teste (debug)

O projeto contém:
- gradlew
- settings.gradle
- pasta app
- aplicativo Android simples

Quando a compilação terminar, baixe o artefato APK no painel.
