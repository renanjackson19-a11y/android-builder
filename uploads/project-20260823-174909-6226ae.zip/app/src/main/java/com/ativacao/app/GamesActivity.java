package com.ativacao.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class GamesActivity extends Activity {
    private boolean phone; private GridView grid; private TextView status,title; private EditText search;
    private final List<OpenGameCatalog.Game> all=new ArrayList<>(),games=new ArrayList<>(); private GameAdapter adapter; private String mode="retro";
    @Override public void onCreate(Bundle b){super.onCreate(b);Ui.immersive(this);phone=Ui.phone(this);mode=getIntent().getStringExtra("mode");if(mode==null||mode.isEmpty())mode="retro";setContentView(build());load();}
    private View build(){
        LinearLayout root=Ui.column(this);root.setBackgroundColor(Ui.BG);root.addView(YellowNav.bar(this,"GAMES"),new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?56:64)));
        LinearLayout body=Ui.column(this);body.setPadding(Ui.dp(this,phone?14:24),Ui.dp(this,10),Ui.dp(this,phone?14:24),Ui.dp(this,14));
        LinearLayout tabs=new LinearLayout(this);tabs.setGravity(Gravity.CENTER_VERTICAL);String[][] ts={{"JOGOS RETRÔ","retro"},{"PS2","ps2"},{"NINTENDO DS","ds"},{"3DS","3ds"},{"FUTEBOL","football"}};for(int i=0;i<ts.length;i++){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,Ui.dp(this,46),1);if(i>0)lp.leftMargin=Ui.dp(this,8);tabs.addView(tab(ts[i][0],ts[i][1]),lp);}body.addView(tabs,new LinearLayout.LayoutParams(-1,Ui.dp(this,50)));
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);title=Ui.text(this,"JOGOS RETRÔ",phone?21:28,Ui.TEXT,true);head.addView(title,new LinearLayout.LayoutParams(0,Ui.dp(this,48),1));search=new EditText(this);search.setSingleLine(true);search.setHint("Pesquisar jogo...");search.setHintTextColor(Ui.MUTED);search.setTextColor(Color.WHITE);search.setTextSize(12);search.setPadding(Ui.dp(this,14),0,Ui.dp(this,14),0);search.setBackground(round(0xff121512,16,0xff303630));search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){filter(s.toString());}public void afterTextChanged(Editable e){}});head.addView(search,new LinearLayout.LayoutParams(Ui.dp(this,phone?230:320),Ui.dp(this,40)));body.addView(head);
        status=Ui.text(this,"Carregando jogos...",10,Ui.MUTED,false);body.addView(status,new LinearLayout.LayoutParams(-1,Ui.dp(this,26)));
        grid=new GridView(this);grid.setNumColumns(phone?4:6);grid.setHorizontalSpacing(Ui.dp(this,14));grid.setVerticalSpacing(Ui.dp(this,16));grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);grid.setSelector(android.R.color.transparent);adapter=new GameAdapter();grid.setAdapter(adapter);body.addView(grid,new LinearLayout.LayoutParams(-1,0,1));root.addView(Ui.centered(this,body,1480),new LinearLayout.LayoutParams(-1,0,1));return root;
    }
    private GradientDrawable round(int color,int radius,int stroke){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(Ui.dp(this,radius));if(stroke!=0)g.setStroke(Ui.dp(this,1),stroke);return g;}
    private TextView tab(String label,String target){TextView v=Ui.button(this,label);v.setOnClickListener(x->{if("football".equals(target)){startActivity(new Intent(this,FootballActivity.class));return;}mode=target;search.setText("");load();});return v;}
    private void load(){title.setText("retro".equals(mode)?"JOGOS RETRÔ":mode.toUpperCase(Locale.ROOT));status.setText("Carregando jogos...");all.clear();games.clear();adapter.notifyDataSetChanged();OpenGameCatalog.load(mode,new OpenGameCatalog.Callback(){public void ok(List<OpenGameCatalog.Game>d){runOnUiThread(()->{all.clear();all.addAll(d);filter(search.getText().toString());status.setText(all.size()+" jogos • escolha uma capa para ver detalhes");if(!games.isEmpty())grid.requestFocus();});}public void error(String m){runOnUiThread(()->status.setText(m));}});}
    private void filter(String q){String x=q==null?"":q.trim().toLowerCase(Locale.ROOT);games.clear();for(OpenGameCatalog.Game g:all)if(x.isEmpty()||g.name.toLowerCase(Locale.ROOT).contains(x)||g.platform.toLowerCase(Locale.ROOT).contains(x))games.add(g);adapter.notifyDataSetChanged();}
    private void details(OpenGameCatalog.Game g){status.setText("Carregando detalhes de "+g.name+"...");OpenGameCatalog.enrich(g,x->runOnUiThread(()->{status.setText(all.size()+" jogos • catálogo aberto");String msg=x.platform+(x.year.isEmpty()?"":" • "+x.year)+(x.synopsis.isEmpty()?"":"\n\n"+x.synopsis);new AlertDialog.Builder(this).setTitle(x.name).setMessage(msg).setPositiveButton("FECHAR",null).show();}));}
    private class GameAdapter extends BaseAdapter{
        public int getCount(){return games.size();}public Object getItem(int p){return games.get(p);}public long getItemId(int p){return p;}
        public View getView(int p,View cv,android.view.ViewGroup parent){LinearLayout card;ImageView cover;TextView badge,name;if(cv==null){card=Ui.column(GamesActivity.this);card.setFocusable(true);Ui.focus(card,GamesActivity.this);card.setBackground(round(0xff101310,14,0xff252a25));cover=new ImageView(GamesActivity.this);cover.setId(901);cover.setScaleType(ImageView.ScaleType.CENTER_CROP);cover.setBackground(round(0xff242824,14,0));card.addView(cover,new LinearLayout.LayoutParams(-1,0,1));badge=Ui.text(GamesActivity.this,"",9,Ui.GREEN,true);badge.setId(902);badge.setPadding(Ui.dp(GamesActivity.this,8),Ui.dp(GamesActivity.this,5),Ui.dp(GamesActivity.this,8),0);card.addView(badge,new LinearLayout.LayoutParams(-1,Ui.dp(GamesActivity.this,24)));name=Ui.text(GamesActivity.this,"",phone?10:12,Color.WHITE,true);name.setId(903);name.setMaxLines(2);name.setPadding(Ui.dp(GamesActivity.this,8),0,Ui.dp(GamesActivity.this,8),Ui.dp(GamesActivity.this,7));card.addView(name,new LinearLayout.LayoutParams(-1,Ui.dp(GamesActivity.this,42)));cv=card;}else card=(LinearLayout)cv;cover=cv.findViewById(901);badge=cv.findViewById(902);name=cv.findViewById(903);OpenGameCatalog.Game g=games.get(p);cover.setImageDrawable(null);cover.setTag(null);badge.setText(g.platform);name.setText(g.name);if(!g.cover.isEmpty())ImageLoader.into(GamesActivity.this,cover,g.cover);else OpenGameCatalog.enrich(g,x->runOnUiThread(()->{if(x==g&&!x.cover.isEmpty())ImageLoader.into(GamesActivity.this,cover,x.cover);}));card.setOnClickListener(v->details(g));return cv;}
    }
    @Override protected void onResume(){super.onResume();Ui.immersive(this);}
}
