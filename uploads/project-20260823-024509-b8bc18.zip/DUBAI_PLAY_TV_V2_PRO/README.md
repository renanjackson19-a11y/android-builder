# Dubai Play TV V2 PRO

Base Android profissional para Android TV, TV Box e celular em modo paisagem.

## Já configurado
- Domínio do painel: `https://dubaiplay.shop/api/`
- Dashboard profissional
- Canais ao vivo
- Filmes
- Séries
- Busca no catálogo
- Logos/capas via URL
- Player Media3 / ExoPlayer
- Controle por TV/controle remoto
- Tela de status/conexão
- GitHub Actions para gerar APK
- A M3U privada não fica dentro do aplicativo

## Única configuração antes do APK acessar o catálogo
Abra:

`app/src/main/java/com/dubaiplay/tv/Config.java`

E troque:

`COLE_A_CHAVE_API_DO_PAINEL_AQUI`

pela chave `api_key` criada no `config.php` do painel instalado.

A URL da sua lista M3U, usuário e senha da origem NÃO devem ser colocados no APK.

## Compilar pelo celular no GitHub
1. Crie um repositório.
2. Envie o conteúdo desta pasta para a raiz do repositório.
3. Abra a aba **Actions**.
4. Execute **Build Dubai Play APK**.
5. Baixe o artefato `DUBAI-PLAY-TV-V2`.

O APK gerado terá o nome `DUBAI-PLAY-TV-V2.apk`.
