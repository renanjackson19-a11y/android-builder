package com.dubaiplay.tv;

/**
 * Configuração do aplicativo.
 *
 * O app já está apontando para o painel em dubaiplay.shop.
 * Para liberar o catálogo, cole em API_KEY a chave gerada pelo install.php
 * do seu painel. Não coloque a URL/usuário/senha da M3U neste aplicativo.
 */
public final class Config {
    private Config() {}

    public static final String APP_NAME = "Dubai Play";
    public static final String API_BASE_URL = "https://dubaiplay.shop/api/";

    // Cole somente a chave da API do PAINEL. Nunca coloque a senha da M3U aqui.
    public static final String API_KEY = "COLE_A_CHAVE_API_DO_PAINEL_AQUI";

    public static boolean apiKeyConfigured() {
        return API_KEY != null
                && !API_KEY.trim().isEmpty()
                && !API_KEY.contains("COLE_A_CHAVE");
    }
}
