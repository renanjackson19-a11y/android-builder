package com.dubaiplay.tv.model;

public class StatusResponse {
    public boolean ok;
    public String name;
    public String version;
}
