package com.dubaiplay.tv.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.dubaiplay.tv.BuildConfig;
import com.dubaiplay.tv.Config;
import com.dubaiplay.tv.R;
import com.dubaiplay.tv.model.StatusResponse;
import com.dubaiplay.tv.net.ApiClient;

public class SettingsActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        immersive();
        ((TextView)findViewById(R.id.serverUrl)).setText(Config.API_BASE_URL.replace("/api/", ""));
        ((TextView)findViewById(R.id.appVersion)).setText(BuildConfig.VERSION_NAME);
        ((TextView)findViewById(R.id.apiKeyState)).setText(Config.apiKeyConfigured() ? "Configurada" : "Pendente");
        findViewById(R.id.btnSettingsBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnTestConnection).setOnClickListener(v -> test());
        findViewById(R.id.btnSettingsBack).requestFocus();
    }

    private void test() {
        TextView result = findViewById(R.id.connectionResult);
        result.setText("Testando conexão...");
        ApiClient.status(new ApiClient.Result<StatusResponse>() {
            @Override public void onSuccess(StatusResponse value) {
                runOnUiThread(() -> result.setText("Servidor online • " + (value.name == null ? "Dubai Play" : value.name)));
            }
            @Override public void onError(String message) {
                runOnUiThread(() -> result.setText("Servidor indisponível • " + message));
            }
        });
    }

    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }
}
