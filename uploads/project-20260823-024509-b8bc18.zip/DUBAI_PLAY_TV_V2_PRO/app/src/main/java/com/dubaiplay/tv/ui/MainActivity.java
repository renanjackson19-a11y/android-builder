package com.dubaiplay.tv.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.dubaiplay.tv.Config;
import com.dubaiplay.tv.R;
import com.dubaiplay.tv.model.CatalogResponse;
import com.dubaiplay.tv.model.StatusResponse;
import com.dubaiplay.tv.net.ApiClient;

public class MainActivity extends AppCompatActivity {
    private TextView liveCount, movieCount, seriesCount, serviceStatus;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        immersive();

        liveCount = findViewById(R.id.liveCount);
        movieCount = findViewById(R.id.movieCount);
        seriesCount = findViewById(R.id.seriesCount);
        serviceStatus = findViewById(R.id.serviceStatus);

        View live = findViewById(R.id.cardLive);
        View movies = findViewById(R.id.cardMovies);
        View series = findViewById(R.id.cardSeries);
        View settings = findViewById(R.id.btnSettings);

        focusFx(live); focusFx(movies); focusFx(series); focusFx(settings);
        live.setOnClickListener(v -> openCatalog("live", "Canais ao Vivo"));
        movies.setOnClickListener(v -> openCatalog("movie", "Filmes"));
        series.setOnClickListener(v -> openCatalog("series", "Séries"));
        settings.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));

        findViewById(R.id.btnExplore).setOnClickListener(v -> openCatalog("live", "Canais ao Vivo"));
        focusFx(findViewById(R.id.btnExplore));
        live.requestFocus();
        refresh();
    }

    @Override protected void onResume() {
        super.onResume();
        immersive();
        refresh();
    }

    private void refresh() {
        ApiClient.status(new ApiClient.Result<StatusResponse>() {
            @Override public void onSuccess(StatusResponse value) {
                runOnUiThread(() -> serviceStatus.setText("●  SERVIDOR ONLINE"));
            }
            @Override public void onError(String message) {
                runOnUiThread(() -> serviceStatus.setText("●  SERVIDOR INDISPONÍVEL"));
            }
        });
        loadCount("live", liveCount);
        loadCount("movie", movieCount);
        loadCount("series", seriesCount);
    }

    private void loadCount(String type, TextView target) {
        ApiClient.catalog(type, new ApiClient.Result<CatalogResponse>() {
            @Override public void onSuccess(CatalogResponse value) {
                int count = value.items == null ? 0 : value.items.size();
                runOnUiThread(() -> target.setText(String.valueOf(count)));
            }
            @Override public void onError(String message) {
                runOnUiThread(() -> target.setText("0"));
            }
        });
    }

    private void openCatalog(String type, String title) {
        Intent i = new Intent(this, CatalogActivity.class);
        i.putExtra("type", type);
        i.putExtra("title", title);
        startActivity(i);
    }

    private void focusFx(View v) {
        v.setOnFocusChangeListener((view, focused) -> view.animate()
                .scaleX(focused ? 1.045f : 1f)
                .scaleY(focused ? 1.045f : 1f)
                .translationZ(focused ? 14f : 0f)
                .setDuration(120)
                .start());
    }

    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }
}
