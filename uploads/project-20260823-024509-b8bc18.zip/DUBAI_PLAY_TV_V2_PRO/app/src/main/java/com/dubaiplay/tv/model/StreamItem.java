package com.dubaiplay.tv.model;

public class StreamItem {
    public long id;
    public String name;
    public String logo;
    public String group_title;

    public String group() {
        return group_title == null || group_title.trim().isEmpty() ? "Sem categoria" : group_title;
    }
}
