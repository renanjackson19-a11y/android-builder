package com.dubaiplay.tv.ui;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.dubaiplay.tv.R;
import com.dubaiplay.tv.model.StreamItem;

import java.util.ArrayList;
import java.util.List;

public class ContentAdapter extends RecyclerView.Adapter<ContentAdapter.Holder> {
    public interface Listener { void onOpen(StreamItem item); }

    private final Context context;
    private final Listener listener;
    private final List<StreamItem> items = new ArrayList<>();

    public ContentAdapter(Context context, Listener listener) {
        this.context = context;
        this.listener = listener;
    }

    public void submit(List<StreamItem> newItems) {
        items.clear();
        if (newItems != null) items.addAll(newItems);
        notifyDataSetChanged();
    }

    @NonNull @Override public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_content, parent, false);
        return new Holder(v);
    }

    @Override public void onBindViewHolder(@NonNull Holder h, int position) {
        StreamItem item = items.get(position);
        h.title.setText(item.name == null ? "Sem nome" : item.name);
        h.group.setText(item.group());
        String logo = item.logo == null ? "" : item.logo.trim();
        Glide.with(context)
                .load(logo.isEmpty() ? null : logo)
                .placeholder(R.drawable.placeholder_content)
                .error(R.drawable.placeholder_content)
                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                .centerCrop()
                .into(h.image);
        h.itemView.setOnClickListener(v -> listener.onOpen(item));
        h.itemView.setOnFocusChangeListener((v, focused) -> {
            v.animate().scaleX(focused ? 1.07f : 1f).scaleY(focused ? 1.07f : 1f)
                    .translationZ(focused ? 18f : 0f).setDuration(120).start();
            h.focus.setVisibility(focused ? View.VISIBLE : View.GONE);
        });
    }

    @Override public int getItemCount() { return items.size(); }

    static class Holder extends RecyclerView.ViewHolder {
        ImageView image;
        TextView title, group;
        View focus;
        Holder(@NonNull View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.poster);
            title = itemView.findViewById(R.id.itemTitle);
            group = itemView.findViewById(R.id.itemGroup);
            focus = itemView.findViewById(R.id.focusBorder);
        }
    }
}
