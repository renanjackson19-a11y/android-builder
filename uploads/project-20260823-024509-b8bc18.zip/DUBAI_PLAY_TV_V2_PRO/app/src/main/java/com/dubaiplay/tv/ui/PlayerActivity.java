package com.dubaiplay.tv.ui;

import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

import com.dubaiplay.tv.Config;
import com.dubaiplay.tv.R;
import com.dubaiplay.tv.net.ApiClient;

public class PlayerActivity extends AppCompatActivity {
    private ExoPlayer player;
    private PlayerView playerView;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_player);
        immersive();

        String name = getIntent().getStringExtra("name");
        String group = getIntent().getStringExtra("group");
        long id = getIntent().getLongExtra("id", 0);
        ((TextView)findViewById(R.id.playerTitle)).setText(name == null ? "Reproduzindo" : name);
        ((TextView)findViewById(R.id.playerGroup)).setText(group == null ? "Dubai Play" : group);
        findViewById(R.id.btnPlayerBack).setOnClickListener(v -> finish());

        playerView = findViewById(R.id.playerView);
        if (!Config.apiKeyConfigured()) {
            Toast.makeText(this, "Configure a chave da API do painel no aplicativo.", Toast.LENGTH_LONG).show();
            return;
        }
        String url = ApiClient.streamUrl(id);
        if (url.isEmpty()) {
            Toast.makeText(this, "Não foi possível criar a URL do conteúdo.", Toast.LENGTH_LONG).show();
            return;
        }

        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        player.setMediaItem(MediaItem.fromUri(url));
        player.addListener(new Player.Listener() {
            @Override public void onPlayerError(PlaybackException error) {
                Toast.makeText(PlayerActivity.this, "Falha ao reproduzir este conteúdo.", Toast.LENGTH_LONG).show();
            }
        });
        player.prepare();
        player.play();
    }

    @Override protected void onStop() {
        super.onStop();
        release();
    }

    @Override protected void onDestroy() {
        release();
        super.onDestroy();
    }

    private void release() {
        if (player != null) {
            player.release();
            player = null;
        }
    }

    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }
}
