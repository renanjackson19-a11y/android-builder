package com.dubaiplay.tv.model;

import java.util.ArrayList;
import java.util.List;

public class CatalogResponse {
    public String type;
    public List<StreamItem> items = new ArrayList<>();
}
