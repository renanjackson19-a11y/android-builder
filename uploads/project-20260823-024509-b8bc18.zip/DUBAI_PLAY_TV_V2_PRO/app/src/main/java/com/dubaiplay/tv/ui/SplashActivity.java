package com.dubaiplay.tv.ui;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.dubaiplay.tv.R;
import com.dubaiplay.tv.model.StatusResponse;
import com.dubaiplay.tv.net.ApiClient;

public class SplashActivity extends AppCompatActivity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean finished = false;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        setContentView(R.layout.activity_splash);

        TextView status = findViewById(R.id.splashStatus);
        ApiClient.status(new ApiClient.Result<StatusResponse>() {
            @Override public void onSuccess(StatusResponse value) {
                runOnUiThread(() -> {
                    status.setText(value.ok ? "Servidor conectado" : "Preparando aplicativo");
                    openSoon(450);
                });
            }

            @Override public void onError(String message) {
                runOnUiThread(() -> {
                    status.setText("Modo offline • tente novamente em instantes");
                    openSoon(650);
                });
            }
        });
        handler.postDelayed(() -> openSoon(0), 2200);
    }

    private void openSoon(long delay) {
        if (finished) return;
        finished = true;
        handler.postDelayed(() -> {
            startActivity(new Intent(this, MainActivity.class));
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            finish();
        }, delay);
    }
}
