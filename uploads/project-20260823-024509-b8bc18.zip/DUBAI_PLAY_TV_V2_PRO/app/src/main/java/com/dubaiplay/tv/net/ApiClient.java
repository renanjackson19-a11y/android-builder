package com.dubaiplay.tv.net;

import com.dubaiplay.tv.Config;
import com.dubaiplay.tv.model.CatalogResponse;
import com.dubaiplay.tv.model.StatusResponse;
import com.google.gson.Gson;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public final class ApiClient {
    private ApiClient() {}

    private static final Gson GSON = new Gson();
    private static final OkHttpClient CLIENT = new OkHttpClient.Builder()
            .connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .build();

    public interface Result<T> {
        void onSuccess(T value);
        void onError(String message);
    }

    public static void status(Result<StatusResponse> cb) {
        Request request = new Request.Builder()
                .url(Config.API_BASE_URL + "status.php")
                .header("Accept", "application/json")
                .build();
        execute(request, StatusResponse.class, cb);
    }

    public static void catalog(String type, Result<CatalogResponse> cb) {
        if (!Config.apiKeyConfigured()) {
            cb.onError("Chave da API ainda não configurada no aplicativo.");
            return;
        }
        HttpUrl base = HttpUrl.parse(Config.API_BASE_URL + "catalog.php");
        if (base == null) {
            cb.onError("URL da API inválida.");
            return;
        }
        HttpUrl url = base.newBuilder()
                .addQueryParameter("type", type)
                .build();
        Request request = new Request.Builder()
                .url(url)
                .header("X-API-Key", Config.API_KEY)
                .header("Accept", "application/json")
                .build();
        execute(request, CatalogResponse.class, cb);
    }

    public static String streamUrl(long id) {
        HttpUrl base = HttpUrl.parse(Config.API_BASE_URL + "stream.php");
        if (base == null) return "";
        return base.newBuilder()
                .addQueryParameter("id", String.valueOf(id))
                .addQueryParameter("key", Config.API_KEY)
                .build()
                .toString();
    }

    private static <T> void execute(Request request, Class<T> clazz, Result<T> cb) {
        CLIENT.newCall(request).enqueue(new Callback() {
            @Override public void onFailure(Call call, IOException e) {
                cb.onError(e.getMessage() == null ? "Falha de conexão." : e.getMessage());
            }

            @Override public void onResponse(Call call, Response response) {
                try (Response r = response) {
                    if (!r.isSuccessful()) {
                        cb.onError(r.code() == 401 ? "Aplicativo não autorizado pela API." : "Servidor respondeu HTTP " + r.code());
                        return;
                    }
                    if (r.body() == null) {
                        cb.onError("Resposta vazia do servidor.");
                        return;
                    }
                    T value = GSON.fromJson(r.body().charStream(), clazz);
                    if (value == null) cb.onError("Resposta inválida do servidor.");
                    else cb.onSuccess(value);
                } catch (Exception e) {
                    cb.onError("Não foi possível interpretar a resposta do painel.");
                }
            }
        });
    }
}
