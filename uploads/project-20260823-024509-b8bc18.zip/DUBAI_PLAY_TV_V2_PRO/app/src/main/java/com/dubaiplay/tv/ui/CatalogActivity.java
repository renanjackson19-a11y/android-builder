package com.dubaiplay.tv.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dubaiplay.tv.R;
import com.dubaiplay.tv.model.CatalogResponse;
import com.dubaiplay.tv.model.StreamItem;
import com.dubaiplay.tv.net.ApiClient;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class CatalogActivity extends AppCompatActivity implements ContentAdapter.Listener {
    private final List<StreamItem> all = new ArrayList<>();
    private ContentAdapter adapter;
    private ProgressBar progress;
    private TextView empty, subtitle;
    private String type;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catalog);
        immersive();

        type = getIntent().getStringExtra("type");
        if (type == null) type = "live";
        String title = getIntent().getStringExtra("title");
        if (title == null) title = "Conteúdos";

        ((TextView)findViewById(R.id.catalogTitle)).setText(title);
        subtitle = findViewById(R.id.catalogSubtitle);
        progress = findViewById(R.id.progress);
        empty = findViewById(R.id.emptyState);
        RecyclerView grid = findViewById(R.id.contentGrid);

        int width = getResources().getDisplayMetrics().widthPixels;
        int columns = width >= 1600 ? 6 : width >= 1100 ? 5 : width >= 800 ? 4 : 3;
        grid.setLayoutManager(new GridLayoutManager(this, columns));
        adapter = new ContentAdapter(this, this);
        grid.setAdapter(adapter);

        View back = findViewById(R.id.btnBack);
        back.setOnClickListener(v -> finish());
        back.requestFocus();

        EditText search = findViewById(R.id.searchBox);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { filter(s.toString()); }
            @Override public void afterTextChanged(Editable s) {}
        });

        load();
    }

    private void load() {
        progress.setVisibility(View.VISIBLE);
        empty.setVisibility(View.GONE);
        ApiClient.catalog(type, new ApiClient.Result<CatalogResponse>() {
            @Override public void onSuccess(CatalogResponse value) {
                runOnUiThread(() -> {
                    progress.setVisibility(View.GONE);
                    all.clear();
                    if (value.items != null) all.addAll(value.items);
                    adapter.submit(new ArrayList<>(all));
                    subtitle.setText(all.size() + " itens disponíveis");
                    empty.setVisibility(all.isEmpty() ? View.VISIBLE : View.GONE);
                });
            }
            @Override public void onError(String message) {
                runOnUiThread(() -> {
                    progress.setVisibility(View.GONE);
                    empty.setText(message + "\n\nConfira a integração em Config.java.");
                    empty.setVisibility(View.VISIBLE);
                    subtitle.setText("Não foi possível carregar o catálogo");
                });
            }
        });
    }

    private void filter(String q) {
        String needle = q == null ? "" : q.trim().toLowerCase(Locale.ROOT);
        if (needle.isEmpty()) {
            adapter.submit(new ArrayList<>(all));
            return;
        }
        List<StreamItem> out = new ArrayList<>();
        for (StreamItem i : all) {
            String name = i.name == null ? "" : i.name.toLowerCase(Locale.ROOT);
            String group = i.group().toLowerCase(Locale.ROOT);
            if (name.contains(needle) || group.contains(needle)) out.add(i);
        }
        adapter.submit(out);
        empty.setText("Nenhum conteúdo encontrado.");
        empty.setVisibility(out.isEmpty() ? View.VISIBLE : View.GONE);
    }

    @Override public void onOpen(StreamItem item) {
        Intent i = new Intent(this, PlayerActivity.class);
        i.putExtra("id", item.id);
        i.putExtra("name", item.name);
        i.putExtra("group", item.group());
        startActivity(i);
    }

    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }
}
