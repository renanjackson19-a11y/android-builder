GreenPlay Android 5.25 (versionCode 52500)

- Atualização OTA volta a ser detectada por quem está no 5.24.
- Filmes/séries não são escondidos por uma contagem zero transitória do provedor.
- Provedores indisponíveis continuam filtrados pelo painel.
- Logos locais do painel (greenplay_logo) têm prioridade sobre links externos.
- Sincronização de logos usa mais paralelismo e timeout menor para a biblioteca local.
- A informação de conexões do fornecedor NÃO é exibida no aplicativo.

Instale primeiro o patch v131.7 do painel e depois publique o APK 5.25 na tela Atualização do App.
