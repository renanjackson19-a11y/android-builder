package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

/** V192 — Kids, Anime e HOT usam fontes/categorias reais do painel. */
public class SmartCatalogActivity extends Activity {
    private final ArrayList<ApiClient.Item> all=new ArrayList<>();
    private final ArrayList<ApiClient.Item> visible=new ArrayList<>();
    private final ArrayList<String> sourceCategories=new ArrayList<>();
    private final ArrayList<ApiClient.HotCategory> hotCategories=new ArrayList<>();
    private final Set<String> animeIdentity=new LinkedHashSet<>();
    private GridView grid; private Adapter adapter; private LinearLayout categoryList;
    private EditText search; private TextView status;
    private String mode="kids",selected="",query=""; private boolean phone;
    private final Handler handler=new Handler(); private Runnable searchTask;

    @Override public void onCreate(Bundle b){
        super.onCreate(b); Ui.immersive(this); phone=Ui.phone(this);
        mode=clean(getIntent().getStringExtra("mode"),"kids").toLowerCase(Locale.ROOT);
        if(!"kids".equals(mode)&&!"anime".equals(mode)&&!"hot".equals(mode))mode="kids";
        setContentView(AppBackground.wrap(this,build()));
        if("hot".equals(mode))loadHot(); else discoverExactSources();
    }
    @Override protected void onResume(){super.onResume();Ui.immersive(this);if("__favorites".equals(selected))showFavorites();}

    private View build(){
        LinearLayout root=Ui.column(this); root.setBackgroundColor(Color.TRANSPARENT);
        String active="hot".equals(mode)?"HOT":("anime".equals(mode)?"ANIMES":"KIDS");
        root.addView(YellowNav.bar(this,active),new LinearLayout.LayoutParams(-1,Ui.dp(this,64)));
        LinearLayout main=new LinearLayout(this); main.setPadding(Ui.dp(this,18),Ui.dp(this,8),Ui.dp(this,18),Ui.dp(this,12));
        LinearLayout rail=Ui.column(this); rail.setPadding(Ui.dp(this,10),Ui.dp(this,8),Ui.dp(this,10),Ui.dp(this,8)); rail.setBackground(Ui.round(0xAA111315,12,this));
        search=new EditText(this); search.setSingleLine(true);search.setHint("⌕  Buscar");search.setHintTextColor(0xFFE5E5E5);search.setTextColor(Ui.TEXT);search.setTextSize(phone?11:13);search.setPadding(Ui.dp(this,14),0,Ui.dp(this,10),0);search.setBackground(Ui.stroke(0xFF3B3B3F,0xFF505055,7,this));
        rail.addView(search,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));
        TextView head=Ui.text(this,"hot".equals(mode)?"HOT • RECENTES":("anime".equals(mode)?"ANIMES • RECENTES":"KIDS • RECENTES"),phone?9:10,Ui.GREEN,true); head.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,Ui.dp(this,30));hp.topMargin=Ui.dp(this,6);rail.addView(head,hp);
        ScrollView sc=new ScrollView(this);sc.setVerticalScrollBarEnabled(false);categoryList=Ui.column(this);sc.addView(categoryList,new ScrollView.LayoutParams(-1,-2));rail.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(Ui.dp(this,phone?142:158),-1);rp.rightMargin=Ui.dp(this,14);main.addView(rail,rp);
        LinearLayout right=Ui.column(this);
        status=Ui.text(this,"CARREGANDO",phone?10:11,0xFFE9F7EE,true);status.setGravity(Gravity.CENTER);status.setLetterSpacing(0.08f);status.setBackground(Ui.round(0x520A1510,16,this));
        LinearLayout.LayoutParams stp=new LinearLayout.LayoutParams(Ui.dp(this,210),Ui.dp(this,32));stp.gravity=Gravity.CENTER_HORIZONTAL;stp.bottomMargin=Ui.dp(this,7);right.addView(status,stp);
        grid=new GridView(this);grid.setNumColumns(phone?5:6);grid.setHorizontalSpacing(Ui.dp(this,phone?7:9));grid.setVerticalSpacing(Ui.dp(this,phone?8:10));grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);grid.setClipToPadding(false);grid.setPadding(Ui.dp(this,2),0,Ui.dp(this,2),Ui.dp(this,8));adapter=new Adapter();grid.setAdapter(adapter);grid.setOnItemClickListener((p,v,pos,id)->{if(pos>=0&&pos<visible.size())open(visible.get(pos));});
        right.addView(grid,new LinearLayout.LayoutParams(-1,0,1));main.addView(right,new LinearLayout.LayoutParams(0,-1,1));root.addView(main,new LinearLayout.LayoutParams(-1,0,1));
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){query=s==null?"":s.toString().trim();if(searchTask!=null)handler.removeCallbacks(searchTask);searchTask=()->filter();handler.postDelayed(searchTask,100);}public void afterTextChanged(Editable e){}});
        return root;
    }

    // ------------------ KIDS / ANIME: descobrir CATEGORIAS exatas ------------------
    private void discoverExactSources(){
        renderSide(); status.setText("CARREGANDO");status.setVisibility(View.VISIBLE);
        final ArrayList<String> movieCats=new ArrayList<>(),seriesCats=new ArrayList<>(); final AtomicInteger p=new AtomicInteger(2);
        ApiClient.categoriesPrepared("movie",new ApiClient.Callback<List<String>>(){public void ok(List<String>x){if(x!=null)movieCats.addAll(x);finishSourceDiscovery(movieCats,seriesCats,p);}public void error(String m){finishSourceDiscovery(movieCats,seriesCats,p);}});
        ApiClient.categoriesPrepared("series",new ApiClient.Callback<List<String>>(){public void ok(List<String>x){if(x!=null)seriesCats.addAll(x);finishSourceDiscovery(movieCats,seriesCats,p);}public void error(String m){finishSourceDiscovery(movieCats,seriesCats,p);}});
    }
    private void finishSourceDiscovery(List<String> movieCats,List<String> seriesCats,AtomicInteger p){
        if(p.decrementAndGet()!=0)return;
        ArrayList<Source> sources=new ArrayList<>(); sourceCategories.clear();
        for(String c:movieCats)if(matchCategory(c)){sources.add(new Source("movie",c,-1));addCat(c);}
        for(String c:seriesCats)if(matchCategory(c)){sources.add(new Source("series",c,-1));addCat(c);}
        runOnUiThread(this::renderSide);
        if(sources.isEmpty()){runOnUiThread(()->{status.setText("Nenhuma categoria do painel para "+("kids".equals(mode)?"Kids":"Anime"));status.setVisibility(View.VISIBLE);});return;}

        // Kids exclui qualquer título que também esteja em categoria oficial de Anime.
        if("kids".equals(mode))loadAnimeIdentityThen(sources); else loadSources(sources);
    }
    private boolean matchCategory(String c){return "kids".equals(mode)?CatalogModeRules.kidsCategory(c):CatalogModeRules.animeCategory(c);}
    private void addCat(String c){for(String x:sourceCategories)if(x.equalsIgnoreCase(c))return;sourceCategories.add(c);}

    private void loadAnimeIdentityThen(List<Source> kidsSources){
        final ArrayList<String> mc=new ArrayList<>(),sc=new ArrayList<>();final AtomicInteger q=new AtomicInteger(2);
        ApiClient.categoriesPrepared("movie",new ApiClient.Callback<List<String>>(){public void ok(List<String>x){if(x!=null)for(String c:x)if(CatalogModeRules.animeCategory(c))mc.add(c);finishAnimeIdentityCats(mc,sc,q,kidsSources);}public void error(String m){finishAnimeIdentityCats(mc,sc,q,kidsSources);}});
        ApiClient.categoriesPrepared("series",new ApiClient.Callback<List<String>>(){public void ok(List<String>x){if(x!=null)for(String c:x)if(CatalogModeRules.animeCategory(c))sc.add(c);finishAnimeIdentityCats(mc,sc,q,kidsSources);}public void error(String m){finishAnimeIdentityCats(mc,sc,q,kidsSources);}});
    }
    private void finishAnimeIdentityCats(List<String> mc,List<String> sc,AtomicInteger q,List<Source> kidsSources){
        if(q.decrementAndGet()!=0)return;
        ArrayList<Source> animeSources=new ArrayList<>();for(String c:mc)animeSources.add(new Source("movie",c,-1));for(String c:sc)animeSources.add(new Source("series",c,-1));
        if(animeSources.isEmpty()){loadSources(kidsSources);return;}
        AtomicInteger pending=new AtomicInteger(animeSources.size());
        for(Source s:animeSources)fetchAll(s,items->{synchronized(animeIdentity){for(ApiClient.Item i:items)animeIdentity.add(identity(i));}if(pending.decrementAndGet()==0)loadSources(kidsSources);});
    }

    private void loadSources(List<Source> sources){
        all.clear();final AtomicInteger pending=new AtomicInteger(sources.size());
        for(Source s:sources)fetchAll(s,items->{
            synchronized(all){for(ApiClient.Item i:items){if(i==null)continue;if("kids".equals(mode)&&animeIdentity.contains(identity(i)))continue;all.add(i);}dedupeInPlace(all);sortNewest(all);}
            runOnUiThread(()->{filter();status.setVisibility(all.isEmpty()?View.VISIBLE:View.GONE);});
            if(pending.decrementAndGet()==0)runOnUiThread(()->{dedupeInPlace(all);sortNewest(all);filter();status.setVisibility(all.isEmpty()?View.VISIBLE:View.GONE);if(all.isEmpty())status.setText("Nenhum conteúdo encontrado");});
        });
    }

    // ------------------ HOT: categorias adultas reais + VOD direto ------------------
    private void loadHot(){
        renderSide();status.setText("CARREGANDO HOT");status.setVisibility(View.VISIBLE);
        ApiClient.hotCategories(new ApiClient.Callback<List<ApiClient.HotCategory>>(){
            public void ok(List<ApiClient.HotCategory> cats){
                if(cats!=null)hotCategories.addAll(cats);sourceCategories.clear();ArrayList<Source> src=new ArrayList<>();
                for(ApiClient.HotCategory h:hotCategories){addCat(clean(h.name,"HOT"));if(h.movieCount!=0||h.count==0)src.add(new Source("movie",h.name,h.sourceId));if(h.seriesCount!=0||h.count==0)src.add(new Source("series",h.name,h.sourceId));}
                runOnUiThread(SmartCatalogActivity.this::renderSide);
                if(src.isEmpty()){runOnUiThread(()->{status.setText("Nenhum filme ou série HOT disponível");status.setVisibility(View.VISIBLE);});return;}
                all.clear();AtomicInteger pending=new AtomicInteger(src.size());
                for(Source s:src)fetchAll(s,items->{synchronized(all){all.addAll(items);dedupeInPlace(all);sortNewest(all);}runOnUiThread(()->{filter();if(!all.isEmpty())status.setVisibility(View.GONE);});if(pending.decrementAndGet()==0)runOnUiThread(()->{filter();status.setVisibility(all.isEmpty()?View.VISIBLE:View.GONE);if(all.isEmpty())status.setText("Nenhum filme ou série HOT encontrado");});});
            }
            public void error(String m){runOnUiThread(()->{status.setText("Falha ao carregar HOT");status.setVisibility(View.VISIBLE);});}
        });
    }

    // Busca TODAS as páginas da categoria. Primeiro tenta snapshot preparado; próximas páginas entram em sequência.
    private void fetchAll(Source s,ItemsDone done){fetchPage(s,1,new ArrayList<>(),done);}
    private void fetchPage(Source s,int page,ArrayList<ApiClient.Item> acc,ItemsDone done){
        ApiClient.Callback<ApiClient.CatalogPage> cb=new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){if(p!=null)acc.addAll(p.items);int pages=p==null?1:Math.max(1,p.pages);if(page<pages)fetchPage(s,page+1,acc,done);else done.done(acc);}
            public void error(String m){done.done(acc);}
        };
        if(s.sourceId>=0)ApiClient.catalogAdult(s.type,page,72,s.category,s.sourceId,cb);
        else ApiClient.catalogPrepared(s.type,page,72,"",s.category,"",cb);
    }

    private void renderSide(){
        if(categoryList==null)return;categoryList.removeAllViews();addSide("Todos","");addSide("★ FAVORITOS","__favorites");for(String c:sourceCategories)addSide(c,c);
    }
    private void addSide(String label,String key){boolean sel=key.equals(selected);TextView b=Ui.text(this,label,phone?9:11,sel?Color.BLACK:0xFFE7EBE8,sel);b.setGravity(Gravity.CENTER);b.setMaxLines(1);b.setFocusable(true);b.setClickable(true);b.setPadding(Ui.dp(this,8),0,Ui.dp(this,8),0);Ui.focus(b,this,sel?Ui.gradient(Ui.GREEN,Ui.GREEN_2,7,this):Ui.round(0xFF3A3A3E,7,this),Ui.stroke(0xFF45454A,Ui.GREEN,7,this));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,Ui.dp(this,40));p.topMargin=Ui.dp(this,4);categoryList.addView(b,p);b.setOnClickListener(v->{selected=key;if("__favorites".equals(key))showFavorites();else{filter();renderSide();}});}
    private void showFavorites(){visible.clear();for(ApiClient.Item i:LocalStore.favorites(this)){if(i==null)continue;if(!"movie".equals(i.type)&&!"series".equals(i.type))continue;if("hot".equals(mode)){boolean ok=false;for(String c:sourceCategories)if(clean(i.group,"").equalsIgnoreCase(c)){ok=true;break;}if(!ok)continue;}else{boolean ok="kids".equals(mode)?CatalogModeRules.kidsCategory(i.group):CatalogModeRules.animeCategory(i.group);if(!ok)continue;}visible.add(i);}sortNewest(visible);adapter.notifyDataSetChanged();status.setVisibility(visible.isEmpty()?View.VISIBLE:View.GONE);if(visible.isEmpty())status.setText("Nenhum favorito aqui");renderSide();}
    private void filter(){
        if("__favorites".equals(selected)){showFavorites();return;}visible.clear();String q=query.toLowerCase(Locale.ROOT);
        synchronized(all){for(ApiClient.Item i:all){if(i==null)continue;if(!selected.isEmpty()&&!clean(i.group,"").equalsIgnoreCase(selected))continue;if(!q.isEmpty()&&!(clean(i.name,"")+" "+clean(i.group,"")).toLowerCase(Locale.ROOT).contains(q))continue;visible.add(i);}}
        adapter.notifyDataSetChanged();if(!visible.isEmpty())grid.requestFocus();
    }
    private void open(ApiClient.Item i){if(i==null)return;if("series".equals(i.type)){Intent s=new Intent(this,SeriesActivity.class);s.putExtra("id",i.id);s.putExtra("title",clean(i.seriesTitle,i.name));s.putExtra("name",i.name);s.putExtra("logo",i.logo);s.putExtra("backdrop",i.backdrop);s.putExtra("synopsis",i.synopsis);s.putExtra("group",i.group);s.putExtra("year",i.year);startActivity(s);}else{Intent d=new Intent(this,DetailActivity.class);MainActivity.putItem(d,i);startActivity(d);}}

    private void dedupeInPlace(List<ApiClient.Item> list){LinkedHashMap<String,ApiClient.Item> map=new LinkedHashMap<>();for(ApiClient.Item i:new ArrayList<>(list)){if(i==null)continue;String k=identity(i);ApiClient.Item old=map.get(k);if(old==null||score(i)>score(old))map.put(k,i);}list.clear();list.addAll(map.values());}
    private String identity(ApiClient.Item i){String n=clean(i.seriesTitle,clean(i.name,"")).toLowerCase(Locale.ROOT).replaceAll("\\([^)]*\\)","").replaceAll("[^a-z0-9áàâãéêíóôõúç]+"," ").trim();return n+"|"+i.year;}
    private int score(ApiClient.Item i){return (clean(i.logo,"").isEmpty()?0:2)+(clean(i.backdrop,"").isEmpty()?0:3)+(clean(i.synopsis,"").isEmpty()?0:1);}
    private void sortNewest(List<ApiClient.Item> l){Collections.sort(l,(a,b)->{int ay=a==null?0:a.year,by=b==null?0:b.year;if(ay!=by)return Integer.compare(by,ay);return Long.compare(b==null?0:b.id,a==null?0:a.id);});}
    private String clean(String s,String fallback){if(s==null)return fallback;String x=s.trim();return x.isEmpty()||"null".equalsIgnoreCase(x)?fallback:x;}
    @Override public void onBackPressed(){AppExit.confirm(this);}

    private static class Source{String type,category;int sourceId;Source(String t,String c,int s){type=t;category=c;sourceId=s;}}
    private interface ItemsDone{void done(ArrayList<ApiClient.Item> items);}

    private class Adapter extends BaseAdapter{
        public int getCount(){return visible.size();}public Object getItem(int p){return visible.get(p);}public long getItemId(int p){return visible.get(p).id;}
        public View getView(int pos,View reuse,android.view.ViewGroup parent){ApiClient.Item i=visible.get(pos);LinearLayout card=reuse instanceof LinearLayout?(LinearLayout)reuse:Ui.column(SmartCatalogActivity.this);card.removeAllViews();card.setFocusable(true);card.setClickable(true);card.setPadding(Ui.dp(SmartCatalogActivity.this,2),Ui.dp(SmartCatalogActivity.this,2),Ui.dp(SmartCatalogActivity.this,2),Ui.dp(SmartCatalogActivity.this,3));Ui.focus(card,SmartCatalogActivity.this,Ui.round(0x20000000,5,SmartCatalogActivity.this),Ui.stroke(0x33182218,Ui.GREEN,5,SmartCatalogActivity.this));ImageView img=new ImageView(SmartCatalogActivity.this);img.setScaleType(ImageView.ScaleType.CENTER_CROP);img.setBackgroundColor(0xFF101612);ImageLoader.intoPoster(SmartCatalogActivity.this,img,clean(i.logo,i.backdrop));card.addView(img,new LinearLayout.LayoutParams(-1,Ui.dp(SmartCatalogActivity.this,phone?150:198)));TextView n=Ui.text(SmartCatalogActivity.this,clean(i.name,"Conteúdo"),phone?9:11,Color.WHITE,false);n.setMaxLines(1);n.setPadding(Ui.dp(SmartCatalogActivity.this,5),Ui.dp(SmartCatalogActivity.this,4),Ui.dp(SmartCatalogActivity.this,4),0);card.addView(n,new LinearLayout.LayoutParams(-1,Ui.dp(SmartCatalogActivity.this,phone?27:30)));TextView sub=Ui.text(SmartCatalogActivity.this,i.year>0?String.valueOf(i.year):clean(i.group,""),phone?8:9,0xFFAEB8B1,false);sub.setMaxLines(1);sub.setPadding(Ui.dp(SmartCatalogActivity.this,5),0,0,0);card.addView(sub,new LinearLayout.LayoutParams(-1,Ui.dp(SmartCatalogActivity.this,phone?22:25)));card.setOnClickListener(v->open(i));return card;}
    }
}
