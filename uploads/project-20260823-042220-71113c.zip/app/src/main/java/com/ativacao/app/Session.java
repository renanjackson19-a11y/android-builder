package com.ativacao.app;

import android.content.Context;
import android.content.SharedPreferences;

final class Session {
    private static final String PREF = "dubai_play_session";
    private static final String LOGGED = "logged";
    private static final String USER = "user";
    private static final String EXPIRES = "expires";
    private Session() {}

    static boolean isLogged(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean(LOGGED, false);
    }

    static void save(Context c, String user, String expires) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putBoolean(LOGGED, true)
                .putString(USER, user == null ? "" : user)
                .putString(EXPIRES, expires == null ? "" : expires)
                .apply();
    }

    static String user(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(USER, "");
    }

    static String expires(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(EXPIRES, "");
    }

    static void clear(Context c) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().apply();
    }
}
