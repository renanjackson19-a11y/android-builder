package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class CatalogActivity extends Activity {
    private final List<ApiClient.Item> items = new ArrayList<>();
    private GridView grid;
    private TextView status;
    private LinearLayout categoryRow;
    private Adapter adapter;
    private String type;
    private String query = "";
    private String category = "";
    private String smart = "";
    private int page = 1, pages = 1, total = 0;
    private boolean loading = false;
    private final Handler handler = new Handler();
    private Runnable searchTask;
    private boolean phone;
    private boolean portrait;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b); immersive(); phone = Ui.phone(this); portrait = Ui.portrait(this);
        type = clean(getIntent().getStringExtra("type"), "live");
        category = clean(getIntent().getStringExtra("category"), "");
        smart = clean(getIntent().getStringExtra("smart"), "");
        setContentView(build()); load(1, true);
    }

    private View build() {
        LinearLayout root = Ui.column(this); root.setBackgroundColor(Ui.BG);
        LinearLayout content = Ui.column(this); int side = phone ? 12 : 24;
        content.setPadding(Ui.dp(this, side), Ui.dp(this, 10), Ui.dp(this, side), Ui.dp(this, 10));

        String titleText = clean(getIntent().getStringExtra("title"), titleFor(type));
        TextView back = Ui.button(this, "‹  VOLTAR"); back.setOnClickListener(v -> finish());
        TextView title = Ui.text(this, titleText, phone ? 21 : 25, Ui.TEXT, true); title.setMaxLines(1);
        EditText search = new EditText(this); search.setHint("Pesquisar em " + titleText.toLowerCase() + "..."); search.setHintTextColor(Ui.MUTED); search.setTextColor(Ui.TEXT);
        search.setTextSize(phone ? 13 : 14); search.setSingleLine(true); search.setPadding(Ui.dp(this,14),0,Ui.dp(this,14),0); search.setBackground(Ui.stroke(Ui.PANEL_2,Ui.BORDER,12,this));

        LinearLayout bar = new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.addView(back,new LinearLayout.LayoutParams(Ui.dp(this,phone?112:145),Ui.dp(this,42)));
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0,Ui.dp(this,42),1); tp.leftMargin=Ui.dp(this,10); bar.addView(title,tp);
        bar.addView(search,new LinearLayout.LayoutParams(Ui.dp(this,phone?245:330),Ui.dp(this,40)));
        content.addView(bar,new LinearLayout.LayoutParams(-1,Ui.dp(this,46)));

        TextView categoryLabel = Ui.text(this, categoryHeading(), phone?12:13, Ui.MUTED, true);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-1,Ui.dp(this,26)); clp.topMargin=Ui.dp(this,5); content.addView(categoryLabel,clp);
        HorizontalScrollView catScroll = new HorizontalScrollView(this); catScroll.setHorizontalScrollBarEnabled(false);
        categoryRow = new LinearLayout(this); categoryRow.setGravity(Gravity.CENTER_VERTICAL); categoryRow.setPadding(0,Ui.dp(this,2),0,0); catScroll.addView(categoryRow);
        content.addView(catScroll,new LinearLayout.LayoutParams(-1,Ui.dp(this,44)));

        status = Ui.text(this,"Carregando...",11,Ui.MUTED,false); content.addView(status,new LinearLayout.LayoutParams(-1,Ui.dp(this,28)));

        grid = new GridView(this);
        int cols;
        if (phone) {
            if ("live".equals(type)) cols = 5;
            else cols = 4;
        } else {
            int sw=Ui.sw(this); cols = sw < 1000 ? 5 : 7; if ("live".equals(type)) cols++;
        }
        grid.setNumColumns(cols); grid.setHorizontalSpacing(Ui.dp(this,8)); grid.setVerticalSpacing(Ui.dp(this,9)); grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH); grid.setSelector(android.R.color.transparent); grid.setPadding(0,Ui.dp(this,3),0,Ui.dp(this,10));
        adapter = new Adapter(); grid.setAdapter(adapter); content.addView(grid,new LinearLayout.LayoutParams(-1,0,1));
        grid.setOnScrollListener(new AbsListView.OnScrollListener(){ public void onScrollStateChanged(AbsListView v,int s){} public void onScroll(AbsListView v,int first,int visible,int count){ if(count>0 && !loading && page<pages && first+visible>=count-5) load(page+1,false); }});
        search.addTextChangedListener(new TextWatcher(){ public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){ query=s==null?"":s.toString(); if(searchTask!=null)handler.removeCallbacks(searchTask); searchTask=()->load(1,true); handler.postDelayed(searchTask,360);} public void afterTextChanged(Editable e){} });

        FrameLayout centered = Ui.centered(this,content,1260); root.addView(centered,new LinearLayout.LayoutParams(-1,-1)); back.requestFocus(); return root;
    }

    private String categoryHeading(){ if("live".equals(type)) return "CATEGORIAS DE CANAIS"; if("movie".equals(type)) return "CATEGORIAS DE FILMES"; return "CATEGORIAS DE SÉRIES"; }

    private void renderCategories(List<String> cats) {
        categoryRow.removeAllViews();
        addSmartChip("TODOS", "");
        if ("live".equals(type)) {
            TextView today=Ui.primaryButton(this,"⚽ FUTEBOL HOJE"); today.setOnClickListener(v->startActivity(new Intent(this,FootballActivity.class))); addCatButton(today);
            addSmartChip("FUTEBOL", "football"); addSmartChip("📰 NOTÍCIAS", "news"); addSmartChip("👶 KIDS", "kids"); addSmartChip("♫ MÚSICA", "music");
        } else if ("movie".equals(type)) {
            addSmartChip("★ LANÇAMENTOS", "launch"); addSmartChip("👶 KIDS", "kids"); addSmartChip("ANIMES", "anime");
        } else {
            addSmartChip("★ LANÇAMENTOS", "launch"); addSmartChip("ANIMES", "anime"); addSmartChip("👶 KIDS", "kids"); addSmartChip("NOVELAS", "novela");
        }
        int max=Math.min(cats.size(),50);
        for(int i=0;i<max;i++){
            String c=clean(cats.get(i),""); if(c.isEmpty()) continue;
            TextView b=Ui.button(this,c.toUpperCase()); b.setMaxLines(1); b.setOnClickListener(v->{category=c;smart="";load(1,true);}); addCatButton(b);
        }
    }

    private void addSmartChip(String label,String smartKey){TextView b=smartKey.equals(smart)?Ui.primaryButton(this,label):Ui.button(this,label);b.setMaxLines(1);b.setOnClickListener(v->{category="";smart=smartKey;load(1,true);});addCatButton(b);}
    private void addCatButton(TextView b){ LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,Ui.dp(this,36));p.rightMargin=Ui.dp(this,6);categoryRow.addView(b,p); }

    private void load(int target, boolean reset) {
        if (loading) return; loading=true; if(reset) status.setText("Buscando no catálogo..."); int limit = phone ? 40 : 48;
        ApiClient.catalog(type,target,limit,query,category,smart,new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){runOnUiThread(()->{ loading=false; page=p.page; pages=p.pages; total=p.total; if(reset) items.clear(); items.addAll(p.items); adapter.notifyDataSetChanged(); if(reset) renderCategories(p.categories);
                String prefix=!category.isEmpty()?category+" • ":(!smart.isEmpty()?smartLabel(smart)+" • ":"");
                status.setText(prefix+items.size()+" de "+total+("series".equals(type)?" séries":" itens")+(pages>1?" • página "+page+"/"+pages:"")); if(reset&&!items.isEmpty()) grid.requestFocus(); });}
            public void error(String m){runOnUiThread(()->{loading=false;status.setText("Não foi possível carregar • "+m);});}
        });
    }

    private String smartLabel(String s){if("launch".equals(s))return"Lançamentos";if("football".equals(s))return"Futebol";if("news".equals(s))return"Notícias";if("kids".equals(s))return"Kids";if("music".equals(s))return"Música";if("anime".equals(s))return"Animes";if("novela".equals(s))return"Novelas";return s;}

    private class Adapter extends BaseAdapter {
        public int getCount(){return items.size();} public Object getItem(int p){return items.get(p);} public long getItemId(int p){return items.get(p).id;}
        public View getView(int p,View convert,android.view.ViewGroup parent){
            LinearLayout card; ImageView image; TextView title,meta; boolean live="live".equals(type);
            int imageH;
            if(live) imageH = phone ? 76 : 96;
            else imageH = phone ? 126 : 150;
            if(convert==null){ card=Ui.column(CatalogActivity.this); card.setPadding(Ui.dp(CatalogActivity.this,6),Ui.dp(CatalogActivity.this,6),Ui.dp(CatalogActivity.this,6),Ui.dp(CatalogActivity.this,6)); card.setFocusable(true); card.setClickable(true); Ui.focus(card,CatalogActivity.this);
                image=new ImageView(CatalogActivity.this); image.setId(101); image.setScaleType(live?ImageView.ScaleType.CENTER_INSIDE:ImageView.ScaleType.CENTER_CROP); image.setBackgroundColor(Ui.PANEL_2); card.addView(image,new LinearLayout.LayoutParams(-1,Ui.dp(CatalogActivity.this,imageH)));
                title=Ui.text(CatalogActivity.this,"",phone?11:12,Ui.TEXT,true); title.setId(102); title.setMaxLines(2); card.addView(title,new LinearLayout.LayoutParams(-1,Ui.dp(CatalogActivity.this,36)));
                meta=Ui.text(CatalogActivity.this,"",9,Ui.MUTED,false); meta.setId(103); meta.setMaxLines(1); card.addView(meta,new LinearLayout.LayoutParams(-1,Ui.dp(CatalogActivity.this,18))); convert=card;
            } else card=(LinearLayout)convert;
            image=convert.findViewById(101); title=convert.findViewById(102); meta=convert.findViewById(103); android.view.ViewGroup.LayoutParams ip=image.getLayoutParams(); ip.height=Ui.dp(CatalogActivity.this,imageH); image.setLayoutParams(ip); image.setScaleType(live?ImageView.ScaleType.CENTER_INSIDE:ImageView.ScaleType.CENTER_CROP);
            ApiClient.Item item=items.get(p); title.setText(clean(item.name,"Sem nome")); String m=clean(item.group,live?"Ao vivo":"Dubai Play"); if("series".equals(type) && item.episodeCount>0) m=(item.seasonCount>0?item.seasonCount+" temp. • ":"")+item.episodeCount+" episódios"; else if(item.year>0)m+=" • "+item.year; meta.setText(m); ImageLoader.into(CatalogActivity.this,image,item.logo);
            card.setOnClickListener(v->{ if("series".equals(type)){Intent in=new Intent(CatalogActivity.this,SeriesActivity.class);in.putExtra("title",clean(item.seriesTitle,item.name));in.putExtra("name",item.name);in.putExtra("logo",item.logo);in.putExtra("backdrop",item.backdrop);startActivity(in);}else{Intent in=new Intent(CatalogActivity.this,PlayerActivity.class);in.putExtra("id",item.id);in.putExtra("name",item.name);in.putExtra("group",item.group);in.putExtra("type",type);in.putExtra("format",item.format);startActivity(in);} }); return convert;
        }
    }

    private String titleFor(String t){if("live".equals(t))return"Canais ao Vivo";if("movie".equals(t))return"Filmes";return"Séries";}
    private String clean(String v,String fallback){if(v==null)return fallback;String s=v.trim();return s.isEmpty()||"null".equalsIgnoreCase(s)?fallback:s;}
    private void immersive(){getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);}
}
