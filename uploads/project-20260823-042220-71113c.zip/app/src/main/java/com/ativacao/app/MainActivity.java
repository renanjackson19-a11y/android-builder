package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends Activity {
    private TextView server, liveCount, movieCount, seriesCount;
    private TextView heroTitle, heroMeta, heroText, heroPlay;
    private ImageView heroImage;
    private LinearLayout liveRow, movieRow, seriesRow;
    private ApiClient.Item heroItem;
    private boolean phone;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        if (!Session.isLogged(this)) { startActivity(new Intent(this, LoginActivity.class)); finish(); return; }
        phone = Ui.phone(this);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        immersive();
        setContentView(build());
        refresh();
    }

    @Override protected void onResume() { super.onResume(); immersive(); }

    private View build() {
        LinearLayout root = Ui.column(this);
        root.setBackgroundColor(Ui.BG);
        buildHeader(root);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);

        LinearLayout content = Ui.column(this);
        int side = phone ? 16 : 28;
        content.setPadding(Ui.dp(this, side), Ui.dp(this, phone ? 10 : 18), Ui.dp(this, side), Ui.dp(this, 28));

        content.addView(buildHero(), new LinearLayout.LayoutParams(-1, Ui.dp(this, phone ? 176 : 238)));
        content.addView(buildStats(), new LinearLayout.LayoutParams(-1, Ui.dp(this, phone ? 82 : 100)));

        liveRow = addShelf(content, "Canais ao vivo", "VER TODOS", "live", phone ? 132 : 170, true);
        movieRow = addShelf(content, "Filmes em destaque", "VER TODOS", "movie", phone ? 178 : 214, false);
        seriesRow = addShelf(content, "Séries em destaque", "VER TODOS", "series", phone ? 178 : 214, false);

        FrameLayout centered = Ui.centered(this, content, 1180);
        scroll.addView(centered, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        return root;
    }

    private void buildHeader(LinearLayout root) {
        LinearLayout inner = new LinearLayout(this);
        inner.setGravity(Gravity.CENTER_VERTICAL);
        inner.setPadding(Ui.dp(this, phone ? 14 : 20), Ui.dp(this, 6), Ui.dp(this, phone ? 14 : 20), Ui.dp(this, 6));
        inner.setBackgroundColor(Ui.BG_2);

        TextView logo = Ui.text(this, "▶", phone ? 14 : 17, Color.WHITE, true);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(Ui.gradient(Color.rgb(49, 223, 94), Color.rgb(19, 139, 55), 12, this));
        inner.addView(logo, new LinearLayout.LayoutParams(Ui.dp(this, phone ? 38 : 44), Ui.dp(this, phone ? 38 : 44)));

        TextView brand = Ui.text(this, "DUBAI PLAY", phone ? 16 : 21, Ui.TEXT, true);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(Ui.dp(this, phone ? 142 : 190), Ui.dp(this, 42));
        bp.leftMargin = Ui.dp(this, 10);
        inner.addView(brand, bp);

        TextView home = nav("INÍCIO"), live = nav("AO VIVO"), movie = nav("FILMES"), series = nav("SÉRIES");
        live.setOnClickListener(v -> open("live", "Canais ao Vivo"));
        movie.setOnClickListener(v -> open("movie", "Filmes"));
        series.setOnClickListener(v -> open("series", "Séries"));
        int navW = phone ? 72 : 88;
        inner.addView(home, new LinearLayout.LayoutParams(Ui.dp(this, navW), Ui.dp(this, 38)));
        inner.addView(live, new LinearLayout.LayoutParams(Ui.dp(this, navW + 8), Ui.dp(this, 38)));
        inner.addView(movie, new LinearLayout.LayoutParams(Ui.dp(this, navW), Ui.dp(this, 38)));
        inner.addView(series, new LinearLayout.LayoutParams(Ui.dp(this, navW), Ui.dp(this, 38)));

        inner.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1));
        server = Ui.text(this, "● CONECTANDO", phone ? 9 : 11, Ui.MUTED, true);
        server.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        inner.addView(server, new LinearLayout.LayoutParams(Ui.dp(this, phone ? 105 : 170), Ui.dp(this, 38)));

        TextView settings = Ui.button(this, "⚙");
        settings.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(Ui.dp(this, phone ? 42 : 50), Ui.dp(this, 38));
        sp.leftMargin = Ui.dp(this, 6);
        inner.addView(settings, sp);

        FrameLayout shell = Ui.centered(this, inner, 1280);
        shell.setBackgroundColor(Ui.BG_2);
        root.addView(shell, new LinearLayout.LayoutParams(-1, Ui.dp(this, phone ? 52 : 58)));
        home.requestFocus();
    }

    private View buildHero() {
        FrameLayout hero = new FrameLayout(this);
        hero.setBackground(Ui.stroke(Color.rgb(8, 15, 19), Color.rgb(31, 71, 45), 18, this));
        hero.setClipToOutline(true);

        heroImage = new ImageView(this);
        heroImage.setScaleType(ImageView.ScaleType.CENTER_CROP);
        heroImage.setAlpha(.58f);
        heroImage.setBackgroundColor(Color.rgb(8, 17, 14));
        hero.addView(heroImage, new FrameLayout.LayoutParams(-1, -1));
        View shade = new View(this);
        shade.setBackground(new ColorDrawable(0x8A000000));
        hero.addView(shade, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout info = Ui.column(this);
        int hp = phone ? 20 : 32;
        info.setPadding(Ui.dp(this, hp), Ui.dp(this, phone ? 12 : 20), Ui.dp(this, hp), Ui.dp(this, 12));
        TextView badge = Ui.text(this, "DUBAI PLAY • DESTAQUE", phone ? 9 : 11, Ui.GREEN, true);
        info.addView(badge, new LinearLayout.LayoutParams(-1, Ui.dp(this, 20)));

        heroTitle = Ui.text(this, "Carregando seu catálogo...", phone ? 23 : 31, Color.WHITE, true);
        heroTitle.setMaxLines(1);
        info.addView(heroTitle, new LinearLayout.LayoutParams(-1, Ui.dp(this, phone ? 42 : 50)));

        heroMeta = Ui.text(this, "Ao vivo • Filmes • Séries", phone ? 10 : 13, Color.rgb(220, 229, 223), true);
        heroMeta.setMaxLines(1);
        info.addView(heroMeta, new LinearLayout.LayoutParams(-1, Ui.dp(this, 24)));

        heroText = Ui.text(this, "Categorias organizadas dentro de cada seção.", phone ? 10 : 13, Color.rgb(177, 193, 183), false);
        heroText.setMaxLines(2);
        info.addView(heroText, new LinearLayout.LayoutParams(-1, Ui.dp(this, phone ? 34 : 44)));

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        heroPlay = Ui.primaryButton(this, "▶  ASSISTIR");
        heroPlay.setOnClickListener(v -> playHero());
        TextView movies = Ui.button(this, "FILMES");
        movies.setOnClickListener(v -> open("movie", "Filmes"));
        actions.addView(heroPlay, new LinearLayout.LayoutParams(Ui.dp(this, phone ? 140 : 182), Ui.dp(this, phone ? 38 : 44)));
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(Ui.dp(this, phone ? 94 : 136), Ui.dp(this, phone ? 38 : 44));
        mp.leftMargin = Ui.dp(this, 8);
        actions.addView(movies, mp);
        info.addView(actions);
        hero.addView(info, new FrameLayout.LayoutParams(-1, -1));
        return hero;
    }

    private View buildStats() {
        LinearLayout row = new LinearLayout(this);
        row.setPadding(0, Ui.dp(this, 10), 0, 0);
        liveCount = statCard(row, "AO VIVO", "—", Ui.GREEN, "live");
        movieCount = statCard(row, "FILMES", "—", Color.rgb(76, 225, 108), "movie");
        seriesCount = statCard(row, "SÉRIES", "—", Color.rgb(120, 239, 119), "series");
        return row;
    }

    private TextView statCard(LinearLayout row, String title, String value, int accent, String type) {
        LinearLayout card = Ui.column(this);
        card.setPadding(Ui.dp(this, phone ? 12 : 16), Ui.dp(this, phone ? 7 : 10), Ui.dp(this, 12), Ui.dp(this, 6));
        card.setFocusable(true); card.setClickable(true);
        Ui.focus(card, this, Ui.stroke(Color.rgb(10, 20, 27), Color.rgb(31, 61, 48), 14, this), Ui.stroke(Color.rgb(12, 31, 22), Ui.GREEN, 14, this));
        card.setOnClickListener(v -> open(type, titleFor(type)));
        TextView t = Ui.text(this, title, phone ? 9 : 10, accent, true);
        card.addView(t, new LinearLayout.LayoutParams(-1, Ui.dp(this, 18)));
        TextView count = Ui.text(this, value, phone ? 20 : 26, Ui.TEXT, true);
        card.addView(count, new LinearLayout.LayoutParams(-1, Ui.dp(this, phone ? 28 : 34)));
        TextView sub = Ui.text(this, "no catálogo", 8, Ui.MUTED, false);
        card.addView(sub, new LinearLayout.LayoutParams(-1, Ui.dp(this, 16)));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, Ui.dp(this, phone ? 70 : 86), 1);
        p.rightMargin = Ui.dp(this, 10);
        row.addView(card, p);
        return count;
    }

    private LinearLayout addShelf(LinearLayout content, String titleText, String actionText, String type, int height, boolean live) {
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = Ui.text(this, titleText, phone ? 15 : 20, Ui.TEXT, true);
        TextView action = Ui.text(this, actionText, phone ? 9 : 11, Ui.GREEN, true);
        action.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        action.setFocusable(true); action.setClickable(true);
        action.setOnClickListener(v -> open(type, titleFor(type)));
        head.addView(title, new LinearLayout.LayoutParams(0, Ui.dp(this, phone ? 32 : 42), 1));
        head.addView(action, new LinearLayout.LayoutParams(Ui.dp(this, phone ? 78 : 100), Ui.dp(this, phone ? 32 : 42)));
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, Ui.dp(this, phone ? 36 : 46));
        hp.topMargin = Ui.dp(this, phone ? 6 : 10);
        content.addView(head, hp);

        HorizontalScrollView sc = new HorizontalScrollView(this);
        sc.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        sc.addView(row);
        content.addView(sc, new LinearLayout.LayoutParams(-1, Ui.dp(this, height)));
        return row;
    }

    private TextView nav(String label) {
        TextView t = Ui.text(this, label, phone ? 9 : 11, Ui.MUTED, true);
        t.setGravity(Gravity.CENTER); t.setFocusable(true); t.setClickable(true);
        Ui.focus(t, this, Ui.round(Color.TRANSPARENT, 10, this), Ui.stroke(Color.rgb(12, 28, 19), Ui.GREEN, 10, this));
        return t;
    }

    private void refresh() {
        server.setText("● CONECTANDO"); server.setTextColor(Ui.MUTED);
        ApiClient.status(new ApiClient.Callback<String>() {
            public void ok(String s) { runOnUiThread(() -> { server.setText(phone ? "● ONLINE" : "● SERVIDOR ONLINE"); server.setTextColor(Ui.GREEN); }); }
            public void error(String m) { runOnUiThread(() -> { server.setText("● OFFLINE"); server.setTextColor(Ui.RED); }); }
        });
        ApiClient.home(new ApiClient.Callback<ApiClient.HomeData>() {
            public void ok(ApiClient.HomeData h) { runOnUiThread(() -> applyHome(h)); }
            public void error(String m) { runOnUiThread(() -> showHomeError(m)); }
        });
    }

    private void showHomeError(String message) {
        server.setText("● ERRO"); server.setTextColor(Ui.RED);
        liveCount.setText("—"); movieCount.setText("—"); seriesCount.setText("—");
        heroItem = null;
        heroTitle.setText("Não foi possível conectar ao catálogo");
        heroMeta.setText("Verifique a conexão com o painel");
        heroText.setText(clean(message, "Falha de comunicação com o servidor."));
        heroPlay.setText("↻  TENTAR NOVAMENTE");
        heroPlay.setVisibility(View.VISIBLE);
        heroPlay.setOnClickListener(v -> { heroPlay.setText("CONECTANDO..."); refresh(); });
        liveRow.removeAllViews(); movieRow.removeAllViews(); seriesRow.removeAllViews();
    }

    private void applyHome(ApiClient.HomeData h) {
        server.setText(phone ? "● ONLINE" : "● SERVIDOR ONLINE"); server.setTextColor(Ui.GREEN);
        liveCount.setText(String.valueOf(h.liveCount)); movieCount.setText(String.valueOf(h.movieCount)); seriesCount.setText(String.valueOf(h.seriesCount));
        heroItem = h.hero;
        heroPlay.setText("▶  ASSISTIR"); heroPlay.setOnClickListener(v -> playHero());
        if (h.hero != null) {
            heroTitle.setText(clean(h.hero.name, "Destaque Dubai Play"));
            String meta = clean(h.hero.group, "Destaque Dubai Play"); if (h.hero.year > 0) meta += " • " + h.hero.year;
            heroMeta.setText(meta);
            heroText.setText(clean(h.hero.synopsis, "Assista agora no Dubai Play."));
            String img = clean(h.hero.backdrop, ""); if (img.isEmpty()) img = clean(h.hero.logo, ""); ImageLoader.into(this, heroImage, img);
            heroPlay.setVisibility(View.VISIBLE);
        } else {
            heroTitle.setText("Dubai Play"); heroMeta.setText("Catálogo conectado"); heroText.setText("Seu conteúdo está pronto para navegar por categorias."); heroPlay.setVisibility(View.GONE);
        }
        renderShelf(liveRow, h.live, true); renderShelf(movieRow, h.movies, false); renderShelf(seriesRow, h.series, false);
    }

    private void renderShelf(LinearLayout row, List<ApiClient.Item> items, boolean live) {
        row.removeAllViews();
        int max = Math.min(items.size(), 16);
        for (int i = 0; i < max; i++) {
            ApiClient.Item item = items.get(i);
            LinearLayout card = Ui.column(this);
            card.setFocusable(true); card.setClickable(true);
            card.setPadding(Ui.dp(this, 5), Ui.dp(this, 5), Ui.dp(this, 5), Ui.dp(this, 5));
            Ui.focus(card, this, Ui.stroke(Color.rgb(10, 19, 28), Color.rgb(29, 55, 67), 12, this), Ui.stroke(Color.rgb(11, 28, 20), Ui.GREEN, 12, this));
            ImageView image = new ImageView(this);
            image.setScaleType(live ? ImageView.ScaleType.CENTER_INSIDE : ImageView.ScaleType.CENTER_CROP);
            image.setBackgroundColor(Ui.PANEL_2);
            int w = phone ? (live ? 112 : 124) : (live ? 150 : 172);
            int ih = phone ? (live ? 62 : 105) : (live ? 100 : 142);
            card.addView(image, new LinearLayout.LayoutParams(-1, Ui.dp(this, ih)));
            TextView n = Ui.text(this, clean(item.name, "Sem nome"), phone ? 9 : 11, Ui.TEXT, true);
            n.setMaxLines(2); card.addView(n, new LinearLayout.LayoutParams(-1, Ui.dp(this, phone ? 29 : 34)));
            TextView g = Ui.text(this, clean(item.group, live ? "Ao vivo" : "Dubai Play"), phone ? 8 : 9, Ui.MUTED, false);
            g.setMaxLines(1); card.addView(g, new LinearLayout.LayoutParams(-1, Ui.dp(this, 16)));
            ImageLoader.into(this, image, item.logo);
            card.setOnClickListener(v -> openPlayer(item));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(Ui.dp(this, w), Ui.dp(this, ih + (phone ? 52 : 60)));
            p.rightMargin = Ui.dp(this, 8); row.addView(card, p);
        }
    }

    private void openPlayer(ApiClient.Item item) {
        String t = item.type == null || item.type.isEmpty() ? "movie" : item.type;
        if ("series".equals(t)) {
            Intent in = new Intent(this, SeriesActivity.class);
            in.putExtra("title", clean(item.seriesTitle, item.name)); in.putExtra("name", item.name); in.putExtra("logo", item.logo); in.putExtra("backdrop", item.backdrop);
            startActivity(in); return;
        }
        Intent in = new Intent(this, PlayerActivity.class);
        in.putExtra("id", item.id); in.putExtra("name", item.name); in.putExtra("group", item.group); in.putExtra("type", t); in.putExtra("format", item.format); in.putExtra("synopsis", item.synopsis);
        startActivity(in);
    }

    private void playHero() { if (heroItem != null) openPlayer(heroItem); }
    private void open(String type, String title) { Intent i = new Intent(this, CatalogActivity.class); i.putExtra("type", type); i.putExtra("title", title); startActivity(i); }
    private String titleFor(String type) { if ("live".equals(type)) return "Canais ao Vivo"; if ("movie".equals(type)) return "Filmes"; return "Séries"; }
    private String clean(String v, String fallback) { if (v == null) return fallback; String s = v.trim(); return s.isEmpty() || "null".equalsIgnoreCase(s) ? fallback : s; }
    private void immersive() { getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION); }
}
