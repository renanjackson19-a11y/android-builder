package com.ativacao.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public class LoginActivity extends Activity {
    private EditText user;
    private EditText pass;
    private TextView message;
    private TextView serverBadge;
    private TextView enter;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        immersive();
        if (Session.isLogged(this)) {
            openHome();
            return;
        }
        setContentView(build());
        checkServer();
    }

    @Override protected void onResume() { super.onResume(); immersive(); }

    private View build() {
        boolean phone = Ui.phone(this), portrait = Ui.portrait(this);
        FrameLayout root = new FrameLayout(this);
        root.setBackground(makeBackground());

        android.widget.ScrollView scroll = new android.widget.ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(phone && portrait ? LinearLayout.VERTICAL : LinearLayout.HORIZONTAL);
        shell.setPadding(Ui.dp(this, phone?18:34), Ui.dp(this, phone?18:26), Ui.dp(this, phone?18:34), Ui.dp(this, phone?20:24));
        scroll.addView(shell, new android.widget.ScrollView.LayoutParams(-1,-2));
        root.addView(scroll, new FrameLayout.LayoutParams(-1,-1));

        LinearLayout brand = Ui.column(this);
        brand.setGravity(Gravity.CENTER);
        brand.setPadding(Ui.dp(this, 14), Ui.dp(this, 8), Ui.dp(this, 20), Ui.dp(this, 8));
        TextView logo = Ui.text(this, "▶", phone?30:42, Color.WHITE, true);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(Ui.gradient(Color.rgb(114, 255, 56), Color.rgb(19, 132, 44), 28, this));
        brand.addView(logo, new LinearLayout.LayoutParams(Ui.dp(this, phone?78:112), Ui.dp(this, phone?78:112)));
        TextView dubai = Ui.text(this, "DUBAI PLAY", phone?26:42, Color.WHITE, true); dubai.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1, Ui.dp(this, phone?44:58)); dp.topMargin = Ui.dp(this, phone?8:18); brand.addView(dubai, dp);
        TextView slogan = Ui.text(this, "SEU MUNDO • SEU CONTEÚDO • SEM LIMITES", phone?8:10, Color.rgb(142, 158, 149), false); slogan.setGravity(Gravity.CENTER); brand.addView(slogan, new LinearLayout.LayoutParams(-1, Ui.dp(this, phone?28:38)));
        TextView device = Ui.text(this, "APARELHO: " + DeviceInfo.macOrId(this), 9, Color.rgb(145, 160, 151), false); device.setGravity(Gravity.CENTER);
        brand.addView(device, new LinearLayout.LayoutParams(-1, Ui.dp(this,30)));

        LinearLayout cardArea = Ui.column(this); cardArea.setGravity(Gravity.CENTER);
        cardArea.setPadding(Ui.dp(this, phone?0:34), Ui.dp(this, 8), Ui.dp(this, phone?0:10), Ui.dp(this, 10));
        LinearLayout card = Ui.column(this); card.setPadding(Ui.dp(this, phone?20:34), Ui.dp(this, phone?20:26), Ui.dp(this, phone?20:34), Ui.dp(this, phone?20:24));
        card.setBackground(Ui.stroke(Color.argb(235, 7, 13, 11), Color.rgb(35, 73, 49), 22, this));
        serverBadge = Ui.text(this, "● VERIFICANDO", 10, Color.rgb(230, 185, 67), true); serverBadge.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); card.addView(serverBadge,new LinearLayout.LayoutParams(-1,Ui.dp(this,26)));
        TextView title = Ui.text(this, "Entre na sua conta", phone?24:28, Color.WHITE, true); card.addView(title,new LinearLayout.LayoutParams(-1,Ui.dp(this,46)));
        TextView subtitle = Ui.text(this, "Digite seu usuário e senha para acessar o Dubai Play.", phone?11:12, Color.rgb(142,153,166), false); subtitle.setMaxLines(2); card.addView(subtitle,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));
        card.addView(Ui.text(this,"Usuário",11,Color.WHITE,true),new LinearLayout.LayoutParams(-1,Ui.dp(this,26)));
        user=field("Digite seu usuário",false); card.addView(user,new LinearLayout.LayoutParams(-1,Ui.dp(this,52)));
        TextView pl=Ui.text(this,"Senha",11,Color.WHITE,true); LinearLayout.LayoutParams plp=new LinearLayout.LayoutParams(-1,Ui.dp(this,26));plp.topMargin=Ui.dp(this,10);card.addView(pl,plp);
        pass=field("Digite sua senha",true);card.addView(pass,new LinearLayout.LayoutParams(-1,Ui.dp(this,52)));
        enter=greenButton("ENTRAR");LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,Ui.dp(this,50));ep.topMargin=Ui.dp(this,16);card.addView(enter,ep);
        TextView test=outlineGreenButton("◉  TESTAR CONEXÃO");LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,Ui.dp(this,48));tp.topMargin=Ui.dp(this,9);card.addView(test,tp);
        message=Ui.text(this,"",10,Color.rgb(150,160,170),false);message.setGravity(Gravity.CENTER);LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,Ui.dp(this,34));mp.topMargin=Ui.dp(this,5);card.addView(message,mp);
        cardArea.addView(card,new LinearLayout.LayoutParams(-1,-2));

        if(phone && portrait){
            shell.addView(brand,new LinearLayout.LayoutParams(-1,Ui.dp(this,190)));
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.topMargin=Ui.dp(this,8);shell.addView(cardArea,cp);
        }else{
            shell.addView(brand,new LinearLayout.LayoutParams(0,Math.max(Ui.dp(this,460),getResources().getDisplayMetrics().heightPixels-Ui.dp(this,50)),1.0f));
            shell.addView(cardArea,new LinearLayout.LayoutParams(0,-1,1.0f));
        }
        enter.setOnClickListener(v -> doLogin()); test.setOnClickListener(v -> showDiagnostic()); pass.setOnEditorActionListener((v, actionId, event) -> { doLogin(); return true; }); user.requestFocus();
        return root;
    }

    private EditText field(String hint, boolean password) {
        EditText e = new EditText(this);
        e.setHint(hint); e.setHintTextColor(Color.rgb(104, 118, 134)); e.setTextColor(Color.WHITE); e.setTextSize(14);
        e.setSingleLine(true); e.setPadding(Ui.dp(this, 18), 0, Ui.dp(this, 18), 0); e.setFocusable(true);
        e.setBackground(Ui.stroke(Color.rgb(12, 20, 28), Color.rgb(49, 67, 82), 16, this));
        if (password) e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        e.setOnFocusChangeListener((v, f) -> e.setBackground(Ui.stroke(Color.rgb(12, 20, 28), f ? Color.rgb(79, 220, 70) : Color.rgb(49, 67, 82), 16, this)));
        return e;
    }

    private TextView greenButton(String text) {
        TextView b = Ui.text(this, text, 14, Color.WHITE, true); b.setGravity(Gravity.CENTER); b.setFocusable(true); b.setClickable(true);
        Ui.focus(b, this, Ui.gradient(Color.rgb(35, 190, 73), Color.rgb(63, 230, 91), 18, this), Ui.gradient(Color.rgb(64, 225, 87), Color.rgb(114, 255, 82), 18, this)); return b;
    }

    private TextView outlineGreenButton(String text) {
        TextView b = Ui.text(this, text, 14, Color.rgb(61, 224, 86), true); b.setGravity(Gravity.CENTER); b.setFocusable(true); b.setClickable(true);
        Ui.focus(b, this, Ui.stroke(Color.rgb(6, 20, 12), Color.rgb(52, 211, 80), 18, this), Ui.stroke(Color.rgb(16, 45, 24), Color.rgb(106, 255, 119), 18, this)); return b;
    }

    private GradientDrawable makeBackground() {
        return new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{Color.rgb(1, 5, 4), Color.rgb(3, 18, 9), Color.rgb(0, 4, 3)});
    }

    private void doLogin() {
        String u = user.getText().toString().trim(); String p = pass.getText().toString();
        if (u.isEmpty() || p.isEmpty()) { message.setText("Informe usuário e senha."); message.setTextColor(Ui.RED); return; }
        enter.setEnabled(false); enter.setText("ENTRANDO..."); message.setText("Validando acesso no servidor..."); message.setTextColor(Color.rgb(151, 162, 172));
        ApiClient.login(u, p, DeviceInfo.macOrId(this), new ApiClient.Callback<ApiClient.LoginResult>() {
            public void ok(ApiClient.LoginResult r) { runOnUiThread(() -> { Session.save(LoginActivity.this, r.username, r.expiresAt); openHome(); }); }
            public void error(String m) { runOnUiThread(() -> { enter.setEnabled(true); enter.setText("ENTRAR"); message.setText(m); message.setTextColor(Ui.RED); }); }
        });
    }

    private void checkServer() {
        ApiClient.status(new ApiClient.Callback<String>() {
            public void ok(String s) { runOnUiThread(() -> { if(serverBadge!=null){serverBadge.setText("● SERVIDOR ONLINE"); serverBadge.setTextColor(Color.rgb(47, 224, 100));} }); }
            public void error(String m) { runOnUiThread(() -> { if(serverBadge!=null){serverBadge.setText("● SERVIDOR OFFLINE"); serverBadge.setTextColor(Ui.RED);} }); }
        });
    }

    private boolean hasNetwork() {
        try { ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE); NetworkInfo n=cm==null?null:cm.getActiveNetworkInfo(); return n!=null && n.isConnected(); }
        catch(Throwable e){ return false; }
    }

    private void showDiagnostic() {
        final Dialog d = new Dialog(this); d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box = Ui.column(this); box.setPadding(Ui.dp(this, 28), Ui.dp(this, 24), Ui.dp(this, 28), Ui.dp(this, 24)); box.setBackground(Ui.stroke(Color.rgb(10, 12, 10), Color.rgb(67, 83, 67), 20, this));
        TextView wifi = Ui.text(this, "◉", 28, Color.rgb(227, 186, 67), true); wifi.setGravity(Gravity.CENTER); box.addView(wifi,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));
        TextView t = Ui.text(this,"Diagnóstico de rede",18,Color.WHITE,true); t.setGravity(Gravity.CENTER); box.addView(t,new LinearLayout.LayoutParams(-1,Ui.dp(this,38)));
        TextView sub = Ui.text(this,"Verificando conexão do aparelho até o servidor",11,Color.rgb(145,153,145),false); sub.setGravity(Gravity.CENTER); box.addView(sub,new LinearLayout.LayoutParams(-1,Ui.dp(this,32)));
        LinearLayout steps = new LinearLayout(this); steps.setGravity(Gravity.CENTER);
        TextView a=diagStep("▣\nBox", Color.rgb(60,220,86)); TextView b=diagStep("⌁\nRede", hasNetwork()?Color.rgb(60,220,86):Ui.RED); TextView c=diagStep("◎\nInternet", hasNetwork()?Color.rgb(60,220,86):Ui.RED); TextView s=diagStep("▦\nServidor", Color.rgb(115,115,115));
        for(TextView v:new TextView[]{a,b,c,s}){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(Ui.dp(this,90),Ui.dp(this,72));p.leftMargin=Ui.dp(this,6);p.rightMargin=Ui.dp(this,6);steps.addView(v,p);} box.addView(steps,new LinearLayout.LayoutParams(-1,Ui.dp(this,82)));
        TextView result=Ui.text(this,"Testando servidor...",12,Color.rgb(190,190,190),true); result.setGravity(Gravity.CENTER); box.addView(result,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));
        TextView close=outlineGreenButton("FECHAR"); close.setOnClickListener(v->d.dismiss()); box.addView(close,new LinearLayout.LayoutParams(-1,Ui.dp(this,46)));
        d.setContentView(box); Window w=d.getWindow(); if(w!=null){w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));w.setLayout(Math.min(Ui.dp(this,560), getResources().getDisplayMetrics().widthPixels-Ui.dp(this,24)),WindowManager.LayoutParams.WRAP_CONTENT);} d.show(); if(w!=null)w.setLayout(Math.min(Ui.dp(this,560), getResources().getDisplayMetrics().widthPixels-Ui.dp(this,24)),WindowManager.LayoutParams.WRAP_CONTENT);
        ApiClient.status(new ApiClient.Callback<String>(){public void ok(String x){runOnUiThread(()->{s.setText("▦\nServidor");s.setTextColor(Color.rgb(60,220,86));s.setBackground(Ui.stroke(Color.rgb(8,30,14),Color.rgb(60,220,86),13,LoginActivity.this));result.setText("✓ Conexão completa. Servidor online.");result.setTextColor(Color.rgb(60,220,86));});}public void error(String m){runOnUiThread(()->{s.setTextColor(Ui.RED);s.setBackground(Ui.stroke(Color.rgb(34,10,12),Ui.RED,13,LoginActivity.this));result.setText("Falha no servidor: "+m);result.setTextColor(Ui.RED);});}});
    }

    private TextView diagStep(String text, int color) {
        TextView v=Ui.text(this,text,12,color,true);v.setGravity(Gravity.CENTER);v.setBackground(Ui.stroke(Color.rgb(11,22,14),color,13,this));return v;
    }

    private void openHome() { Intent i=new Intent(this,MainActivity.class); startActivity(i); finish(); }
    private void immersive(){getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);}
}
