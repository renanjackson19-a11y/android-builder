package com.ativacao.app;

import android.content.Context;
import android.content.SharedPreferences;

public final class LauncherStore {
    private static final String PREFS = "launcher_state";
    private LauncherStore() {}
    private static SharedPreferences p(Context c){ return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }

    public static void setDeviceCode(Context c,String v){p(c).edit().putString("device_code",v==null?"":v).apply();}
    public static String getDeviceCode(Context c){return p(c).getString("device_code","");}
    public static void setActivationComplete(Context c,boolean v){p(c).edit().putBoolean("activation_complete",v).apply();}
    public static boolean isActivationComplete(Context c){return p(c).getBoolean("activation_complete",false);}
    public static void setDeviceType(Context c,String v){p(c).edit().putString("device_type",v==null?"":v).apply();}
    public static String getDeviceType(Context c){return p(c).getString("device_type","");}
    public static boolean isTvBoxMode(Context c){return "tv_box".equalsIgnoreCase(getDeviceType(c));}
    public static void setCachedJson(Context c,String json){p(c).edit().putString("cached_json",json==null?"":json).putLong("last_sync",System.currentTimeMillis()).apply();}
    public static String getCachedJson(Context c){return p(c).getString("cached_json","");}
    public static long getLastSync(Context c){return p(c).getLong("last_sync",0L);}
    public static void setPayer(Context c,String name,String email,String doc){p(c).edit().putString("payer_name",name).putString("payer_email",email).putString("payer_doc",doc).apply();}
    public static String getPayerName(Context c){return p(c).getString("payer_name","");}
    public static String getPayerEmail(Context c){return p(c).getString("payer_email","");}
    public static String getPayerDoc(Context c){return p(c).getString("payer_doc","");}
}
