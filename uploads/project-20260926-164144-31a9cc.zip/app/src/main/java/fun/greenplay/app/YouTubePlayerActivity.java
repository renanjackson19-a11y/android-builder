package fun.greenplay.app;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import android.content.res.ColorStateList;
import android.content.pm.ActivityInfo;
import java.util.Locale;

public class YouTubePlayerActivity extends Activity {
    FrameLayout root;
    WebView web;
    View touchShield;
    LinearLayout controls;
    TextView back,back10,play,fwd10,time;
    SeekBar seek;
    Handler h=new Handler(Looper.getMainLooper());
    Runnable hideTask;
    boolean seeking=false,tvMode=false,ready=false,previewMode=false,previewBlocked=false,previewWasPlaying=false;
    int accent=0xffff4f9a;
    String videoId="",previewUserId="";
    long previewMovieMs=0,previewWatchedMs=0,previewLastTick=0;

    int dp(int n){return(int)(n*getResources().getDisplayMetrics().density+.5f);}
    GradientDrawable bg(int c,int r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));return g;}
    TextView tx(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(size);t.setGravity(Gravity.CENTER);return t;}
    GradientDrawable focusBg(){GradientDrawable g=bg(0xee211118,14);g.setStroke(dp(3),accent);return g;}
    void tvControl(View v){
        if(!tvMode||v==null)return;
        v.setFocusable(true);v.setFocusableInTouchMode(false);
        final android.graphics.drawable.Drawable normal=v.getBackground();
        v.setOnFocusChangeListener((x,has)->{
            x.animate().scaleX(has?1.06f:1f).scaleY(has?1.06f:1f).setDuration(90).start();
            if(android.os.Build.VERSION.SDK_INT>=21)x.setTranslationZ(has?dp(14):0);
            if(has){showControls();x.setBackground(focusBg());if(x instanceof TextView)((TextView)x).setTextColor(accent);}
            else{x.setBackground(normal);if(x instanceof TextView)((TextView)x).setTextColor(Color.WHITE);}
        });
    }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        tvMode=(getIntent()!=null&&getIntent().getBooleanExtra("tv_mode",false))||DeviceCompat.isTelevisionDevice(this);
        try{setRequestedOrientation(tvMode?ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE:ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);}catch(Exception ignored){}
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        applyImmersive();

        if(getIntent()!=null){videoId=getIntent().getStringExtra("youtube_id");previewMode=getIntent().getBooleanExtra("preview_mode",false);previewMovieMs=Math.max(0,getIntent().getLongExtra("preview_movie_ms",0));previewUserId=getIntent().getStringExtra("preview_user_id");}
        if(videoId==null)videoId="";if(previewUserId==null)previewUserId="";
        videoId=videoId.replaceAll("[^A-Za-z0-9_-]","");
        if(videoId.isEmpty()){finish();return;}
        if(previewMode){if(previewMovieMs<=0)previewMovieMs=Math.max(0,getSharedPreferences("gp",0).getInt("preview_movie_minutes",5))*60000L;previewWatchedMs=getSharedPreferences("gp",0).getLong(previewWatchKey(),0L);}

        build();
        if(previewMode)refreshPreviewLimitFromPanel();
        loadPlayer();
        h.post(poll);
        showControls();
    }

    void applyImmersive(){
        try{getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_FULLSCREEN|
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );}catch(Exception ignored){}
    }

    void build(){
        root=new FrameLayout(this);root.setBackgroundColor(Color.BLACK);

        web=new WebView(this);web.setBackgroundColor(Color.BLACK);web.setAlpha(tvMode?0f:1f);
        SecurityGuard.hardenWebView();
        WebSettings ws=web.getSettings();
        ws.setJavaScriptEnabled(true);ws.setDomStorageEnabled(true);ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setAllowFileAccess(false);ws.setAllowContentAccess(false);ws.setSaveFormData(false);
        if(android.os.Build.VERSION.SDK_INT>=21)ws.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        ws.setLoadsImagesAutomatically(true);ws.setUseWideViewPort(true);ws.setLoadWithOverviewMode(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient());
        web.setLongClickable(false);web.setHapticFeedbackEnabled(false);
        web.setOnLongClickListener(v->true);
        web.setOnTouchListener((v,e)->true);
        root.addView(web,new FrameLayout.LayoutParams(-1,-1));

        if(!tvMode){
            int screenH=getResources().getDisplayMetrics().heightPixels;
            int topMaskH=Math.max(dp(64),Math.min(dp(118),(int)(screenH*0.125f)));
            int bottomMaskH=Math.max(dp(64),Math.min(dp(110),(int)(screenH*0.11f)));
            View topMask=new View(this);topMask.setBackgroundColor(Color.BLACK);
            FrameLayout.LayoutParams topMaskLp=new FrameLayout.LayoutParams(-1,topMaskH,Gravity.TOP);root.addView(topMask,topMaskLp);
            View bottomMask=new View(this);bottomMask.setBackgroundColor(Color.BLACK);
            FrameLayout.LayoutParams bottomMaskLp=new FrameLayout.LayoutParams(-1,bottomMaskH,Gravity.BOTTOM);root.addView(bottomMask,bottomMaskLp);
        }

        touchShield=new View(this);touchShield.setBackgroundColor(Color.TRANSPARENT);touchShield.setClickable(true);
        touchShield.setOnClickListener(v->{if(controls.getVisibility()==View.VISIBLE)hideControls();else showControls();});
        root.addView(touchShield,new FrameLayout.LayoutParams(-1,-1));

        back=tx("‹",34);back.setBackground(bg(0x77000000,24));back.setOnClickListener(v->finish());
        FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(dp(48),dp(48),Gravity.TOP|Gravity.LEFT);
        bp.setMargins(dp(14),dp(14),0,0);root.addView(back,bp);
        back.bringToFront();

        controls=new LinearLayout(this);controls.setOrientation(LinearLayout.VERTICAL);
        controls.setPadding(dp(8),dp(4),dp(8),dp(3));
        GradientDrawable controlsBg=bg(0xf21f1019,20);controlsBg.setStroke(dp(1),0x995b3146);
        controls.setBackground(controlsBg);controls.setElevation(dp(12));

        LinearLayout buttons=new LinearLayout(this);buttons.setGravity(Gravity.CENTER);
        back10=tx("↶ 10s",12);play=tx("Ⅱ",20);fwd10=tx("10s ↷",12);
        back10.setBackground(bg(0xcc1c1318,14));play.setBackground(bg(0xee2a1521,18));fwd10.setBackground(bg(0xcc1c1318,14));
        LinearLayout.LayoutParams b1=new LinearLayout.LayoutParams(0,dp(34),1f);b1.setMargins(dp(3),0,dp(3),0);
        LinearLayout.LayoutParams b2=new LinearLayout.LayoutParams(0,dp(34),1f);b2.setMargins(dp(3),0,dp(3),0);
        LinearLayout.LayoutParams b3=new LinearLayout.LayoutParams(0,dp(34),1f);b3.setMargins(dp(3),0,dp(3),0);
        buttons.addView(back10,b1);buttons.addView(play,b2);buttons.addView(fwd10,b3);
        controls.addView(buttons,new LinearLayout.LayoutParams(-1,dp(36)));

        LinearLayout progress=new LinearLayout(this);progress.setGravity(Gravity.CENTER_VERTICAL);
        time=tx("00:00 / 00:00",12);time.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
        progress.addView(time,new LinearLayout.LayoutParams(dp(98),dp(24)));
        seek=new SeekBar(this);seek.setMax(1000);
        seek.setProgressTintList(ColorStateList.valueOf(accent));
        seek.setProgressBackgroundTintList(ColorStateList.valueOf(0xff49313e));
        seek.setThumbTintList(ColorStateList.valueOf(accent));
        progress.addView(seek,new LinearLayout.LayoutParams(0,dp(24),1));
        controls.addView(progress,new LinearLayout.LayoutParams(-1,dp(24)));

        FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(-1,dp(64),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
        cp.setMargins(dp(28),0,dp(28),dp(6));root.addView(controls,cp);
        controls.bringToFront();

        back10.setOnClickListener(v->{eval("gpSeekBy(-10)");showControls();});
        play.setOnClickListener(v->{eval("gpToggle()");showControls();});
        fwd10.setOnClickListener(v->{eval("gpSeekBy(10)");showControls();});

        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar s,int p,boolean fromUser){}
            public void onStartTrackingTouch(SeekBar s){seeking=true;showControls();}
            public void onStopTrackingTouch(SeekBar s){seeking=false;eval("gpSeek("+(s.getProgress()/1000.0)+")");showControls();}
        });

        if(tvMode){tvControl(back);tvControl(back10);tvControl(play);tvControl(fwd10);tvControl(seek);play.postDelayed(()->play.requestFocus(),180);}
        setContentView(root);
    }

    void loadPlayer(){
        String tvCss=tvMode?"transform:scale(1.48);transform-origin:50% 50%;":"";
        String html="<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no'>"+
            "<style>html,body,#p{margin:0;padding:0;width:100%;height:100%;background:#000;overflow:hidden}iframe{width:100%!important;height:100%!important;border:0;"+tvCss+"}</style>"+
            "<script src='https://www.youtube.com/iframe_api'></script></head><body><div id='p'></div><script>"+
            "var player,ready=false;function onYouTubeIframeAPIReady(){player=new YT.Player('p',{videoId:'"+videoId+"',playerVars:{autoplay:1,controls:0,disablekb:1,fs:0,iv_load_policy:3,cc_load_policy:0,playsinline:1,rel:0,modestbranding:1,origin:'https://greenplay.fun'},events:{onReady:function(e){ready=true;e.target.playVideo();AndroidBridge.playerReady();}}});}"+
            "function gpToggle(){if(!ready)return;var s=player.getPlayerState();if(s==1)player.pauseVideo();else player.playVideo();}"+
            "function gpSeek(r){if(!ready)return;var d=player.getDuration()||0;player.seekTo(Math.max(0,Math.min(d,d*r)),true);}"+
            "function gpSeekBy(s){if(!ready)return;var d=player.getDuration()||0;player.seekTo(Math.max(0,Math.min(d,(player.getCurrentTime()||0)+s)),true);}"+
            "function gpTime(){if(!ready)return '0|0|0';return (player.getCurrentTime()||0)+'|'+(player.getDuration()||0)+'|'+player.getPlayerState();}"+
            "</script></body></html>";
        web.addJavascriptInterface(new Object(){
            @android.webkit.JavascriptInterface public void playerReady(){runOnUiThread(()->{if(web!=null){web.setTranslationX(0f);web.setTranslationY(0f);web.animate().alpha(1f).setDuration(120).start();}});}
        },"AndroidBridge");
        web.loadDataWithBaseURL("https://greenplay.fun/",html,"text/html","UTF-8",null);
    }

    void eval(String js){if(web!=null)web.evaluateJavascript("javascript:"+js,null);}
    String fmt(double sec){int s=Math.max(0,(int)sec),hh=s/3600,mm=(s%3600)/60,ss=s%60;return hh>0?String.format(Locale.US,"%d:%02d:%02d",hh,mm,ss):String.format(Locale.US,"%02d:%02d",mm,ss);}
    String previewWatchKey(){String who=previewUserId.trim().isEmpty()?"guest":previewUserId.trim();return "preview_yt_watch_"+(who+"_"+videoId).replaceAll("[^a-zA-Z0-9._-]","_");}
    void persistPreviewWatch(){if(!previewMode)return;getSharedPreferences("gp",0).edit().putLong(previewWatchKey(),Math.max(0,previewWatchedMs)).apply();}
    void refreshPreviewLimitFromPanel(){Api.post("general_setting",Api.m(),new Api.CB(){public void ok(org.json.JSONObject j){org.json.JSONArray a=j.optJSONArray("result");if(a==null)return;for(int i=0;i<a.length();i++){org.json.JSONObject x=a.optJSONObject(i);if(x==null)continue;if("greenplay_preview_movie_minutes".equals(x.optString("key"))){try{int m=Math.max(0,Integer.parseInt(x.optString("value","0")));previewMovieMs=m*60000L;getSharedPreferences("gp",0).edit().putInt("preview_movie_minutes",m).apply();}catch(Exception ignored){}break;}}}public void err(String e){}});}
    void blockPreview(){if(previewBlocked||isFinishing())return;previewBlocked=true;persistPreviewWatch();eval("if(ready)player.pauseVideo()");final Dialog d=new Dialog(this);LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(24),dp(22),dp(24),dp(20));GradientDrawable g=bg(0xff1f1019,24);g.setStroke(dp(1),0xff5b3146);box.setBackground(g);TextView brand=tx("Yelly Doramas",18);brand.setTextColor(accent);brand.setTypeface(null,1);box.addView(brand,new LinearLayout.LayoutParams(-1,dp(32)));TextView tt=tx("Seu período grátis terminou",21);tt.setTypeface(null,1);box.addView(tt,new LinearLayout.LayoutParams(-1,dp(48)));int mins=(int)Math.max(1,previewMovieMs/60000L);TextView msg=tx("Você assistiu aos "+mins+" minutos grátis deste filme. Assine um plano para continuar.",14);msg.setTextColor(0xffd9cbd3);msg.setPadding(dp(4),0,dp(4),dp(14));box.addView(msg,new LinearLayout.LayoutParams(-1,-2));TextView plans=tx("VER PLANOS",15);plans.setTextColor(0xff11060c);plans.setTypeface(null,1);plans.setBackground(bg(accent,18));box.addView(plans,new LinearLayout.LayoutParams(-1,dp(52)));TextView later=tx("Agora não",14);later.setTextColor(0xffc8bac3);later.setPadding(0,dp(10),0,0);box.addView(later,new LinearLayout.LayoutParams(-1,dp(48)));plans.setOnClickListener(v->{d.dismiss();android.content.Intent go=new android.content.Intent(YouTubePlayerActivity.this,MainActivity.class);go.addFlags(android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP|android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP);go.putExtra("gp_open_plans",true);startActivity(go);finish();});later.setOnClickListener(v->{d.dismiss();finish();});d.setContentView(box);Window w=d.getWindow();if(w!=null){w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));w.setDimAmount(.72f);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);w.setGravity(Gravity.CENTER);}d.setCancelable(false);d.show();if(w!=null)w.setLayout(tvMode?dp(520):Math.min(getResources().getDisplayMetrics().widthPixels-dp(36),dp(520)),-2);}

    final Runnable poll=new Runnable(){public void run(){
        if(web!=null)web.evaluateJavascript("javascript:gpTime()",v->{
            try{
                if(v==null)return;String z=v;
                if(z.length()>=2&&z.charAt(0)==34&&z.charAt(z.length()-1)==34)z=z.substring(1,z.length()-1);
                String[] a=z.split("\\|");if(a.length<3)return;
                double cur=Double.parseDouble(a[0]),dur=Double.parseDouble(a[1]);int st=(int)Double.parseDouble(a[2]);
                ready=dur>0||st!=0;time.setText(fmt(cur)+" / "+fmt(dur));play.setText(st==1?"Ⅱ":"▶");
                if(!seeking&&dur>0)seek.setProgress((int)Math.max(0,Math.min(1000,(cur/dur)*1000)));
                if(previewMode&&!previewBlocked&&previewMovieMs>0){long now=SystemClock.elapsedRealtime();boolean playing=st==1;if(playing&&previewWasPlaying&&previewLastTick>0){long delta=Math.max(0,Math.min(1500,now-previewLastTick));previewWatchedMs+=delta;if(delta>0)persistPreviewWatch();}previewWasPlaying=playing;previewLastTick=now;if(previewWatchedMs>=previewMovieMs)runOnUiThread(()->blockPreview());}
            }catch(Exception ignored){}
        });
        h.postDelayed(this,750);
    }};

    void showControls(){
        controls.setVisibility(View.VISIBLE);back.setVisibility(View.VISIBLE);
        controls.bringToFront();back.bringToFront();
        if(hideTask!=null)h.removeCallbacks(hideTask);
        hideTask=()->{if(!seeking&&!tvMode)hideControls();};
        h.postDelayed(hideTask,tvMode?6500:5000);
    }
    void hideControls(){if(controls!=null)controls.setVisibility(View.GONE);if(back!=null)back.setVisibility(View.GONE);}

    @Override public boolean dispatchKeyEvent(KeyEvent e){
        if(e!=null&&e.getAction()==KeyEvent.ACTION_DOWN){
            int k=e.getKeyCode();
            if(k==KeyEvent.KEYCODE_BACK){finish();return true;}
            if(k==KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE||k==KeyEvent.KEYCODE_MEDIA_PLAY||k==KeyEvent.KEYCODE_MEDIA_PAUSE||k==KeyEvent.KEYCODE_DPAD_CENTER||k==KeyEvent.KEYCODE_ENTER||k==KeyEvent.KEYCODE_NUMPAD_ENTER){eval("gpToggle()");showControls();return true;}
            if(k==KeyEvent.KEYCODE_MEDIA_REWIND||k==KeyEvent.KEYCODE_DPAD_LEFT){eval("gpSeekBy(-10)");showControls();return true;}
            if(k==KeyEvent.KEYCODE_MEDIA_FAST_FORWARD||k==KeyEvent.KEYCODE_DPAD_RIGHT){eval("gpSeekBy(10)");showControls();return true;}
            if(k==KeyEvent.KEYCODE_DPAD_UP||k==KeyEvent.KEYCODE_DPAD_DOWN){showControls();return true;}
        }
        return super.dispatchKeyEvent(e);
    }

    @Override public void onWindowFocusChanged(boolean hasFocus){super.onWindowFocusChanged(hasFocus);if(hasFocus)applyImmersive();}
    @Override protected void onPause(){persistPreviewWatch();previewWasPlaying=false;previewLastTick=0;eval("if(ready)player.pauseVideo()");super.onPause();}
    @Override protected void onResume(){super.onResume();applyImmersive();}
    @Override protected void onDestroy(){
        h.removeCallbacksAndMessages(null);
        if(web!=null){try{web.stopLoading();web.loadUrl("about:blank");web.removeAllViews();web.destroy();}catch(Exception ignored){}web=null;}
        super.onDestroy();
    }
}
