<?php
function greenplay_app_settings_defaults(){
    return array(
        'app_name' => 'GreenPlay',
        'trial_enabled' => '1',
        'trial_hours' => '3',
        'subscription_enabled' => '1',
        'payment_provider' => 'misticpay',
        'misticpay_base_url' => 'https://api.misticpay.com/api',
        'misticpay_client_id' => '',
        'misticpay_client_secret' => '',
        'misticpay_webhook_url' => '',
        'show_movies' => '1',
        'show_series' => '1',
        'show_live' => '1',
        'watchlist_enabled' => '1',
        'downloads_enabled' => '0',
        'continue_watching_enabled' => '0'
    );
}
function greenplay_app_settings_path(){ return __DIR__.'/app_settings.json'; }
function greenplay_app_settings(){
    $defaults=greenplay_app_settings_defaults();
    $path=greenplay_app_settings_path();
    if(!is_file($path)) return $defaults;
    $raw=@file_get_contents($path); $data=json_decode($raw,true);
    return is_array($data)?array_merge($defaults,$data):$defaults;
}
function greenplay_app_settings_save($settings){
    $data=array_merge(greenplay_app_settings_defaults(),(array)$settings);
    return @file_put_contents(greenplay_app_settings_path(), json_encode($data,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES), LOCK_EX)!==false;
}
