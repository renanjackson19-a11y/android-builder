<?php 
require_once $_SERVER['DOCUMENT_ROOT'].'/controller/cliente/cliente_controller.php';

$premium_listar         = premium_listar(0);
$token_mp               = SITE_TOKEN_MP;
$comprar_no_whatsapp    = SITE_WHATSAPP;

if($cliente['user_revendedor']){

    if($cliente_revendedor_valido){
        $comprar_no_whatsapp    = $cliente_revendedor['user_whatsapp'];
        $token_mp               = $cliente_revendedor['user_token_mp'];

        if(count(premium_listar($cliente_revendedor['user_id'])) > 0){
            $premium_listar = array();
            foreach(premium_listar($cliente_revendedor['user_id']) as $pv){
                if(cliente_revendedor_valido($cliente_revendedor['user_id'], $pv['premium_id'], false)){
                    $premium_listar[] = $pv;
                }
            }   
        }
        
    }

}      