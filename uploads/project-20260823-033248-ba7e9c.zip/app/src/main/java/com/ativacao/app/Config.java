package com.ativacao.app;

public final class Config {
    private Config() {}

    public static final String API_BASE_URL = "https://dubaiplay.shop/api/";
    public static final String PANEL_URL = "https://dubaiplay.shop/";

    // Credencial exclusiva do aplicativo. O painel V1.7 aceita esta chave automaticamente.
    public static final String APP_TOKEN = "CTAdcb_S0Y7Sjnpx7w3F8c-v7rW6sA9lxkhkcvVAWuQ";
}
