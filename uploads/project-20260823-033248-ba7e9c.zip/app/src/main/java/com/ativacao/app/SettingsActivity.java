package com.ativacao.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class SettingsActivity extends Activity {
    @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(build());}

    private View build(){
        boolean phone=Ui.phone(this), portrait=Ui.portrait(this);
        LinearLayout root=Ui.column(this);root.setBackgroundColor(Ui.BG);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);
        LinearLayout content=Ui.column(this);int side=phone?18:30;content.setPadding(Ui.dp(this,side),Ui.dp(this,phone?22:28),Ui.dp(this,side),Ui.dp(this,28));
        TextView title=Ui.text(this,"Configurações",phone?26:28,Ui.TEXT,true);content.addView(title,new LinearLayout.LayoutParams(-1,Ui.dp(this,48)));
        TextView sub=Ui.text(this,"Dubai Play conectado automaticamente ao seu painel",phone?12:14,Ui.MUTED,false);content.addView(sub,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));

        LinearLayout card=Ui.column(this);card.setPadding(Ui.dp(this,20),Ui.dp(this,16),Ui.dp(this,20),Ui.dp(this,16));card.setBackground(Ui.stroke(Ui.PANEL,Ui.BORDER,16,this));
        card.addView(Ui.text(this,"SERVIDOR",10,Ui.PURPLE,true),new LinearLayout.LayoutParams(-1,Ui.dp(this,26)));
        TextView url=Ui.text(this,Config.PANEL_URL,phone?14:17,Ui.TEXT,true);url.setMaxLines(2);card.addView(url,new LinearLayout.LayoutParams(-1,Ui.dp(this,40)));
        TextView auto=Ui.text(this,"● Conexão automática • sem chave manual",phone?11:13,Ui.GREEN,true);card.addView(auto,new LinearLayout.LayoutParams(-1,Ui.dp(this,30)));
        content.addView(card,new LinearLayout.LayoutParams(-1,Ui.dp(this,112)));

        TextView test=Ui.primaryButton(this,"TESTAR CONEXÃO");TextView clear=Ui.button(this,"LIMPAR CAPAS");TextView back=Ui.button(this,"VOLTAR");
        if(phone && portrait){
            LinearLayout.LayoutParams p1=new LinearLayout.LayoutParams(-1,Ui.dp(this,50));p1.topMargin=Ui.dp(this,18);content.addView(test,p1);LinearLayout.LayoutParams p2=new LinearLayout.LayoutParams(-1,Ui.dp(this,50));p2.topMargin=Ui.dp(this,10);content.addView(clear,p2);LinearLayout.LayoutParams p3=new LinearLayout.LayoutParams(-1,Ui.dp(this,50));p3.topMargin=Ui.dp(this,10);content.addView(back,p3);
        }else{
            LinearLayout actions=new LinearLayout(this);actions.setGravity(Gravity.LEFT);actions.setPadding(0,Ui.dp(this,18),0,0);actions.addView(test,new LinearLayout.LayoutParams(Ui.dp(this,185),Ui.dp(this,50)));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(Ui.dp(this,160),Ui.dp(this,50));cp.leftMargin=Ui.dp(this,10);actions.addView(clear,cp);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(Ui.dp(this,120),Ui.dp(this,50));bp.leftMargin=Ui.dp(this,10);actions.addView(back,bp);content.addView(actions);
        }
        TextView result=Ui.text(this,"",phone?12:14,Ui.MUTED,false);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,Ui.dp(this,60));rp.topMargin=Ui.dp(this,12);content.addView(result,rp);
        TextView about=Ui.text(this,"Dubai Play TV • versão 1.3.0 • Android TV / TV Box / celular",11,Color.rgb(92,106,130),false);content.addView(about,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));

        test.setOnClickListener(v->{result.setText("Testando conexão...");result.setTextColor(Ui.MUTED);ApiClient.home(new ApiClient.Callback<ApiClient.HomeData>(){public void ok(ApiClient.HomeData h){runOnUiThread(()->{result.setText("✓ Conectado • "+h.liveCount+" canais • "+h.movieCount+" filmes • "+h.seriesCount+" séries");result.setTextColor(Ui.GREEN);});}public void error(String m){runOnUiThread(()->{result.setText("Falha: "+m);result.setTextColor(Ui.RED);});}});});
        clear.setOnClickListener(v->{ImageLoader.clear();result.setText("Capas em memória limpas.");result.setTextColor(Ui.GREEN);});back.setOnClickListener(v->finish());

        FrameLayout centered=Ui.centered(this,content,760);scroll.addView(centered,new ScrollView.LayoutParams(-1,-2));root.addView(scroll,new LinearLayout.LayoutParams(-1,-1));test.requestFocus();return root;
    }
}
