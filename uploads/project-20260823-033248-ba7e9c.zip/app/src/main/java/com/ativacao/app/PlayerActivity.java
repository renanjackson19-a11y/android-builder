package com.ativacao.app;

import android.app.Activity;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

public class PlayerActivity extends Activity {
    private VideoView video;
    private ProgressBar loading;
    private TextView epgNow, epgNext, playPause, elapsed, durationText;
    private SeekBar seek;
    private LinearLayout controls;
    private final Handler handler = new Handler();
    private boolean live;
    private boolean dragging=false;
    private int resumePos=0;

    private final Runnable progressTask = new Runnable(){
        @Override public void run(){
            if(video!=null && !live && !dragging){
                try{
                    int pos=video.getCurrentPosition(), dur=video.getDuration();
                    if(dur>0){seek.setMax(dur);seek.setProgress(pos);elapsed.setText(time(pos));durationText.setText(time(dur));}
                }catch(Exception ignored){}
            }
            handler.postDelayed(this,1000);
        }
    };
    private final Runnable hideTask=()->{if(video!=null && video.isPlaying() && controls!=null)controls.setVisibility(View.GONE);};

    @Override public void onCreate(Bundle b){
        super.onCreate(b);immersive();if(b!=null)resumePos=b.getInt("pos",0);
        live="live".equals(getIntent().getStringExtra("type"));
        setContentView(build());
        play();
    }

    private View build(){
        FrameLayout root=new FrameLayout(this);root.setBackgroundColor(Color.BLACK);root.setFocusable(true);root.setClickable(true);
        video=new VideoView(this);video.setBackgroundColor(Color.BLACK);root.addView(video,new FrameLayout.LayoutParams(-1,-1));
        loading=new ProgressBar(this);root.addView(loading,new FrameLayout.LayoutParams(Ui.dp(this,48),Ui.dp(this,48),Gravity.CENTER));

        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);top.setPadding(Ui.dp(this,18),0,Ui.dp(this,18),0);top.setBackgroundColor(0x99040911);
        TextView name=Ui.text(this,clean(getIntent().getStringExtra("name"),"Dubai Play"),Ui.phone(this)?13:16,Color.WHITE,true);name.setMaxLines(1);top.addView(name,new LinearLayout.LayoutParams(0,Ui.dp(this,50),1));
        TextView brand=Ui.text(this,"DUBAI PLAY",11,Color.rgb(205,193,255),true);brand.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);top.addView(brand,new LinearLayout.LayoutParams(Ui.dp(this,120),Ui.dp(this,50)));root.addView(top,new FrameLayout.LayoutParams(-1,Ui.dp(this,50),Gravity.TOP));

        controls=new LinearLayout(this);controls.setGravity(Gravity.CENTER_VERTICAL);controls.setPadding(Ui.dp(this,12),Ui.dp(this,8),Ui.dp(this,12),Ui.dp(this,8));controls.setBackground(Ui.stroke(0xE6111825,0x663C4F6C,14,this));
        TextView back=Ui.button(this,"‹");back.setOnClickListener(v->finish());controls.addView(back,new LinearLayout.LayoutParams(Ui.dp(this,48),Ui.dp(this,44)));
        if(!live){TextView prev=Ui.button(this,"−10");prev.setOnClickListener(v->seekBy(-10000));LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(Ui.dp(this,58),Ui.dp(this,44));pp.leftMargin=Ui.dp(this,8);controls.addView(prev,pp);}
        playPause=Ui.primaryButton(this,"❚❚");playPause.setOnClickListener(v->togglePlayback());LinearLayout.LayoutParams playP=new LinearLayout.LayoutParams(Ui.dp(this,64),Ui.dp(this,44));playP.leftMargin=Ui.dp(this,8);controls.addView(playPause,playP);
        if(!live){TextView next=Ui.button(this,"+10");next.setOnClickListener(v->seekBy(10000));LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(Ui.dp(this,58),Ui.dp(this,44));np.leftMargin=Ui.dp(this,8);controls.addView(next,np);}

        if(!live){
            elapsed=Ui.text(this,"00:00",10,Ui.MUTED,true);elapsed.setGravity(Gravity.CENTER);LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(Ui.dp(this,52),Ui.dp(this,44));ep.leftMargin=Ui.dp(this,10);controls.addView(elapsed,ep);
            seek=new SeekBar(this);seek.setFocusable(true);seek.setMax(1);LinearLayout.LayoutParams sk=new LinearLayout.LayoutParams(0,Ui.dp(this,44),1);sk.leftMargin=Ui.dp(this,6);sk.rightMargin=Ui.dp(this,6);controls.addView(seek,sk);
            durationText=Ui.text(this,"00:00",10,Ui.MUTED,true);durationText.setGravity(Gravity.CENTER);controls.addView(durationText,new LinearLayout.LayoutParams(Ui.dp(this,52),Ui.dp(this,44)));
            seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean from){if(from && elapsed!=null)elapsed.setText(time(p));}public void onStartTrackingTouch(SeekBar s){dragging=true;showControls();}public void onStopTrackingTouch(SeekBar s){dragging=false;video.seekTo(s.getProgress());scheduleHide();}});
        }else{
            TextView liveBadge=Ui.text(this,"● AO VIVO",11,Ui.GREEN,true);liveBadge.setGravity(Gravity.CENTER);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,Ui.dp(this,44),1);lp.leftMargin=Ui.dp(this,12);controls.addView(liveBadge,lp);
        }

        FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(-1,Ui.dp(this,62),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);cp.leftMargin=Ui.dp(this,Ui.phone(this)?10:24);cp.rightMargin=Ui.dp(this,Ui.phone(this)?10:24);cp.bottomMargin=Ui.dp(this,live?94:14);root.addView(controls,cp);

        if(live){
            LinearLayout guide=Ui.column(this);guide.setPadding(Ui.dp(this,18),Ui.dp(this,9),Ui.dp(this,18),Ui.dp(this,9));guide.setBackground(Ui.stroke(0xDD091321,0x553C4F6C,14,this));
            epgNow=Ui.text(this,"AGORA  Carregando programação...",Ui.phone(this)?11:13,Color.WHITE,true);epgNext=Ui.text(this,"A SEGUIR  —",Ui.phone(this)?10:11,Ui.MUTED,false);epgNow.setMaxLines(1);epgNext.setMaxLines(1);guide.addView(epgNow,new LinearLayout.LayoutParams(-1,Ui.dp(this,25)));guide.addView(epgNext,new LinearLayout.LayoutParams(-1,Ui.dp(this,22)));
            FrameLayout.LayoutParams gp=new FrameLayout.LayoutParams(-1,Ui.dp(this,62),Gravity.BOTTOM);gp.leftMargin=Ui.dp(this,Ui.phone(this)?10:24);gp.rightMargin=Ui.dp(this,Ui.phone(this)?10:24);gp.bottomMargin=Ui.dp(this,16);root.addView(guide,gp);
        }

        root.setOnClickListener(v->{if(controls.getVisibility()==View.VISIBLE)controls.setVisibility(View.GONE);else showControls();});
        showControls();back.requestFocus();return root;
    }

    private void play(){
        long id=getIntent().getLongExtra("id",0);String url=ApiClient.streamUrl(id);video.setOnPreparedListener(mp->{loading.setVisibility(View.GONE);mp.setScreenOnWhilePlaying(true);if(resumePos>0&&!live)video.seekTo(resumePos);video.start();playPause.setText("❚❚");handler.post(progressTask);scheduleHide();});
        video.setOnCompletionListener(mp->{playPause.setText("▶");showControls();});
        video.setOnErrorListener((mp,what,extra)->{loading.setVisibility(View.GONE);showControls();Toast.makeText(this,"Não foi possível reproduzir este conteúdo.",Toast.LENGTH_LONG).show();return true;});
        video.setVideoURI(Uri.parse(url));video.requestFocus();if(live)loadEpg(id);
    }

    private void togglePlayback(){if(video==null)return;if(video.isPlaying()){video.pause();playPause.setText("▶");showControls();}else{video.start();playPause.setText("❚❚");scheduleHide();}}
    private void seekBy(int delta){if(video==null||live)return;int dur=video.getDuration();int pos=Math.max(0,Math.min(dur,video.getCurrentPosition()+delta));video.seekTo(pos);showControls();scheduleHide();}
    private void showControls(){handler.removeCallbacks(hideTask);controls.setVisibility(View.VISIBLE);}
    private void scheduleHide(){handler.removeCallbacks(hideTask);handler.postDelayed(hideTask,4000);}

    @Override public boolean onKeyDown(int keyCode, KeyEvent event){
        if(keyCode==KeyEvent.KEYCODE_DPAD_CENTER||keyCode==KeyEvent.KEYCODE_ENTER||keyCode==KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE){togglePlayback();return true;}
        if(!live && keyCode==KeyEvent.KEYCODE_DPAD_LEFT){seekBy(-10000);return true;}
        if(!live && keyCode==KeyEvent.KEYCODE_DPAD_RIGHT){seekBy(10000);return true;}
        showControls();return super.onKeyDown(keyCode,event);
    }

    private void loadEpg(long id){ApiClient.epg(id,new ApiClient.Callback<ApiClient.EpgInfo>(){public void ok(ApiClient.EpgInfo i){runOnUiThread(()->{if(epgNow!=null)epgNow.setText(clean(i.nowTitle,"").isEmpty()?"AGORA  Programação não disponível":"AGORA  "+i.nowTitle);if(epgNext!=null)epgNext.setText(clean(i.nextTitle,"").isEmpty()?"A SEGUIR  —":"A SEGUIR  "+i.nextTitle);});}public void error(String m){runOnUiThread(()->{if(epgNow!=null)epgNow.setText("AGORA  Programação não disponível");if(epgNext!=null)epgNext.setText("A SEGUIR  —");});}});}

    @Override protected void onSaveInstanceState(Bundle out){if(video!=null&&!live)out.putInt("pos",video.getCurrentPosition());super.onSaveInstanceState(out);}
    @Override protected void onStop(){handler.removeCallbacksAndMessages(null);if(video!=null)video.stopPlayback();super.onStop();}
    private String clean(String v,String fallback){if(v==null)return fallback;String s=v.trim();return s.isEmpty()||"null".equalsIgnoreCase(s)?fallback:s;}
    private String time(int ms){int sec=Math.max(0,ms/1000),m=sec/60,s=sec%60;int h=m/60;m%=60;return h>0?String.format(java.util.Locale.US,"%d:%02d:%02d",h,m,s):String.format(java.util.Locale.US,"%02d:%02d",m,s);}
    private void immersive(){getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);}
}
