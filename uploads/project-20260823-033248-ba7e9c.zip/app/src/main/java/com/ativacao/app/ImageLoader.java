package com.ativacao.app;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.widget.ImageView;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.LinkedHashMap;
import java.util.Map;

final class ImageLoader {
    private static final int MAX = 80;
    private static final Map<String, Bitmap> CACHE = new LinkedHashMap<String, Bitmap>(MAX, .75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<String, Bitmap> eldest) { return size() > MAX; }
    };

    static void into(Activity a, ImageView target, String url) {
        target.setImageDrawable(null);
        if (url == null || url.trim().isEmpty()) return;
        final String u = url.trim();
        target.setTag(u);
        Bitmap hit;
        synchronized (CACHE) { hit = CACHE.get(u); }
        if (hit != null) { target.setImageBitmap(hit); return; }

        ApiClient.IO.execute(() -> {
            HttpURLConnection con = null;
            try {
                con = (HttpURLConnection) new URL(u).openConnection();
                con.setConnectTimeout(8000);
                con.setReadTimeout(12000);
                con.setInstanceFollowRedirects(true);
                con.setRequestProperty("User-Agent", "DubaiPlayTV/1.2 Android");
                Bitmap bmp = BitmapFactory.decodeStream(con.getInputStream());
                if (bmp != null) {
                    synchronized (CACHE) { CACHE.put(u, bmp); }
                    Bitmap finalBmp = bmp;
                    a.runOnUiThread(() -> { if (u.equals(target.getTag())) target.setImageBitmap(finalBmp); });
                }
            } catch (Exception ignored) {
            } finally { if (con != null) con.disconnect(); }
        });
    }

    static void clear() { synchronized (CACHE) { CACHE.clear(); } }
}
