package com.ativacao.app;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.PlayerView;

import java.util.ArrayList;
import java.util.List;

/**
 * Tela de TV inspirada no fluxo enviado pelo usuário:
 * menu superior + lista fixa à esquerda + preview à direita.
 * Enter abre o canal em tela cheia; Voltar retorna uma etapa por vez.
 */
public class LiveTvActivity extends android.app.Activity {
    private final List<ApiClient.Item> channels = new ArrayList<>();
    private LinearLayout rows;
    private PlayerView preview;
    private ExoPlayer player;
    private TextView title, epgNow, epgNext, speed;
    private ProgressBar loading;
    private ApiClient.Item current;
    private View currentRow;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        immersive();
        setContentView(build());
        loadChannels();
    }

    private View build() {
        LinearLayout root = Ui.column(this);
        root.setBackground(Ui.diagonalGradient(Color.rgb(82, 4, 10), Color.rgb(24, 2, 5), 0, this));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(Ui.dp(this, 18), Ui.dp(this, 4), Ui.dp(this, 18), 0);
        TextView brand = Ui.text(this, "▣  DUBAI PLAY", Ui.phone(this)?13:16, Color.WHITE, true);
        header.addView(brand, new LinearLayout.LayoutParams(Ui.dp(this, 190), -1));
        LinearLayout nav = new LinearLayout(this); nav.setGravity(Gravity.CENTER_VERTICAL);
        addNav(nav,"TV",true, null);
        addNav(nav,"DESTAQUES",false, () -> openMain());
        addNav(nav,"FILMES",false, () -> openCatalog("movie","Filmes"));
        addNav(nav,"SÉRIES",false, () -> openCatalog("series","Séries"));
        addNav(nav,"KIDS",false, () -> openDiscover("kids","Kids"));
        addNav(nav,"ANIME",false, () -> openDiscover("anime","Anime"));
        addNav(nav,"EXPLORAR",false, () -> openDiscover("","Explorar"));
        header.addView(nav, new LinearLayout.LayoutParams(0,-1,1));
        TextView clock = Ui.text(this,"⌕   ◷   ♙   ◉",10,Color.WHITE,false); clock.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        header.addView(clock,new LinearLayout.LayoutParams(Ui.dp(this,150),-1));
        root.addView(header,new LinearLayout.LayoutParams(-1,Ui.dp(this,58)));

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.HORIZONTAL);
        content.setPadding(Ui.dp(this, 18), Ui.dp(this, 8), Ui.dp(this, 18), Ui.dp(this, 14));

        LinearLayout left = Ui.column(this);
        TextView lh=Ui.text(this,"Lista de Canais",13,Color.WHITE,true); lh.setGravity(Gravity.CENTER);
        left.addView(lh,new LinearLayout.LayoutParams(-1,Ui.dp(this,34)));
        ScrollView sc=new ScrollView(this); sc.setVerticalScrollBarEnabled(false);
        rows=Ui.column(this); sc.addView(rows,new ScrollView.LayoutParams(-1,-2));
        left.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout.LayoutParams lpLeft=new LinearLayout.LayoutParams(Ui.dp(this,Ui.phone(this)?250:305),-1);
        lpLeft.rightMargin=Ui.dp(this,12); content.addView(left,lpLeft);

        FrameLayout playerCard=new FrameLayout(this);
        playerCard.setBackground(Ui.stroke(Color.BLACK,0x445A677A,6,this));
        preview=new PlayerView(this); preview.setUseController(false); preview.setBackgroundColor(Color.BLACK); preview.setKeepScreenOn(true);
        playerCard.addView(preview,new FrameLayout.LayoutParams(-1,-1));
        loading=new ProgressBar(this); playerCard.addView(loading,new FrameLayout.LayoutParams(Ui.dp(this,42),Ui.dp(this,42),Gravity.CENTER));

        LinearLayout info=Ui.column(this); info.setPadding(Ui.dp(this,14),Ui.dp(this,8),Ui.dp(this,14),Ui.dp(this,8)); info.setBackgroundColor(0xA8101010);
        title=Ui.text(this,"Carregando canal...",12,Color.WHITE,true); title.setMaxLines(1); info.addView(title,new LinearLayout.LayoutParams(-1,Ui.dp(this,26)));
        epgNow=Ui.text(this,"AGORA  —",9,Color.WHITE,true); epgNow.setMaxLines(1); info.addView(epgNow,new LinearLayout.LayoutParams(-1,Ui.dp(this,22)));
        epgNext=Ui.text(this,"A SEGUIR  —",9,Ui.MUTED,false); epgNext.setMaxLines(1); info.addView(epgNext,new LinearLayout.LayoutParams(-1,Ui.dp(this,22)));
        speed=Ui.text(this,"Enter: tela cheia",9,Ui.MUTED,true); speed.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); info.addView(speed,new LinearLayout.LayoutParams(-1,Ui.dp(this,22)));
        FrameLayout.LayoutParams ip=new FrameLayout.LayoutParams(-1,Ui.dp(this,92),Gravity.BOTTOM); playerCard.addView(info,ip);
        playerCard.setFocusable(true); playerCard.setClickable(true); playerCard.setOnClickListener(v -> openFullscreen());
        content.addView(playerCard,new LinearLayout.LayoutParams(0,-1,1));
        root.addView(content,new LinearLayout.LayoutParams(-1,0,1));
        return root;
    }

    private void addNav(LinearLayout row,String label,boolean selected,Runnable action){
        TextView v=Ui.nav(this,label,selected); if(action!=null)v.setOnClickListener(x->action.run());
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1); row.addView(v,p);
    }

    private void loadChannels(){
        ApiClient.catalog("live",1,200,"","","",new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){runOnUiThread(()->render(p==null?null:p.items));}
            public void error(String m){runOnUiThread(()->Toast.makeText(LiveTvActivity.this,"Não foi possível carregar os canais",Toast.LENGTH_LONG).show());}
        });
    }

    private void render(List<ApiClient.Item> list){
        rows.removeAllViews(); channels.clear(); if(list!=null)channels.addAll(list);
        if(channels.isEmpty()){ rows.addView(Ui.text(this,"Nenhum canal disponível",11,Ui.MUTED,false)); return; }
        ApiClient.Item last=LocalStore.lastLive(this); ApiClient.Item initial=null;
        if(last!=null) for(ApiClient.Item x:channels) if(x.id==last.id){initial=x;break;}
        if(initial==null) initial=channels.get(0);
        View focus=null;
        int n=1;
        for(ApiClient.Item i:channels){
            LinearLayout r=new LinearLayout(this); r.setGravity(Gravity.CENTER_VERTICAL); r.setPadding(Ui.dp(this,8),0,Ui.dp(this,8),0); r.setFocusable(true); r.setClickable(true);
            TextView num=Ui.text(this,String.valueOf(n++),10,Color.WHITE,true); num.setGravity(Gravity.CENTER); r.addView(num,new LinearLayout.LayoutParams(Ui.dp(this,28),-1));
            TextView name=Ui.text(this,clean(i.name,"Canal"),10,Color.WHITE,false); name.setMaxLines(1); r.addView(name,new LinearLayout.LayoutParams(0,-1,1));
            Ui.focus(r,this,Ui.round(0x3010090B,5,this),Ui.stroke(0x80451A1F,Ui.GREEN,5,this));
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,Ui.dp(this,42)); rp.bottomMargin=Ui.dp(this,2); rows.addView(r,rp);
            r.setOnFocusChangeListener((v,has)->{ if(has){v.setBackground(Ui.stroke(0x80451A1F,Ui.GREEN,5,this)); previewChannel(i,v);} else if(v!=currentRow)v.setBackground(Ui.round(0x3010090B,5,this)); });
            r.setOnClickListener(v->{previewChannel(i,v); openFullscreen();});
            if(i.id==initial.id) focus=r;
        }
        previewChannel(initial,focus);
        if(focus!=null)focus.requestFocus();
    }

    private void previewChannel(ApiClient.Item i, View row){
        if(i==null)return;
        if(current!=null && current.id==i.id){currentRow=row;return;}
        current=i; currentRow=row; LocalStore.saveLastLive(this,i);
        title.setText(clean(i.name,"Canal")); epgNow.setText("AGORA  Carregando programação..."); epgNext.setText("A SEGUIR  —");
        loadEpg(i.id); startPreview(i.id);
    }

    private void startPreview(long id){
        loading.setVisibility(View.VISIBLE);
        if(player!=null){try{player.release();}catch(Exception ignored){}}
        DefaultHttpDataSource.Factory http=new DefaultHttpDataSource.Factory().setUserAgent("DubaiPlayTV/2.5.7 Android").setConnectTimeoutMs(6000).setReadTimeoutMs(30000).setAllowCrossProtocolRedirects(true);
        player=new ExoPlayer.Builder(this).setMediaSourceFactory(new DefaultMediaSourceFactory(this).setDataSourceFactory(http)).build();
        preview.setPlayer(player);
        player.addListener(new Player.Listener(){@Override public void onPlaybackStateChanged(int state){if(state==Player.STATE_READY)loading.setVisibility(View.GONE);}});
        player.setMediaItem(MediaItem.fromUri(ApiClient.streamUrl(id))); player.prepare(); player.play();
    }

    private void loadEpg(long id){
        ApiClient.epg(id,new ApiClient.Callback<ApiClient.EpgInfo>(){
            public void ok(ApiClient.EpgInfo e){runOnUiThread(()->{if(current==null||current.id!=id)return; epgNow.setText("AGORA  "+clean(e.nowTitle,"Sem informação")); epgNext.setText("A SEGUIR  "+clean(e.nextTitle,"—"));});}
            public void error(String m){runOnUiThread(()->{if(current!=null&&current.id==id){epgNow.setText("AGORA  Sem informação");epgNext.setText("A SEGUIR  —");}});}
        });
    }

    private void openFullscreen(){
        if(current==null)return;
        Intent in=new Intent(this,PlayerActivity.class); MainActivity.putItem(in,current); in.putExtra("from_live_tv_page",true); startActivity(in);
    }
    private void openMain(){finish();}
    private void openCatalog(String type,String ttl){Intent in=new Intent(this,CatalogActivity.class);in.putExtra("type",type);in.putExtra("title",ttl);startActivity(in);}
    private void openDiscover(String smart,String ttl){Intent in=new Intent(this,DiscoverActivity.class);in.putExtra("smart",smart);in.putExtra("title",ttl);startActivity(in);}

    @Override public boolean onKeyDown(int keyCode, KeyEvent e){
        if((keyCode==KeyEvent.KEYCODE_DPAD_RIGHT || keyCode==KeyEvent.KEYCODE_ENTER || keyCode==KeyEvent.KEYCODE_DPAD_CENTER) && currentRow!=null && currentRow.hasFocus()){
            if(keyCode!=KeyEvent.KEYCODE_DPAD_RIGHT) openFullscreen();
            return true;
        }
        return super.onKeyDown(keyCode,e);
    }
    @Override public void onBackPressed(){finish();}
    @Override protected void onResume(){super.onResume();immersive();}
    @Override protected void onDestroy(){super.onDestroy();if(player!=null){try{player.release();}catch(Exception ignored){}}}
    private void immersive(){WindowCompat.setDecorFitsSystemWindows(getWindow(),false);WindowInsetsControllerCompat c=WindowCompat.getInsetsController(getWindow(),getWindow().getDecorView());c.hide(WindowInsetsCompat.Type.systemBars());c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);}
    private String clean(String v,String f){if(v==null)return f;String s=v.trim();return s.isEmpty()||"null".equalsIgnoreCase(s)?f:s;}
}
