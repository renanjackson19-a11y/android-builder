package com.ativacao.app;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.PlayerView;
import androidx.media3.ui.AspectRatioFrameLayout;

import java.util.ArrayList;
import java.util.List;

/** TV: lista/categorias à esquerda + preview à direita. Primeiro OK seleciona; segundo OK abre tela cheia. */
public class LiveTvActivity extends android.app.Activity {
    private final List<ApiClient.Item> allChannels = new ArrayList<>();
    private LinearLayout rows;
    private PlayerView preview;
    private FrameLayout playerCard;
    private FrameLayout shell, fullscreenLayer;
    private LinearLayout content;
    private LinearLayout.LayoutParams playerNormalLp;
    private boolean fullscreen = false;
    private ExoPlayer player;
    private TextView title, epgNow, epgNext, hint;
    private ProgressBar loading;
    private ApiClient.Item current;
    private View currentRow;
    private long armedChannelId = -1L;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        immersive();
        setContentView(build());
        loadChannels();
    }

    private View build() {
        shell = new FrameLayout(this);
        LinearLayout root = Ui.column(this);
        root.setBackgroundColor(Color.rgb(1,2,1));
        shell.addView(root,new FrameLayout.LayoutParams(-1,-1));

        fullscreenLayer = new FrameLayout(this);
        fullscreenLayer.setBackgroundColor(Color.BLACK);
        fullscreenLayer.setVisibility(View.GONE);
        shell.addView(fullscreenLayer,new FrameLayout.LayoutParams(-1,-1));

        // Top bar estilo appyellow: marca + navegação + conta
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(Ui.dp(this,20),0,Ui.dp(this,16),0);
        top.setBackgroundColor(Color.BLACK);

        TextView brand=Ui.text(this,"DUBAI PLAY",17,Ui.GREEN,true);
        top.addView(brand,new LinearLayout.LayoutParams(Ui.dp(this,190),-1));

        LinearLayout nav=new LinearLayout(this);
        nav.setGravity(Gravity.CENTER_VERTICAL);
        addNav(nav,"TV",true,null);
        addNav(nav,"DESTAQUES",false,this::openMain);
        addNav(nav,"FILMES",false,()->openCatalog("movie","Filmes"));
        addNav(nav,"SÉRIES",false,()->openCatalog("series","Séries"));
        addNav(nav,"KIDS",false,()->openDiscover("kids","Kids"));
        addNav(nav,"ANIME",false,()->openDiscover("anime","Anime"));
        addNav(nav,"EXPLORAR",false,()->openDiscover("explore","Explorar"));
        top.addView(nav,new LinearLayout.LayoutParams(0,-1,1));

        TextView search=Ui.ghostButton(this,"⌕");
        search.setOnClickListener(v->startActivity(new Intent(this,SearchActivity.class)));
        top.addView(search,new LinearLayout.LayoutParams(Ui.dp(this,44),Ui.dp(this,40)));
        TextView account=Ui.ghostButton(this,"♙");
        account.setContentDescription("Minha conta");
        account.setOnClickListener(v->startActivity(new Intent(this,ProfileActivity.class)));
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(Ui.dp(this,44),Ui.dp(this,40));ap.leftMargin=Ui.dp(this,6);
        top.addView(account,ap);
        root.addView(top,new LinearLayout.LayoutParams(-1,Ui.dp(this,64)));

        // Conteúdo em 2 áreas bem definidas
        LinearLayout contentWrap=new LinearLayout(this);
        contentWrap.setOrientation(LinearLayout.HORIZONTAL);
        contentWrap.setPadding(Ui.dp(this,22),Ui.dp(this,14),Ui.dp(this,22),Ui.dp(this,18));

        // Sidebar
        LinearLayout sidebar=Ui.column(this);
        sidebar.setBackground(Ui.round(0xFF080A08,10,this));
        sidebar.setPadding(Ui.dp(this,14),Ui.dp(this,14),Ui.dp(this,14),Ui.dp(this,12));

        TextView liveTitle=Ui.text(this,"AO VIVO",14,Ui.GREEN,true);
        sidebar.addView(liveTitle,new LinearLayout.LayoutParams(-1,Ui.dp(this,34)));
        TextView channelLabel=Ui.text(this,"CANAIS",9,0xFFB8BDB5,true);
        sidebar.addView(channelLabel,new LinearLayout.LayoutParams(-1,Ui.dp(this,26)));

        ScrollView sc=new ScrollView(this);
        sc.setVerticalScrollBarEnabled(false);
        sc.setFillViewport(true);
        rows=Ui.column(this);
        sc.addView(rows,new ScrollView.LayoutParams(-1,-2));
        sidebar.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout.LayoutParams sideLp=new LinearLayout.LayoutParams(Ui.dp(this,330),-1);
        sideLp.rightMargin=Ui.dp(this,18);
        contentWrap.addView(sidebar,sideLp);

        // Área direita: player + EPG separado
        LinearLayout right=Ui.column(this);

        playerCard=new FrameLayout(this);
        playerCard.setFocusable(true);
        playerCard.setClickable(true);
        playerCard.setBackground(Ui.stroke(Color.BLACK,0xFF343A2C,8,this));
        preview=new PlayerView(this);
        preview.setUseController(false);
        preview.setBackgroundColor(Color.BLACK);
        preview.setKeepScreenOn(true);
        preview.setFocusable(false);
        preview.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        playerCard.addView(preview,new FrameLayout.LayoutParams(-1,-1));
        loading=new ProgressBar(this);
        playerCard.addView(loading,new FrameLayout.LayoutParams(Ui.dp(this,44),Ui.dp(this,44),Gravity.CENTER));
        playerCard.setOnClickListener(v->openFullscreen());
        playerNormalLp=new LinearLayout.LayoutParams(-1,0,1);
        right.addView(playerCard,playerNormalLp);

        LinearLayout epg=Ui.column(this);
        epg.setBackground(Ui.round(0xFF0B0D0A,8,this));
        epg.setPadding(Ui.dp(this,18),Ui.dp(this,10),Ui.dp(this,18),Ui.dp(this,8));
        title=Ui.text(this,"Carregando canal...",16,Color.WHITE,true);
        title.setMaxLines(1);
        epg.addView(title,new LinearLayout.LayoutParams(-1,Ui.dp(this,32)));
        epgNow=Ui.text(this,"AGORA  —",10,Ui.GREEN,true);
        epgNow.setMaxLines(1);
        epg.addView(epgNow,new LinearLayout.LayoutParams(-1,Ui.dp(this,25)));
        epgNext=Ui.text(this,"A SEGUIR  —",10,0xFFCCD0C8,false);
        epgNext.setMaxLines(1);
        epg.addView(epgNext,new LinearLayout.LayoutParams(-1,Ui.dp(this,25)));
        hint=Ui.text(this,"OK seleciona • OK novamente abre tela cheia",8,0xFF8E958A,false);
        hint.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        epg.addView(hint,new LinearLayout.LayoutParams(-1,Ui.dp(this,22)));

        LinearLayout.LayoutParams epgLp=new LinearLayout.LayoutParams(-1,Ui.dp(this,112));
        epgLp.topMargin=Ui.dp(this,10);
        right.addView(epg,epgLp);
        contentWrap.addView(right,new LinearLayout.LayoutParams(0,-1,1));

        root.addView(contentWrap,new LinearLayout.LayoutParams(-1,0,1));
        return shell;
    }

    private void addNav(LinearLayout row,String label,boolean selected,Runnable action){
        TextView v=Ui.nav(this,label,selected); if(action!=null)v.setOnClickListener(x->action.run());
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1); row.addView(v,p);
    }

    private void loadChannels(){
        loadChannelPage(1, new ArrayList<>());
    }

    private void loadChannelPage(int page, List<ApiClient.Item> acc){
        ApiClient.catalog("live",page,72,"","","",new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){
                if(p!=null && p.items!=null) acc.addAll(p.items);
                int pages = p==null ? 1 : Math.max(1,p.pages);
                if(page < pages){
                    loadChannelPage(page+1, acc);
                    return;
                }
                runOnUiThread(()->renderAll(acc));
            }
            public void error(String m){
                if(!acc.isEmpty()){runOnUiThread(()->renderAll(acc));return;}
                runOnUiThread(()->Toast.makeText(LiveTvActivity.this,"Não foi possível carregar os canais",Toast.LENGTH_LONG).show());
            }
        });
    }

    private void renderAll(List<ApiClient.Item> list){
        allChannels.clear(); if(list!=null)allChannels.addAll(list);
        renderRows();
    }


    private void renderRows(){
        rows.removeAllViews();
        List<ApiClient.Item> visible=new ArrayList<>();
        for(ApiClient.Item i:allChannels){
            visible.add(i);
        }
        if(visible.isEmpty()){rows.addView(Ui.text(this,"Nenhum canal nesta categoria",10,Ui.MUTED,false));return;}

        ApiClient.Item last=LocalStore.lastLive(this); ApiClient.Item initial=null;
        if(current!=null) for(ApiClient.Item x:visible)if(x.id==current.id){initial=x;break;}
        if(initial==null&&last!=null)for(ApiClient.Item x:visible)if(x.id==last.id){initial=x;break;}
        if(initial==null)initial=visible.get(0);
        View focus=null; int n=1;
        for(ApiClient.Item i:visible){
            LinearLayout r=new LinearLayout(this); r.setGravity(Gravity.CENTER_VERTICAL); r.setPadding(Ui.dp(this,6),Ui.dp(this,5),Ui.dp(this,8),Ui.dp(this,5)); r.setFocusable(true); r.setClickable(true);
            TextView num=Ui.text(this,String.valueOf(n++),9,Ui.MUTED,true); num.setGravity(Gravity.CENTER); r.addView(num,new LinearLayout.LayoutParams(Ui.dp(this,28),-1));
            ImageView logo=new ImageView(this);logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);logo.setBackground(Ui.round(0x25FFFFFF,7,this));ImageLoader.into(this,logo,i.logo);
            LinearLayout.LayoutParams lip=new LinearLayout.LayoutParams(Ui.dp(this,52),Ui.dp(this,52));lip.rightMargin=Ui.dp(this,9);r.addView(logo,lip);
            TextView name=Ui.text(this,clean(i.name,"Canal"),10,Color.WHITE,true);name.setMaxLines(1);name.setGravity(Gravity.CENTER_VERTICAL);
            r.addView(name,new LinearLayout.LayoutParams(0,-1,1));
            TextView fav=Ui.text(this,LocalStore.isFavorite(this,i.id)?"★":"☆",17,LocalStore.isFavorite(this,i.id)?Ui.GREEN:0xFF777D74,true);
            fav.setGravity(Gravity.CENTER); fav.setFocusable(true); fav.setClickable(true);
            fav.setOnClickListener(v->{LocalStore.toggleFavorite(this,i); boolean yes=LocalStore.isFavorite(this,i.id); fav.setText(yes?"★":"☆"); fav.setTextColor(yes?Ui.GREEN:0xFF777D74);});
            r.addView(fav,new LinearLayout.LayoutParams(Ui.dp(this,38),-1));
            android.graphics.drawable.Drawable normal=Ui.round(0xFF11130F,6,this), focused=Ui.stroke(0xFF1C1F17,Ui.GREEN,6,this);
            r.setBackground(normal);
            r.setOnFocusChangeListener((v,has)->{
                v.animate().scaleX(has?1.015f:1f).scaleY(has?1.015f:1f).setDuration(90).start();
                v.setBackground(has?focused:normal);
                if(has){
                    if(current==null || current.id!=i.id){
                        armedChannelId=-1L;
                        previewChannel(i,v);
                    } else {
                        currentRow=v;
                    }
                }
            });
            r.setOnClickListener(v->{
                // OK em OUTRO canal: troca o preview uma única vez e arma o canal.
                // OK no MESMO canal: não recarrega; segundo OK abre tela cheia.
                if(current==null || current.id!=i.id){
                    armedChannelId=i.id;
                    previewChannel(i,v);
                    currentRow=v;
                    hint.setText("OK novamente: tela cheia  •  ou OK no preview");
                    return;
                }
                if(armedChannelId==i.id){
                    openFullscreen();
                    return;
                }
                armedChannelId=i.id;
                currentRow=v;
                hint.setText("OK novamente: tela cheia  •  ou OK no preview");
            });
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,Ui.dp(this,68)); rp.bottomMargin=Ui.dp(this,5); rows.addView(r,rp);
            if(i.id==initial.id)focus=r;
        }
        previewChannel(initial,focus); if(focus!=null)focus.requestFocus();
    }

    private void previewChannel(ApiClient.Item i, View row){
        if(i==null)return;
        if(current!=null && current.id==i.id){currentRow=row;return;}
        current=i; currentRow=row; LocalStore.saveLastLive(this,i);
        title.setText(clean(i.name,"Canal")); epgNow.setText("AGORA  Carregando programação..."); epgNext.setText("A SEGUIR  —"); hint.setText("1º OK seleciona • 2º OK abre tela cheia");
        loadEpg(i.id); startPreview(i.id);
    }

    private void startPreview(long id){
        loading.setVisibility(View.VISIBLE);
        if(player!=null){try{player.release();}catch(Exception ignored){}}
        DefaultHttpDataSource.Factory http=new DefaultHttpDataSource.Factory().setUserAgent("DubaiPlayTV/2.9.0 Android").setConnectTimeoutMs(6000).setReadTimeoutMs(30000).setAllowCrossProtocolRedirects(true);
        player=new ExoPlayer.Builder(this).setMediaSourceFactory(new DefaultMediaSourceFactory(this).setDataSourceFactory(http)).build();
        preview.setPlayer(player);
        player.addListener(new Player.Listener(){@Override public void onPlaybackStateChanged(int state){if(state==Player.STATE_READY)loading.setVisibility(View.GONE);}});
        player.setMediaItem(MediaItem.fromUri(ApiClient.streamUrl(id))); player.prepare(); player.play();
    }

    private void loadEpg(long id){
        ApiClient.epg(id,new ApiClient.Callback<ApiClient.EpgInfo>(){
            public void ok(ApiClient.EpgInfo e){runOnUiThread(()->{if(current==null||current.id!=id)return;epgNow.setText("AGORA  "+clean(e.nowTitle,"Sem informação"));epgNext.setText("A SEGUIR  "+clean(e.nextTitle,"—"));});}
            public void error(String m){runOnUiThread(()->{if(current!=null&&current.id==id){epgNow.setText("AGORA  Sem informação");epgNext.setText("A SEGUIR  —");}});}
        });
    }

    private void openFullscreen(){
        if(current==null || fullscreen)return;
        fullscreen=true;
        if(playerCard.getParent() instanceof android.view.ViewGroup){
            ((android.view.ViewGroup)playerCard.getParent()).removeView(playerCard);
        }
        fullscreenLayer.removeAllViews();
        preview.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FILL);
        fullscreenLayer.addView(playerCard,new FrameLayout.LayoutParams(-1,-1));
        fullscreenLayer.setVisibility(View.VISIBLE);
        fullscreenLayer.bringToFront();
        hint.setText("VOLTAR: lista de canais");
        playerCard.requestFocus();
        immersive();
    }

    private void closeFullscreen(){
        if(!fullscreen)return;
        fullscreen=false;
        if(playerCard.getParent() instanceof android.view.ViewGroup){
            ((android.view.ViewGroup)playerCard.getParent()).removeView(playerCard);
        }
        fullscreenLayer.setVisibility(View.GONE);
        preview.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        content.addView(playerCard,playerNormalLp);
        hint.setText("1º OK seleciona • 2º OK abre tela cheia");
        if(currentRow!=null) currentRow.requestFocus();
        immersive();
    }

    private void openMain(){Intent in=new Intent(this,MainActivity.class);in.putExtra("show_highlights",true);startActivity(in);finish();}
    private void openCatalog(String type,String name){Intent in=new Intent(this,CatalogActivity.class);in.putExtra("type",type);in.putExtra("title",name);startActivity(in);}
    private void openDiscover(String smart,String name){Intent in=new Intent(this,DiscoverActivity.class);in.putExtra("smart",smart);in.putExtra("title",name);startActivity(in);}

    @Override public void onBackPressed(){if(fullscreen){closeFullscreen();return;}finish();}
    @Override protected void onResume(){super.onResume();immersive();if(player!=null)player.play();}
    @Override protected void onPause(){if(player!=null)player.pause();super.onPause();}
    @Override protected void onDestroy(){super.onDestroy();if(player!=null){try{player.release();}catch(Exception ignored){}}}
    private void immersive(){WindowCompat.setDecorFitsSystemWindows(getWindow(),false);WindowInsetsControllerCompat c=WindowCompat.getInsetsController(getWindow(),getWindow().getDecorView());c.hide(WindowInsetsCompat.Type.systemBars());c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);}
    private String clean(String v,String f){if(v==null)return f;String s=v.trim();return s.isEmpty()||"null".equalsIgnoreCase(s)?f:s;}
}
