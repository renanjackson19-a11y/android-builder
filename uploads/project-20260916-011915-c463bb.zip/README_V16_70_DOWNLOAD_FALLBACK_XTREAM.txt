GreenPlay Android v16.70

Correção do download offline sobre a v16.69.

- Download tenta todas as URLs/qualidades disponíveis antes de falhar.
- Suporte mais robusto a redirecionamentos HTTP/HTTPS.
- Se um servidor rejeitar Origin/Referer, tenta novamente com cabeçalhos mínimos.
- HLS e arquivo direto continuam suportados.
- Downloads passam a usar chave provider + tipo + id, evitando colisão entre filme/série/episódio com IDs iguais.
- Repetir um download com falha reutiliza a lista completa de fontes.
- Nenhuma alteração no painel v72.8.
