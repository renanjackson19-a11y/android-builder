package com.r7ativador.painel;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.app.KeyguardManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.hardware.biometrics.BiometricPrompt;
import android.hardware.fingerprint.FingerprintManager;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Environment;
import android.provider.Settings;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.SslErrorHandler;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.concurrent.Executor;

public class MainActivity extends Activity {
    private static final String PANEL_URL = "https://painel.br232uni.shop/";
    private static final int FILE_CHOOSER_REQUEST = 701;
    private static final int DEVICE_CREDENTIAL_REQUEST = 702;
    private static final int STORAGE_PERMISSION_REQUEST = 703;
    private static final long AUTO_LOCK_AFTER_MS = 120_000L;

    private WebView webView;
    private ProgressBar progressBar;
    private ValueCallback<Uri[]> fileCallback;
    private CancellationSignal biometricCancellation;
    private TextView securityStatus;
    private Button biometricButton;
    private boolean authenticated = false;
    private boolean appInterfaceVisible = false;
    private long backgroundAt = 0L;
    private String currentUrl = PANEL_URL;

    private String pendingDownloadUrl;
    private String pendingDownloadUserAgent;
    private String pendingDownloadDisposition;
    private String pendingDownloadMime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.parseColor("#07080C"));
        getWindow().setNavigationBarColor(Color.parseColor("#07080C"));
        showSecurityGate(true);
    }

    private void showSecurityGate(boolean authenticateAutomatically) {
        authenticated = false;
        appInterfaceVisible = false;
        destroyWebView();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(28), dp(24), dp(24));
        root.setBackgroundColor(Color.parseColor("#07080C"));
        root.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        Space topSpace = new Space(this);
        root.addView(topSpace, new LinearLayout.LayoutParams(1, 0, 0.7f));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        root.addView(logo, new LinearLayout.LayoutParams(dp(132), dp(132)));

        TextView badge = new TextView(this);
        badge.setText("ACESSO SEGURO");
        badge.setTextColor(Color.WHITE);
        badge.setTextSize(12);
        badge.setGravity(Gravity.CENTER);
        badge.setTypeface(null, android.graphics.Typeface.BOLD);
        badge.setLetterSpacing(0.16f);
        badge.setBackgroundResource(R.drawable.bg_badge);
        LinearLayout.LayoutParams badgeParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        badgeParams.topMargin = dp(18);
        root.addView(badge, badgeParams);

        TextView title = new TextView(this);
        title.setText("Painel R7 Ativador");
        title.setTextColor(Color.WHITE);
        title.setTextSize(29);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        titleParams.topMargin = dp(22);
        root.addView(title, titleParams);

        TextView subtitle = new TextView(this);
        subtitle.setText("Acesso protegido ao seu painel");
        subtitle.setTextColor(Color.parseColor("#B5BAC5"));
        subtitle.setTextSize(16);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subtitleParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        subtitleParams.topMargin = dp(6);
        root.addView(subtitle, subtitleParams);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(dp(22), dp(22), dp(22), dp(22));
        card.setBackgroundResource(R.drawable.bg_security_card);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) card.setElevation(dp(8));
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        cardParams.topMargin = dp(28);
        root.addView(card, cardParams);

        ImageView lockIcon = new ImageView(this);
        lockIcon.setImageResource(android.R.drawable.ic_lock_lock);
        lockIcon.setColorFilter(Color.parseColor("#FF3A32"));
        card.addView(lockIcon, new LinearLayout.LayoutParams(dp(54), dp(54)));

        TextView cardTitle = new TextView(this);
        cardTitle.setText("Confirme sua identidade");
        cardTitle.setTextColor(Color.WHITE);
        cardTitle.setTextSize(20);
        cardTitle.setGravity(Gravity.CENTER);
        cardTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams cardTitleParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        cardTitleParams.topMargin = dp(12);
        card.addView(cardTitle, cardTitleParams);

        securityStatus = new TextView(this);
        securityStatus.setText("Use sua biometria para entrar com segurança.");
        securityStatus.setTextColor(Color.parseColor("#AEB3BE"));
        securityStatus.setTextSize(14);
        securityStatus.setGravity(Gravity.CENTER);
        securityStatus.setPadding(0, dp(8), 0, 0);
        card.addView(securityStatus, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        biometricButton = createActionButton("ENTRAR COM BIOMETRIA", true);
        biometricButton.setOnClickListener(v -> authenticateUser());
        LinearLayout.LayoutParams primaryParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(58));
        primaryParams.topMargin = dp(22);
        card.addView(biometricButton, primaryParams);

        Button credentialButton = createActionButton("USAR SENHA OU PIN", false);
        credentialButton.setOnClickListener(v -> launchDeviceCredential());
        LinearLayout.LayoutParams secondaryParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(54));
        secondaryParams.topMargin = dp(12);
        card.addView(credentialButton, secondaryParams);

        TextView privacy = new TextView(this);
        privacy.setText("A biometria é validada pelo próprio Android e não é enviada ao site.");
        privacy.setTextColor(Color.parseColor("#747A86"));
        privacy.setTextSize(12);
        privacy.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams privacyParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        privacyParams.topMargin = dp(18);
        card.addView(privacy, privacyParams);

        Space bottomSpace = new Space(this);
        root.addView(bottomSpace, new LinearLayout.LayoutParams(1, 0, 1f));

        TextView footer = new TextView(this);
        footer.setText("R7 ATIVADOR • CONEXÃO PROTEGIDA");
        footer.setTextColor(Color.parseColor("#6D717B"));
        footer.setTextSize(11);
        footer.setLetterSpacing(0.10f);
        footer.setGravity(Gravity.CENTER);
        root.addView(footer, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        setContentView(root);

        if (authenticateAutomatically) {
            root.postDelayed(this::authenticateUser, 450);
        }
    }

    private Button createActionButton(String text, boolean primary) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setTextSize(14);
        button.setTypeface(null, android.graphics.Typeface.BOLD);
        button.setAllCaps(false);
        button.setGravity(Gravity.CENTER);
        button.setBackgroundResource(primary ? R.drawable.bg_primary_button : R.drawable.bg_secondary_button);
        button.setFocusable(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) button.setElevation(dp(primary ? 6 : 2));
        return button;
    }

    private void authenticateUser() {
        if (authenticated) return;
        cancelBiometricPrompt();
        setSecurityStatus("Aguardando confirmação biométrica...", false);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            authenticateWithBiometricPrompt();
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            authenticateWithFingerprintManager();
        } else {
            launchDeviceCredential();
        }
    }

    private void authenticateWithBiometricPrompt() {
        Executor executor = command -> runOnUiThread(command);
        biometricCancellation = new CancellationSignal();
        BiometricPrompt prompt = new BiometricPrompt.Builder(this)
                .setTitle("Painel R7 Ativador")
                .setSubtitle("Confirme sua identidade para continuar")
                .setDescription("Acesso seguro ao painel")
                .setNegativeButton("Usar senha/PIN", executor, (dialog, which) -> launchDeviceCredential())
                .build();

        prompt.authenticate(biometricCancellation, executor, new BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                super.onAuthenticationSucceeded(result);
                unlockApplication();
            }

            @Override
            public void onAuthenticationFailed() {
                super.onAuthenticationFailed();
                setSecurityStatus("Biometria não reconhecida. Tente novamente.", true);
            }

            @Override
            public void onAuthenticationError(int errorCode, CharSequence errString) {
                super.onAuthenticationError(errorCode, errString);
                if (errorCode != BiometricPrompt.BIOMETRIC_ERROR_CANCELED
                        && errorCode != BiometricPrompt.BIOMETRIC_ERROR_USER_CANCELED
                        && errorCode != BiometricPrompt.BIOMETRIC_ERROR_NEGATIVE_BUTTON) {
                    setSecurityStatus(errString == null ? "Não foi possível validar a biometria." : errString.toString(), true);
                }
            }
        });
    }

    @SuppressWarnings("deprecation")
    private void authenticateWithFingerprintManager() {
        FingerprintManager manager = (FingerprintManager) getSystemService(Context.FINGERPRINT_SERVICE);
        if (manager == null || !manager.isHardwareDetected() || !manager.hasEnrolledFingerprints()) {
            setSecurityStatus("Biometria indisponível. Use a senha ou o PIN do aparelho.", true);
            launchDeviceCredential();
            return;
        }

        biometricCancellation = new CancellationSignal();
        manager.authenticate(null, biometricCancellation, 0, new FingerprintManager.AuthenticationCallback() {
            @Override
            public void onAuthenticationSucceeded(FingerprintManager.AuthenticationResult result) {
                super.onAuthenticationSucceeded(result);
                runOnUiThread(MainActivity.this::unlockApplication);
            }

            @Override
            public void onAuthenticationFailed() {
                super.onAuthenticationFailed();
                runOnUiThread(() -> setSecurityStatus("Biometria não reconhecida. Tente novamente.", true));
            }

            @Override
            public void onAuthenticationError(int errorCode, CharSequence errString) {
                super.onAuthenticationError(errorCode, errString);
                if (errorCode != FingerprintManager.FINGERPRINT_ERROR_CANCELED) {
                    runOnUiThread(() -> setSecurityStatus(
                            errString == null ? "Não foi possível validar a biometria." : errString.toString(), true));
                }
            }
        }, null);
    }

    private void launchDeviceCredential() {
        cancelBiometricPrompt();
        KeyguardManager keyguard = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
        if (keyguard != null && keyguard.isKeyguardSecure()) {
            Intent intent = keyguard.createConfirmDeviceCredentialIntent(
                    "Painel R7 Ativador",
                    "Confirme a senha, o PIN ou o padrão do aparelho");
            if (intent != null) {
                startActivityForResult(intent, DEVICE_CREDENTIAL_REQUEST);
                return;
            }
        }

        new AlertDialog.Builder(this)
                .setTitle("Proteção não configurada")
                .setMessage("Este aparelho não possui biometria nem bloqueio de tela configurado. Configure uma proteção no Android para usar o acesso seguro.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Abrir configurações", (dialog, which) -> {
                    try {
                        startActivity(new Intent(Settings.ACTION_SECURITY_SETTINGS));
                    } catch (Exception e) {
                        Toast.makeText(this, "Abra as configurações de segurança do aparelho.", Toast.LENGTH_LONG).show();
                    }
                })
                .show();
    }

    private void setSecurityStatus(String message, boolean error) {
        if (securityStatus != null) {
            securityStatus.setText(message);
            securityStatus.setTextColor(Color.parseColor(error ? "#FF837A" : "#AEB3BE"));
        }
    }

    private void unlockApplication() {
        cancelBiometricPrompt();
        authenticated = true;
        backgroundAt = 0L;
        buildAppInterface();
        configureWebView();
        loadUrl(currentUrl == null ? PANEL_URL : currentUrl);
    }

    private void buildAppInterface() {
        appInterfaceVisible = true;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#07080C"));
        root.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(14), dp(9), dp(10), dp(9));
        header.setBackgroundResource(R.drawable.bg_header);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(dp(48), dp(48));
        logoParams.setMarginEnd(dp(11));
        header.addView(logo, logoParams);

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView title = new TextView(this);
        title.setText("R7 ATIVADOR");
        title.setTextColor(Color.WHITE);
        title.setTextSize(19);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        TextView subtitle = new TextView(this);
        subtitle.setText("Painel protegido por biometria");
        subtitle.setTextColor(Color.parseColor("#FF766B"));
        subtitle.setTextSize(12);
        titles.addView(title);
        titles.addView(subtitle);
        header.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView lock = new TextView(this);
        lock.setText("🔒");
        lock.setTextSize(23);
        lock.setGravity(Gravity.CENTER);
        lock.setContentDescription("Bloquear aplicativo");
        lock.setOnClickListener(v -> showSecurityGate(true));
        header.addView(lock, new LinearLayout.LayoutParams(dp(48), dp(48)));
        root.addView(header, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        FrameLayout content = new FrameLayout(this);
        webView = new WebView(this);
        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            progressBar.setProgressTintList(android.content.res.ColorStateList.valueOf(Color.parseColor("#E50914")));
            progressBar.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.parseColor("#311015")));
        }

        content.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        FrameLayout.LayoutParams progressParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(3));
        progressParams.gravity = Gravity.TOP;
        content.addView(progressBar, progressParams);
        root.addView(content, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f));

        LinearLayout navigation = new LinearLayout(this);
        navigation.setOrientation(LinearLayout.HORIZONTAL);
        navigation.setGravity(Gravity.CENTER);
        navigation.setPadding(dp(8), dp(8), dp(8), dp(8));
        navigation.setBackgroundResource(R.drawable.bg_nav);

        Button home = createBottomButton("INÍCIO");
        Button reload = createBottomButton("ATUALIZAR");
        Button secure = createBottomButton("BLOQUEAR");
        home.setOnClickListener(v -> loadUrl(PANEL_URL));
        reload.setOnClickListener(v -> webView.reload());
        secure.setOnClickListener(v -> showSecurityGate(true));

        LinearLayout.LayoutParams navParams = new LinearLayout.LayoutParams(0, dp(48), 1f);
        navParams.setMargins(dp(4), 0, dp(4), 0);
        navigation.addView(home, navParams);
        navigation.addView(reload, navParams);
        navigation.addView(secure, navParams);
        root.addView(navigation, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        setContentView(root);
    }

    private Button createBottomButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setTextSize(12);
        button.setTypeface(null, android.graphics.Typeface.BOLD);
        button.setAllCaps(false);
        button.setGravity(Gravity.CENTER);
        button.setBackgroundResource(R.drawable.bg_secondary_button);
        button.setFocusable(true);
        return button;
    }

    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            settings.setSafeBrowsingEnabled(true);
        }
        settings.setUserAgentString(settings.getUserAgentString() + " R7PainelApp/1.0");

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            cookies.setAcceptThirdPartyCookies(webView, true);
        }

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                progressBar.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), FILE_CHOOSER_REQUEST);
                    return true;
                } catch (ActivityNotFoundException e) {
                    fileCallback = null;
                    Toast.makeText(MainActivity.this, "Nenhum seletor de arquivo disponível.", Toast.LENGTH_LONG).show();
                    return false;
                }
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                currentUrl = url;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                currentUrl = url;
                CookieManager.getInstance().flush();
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl().toString());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(url);
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, android.net.http.SslError error) {
                handler.cancel();
                Toast.makeText(MainActivity.this, "Não foi possível validar a segurança deste endereço.", Toast.LENGTH_LONG).show();
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && request.isForMainFrame()) showOfflinePage();
            }
        });

        webView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimeType, long contentLength) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                        && Build.VERSION.SDK_INT <= Build.VERSION_CODES.P
                        && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    pendingDownloadUrl = url;
                    pendingDownloadUserAgent = userAgent;
                    pendingDownloadDisposition = contentDisposition;
                    pendingDownloadMime = mimeType;
                    requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, STORAGE_PERMISSION_REQUEST);
                } else {
                    startDownload(url, userAgent, contentDisposition, mimeType);
                }
            }
        });
    }

    private boolean handleUrl(String url) {
        if (url == null || url.trim().isEmpty()) return true;
        Uri uri = Uri.parse(url);
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
        if (scheme.equals("http") || scheme.equals("https")) {
            webView.loadUrl(url);
            return true;
        }
        if (scheme.equals("tel") || scheme.equals("mailto") || scheme.equals("sms")
                || scheme.equals("whatsapp") || scheme.equals("intent") || scheme.equals("market")) {
            openExternal(url);
            return true;
        }
        return false;
    }

    private void openExternal(String url) {
        try {
            Intent intent = url.startsWith("intent://")
                    ? Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
                    : new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível abrir este link.", Toast.LENGTH_SHORT).show();
        }
    }

    private void startDownload(String url, String userAgent, String contentDisposition, String mimeType) {
        try {
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            if (userAgent != null) request.addRequestHeader("User-Agent", userAgent);
            String cookie = CookieManager.getInstance().getCookie(url);
            if (cookie != null) request.addRequestHeader("Cookie", cookie);
            if (mimeType != null) request.setMimeType(mimeType);
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(
                    Environment.DIRECTORY_DOWNLOADS,
                    guessFileName(url, contentDisposition));
            DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            manager.enqueue(request);
            Toast.makeText(this, "Download iniciado.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            openExternal(url);
        }
    }

    private void loadUrl(String url) {
        if (!hasInternet()) {
            showOfflinePage();
            return;
        }
        currentUrl = url;
        webView.loadUrl(url);
    }

    private void showOfflinePage() {
        String html = "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>" +
                "<style>body{margin:0;background:#07080c;color:#fff;font-family:Arial;display:flex;min-height:100vh;align-items:center;justify-content:center;text-align:center;padding:26px;box-sizing:border-box}.card{max-width:480px;background:#11131a;border:1px solid #402027;border-radius:22px;padding:30px}h2{color:#ff4a32}button{border:0;border-radius:14px;padding:15px 24px;background:linear-gradient(90deg,#b10811,#ff4a32);color:#fff;font-weight:700;font-size:16px}</style></head>" +
                "<body><div class='card'><h2>Sem conexão</h2><p>Verifique sua internet e toque abaixo para tentar novamente.</p><button onclick=\"location.href='" + PANEL_URL + "'\">TENTAR NOVAMENTE</button></div></body></html>";
        webView.loadDataWithBaseURL(PANEL_URL, html, "text/html", "UTF-8", null);
    }

    private boolean hasInternet() {
        ConnectivityManager manager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (manager == null) return true;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            android.net.Network network = manager.getActiveNetwork();
            if (network == null) return false;
            NetworkCapabilities caps = manager.getNetworkCapabilities(network);
            return caps != null && (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                    || caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
                    || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
                    || caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN));
        }
        android.net.NetworkInfo info = manager.getActiveNetworkInfo();
        return info != null && info.isConnected();
    }

    private String guessFileName(String url, String contentDisposition) {
        String name = android.webkit.URLUtil.guessFileName(url, contentDisposition, null);
        try {
            return URLDecoder.decode(name, StandardCharsets.UTF_8.name());
        } catch (Exception ignored) {
            return name;
        }
    }

    private void cancelBiometricPrompt() {
        if (biometricCancellation != null) {
            try {
                biometricCancellation.cancel();
            } catch (Exception ignored) {
            }
            biometricCancellation = null;
        }
    }

    private void destroyWebView() {
        if (webView != null) {
            try {
                webView.stopLoading();
                webView.setWebChromeClient(null);
                webView.setWebViewClient(null);
                webView.destroy();
            } catch (Exception ignored) {
            }
            webView = null;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && fileCallback != null) {
            Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        } else if (requestCode == DEVICE_CREDENTIAL_REQUEST) {
            if (resultCode == RESULT_OK) {
                unlockApplication();
            } else {
                setSecurityStatus("A confirmação foi cancelada.", true);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == STORAGE_PERMISSION_REQUEST && pendingDownloadUrl != null) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startDownload(pendingDownloadUrl, pendingDownloadUserAgent, pendingDownloadDisposition, pendingDownloadMime);
            } else {
                Toast.makeText(this, "Permissão necessária para salvar o arquivo.", Toast.LENGTH_LONG).show();
            }
            pendingDownloadUrl = null;
            pendingDownloadUserAgent = null;
            pendingDownloadDisposition = null;
            pendingDownloadMime = null;
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (authenticated && appInterfaceVisible && !isChangingConfigurations()) {
            backgroundAt = System.currentTimeMillis();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (authenticated && appInterfaceVisible && backgroundAt > 0
                && System.currentTimeMillis() - backgroundAt >= AUTO_LOCK_AFTER_MS) {
            showSecurityGate(true);
        }
        backgroundAt = 0L;
    }

    @Override
    public void onBackPressed() {
        if (appInterfaceVisible && webView != null && webView.canGoBack()) {
            webView.goBack();
        } else if (appInterfaceVisible) {
            new AlertDialog.Builder(this)
                    .setTitle("Sair do aplicativo?")
                    .setMessage("Deseja fechar o Painel R7 Ativador?")
                    .setNegativeButton("Cancelar", null)
                    .setNeutralButton("Bloquear", (dialog, which) -> showSecurityGate(true))
                    .setPositiveButton("Sair", (dialog, which) -> finish())
                    .show();
        } else {
            finish();
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && appInterfaceVisible && webView != null && webView.canGoBack()) {
            webView.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onDestroy() {
        cancelBiometricPrompt();
        destroyWebView();
        super.onDestroy();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
