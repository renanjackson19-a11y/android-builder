package com.spotnet.music;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.bumptech.glide.Glide;
import org.json.JSONObject;

public class SplashActivity extends AppCompatActivity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private long duration = 1500;
    private boolean finished = false;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        ImageView media=findViewById(R.id.splashMedia);
        LinearLayout brand=findViewById(R.id.splashBrand);
        TextView title=findViewById(R.id.splashTitle); ImageView logo=findViewById(R.id.splashLogo);
        // Mostra imediatamente a mídia salva da última abertura, sem tela vazia.
        android.content.SharedPreferences cache=getSharedPreferences("ui_cache",MODE_PRIVATE);
        String cachedUrl=cache.getString("splash_media_url",""); String cachedLogo=cache.getString("app_logo_url","");
        boolean cachedBrand=cache.getBoolean("splash_show_branding",true);
        String cachedName=cache.getString("site_name","Spotnet Music");
        long cachedDuration=cache.getLong("splash_duration_ms",1500);
        duration=Math.max(700,Math.min(5000,cachedDuration));
        title.setText(cachedName.toUpperCase());
        brand.setVisibility(cachedBrand?View.VISIBLE:View.GONE);
        if(!cachedLogo.isEmpty()) Glide.with(this).load(cachedLogo).fitCenter().into(logo);
        if(!cachedUrl.isEmpty()) Glide.with(this).load(cachedUrl).centerCrop().into(media);
        else media.setImageResource(R.drawable.splash_gradient);
        scheduleOpen();

        // Atualiza a configuração em paralelo para a próxima abertura.
        new Thread(() -> {
            try {
                JSONObject response=new JSONObject(Net.getFast(BuildConfig.PANEL_URL+"/api/config.php"));
                JSONObject cfg=response.optJSONObject("settings");
                if(cfg!=null){
                    String rawUrl=cfg.optString("splash_media_url","");
                    if(!rawUrl.isEmpty()&&!rawUrl.startsWith("http")){if(!rawUrl.startsWith("/"))rawUrl="/"+rawUrl;rawUrl=BuildConfig.PANEL_URL+rawUrl;}
                    final String url=rawUrl;
                    duration=Math.max(700,Math.min(5000,cfg.optLong("splash_duration_ms",1500)));
                    boolean showBrand=cfg.optBoolean("splash_show_branding",true);
                    String appName=cfg.optString("site_name","Spotnet Music"); String rawLogo=cfg.optString("logo",""); if(!rawLogo.isEmpty()&&!rawLogo.startsWith("http")){if(!rawLogo.startsWith("/"))rawLogo="/"+rawLogo;rawLogo=BuildConfig.PANEL_URL+rawLogo;} final String logoUrl=rawLogo;
                    cache.edit().putString("splash_media_url",url).putString("app_logo_url",logoUrl).putBoolean("splash_show_branding",showBrand).putString("site_name",appName).putLong("splash_duration_ms",duration).apply();
                    runOnUiThread(() -> {
                        title.setText(appName.toUpperCase());
                        brand.setVisibility(showBrand?View.VISIBLE:View.GONE);
                        if(!logoUrl.isEmpty()) Glide.with(this).load(logoUrl).fitCenter().into(logo);
                        if(!url.isEmpty()) Glide.with(this).load(url).centerCrop().into(media);
                    });
                    return;
                }
            }catch(Exception ignored){}
        }).start();
        handler.postDelayed(this::openApp,5200);
    }

    private void scheduleOpen(){handler.postDelayed(this::openApp,duration);}
    private void openApp(){
        if(finished)return; finished=true;
        String user=getSharedPreferences("auth",MODE_PRIVATE).getString("user","");
        startActivity(new Intent(this,user.isEmpty()?LoginActivity.class:MainActivity.class));
        overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);
        finish();
    }
    @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);super.onDestroy();}
}
