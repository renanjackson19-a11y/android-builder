# GREEN PLAY V5 — BASE NOVA

Projeto Android criado do zero. Nenhuma Activity, Adapter, cache, player ou classe do V4 foi reutilizada.

## Alpha 02
- Contrato real do painel conectado (host + token do aplicativo configurados apenas como dados de compatibilidade).
- Login do painel corrigido: quando o painel não devolve `xtream_host`, o V5 usa a raiz oficial do painel como servidor Xtream, como exige o contrato atual.
- Sessão V5 continua independente.
- Primeiro módulo funcional criado: TV.
- TV carrega `get_live_categories` e `get_live_streams` diretamente pelo Xtream.
- Filtro por categoria.
- Pesquisa por nome do canal.
- Logos dos canais.
- Preview Media3 à direita.
- EPG curto (Agora / A seguir).
- OK/click abre player em tela cheia.
- Navegação focável para TV Box/controle remoto.

## Ainda não implementado nesta alpha
- Favoritos e recentes persistentes.
- Futebol.
- Filmes.
- Séries/temporadas/episódios.
- Kids.
- Anime.
- HOT + PIN.
- Conta e personalização completa do painel.

A regra permanece: cada módulo novo é isolado. Não remendar o V4.

## Alpha 03 TV
- TV refeita sem reaproveitar a Activity/Adapter do V4.
- Liberado HTTP cleartext para servidores Xtream legados.
- Preview tenta TS e faz fallback automático para HLS/m3u8 em erro.
- Player de tela cheia também tenta URL alternativa.
- EPG agora escolhe o programa vigente por timestamp, exibe horário e progresso.
- Favoritos e recentes locais adicionados.
- Layout de TV compactado para exibir mais canais e aproximado da referência visual.


## Alpha 04 - player TV
- transporte HTTP próprio do V5 com redirects HTTP/HTTPS habilitados;
- User-Agent compatível com fontes IPTV que rejeitam o cliente HTTP padrão;
- headers neutros para stream (`Accept: */*`, `Accept-Encoding: identity`);
- MIME explícito para MPEG-TS e HLS;
- fallback TS -> HLS preservado;
- preview passa a exibir código/causa resumida quando ambos os formatos falham;
- PlayerActivity não destrói mais o player apenas por ir para background; libera somente no destroy.


## Alpha 05 - TV/player diagnostic
- applicationId V5 próprio: `com.greenplay.v5` (não conflita com V4 `shop.dubaiplay.tv`).
- preview inicia automaticamente ao carregar/focar canal.
- preview e tela cheia usam `TextureView` para evitar tela preta causada por SurfaceView/hardware overlay em alguns aparelhos/TV Boxes.
- antes de tocar, o V5 testa o stream e segue redirects, detectando HTTP, Content-Type e TS/HLS.
- status do preview exibe algo como `HTTP 200 • TS • video/mp2t`; em falha exibe o código real.
- nenhuma classe do V4 foi importada/copied para a base V5.

## Alpha 06 — TV fechada para validação
- Player/preview preservado da Alpha 05 (não mexer no núcleo que passou a reproduzir).
- Lista de canais compactada para exibir mais itens simultaneamente em 16:9.
- Cabeçalho, busca, filtros e categorias compactados sem mudar o fluxo funcional.
- Categorias horizontais acompanham o foco para evitar item selecionado escondido nas laterais.
- Ao abrir tela cheia e voltar, o app retorna para o mesmo canal e reposiciona o foco nele.
- Favoritos e recentes continuam isolados em armazenamento local.
- applicationId continua `com.greenplay.v5`, permitindo instalar ao lado do V4.

## Alpha 07
- Mantido o player da Alpha 05/06 que já reproduz TV.
- Preview voltou a ficar limitado à área superior direita; o EPG agora fica em painel opaco separado, sem o vídeo "crescer" por trás ao trocar de canal.
- `resize_mode=fit` para evitar zoom/corte do vídeo no preview.
- `applicationId` continua `com.greenplay.v5`.
- Adicionada assinatura fixa do projeto em `app/signing/greenplay-v5.jks` para permitir atualização por cima nas próximas versões.
- `versionCode` aumentado para 5007.

IMPORTANTE: se uma Alpha anterior foi instalada com outra assinatura, será necessário desinstalar ESSA Alpha uma última vez antes da Alpha 07. Da Alpha 07 em diante, mantendo este mesmo arquivo de assinatura e aumentando o versionCode, as novas APKs instalam como atualização por cima.


## Alpha 08 — correção de seleção de canal
- D-pad/cursor apenas move o foco na lista; não troca o preview e não abre tela cheia.
- Primeiro OK em um canal diferente: seleciona o canal e inicia o preview na direita.
- Segundo OK no mesmo canal já selecionado: abre o player em tela cheia.
- Ao voltar da tela cheia, o foco retorna ao canal selecionado.
- versionCode 5008, mantendo o mesmo applicationId e a mesma assinatura da Alpha 07 para instalar por cima.
