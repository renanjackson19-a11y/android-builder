package com.spotnet.music;
import android.content.*;import android.os.*;import android.provider.Settings;import android.view.View;import android.widget.*;import androidx.appcompat.app.AppCompatActivity;import com.bumptech.glide.Glide;import org.json.JSONObject;import java.net.URLEncoder;
public class LoginActivity extends AppCompatActivity{
 protected void onCreate(Bundle b){super.onCreate(b);if(getSharedPreferences("auth",MODE_PRIVATE).getBoolean("ok",false)){open();return;}setContentView(R.layout.activity_login);loadBrand();EditText u=findViewById(R.id.user),p=findViewById(R.id.pass);TextView s=findViewById(R.id.status);Button bt=findViewById(R.id.loginBtn); View overlay=findViewById(R.id.accessOverlay); TextView accessTitle=findViewById(R.id.accessTitle), accessMessage=findViewById(R.id.accessMessage);
  View.OnClickListener unavailable=v->Toast.makeText(this,"Opção ainda não configurada no painel.",Toast.LENGTH_SHORT).show();findViewById(R.id.googleLogin).setOnClickListener(unavailable);findViewById(R.id.appleLogin).setOnClickListener(unavailable);findViewById(R.id.createAccount).setOnClickListener(unavailable);findViewById(R.id.forgotPassword).setOnClickListener(v->Toast.makeText(this,"Entre em contato com o suporte para recuperar a senha.",Toast.LENGTH_SHORT).show());
  bt.setOnClickListener(v->{String username=u.getText().toString().trim();String password=p.getText().toString();if(username.isEmpty()||password.isEmpty()){s.setText("Informe usuário e senha.");return;}bt.setEnabled(false);s.setText("");overlay.setVisibility(View.VISIBLE);accessTitle.setText("Liberando seu acesso…");accessMessage.setText("Validando sua assinatura com segurança");new Thread(()->{try{String d=Settings.Secure.getString(getContentResolver(),Settings.Secure.ANDROID_ID);String body="user="+URLEncoder.encode(username,"UTF-8")+"&pass="+URLEncoder.encode(password,"UTF-8")+"&device="+URLEncoder.encode(d,"UTF-8");JSONObject j=new JSONObject(Net.post(BuildConfig.PANEL_URL+"/api/login.php",body));if(j.optBoolean("ok")){getSharedPreferences("auth",MODE_PRIVATE).edit().putBoolean("ok",true).putString("user",username).putString("device",d).putString("token",j.optString("token","")).apply();runOnUiThread(()->{accessTitle.setText("Acesso liberado!");accessMessage.setText("Tudo pronto. Bem-vindo à Spotnet Music.");new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(this::open,550);});}else runOnUiThread(()->{overlay.setVisibility(View.GONE);s.setText(j.optString("message","Acesso negado"));bt.setEnabled(true);});}catch(Exception e){runOnUiThread(()->{overlay.setVisibility(View.GONE);s.setText("Não foi possível conectar. Tente novamente.");bt.setEnabled(true);});}}).start();});}
 void loadBrand(){
  ImageView logo=findViewById(R.id.loginLogo); View fallback=findViewById(R.id.loginBrandFallback);
  android.content.SharedPreferences cache=getSharedPreferences("ui_cache",MODE_PRIVATE);
  String cached=cache.getString("app_logo_url","");
  if(!cached.isEmpty()){Glide.with(this).load(cached).fitCenter().into(logo);fallback.setVisibility(View.GONE);}
  new Thread(()->{try{
    JSONObject r=new JSONObject(Net.getFast(BuildConfig.PANEL_URL+"/api/branding.php?t="+System.currentTimeMillis()));
    JSONObject cfg=r.optJSONObject("branding"); if(cfg==null)return;
    String url=cfg.optString("logo_url",""); String version=cfg.optString("version","0");
    if(!url.isEmpty()) url=url+(url.contains("?")?"&":"?")+"v="+version;
    final String finalUrl=url;
    cache.edit().putString("app_logo_url",finalUrl).putString("branding_version",version).apply();
    runOnUiThread(()->{if(!finalUrl.isEmpty()){Glide.with(this).load(finalUrl).fitCenter().into(logo);fallback.setVisibility(View.GONE);}else{fallback.setVisibility(View.VISIBLE);}});
  }catch(Exception ignored){}}).start();
 }
 void open(){startActivity(new Intent(this,MainActivity.class));finish();}
}