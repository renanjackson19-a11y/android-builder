package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class CatalogActivity extends Activity {
    private final List<ApiClient.Item> items=new ArrayList<>();
    private GridView grid; private Adapter adapter; private LinearLayout categoryList; private TextView status,title;
    private EditText search; private String type,category="",smart="",query=""; private int page=1,pages=1,total=0;
    private boolean loading=false,phone; private final Handler handler=new Handler(); private Runnable searchTask;

    @Override public void onCreate(Bundle b){
        super.onCreate(b); Ui.immersive(this); phone=Ui.phone(this);
        type=clean(getIntent().getStringExtra("type"),"live");
        category=clean(getIntent().getStringExtra("category"),""); smart=clean(getIntent().getStringExtra("smart"),"");
        setContentView(build());
        renderCategories(new ArrayList<>()); // atalhos aparecem imediatamente
        loadCategories();
        load(1,true);
    }
    @Override protected void onResume(){super.onResume();Ui.immersive(this);}

    private View build(){
        LinearLayout root=Ui.column(this); root.setBackgroundColor(Ui.BG);

        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setPadding(Ui.dp(this,18),0,Ui.dp(this,18),0); top.setBackgroundColor(Ui.BG_2);
        TextView back=Ui.button(this,"‹ VOLTAR"); back.setOnClickListener(v->finish()); top.addView(back,new LinearLayout.LayoutParams(Ui.dp(this,110),Ui.dp(this,40)));
        title=Ui.text(this,clean(getIntent().getStringExtra("title"),titleFor(type)),phone?19:24,Ui.TEXT,true);
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,Ui.dp(this,44),1); tp.leftMargin=Ui.dp(this,14); top.addView(title,tp);
        search=new EditText(this); search.setSingleLine(true); search.setHint("Pesquisar no catálogo..."); search.setHintTextColor(Ui.MUTED); search.setTextColor(Ui.TEXT); search.setTextSize(phone?11:13);
        search.setBackground(Ui.stroke(Ui.PANEL_2,Ui.BORDER,12,this)); search.setPadding(Ui.dp(this,14),0,Ui.dp(this,14),0); top.addView(search,new LinearLayout.LayoutParams(Ui.dp(this,phone?220:310),Ui.dp(this,40)));
        TextView profile=Ui.ghostButton(this,"●"); profile.setOnClickListener(v->startActivity(new Intent(this,ProfileActivity.class)));
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(Ui.dp(this,42),Ui.dp(this,38)); pp.leftMargin=Ui.dp(this,7); top.addView(profile,pp);
        root.addView(top,new LinearLayout.LayoutParams(-1,Ui.dp(this,58)));

        LinearLayout main=new LinearLayout(this); main.setPadding(Ui.dp(this,14),Ui.dp(this,10),Ui.dp(this,14),Ui.dp(this,12));
        LinearLayout rail=Ui.column(this); rail.setPadding(Ui.dp(this,9),Ui.dp(this,9),Ui.dp(this,9),Ui.dp(this,9)); rail.setBackground(Ui.stroke(Ui.PANEL,Ui.BORDER,14,this));
        TextView catTitle=Ui.text(this,categoryHeading(),10,Ui.GREEN,true); rail.addView(catTitle,new LinearLayout.LayoutParams(-1,Ui.dp(this,30)));
        ScrollView cs=new ScrollView(this); cs.setVerticalScrollBarEnabled(false); categoryList=Ui.column(this); cs.addView(categoryList,new ScrollView.LayoutParams(-1,-2)); rail.addView(cs,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(Ui.dp(this,phone?195:230),-1); rp.rightMargin=Ui.dp(this,12); main.addView(rail,rp);

        LinearLayout right=Ui.column(this);
        status=Ui.text(this,"Carregando catálogo...",10,Ui.MUTED,false); right.addView(status,new LinearLayout.LayoutParams(-1,Ui.dp(this,31)));
        grid=new GridView(this); int sw=Ui.sw(this); int cols;
        if("live".equals(type)) cols=phone?5:(sw<1000?6:7); else cols=phone?4:(sw<1000?5:6);
        grid.setNumColumns(cols); grid.setHorizontalSpacing(Ui.dp(this,9)); grid.setVerticalSpacing(Ui.dp(this,9)); grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH); grid.setSelector(android.R.color.transparent); grid.setPadding(0,0,0,Ui.dp(this,8));
        adapter=new Adapter(); grid.setAdapter(adapter); right.addView(grid,new LinearLayout.LayoutParams(-1,0,1)); main.addView(right,new LinearLayout.LayoutParams(0,-1,1)); root.addView(main,new LinearLayout.LayoutParams(-1,0,1));

        grid.setOnScrollListener(new AbsListView.OnScrollListener(){public void onScrollStateChanged(AbsListView v,int s){} public void onScroll(AbsListView v,int first,int visible,int count){if(count>0&&!loading&&page<pages&&first+visible>=count-5)load(page+1,false);}});
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){query=s==null?"":s.toString().trim(); if(searchTask!=null)handler.removeCallbacks(searchTask); searchTask=()->load(1,true); handler.postDelayed(searchTask,450);} public void afterTextChanged(Editable e){}});
        back.requestFocus(); return root;
    }

    private void loadCategories(){
        ApiClient.categories(type,new ApiClient.Callback<List<String>>(){
            public void ok(List<String> cats){runOnUiThread(()->renderCategories(cats));}
            public void error(String m){ /* atalhos locais continuam disponíveis */ }
        });
    }

    private void renderCategories(List<String> cats){
        categoryList.removeAllViews(); addCategory("TODOS","","");
        if("live".equals(type)){
            addCategory("⚽ Futebol hoje","","football_today"); addCategory("Futebol","","football"); addCategory("Notícias","","news"); addCategory("Kids","","kids"); addCategory("Música","","music");
        }else if("movie".equals(type)){
            addCategory("Lançamentos","","launch"); addCategory("Kids","","kids"); addCategory("Anime","","anime");
        }else{
            addCategory("Lançamentos","","launch"); addCategory("Novelas","","novela"); addCategory("Kids","","kids"); addCategory("Anime","","anime");
        }
        int max=Math.min(cats==null?0:cats.size(),80); for(int i=0;i<max;i++){String c=clean(cats.get(i),""); if(c.isEmpty())continue; addCategory(c,c,"");}
    }

    private void addCategory(String label,String cat,String smartKey){
        boolean selected=cat.equals(category)&&smartKey.equals(smart); TextView b=selected?Ui.primaryButton(this,label):Ui.button(this,label); b.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL); b.setMaxLines(1);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,Ui.dp(this,39)); p.bottomMargin=Ui.dp(this,5); categoryList.addView(b,p);
        b.setOnClickListener(v->{if("football_today".equals(smartKey)){startActivity(new Intent(this,FootballActivity.class));return;} category=cat;smart=smartKey;renderCategoriesSnapshot();load(1,true);});
    }
    private void renderCategoriesSnapshot(){ loadCategories(); }

    private void load(int target,boolean reset){
        if(loading)return; loading=true; if(reset){status.setText("Carregando "+titleFor(type).toLowerCase()+"..."); if(target==1){items.clear();adapter.notifyDataSetChanged();}}
        int limit="series".equals(type)?30:(phone?36:48);
        ApiClient.catalog(type,target,limit,query,category,smart,new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){runOnUiThread(()->{loading=false;page=p.page;pages=p.pages;total=p.total;if(reset)items.clear();items.addAll(p.items);adapter.notifyDataSetChanged();String prefix=!category.isEmpty()?category+" • ":(!smart.isEmpty()?smartLabel(smart)+" • ":"");status.setText(prefix+total+("series".equals(type)?" séries":" itens")+(pages>1?" • página "+page+"/"+pages:""));if(reset&&!items.isEmpty())grid.requestFocus();if(items.isEmpty()&&reset)status.setText(prefix+"Nenhum conteúdo encontrado");});}
            public void error(String m){runOnUiThread(()->{loading=false;status.setText("Falha ao carregar • "+m+" • toque em TODOS para tentar novamente");});}
        });
    }

    private class Adapter extends BaseAdapter{
        public int getCount(){return items.size();} public Object getItem(int p){return items.get(p);} public long getItemId(int p){return items.get(p).id;}
        public View getView(int p,View convert,android.view.ViewGroup parent){
            LinearLayout card;ImageView image;TextView name,meta;boolean live="live".equals(type);int imageH=live?(phone?74:94):(phone?118:152);
            if(convert==null){card=Ui.column(CatalogActivity.this);card.setPadding(Ui.dp(CatalogActivity.this,5),Ui.dp(CatalogActivity.this,5),Ui.dp(CatalogActivity.this,5),Ui.dp(CatalogActivity.this,5));card.setFocusable(true);card.setClickable(true);Ui.focus(card,CatalogActivity.this);
                image=new ImageView(CatalogActivity.this);image.setId(601);image.setScaleType(live?ImageView.ScaleType.CENTER_INSIDE:ImageView.ScaleType.CENTER_CROP);image.setBackgroundColor(Ui.PANEL_2);card.addView(image,new LinearLayout.LayoutParams(-1,Ui.dp(CatalogActivity.this,imageH)));
                name=Ui.text(CatalogActivity.this,"",phone?10:11,Ui.TEXT,true);name.setId(602);name.setMaxLines(2);card.addView(name,new LinearLayout.LayoutParams(-1,Ui.dp(CatalogActivity.this,34)));
                meta=Ui.text(CatalogActivity.this,"",8,Ui.MUTED,false);meta.setId(603);meta.setMaxLines(1);card.addView(meta,new LinearLayout.LayoutParams(-1,Ui.dp(CatalogActivity.this,18)));convert=card;
            }
            card=(LinearLayout)convert;image=convert.findViewById(601);name=convert.findViewById(602);meta=convert.findViewById(603);android.view.ViewGroup.LayoutParams ip=image.getLayoutParams();ip.height=Ui.dp(CatalogActivity.this,imageH);image.setLayoutParams(ip);image.setScaleType(live?ImageView.ScaleType.CENTER_INSIDE:ImageView.ScaleType.CENTER_CROP);
            ApiClient.Item i=items.get(p);name.setText(clean(i.name,"Sem nome"));String m=clean(i.group,live?"Ao vivo":"Dubai Play");if("series".equals(type)&&i.episodeCount>0)m=(i.seasonCount>0?i.seasonCount+" temp. • ":"")+i.episodeCount+" eps.";else if(i.year>0)m+=" • "+i.year;meta.setText(m);ImageLoader.into(CatalogActivity.this,image,i.logo);card.setOnClickListener(v->open(i));return convert;
        }
    }

    private void open(ApiClient.Item i){if("series".equals(type)){Intent in=new Intent(this,SeriesActivity.class);in.putExtra("title",clean(i.seriesTitle,i.name));in.putExtra("logo",i.logo);in.putExtra("backdrop",i.backdrop);startActivity(in);}else if("movie".equals(type)){Intent in=new Intent(this,DetailActivity.class);MainActivity.putItem(in,i);startActivity(in);}else{Intent in=new Intent(this,PlayerActivity.class);MainActivity.putItem(in,i);startActivity(in);LocalStore.addHistory(this,i);}}
    private String smartLabel(String s){if("launch".equals(s))return"Lançamentos";if("football".equals(s))return"Futebol";if("news".equals(s))return"Notícias";if("kids".equals(s))return"Kids";if("music".equals(s))return"Música";if("anime".equals(s))return"Anime";if("novela".equals(s))return"Novelas";return s;}
    private String categoryHeading(){return"live".equals(type)?"CATEGORIAS DE TV":"movie".equals(type)?"CATEGORIAS DE FILMES":"CATEGORIAS DE SÉRIES";}
    private String titleFor(String t){return"live".equals(t)?"TV ao Vivo":"movie".equals(t)?"Filmes":"Séries";}
    private String clean(String v,String f){if(v==null)return f;String s=v.trim();return s.isEmpty()||"null".equalsIgnoreCase(s)?f:s;}
}
