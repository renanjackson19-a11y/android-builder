package com.greenplay.v5.ui.movies;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.greenplay.v5.R;
import com.greenplay.v5.data.model.movie.Movie;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.Holder> {
    public interface Listener {
        void onOpen(Movie movie);
        void onFavorite(Movie movie);
        boolean isFavorite(Movie movie);
    }

    private final Listener listener;
    private final List<Movie> source = new ArrayList<>();
    private final List<Movie> rows = new ArrayList<>();
    private String query = "";
    private boolean favoritesOnly = false;

    public MovieAdapter(Listener listener) {
        this.listener = listener;
        setHasStableIds(true);
    }

    public void submit(List<Movie> items) {
        source.clear();
        if (items != null) source.addAll(items);
        apply();
    }

    public void search(String value) {
        query = value == null ? "" : value.trim();
        apply();
    }

    public void favoritesOnly(boolean enabled) {
        favoritesOnly = enabled;
        apply();
    }

    public void refreshFavorite(long id) {
        if (favoritesOnly) { apply(); return; }
        for (int i = 0; i < rows.size(); i++) if (rows.get(i).id == id) { notifyItemChanged(i); return; }
    }

    private void apply() {
        rows.clear();
        String q = query.toLowerCase(Locale.ROOT);
        for (Movie m : source) {
            if (favoritesOnly && !listener.isFavorite(m)) continue;
            if (!q.isEmpty() && (m.name == null || !m.name.toLowerCase(Locale.ROOT).contains(q))) continue;
            rows.add(m);
        }
        notifyDataSetChanged();
    }

    @Override public long getItemId(int position) { return rows.get(position).id; }

    @NonNull @Override public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new Holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_movie, parent, false));
    }

    @Override public void onBindViewHolder(@NonNull Holder h, int position) {
        Movie m = rows.get(position);
        h.title.setText(m.name);
        String meta = meta(m);
        h.meta.setText(meta);
        h.meta.setVisibility(meta.isEmpty() ? View.GONE : View.VISIBLE);
        h.favorite.setText(listener.isFavorite(m) ? "★" : "☆");
        h.poster.setImageDrawable(null);
        h.poster.setBackgroundResource(R.drawable.bg_movie_poster_placeholder);
        if (m.poster != null && !m.poster.trim().isEmpty()) {
            Picasso.get().load(m.poster).fit().centerCrop().noFade().into(h.poster);
        }
        h.itemView.setOnClickListener(v -> listener.onOpen(m));
        h.favorite.setOnClickListener(v -> {
            listener.onFavorite(m);
            h.favorite.setText(listener.isFavorite(m) ? "★" : "☆");
        });
    }

    private static String meta(Movie m) {
        String y = m.year == null ? "" : m.year.trim();
        String r = m.rating == null ? "" : m.rating.trim();
        if (!r.isEmpty() && !"0".equals(r) && !"0.0".equals(r)) return y.isEmpty() ? "★ " + r : y + "  •  ★ " + r;
        return y;
    }

    @Override public int getItemCount() { return rows.size(); }

    static final class Holder extends RecyclerView.ViewHolder {
        final ImageView poster;
        final TextView title, meta, favorite;
        Holder(View itemView) {
            super(itemView);
            poster = itemView.findViewById(R.id.moviePoster);
            title = itemView.findViewById(R.id.movieTitle);
            meta = itemView.findViewById(R.id.movieMeta);
            favorite = itemView.findViewById(R.id.movieFavorite);
        }
    }
}
