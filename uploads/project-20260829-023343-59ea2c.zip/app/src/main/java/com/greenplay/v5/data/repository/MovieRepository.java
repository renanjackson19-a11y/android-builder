package com.greenplay.v5.data.repository;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.greenplay.v5.core.network.HostNormalizer;
import com.greenplay.v5.core.network.NetworkProvider;
import com.greenplay.v5.core.network.XtreamApi;
import com.greenplay.v5.data.model.movie.Movie;
import com.greenplay.v5.data.model.movie.MovieCategory;
import com.greenplay.v5.data.model.movie.MovieDetails;
import java.util.ArrayList;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Movies use only the public Xtream contract exposed by the current panel.
 * Bouquet/category permissions therefore remain enforced by the panel itself.
 * Adult VOD is intentionally excluded here because it belongs to the HOT module.
 */
public final class MovieRepository {
    public interface CategoriesResult { void success(List<MovieCategory> rows); void error(String message); }
    public interface MoviesResult { void success(List<Movie> rows); void error(String message); }
    public interface DetailResult { void success(MovieDetails detail); void error(String message); }

    private final XtreamApi api;
    private final String host;
    private final String user;
    private final String pass;

    public MovieRepository(String host, String user, String pass) {
        this.host = HostNormalizer.normalize(host);
        this.api = NetworkProvider.xtream(host);
        this.user = user;
        this.pass = pass;
    }

    public void categories(CategoriesResult result) {
        api.list(user, pass, "get_vod_categories").enqueue(new Callback<JsonArray>() {
            @Override public void onResponse(Call<JsonArray> call, Response<JsonArray> response) {
                if (!response.isSuccessful() || response.body() == null) {
                    result.error("Categorias de filmes indisponíveis");
                    return;
                }
                List<MovieCategory> out = new ArrayList<>();
                out.add(new MovieCategory("", "TODOS"));
                for (JsonElement e : response.body()) {
                    if (!e.isJsonObject()) continue;
                    JsonObject o = e.getAsJsonObject();
                    String id = str(o, "category_id");
                    String name = str(o, "category_name");
                    if (!id.isEmpty() && !name.isEmpty()) out.add(new MovieCategory(id, name));
                }
                result.success(out);
            }
            @Override public void onFailure(Call<JsonArray> call, Throwable t) {
                result.error("Falha ao carregar categorias de filmes");
            }
        });
    }

    public void movies(String categoryId, MoviesResult result) {
        Call<JsonArray> call = categoryId == null || categoryId.trim().isEmpty()
                ? api.list(user, pass, "get_vod_streams")
                : api.listByCategory(user, pass, "get_vod_streams", categoryId.trim());
        call.enqueue(new Callback<JsonArray>() {
            @Override public void onResponse(Call<JsonArray> c, Response<JsonArray> response) {
                if (!response.isSuccessful() || response.body() == null) {
                    result.error("Filmes indisponíveis");
                    return;
                }
                List<Movie> out = new ArrayList<>();
                for (JsonElement e : response.body()) {
                    if (!e.isJsonObject()) continue;
                    JsonObject o = e.getAsJsonObject();
                    if (boolVal(o, "is_adult")) continue; // HOT remains isolated from Filmes.
                    long id = longVal(o, "stream_id");
                    if (id <= 0) continue;
                    Movie m = new Movie();
                    m.id = id;
                    m.name = first(str(o, "name"), str(o, "title"), "Filme");
                    m.poster = normalizeImage(str(o, "stream_icon"));
                    m.categoryId = str(o, "category_id");
                    m.extension = first(str(o, "container_extension"), "mp4");
                    m.year = str(o, "year");
                    m.rating = str(o, "rating");
                    m.directSource = normalizeDirect(str(o, "direct_source"));
                    out.add(m);
                }
                result.success(out);
            }
            @Override public void onFailure(Call<JsonArray> c, Throwable t) {
                result.error("Falha ao carregar filmes");
            }
        });
    }

    public void detail(long movieId, DetailResult result) {
        api.vodInfo(user, pass, "get_vod_info", movieId).enqueue(new Callback<JsonObject>() {
            @Override public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (!response.isSuccessful() || response.body() == null) {
                    result.error("Detalhes do filme indisponíveis");
                    return;
                }
                try {
                    JsonObject root = response.body();
                    JsonObject info = object(root, "info");
                    JsonObject data = object(root, "movie_data");
                    MovieDetails d = new MovieDetails();
                    d.id = movieId;
                    d.name = first(str(info, "name"), str(data, "name"), str(data, "title"), "Filme");
                    d.poster = normalizeImage(first(str(info, "cover_big"), str(info, "movie_image"), str(data, "stream_icon"), str(data, "movie_image")));
                    d.backdrop = normalizeImage(firstBackdrop(info.get("backdrop_path")));
                    d.plot = first(str(info, "plot"), str(info, "description"));
                    d.year = first(str(data, "year"), yearFromDate(first(str(info, "release_date"), str(info, "releasedate"))));
                    d.genre = str(info, "genre");
                    d.duration = first(str(info, "duration"), runtimeText(str(info, "runtime")));
                    d.director = str(info, "director");
                    d.cast = first(str(info, "cast"), str(info, "actors"));
                    d.country = str(info, "country");
                    d.releaseDate = first(str(info, "release_date"), str(info, "releasedate"));
                    d.rating = str(info, "rating");
                    d.extension = first(str(data, "container_extension"), "mp4");
                    d.directSource = normalizeDirect(str(data, "direct_source"));
                    result.success(d);
                } catch (Exception e) {
                    result.error("Não foi possível ler os detalhes do filme");
                }
            }
            @Override public void onFailure(Call<JsonObject> call, Throwable t) {
                result.error("Falha ao carregar detalhes do filme");
            }
        });
    }

    private String normalizeImage(String raw) {
        if (raw == null) return "";
        String u = raw.trim().replace("\\/", "/").replace(" ", "%20");
        if (u.isEmpty()) return "";
        if (u.startsWith("//")) return (host.startsWith("https://") ? "https:" : "http:") + u;
        if (u.startsWith("http://") || u.startsWith("https://")) return u;
        if (u.startsWith("/")) return host + u;
        return host + "/" + u;
    }

    private String normalizeDirect(String raw) {
        if (raw == null) return "";
        String u = raw.trim().replace("\\/", "/").replace(" ", "%20");
        if (u.isEmpty()) return "";
        if (u.startsWith("//")) return (host.startsWith("https://") ? "https:" : "http:") + u;
        if (u.startsWith("http://") || u.startsWith("https://")) return u;
        if (u.startsWith("/")) return host + u;
        return host + "/" + u;
    }

    private static JsonObject object(JsonObject root, String key) {
        try {
            JsonElement e = root.get(key);
            return e != null && e.isJsonObject() ? e.getAsJsonObject() : new JsonObject();
        } catch (Exception e) { return new JsonObject(); }
    }

    private static String firstBackdrop(JsonElement e) {
        try {
            if (e == null || e.isJsonNull()) return "";
            if (e.isJsonArray()) {
                JsonArray a = e.getAsJsonArray();
                return a.size() > 0 && !a.get(0).isJsonNull() ? a.get(0).getAsString() : "";
            }
            return e.getAsString();
        } catch (Exception ex) { return ""; }
    }

    private static String runtimeText(String raw) {
        try {
            long sec = Long.parseLong(raw == null ? "" : raw.trim());
            if (sec <= 0) return "";
            long h = sec / 3600;
            long m = (sec % 3600) / 60;
            return h > 0 ? h + "h " + m + "min" : m + "min";
        } catch (Exception e) { return ""; }
    }

    private static String yearFromDate(String raw) {
        if (raw == null) return "";
        String s = raw.trim();
        return s.length() >= 4 ? s.substring(0, 4) : "";
    }

    private static String first(String... values) {
        if (values == null) return "";
        for (String v : values) if (v != null && !v.trim().isEmpty()) return v.trim();
        return "";
    }

    private static String str(JsonObject o, String k) {
        try {
            JsonElement e = o.get(k);
            return e == null || e.isJsonNull() ? "" : e.getAsString();
        } catch (Exception e) { return ""; }
    }

    private static long longVal(JsonObject o, String k) {
        try { return o.get(k).getAsLong(); } catch (Exception e) { return 0L; }
    }

    private static boolean boolVal(JsonObject o, String k) {
        try {
            JsonElement e = o.get(k);
            if (e == null || e.isJsonNull()) return false;
            if (e.getAsJsonPrimitive().isBoolean()) return e.getAsBoolean();
            String s = e.getAsString().trim();
            return "1".equals(s) || "true".equalsIgnoreCase(s) || "yes".equalsIgnoreCase(s);
        } catch (Exception e) { return false; }
    }
}
