package com.ativacao.app;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.common.PlaybackException;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.PlayerView;
import androidx.media3.ui.AspectRatioFrameLayout;

import java.util.ArrayList;
import java.util.List;

/** TV: lista/categorias à esquerda + preview à direita. Primeiro OK seleciona; segundo OK abre tela cheia. */
public class LiveTvActivity extends android.app.Activity {
    private final List<ApiClient.Item> allChannels = new ArrayList<>();
    private LinearLayout rows;
    private PlayerView preview;
    private FrameLayout playerCard;
    private FrameLayout shell, fullscreenLayer;
    private LinearLayout content, rightColumn;
    private LinearLayout.LayoutParams playerNormalLp;
    private boolean fullscreen = false;
    private ExoPlayer player;
    private TextView title, epgNow, epgNext, hint;
    private ProgressBar loading;
    private ApiClient.Item current;
    private View currentRow;
    private long armedChannelId = -1L;
    private int channelLoadToken = 0;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        immersive();
        setContentView(build());
        loadChannels();
    }

    private View build() {
        shell=new FrameLayout(this);

        LinearLayout root=Ui.column(this);
        root.setBackground(Ui.diagonalGradient(0xFF07160B,0xFF010402,0,this));
        shell.addView(root,new FrameLayout.LayoutParams(-1,-1));

        fullscreenLayer=new FrameLayout(this);
        fullscreenLayer.setBackgroundColor(Color.BLACK);
        fullscreenLayer.setVisibility(View.GONE);
        shell.addView(fullscreenLayer,new FrameLayout.LayoutParams(-1,-1));

        root.addView(YellowNav.bar(this,"TV"),new LinearLayout.LayoutParams(-1,Ui.dp(this,64)));

        LinearLayout main=new LinearLayout(this);
        main.setOrientation(LinearLayout.HORIZONTAL);
        main.setPadding(Ui.dp(this,phonePad()),Ui.dp(this,10),Ui.dp(this,phonePad()),Ui.dp(this,16));

        // Left column follows the reference: title + search + clean channel rows.
        LinearLayout left=Ui.column(this);
        left.setPadding(Ui.dp(this,4),0,Ui.dp(this,12),0);

        TextView section=Ui.text(this,"TV AO VIVO",28,Ui.GREEN,true);
        left.addView(section,new LinearLayout.LayoutParams(-1,Ui.dp(this,46)));

        android.widget.EditText search=new android.widget.EditText(this);
        search.setSingleLine(true);
        search.setHint("Pesquisar canal...");
        search.setHintTextColor(0xFF8E9890);
        search.setTextColor(Color.WHITE);
        search.setTextSize(11);
        search.setPadding(Ui.dp(this,14),0,Ui.dp(this,14),0);
        search.setBackground(Ui.stroke(0x85090F0A,0xFF26372A,12,this));
        left.addView(search,new LinearLayout.LayoutParams(-1,Ui.dp(this,44)));

        TextView all=Ui.text(this,"TODOS",12,Color.BLACK,true);
        all.setGravity(Gravity.CENTER);
        all.setBackground(Ui.gradient(Ui.GREEN,Ui.GREEN_2,24,this));
        LinearLayout.LayoutParams alp=new LinearLayout.LayoutParams(-1,Ui.dp(this,38));
        alp.topMargin=Ui.dp(this,10);alp.bottomMargin=Ui.dp(this,8);
        left.addView(all,alp);

        ScrollView sc=new ScrollView(this);
        sc.setVerticalScrollBarEnabled(false);
        sc.setFillViewport(true);
        rows=Ui.column(this);
        sc.addView(rows,new ScrollView.LayoutParams(-1,-2));
        left.addView(sc,new LinearLayout.LayoutParams(-1,0,1));

        search.addTextChangedListener(new android.text.TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b,int c){renderRowsFiltered(s==null?"":s.toString());}
            public void afterTextChanged(android.text.Editable e){}
        });

        LinearLayout.LayoutParams llp=new LinearLayout.LayoutParams(Ui.dp(this,phoneLeftWidth()),-1);
        llp.rightMargin=Ui.dp(this,18);
        main.addView(left,llp);

        // Right: one continuous large preview, information embedded inside it.
        rightColumn=Ui.column(this);

        playerCard=new FrameLayout(this);
        playerCard.setFocusable(true);
        playerCard.setClickable(true);
        playerCard.setBackgroundColor(Color.BLACK);

        preview=new PlayerView(this);
        preview.setUseController(false);
        preview.setKeepScreenOn(true);
        preview.setFocusable(false);
        preview.setBackgroundColor(Color.BLACK);
        preview.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        playerCard.addView(preview,new FrameLayout.LayoutParams(-1,-1));

        loading=new ProgressBar(this);
        playerCard.addView(loading,new FrameLayout.LayoutParams(Ui.dp(this,42),Ui.dp(this,42),Gravity.CENTER));

        LinearLayout overlay=Ui.column(this);
        overlay.setPadding(Ui.dp(this,18),Ui.dp(this,8),Ui.dp(this,18),Ui.dp(this,8));
        overlay.setBackground(Ui.verticalGradient(0x11000000,0xEA000000,0,this));

        title=Ui.text(this,"Canal",18,Color.WHITE,true);
        overlay.addView(title,new LinearLayout.LayoutParams(-1,Ui.dp(this,34)));
        epgNow=Ui.text(this,"AGORA  —",10,Ui.GREEN,true);
        overlay.addView(epgNow,new LinearLayout.LayoutParams(-1,Ui.dp(this,24)));
        epgNext=Ui.text(this,"A SEGUIR  —",9,0xFFD0D6D2,false);
        overlay.addView(epgNext,new LinearLayout.LayoutParams(-1,Ui.dp(this,24)));
        hint=Ui.text(this,"OK seleciona • OK novamente abre tela cheia",8,0xFFA5ADA7,false);
        hint.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        overlay.addView(hint,new LinearLayout.LayoutParams(-1,Ui.dp(this,22)));

        FrameLayout.LayoutParams olp=new FrameLayout.LayoutParams(-1,Ui.dp(this,110),Gravity.BOTTOM);
        playerCard.addView(overlay,olp);

        playerCard.setOnClickListener(v->openFullscreen());
        playerNormalLp=new LinearLayout.LayoutParams(-1,-1);
        rightColumn.addView(playerCard,playerNormalLp);
        main.addView(rightColumn,new LinearLayout.LayoutParams(0,-1,1));

        root.addView(main,new LinearLayout.LayoutParams(-1,0,1));
        return shell;
    }

    private int phonePad(){return Ui.phone(this)?12:24;}
    private int phoneLeftWidth(){return Ui.phone(this)?315:380;}

    private void addNav(LinearLayout row,String label,boolean selected,Runnable action){
        TextView v=Ui.nav(this,label,selected); if(action!=null)v.setOnClickListener(x->action.run());
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1); row.addView(v,p);
    }

    private void loadChannels(){
        int token=++channelLoadToken;
        loadChannelPage(1, new ArrayList<>(), token);
    }

    private void loadChannelPage(int page, List<ApiClient.Item> acc, int token){
        if(token!=channelLoadToken || isFinishing() || isDestroyed()) return;
        ApiClient.catalog("live",page,72,"","","",new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){
                if(token!=channelLoadToken) return;
                int before=acc.size();
                if(p!=null && p.items!=null){
                    java.util.HashSet<Long> ids=new java.util.HashSet<>();
                    for(ApiClient.Item old:acc) ids.add(old.id);
                    for(ApiClient.Item item:p.items) if(item!=null && !ids.contains(item.id)){acc.add(item);ids.add(item.id);}
                }
                int pages=p==null?1:Math.max(1,p.pages);
                boolean apiHasNext=page<pages;
                boolean fullPage=p!=null && p.items!=null && p.items.size()>=72 && acc.size()>before;
                // Alguns backends antigos não informam "pages" corretamente. Continua enquanto vier página cheia.
                if(page<30 && (apiHasNext || fullPage)){ loadChannelPage(page+1,acc,token); return; }
                runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())renderAll(acc);});
            }
            public void error(String m){
                if(!acc.isEmpty()){runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())renderAll(acc);});return;}
                runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())Toast.makeText(LiveTvActivity.this,"Não foi possível carregar os canais",Toast.LENGTH_LONG).show();});
            }
        });
    }

    private void renderAll(List<ApiClient.Item> list){
        allChannels.clear(); if(list!=null)allChannels.addAll(list);
        renderRows();
    }


    private void renderRows(){ renderRowsFiltered(""); }

    private void renderRowsFiltered(String query){
        if(rows==null)return;
        rows.removeAllViews();
        String q=query==null?"":query.trim().toLowerCase(java.util.Locale.ROOT);

        List<ApiClient.Item> visible=new ArrayList<>();
        for(ApiClient.Item i:allChannels){
            if(i==null)continue;
            String nm=clean(i.name,"Canal").toLowerCase(java.util.Locale.ROOT);
            if(q.isEmpty()||nm.contains(q))visible.add(i);
        }

        if(visible.isEmpty()){
            TextView empty=Ui.text(this,"Nenhum canal encontrado",10,Ui.MUTED,false);
            empty.setGravity(Gravity.CENTER);
            rows.addView(empty,new LinearLayout.LayoutParams(-1,Ui.dp(this,90)));
            return;
        }

        ApiClient.Item last=LocalStore.lastLive(this);
        ApiClient.Item initial=null;
        if(current!=null)for(ApiClient.Item x:visible)if(x.id==current.id){initial=x;break;}
        if(initial==null&&last!=null)for(ApiClient.Item x:visible)if(x.id==last.id){initial=x;break;}
        if(initial==null)initial=visible.get(0);

        View focus=null;
        int n=1;
        for(ApiClient.Item i:visible){
            LinearLayout r=new LinearLayout(this);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(Ui.dp(this,4),Ui.dp(this,3),Ui.dp(this,8),Ui.dp(this,3));
            r.setFocusable(true);r.setClickable(true);

            TextView num=Ui.text(this,String.valueOf(n++),11,Ui.GREEN,true);
            num.setGravity(Gravity.CENTER);
            r.addView(num,new LinearLayout.LayoutParams(Ui.dp(this,28),-1));

            ImageView logo=new ImageView(this);
            logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            logo.setBackground(Ui.round(0x20FFFFFF,7,this));
            ImageLoader.into(this,logo,i.logo);
            LinearLayout.LayoutParams lip=new LinearLayout.LayoutParams(Ui.dp(this,48),Ui.dp(this,48));
            lip.rightMargin=Ui.dp(this,10);
            r.addView(logo,lip);

            LinearLayout names=Ui.column(this);
            TextView nm=Ui.text(this,clean(i.name,"Canal"),12,Color.WHITE,true);
            nm.setMaxLines(1);
            names.addView(nm,new LinearLayout.LayoutParams(-1,0,1));

            if(i.group!=null&&!i.group.trim().isEmpty()){
                TextView grp=Ui.text(this,i.group,8,0xFF8F9991,false);
                grp.setMaxLines(1);
                names.addView(grp,new LinearLayout.LayoutParams(-1,Ui.dp(this,18)));
            }
            r.addView(names,new LinearLayout.LayoutParams(0,-1,1));

            TextView fav=Ui.text(this,LocalStore.isFavorite(this,i.id)?"★":"☆",16,
                    LocalStore.isFavorite(this,i.id)?Ui.GREEN:0xFF6F7771,true);
            fav.setGravity(Gravity.CENTER);fav.setFocusable(true);fav.setClickable(true);
            fav.setOnClickListener(v->{
                LocalStore.toggleFavorite(this,i);
                boolean yes=LocalStore.isFavorite(this,i.id);
                fav.setText(yes?"★":"☆");fav.setTextColor(yes?Ui.GREEN:0xFF6F7771);
            });
            r.addView(fav,new LinearLayout.LayoutParams(Ui.dp(this,38),-1));

            android.graphics.drawable.Drawable normal=Ui.round(0x18000000,7,this);
            android.graphics.drawable.Drawable focused=Ui.stroke(0xFF102016,Ui.GREEN,7,this);
            r.setBackground(normal);

            r.setOnFocusChangeListener((v,has)->{
                v.animate().scaleX(has?1.018f:1f).scaleY(has?1.018f:1f).setDuration(90).start();
                v.setBackground(has?focused:normal);
                if(has){
                    if(current==null||current.id!=i.id){armedChannelId=-1L;previewChannel(i,v);}
                    else currentRow=v;
                }
            });

            r.setOnClickListener(v->{
                if(current==null||current.id!=i.id){
                    armedChannelId=i.id;
                    previewChannel(i,v);
                    currentRow=v;
                    hint.setText("OK novamente: tela cheia");
                    return;
                }
                if(armedChannelId==i.id){openFullscreen();return;}
                armedChannelId=i.id;currentRow=v;hint.setText("OK novamente: tela cheia");
            });

            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,Ui.dp(this,62));
            rp.bottomMargin=Ui.dp(this,4);
            rows.addView(r,rp);
            if(i.id==initial.id)focus=r;
        }

        previewChannel(initial,focus);
        if(focus!=null)focus.requestFocus();
    }

    private void previewChannel(ApiClient.Item i, View row){
        if(i==null)return;
        if(current!=null && current.id==i.id){currentRow=row;return;}
        current=i; currentRow=row; LocalStore.saveLastLive(this,i);
        title.setText(clean(i.name,"Canal")); epgNow.setText("AGORA  Carregando programação..."); epgNext.setText("A SEGUIR  —"); hint.setText("1º OK seleciona • 2º OK abre tela cheia");
        loadEpg(i.id); startPreview(i.id);
    }

    private void startPreview(long id){
        if(isFinishing() || isDestroyed()) return;
        loading.setVisibility(View.VISIBLE);
        if(player!=null){try{preview.setPlayer(null);player.release();}catch(Exception ignored){} player=null;}
        try{
            String url=ApiClient.streamUrl(id);
            if(url==null || url.trim().isEmpty()) throw new IllegalArgumentException("URL do canal vazia");
            DefaultHttpDataSource.Factory http=new DefaultHttpDataSource.Factory().setUserAgent("DubaiPlayTV/4.0.1 Android").setConnectTimeoutMs(8000).setReadTimeoutMs(30000).setAllowCrossProtocolRedirects(true);
            player=new ExoPlayer.Builder(this).setMediaSourceFactory(new DefaultMediaSourceFactory(this).setDataSourceFactory(http)).build();
            preview.setPlayer(player);
            player.addListener(new Player.Listener(){
                @Override public void onPlaybackStateChanged(int state){if(state==Player.STATE_READY && loading!=null)loading.setVisibility(View.GONE);}
                @Override public void onPlayerError(PlaybackException error){
                    if(loading!=null)loading.setVisibility(View.GONE);
                    if(epgNow!=null)epgNow.setText("AGORA  Sinal indisponível");
                }
            });
            player.setMediaItem(MediaItem.fromUri(url)); player.prepare(); player.play();
        }catch(Throwable e){
            loading.setVisibility(View.GONE);
            epgNow.setText("AGORA  Sinal indisponível");
        }
    }

    private void loadEpg(long id){
        ApiClient.epg(id,new ApiClient.Callback<ApiClient.EpgInfo>(){
            public void ok(ApiClient.EpgInfo e){runOnUiThread(()->{if(current==null||current.id!=id)return;epgNow.setText("AGORA  "+clean(e.nowTitle,"Sem informação"));epgNext.setText("A SEGUIR  "+clean(e.nextTitle,"—"));});}
            public void error(String m){runOnUiThread(()->{if(current!=null&&current.id==id){epgNow.setText("AGORA  Sem informação");epgNext.setText("A SEGUIR  —");}});}
        });
    }

    private void openFullscreen(){
        if(current==null || fullscreen)return;
        fullscreen=true;
        if(playerCard.getParent() instanceof android.view.ViewGroup){
            ((android.view.ViewGroup)playerCard.getParent()).removeView(playerCard);
        }
        fullscreenLayer.removeAllViews();
        preview.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FILL);
        fullscreenLayer.addView(playerCard,new FrameLayout.LayoutParams(-1,-1));
        fullscreenLayer.setVisibility(View.VISIBLE);
        fullscreenLayer.bringToFront();
        hint.setText("VOLTAR: lista de canais");
        playerCard.requestFocus();
        immersive();
    }

    private void closeFullscreen(){
        if(!fullscreen)return;
        fullscreen=false;
        if(playerCard.getParent() instanceof android.view.ViewGroup){
            ((android.view.ViewGroup)playerCard.getParent()).removeView(playerCard);
        }
        fullscreenLayer.setVisibility(View.GONE);
        preview.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        if(rightColumn!=null) rightColumn.addView(playerCard,0,playerNormalLp);
        hint.setText("1º OK seleciona • 2º OK abre tela cheia");
        if(currentRow!=null) currentRow.requestFocus();
        immersive();
    }

    private void openMain(){Intent in=new Intent(this,MainActivity.class);in.putExtra("show_highlights",true);startActivity(in);finish();}
    private void openCatalog(String type,String name){Intent in=new Intent(this,CatalogActivity.class);in.putExtra("type",type);in.putExtra("title",name);startActivity(in);}
    private void openDiscover(String smart,String name){Intent in=new Intent(this,DiscoverActivity.class);in.putExtra("smart",smart);in.putExtra("title",name);startActivity(in);}

    @Override public void onBackPressed(){if(fullscreen){closeFullscreen();return;}finish();}
    @Override protected void onResume(){super.onResume();immersive();try{if(player!=null)player.play();}catch(Throwable ignored){}}
    @Override protected void onPause(){try{if(player!=null)player.pause();}catch(Throwable ignored){}super.onPause();}
    @Override protected void onDestroy(){super.onDestroy();if(player!=null){try{player.release();}catch(Exception ignored){}}}
    private void immersive(){WindowCompat.setDecorFitsSystemWindows(getWindow(),false);WindowInsetsControllerCompat c=WindowCompat.getInsetsController(getWindow(),getWindow().getDecorView());c.hide(WindowInsetsCompat.Type.systemBars());c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);}
    private String clean(String v,String f){if(v==null)return f;String s=v.trim();return s.isEmpty()||"null".equalsIgnoreCase(s)?f:s;}
}
