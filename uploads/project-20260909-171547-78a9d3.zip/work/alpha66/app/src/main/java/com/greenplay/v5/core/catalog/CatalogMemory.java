package com.greenplay.v5.core.catalog;

import com.greenplay.v5.data.model.movie.Movie;
import com.greenplay.v5.data.model.movie.MovieCategory;
import com.greenplay.v5.data.model.series.SeriesItem;
import com.greenplay.v5.data.model.series.SeriesCategory;
import com.greenplay.v5.data.model.tv.TvChannel;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Fresh catalog prepared at app startup. It deliberately lives only in-process:
 * every cold start re-reads the current bouquet from the panel, avoiding stale
 * permissions after a source is changed.
 */
public final class CatalogMemory {
    private static List<TvChannel> channels = Collections.emptyList();
    private static List<MovieCategory> movieCategories = Collections.emptyList();
    private static List<Movie> movies = Collections.emptyList();
    private static List<SeriesItem> series = Collections.emptyList();
    private static List<SeriesCategory> seriesCategories = Collections.emptyList();
    private static long updatedAt = 0L;

    private CatalogMemory() {}

    public static synchronized void clear() {
        channels = Collections.emptyList();
        movieCategories = Collections.emptyList();
        movies = Collections.emptyList();
        series = Collections.emptyList();
        seriesCategories = Collections.emptyList();
        updatedAt = 0L;
        SpecialCatalogIndex.clear();
    }

    public static synchronized void setChannels(List<TvChannel> rows) {
        channels = copy(rows);
        touch();
    }

    public static synchronized void setMovieCategories(List<MovieCategory> rows) {
        movieCategories = copy(rows);
        touch();
    }

    public static synchronized void setMovies(List<Movie> rows) {
        movies = copy(rows);
        touch();
    }

    public static synchronized void setSeries(List<SeriesItem> rows) {
        series = copy(rows);
        touch();
    }

    public static synchronized void setSeriesCategories(List<SeriesCategory> rows) {
        seriesCategories = copy(rows);
        touch();
    }


    /** V5.0.142: mescla apenas o necessário para KIDS/ANIMES sem substituir o catálogo normal. */
    public static synchronized void mergeMovieCategories(List<MovieCategory> rows) {
        if (rows == null || rows.isEmpty()) return;
        java.util.LinkedHashMap<String,MovieCategory> map = new java.util.LinkedHashMap<>();
        for (MovieCategory c : movieCategories) if (c != null) map.put(c.id == null ? "" : c.id, c);
        for (MovieCategory c : rows) if (c != null) map.put(c.id == null ? "" : c.id, c);
        movieCategories = new ArrayList<>(map.values());
        touch();
    }

    public static synchronized void mergeSeriesCategories(List<SeriesCategory> rows) {
        if (rows == null || rows.isEmpty()) return;
        java.util.LinkedHashMap<String,SeriesCategory> map = new java.util.LinkedHashMap<>();
        for (SeriesCategory c : seriesCategories) if (c != null) map.put(c.id == null ? "" : c.id, c);
        for (SeriesCategory c : rows) if (c != null) map.put(c.id == null ? "" : c.id, c);
        seriesCategories = new ArrayList<>(map.values());
        touch();
    }

    public static synchronized void mergeMovies(List<Movie> rows) {
        if (rows == null || rows.isEmpty()) return;
        java.util.LinkedHashMap<Long,Movie> map = new java.util.LinkedHashMap<>();
        for (Movie m : movies) if (m != null && m.id > 0) map.put(m.id, m);
        for (Movie incoming : rows) {
            if (incoming == null || incoming.id <= 0) continue;
            Movie current = map.get(incoming.id);
            if (current == null) { map.put(incoming.id, incoming); continue; }
            current.allCategoryIds = mergeIds(current.allCategoryIds, incoming.allCategoryIds, incoming.categoryId);
            if (blank(current.categoryId)) current.categoryId = incoming.categoryId;
            if (blank(current.poster)) current.poster = incoming.poster;
            if (blank(current.year)) current.year = incoming.year;
            if (blank(current.rating)) current.rating = incoming.rating;
            if (blank(current.contentRating)) current.contentRating = incoming.contentRating;
            if (blank(current.genre)) current.genre = incoming.genre;
            if (blank(current.plot)) current.plot = incoming.plot;
            if (blank(current.originalLanguage)) current.originalLanguage = incoming.originalLanguage;
            if (blank(current.country)) current.country = incoming.country;
            if (blank(current.mediaType)) current.mediaType = incoming.mediaType;
            if (blank(current.vodType)) current.vodType = incoming.vodType;
            if (blank(current.filterType)) current.filterType = incoming.filterType;
            current.isAdult = current.isAdult || incoming.isAdult;
        }
        movies = new ArrayList<>(map.values());
        touch();
    }

    public static synchronized void mergeSeries(List<SeriesItem> rows) {
        if (rows == null || rows.isEmpty()) return;
        java.util.LinkedHashMap<Long,SeriesItem> map = new java.util.LinkedHashMap<>();
        for (SeriesItem x : series) if (x != null && x.id > 0) map.put(x.id, x);
        for (SeriesItem incoming : rows) {
            if (incoming == null || incoming.id <= 0) continue;
            SeriesItem current = map.get(incoming.id);
            if (current == null) { map.put(incoming.id, incoming); continue; }
            current.allCategoryIds = mergeIds(current.allCategoryIds, incoming.allCategoryIds, incoming.categoryId);
            if (blank(current.categoryId)) current.categoryId = incoming.categoryId;
            if (blank(current.cover)) current.cover = incoming.cover;
            if (blank(current.year)) current.year = incoming.year;
            if (blank(current.rating)) current.rating = incoming.rating;
            if (blank(current.contentRating)) current.contentRating = incoming.contentRating;
            if (blank(current.genre)) current.genre = incoming.genre;
            if (blank(current.plot)) current.plot = incoming.plot;
            if (blank(current.mediaType)) current.mediaType = incoming.mediaType;
            if (blank(current.vodType)) current.vodType = incoming.vodType;
            if (blank(current.filterType)) current.filterType = incoming.filterType;
            current.isAdult = current.isAdult || incoming.isAdult;
        }
        series = new ArrayList<>(map.values());
        touch();
    }

    private static boolean blank(String s) { return s == null || s.trim().isEmpty(); }

    private static String mergeIds(String... values) {
        java.util.LinkedHashSet<String> ids = new java.util.LinkedHashSet<>();
        if (values != null) for (String value : values) {
            if (value == null) continue;
            for (String part : value.split("[|,;]+")) {
                String id = part == null ? "" : part.trim();
                if (!id.isEmpty()) ids.add(id);
            }
        }
        return android.text.TextUtils.join("|", ids);
    }

    public static synchronized List<TvChannel> channels() { return new ArrayList<>(channels); }
    public static synchronized List<MovieCategory> movieCategories() { return new ArrayList<>(movieCategories); }
    public static synchronized List<Movie> movies() { return new ArrayList<>(movies); }
    public static synchronized List<SeriesItem> series() { return new ArrayList<>(series); }
    public static synchronized List<SeriesCategory> seriesCategories() { return new ArrayList<>(seriesCategories); }
    public static synchronized long updatedAt() { return updatedAt; }

    /** V5.0.104: retorna apenas os itens permitidos pelo escopo, sem copiar o catálogo inteiro. */
    public static synchronized List<Movie> moviesForIds(java.util.Set<Long> ids) {
        ArrayList<Movie> out = new ArrayList<>();
        if (ids == null || ids.isEmpty()) return out;
        for (Movie x : movies) if (x != null && ids.contains(x.id)) out.add(x);
        return out;
    }

    public static synchronized List<SeriesItem> seriesForIds(java.util.Set<Long> ids) {
        ArrayList<SeriesItem> out = new ArrayList<>();
        if (ids == null || ids.isEmpty()) return out;
        for (SeriesItem x : series) if (x != null && ids.contains(x.id)) out.add(x);
        return out;
    }

    private static void touch() { updatedAt = android.os.SystemClock.elapsedRealtime(); }

    private static <T> List<T> copy(List<T> rows) {
        return rows == null ? new ArrayList<>() : new ArrayList<>(rows);
    }
}
