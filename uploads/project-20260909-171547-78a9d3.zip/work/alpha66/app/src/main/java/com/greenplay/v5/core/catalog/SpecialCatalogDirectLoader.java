package com.greenplay.v5.core.catalog;

import android.content.Context;
import com.greenplay.v5.core.ui.SpecialSections;
import com.greenplay.v5.data.model.movie.Movie;
import com.greenplay.v5.data.model.movie.MovieCategory;
import com.greenplay.v5.data.model.series.SeriesCategory;
import com.greenplay.v5.data.model.series.SeriesItem;
import com.greenplay.v5.data.repository.MovieRepository;
import com.greenplay.v5.data.repository.SeriesRepository;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * V5.0.142 — KIDS/ANIMES não dependem de cache persistente.
 *
 * Em todo cold start, consulta as categorias Xtream diretamente e carrega apenas
 * as pastas relevantes para KIDS/ANIMES. A tela especial pode abrir antes do fim;
 * quando o catálogo real chega, o SpecialCatalogIndex publica o novo escopo.
 *
 * O cache normal de TV/Filmes/Séries continua existindo só para desempenho do app,
 * mas KIDS/ANIMES nunca precisam de SpecialCatalogScopeStore para aparecer.
 */
public final class SpecialCatalogDirectLoader {
    private static String runningKey = "";
    private static String completedKey = "";

    private SpecialCatalogDirectLoader() {}

    public static void start(Context context, String host, String user, String pass) {
        if (context == null) return;
        final String h = host == null ? "" : host.trim();
        final String u = user == null ? "" : user.trim();
        final String p = pass == null ? "" : pass;
        if (h.isEmpty() || u.isEmpty() || p.isEmpty()) return;
        final String key = h.toLowerCase(Locale.ROOT) + "|" + u;

        synchronized (SpecialCatalogDirectLoader.class) {
            if (key.equals(runningKey)) return;
            if (key.equals(completedKey)
                    && SpecialCatalogIndex.hasContent(SpecialCatalogIndex.cachedScope(SpecialSections.KIDS))
                    && SpecialCatalogIndex.hasContent(SpecialCatalogIndex.cachedScope(SpecialSections.ANIME))) return;
            runningKey = key;
        }

        new Job(context.getApplicationContext(), h, u, p, key).start();
    }

    private static void finish(String key, boolean completed) {
        synchronized (SpecialCatalogDirectLoader.class) {
            if (key.equals(runningKey)) runningKey = "";
            if (completed) completedKey = key;
        }
    }

    private static final class Job {
        final Context app;
        final String host, user, pass, key;
        final MovieRepository movieRepo;
        final SeriesRepository seriesRepo;
        List<MovieCategory> movieCategories = new ArrayList<>();
        List<SeriesCategory> seriesCategories = new ArrayList<>();
        final Map<Long, Movie> movies = new LinkedHashMap<>();
        final Map<Long, SeriesItem> series = new LinkedHashMap<>();
        boolean movieCategoriesDone;
        boolean seriesCategoriesDone;
        boolean movieRowsDone;
        boolean seriesRowsDone;
        boolean fallbackStarted;

        Job(Context app, String host, String user, String pass, String key) {
            this.app = app;
            this.host = host;
            this.user = user;
            this.pass = pass;
            this.key = key;
            this.movieRepo = new MovieRepository(host, user, pass);
            this.seriesRepo = new SeriesRepository(host, user, pass);
        }

        void start() {
            movieRepo.categories(new MovieRepository.CategoriesResult() {
                @Override public void success(List<MovieCategory> rows) {
                    movieCategories = rows == null ? new ArrayList<>() : new ArrayList<>(rows);
                    movieCategoriesDone = true;
                    maybeStartRows();
                }
                @Override public void error(String message) {
                    movieCategoriesDone = true;
                    maybeStartRows();
                }
            });
            seriesRepo.categories(new SeriesRepository.CategoriesResult() {
                @Override public void success(List<SeriesCategory> rows) {
                    seriesCategories = rows == null ? new ArrayList<>() : new ArrayList<>(rows);
                    seriesCategoriesDone = true;
                    maybeStartRows();
                }
                @Override public void error(String message) {
                    seriesCategoriesDone = true;
                    maybeStartRows();
                }
            });
        }

        synchronized void maybeStartRows() {
            if (!movieCategoriesDone || !seriesCategoriesDone) return;
            if (!movieRowsDone && movies.isEmpty()) {
                List<String> ids = candidateMovieCategoryIds(movieCategories);
                if (ids.isEmpty()) {
                    movieRowsDone = true;
                } else {
                    loadMovieCategory(ids, 0);
                }
            }
            if (!seriesRowsDone && series.isEmpty()) {
                List<String> ids = candidateSeriesCategoryIds(seriesCategories);
                if (ids.isEmpty()) {
                    seriesRowsDone = true;
                } else {
                    loadSeriesCategory(ids, 0);
                }
            }
            maybePublish();
        }

        void loadMovieCategory(final List<String> ids, final int index) {
            if (index >= ids.size()) {
                synchronized (this) { movieRowsDone = true; }
                maybePublish();
                return;
            }
            final String categoryId = ids.get(index);
            movieRepo.movies(categoryId, new MovieRepository.MoviesResult() {
                @Override public void success(List<Movie> rows) {
                    mergeMovies(rows, categoryId);
                    loadMovieCategory(ids, index + 1);
                }
                @Override public void error(String message) {
                    loadMovieCategory(ids, index + 1);
                }
            });
        }

        void loadSeriesCategory(final List<String> ids, final int index) {
            if (index >= ids.size()) {
                synchronized (this) { seriesRowsDone = true; }
                maybePublish();
                return;
            }
            final String categoryId = ids.get(index);
            seriesRepo.series(categoryId, new SeriesRepository.SeriesResult() {
                @Override public void success(List<SeriesItem> rows) {
                    mergeSeries(rows, categoryId);
                    loadSeriesCategory(ids, index + 1);
                }
                @Override public void error(String message) {
                    loadSeriesCategory(ids, index + 1);
                }
            });
        }

        synchronized void mergeMovies(List<Movie> rows, String requestedCategoryId) {
            if (rows == null) return;
            for (Movie m : rows) {
                if (m == null || m.id <= 0) continue;
                stampMovieCategory(m, requestedCategoryId);
                Movie current = movies.get(m.id);
                if (current == null) movies.put(m.id, m);
                else mergeMovie(current, m);
            }
        }

        synchronized void mergeSeries(List<SeriesItem> rows, String requestedCategoryId) {
            if (rows == null) return;
            for (SeriesItem s : rows) {
                if (s == null || s.id <= 0) continue;
                stampSeriesCategory(s, requestedCategoryId);
                SeriesItem current = series.get(s.id);
                if (current == null) series.put(s.id, s);
                else mergeSeriesItem(current, s);
            }
        }

        synchronized void maybePublish() {
            if (!movieRowsDone || !seriesRowsDone) return;

            List<Movie> movieList = new ArrayList<>(movies.values());
            List<SeriesItem> seriesList = new ArrayList<>(series.values());

            if (!movieCategories.isEmpty()) CatalogMemory.mergeMovieCategories(movieCategories);
            if (!seriesCategories.isEmpty()) CatalogMemory.mergeSeriesCategories(seriesCategories);
            if (!movieList.isEmpty()) CatalogMemory.mergeMovies(movieList);
            if (!seriesList.isEmpty()) CatalogMemory.mergeSeries(seriesList);

            SpecialCatalogIndex.Scope kids = SpecialCatalogIndex.buildScope(
                    SpecialSections.KIDS, movieCategories, movieList, seriesCategories, seriesList);
            SpecialCatalogIndex.Scope anime = SpecialCatalogIndex.buildScope(
                    SpecialSections.ANIME, movieCategories, movieList, seriesCategories, seriesList);

            if (SpecialCatalogIndex.hasContent(kids)) SpecialCatalogIndex.publishScope(SpecialSections.KIDS, kids);
            if (SpecialCatalogIndex.hasContent(anime)) SpecialCatalogIndex.publishScope(SpecialSections.ANIME, anime);

            boolean kidsOk = SpecialCatalogIndex.hasContent(SpecialCatalogIndex.cachedScope(SpecialSections.KIDS));
            boolean animeOk = SpecialCatalogIndex.hasContent(SpecialCatalogIndex.cachedScope(SpecialSections.ANIME));
            if (kidsOk && animeOk) {
                finish(key, true);
                return;
            }

            // Servidor sem pastas reconhecíveis: uma única varredura geral em fallback.
            // Continua em background e só acontece quando a carga seletiva não resolveu.
            if (!fallbackStarted) {
                fallbackStarted = true;
                loadFullFallback(kidsOk, animeOk);
            }
        }

        void loadFullFallback(boolean kidsAlreadyOk, boolean animeAlreadyOk) {
            final boolean needMovies = true;
            movieRepo.movies("", new MovieRepository.MoviesResult() {
                @Override public void success(List<Movie> rows) {
                    mergeMovies(rows, "");
                    loadFullSeries();
                }
                @Override public void error(String message) { loadFullSeries(); }
            });
        }

        void loadFullSeries() {
            seriesRepo.series("", new SeriesRepository.SeriesResult() {
                @Override public void success(List<SeriesItem> rows) {
                    mergeSeries(rows, "");
                    publishFallbackAndFinish();
                }
                @Override public void error(String message) { publishFallbackAndFinish(); }
            });
        }

        synchronized void publishFallbackAndFinish() {
            List<Movie> movieList = new ArrayList<>(movies.values());
            List<SeriesItem> seriesList = new ArrayList<>(series.values());
            if (!movieList.isEmpty()) CatalogMemory.mergeMovies(movieList);
            if (!seriesList.isEmpty()) CatalogMemory.mergeSeries(seriesList);

            SpecialCatalogIndex.Scope kids = SpecialCatalogIndex.buildScope(
                    SpecialSections.KIDS, movieCategories, movieList, seriesCategories, seriesList);
            SpecialCatalogIndex.Scope anime = SpecialCatalogIndex.buildScope(
                    SpecialSections.ANIME, movieCategories, movieList, seriesCategories, seriesList);
            if (SpecialCatalogIndex.hasContent(kids)) SpecialCatalogIndex.publishScope(SpecialSections.KIDS, kids);
            if (SpecialCatalogIndex.hasContent(anime)) SpecialCatalogIndex.publishScope(SpecialSections.ANIME, anime);
            finish(key,
                    SpecialCatalogIndex.hasContent(SpecialCatalogIndex.cachedScope(SpecialSections.KIDS))
                    || SpecialCatalogIndex.hasContent(SpecialCatalogIndex.cachedScope(SpecialSections.ANIME)));
        }
    }

    private static List<String> candidateMovieCategoryIds(List<MovieCategory> rows) {
        LinkedHashMap<String, String> out = new LinkedHashMap<>();
        if (rows != null) for (MovieCategory c : rows) {
            if (c == null || blank(c.id)) continue;
            String n = c.name == null ? "" : c.name;
            boolean kids = SpecialSections.isKidsCategoryName(n);
            boolean anime = SpecialSections.isAnimeCategoryName(n);
            boolean animationFallback = isAnimationCategoryName(n);
            if (kids || anime || animationFallback) out.put(c.id.trim(), c.id.trim());
        }
        return new ArrayList<>(out.keySet());
    }

    private static List<String> candidateSeriesCategoryIds(List<SeriesCategory> rows) {
        LinkedHashMap<String, String> out = new LinkedHashMap<>();
        if (rows != null) for (SeriesCategory c : rows) {
            if (c == null || blank(c.id)) continue;
            String n = c.name == null ? "" : c.name;
            if (SpecialSections.isKidsCategoryName(n) || SpecialSections.isAnimeCategoryName(n))
                out.put(c.id.trim(), c.id.trim());
        }
        return new ArrayList<>(out.keySet());
    }

    /** Anime VOD costuma vir escondido em "Animação" sem pasta "Anime". */
    private static boolean isAnimationCategoryName(String raw) {
        String n = " " + normalize(raw) + " ";
        return n.contains(" animacao ") || n.contains(" animacoes ")
                || n.contains(" animation ") || n.contains(" animations ")
                || n.contains(" animated ");
    }

    private static void stampMovieCategory(Movie m, String categoryId) {
        if (m == null || blank(categoryId)) return;
        String cid = categoryId.trim();
        if (blank(m.categoryId)) m.categoryId = cid;
        m.allCategoryIds = appendCategory(m.allCategoryIds, cid);
        m.allCategoryIds = appendCategory(m.allCategoryIds, m.categoryId);
    }

    private static void stampSeriesCategory(SeriesItem s, String categoryId) {
        if (s == null || blank(categoryId)) return;
        String cid = categoryId.trim();
        if (blank(s.categoryId)) s.categoryId = cid;
        s.allCategoryIds = appendCategory(s.allCategoryIds, cid);
        s.allCategoryIds = appendCategory(s.allCategoryIds, s.categoryId);
    }

    private static void mergeMovie(Movie a, Movie b) {
        a.allCategoryIds = appendCategory(a.allCategoryIds, b.allCategoryIds);
        a.allCategoryIds = appendCategory(a.allCategoryIds, b.categoryId);
        if (blank(a.categoryId)) a.categoryId = b.categoryId;
        if (blank(a.poster)) a.poster = b.poster;
        if (blank(a.year)) a.year = b.year;
        if (blank(a.rating)) a.rating = b.rating;
        if (blank(a.contentRating)) a.contentRating = b.contentRating;
        if (blank(a.genre)) a.genre = b.genre;
        if (blank(a.plot)) a.plot = b.plot;
        if (blank(a.originalLanguage)) a.originalLanguage = b.originalLanguage;
        if (blank(a.country)) a.country = b.country;
        if (blank(a.mediaType)) a.mediaType = b.mediaType;
        if (blank(a.vodType)) a.vodType = b.vodType;
        if (blank(a.filterType)) a.filterType = b.filterType;
        a.isAdult = a.isAdult || b.isAdult;
    }

    private static void mergeSeriesItem(SeriesItem a, SeriesItem b) {
        a.allCategoryIds = appendCategory(a.allCategoryIds, b.allCategoryIds);
        a.allCategoryIds = appendCategory(a.allCategoryIds, b.categoryId);
        if (blank(a.categoryId)) a.categoryId = b.categoryId;
        if (blank(a.cover)) a.cover = b.cover;
        if (blank(a.year)) a.year = b.year;
        if (blank(a.rating)) a.rating = b.rating;
        if (blank(a.contentRating)) a.contentRating = b.contentRating;
        if (blank(a.genre)) a.genre = b.genre;
        if (blank(a.plot)) a.plot = b.plot;
        if (blank(a.mediaType)) a.mediaType = b.mediaType;
        if (blank(a.vodType)) a.vodType = b.vodType;
        if (blank(a.filterType)) a.filterType = b.filterType;
        a.isAdult = a.isAdult || b.isAdult;
    }

    private static String appendCategory(String raw, String addRaw) {
        String out = raw == null ? "" : raw.trim();
        if (addRaw == null || addRaw.trim().isEmpty()) return out;
        String[] adds = addRaw.trim().split("[|,;]+");
        for (String x : adds) {
            String id = x == null ? "" : x.trim();
            if (id.isEmpty()) continue;
            boolean found = false;
            if (!out.isEmpty()) {
                for (String existing : out.split("[|,;]+")) {
                    if (id.equals(existing.trim())) { found = true; break; }
                }
            }
            if (!found) out = out.isEmpty() ? id : out + "|" + id;
        }
        return out;
    }

    private static String normalize(String raw) {
        if (raw == null) return "";
        return Normalizer.normalize(raw, Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "")
                .toLowerCase(Locale.ROOT)
                .replaceAll("[^\\p{L}\\p{N}+]+", " ")
                .replaceAll("\\s+", " ").trim();
    }

    private static boolean blank(String s) { return s == null || s.trim().isEmpty(); }
}
