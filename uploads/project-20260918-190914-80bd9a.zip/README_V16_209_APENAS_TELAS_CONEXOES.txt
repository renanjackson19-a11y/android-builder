GreenPlay v16.209

Base restaurada: v16.207.

Alteracoes SOMENTE na leitura de telas/conexoes:
- reconhece screens_total vindo do painel;
- reconhece screens_used / active_sessions ja suportados;
- a consulta complementar de telas fica somente na tela Perfil;
- o carregamento da Home NAO espera consulta de planos/telas.

Nao foi alterado:
- Home;
- catalogo;
- menu;
- layout;
- player;
- TV/TV Box;
- login;
- Web.
