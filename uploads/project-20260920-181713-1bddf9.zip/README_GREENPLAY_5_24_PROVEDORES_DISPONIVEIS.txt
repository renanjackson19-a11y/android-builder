GREENPLAY APP 5.24 — PROVEDORES DISPONÍVEIS

- Removida do aplicativo a exibição de conexões do fornecedor.
- A lista de servidores mostra somente provedores devolvidos como disponíveis pelo painel.
- Provedor desativado/offline não reaparece por fallback de configuração antiga.
- Ao iniciar/retomar o app, o provedor atualmente selecionado é validado.
- Se o provedor atual deixou de estar disponível, a seleção é limpa e o app volta para Escolha um servidor.
- Quando não há nenhum provedor online, a tela permite tentar novamente e refaz a verificação automaticamente.
- versionName 5.24 / versionCode 52400 mantidos.
