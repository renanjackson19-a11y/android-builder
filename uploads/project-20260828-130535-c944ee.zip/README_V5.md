# GREEN PLAY V5 — BASE NOVA

Projeto Android criado do zero. Nenhuma Activity, Adapter, cache, player ou classe do V4 foi reutilizada.

## Alpha 02
- Contrato real do painel conectado (host + token do aplicativo configurados apenas como dados de compatibilidade).
- Login do painel corrigido: quando o painel não devolve `xtream_host`, o V5 usa a raiz oficial do painel como servidor Xtream, como exige o contrato atual.
- Sessão V5 continua independente.
- Primeiro módulo funcional criado: TV.
- TV carrega `get_live_categories` e `get_live_streams` diretamente pelo Xtream.
- Filtro por categoria.
- Pesquisa por nome do canal.
- Logos dos canais.
- Preview Media3 à direita.
- EPG curto (Agora / A seguir).
- OK/click abre player em tela cheia.
- Navegação focável para TV Box/controle remoto.

## Ainda não implementado nesta alpha
- Favoritos e recentes persistentes.
- Futebol.
- Filmes.
- Séries/temporadas/episódios.
- Kids.
- Anime.
- HOT + PIN.
- Conta e personalização completa do painel.

A regra permanece: cada módulo novo é isolado. Não remendar o V4.

## Alpha 03 TV
- TV refeita sem reaproveitar a Activity/Adapter do V4.
- Liberado HTTP cleartext para servidores Xtream legados.
- Preview tenta TS e faz fallback automático para HLS/m3u8 em erro.
- Player de tela cheia também tenta URL alternativa.
- EPG agora escolhe o programa vigente por timestamp, exibe horário e progresso.
- Favoritos e recentes locais adicionados.
- Layout de TV compactado para exibir mais canais e aproximado da referência visual.


## Alpha 04 - player TV
- transporte HTTP próprio do V5 com redirects HTTP/HTTPS habilitados;
- User-Agent compatível com fontes IPTV que rejeitam o cliente HTTP padrão;
- headers neutros para stream (`Accept: */*`, `Accept-Encoding: identity`);
- MIME explícito para MPEG-TS e HLS;
- fallback TS -> HLS preservado;
- preview passa a exibir código/causa resumida quando ambos os formatos falham;
- PlayerActivity não destrói mais o player apenas por ir para background; libera somente no destroy.


## Alpha 05 - TV/player diagnostic
- applicationId V5 próprio: `com.greenplay.v5` (não conflita com V4 `shop.dubaiplay.tv`).
- preview inicia automaticamente ao carregar/focar canal.
- preview e tela cheia usam `TextureView` para evitar tela preta causada por SurfaceView/hardware overlay em alguns aparelhos/TV Boxes.
- antes de tocar, o V5 testa o stream e segue redirects, detectando HTTP, Content-Type e TS/HLS.
- status do preview exibe algo como `HTTP 200 • TS • video/mp2t`; em falha exibe o código real.
- nenhuma classe do V4 foi importada/copied para a base V5.

## Alpha 06 — TV fechada para validação
- Player/preview preservado da Alpha 05 (não mexer no núcleo que passou a reproduzir).
- Lista de canais compactada para exibir mais itens simultaneamente em 16:9.
- Cabeçalho, busca, filtros e categorias compactados sem mudar o fluxo funcional.
- Categorias horizontais acompanham o foco para evitar item selecionado escondido nas laterais.
- Ao abrir tela cheia e voltar, o app retorna para o mesmo canal e reposiciona o foco nele.
- Favoritos e recentes continuam isolados em armazenamento local.
- applicationId continua `com.greenplay.v5`, permitindo instalar ao lado do V4.

## Alpha 07
- Mantido o player da Alpha 05/06 que já reproduz TV.
- Preview voltou a ficar limitado à área superior direita; o EPG agora fica em painel opaco separado, sem o vídeo "crescer" por trás ao trocar de canal.
- `resize_mode=fit` para evitar zoom/corte do vídeo no preview.
- `applicationId` continua `com.greenplay.v5`.
- Adicionada assinatura fixa do projeto em `app/signing/greenplay-v5.jks` para permitir atualização por cima nas próximas versões.
- `versionCode` aumentado para 5007.

IMPORTANTE: se uma Alpha anterior foi instalada com outra assinatura, será necessário desinstalar ESSA Alpha uma última vez antes da Alpha 07. Da Alpha 07 em diante, mantendo este mesmo arquivo de assinatura e aumentando o versionCode, as novas APKs instalam como atualização por cima.


## Alpha 08 — correção de seleção de canal
- D-pad/cursor apenas move o foco na lista; não troca o preview e não abre tela cheia.
- Primeiro OK em um canal diferente: seleciona o canal e inicia o preview na direita.
- Segundo OK no mesmo canal já selecionado: abre o player em tela cheia.
- Ao voltar da tela cheia, o foco retorna ao canal selecionado.
- versionCode 5008, mantendo o mesmo applicationId e a mesma assinatura da Alpha 07 para instalar por cima.


## Alpha 09 — TV limpa / preview abre tela cheia
- Removida a segunda fileira de “pastas”/categorias da tela de TV.
- TV abre diretamente com TODOS os canais; Favoritos e Recentes permanecem.
- Tocar/clicar no preview abre o canal atual em tela cheia.
- No controle remoto, focar o preview e pressionar OK/Enter também abre tela cheia.
- Mantidos pacote `com.greenplay.v5` e a mesma assinatura da Alpha 07/08; versionCode 5009 para atualização por cima.
- Núcleo de reprodução que já estava funcionando não foi alterado.


## Alpha 10 - TV rápida + fullscreen sem recarga + sessão persistente
- Troca de canal não faz mais inspeção HTTP antes de tocar; abre direto no ExoPlayer e usa fallback TS/HLS apenas se der erro.
- Removido atraso artificial de 350 ms na seleção do canal.
- Tela cheia agora usa o MESMO ExoPlayer da prévia, sem abrir uma nova Activity e sem reiniciar o stream.
- VOLTAR da tela cheia devolve o mesmo player para a prévia, sem recarregar o canal.
- Login agora pula automaticamente para o app quando já existe sessão salva válida.
- Mantidos applicationId e signingConfig da linha Alpha 07+ para permitir atualização por cima.


## Alpha 11 – TV layout final de referência
- Tela de TV refeita visualmente sobre a base V5, sem copiar código do app antigo.
- Lista limpa à esquerda com TODOS/FAVORITOS e canais compactos.
- Vídeo ocupa toda a área direita.
- EPG virou painel flutuante sobre o vídeo, com logo, número, nome, atual/próximo e progresso.
- Player, troca rápida, fullscreen sem recarga, sessão e assinatura preservados.
- versionCode 5011; mesmo applicationId/assinatura para atualizar por cima.


## Alpha 12 - proporção correta + fullscreen estável
- Player da TV alterado de `zoom` para `fit`: não corta nem amplia a imagem do canal.
- Barras pretas aparecem apenas quando a proporção do sinal exigir, preservando a imagem completa.
- Toque/clique/OK durante tela cheia não reduz mais o player.
- Para sair da tela cheia, somente VOLTAR/BACK.
- Mesmo player é mantido; não há reinício de stream ao entrar/sair do fullscreen.
- versionCode 5012, mantendo pacote e assinatura para atualização por cima.


## Alpha 13 — comportamento de TV conferido na referência V4
- A referência V4.0.96/V4.0.97 confirma: layout normal lista + preview; tocar no preview amplia o MESMO player.
- Tela cheia não cria outro player e não recarrega o stream.
- Em tela cheia, OK/toque abre/fecha uma lista lateral sobre o vídeo; não reduz o vídeo.
- VOLTAR fecha primeiro a lista lateral; novo VOLTAR retorna ao layout normal.
- Player normal e fullscreen usam FIT para preservar proporção e deixar barras pretas somente quando necessárias.
- Implementação do V5 continua nova; o V4 foi usado apenas como referência comportamental.

## Alpha 14 — vídeo preenchendo somente as faixas pretas
- Confirmado no V4 original: a TV usava `AspectRatioFrameLayout.RESIZE_MODE_FILL` no preview e no fullscreen.
- V5 voltou ao mesmo comportamento visual: o quadro do player é preenchido sem o crop/zoom do modo ZOOM.
- Isso elimina as faixas pretas do container esticando apenas a apresentação do vídeo para ocupar a área disponível; não usa zoom com corte.
- Fullscreen mantém o mesmo player e o fluxo definido na Alpha 13.
