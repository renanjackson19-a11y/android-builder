PROJETO ANDROID SPOTNET MUSIC

Já aponta para https://spotnet.br232.shop
Consome banners do painel e usa login com planos/conexões.

Envie este ZIP no compilador em modo debug.
