package com.ativacao.app;

import android.app.Activity;
import android.content.Context;
import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Faz a preparação inicial uma única vez por cliente/token.
 * A interface só abre depois que TV, Filmes e Séries possuem a primeira página salva.
 */
final class CatalogPreloader {
    private static final String PREF="dubai_content_preload";
    private static final int CACHE_SCHEMA=9;
    private static volatile boolean running=false;
    private static volatile boolean ready=false;

    interface Progress { void onProgress(String text,int done,int total); }

    static void init(Context c){
        if(c==null)return;
        ready=c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getBoolean(key(Session.token(c)),false);
    }
    static boolean isReady(){ return ready; }
    static boolean isPrepared(Context c){
        if(c==null)return ready;
        return c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getBoolean(key(Session.token(c)),false);
    }
    private static String key(String token){ return "ready_v"+CACHE_SCHEMA+"_"+Integer.toHexString((token==null?"":token).hashCode()); }
    private static void markReady(Context c,boolean value){
        if(c==null)return;
        c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putBoolean(key(Session.token(c)),value).apply();
        ready=value;
    }

    static void start(Activity a, boolean force, Runnable done){ start(a,force,null,done); }

    static void start(Activity a, boolean force, Progress progress, Runnable done){
        if(a==null){ if(done!=null)done.run(); return; }
        if(!force && isPrepared(a)){ ready=true; if(done!=null)done.run(); return; }
        if(running) return;
        running=true;
        // V185: stale-while-revalidate.
        // Nunca apaga o snapshot válido antes de buscar o novo.
        // Assim todas as telas continuam abrindo instantaneamente durante a sincronização.
        final boolean hadPrepared=isPrepared(a);
        if(!hadPrepared) markReady(a,false);

        final boolean phone=Ui.phone(a);
        final int liveLimit=72;
        final int movieLimit=72;
        final int seriesLimit=72;
        // V198: a primeira entrada só libera a Home depois de preparar também
        // Kids, Anime e HOT. Assim as abas entram com o catálogo já salvo.
        final int total=6;
        final AtomicInteger pending=new AtomicInteger(total);
        final AtomicInteger doneCount=new AtomicInteger(0);
        final AtomicInteger primaryFailures=new AtomicInteger(0);

        notify(progress,"Preparando TV ao vivo...",0,total);
        preloadPrimary(a,"live",liveLimit,"TV ao vivo",pending,doneCount,total,primaryFailures,progress,done);
        preloadPrimary(a,"movie",movieLimit,"Filmes",pending,doneCount,total,primaryFailures,progress,done);
        preloadPrimary(a,"series",seriesLimit,"Séries",pending,doneCount,total,primaryFailures,progress,done);
        preloadExactMode(a,"kids","Kids",pending,doneCount,total,primaryFailures,progress,done);
        preloadExactMode(a,"anime","Anime",pending,doneCount,total,primaryFailures,progress,done);
        preloadAdultAll(a,pending,doneCount,total,primaryFailures,progress,done);

    }

    private static void preloadPrimary(Activity a,String type,int limit,String label,
                                       AtomicInteger pending,AtomicInteger doneCount,int total,
                                       AtomicInteger failures,Progress progress,Runnable done){
        ApiClient.catalog(type,1,limit,"","","",new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){
                if(valid(p)){ warmImages(a,p); finishOne(a,label,pending,doneCount,total,failures,progress,done); return; }
                retryFresh(a,type,limit,label,pending,doneCount,total,failures,progress,done);
            }
            public void error(String first){ retryFresh(a,type,limit,label,pending,doneCount,total,failures,progress,done); }
        });
    }

    private static boolean valid(ApiClient.CatalogPage p){ return p!=null && (p.total>0 || !p.items.isEmpty()); }

    private static void preloadExactMode(Activity a,String mode,String label,
                                         AtomicInteger pending,AtomicInteger doneCount,int total,AtomicInteger failures,
                                         Progress progress,Runnable done){
        final ArrayList<String> movieCats=new ArrayList<>(), seriesCats=new ArrayList<>();
        final AtomicInteger catsPending=new AtomicInteger(2);
        ApiClient.categories("movie",new ApiClient.Callback<List<String>>(){
            public void ok(List<String>x){if(x!=null)movieCats.addAll(x);exactCatsReady(a,mode,label,movieCats,seriesCats,catsPending,pending,doneCount,total,failures,progress,done);}
            public void error(String m){exactCatsReady(a,mode,label,movieCats,seriesCats,catsPending,pending,doneCount,total,failures,progress,done);}
        });
        ApiClient.categories("series",new ApiClient.Callback<List<String>>(){
            public void ok(List<String>x){if(x!=null)seriesCats.addAll(x);exactCatsReady(a,mode,label,movieCats,seriesCats,catsPending,pending,doneCount,total,failures,progress,done);}
            public void error(String m){exactCatsReady(a,mode,label,movieCats,seriesCats,catsPending,pending,doneCount,total,failures,progress,done);}
        });
    }

    private static void exactCatsReady(Activity a,String mode,String label,List<String> movieCats,List<String> seriesCats,
                                       AtomicInteger catsPending,AtomicInteger pending,AtomicInteger doneCount,int total,
                                       AtomicInteger failures,Progress progress,Runnable done){
        if(catsPending.decrementAndGet()!=0)return;
        ArrayList<String[]> jobs=new ArrayList<>();
        for(String c:movieCats)if(matchModeCategory(c,mode))jobs.add(new String[]{"movie",c});
        for(String c:seriesCats)if(matchModeCategory(c,mode))jobs.add(new String[]{"series",c});
        if(jobs.isEmpty()){finishOne(a,label,pending,doneCount,total,failures,progress,done);return;}
        AtomicInteger jp=new AtomicInteger(jobs.size());
        for(String[] j:jobs)preloadCategoryChain(a,j[0],j[1],1,()->{
            if(jp.decrementAndGet()==0)finishOne(a,label,pending,doneCount,total,failures,progress,done);
        });
    }

    private static void preloadCategoryChain(Activity a,String type,String category,int page,Runnable completed){
        ApiClient.catalog(type,page,72,"",category,"",new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){
                warmImages(a,p);
                if(p!=null && page<Math.max(1,p.pages))preloadCategoryChain(a,type,category,page+1,completed); else completed.run();
            }
            public void error(String m){completed.run();}
        });
    }

    private static void preloadAdultAll(Activity a,AtomicInteger pending,AtomicInteger doneCount,int total,
                                        AtomicInteger failures,Progress progress,Runnable done){
        AtomicInteger types=new AtomicInteger(2);
        Runnable one=()->{if(types.decrementAndGet()==0)finishOne(a,"HOT",pending,doneCount,total,failures,progress,done);};
        preloadAdultChain(a,"movie",1,one);
        preloadAdultChain(a,"series",1,one);
    }

    private static void preloadAdultChain(Activity a,String type,int page,Runnable completed){
        // Consulta ampla smart=adult diretamente no painel e grava cada página no cache.
        ApiClient.catalogAdult(type,page,72,"",-1,new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){
                warmImages(a,p);
                if(p!=null && page<Math.max(1,p.pages))preloadAdultChain(a,type,page+1,completed); else completed.run();
            }
            public void error(String m){completed.run();}
        });
    }

    private static void retryFresh(Activity a,String type,int limit,String label,
                                   AtomicInteger pending,AtomicInteger doneCount,int total,AtomicInteger failures,
                                   Progress progress,Runnable done){
        ApiClient.invalidateCatalog(type,1,limit,"","","");
        ApiClient.catalog(type,1,limit,"","","",new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){
                if(valid(p)){ warmImages(a,p); finishOne(a,label,pending,doneCount,total,failures,progress,done); }
                else { failures.incrementAndGet(); finishOne(a,label,pending,doneCount,total,failures,progress,done); }
            }
            public void error(String m){ failures.incrementAndGet(); finishOne(a,label,pending,doneCount,total,failures,progress,done); }
        });
    }

    private static void finishOne(Activity a,String label,AtomicInteger pending,AtomicInteger doneCount,int total,
                                  AtomicInteger failures,Progress progress,Runnable done){
        int d=doneCount.incrementAndGet();
        notify(progress,"Atualizando "+label+"...",d,total);
        if(pending.decrementAndGet()!=0)return;
        running=false;
        boolean ok=failures.get()==0;
        boolean usable=ok || isPrepared(a);
        markReady(a,usable);
        notify(progress,ok?"Conteúdo pronto":"Conteúdo disponível • atualização parcial",total,total);
        if(done!=null)done.run();
        backgroundWarm(a);
    }

    private static void notify(Progress p,String text,int done,int total){ if(p!=null) p.onProgress(text,done,total); }

    /** Sincroniza silenciosamente quando o usuário volta ao app. Não troca de tela. */
    static void refreshBackground(Activity a){
        if(a==null || running)return;
        ApiClient.setUserToken(Session.token(a));

        // Atualiza os três snapshots principais sem apagar os anteriores.
        String[] types={"live","movie","series"};
        int[] limits={72,72,72};
        for(int i=0;i<types.length;i++){
            final String type=types[i];
            final int limit=limits[i];
            ApiClient.catalog(type,1,limit,"","","",new ApiClient.Callback<ApiClient.CatalogPage>(){
                public void ok(ApiClient.CatalogPage p){
                    warmImages(a,p);
                    if("series".equals(type) && p!=null){
                        int max=Math.min(4,p.items.size());
                        for(int n=0;n<max;n++){
                            ApiClient.Item it=p.items.get(n);
                            if(it!=null)ApiClient.warmSeries(it.name);
                        }
                    }
                }
                public void error(String m){}
            });
        }
        backgroundWarm(a);
    }

    private static void backgroundWarm(Activity a){
        // Categorias ficam prontas antes do primeiro clique.
        ApiClient.categories("movie",new ApiClient.Callback<List<String>>(){ public void ok(List<String>x){} public void error(String m){} });
        ApiClient.categories("series",new ApiClient.Callback<List<String>>(){ public void ok(List<String>x){} public void error(String m){} });
        ApiClient.hotCategories(new ApiClient.Callback<List<ApiClient.HotCategory>>(){ public void ok(List<ApiClient.HotCategory>x){ warmHotVod(a,x); } public void error(String m){} });
        warmExactMode(a,"kids");
        warmExactMode(a,"anime");

        // Lançamentos continuam aquecidos sem segurar a interface.
        String[][] jobs={{"movie","launch"},{"series","launch"}};
        for(String[] j:jobs){
            int limit="series".equals(j[0])?30:48;
            ApiClient.catalog(j[0],1,limit,"","",j[1],new ApiClient.Callback<ApiClient.CatalogPage>(){
                public void ok(ApiClient.CatalogPage p){
                    warmImages(a,p);
                    if("series".equals(j[0]) && p!=null){
                        int max=Math.min(3,p.items.size());
                        for(int n=0;n<max;n++){
                            ApiClient.Item it=p.items.get(n);
                            if(it!=null)ApiClient.warmSeries(it.name);
                        }
                    }
                }
                public void error(String m){}
            });
        }
    }

    private static void warmExactMode(Activity a,String mode){
        ApiClient.categoriesPrepared("movie",new ApiClient.Callback<List<String>>(){
            public void ok(List<String> cats){ if(cats!=null)for(String cat:cats)if(matchModeCategory(cat,mode))warmCategoryPages(a,"movie",cat,1); }
            public void error(String m){}
        });
        ApiClient.categoriesPrepared("series",new ApiClient.Callback<List<String>>(){
            public void ok(List<String> cats){ if(cats!=null)for(String cat:cats)if(matchModeCategory(cat,mode))warmCategoryPages(a,"series",cat,1); }
            public void error(String m){}
        });
    }
    private static boolean matchModeCategory(String cat,String mode){return "kids".equals(mode)?CatalogModeRules.kidsCategory(cat):CatalogModeRules.animeCategory(cat);}
    private static void warmCategoryPages(Activity a,String type,String category,int page){
        ApiClient.catalog(type,page,72,"",category,"",new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){warmImages(a,p);if(p!=null&&page<p.pages)warmCategoryPages(a,type,category,page+1);}
            public void error(String m){}
        });
    }
    private static void warmHotVod(Activity a,List<ApiClient.HotCategory> cats){
        if(cats==null)return;for(ApiClient.HotCategory h:cats){if(h==null)continue;if(h.movieCount!=0||h.count==0)warmHotPages(a,"movie",h,1);if(h.seriesCount!=0||h.count==0)warmHotPages(a,"series",h,1);}
    }
    private static void warmHotPages(Activity a,String type,ApiClient.HotCategory h,int page){
        ApiClient.catalogAdult(type,page,72,h.name,h.sourceId,new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){warmImages(a,p);if(p!=null&&page<p.pages)warmHotPages(a,type,h,page+1);}
            public void error(String m){}
        });
    }

    private static void warmImages(Activity a,ApiClient.CatalogPage p){
        if(p==null)return;
        int max=Math.min(p.items.size(),12);
        for(int n=0;n<max;n++){
            ApiClient.Item i=p.items.get(n); if(i==null)continue;
            ImageLoader.preload(a,clean(i.logo,i.backdrop));
        }
    }
    private static String clean(String a,String b){ String x=a==null?"":a.trim(); return x.isEmpty()?(b==null?"":b.trim()):x; }
}
