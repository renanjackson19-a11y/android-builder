DUBAI BUSCAR CANAIS 1.0

Funções:
- Cola URL M3U/Xtream ou conteúdo M3U.
- Abre arquivo M3U local.
- Pode carregar a URL informada pelo próprio usuário.
- Separa DNS, usuário e senha de URLs Xtream comuns.
- Lista canais encontrados.

Segurança:
- Não lê dados privados de outros aplicativos.
- Não intercepta HTTPS de terceiros.

Compilar no Android Studio:
1. Abra esta pasta.
2. Aguarde o Gradle sincronizar.
3. Build > Build APK(s).
