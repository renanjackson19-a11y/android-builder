package com.dubai.buscarcanais;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;

public class MainActivity extends Activity {
    private static final int PICK_M3U = 2001;
    private EditText input;
    private TextView info, result;
    private int green = Color.rgb(49,232,106);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(18));
        root.setBackgroundColor(Color.rgb(7,17,11));

        TextView title = tv("Dubai Buscar Canais", 26, Color.WHITE, true);
        root.addView(title);
        TextView sub = tv("Analise sua própria fonte M3U / Xtream e organize DNS, usuário e senha.", 14, Color.LTGRAY, false);
        sub.setPadding(0, dp(6), 0, dp(14)); root.addView(sub);

        input = new EditText(this);
        input.setHint("Cole a URL M3U/Xtream ou o conteúdo M3U aqui");
        input.setHintTextColor(Color.GRAY); input.setTextColor(Color.WHITE);
        input.setMinLines(4); input.setGravity(Gravity.TOP);
        input.setBackgroundColor(Color.rgb(18,35,25)); input.setPadding(dp(12),dp(12),dp(12),dp(12));
        root.addView(input, new LinearLayout.LayoutParams(-1, dp(150)));

        LinearLayout buttons = new LinearLayout(this); buttons.setOrientation(LinearLayout.HORIZONTAL); buttons.setPadding(0,dp(10),0,0);
        Button analyze = btn("ANALISAR"); Button open = btn("ABRIR M3U"); Button load = btn("CARREGAR URL");
        buttons.addView(analyze, new LinearLayout.LayoutParams(0, dp(52), 1));
        buttons.addView(open, new LinearLayout.LayoutParams(0, dp(52), 1));
        buttons.addView(load, new LinearLayout.LayoutParams(0, dp(52), 1));
        root.addView(buttons);

        info = tv("DNS: —\nUsuário: —\nSenha: —", 16, Color.WHITE, false);
        info.setBackgroundColor(Color.rgb(13,29,19)); info.setPadding(dp(12),dp(12),dp(12),dp(12));
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1,-2); ip.setMargins(0,dp(12),0,dp(10)); root.addView(info, ip);

        TextView h = tv("CANAIS ENCONTRADOS", 16, green, true); root.addView(h);
        ScrollView sv = new ScrollView(this); result = tv("Nenhum canal analisado ainda.", 14, Color.WHITE, false); result.setPadding(0,dp(8),0,dp(20)); sv.addView(result); root.addView(sv, new LinearLayout.LayoutParams(-1,0,1));

        analyze.setOnClickListener(v -> analyzeText(input.getText().toString()));
        open.setOnClickListener(v -> pickFile());
        load.setOnClickListener(v -> loadUrl());
        setContentView(root);
    }

    private void pickFile(){
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("*/*"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,PICK_M3U);
    }
    @Override protected void onActivityResult(int r,int c,Intent d){ super.onActivityResult(r,c,d); if(r==PICK_M3U && c==RESULT_OK && d!=null){ try{ String s=readAll(getContentResolver().openInputStream(d.getData())); input.setText(s); analyzeText(s);}catch(Exception e){toast("Erro ao abrir M3U: "+e.getMessage());}} }

    private void loadUrl(){
        String u=input.getText().toString().trim();
        if(!u.startsWith("http://") && !u.startsWith("https://")){ toast("Cole uma URL http/https para carregar."); return; }
        result.setText("Carregando sua fonte...");
        new Thread(() -> { try {
            HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection(); c.setConnectTimeout(12000); c.setReadTimeout(20000); c.setRequestProperty("User-Agent","DubaiBuscarCanais/1.0");
            String s=readAll(c.getInputStream()); runOnUiThread(() -> { input.setText(s); analyzeTextWithSource(s,u); });
        } catch(Exception e){ runOnUiThread(() -> {result.setText("Falha ao carregar: "+e.getMessage()); analyzeText(u);}); } }).start();
    }

    private String readAll(InputStream in) throws Exception { if(in==null)return ""; BufferedReader br=new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8)); StringBuilder sb=new StringBuilder(); String l; while((l=br.readLine())!=null){sb.append(l).append('\n'); if(sb.length()>8_000_000)break;} br.close(); return sb.toString(); }
    private void analyzeText(String text){ analyzeTextWithSource(text,text); }
    private void analyzeTextWithSource(String text,String source){
        String dns="—", user="—", pass="—";
        try{
            Matcher m=Pattern.compile("https?://[^\\s]+",Pattern.CASE_INSENSITIVE).matcher(source); String url=m.find()?m.group():source.trim();
            if(url.startsWith("http://")||url.startsWith("https://")){
                URL u=new URL(url); dns=u.getProtocol()+"://"+u.getHost()+(u.getPort()>0?":"+u.getPort():"");
                String q=u.getQuery(); if(q!=null){ for(String p:q.split("&")){ String[] kv=p.split("=",2); if(kv.length==2){String k=kv[0].toLowerCase(); String v=URLDecoder.decode(kv[1],"UTF-8"); if(k.equals("username")||k.equals("user"))user=v; if(k.equals("password")||k.equals("pass"))pass=v; } } }
                String path=u.getPath(); Matcher xp=Pattern.compile("/(?:live|movie|series)/([^/]+)/([^/]+)/").matcher(path); if(xp.find()){ user=decode(xp.group(1)); pass=decode(xp.group(2)); }
            }
        }catch(Exception ignored){}
        info.setText("DNS: "+dns+"\nUsuário: "+user+"\nSenha: "+pass);

        StringBuilder out=new StringBuilder(); String pending=null; int count=0;
        String[] lines=text.split("\\r?\\n");
        for(String l:lines){ l=l.trim(); if(l.startsWith("#EXTINF")){ int comma=l.lastIndexOf(','); pending=comma>=0?l.substring(comma+1).trim():"Canal"; }
            else if(pending!=null && (l.startsWith("http://")||l.startsWith("https://")||l.startsWith("rtmp://")||l.startsWith("rtsp://"))){ count++; out.append(count).append(". ").append(pending).append("\n").append(l).append("\n\n"); pending=null; if(count>=300)break; }
        }
        if(count==0){ Matcher urls=Pattern.compile("https?://[^\\s]+",Pattern.CASE_INSENSITIVE).matcher(text); while(urls.find() && count<100){count++; out.append(count).append(". ").append(urls.group()).append("\n\n");} }
        result.setText(count==0?"Nenhum canal/URL encontrado. Cole uma M3U completa ou carregue sua própria URL.":("Total listado: "+count+"\n\n"+out));
    }
    private String decode(String s){ try{return URLDecoder.decode(s,"UTF-8");}catch(Exception e){return s;} }
    private TextView tv(String s,int sp,int color,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color); if(bold)t.setTypeface(null,1); return t; }
    private Button btn(String s){ Button b=new Button(this); b.setText(s); b.setTextColor(Color.BLACK); b.setBackgroundColor(green); b.setTextSize(11); return b; }
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);} private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
