GreenPlay Android 5.24 - catálogo completo/provedores
Data: 2026-09-20

- Mostra conexões usadas / total do fornecedor quando o painel disponibiliza os dados.
- Não trata snapshot inicial parcial como catálogo completo.
- Ao abrir Filmes/Séries busca categorias faltantes em vez de usar 0/contagem parcial como definitivo.
- Mantém fallback do bootstrap para fontes Xtream grandes e M3U.
- Evita retorno indevido ao início ao entrar em Séries por causa de snapshot parcial.
