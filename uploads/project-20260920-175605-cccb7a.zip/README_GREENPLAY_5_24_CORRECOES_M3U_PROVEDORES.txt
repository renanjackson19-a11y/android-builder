GREENPLAY APP 5.24 — CORREÇÕES M3U / PROVEDORES / SÉRIES

Correções desta entrega:
- Provedor com catálogo ainda não contado não é mais tratado como 0 filmes/0 séries.
- Ao conectar uma fonte M3U nova, o app solicita Filmes e Séries mesmo antes das contagens ficarem prontas.
- Contagens antigas zeradas em cache não bloqueiam a carga de um provedor novo.
- A troca de provedor preserva provider_id nas chamadas e força o snapshot correto do servidor selecionado.
- Timeouts de bootstrap e enriquecimento/detalhes ampliados para fontes M3U grandes.
- Mantidas as correções da 5.24 para acesso expirado em Séries.

Esta base continua versionName 5.24 / versionCode 52400.
