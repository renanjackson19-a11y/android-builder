package com.ativacao.app;

public class Config {
    public static final String GERADOR_BASE_URL = "https://geradorconfig.clickaqui.site";
    public static final String GERADOR_API_ATIVAR = GERADOR_BASE_URL + "/api/ativar-app.php";
    public static final String GERADOR_API_VISUAL = GERADOR_BASE_URL + "/api/app-visual.php";

    public static final String BASE_URL = "https://unitvativador.br232.shop";
    public static final String[] BASE_URLS = new String[] {
            "https://unitvativador.br232.shop",
            "https://painel.br232uni.shop",
            "https://painel.br232ativa.shop"
    };
    public static final String API_ATIVAR = BASE_URL + "/api/ativar.php";
    public static final String API_APP_CONFIG = BASE_URL + "/api/app_config.php";
    public static final String API_SUPORTE = BASE_URL + "/api/suporte_app.php";
    public static final String PASTA_ALTERNATIVA = "Android/data/com.ativacao.app/files";
    public static final String NOME_CONFIG_FINAL = ".config";
    public static final String NOME_PROPERTIES_FINAL = ".properties";
    public static final String NOME_APK_FINAL = "unitvfree.apk";
}
