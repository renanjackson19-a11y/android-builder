package com.dubai.buscarcanais;

import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.VpnService;
import android.os.*;
import android.text.TextUtils;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private static final String PREFS="dubai_buscar_canais", KEY_TARGETS="targets";
    private static final int VPN_REQ=700;
    private final int bg=Color.rgb(8,10,14), panel=Color.rgb(15,17,23), green=Color.rgb(35,231,101), white=Color.rgb(245,245,245), muted=Color.rgb(180,183,188);
    private LinearLayout statusPage, connPage;
    private Button statusTab, connTab, startStop;
    private TextView stateCircle, selectedText, sourceText, logText;
    private final Set<String> selected = new LinkedHashSet<>();
    private final ArrayList<String> logs = new ArrayList<>();
    private boolean running=false;
    private BroadcastReceiver receiver;

    @Override protected void onCreate(Bundle b){ super.onCreate(b); load(); build(); register(); }
    @Override protected void onDestroy(){ try{unregisterReceiver(receiver);}catch(Exception ignored){} super.onDestroy(); }

    private void build(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(bg); root.setPadding(0,dp(8),0,0);
        root.addView(toolbar()); root.addView(tabs());
        statusPage=status(); connPage=connections();
        root.addView(statusPage,new LinearLayout.LayoutParams(-1,0,1)); root.addView(connPage,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root); showStatus(); refresh();
    }
    private View toolbar(){ LinearLayout r=row();r.setPadding(dp(18),dp(12),dp(18),dp(12)); TextView m=t("☰",28,white,true),title=t("Dubai Buscar Canais",22,white,true),gear=t("⚙",24,white,false),more=t("⋮",28,white,false); title.setPadding(dp(16),0,0,0); LinearLayout l=row();l.addView(m);l.addView(title);r.addView(l,new LinearLayout.LayoutParams(0,-2,1));r.addView(gear);more.setPadding(dp(22),0,0,0);r.addView(more);return r; }
    private View tabs(){ LinearLayout r=row(); statusTab=button("STATUS"); connTab=button("CONEXÕES"); statusTab.setOnClickListener(v->showStatus());connTab.setOnClickListener(v->showConn()); r.addView(statusTab,new LinearLayout.LayoutParams(0,dp(58),1));r.addView(connTab,new LinearLayout.LayoutParams(0,dp(58),1));return r; }
    private LinearLayout status(){ ScrollView s=new ScrollView(this);LinearLayout c=col();c.setPadding(dp(18),dp(20),dp(18),dp(20)); LinearLayout cw=col();cw.setGravity(Gravity.CENTER_HORIZONTAL); stateCircle=t("Pronto",34,white,false);stateCircle.setGravity(Gravity.CENTER);stateCircle.setBackground(circle(false));cw.addView(stateCircle,new LinearLayout.LayoutParams(dp(210),dp(210)));c.addView(cw);c.addView(space(28));
        c.addView(title("Aplicativos de destino"));c.addView(sub("Escolha o aplicativo de TV/IPTV que você quer analisar."));LinearLayout card=card();card.setOrientation(LinearLayout.VERTICAL);selectedText=t("Nenhum selecionado",16,white,true);Button pick=action("SELECIONAR APP DE TV/IPTV");pick.setOnClickListener(v->pickApps());card.addView(selectedText);card.addView(space(10));card.addView(pick);c.addView(card);c.addView(space(18));
        startStop=action("INICIAR CAPTURA");startStop.setOnClickListener(v->toggle());c.addView(startStop);c.addView(space(12));c.addView(sub("Ao iniciar, o Android mostrará a permissão de VPN. A captura fica limitada aos apps escolhidos. HTTP visível pode mostrar a URL completa; HTTPS mostra apenas o domínio/host."));s.addView(c);LinearLayout h=col();h.addView(s,new LinearLayout.LayoutParams(-1,-1));return h; }
    private LinearLayout connections(){ ScrollView s=new ScrollView(this);LinearLayout c=col();c.setPadding(dp(18),dp(18),dp(18),dp(18));c.addView(title("Fonte detectada"));LinearLayout src=card();sourceText=t("DNS: —\nUsuário: —\nSenha: —",18,white,false);src.addView(sourceText);c.addView(src);c.addView(space(18));c.addView(title("Conexões capturadas"));c.addView(sub("Domínios DNS e URLs HTTP visíveis aparecem aqui em tempo real."));LinearLayout l=card();logText=t("Nenhuma conexão ainda.",15,white,false);l.addView(logText);c.addView(l);s.addView(c);LinearLayout h=col();h.addView(s,new LinearLayout.LayoutParams(-1,-1));return h; }

    private void toggle(){ if(!running){ if(selected.isEmpty()){Toast.makeText(this,"Selecione primeiro seu aplicativo de TV/IPTV",Toast.LENGTH_LONG).show();pickApps();return;} Intent prep=VpnService.prepare(this); if(prep!=null) startActivityForResult(prep,VPN_REQ); else startCapture(); } else stopCapture(); }
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==VPN_REQ&&c==RESULT_OK)startCapture();}
    private void startCapture(){ getSharedPreferences(PREFS,MODE_PRIVATE).edit().putStringSet(KEY_TARGETS,new LinkedHashSet<>(selected)).apply(); logs.clear(); addLog(time()+"  Iniciando captura..."); Intent i=new Intent(this,CaptureVpnService.class); if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);running=true;showConn();refresh(); }
    private void stopCapture(){ Intent i=new Intent(this,CaptureVpnService.class); stopService(i); running=false;refresh(); }

    private void pickApps(){
        PackageManager pm=getPackageManager();List<ApplicationInfo> all=pm.getInstalledApplications(0);ArrayList<ApplicationInfo> apps=new ArrayList<>();
        String[] keys={"tv","iptv","ott","player","unitv","green play","dubai","yellow","smarters","xciptv","ibo","flix","stb","m3u","vod","stream","canais"};
        for(ApplicationInfo a:all){ if(a.packageName.equals(getPackageName()))continue; String label=String.valueOf(pm.getApplicationLabel(a)).toLowerCase(Locale.US);String pkg=a.packageName.toLowerCase(Locale.US);boolean likely=false;for(String k:keys)if(label.contains(k)||pkg.contains(k)){likely=true;break;} if(likely)apps.add(a); }
        apps.sort(Comparator.comparing(a->String.valueOf(pm.getApplicationLabel(a)),String.CASE_INSENSITIVE_ORDER));
        if(apps.isEmpty()){Toast.makeText(this,"Nenhum app de TV/IPTV foi identificado automaticamente.",Toast.LENGTH_LONG).show();return;}
        String[] names=new String[apps.size()];boolean[] checked=new boolean[apps.size()];for(int i=0;i<apps.size();i++){names[i]=pm.getApplicationLabel(apps.get(i))+"\n"+apps.get(i).packageName;checked[i]=selected.contains(apps.get(i).packageName);} 
        new AlertDialog.Builder(this).setTitle("Apps de TV/IPTV").setMultiChoiceItems(names,checked,(d,w,is)->{String p=apps.get(w).packageName;if(is)selected.add(p);else selected.remove(p);}).setPositiveButton("SALVAR",(d,w)->{save();refresh();}).setNegativeButton("CANCELAR",null).show();
    }

    private void register(){ receiver=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent i){String line=i.getStringExtra(CaptureVpnService.EXTRA_LOG);if(line==null)return; if(line.startsWith("FONTE|")) showSource(line); else addLog(line); if("Captura parada".equals(line)){running=false;refresh();}}}; IntentFilter f=new IntentFilter(CaptureVpnService.ACTION_LOG); if(Build.VERSION.SDK_INT>=33)registerReceiver(receiver,f,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(receiver,f); }
    private void showSource(String line){String dns="—",u="—",p="—";for(String x:line.split("\\|")){if(x.startsWith("DNS="))dns=x.substring(4);else if(x.startsWith("USUARIO="))u=x.substring(8);else if(x.startsWith("SENHA="))p=x.substring(6);}sourceText.setText("DNS: "+dns+"\nUsuário: "+u+"\nSenha: "+p);addLog("Fonte Xtream/M3U detectada");}
    private void addLog(String x){logs.add(0,"• "+x);while(logs.size()>120)logs.remove(logs.size()-1);if(logText!=null)logText.setText(TextUtils.join("\n",logs));}
    private String time(){return new SimpleDateFormat("HH:mm:ss",Locale.getDefault()).format(new Date());}
    private void load(){selected.addAll(getSharedPreferences(PREFS,MODE_PRIVATE).getStringSet(KEY_TARGETS,Collections.emptySet()));}
    private void save(){getSharedPreferences(PREFS,MODE_PRIVATE).edit().putStringSet(KEY_TARGETS,new LinkedHashSet<>(selected)).apply();}
    private void refresh(){ if(selectedText!=null)selectedText.setText(selected.isEmpty()?"Nenhum aplicativo selecionado":selected.size()+" aplicativo(s) selecionado(s)"); if(stateCircle!=null){stateCircle.setText(running?"Capturando":"Pronto");stateCircle.setBackground(circle(running));} if(startStop!=null)startStop.setText(running?"PARAR CAPTURA":"INICIAR CAPTURA"); }
    private void showStatus(){statusPage.setVisibility(View.VISIBLE);connPage.setVisibility(View.GONE);styleTab(statusTab,true);styleTab(connTab,false);} private void showConn(){statusPage.setVisibility(View.GONE);connPage.setVisibility(View.VISIBLE);styleTab(statusTab,false);styleTab(connTab,true);} private void styleTab(Button b,boolean on){b.setTextColor(on?white:muted);GradientDrawable g=new GradientDrawable();g.setColor(Color.TRANSPARENT);if(on)g.setStroke(dp(2),green);b.setBackground(g);} 
    private LinearLayout row(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.HORIZONTAL);x.setGravity(Gravity.CENTER_VERTICAL);return x;} private LinearLayout col(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);return x;} private TextView t(String s,int z,int c,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);if(bold)v.setTypeface(null,1);return v;} private TextView title(String s){TextView v=t(s,20,white,true);v.setPadding(0,dp(5),0,dp(4));return v;}private TextView sub(String s){TextView v=t(s,15,muted,false);v.setPadding(0,0,0,dp(10));return v;}private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextSize(16);b.setAllCaps(false);return b;}private Button action(String s){Button b=button(s);b.setTextColor(Color.rgb(0,35,12));GradientDrawable g=new GradientDrawable();g.setColor(green);g.setCornerRadius(dp(10));b.setBackground(g);b.setPadding(dp(10),dp(15),dp(10),dp(15));return b;}private LinearLayout card(){LinearLayout x=col();x.setPadding(dp(18),dp(18),dp(18),dp(18));GradientDrawable g=new GradientDrawable();g.setColor(panel);g.setCornerRadius(dp(14));x.setBackground(g);return x;}private View space(int h){View v=new View(this);v.setLayoutParams(new LinearLayout.LayoutParams(1,dp(h)));return v;}private GradientDrawable circle(boolean on){GradientDrawable g=new GradientDrawable();g.setShape(GradientDrawable.OVAL);g.setColor(Color.TRANSPARENT);g.setStroke(dp(4),on?green:Color.rgb(120,60,150));return g;}private int dp(int v){return(int)(v*getResources().getDisplayMetrics().density+.5f);} 
}
