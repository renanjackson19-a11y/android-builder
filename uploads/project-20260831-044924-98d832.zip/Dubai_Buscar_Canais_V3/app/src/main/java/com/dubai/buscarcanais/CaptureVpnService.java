package com.dubai.buscarcanais;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import java.io.*;
import java.net.*;
import java.nio.ByteBuffer;
import java.util.*;
import java.util.concurrent.*;

public class CaptureVpnService extends VpnService {
    public static final String ACTION_LOG = "com.dubai.buscarcanais.LOG";
    public static final String EXTRA_LOG = "line";
    public static final String ACTION_STOP = "com.dubai.buscarcanais.STOP";
    private static final String CH = "capture";
    private ParcelFileDescriptor tun;
    private volatile boolean running;
    private ExecutorService pool;
    private ServerSocket proxyServer;
    private final int proxyPort = 8899;

    @Override public void onCreate() {
        super.onCreate();
        pool = Executors.newCachedThreadPool();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if (!running) startCapture();
        return START_STICKY;
    }

    private void startCapture() {
        try {
            createChannel();
            startForeground(44, notification("Captura ativa"));
            startHttpProxy();

            Builder b = new Builder()
                    .setSession("Dubai Buscar Canais")
                    .setMtu(1500)
                    .addAddress("10.88.0.2", 32)
                    .addDnsServer("10.88.0.1")
                    .addRoute("10.88.0.1", 32);

            if (Build.VERSION.SDK_INT >= 29) {
                try { b.setHttpProxy(ProxyInfo.buildDirectProxy("127.0.0.1", proxyPort)); } catch (Throwable ignored) {}
            }

            SharedPreferences p = getSharedPreferences("dubai_buscar_canais", MODE_PRIVATE);
            Set<String> targets = p.getStringSet("targets", Collections.emptySet());
            if (!targets.isEmpty()) {
                for (String pkg : targets) {
                    try { b.addAllowedApplication(pkg); } catch (Exception ignored) {}
                }
            }

            tun = b.establish();
            if (tun == null) throw new IOException("VPN não foi criada");
            running = true;
            log("VPN ativa • captura DNS iniciada");
            log("Proxy HTTP local ativo na porta " + proxyPort);
            if (targets.isEmpty()) log("Nenhum app selecionado. Pare e selecione um app de TV/IPTV.");
            pool.execute(this::dnsLoop);
        } catch (Exception e) {
            log("ERRO: " + e.getMessage());
            stopSelf();
        }
    }

    private void dnsLoop() {
        try (FileInputStream in = new FileInputStream(tun.getFileDescriptor());
             FileOutputStream out = new FileOutputStream(tun.getFileDescriptor())) {
            byte[] packet = new byte[32767];
            while (running) {
                int n = in.read(packet);
                if (n <= 0) continue;
                byte[] copy = Arrays.copyOf(packet, n);
                handleDns(copy, out);
            }
        } catch (Exception e) {
            if (running) log("Captura DNS encerrada: " + e.getMessage());
        }
    }

    private void handleDns(byte[] ip, FileOutputStream out) {
        try {
            if (ip.length < 28) return;
            int ver = (ip[0] >> 4) & 0xF;
            if (ver != 4) return;
            int ihl = (ip[0] & 0xF) * 4;
            if (ip.length < ihl + 8) return;
            int proto = ip[9] & 0xFF;
            if (proto != 17) return;
            int dstPort = ((ip[ihl+2] & 0xff) << 8) | (ip[ihl+3] & 0xff);
            if (dstPort != 53) return;
            int udpLen = ((ip[ihl+4] & 0xff) << 8) | (ip[ihl+5] & 0xff);
            int dnsOff = ihl + 8;
            int dnsLen = Math.min(udpLen - 8, ip.length - dnsOff);
            if (dnsLen < 12) return;
            byte[] query = Arrays.copyOfRange(ip, dnsOff, dnsOff + dnsLen);
            String domain = parseDnsName(query, 12);
            if (domain != null && !domain.isEmpty()) log("DNS  " + domain);

            byte[] response = forwardDns(query);
            if (response == null) return;
            byte[] reply = buildUdpReply(ip, ihl, response);
            synchronized (out) { out.write(reply); }
        } catch (Exception ignored) {}
    }

    private byte[] forwardDns(byte[] query) {
        DatagramSocket s = null;
        try {
            s = new DatagramSocket();
            protect(s);
            s.setSoTimeout(3500);
            DatagramPacket q = new DatagramPacket(query, query.length, InetAddress.getByName("1.1.1.1"), 53);
            s.send(q);
            byte[] buf = new byte[4096];
            DatagramPacket r = new DatagramPacket(buf, buf.length);
            s.receive(r);
            return Arrays.copyOf(r.getData(), r.getLength());
        } catch (Exception e) { return null; }
        finally { if (s != null) s.close(); }
    }

    private static String parseDnsName(byte[] d, int pos) {
        try {
            StringBuilder sb = new StringBuilder();
            int guard = 0;
            while (pos < d.length && guard++ < 50) {
                int len = d[pos++] & 0xff;
                if (len == 0) break;
                if ((len & 0xC0) == 0xC0) break;
                if (pos + len > d.length) return null;
                if (sb.length() > 0) sb.append('.');
                for (int i=0;i<len;i++) {
                    int c = d[pos++] & 0xff;
                    if (c >= 32 && c <= 126) sb.append((char)c);
                }
            }
            return sb.toString();
        } catch (Exception e) { return null; }
    }

    private static byte[] buildUdpReply(byte[] req, int ihl, byte[] dns) {
        int total = ihl + 8 + dns.length;
        byte[] out = new byte[total];
        System.arraycopy(req, 0, out, 0, ihl + 8);
        out[2] = (byte)(total >> 8); out[3] = (byte)total;
        for (int i=0;i<4;i++) { byte t=out[12+i]; out[12+i]=out[16+i]; out[16+i]=t; }
        int sp = ((req[ihl]&0xff)<<8)|(req[ihl+1]&0xff);
        out[ihl] = 0; out[ihl+1] = 53;
        out[ihl+2] = (byte)(sp>>8); out[ihl+3] = (byte)sp;
        int udpLen = 8 + dns.length;
        out[ihl+4]=(byte)(udpLen>>8); out[ihl+5]=(byte)udpLen;
        out[ihl+6]=0; out[ihl+7]=0;
        System.arraycopy(dns, 0, out, ihl+8, dns.length);
        out[10]=0; out[11]=0;
        int ipCsum = checksum(out, 0, ihl);
        out[10]=(byte)(ipCsum>>8); out[11]=(byte)ipCsum;
        int udpCsum = udpChecksum(out, ihl, udpLen);
        out[ihl+6]=(byte)(udpCsum>>8); out[ihl+7]=(byte)udpCsum;
        return out;
    }

    private static int checksum(byte[] b, int off, int len) {
        long sum=0; int i=off;
        while (len>1) { sum += ((b[i]&0xff)<<8)|(b[i+1]&0xff); i+=2; len-=2; }
        if (len>0) sum += (b[i]&0xff)<<8;
        while ((sum>>16)!=0) sum=(sum&0xffff)+(sum>>16);
        return (int)(~sum)&0xffff;
    }

    private static int udpChecksum(byte[] ip, int udpOff, int udpLen) {
        long sum=0;
        for(int i=12;i<20;i+=2) sum += ((ip[i]&0xff)<<8)|(ip[i+1]&0xff);
        sum += 17; sum += udpLen;
        int i=udpOff, len=udpLen;
        while(len>1){ sum += ((ip[i]&0xff)<<8)|(ip[i+1]&0xff); i+=2; len-=2; }
        if(len>0) sum += (ip[i]&0xff)<<8;
        while((sum>>16)!=0) sum=(sum&0xffff)+(sum>>16);
        int c=(int)(~sum)&0xffff; return c==0?0xffff:c;
    }

    private void startHttpProxy() throws IOException {
        proxyServer = new ServerSocket();
        proxyServer.setReuseAddress(true);
        proxyServer.bind(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), proxyPort));
        pool.execute(() -> {
            while (!proxyServer.isClosed()) {
                try { Socket c = proxyServer.accept(); pool.execute(() -> handleProxy(c)); }
                catch (IOException e) { break; }
            }
        });
    }

    private void handleProxy(Socket client) {
        try (Socket c = client) {
            c.setSoTimeout(15000);
            InputStream in = c.getInputStream();
            OutputStream cout = c.getOutputStream();
            ByteArrayOutputStream headerBuf = new ByteArrayOutputStream();
            int state=0, ch;
            while ((ch=in.read())!=-1 && headerBuf.size()<65536) {
                headerBuf.write(ch);
                if (state==0 && ch=='\r') state=1;
                else if (state==1 && ch=='\n') state=2;
                else if (state==2 && ch=='\r') state=3;
                else if (state==3 && ch=='\n') break;
                else state=0;
            }
            String headers = headerBuf.toString("ISO-8859-1");
            String[] lines = headers.split("\\r?\\n");
            if (lines.length==0) return;
            String[] first = lines[0].split(" ");
            if (first.length<2) return;
            String method=first[0], target=first[1];
            if ("CONNECT".equalsIgnoreCase(method)) {
                String[] hp=target.split(":",2); String host=hp[0]; int port=hp.length>1?Integer.parseInt(hp[1]):443;
                log("HTTPS  " + host + ":" + port);
                Socket remote = protectedSocket(host, port);
                cout.write("HTTP/1.1 200 Connection Established\r\n\r\n".getBytes("ISO-8859-1")); cout.flush();
                pipeBoth(c, remote);
                return;
            }

            String host=null; int port=80; String path=target; String absoluteUrl=null;
            if (target.startsWith("http://")) {
                URL u=new URL(target); host=u.getHost(); port=u.getPort()>0?u.getPort():80; path=u.getFile(); absoluteUrl=target;
            } else {
                for (String line:lines) if (line.toLowerCase(Locale.US).startsWith("host:")) {
                    String h=line.substring(5).trim(); String[] hp=h.split(":",2); host=hp[0]; if(hp.length>1) port=Integer.parseInt(hp[1]);
                }
                if(host!=null) absoluteUrl="http://"+host+(port==80?"":":"+port)+target;
            }
            if(host==null) return;
            log("HTTP  " + absoluteUrl);
            detectXtream(absoluteUrl);
            Socket remote=protectedSocket(host,port);
            OutputStream rout=remote.getOutputStream();
            StringBuilder rebuilt=new StringBuilder();
            rebuilt.append(method).append(' ').append(path.isEmpty()?"/":path).append(" HTTP/1.1\r\n");
            for(int i=1;i<lines.length;i++) {
                String line=lines[i];
                if(line.isEmpty()) continue;
                String lower=line.toLowerCase(Locale.US);
                if(lower.startsWith("proxy-connection:")) continue;
                rebuilt.append(line).append("\r\n");
            }
            rebuilt.append("\r\n");
            rout.write(rebuilt.toString().getBytes("ISO-8859-1")); rout.flush();
            pipeBoth(c,remote);
        } catch(Exception ignored) {}
    }

    private Socket protectedSocket(String host,int port) throws IOException {
        Socket s=new Socket(); protect(s); s.connect(new InetSocketAddress(host,port),10000); return s;
    }

    private void pipeBoth(Socket a, Socket b) throws Exception {
        CountDownLatch latch=new CountDownLatch(2);
        pool.execute(() -> { copy(a,b); latch.countDown(); });
        pool.execute(() -> { copy(b,a); latch.countDown(); });
        latch.await();
        try{b.close();}catch(Exception ignored){}
    }
    private static void copy(Socket from, Socket to) {
        try { InputStream in=from.getInputStream(); OutputStream out=to.getOutputStream(); byte[] buf=new byte[32768]; int n; while((n=in.read(buf))!=-1){out.write(buf,0,n);out.flush();} } catch(Exception ignored){}
    }

    private void detectXtream(String url) {
        try {
            URI u=URI.create(url); String q=u.getRawQuery(); Map<String,String> m=new HashMap<>();
            if(q!=null) for(String p:q.split("&")){String[]kv=p.split("=",2);if(kv.length==2)m.put(URLDecoder.decode(kv[0],"UTF-8").toLowerCase(Locale.US),URLDecoder.decode(kv[1],"UTF-8"));}
            String user=m.get("username"), pass=m.get("password");
            String[] seg=u.getPath().split("/");
            if((user==null||pass==null) && seg.length>=4) {
                int idx=-1; for(int i=0;i<seg.length;i++) if("live".equals(seg[i])||"movie".equals(seg[i])||"series".equals(seg[i])) {idx=i;break;}
                if(idx>=0 && idx+2<seg.length){user=seg[idx+1];pass=seg[idx+2];}
            }
            if(user!=null && pass!=null) {
                int port=u.getPort(); String dns=u.getScheme()+"://"+u.getHost()+(port>0?":"+port:"");
                log("FONTE|DNS="+dns+"|USUARIO="+user+"|SENHA="+pass);
            }
        } catch(Exception ignored){}
    }

    private void log(String s) {
        Intent i=new Intent(ACTION_LOG); i.setPackage(getPackageName()); i.putExtra(EXTRA_LOG,s); sendBroadcast(i);
    }

    private void createChannel() {
        if(Build.VERSION.SDK_INT>=26){ NotificationManager nm=getSystemService(NotificationManager.class); nm.createNotificationChannel(new NotificationChannel(CH,"Captura de rede",NotificationManager.IMPORTANCE_LOW)); }
    }
    private Notification notification(String text) {
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CH):new Notification.Builder(this);
        return b.setContentTitle("Dubai Buscar Canais").setContentText(text).setSmallIcon(android.R.drawable.stat_sys_download_done).setOngoing(true).build();
    }

    @Override public void onDestroy() {
        running=false;
        try{ if(proxyServer!=null) proxyServer.close(); }catch(Exception ignored){}
        try{ if(tun!=null) tun.close(); }catch(Exception ignored){}
        if(pool!=null) pool.shutdownNow();
        log("Captura parada");
        super.onDestroy();
    }
}
