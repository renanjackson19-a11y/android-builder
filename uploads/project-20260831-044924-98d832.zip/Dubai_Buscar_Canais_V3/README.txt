DUBAI BUSCAR CANAIS V3 — CAPTURA REAL (BASE)

O que mudou em relação à V2:
- A V2 apenas simulava o estado da captura. A V3 usa Android VpnService de verdade.
- O usuário escolhe os apps de TV/IPTV.
- O Android pede a permissão oficial de VPN ao iniciar.
- A VPN intercepta consultas DNS dos apps escolhidos e mostra os domínios em tempo real.
- Um proxy HTTP local tenta registrar URLs HTTP visíveis.
- Se a URL HTTP tiver formato Xtream/M3U, a tela separa DNS, usuário e senha.
- HTTPS continua criptografado: a V3 NÃO quebra TLS, pinning ou certificados; em HTTPS mostra só host/domínio quando o app respeita o proxy do sistema.

IMPORTANTE:
1) Selecione primeiro o aplicativo de TV/IPTV.
2) Toque em INICIAR CAPTURA e aceite a permissão VPN do Android.
3) Abra o app de TV e reproduza um canal.
4) Volte ao Dubai Buscar Canais e veja CONEXÕES.

Compatibilidade:
- Android 6+ para VPN/DNS.
- Proxy HTTP anunciado ao app requer Android 10+ e depende do app respeitar o proxy do sistema.
- Alguns apps usam DNS próprio/DoH, QUIC ou ignoram proxy; nesses casos só parte dos dados pode aparecer.
- Este projeto não instala certificado CA e não descriptografa HTTPS.

Projeto de análise local para fontes e aplicativos que você administra/tem autorização para testar.
