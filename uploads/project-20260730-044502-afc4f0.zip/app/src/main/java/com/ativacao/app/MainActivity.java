package com.ativacao.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.text.Editable;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private EditText edtLicenca;
    private TextView txtStatus;
    private ProgressBar progress;
    private Button btnAtivar;
    private Button btnApagarConfig;
    private RadioGroup grupoTipoAparelho;
    private String tipoAparelhoEscolhido = "";
    private volatile String avisoSalvamentoConfig = "";
    private boolean aguardandoRetornoPermissao = false;
    private volatile boolean verificandoRoot = false;
    private volatile boolean removendoRoot = false;
    private volatile boolean fluxoInicialEmAndamento = false;
    private String nomeOpcaoAndroid = "TV Android / Celular";
    private String nomeOpcaoTvBox = "TV Box / Fire Stick / MXQ";

    private int COR_PRINCIPAL = Color.rgb(235, 30, 45);
    private int COR_PRINCIPAL_ESCURO = Color.rgb(135, 12, 22);
    private final int FUNDO = Color.rgb(12, 10, 16);
    private final int TEXTO_CLARO = Color.rgb(245, 246, 250);
    private final int TEXTO_SUAVE = Color.rgb(190, 190, 202);

    private String appTitulo = "Ativador UnitvFree";
    private String appSubtitulo = "Digite sua licença para ativar seu acesso.";
    private String textoPermissao = "Antes de usar sua licença, toque em LIBERAR PERMISSÕES. O ativador vai abrir a tela correta do aparelho; marque Permitir e volte para o app.";
    private String textoBotaoPermissao = "LIBERAR PERMISSÕES";
    private String textoBotaoAtivar = "ATIVAR LICENÇA";
    private String msgPronto = "Pronto para ativar. A configuração será instalada automaticamente no aparelho.";
    private String logoUrl = "";
    private String fundoUrl = "";
    private String fotoPainelUrl = "";
    private String propagandaTexto = "";
    private String propagandaLink = "";
    private String propagandaBotao = "ACESSAR AGORA";

    private String suporteSessaoId = "";
    private String suporteCodigoAtual = "";
    private Handler suporteHandler = new Handler(Looper.getMainLooper());
    private boolean suporteAtivo = false;
    private volatile boolean ativacaoBloqueadaPorAviso = false;

    private static final String PREFS = "ativador_prefs";
    private static final String KEY_PERMISSOES_CONFIRMADAS = "permissoes_confirmadas";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        carregarConfigDoPainel();
        mostrarTelaCorreta();
        new Handler(Looper.getMainLooper()).postDelayed(this::verificarNotificacaoPainel, 1200);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (aguardandoRetornoPermissao) {
            aguardandoRetornoPermissao = false;
            verificarPermissoesEContinuar();
        } else {
            mostrarTelaCorreta();
        }
    }

    private void carregarConfigDoPainel() {
        new Thread(() -> {
            try {
                String json = httpGet(Config.API_APP_CONFIG);
                if (json == null || json.trim().isEmpty()) return;
                JSONObject obj = new JSONObject(json);
                if (!"ok".equalsIgnoreCase(obj.optString("status", "ok"))) return;
                appTitulo = obj.optString("titulo", appTitulo);
                appSubtitulo = obj.optString("subtitulo", appSubtitulo);
                textoPermissao = obj.optString("texto_permissao", textoPermissao);
                textoBotaoPermissao = obj.optString("botao_permissao", textoBotaoPermissao);
                textoBotaoAtivar = obj.optString("botao_ativar", textoBotaoAtivar);
                msgPronto = obj.optString("mensagem_pronto", msgPronto);
                logoUrl = normalizarUrl(obj.optString("logo_url", ""));
                fundoUrl = normalizarUrl(obj.optString("fundo_url", ""));
                propagandaTexto = obj.optString("propaganda_texto", propagandaTexto);
                propagandaLink = normalizarUrl(obj.optString("propaganda_link", propagandaLink));
                propagandaBotao = obj.optString("propaganda_botao", propagandaBotao);
                nomeOpcaoAndroid = obj.optString("nome_tv_android", obj.optString("opcao1_nome", obj.optString("opcao_1", obj.optString("opcao1", nomeOpcaoAndroid))));
                nomeOpcaoTvBox = obj.optString("nome_tv_box", obj.optString("opcao2_nome", obj.optString("opcao_2", obj.optString("opcao2", nomeOpcaoTvBox))));
                String cor = obj.optString("cor_principal", "").trim();
                if (cor.matches("#?[0-9A-Fa-f]{6}")) {
                    if (!cor.startsWith("#")) cor = "#" + cor;
                    COR_PRINCIPAL = Color.parseColor(cor);
                    COR_PRINCIPAL_ESCURO = escurecer(COR_PRINCIPAL);
                }
                carregarFotoDoGerador();
                runOnUiThread(this::mostrarTelaCorreta);
            } catch (Exception ignored) {
                carregarFotoDoGerador();
            }
        }).start();
    }

    private void carregarFotoDoGerador() {
        try {
            String visualJson = httpGet(Config.API_APP_VISUAL);
            if (visualJson == null || visualJson.trim().isEmpty()) return;
            JSONObject visual = new JSONObject(visualJson);
            if (!"ok".equalsIgnoreCase(visual.optString("status", "ok"))) return;
            fotoPainelUrl = normalizarUrl(visual.optString("foto_url", visual.optString("banner_url", "")));
        } catch (Exception ignored) {}
    }


    private void verificarNotificacaoPainel() {
        new Thread(() -> {
            try {
                String json = httpGet(Config.API_APP_NOTIFICATION + "?t=" + System.currentTimeMillis());
                if (json == null || json.trim().isEmpty()) return;
                JSONObject obj = new JSONObject(json);
                if (!obj.optBoolean("active", false)) {
                    ativacaoBloqueadaPorAviso = false;
                    return;
                }
                String id = obj.optString("id", "");
                boolean umaVez = obj.optBoolean("show_once", true);
                boolean bloquear = obj.optBoolean("block_activation", false);
                ativacaoBloqueadaPorAviso = bloquear;
                SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
                if (umaVez && id.equals(prefs.getString("ultimo_aviso_exibido", ""))) return;
                runOnUiThread(() -> mostrarNotificacaoDoPainel(obj, id, umaVez));
            } catch (Exception ignored) {}
        }).start();
    }

    private void mostrarNotificacaoDoPainel(JSONObject obj, String id, boolean umaVez) {
        String titulo = obj.optString("title", "Aviso");
        String mensagem = obj.optString("message", "");
        String textoBotao = obj.optString("button_text", "").trim();
        String link = obj.optString("button_link", "").trim();
        boolean bloquear = obj.optBoolean("block_activation", false);

        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle(titulo)
                .setMessage(mensagem)
                .setCancelable(!bloquear);
        if (!textoBotao.isEmpty() && !link.isEmpty()) {
            builder.setPositiveButton(textoBotao, (d, w) -> {
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(link))); }
                catch (Exception e) { Toast.makeText(this, "Não foi possível abrir o link.", Toast.LENGTH_LONG).show(); }
                if (umaVez) getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("ultimo_aviso_exibido", id).apply();
            });
            if (!bloquear) builder.setNegativeButton("ENTENDI", (d, w) -> {
                if (umaVez) getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("ultimo_aviso_exibido", id).apply();
            });
        } else {
            builder.setPositiveButton(bloquear ? "VERIFICAR NOVAMENTE" : "ENTENDI", (d, w) -> {
                if (umaVez && !bloquear) getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("ultimo_aviso_exibido", id).apply();
                if (bloquear) verificarNotificacaoPainel();
            });
        }
        builder.show();
    }

    private int escurecer(int cor) {
        int r = Math.max(0, (int)(Color.red(cor) * 0.55));
        int g = Math.max(0, (int)(Color.green(cor) * 0.55));
        int b = Math.max(0, (int)(Color.blue(cor) * 0.55));
        return Color.rgb(r, g, b);
    }

    private boolean isTV() {
        int mode = getResources().getConfiguration().uiMode & Configuration.UI_MODE_TYPE_MASK;
        return mode == Configuration.UI_MODE_TYPE_TELEVISION
                || mode == Configuration.UI_MODE_TYPE_APPLIANCE
                || !getPackageManager().hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN);
    }

    private void mostrarTelaCorreta() {
        // Ordem obrigatória: permissões primeiro, root depois e licença por último.
        if (!permissoesLiberadas() || !permissoesConfirmadas()) {
            verificandoRoot = false;
            montarTelaPermissoes();
            return;
        }
        iniciarVerificacaoRootAposPermissoes();
    }

    private void iniciarVerificacaoRootAposPermissoes() {
        if (!permissoesLiberadas() || !permissoesConfirmadas()) {
            montarTelaPermissoes();
            return;
        }
        verificarRootAntesDaLicenca();
    }

    private void verificarRootAntesDaLicenca() {
        if (verificandoRoot) return;
        verificandoRoot = true;
        montarTelaVerificandoRoot();
        new Thread(() -> {
            boolean root = detectarRoot();
            runOnUiThread(() -> {
                verificandoRoot = false;
                if (root) montarTelaRootDetectado();
                else montarTelaAtivacao();
            });
        }).start();
    }

    private void montarTelaVerificandoRoot() {
        ScrollView scroll = new ScrollView(this);
        configurarFundo(scroll);
        LinearLayout root = criarContainer(scroll);
        adicionarTopo(root);

        ProgressBar barra = new ProgressBar(this);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(isTV() ? 74 : 58), dp(isTV() ? 74 : 58));
        bp.gravity = Gravity.CENTER_HORIZONTAL;
        bp.topMargin = dp(24);
        root.addView(barra, bp);

        TextView titulo = new TextView(this);
        titulo.setText("PREPARANDO O APARELHO");
        titulo.setTextColor(TEXTO_CLARO);
        titulo.setTextSize(isTV() ? 25 : 20);
        titulo.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        titulo.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.topMargin = dp(18);
        root.addView(titulo, tp);

        TextView detalhe = new TextView(this);
        detalhe.setText("Validando a segurança do dispositivo. Aguarde um instante.");
        detalhe.setTextColor(TEXTO_SUAVE);
        detalhe.setTextSize(isTV() ? 18 : 15);
        detalhe.setGravity(Gravity.CENTER);
        detalhe.setPadding(dp(8), dp(14), dp(8), dp(18));
        root.addView(detalhe, new LinearLayout.LayoutParams(-1, -2));

        setContentView(scroll);
    }

    private boolean permissoesConfirmadas() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        return prefs.getBoolean(KEY_PERMISSOES_CONFIRMADAS, false);
    }

    private void confirmarPermissoes() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_PERMISSOES_CONFIRMADAS, true).apply();
    }

    private void configurarFundo(ScrollView scroll) {
        GradientDrawable fundo = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{escurecer(COR_PRINCIPAL), FUNDO, Color.rgb(18, 10, 14)});
        scroll.setBackground(fundo);
        if (!fundoUrl.isEmpty()) {
            new Thread(() -> {
                try {
                    Bitmap bmp = baixarBitmap(fundoUrl);
                    if (bmp != null) runOnUiThread(() -> {
                        BitmapDrawable bd = new BitmapDrawable(getResources(), bmp);
                        bd.setGravity(Gravity.CENTER);
                        scroll.setBackground(bd);
                    });
                } catch (Exception ignored) {}
            }).start();
        }
    }

    private LinearLayout criarContainer(ScrollView scroll) {
        configurarFundo(scroll);
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setGravity(Gravity.CENTER);
        outer.setMinimumHeight(getResources().getDisplayMetrics().heightPixels);
        outer.setPadding(dp(isTV() ? 40 : 18), dp(isTV() ? 32 : 38), dp(isTV() ? 40 : 18), dp(isTV() ? 32 : 38));
        scroll.addView(outer, new ScrollView.LayoutParams(-1, -1));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(isTV() ? 38 : 22), dp(isTV() ? 30 : 24), dp(isTV() ? 38 : 22), dp(24));
        root.setBackground(criarBorda(Color.argb(170, 10, 10, 16), Color.argb(120, 255, 255, 255), dp(22), dp(1)));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(isTV() ? dp(760) : -1, -2);
        rp.gravity = Gravity.CENTER_HORIZONTAL;
        outer.addView(root, rp);
        return root;
    }

    private void adicionarTopo(LinearLayout root) {
        ImageView logo = new ImageView(this);
        logo.setAdjustViewBounds(true);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams lpLogo = new LinearLayout.LayoutParams(dp(isTV()?150:110), dp(isTV()?90:70));
        lpLogo.gravity = Gravity.CENTER_HORIZONTAL;
        lpLogo.setMargins(0, 0, 0, dp(12));
        root.addView(logo, lpLogo);
        if (!logoUrl.isEmpty()) carregarImagem(logo, logoUrl); else logo.setVisibility(View.GONE);

        TextView badge = new TextView(this);
        badge.setText("DUBAI DIGITAL");
        badge.setTextColor(Color.WHITE);
        badge.setTextSize(isTV() ? 16 : 13);
        badge.setTypeface(Typeface.DEFAULT_BOLD);
        badge.setGravity(Gravity.CENTER);
        badge.setLetterSpacing(0.10f);
        badge.setPadding(dp(14), dp(8), dp(14), dp(8));
        badge.setBackground(criarBorda(Color.argb(70, 255, 40, 55), COR_PRINCIPAL, dp(26), dp(1)));
        LinearLayout.LayoutParams badgeParams = new LinearLayout.LayoutParams(-2, -2);
        badgeParams.gravity = Gravity.CENTER_HORIZONTAL;
        badgeParams.setMargins(0, 0, 0, dp(18));
        root.addView(badge, badgeParams);

        TextView titulo = new TextView(this);
        titulo.setText(appTitulo);
        titulo.setTextColor(TEXTO_CLARO);
        titulo.setTextSize(isTV() ? 42 : 32);
        titulo.setTypeface(Typeface.DEFAULT_BOLD);
        titulo.setGravity(Gravity.CENTER);
        titulo.setLineSpacing(0, 0.96f);
        root.addView(titulo, new LinearLayout.LayoutParams(-1, -2));

        TextView by = new TextView(this);
        by.setText("By Dubai Digital");
        by.setTextColor(COR_PRINCIPAL);
        by.setTextSize(isTV() ? 18 : 15);
        by.setTypeface(Typeface.DEFAULT_BOLD);
        by.setGravity(Gravity.CENTER);
        by.setPadding(0, dp(8), 0, dp(18));
        root.addView(by, new LinearLayout.LayoutParams(-1, -2));

        if (fotoPainelUrl != null && !fotoPainelUrl.trim().isEmpty()) {
            ImageView fotoPainel = new ImageView(this);
            fotoPainel.setAdjustViewBounds(false);
            fotoPainel.setScaleType(ImageView.ScaleType.CENTER_CROP);
            fotoPainel.setContentDescription("Imagem do ativador");
            fotoPainel.setBackground(criarBorda(Color.argb(45, 255, 255, 255), Color.argb(90, 255, 255, 255), dp(16), dp(1)));
            fotoPainel.setClipToOutline(Build.VERSION.SDK_INT >= 21);
            LinearLayout.LayoutParams fotoParams = new LinearLayout.LayoutParams(-1, dp(isTV() ? 220 : 150));
            fotoParams.setMargins(0, 0, 0, dp(18));
            root.addView(fotoPainel, fotoParams);
            carregarImagem(fotoPainel, fotoPainelUrl);
        }
    }

    private void adicionarPropaganda(LinearLayout root) {
        if ((propagandaTexto == null || propagandaTexto.trim().isEmpty()) && (propagandaLink == null || propagandaLink.trim().isEmpty())) return;

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(dp(16), dp(14), dp(16), dp(14));
        box.setBackground(criarBorda(Color.argb(90, 255, 255, 255), COR_PRINCIPAL, dp(16), dp(1)));

        TextView txt = new TextView(this);
        txt.setText(propagandaTexto == null || propagandaTexto.trim().isEmpty() ? "Acesse nossa propaganda" : propagandaTexto.trim());
        txt.setTextColor(Color.WHITE);
        txt.setTextSize(isTV() ? 18 : 15);
        txt.setTypeface(Typeface.DEFAULT_BOLD);
        txt.setGravity(Gravity.CENTER);
        txt.setPadding(0, 0, 0, dp(10));
        box.addView(txt, new LinearLayout.LayoutParams(-1, -2));

        if (propagandaLink != null && !propagandaLink.trim().isEmpty()) {
            Button btn = criarBotao(propagandaBotao == null || propagandaBotao.trim().isEmpty() ? "ACESSAR AGORA" : propagandaBotao.trim());
            btn.setTextSize(isTV() ? 17 : 14);
            box.addView(btn, new LinearLayout.LayoutParams(-1, dp(isTV() ? 58 : 48)));
            btn.setOnClickListener(v -> abrirPropaganda());
            box.setOnClickListener(v -> abrirPropaganda());
            box.setFocusable(true);
        }

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(18), 0, dp(6));
        root.addView(box, lp);
    }


    private void adicionarSuporteRemoto(LinearLayout root) {
        Button btn = criarBotao("RECEBER AJUDA REMOTA");
        btn.setTextSize(isTV() ? 17 : 14);
        btn.setBackground(criarBorda(Color.argb(90, 20, 20, 28), Color.argb(170,255,255,255), dp(16), dp(1)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(isTV() ? 58 : 50));
        lp.setMargins(0, dp(12), 0, 0);
        root.addView(btn, lp);
        btn.setOnClickListener(v -> montarTelaSuporteRemoto());
    }

    private void montarTelaSuporteRemoto() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = criarContainer(scroll);
        adicionarTopo(root);

        TextView desc = new TextView(this);
        desc.setText("Digite o código de suporte que o atendente gerou no painel. O suporte só inicia depois que você aceitar.");
        desc.setTextColor(TEXTO_SUAVE);
        desc.setTextSize(isTV() ? 20 : 16);
        desc.setGravity(Gravity.CENTER);
        desc.setPadding(dp(6), 0, dp(6), dp(18));
        root.addView(desc, new LinearLayout.LayoutParams(-1, -2));

        EditText edtCodigo = new EditText(this);
        edtCodigo.setHint("Código de suporte");
        edtCodigo.setTextColor(Color.WHITE);
        edtCodigo.setHintTextColor(Color.rgb(150,145,154));
        edtCodigo.setTextSize(isTV()?28:22);
        edtCodigo.setGravity(Gravity.CENTER);
        edtCodigo.setSingleLine(true);
        edtCodigo.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        edtCodigo.setFilters(new InputFilter[]{new InputFilter.LengthFilter(6)});
        edtCodigo.setBackground(criarBorda(Color.argb(65,120,10,20), COR_PRINCIPAL, dp(18), dp(1)));
        root.addView(edtCodigo, new LinearLayout.LayoutParams(-1, dp(isTV()?78:66)));

        TextView aviso = new TextView(this);
        aviso.setText("Você pode encerrar o suporte a qualquer momento. O suporte permite comandos dentro do ativador e abertura das telas de permissão do Android.");
        aviso.setTextColor(TEXTO_SUAVE);
        aviso.setTextSize(isTV()?16:13);
        aviso.setGravity(Gravity.CENTER);
        aviso.setPadding(0, dp(14), 0, dp(14));
        root.addView(aviso, new LinearLayout.LayoutParams(-1, -2));

        Button entrar = criarBotao("CONECTAR E ACEITAR SUPORTE");
        root.addView(entrar, new LinearLayout.LayoutParams(-1, dp(isTV()?68:58)));
        entrar.setOnClickListener(v -> conectarSuporte(edtCodigo.getText().toString().trim()));
        entrar.requestFocus();

        Button voltar = criarBotao("VOLTAR");
        voltar.setBackground(criarBorda(Color.argb(90,20,20,28), COR_PRINCIPAL, dp(16), dp(1)));
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-1, dp(isTV()?58:50));
        vp.setMargins(0, dp(12), 0, 0);
        root.addView(voltar, vp);
        voltar.setOnClickListener(v -> mostrarTelaCorreta());

        setContentView(scroll);
    }

    private void conectarSuporte(String codigo) {
        if (!codigo.matches("\\d{6}")) {
            Toast.makeText(this, "Digite o código de 6 números.", Toast.LENGTH_LONG).show();
            return;
        }
        Toast.makeText(this, "Conectando suporte...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            try {
                String androidId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
                String aparelho = Build.MANUFACTURER + " " + Build.MODEL;
                String url = Config.API_SUPORTE + "?action=aceitar&codigo=" + URLEncoder.encode(codigo, "UTF-8")
                        + "&device=" + URLEncoder.encode(aparelho, "UTF-8")
                        + "&device_id=" + URLEncoder.encode(androidId == null ? "" : androidId, "UTF-8")
                        + "&android=" + URLEncoder.encode(String.valueOf(Build.VERSION.SDK_INT), "UTF-8")
                        + "&tipo_aparelho=" + URLEncoder.encode(isTV() ? "tv" : "mobile", "UTF-8");
                JSONObject obj = new JSONObject(httpGet(url));
                if (!"ok".equalsIgnoreCase(obj.optString("status"))) {
                    runOnUiThread(() -> Toast.makeText(this, obj.optString("mensagem", "Código não encontrado ou expirado."), Toast.LENGTH_LONG).show());
                    return;
                }
                suporteSessaoId = obj.optString("sessao_id", "");
                suporteCodigoAtual = codigo;
                suporteAtivo = true;
                runOnUiThread(() -> {
                    Toast.makeText(this, "Suporte conectado. Aguarde o atendente.", Toast.LENGTH_LONG).show();
                    iniciarPollSuporte();
                    mostrarTelaCorreta();
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Erro no suporte: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    private void iniciarPollSuporte() {
        suporteHandler.removeCallbacksAndMessages(null);
        suporteHandler.postDelayed(new Runnable() {
            @Override public void run() {
                if (!suporteAtivo || suporteSessaoId == null || suporteSessaoId.isEmpty()) return;
                consultarComandosSuporte();
                suporteHandler.postDelayed(this, 3000);
            }
        }, 1200);
    }

    private void consultarComandosSuporte() {
        new Thread(() -> {
            try {
                String tela = edtLicenca == null ? "permissoes" : "licenca";
                String url = Config.API_SUPORTE + "?action=poll&sessao_id=" + URLEncoder.encode(suporteSessaoId, "UTF-8")
                        + "&tela=" + URLEncoder.encode(tela, "UTF-8")
                        + "&permissoes=" + URLEncoder.encode(permissoesLiberadas() ? "sim" : "nao", "UTF-8");
                JSONObject obj = new JSONObject(httpGet(url));
                String status = obj.optString("status", "");
                if ("encerrado".equalsIgnoreCase(status)) {
                    suporteAtivo = false;
                    runOnUiThread(() -> Toast.makeText(this, "Suporte encerrado.", Toast.LENGTH_LONG).show());
                    return;
                }
                String cmd = obj.optString("comando", "");
                String msg = obj.optString("mensagem", "");
                String lic = obj.optString("licenca", "");
                if (cmd == null || cmd.trim().isEmpty()) return;
                runOnUiThread(() -> executarComandoSuporte(cmd, msg, lic));
            } catch (Exception ignored) {}
        }).start();
    }

    private void executarComandoSuporte(String cmd, String msg, String licenca) {
        if (msg != null && !msg.trim().isEmpty()) Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
        if ("abrir_permissoes".equals(cmd)) {
            montarTelaPermissoes();
            abrirPermissoesNecessarias();
        } else if ("abrir_ativacao".equals(cmd)) {
            if (permissoesLiberadas()) confirmarPermissoes();
            montarTelaAtivacao();
        } else if ("preencher_licenca".equals(cmd)) {
            if (permissoesLiberadas()) confirmarPermissoes();
            montarTelaAtivacao();
            if (edtLicenca != null && licenca != null) edtLicenca.setText(licenca);
        } else if ("ativar_licenca".equals(cmd)) {
            if (permissoesLiberadas()) confirmarPermissoes();
            montarTelaAtivacao();
            if (edtLicenca != null && licenca != null && licenca.matches("\\d{11}")) edtLicenca.setText(licenca);
            if (edtLicenca != null) ativar();
        } else if ("mensagem".equals(cmd)) {
            // Mensagem já foi mostrada acima.
        } else if ("encerrar".equals(cmd)) {
            suporteAtivo = false;
            Toast.makeText(this, "Suporte encerrado.", Toast.LENGTH_LONG).show();
        }
    }

    private void abrirPropaganda() {
        try {
            if (propagandaLink == null || propagandaLink.trim().isEmpty()) return;
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(propagandaLink.trim()));
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível abrir o link da propaganda.", Toast.LENGTH_LONG).show();
        }
    }

    private void mostrarTelaPermissoes() {
        montarTelaPermissoes();
    }

    private void montarTelaPermissoes() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = criarContainer(scroll);
        adicionarTopo(root);

        TextView subtitulo = new TextView(this);
        subtitulo.setText(textoPermissao);
        subtitulo.setTextColor(TEXTO_SUAVE);
        subtitulo.setTextSize(isTV() ? 20 : 16);
        subtitulo.setGravity(Gravity.CENTER);
        subtitulo.setPadding(dp(6), 0, dp(6), dp(18));
        root.addView(subtitulo, new LinearLayout.LayoutParams(-1, -2));

        TextView lista = new TextView(this);
        lista.setText(statusPermissoesTexto());
        lista.setTextColor(Color.WHITE);
        lista.setTextSize(isTV() ? 18 : 15);
        lista.setPadding(dp(18), dp(16), dp(18), dp(16));
        lista.setBackground(criarBorda(Color.argb(85, 30, 35, 50), Color.argb(120, 255, 255, 255), dp(16), dp(1)));
        root.addView(lista, new LinearLayout.LayoutParams(-1, -2));

        Button btn = criarBotao(textoBotaoPermissao);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(isTV() ? 70 : 62));
        bp.setMargins(0, dp(20), 0, dp(12));
        root.addView(btn, bp);
        btn.setOnClickListener(v -> abrirPermissoesNecessarias());
        btn.requestFocus();

        Button atualizar = criarBotao("JÁ LIBEREI, VERIFICAR AGORA");
        atualizar.setBackground(criarBorda(Color.argb(90, 20, 20, 28), COR_PRINCIPAL, dp(16), dp(1)));
        root.addView(atualizar, new LinearLayout.LayoutParams(-1, dp(isTV() ? 62 : 54)));
        atualizar.setOnClickListener(v -> verificarPermissoesEContinuar());

        adicionarPropaganda(root);
        adicionarSuporteRemoto(root);

        setContentView(scroll);
    }

    private boolean detectarRoot() {
        // Confirmação conservadora: só existe root quando o comando realmente
        // consegue executar como UID 0. Arquivo "su", pacote Magisk, test-keys,
        // Permission denied, timeout ou qualquer outro indício isolado NÃO
        // significam root confirmado.
        Process processo = null;
        try {
            processo = Runtime.getRuntime().exec(new String[]{"su", "-c", "id"});

            long limite = System.currentTimeMillis() + 20000L;
            Integer codigo = null;
            while (System.currentTimeMillis() < limite) {
                try {
                    codigo = processo.exitValue();
                    break;
                } catch (IllegalThreadStateException aindaExecutando) {
                    try { Thread.sleep(120L); } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                }
            }

            if (codigo == null) {
                try { processo.destroy(); } catch (Throwable ignored) {}
                return false; // Sem confirmação dentro do prazo: não acusa root.
            }

            StringBuilder resposta = new StringBuilder();
            BufferedReader out = new BufferedReader(new InputStreamReader(processo.getInputStream()));
            BufferedReader err = new BufferedReader(new InputStreamReader(processo.getErrorStream()));
            String linha;
            while ((linha = out.readLine()) != null && resposta.length() < 1200) {
                resposta.append(linha).append('\n');
            }
            while ((linha = err.readLine()) != null && resposta.length() < 1200) {
                resposta.append(linha).append('\n');
            }

            String retorno = resposta.toString().toLowerCase(java.util.Locale.ROOT);
            return codigo == 0 && (retorno.contains("uid=0") || retorno.contains("uid = 0"));
        } catch (Throwable ignored) {
            // su inexistente, bloqueado ou sem permissão não é root confirmado.
            return false;
        } finally {
            if (processo != null) {
                try { processo.destroy(); } catch (Throwable ignored) {}
            }
        }
    }

    private void montarTelaRootDetectado() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = criarContainer(scroll);
        adicionarTopo(root);

        TextView titulo = new TextView(this);
        titulo.setText("ROOT DETECTADO");
        titulo.setTextColor(COR_PRINCIPAL);
        titulo.setTextSize(isTV() ? 30 : 23);
        titulo.setTypeface(Typeface.DEFAULT_BOLD);
        titulo.setGravity(Gravity.CENTER);
        titulo.setPadding(dp(8), dp(10), dp(8), dp(14));
        root.addView(titulo, new LinearLayout.LayoutParams(-1, -2));

        TextView aviso = new TextView(this);
        aviso.setText("Este aparelho possui root. Para evitar bloqueio na instalação, remova o root antes de usar a licença. A instalação do aplicativo continuará sendo normal, pelo instalador original do aparelho.");
        aviso.setTextColor(TEXTO_CLARO);
        aviso.setTextSize(isTV() ? 20 : 16);
        aviso.setGravity(Gravity.CENTER);
        aviso.setPadding(dp(12), dp(8), dp(12), dp(22));
        root.addView(aviso, new LinearLayout.LayoutParams(-1, -2));

        Button remover = new Button(this);
        remover.setText("REMOVER ROOT");
        remover.setTextColor(Color.WHITE);
        remover.setTextSize(isTV() ? 21 : 17);
        remover.setTypeface(Typeface.DEFAULT_BOLD);
        remover.setBackground(criarGradienteBotao());
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(isTV() ? 68 : 58));
        rp.setMargins(0, dp(8), 0, dp(14));
        root.addView(remover, rp);
        remover.setOnClickListener(v -> confirmarRemocaoRoot());

        Button verificar = new Button(this);
        verificar.setText("VERIFICAR NOVAMENTE");
        verificar.setTextColor(Color.WHITE);
        verificar.setTextSize(isTV() ? 18 : 15);
        verificar.setBackground(criarBorda(Color.argb(90, 20, 20, 28), COR_PRINCIPAL, dp(16), dp(1)));
        root.addView(verificar, new LinearLayout.LayoutParams(-1, dp(isTV() ? 62 : 54)));
        verificar.setOnClickListener(v -> verificarRootAntesDaLicenca());

        TextView detalhe = new TextView(this);
        detalhe.setText("A autorização de superusuário será pedida somente para remover o root. Ela não será usada para baixar nem instalar o APK.");
        detalhe.setTextColor(TEXTO_SUAVE);
        detalhe.setTextSize(isTV() ? 16 : 13);
        detalhe.setGravity(Gravity.CENTER);
        detalhe.setPadding(dp(8), dp(18), dp(8), dp(4));
        root.addView(detalhe, new LinearLayout.LayoutParams(-1, -2));

        setContentView(scroll);
    }

    private void confirmarRemocaoRoot() {
        if (removendoRoot) return;
        new AlertDialog.Builder(this)
                .setTitle("Remover root")
                .setMessage("O ativador solicitará a permissão de superusuário e tentará remover o root. Confirme a autorização no gerenciador de root quando ela aparecer.")
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("CONTINUAR", (d, w) -> removerRootAgora())
                .show();
    }

    private void removerRootAgora() {
        if (removendoRoot) return;
        removendoRoot = true;
        Toast.makeText(this, "Aguardando autorização de superusuário...", Toast.LENGTH_LONG).show();
        new Thread(() -> {
            String retorno;
            try {
                retorno = executarRemocaoRoot();
            } catch (Exception e) {
                retorno = "Não foi possível iniciar a remoção: " + e.getMessage();
            }
            try { Thread.sleep(1200); } catch (InterruptedException ignored) {}
            boolean aindaTemRoot = detectarRoot();
            String finalRetorno = retorno;
            runOnUiThread(() -> {
                removendoRoot = false;
                if (!aindaTemRoot) {
                    new AlertDialog.Builder(this)
                            .setTitle("Root removido")
                            .setMessage("A remoção foi concluída. Reinicie o aparelho e abra o ativador novamente para confirmar.")
                            .setPositiveButton("OK", (d, w) -> montarTelaAtivacao())
                            .show();
                } else {
                    new AlertDialog.Builder(this)
                            .setTitle("Root ainda detectado")
                            .setMessage(finalRetorno + "\n\nAbra o gerenciador de root, permita o Ativador Unitv Free e toque novamente em REMOVER ROOT. Em KernelSU/APatch pode ser necessário restaurar o boot original.")
                            .setPositiveButton("OK", null)
                            .show();
                }
            });
        }).start();
    }

    private String executarRemocaoRoot() throws Exception {
        String script =
                "set +e; " +
                "if command -v magisk >/dev/null 2>&1; then magisk --uninstall >/dev/null 2>&1; fi; " +
                "if [ -x /data/adb/magisk/magisk ]; then /data/adb/magisk/magisk --uninstall >/dev/null 2>&1; fi; " +
                "mount -o rw,remount /system >/dev/null 2>&1; " +
                "rm -f /system/bin/su /system/xbin/su /system/bin/.ext/.su /sbin/su /su/bin/su >/dev/null 2>&1; " +
                "rm -f /system/app/Superuser.apk /system/app/SuperSU.apk >/dev/null 2>&1; " +
                "pm uninstall eu.chainfire.supersu >/dev/null 2>&1; " +
                "pm uninstall com.kingroot.kinguser >/dev/null 2>&1; " +
                "pm uninstall com.kingo.root >/dev/null 2>&1; " +
                "sync; echo ROOT_REMOVE_DONE";

        Process processo = Runtime.getRuntime().exec(new String[]{"su", "-c", script});
        BufferedReader out = new BufferedReader(new InputStreamReader(processo.getInputStream()));
        BufferedReader err = new BufferedReader(new InputStreamReader(processo.getErrorStream()));
        StringBuilder resposta = new StringBuilder();
        String linha;
        while ((linha = out.readLine()) != null) resposta.append(linha).append('\n');
        while ((linha = err.readLine()) != null && resposta.length() < 800) resposta.append(linha).append('\n');
        int codigo = processo.waitFor();
        processo.destroy();
        if (codigo != 0) return "A permissão root foi negada ou o método de root bloqueou a remoção (código " + codigo + ").";
        return resposta.toString().contains("ROOT_REMOVE_DONE")
                ? "A tentativa automática foi executada."
                : "A tentativa terminou sem confirmação do gerenciador de root.";
    }

    private void montarTelaAtivacao() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = criarContainer(scroll);
        adicionarTopo(root);

        TextView subtitulo = new TextView(this);
        subtitulo.setText(appSubtitulo);
        subtitulo.setTextColor(TEXTO_SUAVE);
        subtitulo.setTextSize(isTV() ? 20 : 16);
        subtitulo.setGravity(Gravity.CENTER);
        subtitulo.setPadding(dp(8), 0, dp(8), dp(24));
        root.addView(subtitulo, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout inputBox = new LinearLayout(this);
        inputBox.setOrientation(LinearLayout.HORIZONTAL);
        inputBox.setGravity(Gravity.CENTER_VERTICAL);
        inputBox.setPadding(dp(18), dp(10), dp(18), dp(10));
        inputBox.setBackground(criarBorda(Color.argb(65, 120, 10, 20), COR_PRINCIPAL, dp(18), dp(1)));

        TextView lock = new TextView(this);
        lock.setText("#");
        lock.setTextColor(COR_PRINCIPAL);
        lock.setTextSize(isTV() ? 34 : 27);
        lock.setTypeface(Typeface.DEFAULT_BOLD);
        lock.setGravity(Gravity.CENTER);
        inputBox.addView(lock, new LinearLayout.LayoutParams(dp(46), -1));

        edtLicenca = new EditText(this);
        edtLicenca.setHint("Código de 11 dígitos");
        edtLicenca.setTextColor(Color.WHITE);
        edtLicenca.setHintTextColor(Color.rgb(150, 145, 154));
        edtLicenca.setTextSize(isTV() ? 29 : 22);
        edtLicenca.setGravity(Gravity.CENTER);
        edtLicenca.setSingleLine(true);
        edtLicenca.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        edtLicenca.setFilters(new InputFilter[]{new InputFilter.LengthFilter(11)});
        edtLicenca.setBackgroundColor(Color.TRANSPARENT);
        inputBox.addView(edtLicenca, new LinearLayout.LayoutParams(0, -2, 1));

        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(-1, dp(isTV() ? 88 : 74));
        inputParams.setMargins(0, 0, 0, dp(10));
        root.addView(inputBox, inputParams);

        grupoTipoAparelho = new RadioGroup(this);
        grupoTipoAparelho.setOrientation(RadioGroup.VERTICAL);
        grupoTipoAparelho.setVisibility(View.GONE);
        grupoTipoAparelho.setPadding(dp(12), dp(6), dp(12), dp(10));
        grupoTipoAparelho.setBackground(criarBorda(Color.argb(55, 255, 255, 255), Color.argb(90, 255, 255, 255), dp(16), dp(1)));

        TextView escolhaTitulo = new TextView(this);
        escolhaTitulo.setText("Escolha onde será instalado:");
        escolhaTitulo.setTextColor(TEXTO_CLARO);
        escolhaTitulo.setTextSize(isTV() ? 18 : 14);
        escolhaTitulo.setTypeface(Typeface.DEFAULT_BOLD);
        escolhaTitulo.setGravity(Gravity.CENTER);
        escolhaTitulo.setPadding(0, 0, 0, dp(6));
        grupoTipoAparelho.addView(escolhaTitulo, new RadioGroup.LayoutParams(-1, -2));

        RadioButton opcaoAndroid = criarOpcaoTipo(1001, nomeOpcaoAndroid);
        RadioButton opcaoTvBox = criarOpcaoTipo(1002, nomeOpcaoTvBox);
        grupoTipoAparelho.addView(opcaoAndroid);
        grupoTipoAparelho.addView(opcaoTvBox);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1, -2);
        gp.setMargins(0, 0, 0, dp(14));
        root.addView(grupoTipoAparelho, gp);

        grupoTipoAparelho.setOnCheckedChangeListener((g, checkedId) -> {
            if (checkedId == 1001) tipoAparelhoEscolhido = "android";
            else if (checkedId == 1002) tipoAparelhoEscolhido = "tv_box";
        });

        edtLicenca.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence texto, int start, int before, int count) {
                boolean mostrar = texto != null && texto.toString().trim().length() == 11;
                grupoTipoAparelho.setVisibility(mostrar ? View.VISIBLE : View.GONE);
                if (!mostrar) {
                    grupoTipoAparelho.clearCheck();
                    tipoAparelhoEscolhido = "";
                }
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        btnAtivar = criarBotao(textoBotaoAtivar);
        LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(-1, dp(isTV() ? 72 : 62));
        btnParams.setMargins(0, 0, 0, dp(18));
        root.addView(btnAtivar, btnParams);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setVisibility(View.GONE);
        progress.setMax(100);
        LinearLayout.LayoutParams progressParams = new LinearLayout.LayoutParams(-1, dp(8));
        progressParams.setMargins(0, 0, 0, dp(14));
        root.addView(progress, progressParams);

        txtStatus = new TextView(this);
        txtStatus.setText(msgPronto);
        txtStatus.setTextColor(TEXTO_SUAVE);
        txtStatus.setTextSize(isTV() ? 17 : 14);
        txtStatus.setGravity(Gravity.CENTER);
        txtStatus.setPadding(dp(6), dp(8), dp(6), dp(8));
        root.addView(txtStatus, new LinearLayout.LayoutParams(-1, -2));

        btnApagarConfig = criarBotao("APAGAR CONFIG BAIXADA");
        btnApagarConfig.setBackground(criarBorda(Color.argb(90,20,20,28), Color.argb(170,255,255,255), dp(16), dp(1)));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, dp(isTV() ? 58 : 50));
        ap.setMargins(0, dp(12), 0, 0);
        root.addView(btnApagarConfig, ap);
        btnApagarConfig.setOnClickListener(v -> apagarConfigBaixada());

        adicionarPropaganda(root);
        adicionarSuporteRemoto(root);

        btnAtivar.setOnClickListener(v -> ativar());
        btnAtivar.requestFocus();
        edtLicenca.setOnKeyListener((v, keyCode, event) -> {
            if (keyCode == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_UP) { ativar(); return true; }
            return false;
        });
        setContentView(scroll);
    }

    private RadioButton criarOpcaoTipo(int id, String texto) {
        RadioButton rb = new RadioButton(this);
        rb.setId(id);
        rb.setText(texto);
        rb.setTextColor(TEXTO_CLARO);
        rb.setTextSize(isTV() ? 20 : 16);
        rb.setTypeface(Typeface.DEFAULT_BOLD);
        rb.setPadding(dp(4), dp(4), dp(4), dp(4));
        rb.setFocusable(true);
        return rb;
    }

    private Button criarBotao(String texto) {
        Button b = new Button(this);
        b.setText(texto);
        b.setTextColor(Color.WHITE);
        b.setTextSize(isTV() ? 20 : 16);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setAllCaps(false);
        b.setFocusable(true);
        b.setBackground(criarGradienteBotao());
        return b;
    }

    private GradientDrawable criarBorda(int corFundo, int corBorda, int raio, int largura) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(corFundo);
        gd.setCornerRadius(raio);
        gd.setStroke(largura, corBorda);
        return gd;
    }

    private GradientDrawable criarGradienteBotao() {
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{COR_PRINCIPAL_ESCURO, COR_PRINCIPAL, Color.rgb(255, 95, 75)});
        gd.setCornerRadius(dp(16));
        return gd;
    }

    private int dp(int valor) {
        return (int) (valor * getResources().getDisplayMetrics().density + 0.5f);
    }

    private boolean permissoesLiberadas() {
        boolean storageOk = true;
        if (Build.VERSION.SDK_INT >= 30) {
            // Permissão geral verdadeira do Android 11+: Acesso a todos os arquivos.
            storageOk = Environment.isExternalStorageManager();
        } else if (Build.VERSION.SDK_INT >= 23 && Build.VERSION.SDK_INT <= 29) {
            // Android 6 até 10 usa a permissão normal de armazenamento.
            storageOk = checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        }

        // Não basta o Android dizer que liberou: testa escrita real no aparelho.
        if (storageOk) {
            storageOk = testarEscritaPermissaoReal();
        }

        boolean installOk = true;
        if (Build.VERSION.SDK_INT >= 26) installOk = getPackageManager().canRequestPackageInstalls();
        return storageOk && installOk;
    }

    private void verificarPermissoesEContinuar() {
        if (permissoesLiberadas()) {
            confirmarPermissoes();
            Toast.makeText(this, "Permissões confirmadas. Preparando o aparelho...", Toast.LENGTH_SHORT).show();
            iniciarVerificacaoRootAposPermissoes();
        } else {
            Toast.makeText(this, "Ainda falta liberar uma permissão. Toque em Liberar permissões.", Toast.LENGTH_LONG).show();
            montarTelaPermissoes();
        }
    }

    private String statusPermissoesTexto() {
        StringBuilder sb = new StringBuilder();
        boolean acessoArquivos = true;
        if (Build.VERSION.SDK_INT >= 30) {
            acessoArquivos = Environment.isExternalStorageManager();
            sb.append(acessoArquivos ? "✓ Acesso a todos os arquivos liberado\n" : "• Liberar Acesso a todos os arquivos\n");
        } else if (Build.VERSION.SDK_INT >= 23 && Build.VERSION.SDK_INT <= 29) {
            acessoArquivos = checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
            sb.append(acessoArquivos ? "✓ Armazenamento liberado\n" : "• Liberar armazenamento\n");
        } else {
            sb.append("✓ Armazenamento liberado\n");
        }

        if (acessoArquivos) {
            sb.append(testarEscritaPermissaoReal() ? "✓ Escrita real confirmada no aparelho\n" : "• Permissão marcada, mas escrita real ainda bloqueada\n");
        }

        if (Build.VERSION.SDK_INT >= 26) sb.append(getPackageManager().canRequestPackageInstalls() ? "✓ Instalação de apps liberada" : "• Permitir instalar aplicativos desconhecidos");
        else sb.append("✓ Instalação liberada");
        return sb.toString();
    }

    private boolean testarEscritaPermissaoReal() {
        // Testa primeiro o caminho que algumas TVs pedem no erro.
        File[] testes = new File[]{
                new File("/storage/self/primary/Android/.config_teste_permissao"),
                new File("/storage/emulated/0/Android/.config_teste_permissao"),
                new File(Environment.getExternalStorageDirectory(), "Android/.config_teste_permissao")
        };

        for (File teste : testes) {
            if (teste == null) continue;
            try {
                File pai = teste.getParentFile();
                if (pai != null && !pai.exists()) pai.mkdirs();
                FileOutputStream fos = new FileOutputStream(teste, false);
                fos.write("ok".getBytes("UTF-8"));
                fos.flush();
                fos.close();
                // Se conseguiu criar no caminho pedido, apaga só o teste.
                try { teste.delete(); } catch (Exception ignored) {}
                return true;
            } catch (Exception ignored) {}
        }

        // Se a TV bloqueia /Android, confirma pelo caminho automático correto do aparelho.
        try {
            File pastaApp = getExternalFilesDir(null);
            if (pastaApp != null) {
                File teste = new File(pastaApp, ".config_teste_permissao");
                File pai = teste.getParentFile();
                if (pai != null && !pai.exists()) pai.mkdirs();
                FileOutputStream fos = new FileOutputStream(teste, false);
                fos.write("ok".getBytes("UTF-8"));
                fos.flush();
                fos.close();
                try { teste.delete(); } catch (Exception ignored) {}
                return true;
            }
        } catch (Exception ignored) {}

        return false;
    }

    private boolean abrirIntentPermissao(Intent intent, String mensagem) {
        try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            aguardandoRetornoPermissao = true;
            startActivity(intent);
            Toast.makeText(this, mensagem, Toast.LENGTH_LONG).show();
            return true;
        } catch (Exception ignored) {
            return false;
        }
    }

    private boolean abrirTelaTodosArquivos() {
        if (Build.VERSION.SDK_INT < 30) return false;
        String pacote = getPackageName();

        Intent[] tentativas = new Intent[]{
                // Tela verdadeira do Android 11+ para o app atual.
                new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).setData(Uri.parse("package:" + pacote)),
                // Lista geral: Acesso especial > Acesso a todos os arquivos.
                new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION),
                // Fallback usado por algumas ROMs de TV Box.
                new Intent("android.settings.MANAGE_ALL_FILES_ACCESS_PERMISSION"),
                new Intent("android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION").setData(Uri.parse("package:" + pacote)),
                // Último recurso: detalhes do app para o usuário entrar em permissões manualmente.
                new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(Uri.parse("package:" + pacote)),
                new Intent(Settings.ACTION_SETTINGS)
        };

        for (Intent i : tentativas) {
            if (abrirIntentPermissao(i, "Ative a permissão geral de arquivos para o ativador e volte aqui.")) return true;
        }
        return false;
    }

    private boolean abrirTelaInstalarAppsDesconhecidos() {
        if (Build.VERSION.SDK_INT < 26) return false;
        Intent intent = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName()));
        return abrirIntentPermissao(intent, "Marque 'Permitir desta fonte' e volte para o ativador.");
    }

    private boolean abrirTelaPermissoesDiretoDoApp() {
        String pacote = getPackageName();

        Intent[] tentativas = new Intent[]{
                new Intent("android.intent.action.MANAGE_APP_PERMISSIONS")
                        .putExtra("android.intent.extra.PACKAGE_NAME", pacote)
                        .putExtra("android.provider.extra.APP_PACKAGE", pacote)
                        .putExtra("package", pacote),
                new Intent("android.settings.APP_PERMISSION_SETTINGS")
                        .putExtra("android.intent.extra.PACKAGE_NAME", pacote)
                        .putExtra("android.provider.extra.APP_PACKAGE", pacote)
                        .putExtra("package", pacote),
                new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                        .setData(Uri.parse("package:" + pacote))
        };

        for (Intent intent : tentativas) {
            if (abrirIntentPermissao(intent, "Libere as permissões do aplicativo e volte para o ativador.")) return true;
        }
        return false;
    }

    private void abrirPermissoesNecessarias() {
        try {
            // Android 11+ precisa da permissão especial verdadeira para salvar em caminhos públicos/fixos.
            if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
                if (abrirTelaTodosArquivos()) return;
                if (abrirTelaPermissoesDiretoDoApp()) return;
            }

            // Android 6 até 10 usa solicitação normal de armazenamento.
            if (Build.VERSION.SDK_INT >= 23 && Build.VERSION.SDK_INT <= 29
                    && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                aguardandoRetornoPermissao = true;
                requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, 10);
                return;
            }

            // Permissão real para abrir o instalador do APK baixado.
            if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
                if (abrirTelaInstalarAppsDesconhecidos()) return;
                if (abrirTelaPermissoesDiretoDoApp()) return;
            }

            verificarPermissoesEContinuar();
        } catch (Exception e) {
            if (abrirTelaPermissoesDiretoDoApp()) return;
            try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch (Exception ignored2) {}
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 10) {
            verificarPermissoesEContinuar();
        }
    }

    private void ativar() {
        if (ativacaoBloqueadaPorAviso) {
            mensagem("A ativação está temporariamente indisponível. Consulte o aviso exibido ao abrir o aplicativo.");
            verificarNotificacaoPainel();
            return;
        }
        if (!permissoesLiberadas()) {
            Toast.makeText(this, "Libere as permissões antes de usar a licença.", Toast.LENGTH_LONG).show();
            mostrarTelaPermissoes();
            return;
        }
        if (detectarRoot()) {
            Toast.makeText(this, "Root detectado. Remova o root antes de continuar.", Toast.LENGTH_LONG).show();
            montarTelaRootDetectado();
            return;
        }
        String licenca = edtLicenca.getText().toString().trim();
        if (!licenca.matches("\\d{11}")) {
            mensagem("Digite uma licença com exatamente 11 números.");
            return;
        }
        if (tipoAparelhoEscolhido == null || tipoAparelhoEscolhido.trim().isEmpty()) {
            mensagem("Escolha a opção do aparelho antes de ativar.");
            return;
        }
        progress.setVisibility(View.VISIBLE);
        progress.setIndeterminate(false);
        progress.setProgress(8);
        btnAtivar.setEnabled(false);
        txtStatus.setText("Preparando ativação... 8%");

        new Thread(() -> {
            String tokenAtivacao = "";
            String origemAtivacao = "";
            String androidIdAtivacao = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
            try {
                String json = chamarApi(licenca);
                if (json == null || json.trim().isEmpty()) {
                    runOnUiThread(() -> finalizar("Não foi possível consultar a licença. Verifique sua internet e tente novamente."));
                    return;
                }
                JSONObject obj = new JSONObject(json);
                String status = obj.optString("status", "erro");
                String msg = obj.optString("mensagem", "Resposta recebida.");
                tokenAtivacao = obj.optString("activation_token", "");
                origemAtivacao = obj.optString("origem", "");

                if (!"ok".equalsIgnoreCase(status)) {
                    String erroLicenca = msg == null || msg.trim().isEmpty()
                            ? "Licença inválida. Verifique o código e tente novamente."
                            : msg;
                    runOnUiThread(() -> finalizar(erroLicenca));
                    return;
                }

                runOnUiThread(() -> {
                    progress.setIndeterminate(false);
                    progress.setProgress(20);
                    txtStatus.setText("Licença validada. Preparando arquivos... 20%");
                });
                Thread.sleep(700);

                String configUrl = normalizarUrl(obj.optString("config_url", ""));
                String propertiesUrl = normalizarUrl(obj.optString("properties_url", ""));
                String apkUrl = normalizarUrl(obj.optString("apk_url", ""));

                if (configUrl.isEmpty()) {
                    throw new Exception("O painel não enviou a configuração.");
                }
                if (apkUrl.isEmpty()) {
                    throw new Exception("O painel não encontrou um aplicativo publicado para a versão escolhida.");
                }

                runOnUiThread(() -> txtStatus.setText("Baixando configuração..."));
                byte[] configBytes = baixarBytes(configUrl, "Baixando configuração");
                salvarEmPastas(Config.NOME_CONFIG_FINAL, configBytes);

                if (!propertiesUrl.isEmpty()) {
                    runOnUiThread(() -> txtStatus.setText("Baixando propriedades..."));
                    byte[] propBytes = baixarBytes(propertiesUrl, "Baixando propriedades");
                    salvarEmPastas(Config.NOME_PROPERTIES_FINAL, propBytes);
                }

                File apkFile = null;
                if (!apkUrl.isEmpty()) {
                    if (!permissoesLiberadas()) {
                        runOnUiThread(() -> { finalizar("Permissão removida. Libere novamente para instalar o aplicativo."); mostrarTelaPermissoes(); });
                        return;
                    }
                    runOnUiThread(() -> txtStatus.setText("Baixando aplicativo principal..."));
                    byte[] apkBytes = baixarBytes(apkUrl, "Baixando aplicativo");
                    validarApkBaixado(apkBytes);
                    apkFile = salvarArquivoAlternativo(Config.NOME_APK_FINAL, apkBytes);
                    validarArquivoApk(apkFile);
                }

                File finalApkFile = apkFile;
                runOnUiThread(() -> {
                    if (finalApkFile != null) {
                        progress.setVisibility(View.VISIBLE);
                        progress.setIndeterminate(false);
                        progress.setProgress(100);
                        txtStatus.setText("Arquivos prontos. Abrindo instalador... 100%");
                        btnAtivar.setEnabled(true);
                        abrirInstalador(finalApkFile);
                    } else {
                        finalizar(comAvisoConfig("Configuração salva, mas nenhum APK principal foi configurado no painel."));
                    }
                });
            } catch (Exception e) {
                if ("geradorconfig".equalsIgnoreCase(origemAtivacao) && tokenAtivacao != null && !tokenAtivacao.isEmpty()) {
                    devolverAtivacaoGerador(tokenAtivacao, androidIdAtivacao == null ? "" : androidIdAtivacao);
                }
                String detalheErro = e.getMessage() == null ? "" : e.getMessage().trim();
                String texto = "A ativação não foi concluída. Tente novamente.";
                if (!detalheErro.isEmpty() && !detalheErro.toLowerCase().contains("licença já utilizada")) {
                    texto += "\nDetalhe: " + detalheErro;
                }
                String finalTexto = texto;
                runOnUiThread(() -> finalizar(finalTexto));
            }
        }).start();
    }

    private String chamarApi(String licenca) throws Exception {
        String androidId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        String aparelho = Build.MANUFACTURER + " " + Build.MODEL;
        String query = "?codigo=" + URLEncoder.encode(licenca, "UTF-8")
                + "&device=" + URLEncoder.encode(aparelho, "UTF-8")
                + "&device_id=" + URLEncoder.encode(androidId == null ? "" : androidId, "UTF-8")
                + "&android=" + URLEncoder.encode(String.valueOf(Build.VERSION.SDK_INT), "UTF-8")
                + "&tipo=" + URLEncoder.encode(tipoAparelhoEscolhido, "UTF-8")
                + "&tipo_aparelho=" + URLEncoder.encode(tipoAparelhoEscolhido, "UTF-8");

        String respostaPrincipal = null;
        try {
            respostaPrincipal = httpGet(Config.API_ATIVAR + query);
            JSONObject principal = new JSONObject(respostaPrincipal);
            if ("ok".equalsIgnoreCase(principal.optString("status", ""))) return respostaPrincipal;
            String mensagem = principal.optString("mensagem", "").toLowerCase();
            boolean naoEncontrada = mensagem.contains("não encontrada") || mensagem.contains("nao encontrada") || mensagem.contains("inválida") || mensagem.contains("invalida");
            if (!naoEncontrada) return respostaPrincipal;
        } catch (Exception ignored) {
            // Tenta o painel do Gerador Config abaixo.
        }

        try {
            return httpGet(Config.API_ATIVAR_GERADOR + query);
        } catch (Exception erroGerador) {
            if (respostaPrincipal != null && !respostaPrincipal.trim().isEmpty()) return respostaPrincipal;
            throw erroGerador;
        }
    }

    private void devolverAtivacaoGerador(String token, String deviceId) {
        try {
            String endpoint = Config.API_ATIVAR_GERADOR.replace("ativar-app.php", "devolver-ativacao-app.php");
            String query = "?token=" + URLEncoder.encode(token, "UTF-8")
                    + "&device_id=" + URLEncoder.encode(deviceId == null ? "" : deviceId, "UTF-8");
            httpGet(endpoint + query);
        } catch (Exception ignored) {
            // A devolução manual continua disponível no painel do administrador.
        }
    }

    private String httpGet(String urlStr) throws Exception {
        Exception ultimoErro = null;
        for (String tentativa : gerarUrlsFallback(urlStr)) {
            try {
                HttpURLConnection conn = (HttpURLConnection) new URL(tentativa).openConnection();
                conn.setConnectTimeout(20000);
                conn.setReadTimeout(30000);
                conn.setRequestMethod("GET");
                InputStream is = conn.getResponseCode() >= 400 ? conn.getErrorStream() : conn.getInputStream();
                if (is == null) throw new Exception("API não respondeu. Código HTTP: " + conn.getResponseCode());
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line);
                br.close();
                return sb.toString();
            } catch (Exception e) {
                ultimoErro = e;
            }
        }
        throw ultimoErro == null ? new Exception("Falha de conexão.") : ultimoErro;
    }

    private String normalizarUrl(String url) {
        if (url == null) return "";
        url = url.trim();
        if (url.isEmpty()) return "";
        if (url.startsWith("http://") || url.startsWith("https://")) {
            return url.replace("http://", "https://").replace("://www.", "://");
        }
        return Config.BASE_URL + "/" + url.replaceFirst("^/+", "");
    }

    private List<String> gerarUrlsFallback(String urlStr) {
        List<String> urls = new ArrayList<>();
        if (urlStr == null) return urls;

        String normalizada = urlStr.trim();
        if (normalizada.isEmpty()) return urls;
        normalizada = normalizada.replace("http://", "https://").replace("://www.", "://");

        String path = normalizada;
        boolean dominioConhecido = false;

        try {
            URL u = new URL(normalizada);
            String host = u.getHost() == null ? "" : u.getHost();
            if (host.startsWith("www.")) host = host.substring(4);
            path = u.getFile();
            for (String base : Config.BASE_URLS) {
                URL b = new URL(base);
                String baseHost = b.getHost() == null ? "" : b.getHost();
                if (baseHost.startsWith("www.")) baseHost = baseHost.substring(4);
                if (host.equalsIgnoreCase(baseHost)) {
                    dominioConhecido = true;
                    break;
                }
            }
        } catch (Exception ignored) {
            path = "/" + normalizada.replaceFirst("^/+", "");
            dominioConhecido = true;
        }

        if (dominioConhecido) {
            for (String base : Config.BASE_URLS) {
                urls.add(base + (path.startsWith("/") ? path : "/" + path));
            }
        } else {
            urls.add(normalizada);
        }
        return urls;
    }

    private Bitmap baixarBitmap(String urlStr) throws Exception {
        Exception ultimoErro = null;
        for (String tentativa : gerarUrlsFallback(urlStr)) {
            try {
                HttpURLConnection conn = (HttpURLConnection) new URL(tentativa).openConnection();
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(30000);
                InputStream in = conn.getInputStream();
                Bitmap bmp = BitmapFactory.decodeStream(in);
                in.close();
                return bmp;
            } catch (Exception e) {
                ultimoErro = e;
            }
        }
        throw ultimoErro == null ? new Exception("Falha ao baixar imagem.") : ultimoErro;
    }

    private void carregarImagem(ImageView view, String url) {
        new Thread(() -> {
            try {
                Bitmap bmp = baixarBitmap(url);
                if (bmp != null) runOnUiThread(() -> { view.setImageBitmap(bmp); view.setVisibility(View.VISIBLE); });
            } catch (Exception ignored) {}
        }).start();
    }

    private byte[] baixarBytes(String urlStr, String etapa) throws Exception {
        final int inicioEtapa;
        final int faixaEtapa;
        if (etapa.toLowerCase().contains("configuração")) { inicioEtapa = 25; faixaEtapa = 25; }
        else if (etapa.toLowerCase().contains("propriedades")) { inicioEtapa = 50; faixaEtapa = 10; }
        else { inicioEtapa = 60; faixaEtapa = 32; }
        runOnUiThread(() -> {
            progress.setVisibility(View.VISIBLE);
            progress.setIndeterminate(false);
            if (progress.getProgress() < inicioEtapa) progress.setProgress(inicioEtapa);
            txtStatus.setText(etapa + "... " + inicioEtapa + "%");
        });

        Exception ultimoErro = null;
        for (String tentativa : gerarUrlsFallback(urlStr)) {
            try {
                HttpURLConnection conn = (HttpURLConnection) new URL(tentativa).openConnection();
                conn.setConnectTimeout(20000);
                conn.setReadTimeout(90000);
                int total = conn.getContentLength();
                InputStream in = new BufferedInputStream(conn.getInputStream());
                java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
                byte[] buffer = new byte[8192];
                int len;
                int baixado = 0;
                while ((len = in.read(buffer)) != -1) {
                    out.write(buffer, 0, len);
                    baixado += len;
                    if (total > 0) {
                        int pctArquivo = Math.min(100, (baixado * 100) / total);
                        int pct = Math.min(95, inicioEtapa + (pctArquivo * faixaEtapa / 100));
                        final double mbBaixado = baixado / 1048576.0;
                        final double mbTotal = total / 1048576.0;
                        runOnUiThread(() -> {
                            progress.setIndeterminate(false);
                            if (pct > progress.getProgress()) progress.setProgress(pct);
                            if (etapa.toLowerCase().contains("aplicativo")) {
                                txtStatus.setText(String.format(java.util.Locale.getDefault(), "Baixando aplicativo — %.1f MB de %.1f MB (%d%%)", mbBaixado, mbTotal, pct));
                            } else {
                                txtStatus.setText(etapa + "... " + pct + "%");
                            }
                        });
                    }
                }
                in.close();
                return out.toByteArray();
            } catch (Exception e) {
                ultimoErro = e;
            }
        }
        throw ultimoErro == null ? new Exception("Falha ao baixar arquivo.") : ultimoErro;
    }

    private void salvarEmPastas(String nome, byte[] dados) throws Exception {
        if (Config.NOME_CONFIG_FINAL.equals(nome)) {
            salvarConfigUnitvSegura(dados);
            return;
        }
        if (Config.NOME_PROPERTIES_FINAL.equals(nome)) {
            // Mantém properties apenas na pasta do próprio ativador. Não mexe em cache/dados do UniTV.
            salvarArquivoAlternativo(nome, dados);
            return;
        }
        salvarArquivoAlternativo(nome, dados);
    }

    private File[] caminhosConfigUnitv() {
        List<File> caminhos = new ArrayList<>();

        // Caminho correto do próprio aparelho/app. O Android decide o local real.
        File pastaApp = getExternalFilesDir(null);
        if (pastaApp != null) {
            adicionarCaminhoConfig(caminhos, new File(pastaApp, Config.NOME_CONFIG_FINAL));
        }

        // Alguns aparelhos/TV Box retornam mais de um armazenamento externo.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            File[] pastasApp = getExternalFilesDirs(null);
            if (pastasApp != null) {
                for (File pasta : pastasApp) {
                    if (pasta != null) adicionarCaminhoConfig(caminhos, new File(pasta, Config.NOME_CONFIG_FINAL));
                }
            }
        }

        // Caminhos reais comuns, acrescentados sem remover os antigos.
        File raiz = Environment.getExternalStorageDirectory();
        if (raiz != null) {
            adicionarCaminhoConfig(caminhos, new File(raiz, Config.NOME_CONFIG_FINAL));
            adicionarCaminhoConfig(caminhos, new File(raiz, "Android/" + Config.NOME_CONFIG_FINAL));
            adicionarCaminhoConfig(caminhos, new File(raiz, "Download/" + Config.NOME_CONFIG_FINAL));
            adicionarCaminhoConfig(caminhos, new File(raiz, "Documents/" + Config.NOME_CONFIG_FINAL));
        }

        // Caminhos antigos mantidos exatamente para compatibilidade.
        adicionarCaminhoConfig(caminhos, new File("/storage/emulated/0/.config"));
        adicionarCaminhoConfig(caminhos, new File("/storage/emulated/0/Android/.config"));
        adicionarCaminhoConfig(caminhos, new File("/sdcard/.config"));
        adicionarCaminhoConfig(caminhos, new File("/sdcard/Android/.config"));
        adicionarCaminhoConfig(caminhos, new File("/storage/self/primary/.config"));
        adicionarCaminhoConfig(caminhos, new File("/storage/self/primary/Android/.config"));

        return caminhos.toArray(new File[0]);
    }

    private void adicionarCaminhoConfig(List<File> lista, File arquivo) {
        if (arquivo == null) return;
        String caminho = arquivo.getAbsolutePath();
        for (File existente : lista) {
            if (existente != null && existente.getAbsolutePath().equals(caminho)) return;
        }
        lista.add(arquivo);
    }

    private void salvarConfigUnitvSegura(byte[] dados) throws Exception {
        int salvos = 0;
        StringBuilder erros = new StringBuilder();

        for (File destino : caminhosConfigUnitv()) {
            try {
                File pai = destino.getParentFile();
                if (pai != null && !pai.exists()) pai.mkdirs();
                escreverArquivo(destino, dados);
                salvos++;
            } catch (Exception e) {
                if (erros.length() < 900) {
                    erros.append(destino.getAbsolutePath())
                            .append(" -> ")
                            .append(e.getClass().getSimpleName())
                            .append(": ")
                            .append(e.getMessage())
                            .append("\n");
                }
            }
        }

        if (salvos == 0) {
            avisoSalvamentoConfig = "";
            throw new Exception("Não salvou a config em nenhum caminho. Erros:\n" + erros.toString());
        }

        if (erros.length() > 0) {
            avisoSalvamentoConfig = "Config salva em " + salvos + " caminho(s), mas alguns caminhos deram erro para você corrigir:\n" + erros.toString();
        } else {
            avisoSalvamentoConfig = "Config salva em " + salvos + " caminho(s), sem erro de gravação.";
        }
    }

    private void apagarConfigBaixada() {
        if (!permissoesLiberadas()) {
            Toast.makeText(this, "Libere as permissões antes de apagar a config.", Toast.LENGTH_LONG).show();
            mostrarTelaPermissoes();
            return;
        }
        int apagados = 0;
        for (File f : caminhosConfigUnitv()) {
            try {
                if (f.exists() && f.isFile() && f.delete()) apagados++;
            } catch (Exception ignored) {}
        }
        mensagem(apagados > 0 ? "Config apagada com sucesso." : "Nenhuma config encontrada para apagar.");
    }

    private File salvarArquivoAlternativo(String nome, byte[] dados) throws Exception {
        File pastaAlt = getExternalFilesDir(null);
        if (pastaAlt == null) {
            File raiz = Environment.getExternalStorageDirectory();
            pastaAlt = new File(raiz, Config.PASTA_ALTERNATIVA);
        }
        if (!pastaAlt.exists()) pastaAlt.mkdirs();
        File destino = new File(pastaAlt, nome);
        escreverArquivo(destino, dados);
        return destino;
    }

    private void escreverArquivo(File arquivo, byte[] dados) throws Exception {
        FileOutputStream fos = new FileOutputStream(arquivo, false);
        fos.write(dados);
        fos.flush();
        fos.close();
    }

    private void validarApkBaixado(byte[] dados) throws Exception {
        if (dados == null || dados.length < 10240) {
            throw new Exception("O APK recebido está vazio ou incompleto.");
        }
        // APK é um arquivo ZIP e deve iniciar com PK. HTML/JSON de erro não pode ir ao instalador.
        if (dados[0] != 0x50 || dados[1] != 0x4B) {
            String inicio;
            try { inicio = new String(dados, 0, Math.min(dados.length, 180), java.nio.charset.StandardCharsets.UTF_8); }
            catch (Exception ignored) { inicio = ""; }
            throw new Exception("O painel não entregou um APK válido. Resposta recebida: " + inicio.replace("\n", " ").trim());
        }
    }

    private void validarArquivoApk(File arquivo) throws Exception {
        if (arquivo == null || !arquivo.isFile() || arquivo.length() < 10240) {
            throw new Exception("O arquivo APK não foi salvo por completo.");
        }
        android.content.pm.PackageInfo info = getPackageManager().getPackageArchiveInfo(arquivo.getAbsolutePath(), 0);
        if (info == null || info.packageName == null || info.packageName.trim().isEmpty()) {
            arquivo.delete();
            throw new Exception("O Android não reconheceu o pacote baixado. O arquivo foi apagado e o código será devolvido.");
        }
    }

    private void abrirInstalador(File apkFile) {
        try {
            if (!permissoesLiberadas()) { mostrarTelaPermissoes(); return; }
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".provider", apkFile);
            intent.setDataAndType(uri, "application/vnd.android.package-archive");
            startActivity(intent);
        } catch (Exception e) {
            mensagem("APK baixado, mas não foi possível abrir instalador: " + e.getMessage());
        }
    }

    private String comAvisoConfig(String texto) {
        if (avisoSalvamentoConfig == null || avisoSalvamentoConfig.trim().isEmpty()) return texto;
        return texto + "\n" + avisoSalvamentoConfig;
    }

    private void finalizar(String texto) {
        progress.setIndeterminate(false);
        progress.setVisibility(View.GONE);
        btnAtivar.setEnabled(true);
        txtStatus.setText(limparMensagemApi(texto));
    }

    private void mensagem(String texto) {
        txtStatus.setText(limparMensagemApi(texto));
    }

    private String limparMensagemApi(String texto) {
        if (texto == null || texto.trim().isEmpty()) return "Não foi possível concluir agora.";
        String t = texto.trim();
        String low = t.toLowerCase(java.util.Locale.ROOT);
        if (low.contains("licença já utilizada") || low.contains("licenca ja utilizada")) {
            return "Este código já foi usado. Peça ao administrador para liberá-lo novamente.";
        }
        if (low.startsWith("erro:")) t = t.substring(5).trim();
        return t;
    }
}
