package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MovieHomeActivity extends Activity {
    private final List<ApiClient.Item> latest=new ArrayList<>();
    private final Handler slider=new Handler();
    private LinearLayout content;
    private int heroIndex=0;
    private Runnable heroTask;
    private boolean phone;

    @Override public void onCreate(Bundle b){
        super.onCreate(b); Ui.immersive(this); phone=Ui.phone(this);
        setContentView(AppBackground.wrap(this,build())); loadLatest();
    }
    @Override protected void onResume(){super.onResume();Ui.immersive(this);startSlider();}
    @Override protected void onPause(){super.onPause();slider.removeCallbacksAndMessages(null);}

    private View build(){
        LinearLayout root=Ui.column(this); root.setBackgroundColor(Color.TRANSPARENT);
        root.addView(YellowNav.bar(this,"FILMES"),new LinearLayout.LayoutParams(-1,Ui.dp(this,64)));
        content=Ui.column(this); content.setPadding(Ui.dp(this,phone?14:28),Ui.dp(this,12),Ui.dp(this,phone?14:28),Ui.dp(this,14));
        root.addView(content,new LinearLayout.LayoutParams(-1,0,1));
        render(); return root;
    }

    private void render(){
        if(content==null)return; content.removeAllViews();
        LinearLayout head=new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL);
        TextView t=Ui.text(this,"FILMES",phone?16:20,Color.WHITE,true); head.addView(t,new LinearLayout.LayoutParams(0,Ui.dp(this,34),1));
        TextView r=Ui.text(this,"LANÇAMENTOS",phone?9:11,Ui.GREEN,true); r.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); head.addView(r,new LinearLayout.LayoutParams(Ui.dp(this,150),Ui.dp(this,34)));
        content.addView(head,new LinearLayout.LayoutParams(-1,Ui.dp(this,38)));

        LinearLayout stage=new LinearLayout(this); stage.setOrientation(LinearLayout.HORIZONTAL); stage.setGravity(Gravity.TOP);
        LinearLayout left=Ui.column(this);
        left.addView(hero(),new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout shortcuts=new LinearLayout(this); shortcuts.setOrientation(LinearLayout.HORIZONTAL);
        shortcuts.addView(shortcut("★","FAVORITOS",0),new LinearLayout.LayoutParams(0,-1,1));
        shortcuts.addView(shortcut("NEW","LANÇAMENTOS",1),new LinearLayout.LayoutParams(0,-1,1));
        shortcuts.addView(shortcut("☰","GÊNERO",2),new LinearLayout.LayoutParams(0,-1,1));
        shortcuts.addView(shortcut("▦","TODOS",3),new LinearLayout.LayoutParams(0,-1,1));
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?78:116)); sp.topMargin=Ui.dp(this,5); left.addView(shortcuts,sp);
        stage.addView(left,new LinearLayout.LayoutParams(0,-1,phone?1.45f:1.75f));

        int cards=Math.min(2,Math.max(0,latest.size()-1));
        for(int x=0;x<2;x++){
            int idx=latest.isEmpty()?0:(heroIndex+1+x)%latest.size();
            View v=x<cards?featureCard(latest.get(idx)):emptyCard();
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1);
            p.leftMargin=Ui.dp(this,7);
            stage.addView(v,p);
        }
        content.addView(stage,new LinearLayout.LayoutParams(-1,0,1));
    }

    private View hero(){
        FrameLayout f=new FrameLayout(this); f.setFocusable(true); f.setClickable(true); f.setClipChildren(false);
        Ui.focus(f,this,Ui.round(0x22000000,8,this),Ui.stroke(0x33000000,Ui.GREEN,8,this));
        if(latest.isEmpty()) return f;
        ApiClient.Item i=latest.get(Math.min(heroIndex,latest.size()-1));
        ImageView bg=new ImageView(this);
        bg.setBackgroundColor(0xFF07110B);
        String heroBack=clean(i.backdrop,"");
        String heroPoster=clean(i.logo,"");
        if(!heroBack.isEmpty()){
            bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
            ImageLoader.intoBackground(this,bg,heroBack);
        }else if(!heroPoster.isEmpty()){
            // Sem backdrop: a capa do filme aparece de verdade, sem sumir atrás do fundo do app.
            bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
            ImageLoader.intoPoster(this,bg,heroPoster);
        }else{
            String internal=BrandConfig.internalBackground(this);
            if(!clean(internal,"").isEmpty()){
                bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
                ImageLoader.intoBackground(this,bg,internal);
            }
        }
        f.addView(bg,new FrameLayout.LayoutParams(-1,-1));
        View shade=new View(this); shade.setBackground(Ui.gradient(0x22000000,0xD9000000,0,this)); f.addView(shade,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout info=Ui.column(this); info.setGravity(Gravity.BOTTOM); info.setPadding(Ui.dp(this,18),0,Ui.dp(this,18),Ui.dp(this,18));
        TextView name=Ui.text(this,clean(i.name,"Filme"),phone?18:26,Color.WHITE,true); name.setMaxLines(2); info.addView(name,new LinearLayout.LayoutParams(-1,-2));
        long saved=LocalStore.resumePosition(this,i.id);
        String meta=(i.year>0?String.valueOf(i.year):"")+(clean(i.group,"").isEmpty()?"":"  •  "+clean(i.group,""));
        if(saved>10000) meta+="  •  ▶ CONTINUAR";
        TextView m=Ui.text(this,meta,phone?9:11,saved>10000?Ui.GREEN:0xFFE0E5E1,saved>10000);
        info.addView(m,new LinearLayout.LayoutParams(-1,Ui.dp(this,24)));
        if(latest.size()>1){
            StringBuilder dots=new StringBuilder();
            int max=Math.min(6,latest.size());
            for(int d=0;d<max;d++)dots.append(d==heroIndex?"●":"○").append(" ");
            TextView ind=Ui.text(this,dots.toString().trim(),phone?8:10,Ui.GREEN,true);
            info.addView(ind,new LinearLayout.LayoutParams(-1,Ui.dp(this,18)));
        }
        f.addView(info,new FrameLayout.LayoutParams(-1,-1)); f.setOnClickListener(v->openMovie(i)); return f;
    }

    private View shortcut(String icon,String label,int kind){
        FrameLayout f=new FrameLayout(this); f.setFocusable(true); f.setClickable(true); f.setClipChildren(false);
        Ui.focus(f,this,Ui.round(0xAA142119,7,this),Ui.stroke(0xAA1A2A20,Ui.GREEN,7,this));
        LinearLayout box=Ui.column(this); box.setGravity(Gravity.CENTER); TextView a=Ui.text(this,icon,phone?11:16,Ui.GREEN,true); a.setGravity(Gravity.CENTER); TextView b=Ui.text(this,label,phone?8:10,Color.WHITE,true); b.setGravity(Gravity.CENTER); box.addView(a,new LinearLayout.LayoutParams(-1,0,1)); box.addView(b,new LinearLayout.LayoutParams(-1,0,1)); f.addView(box,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout.LayoutParams pad=new LinearLayout.LayoutParams(0,-1,1); pad.rightMargin=Ui.dp(this,4); f.setLayoutParams(pad);
        f.setOnClickListener(v->{
            if(kind==0){
                Intent in=new Intent(this,LibraryActivity.class);
                in.putExtra("mode","favorites");
                startActivity(in);
            }else if(kind==1){
                openLaunches();
            }else if(kind==2){
                openGenres();
            }else{
                openAll();
            }
        }); return f;
    }

    private View featureCard(ApiClient.Item i){
        FrameLayout f=new FrameLayout(this); f.setFocusable(true); f.setClickable(true); f.setClipChildren(false); Ui.focus(f,this,Ui.round(0x22000000,8,this),Ui.stroke(0x33101010,Ui.GREEN,8,this));
        ImageView p=new ImageView(this); p.setScaleType(ImageView.ScaleType.CENTER_CROP); p.setBackgroundColor(Ui.PANEL_2); ImageLoader.intoPoster(this,p,clean(i.logo,i.backdrop)); f.addView(p,new FrameLayout.LayoutParams(-1,-1));
        View sh=new View(this); sh.setBackground(Ui.gradient(0x00000000,0xE6000000,0,this)); f.addView(sh,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout info=Ui.column(this); info.setGravity(Gravity.BOTTOM); info.setPadding(Ui.dp(this,10),0,Ui.dp(this,8),Ui.dp(this,12));
        TextView n=Ui.text(this,clean(i.name,"Filme"),phone?10:13,Color.WHITE,true); n.setMaxLines(2); info.addView(n,new LinearLayout.LayoutParams(-1,-2));
        long saved=LocalStore.resumePosition(this,i.id);
        String lower=(i.year>0?String.valueOf(i.year):"")+(saved>10000?"  •  ▶ CONTINUAR":"");
        TextView y=Ui.text(this,lower,phone?8:9,saved>10000?Ui.GREEN:0xFFE1E6E2,saved>10000);
        info.addView(y,new LinearLayout.LayoutParams(-1,Ui.dp(this,20)));
        f.addView(info,new FrameLayout.LayoutParams(-1,-1)); f.setOnClickListener(v->openMovie(i)); return f;
    }
    private View emptyCard(){FrameLayout f=new FrameLayout(this);f.setBackground(Ui.round(0xAA101713,8,this));return f;}

    private void loadLatest(){
        ApiClient.catalogPrepared("movie",1,72,"","","",new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){apply(p);} public void error(String m){ApiClient.catalog("movie",1,72,"","","",new ApiClient.Callback<ApiClient.CatalogPage>(){public void ok(ApiClient.CatalogPage p){apply(p);}public void error(String e){}});}
        });
    }
    private void apply(ApiClient.CatalogPage p){runOnUiThread(()->{
        latest.clear();
        if(p!=null&&p.items!=null)latest.addAll(p.items);
        Collections.sort(latest,(a,b)->{
            int ay=a==null?0:a.year,by=b==null?0:b.year;
            if(ay!=by)return Integer.compare(by,ay);
            return Long.compare(b==null?0:b.id,a==null?0:a.id);
        });
        heroIndex=0;
        render();
        startSlider();
        enrichFeaturedBackdrops();
    });}

    private void enrichFeaturedBackdrops(){
        int max=Math.min(5,latest.size());
        for(int n=0;n<max;n++){
            ApiClient.Item i=latest.get(n);
            if(i==null || !clean(i.backdrop,"").isEmpty()) continue;
            ApiClient.tmdbEnrich(i,new ApiClient.Callback<ApiClient.Item>(){
                public void ok(ApiClient.Item full){
                    if(full==null)return;
                    runOnUiThread(()->{
                        if(!clean(full.backdrop,"").isEmpty())i.backdrop=full.backdrop;
                        if(!clean(full.synopsis,"").isEmpty())i.synopsis=full.synopsis;
                        if(full.year>0)i.year=full.year;
                        int current=Math.min(heroIndex,Math.max(0,latest.size()-1));
                        if(!latest.isEmpty() && latest.get(current)==i) render();
                    });
                }
                public void error(String m){}
            });
        }
    }
    private void startSlider(){slider.removeCallbacksAndMessages(null);if(latest.size()<2)return;heroTask=()->{heroIndex=(heroIndex+1)%Math.min(6,latest.size());render();slider.postDelayed(heroTask,5000);};slider.postDelayed(heroTask,5000);}
    private void openLaunches(){
        Intent i=new Intent(this,CatalogActivity.class);
        i.putExtra("type","movie");
        i.putExtra("title","Lançamentos");
        i.putExtra("smart","launch");
        i.putExtra("browse",true);
        startActivity(i);
    }

    private void openGenres(){
        Intent i=new Intent(this,CatalogActivity.class);
        i.putExtra("type","movie");
        i.putExtra("title","Gêneros");
        i.putExtra("browse",true);
        i.putExtra("focus_categories",true);
        startActivity(i);
    }

    private void openAll(){
        Intent i=new Intent(this,CatalogActivity.class);
        i.putExtra("type","movie");
        i.putExtra("title","Todos os Filmes");
        i.putExtra("browse",true);
        startActivity(i);
    }
    private void openMovie(ApiClient.Item i){Intent d=new Intent(this,DetailActivity.class);d.putExtra("type","movie");d.putExtra("id",i.id);d.putExtra("name",i.name);d.putExtra("logo",i.logo);d.putExtra("backdrop",i.backdrop);d.putExtra("year",i.year);d.putExtra("synopsis",i.synopsis);startActivity(d);}
    private static String clean(String a,String b){return a==null||a.trim().isEmpty()?b:a.trim();}
    @Override public void onBackPressed(){AppExit.confirm(this);}
}
