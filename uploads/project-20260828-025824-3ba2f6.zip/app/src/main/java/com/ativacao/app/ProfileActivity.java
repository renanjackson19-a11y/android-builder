package com.ativacao.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class ProfileActivity extends Activity {
    private boolean phone;
    private boolean remoteLoaded=false;
    private String accountTitle="GREEN PLAY • SUA CENTRAL DE ENTRETENIMENTO";
    private String supportWhatsapp="";
    private String aboutText="";
    private boolean showParental=true,showFavorites=true,showUpdate=true,showClearCache=true,showSupport=true,showAbout=true;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);Ui.immersive(this);phone=Ui.phone(this);setContentView(build());loadRemoteConfig();
    }

    private void loadRemoteConfig(){
        ApiClient.appConfig(new ApiClient.Callback<ApiClient.AppStatus>(){
            public void ok(ApiClient.AppStatus st){runOnUiThread(()->{
                accountTitle=clean(st.accountTitle,accountTitle);
                supportWhatsapp=clean(st.supportWhatsapp,"");
                aboutText=clean(st.aboutText,"");
                showParental=st.showParental;showFavorites=st.showFavorites;showUpdate=st.showUpdate;
                showClearCache=st.showClearCache;showSupport=st.showSupport&&!supportWhatsapp.isEmpty();showAbout=st.showAbout&&!aboutText.isEmpty();
                remoteLoaded=true;setContentView(build());
            });}
            public void error(String m){remoteLoaded=true;}
        });
    }

    private View build(){
        LinearLayout page=Ui.column(this);
        page.setBackground(Ui.diagonalGradient(0xFF07160B,0xFF010402,0,this));
        page.addView(YellowNav.bar(this,""),new LinearLayout.LayoutParams(-1,Ui.dp(this,58)));

        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.HORIZONTAL);
        root.setPadding(Ui.dp(this,phone?16:28),Ui.dp(this,6),Ui.dp(this,phone?16:28),Ui.dp(this,6));

        LinearLayout left=Ui.column(this);
        left.setPadding(Ui.dp(this,13),Ui.dp(this,4),Ui.dp(this,13),Ui.dp(this,4));
        left.setBackground(Ui.stroke(0xEE080E09,0xFF203526,14,this));

        String uname=clean(Session.user(this),"Usuário");
        TextView avatar=Ui.text(this,uname.substring(0,1).toUpperCase(),phone?22:28,Color.BLACK,true);
        avatar.setGravity(Gravity.CENTER);avatar.setBackground(Ui.gradient(Ui.GREEN,Ui.GREEN_2,60,this));
        LinearLayout.LayoutParams avp=new LinearLayout.LayoutParams(Ui.dp(this,52),Ui.dp(this,52));avp.gravity=Gravity.CENTER_HORIZONTAL;left.addView(avatar,avp);

        TextView user=Ui.text(this,uname,phone?13:16,Ui.TEXT,true);user.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams ulp=new LinearLayout.LayoutParams(-1,Ui.dp(this,25));ulp.topMargin=Ui.dp(this,2);left.addView(user,ulp);

        sectionLeft(left,"SUA ASSINATURA");
        infoCardLeft(left,"PLANO",clean(Session.plan(this),"Ativo"));
        infoCardLeft(left,"VALIDADE",clean(Session.expires(this),"não informada"));
        infoCardLeft(left,"USUÁRIO",uname);

        TextView switchAcc=smallButton("↻  TROCAR DE CONTA");
        switchAcc.setOnClickListener(v->logoutToLogin());
        addTop(left,switchAcc,7,36);
        TextView exit=smallButton("×  SAIR DA CONTA");
        exit.setOnClickListener(v->logoutToLogin());
        addTop(left,exit,6,36);

        LinearLayout.LayoutParams lpLeft=new LinearLayout.LayoutParams(Ui.dp(this,phone?225:300),-1);
        lpLeft.rightMargin=Ui.dp(this,15);root.addView(left,lpLeft);

        LinearLayout main=Ui.column(this);
        TextView banner=Ui.text(this,accountTitle,phone?15:20,Ui.TEXT,true);
        banner.setGravity(Gravity.CENTER);banner.setBackground(Ui.diagonalGradient(0xFF0C2513,0xFF061109,16,this));
        main.addView(banner,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?58:72)));

        TextView hello=Ui.text(this,"Olá, "+uname+" 👋\nSua assinatura está ativa.",phone?12:15,Ui.TEXT,true);
        hello.setGravity(Gravity.CENTER_VERTICAL);hello.setPadding(Ui.dp(this,15),0,Ui.dp(this,15),0);
        hello.setBackground(Ui.stroke(0xCC101712,0xFF203526,12,this));addTop(main,hello,8,phone?52:62);

        sectionCompact(main,"AÇÕES DA CONTA");
        LinearLayout actions=new LinearLayout(this);
        TextView firstFocus=null;

        if(showParental){
            TextView parental=tile("♙\nCONTROLE PARENTAL",0xFF242B26);
            parental.setOnClickListener(v->startActivity(new Intent(this,ParentalSettingsActivity.class)));
            addTile(actions,parental);if(firstFocus==null)firstFocus=parental;
        }
        if(showFavorites){
            TextView fav=tile("★\nFAVORITOS",0xFF164A27);
            fav.setOnClickListener(v->{Intent i=new Intent(this,LibraryActivity.class);i.putExtra("mode","favorites");startActivity(i);});
            addTile(actions,fav);if(firstFocus==null)firstFocus=fav;
        }
        if(showSupport){
            TextView support=tile("☎\nSUPORTE",0xFF123E20);
            support.setOnClickListener(v->openSupport());
            addTile(actions,support);if(firstFocus==null)firstFocus=support;
        }
        if(actions.getChildCount()>0)main.addView(actions,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?72:88)));

        sectionCompact(main,"CONFIGURAÇÕES");
        LinearLayout config=new LinearLayout(this);
        if(showClearCache){
            TextView cache=tile("⌫\nLIMPAR CACHE",0xFF252B27);
            cache.setOnClickListener(v->{ImageLoader.clear();ApiClient.clearCatalogCache();Toast.makeText(this,"Cache do aplicativo limpo.",Toast.LENGTH_SHORT).show();});
            addTile(config,cache);if(firstFocus==null)firstFocus=cache;
        }
        if(showUpdate){
            TextView update=tile("↻\nATUALIZAR CONTEÚDOS",0xFF252B27);
            update.setOnClickListener(v->startActivity(new Intent(this,ContentRefreshActivity.class)));
            addTile(config,update);if(firstFocus==null)firstFocus=update;
        }
        if(showAbout){
            TextView about=tile("●\nSOBRE NÓS",0xFF252B27);
            about.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Sobre nós").setMessage(aboutText).setPositiveButton("Fechar",null).show());
            addTile(config,about);if(firstFocus==null)firstFocus=about;
        }
        if(config.getChildCount()>0)main.addView(config,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?72:88)));

        root.addView(main,new LinearLayout.LayoutParams(0,-1,1));
        page.addView(root,new LinearLayout.LayoutParams(-1,0,1));
        if(firstFocus!=null)firstFocus.requestFocus();
        return AppBackground.wrap(this,page);
    }

    private void openSupport(){
        String n=supportWhatsapp.replaceAll("[^0-9]","");
        if(n.isEmpty()){Toast.makeText(this,"Suporte não configurado.",Toast.LENGTH_SHORT).show();return;}
        try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/"+n)));}catch(Throwable e){Toast.makeText(this,"Não foi possível abrir o suporte.",Toast.LENGTH_SHORT).show();}
    }

    private void logoutToLogin(){
        Session.clear(this);ApiClient.clearCatalogCache();
        Intent i=new Intent(this,LoginActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);finishAffinity();
    }

    private void sectionLeft(LinearLayout p,String s){TextView t=Ui.text(this,s,9,Ui.MUTED,true);LinearLayout.LayoutParams x=new LinearLayout.LayoutParams(-1,Ui.dp(this,20));x.topMargin=Ui.dp(this,5);p.addView(t,x);}
    private void infoCardLeft(LinearLayout p,String label,String value){TextView t=Ui.text(this,label+"\n"+value,9,Ui.TEXT,false);t.setGravity(Gravity.CENTER_VERTICAL);t.setPadding(Ui.dp(this,6),0,Ui.dp(this,6),0);t.setBackground(Ui.stroke(0xFF0B100C,0xFF1A271D,8,this));addTop(p,t,3,39);}
    private void sectionCompact(LinearLayout p,String s){TextView t=Ui.text(this,s,9,Ui.MUTED,true);LinearLayout.LayoutParams x=new LinearLayout.LayoutParams(-1,Ui.dp(this,25));x.topMargin=Ui.dp(this,8);p.addView(t,x);}
    private TextView smallButton(String s){TextView t=Ui.text(this,s,11,Ui.TEXT,true);t.setGravity(Gravity.CENTER);t.setFocusable(true);t.setClickable(true);Ui.focus(t,this,Ui.round(0xFF151B16,8,this),Ui.stroke(0xFF101511,Ui.GREEN,8,this));return t;}
    private TextView tile(String s,int fill){TextView t=Ui.text(this,s,phone?10:12,Ui.TEXT,true);t.setGravity(Gravity.CENTER);t.setFocusable(true);t.setClickable(true);Ui.focus(t,this,Ui.round(fill,12,this),Ui.stroke(fill,Ui.GREEN,12,this));return t;}
    private void addTile(LinearLayout row,TextView t){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,Ui.dp(this,phone?68:84),1);if(row.getChildCount()>0)p.leftMargin=Ui.dp(this,7);row.addView(t,p);}
    private void addTop(LinearLayout p,View v,int top,int h){LinearLayout.LayoutParams x=new LinearLayout.LayoutParams(-1,Ui.dp(this,h));x.topMargin=Ui.dp(this,top);p.addView(v,x);}
    private String clean(String v,String f){if(v==null)return f;String s=v.trim();return s.isEmpty()||"null".equalsIgnoreCase(s)?f:s;}
    @Override protected void onResume(){super.onResume();Ui.immersive(this);}
}
