package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

public class ContentRefreshActivity extends Activity {
    private TextView title, step;
    private ProgressBar progress;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        Ui.immersive(this);

        LinearLayout root=Ui.column(this);
        root.setGravity(Gravity.CENTER);
        root.setPadding(Ui.dp(this,36),Ui.dp(this,24),Ui.dp(this,36),Ui.dp(this,24));
        root.setBackgroundColor(0xFF020805);

        title=Ui.text(this,"Atualizando conteúdo",Ui.phone(this)?22:30,Color.WHITE,true);
        title.setGravity(Gravity.CENTER);
        root.addView(title,new LinearLayout.LayoutParams(-1,Ui.dp(this,58)));

        step=Ui.text(this,"Sincronizando painel...",Ui.phone(this)?12:15,0xFFC7D0CA,false);
        step.setGravity(Gravity.CENTER);
        root.addView(step,new LinearLayout.LayoutParams(-1,Ui.dp(this,44)));

        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        root.addView(progress,new LinearLayout.LayoutParams(Ui.dp(this,Ui.phone(this)?330:520),Ui.dp(this,10)));

        TextView info=Ui.text(this,
                "Canais, filmes, séries e capas sendo atualizados ao vivo.",
                Ui.phone(this)?10:12,0xFF8D9A92,false);
        info.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,Ui.dp(this,54));
        ip.topMargin=Ui.dp(this,18);
        root.addView(info,ip);

        setContentView(AppBackground.wrap(this,root));
        refreshNow();
    }

    private void refreshNow(){
        ApiClient.setUserToken(Session.token(this));
        ApiClient.setXtreamServer(Session.xtreamHost(this),Session.xtreamUser(this),Session.xtreamPass(this));
        ApiClient.clearCatalogCache();

        final java.util.concurrent.atomic.AtomicInteger done=new java.util.concurrent.atomic.AtomicInteger(0);
        final java.util.concurrent.atomic.AtomicInteger pending=new java.util.concurrent.atomic.AtomicInteger(3);

        refreshType("live","TV ao vivo",done,pending);
        refreshType("movie","Filmes",done,pending);
        refreshType("series","Séries",done,pending);
    }

    private void refreshType(String type,String label,java.util.concurrent.atomic.AtomicInteger done,java.util.concurrent.atomic.AtomicInteger pending){
        ApiClient.catalog(type,1,24,"","","",new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){finishType(label,done,pending);}
            public void error(String m){finishType(label,done,pending);}
        });
    }

    private void finishType(String label,java.util.concurrent.atomic.AtomicInteger done,java.util.concurrent.atomic.AtomicInteger pending){
        int d=done.incrementAndGet();
        runOnUiThread(()->{
            step.setText("Atualizado: "+label);
            progress.setProgress(Math.max(0,Math.min(100,(d*100)/3)));
        });
        if(pending.decrementAndGet()==0){
            runOnUiThread(()->{
                step.setText("Conteúdo atualizado");
                progress.setProgress(100);
                ResumeRefreshManager.completeRefresh();
                new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(()->{
                    Intent i=new Intent(this,MainActivity.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(i);finish();
                },350);
            });
        }
    }

    @Override public void onBackPressed(){
        // Durante a atualização não volta para uma tela com cache antigo.
    }
}
