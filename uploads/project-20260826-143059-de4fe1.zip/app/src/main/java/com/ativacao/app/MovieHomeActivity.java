package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MovieHomeActivity extends Activity {
    private final List<ApiClient.Item> latest = new ArrayList<>();
    private LinearLayout featuredRow;
    private TextView loading;
    private boolean phone;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        Ui.immersive(this);
        phone=Ui.phone(this);
        setContentView(build());
        loadLatest();
    }

    @Override protected void onResume(){
        super.onResume();
        Ui.immersive(this);
    }

    private View build(){
        LinearLayout root=Ui.column(this);
        root.setBackground(Ui.diagonalGradient(0xFF07130A,0xFF010302,0,this));
        root.addView(YellowNav.bar(this,"FILMES"),new LinearLayout.LayoutParams(-1,Ui.dp(this,64)));

        LinearLayout body=Ui.column(this);
        body.setPadding(Ui.dp(this,phone?18:28),Ui.dp(this,phone?10:18),Ui.dp(this,phone?18:28),Ui.dp(this,16));

        LinearLayout heading=new LinearLayout(this);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=Ui.text(this,"Filmes",phone?18:24,Ui.TEXT,true);
        heading.addView(title,new LinearLayout.LayoutParams(0,Ui.dp(this,42),1));
        TextView newest=Ui.text(this,"MAIS RECENTES",phone?10:12,Ui.GREEN,true);
        newest.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        heading.addView(newest,new LinearLayout.LayoutParams(Ui.dp(this,phone?130:170),Ui.dp(this,42)));
        body.addView(heading,new LinearLayout.LayoutParams(-1,Ui.dp(this,46)));

        loading=Ui.text(this,"Preparando lançamentos...",phone?10:12,Ui.MUTED,false);
        loading.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
        body.addView(loading,new LinearLayout.LayoutParams(-1,Ui.dp(this,28)));

        featuredRow=new LinearLayout(this);
        featuredRow.setGravity(Gravity.CENTER_VERTICAL);
        body.addView(featuredRow,new LinearLayout.LayoutParams(-1,0,1));

        root.addView(body,new LinearLayout.LayoutParams(-1,0,1));
        return root;
    }

    private void loadLatest(){
        ApiClient.catalog("movie",1,12,"","","",new ApiClient.Callback<ApiClient.CatalogPage>(){
            @Override public void ok(ApiClient.CatalogPage p){
                runOnUiThread(()->{
                    latest.clear();
                    if(p!=null&&p.items!=null)latest.addAll(p.items);
                    render();
                });
            }
            @Override public void error(String m){
                runOnUiThread(()->{
                    loading.setText("Não foi possível carregar os filmes.");
                    renderMenuOnly();
                });
            }
        });
    }

    private void render(){
        featuredRow.removeAllViews();
        loading.setVisibility(View.GONE);

        int posterCount=Math.min(3,latest.size());
        for(int i=0;i<posterCount;i++){
            ApiClient.Item item=latest.get(i);
            View card=posterCard(item);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,1);
            lp.rightMargin=Ui.dp(this,8);
            featuredRow.addView(card,lp);
        }

        LinearLayout actions=Ui.column(this);
        actions.setGravity(Gravity.CENTER);
        actions.setPadding(Ui.dp(this,3),0,0,0);

        TextView all=actionTile("TODOS","Ver catálogo completo");
        all.setOnClickListener(v->openAll(""));
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,0,1);
        ap.bottomMargin=Ui.dp(this,8);
        actions.addView(all,ap);

        TextView categories=actionTile("CATEGORIAS","Ação • Aventura • Comédia...");
        categories.setOnClickListener(v->openAll(""));
        actions.addView(categories,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout.LayoutParams alp=new LinearLayout.LayoutParams(0,-1,phone?0.90f:0.88f);
        featuredRow.addView(actions,alp);

        if(posterCount>0)featuredRow.getChildAt(0).requestFocus();
    }

    private void renderMenuOnly(){
        featuredRow.removeAllViews();
        LinearLayout actions=Ui.column(this);
        TextView all=actionTile("TODOS","Ver catálogo completo");
        all.setOnClickListener(v->openAll(""));
        actions.addView(all,new LinearLayout.LayoutParams(-1,Ui.dp(this,150)));
        featuredRow.addView(actions,new LinearLayout.LayoutParams(Ui.dp(this,260),-1));
        all.requestFocus();
    }

    private View posterCard(ApiClient.Item i){
        FrameLayout card=new FrameLayout(this);
        card.setFocusable(true);
        card.setClickable(true);
        card.setClipChildren(false);
        Ui.focus(card,this,
                Ui.round(0xFF101612,8,this),
                Ui.stroke(0xFF101612,Ui.GREEN,9,this));

        ImageView img=new ImageView(this);
        img.setScaleType(ImageView.ScaleType.CENTER_CROP);
        img.setBackgroundColor(Ui.PANEL_2);
        ImageLoader.intoPoster(this,img,clean(i.logo,i.backdrop));
        card.addView(img,new FrameLayout.LayoutParams(-1,-1));

        View shade=new View(this);
        shade.setBackground(Ui.verticalGradient(Color.TRANSPARENT,Color.argb(220,0,0,0),0,this));
        FrameLayout.LayoutParams sp=new FrameLayout.LayoutParams(-1,Ui.dp(this,65),Gravity.BOTTOM);
        card.addView(shade,sp);

        LinearLayout info=Ui.column(this);
        info.setPadding(Ui.dp(this,10),0,Ui.dp(this,10),Ui.dp(this,8));
        TextView name=Ui.text(this,clean(i.name,"Filme"),phone?10:12,Color.WHITE,true);
        name.setMaxLines(1);
        TextView year=Ui.text(this,i.year>0?String.valueOf(i.year):"",phone?8:9,0xFFC9D0CB,false);
        info.addView(name,new LinearLayout.LayoutParams(-1,0,1));
        info.addView(year,new LinearLayout.LayoutParams(-1,Ui.dp(this,18)));
        card.addView(info,new FrameLayout.LayoutParams(-1,Ui.dp(this,58),Gravity.BOTTOM));

        card.setOnClickListener(v->{
            Intent d=new Intent(this,DetailActivity.class);
            d.putExtra("type","movie");
            d.putExtra("id",i.id);
            d.putExtra("name",i.name);
            d.putExtra("logo",i.logo);
            d.putExtra("backdrop",i.backdrop);
            d.putExtra("year",i.year);
            d.putExtra("synopsis",i.synopsis);
            startActivity(d);
        });
        return card;
    }

    private TextView actionTile(String title,String sub){
        TextView t=Ui.text(this,title+"\n"+sub,phone?13:16,Color.WHITE,true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(Ui.dp(this,14),Ui.dp(this,10),Ui.dp(this,14),Ui.dp(this,10));
        t.setFocusable(true);
        t.setClickable(true);
        Ui.focus(t,this,
                Ui.gradient(0xFF15361F,0xFF0E2114,14,this),
                Ui.stroke(0xFF142218,Ui.GREEN,14,this));
        return t;
    }

    private void openAll(String cat){
        Intent i=new Intent(this,CatalogActivity.class);
        i.putExtra("type","movie");
        i.putExtra("title","Filmes");
        i.putExtra("category",cat);
        i.putExtra("browse",true);
        startActivity(i);
    }

    private static String clean(String a,String b){
        return a==null||a.trim().isEmpty()?b:a.trim();
    }
}