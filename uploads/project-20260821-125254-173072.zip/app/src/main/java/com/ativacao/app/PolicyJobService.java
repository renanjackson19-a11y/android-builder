package com.ativacao.app;

import android.app.job.JobParameters;
import android.app.job.JobService;

public class PolicyJobService extends JobService {
    @Override public boolean onStartJob(JobParameters params) {
        new Thread(() -> {
            try {
                android.content.Context app = getApplicationContext();
                PolicySync.sync(app);
                if (LauncherStore.isActivationComplete(app) && LauncherStore.isTvBoxMode(app)) {
                    if (DeviceControl.isDeviceOwner(app)) DeviceControl.enforceManagedState(app);
                    else DeviceControl.enforceHomeBestEffort(app);
                }
            } finally { jobFinished(params, false); }
        }, "unitv-policy-sync").start();
        return true;
    }
    @Override public boolean onStopJob(JobParameters params) { return true; }
}
