package com.ativacao.app;

import android.app.Activity;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/** Pré-carrega o que o usuário abre logo depois do login. */
final class CatalogPreloader {
    private static volatile boolean running=false;
    private static volatile boolean ready=false;
    private static volatile long lastRun=0L;

    static boolean isReady(){ return ready; }

    static void start(Activity a, boolean force, Runnable done){
        if(a==null){ if(done!=null)done.run(); return; }
        long now=System.currentTimeMillis();
        if(!force && ready && now-lastRun<8L*60L*1000L){ if(done!=null)done.run(); return; }
        if(running){ if(done!=null)done.run(); return; }
        running=true;
        if(force) ApiClient.clearCatalogCache();

        // Somente catálogos principais na etapa crítica do login.
        // Todos rodam em paralelo e ficam no cache por usuário/token.
        final List<String[]> jobs=Arrays.asList(
            new String[]{"live",""},
            new String[]{"movie",""},
            new String[]{"series",""},
            new String[]{"live","adult"},
            new String[]{"movie","adult"},
            new String[]{"series","adult"}
        );

        AtomicInteger pending=new AtomicInteger(jobs.size()+1);
        for(String[] job:jobs){
            String type=job[0], smart=job[1];
            int limit="live".equals(type)?72:60;
            ApiClient.catalog(type,1,limit,"","",smart,new ApiClient.Callback<ApiClient.CatalogPage>(){
                public void ok(ApiClient.CatalogPage p){ warmImages(a,p); finishOne(pending,a,done); }
                public void error(String m){ finishOne(pending,a,done); }
            });
        }
        ApiClient.hotCategories(new ApiClient.Callback<List<ApiClient.HotCategory>>(){
            public void ok(List<ApiClient.HotCategory> x){ finishOne(pending,a,done); }
            public void error(String m){ finishOne(pending,a,done); }
        });
    }

    private static void finishOne(AtomicInteger pending,Activity a,Runnable done){
        if(pending.decrementAndGet()!=0)return;
        running=false;ready=true;lastRun=System.currentTimeMillis();
        if(done!=null)done.run();
        // Conteúdo secundário continua aquecendo sem segurar a entrada no app.
        backgroundWarm(a);
    }

    private static void backgroundWarm(Activity a){
        String[][] jobs={
            {"movie","kids"},{"series","kids"},{"movie","anime"},{"series","anime"}
        };
        for(String[] j:jobs){
            ApiClient.catalog(j[0],1,48,"","",j[1],new ApiClient.Callback<ApiClient.CatalogPage>(){
                public void ok(ApiClient.CatalogPage p){ warmImages(a,p); }
                public void error(String m){}
            });
        }
    }

    private static void warmImages(Activity a,ApiClient.CatalogPage p){
        if(p==null)return;
        int max=Math.min(p.items.size(),28);
        for(int n=0;n<max;n++){
            ApiClient.Item i=p.items.get(n); if(i==null)continue;
            ImageLoader.preload(a,clean(i.logo,i.backdrop));
            ImageLoader.preload(a,clean(i.backdrop,i.logo));
            // TMDB não bloqueia o pré-carregamento principal.
            if(("movie".equals(i.type)||"series".equals(i.type))&&!i.tmdbLoaded){
                ApiClient.tmdbEnrich(i,new ApiClient.Callback<ApiClient.Item>(){
                    public void ok(ApiClient.Item x){ImageLoader.preload(a,clean(x.logo,x.backdrop));ImageLoader.preload(a,clean(x.backdrop,x.logo));}
                    public void error(String m){}
                });
            }
        }
    }

    private static String clean(String a,String b){
        String x=a==null?"":a.trim();
        return x.isEmpty()?(b==null?"":b.trim()):x;
    }
}
