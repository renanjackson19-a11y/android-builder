package com.ativacao.app;

import java.util.ArrayList;
import java.util.List;

final class OpenGameCatalog {
    interface Callback{void ok(List<Game> data);void error(String msg);}
    static class Game{
        String name="",platform="",coverRes="",synopsis="",mode="";
        Game(String m,String n,String p,String c,String s){mode=m;name=n;platform=p;coverRes=c;synopsis=s;}
    }
    static void load(String mode,Callback cb){
        ArrayList<Game> all=new ArrayList<>();

        all.add(new Game("retro","Super Mario Bros.","NES","game_retro_00_super_mario_bros","Super Mario Bros. • NES. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("retro","Sonic the Hedgehog","Mega Drive","game_retro_01_sonic_the_hedgehog","Sonic the Hedgehog • Mega Drive. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("retro","Street Fighter II","SNES","game_retro_02_street_fighter_ii","Street Fighter II • SNES. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("retro","Mortal Kombat II","SNES","game_retro_03_mortal_kombat_ii","Mortal Kombat II • SNES. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("retro","Mega Man X","SNES","game_retro_04_mega_man_x","Mega Man X • SNES. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("retro","Donkey Kong Country","SNES","game_retro_05_donkey_kong_country","Donkey Kong Country • SNES. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("retro","Castlevania: Symphony of the Night","PS1","game_retro_06_castlevania_symphony_of_the_night","Castlevania: Symphony of the Night • PS1. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("retro","Crash Bandicoot","PS1","game_retro_07_crash_bandicoot","Crash Bandicoot • PS1. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("retro","Metal Slug","Arcade","game_retro_08_metal_slug","Metal Slug • Arcade. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("retro","The King of Fighters '98","Arcade","game_retro_09_the_king_of_fighters_98","The King of Fighters '98 • Arcade. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("retro","Contra","NES","game_retro_10_contra","Contra • NES. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("retro","Pac-Man","Arcade","game_retro_11_pac_man","Pac-Man • Arcade. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("ps2","Grand Theft Auto: San Andreas","PlayStation 2","game_ps2_00_grand_theft_auto_san_andreas","Grand Theft Auto: San Andreas • PlayStation 2. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("ps2","God of War","PlayStation 2","game_ps2_01_god_of_war","God of War • PlayStation 2. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("ps2","God of War II","PlayStation 2","game_ps2_02_god_of_war_ii","God of War II • PlayStation 2. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("ps2","Gran Turismo 4","PlayStation 2","game_ps2_03_gran_turismo_4","Gran Turismo 4 • PlayStation 2. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("ps2","Shadow of the Colossus","PlayStation 2","game_ps2_04_shadow_of_the_colossus","Shadow of the Colossus • PlayStation 2. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("ps2","Resident Evil 4","PlayStation 2","game_ps2_05_resident_evil_4","Resident Evil 4 • PlayStation 2. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("ps2","Bully","PlayStation 2","game_ps2_06_bully","Bully • PlayStation 2. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("ps2","Need for Speed: Most Wanted","PlayStation 2","game_ps2_07_need_for_speed_most_wanted","Need for Speed: Most Wanted • PlayStation 2. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("ps2","Dragon Ball Z: Budokai Tenkaichi 3","PlayStation 2","game_ps2_08_dragon_ball_z_budokai_tenkaichi_3","Dragon Ball Z: Budokai Tenkaichi 3 • PlayStation 2. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("ps2","Black","PlayStation 2","game_ps2_09_black","Black • PlayStation 2. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("ps2","Guitar Hero II","PlayStation 2","game_ps2_10_guitar_hero_ii","Guitar Hero II • PlayStation 2. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("ps2","Tekken 5","PlayStation 2","game_ps2_11_tekken_5","Tekken 5 • PlayStation 2. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("ds","Mario Kart DS","Nintendo DS","game_ds_00_mario_kart_ds","Mario Kart DS • Nintendo DS. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("ds","New Super Mario Bros.","Nintendo DS","game_ds_01_new_super_mario_bros","New Super Mario Bros. • Nintendo DS. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("ds","Pokémon HeartGold","Nintendo DS","game_ds_02_pok_mon_heartgold","Pokémon HeartGold • Nintendo DS. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("ds","Pokémon SoulSilver","Nintendo DS","game_ds_03_pok_mon_soulsilver","Pokémon SoulSilver • Nintendo DS. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("ds","Pokémon Platinum","Nintendo DS","game_ds_04_pok_mon_platinum","Pokémon Platinum • Nintendo DS. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("ds","The Legend of Zelda: Phantom Hourglass","Nintendo DS","game_ds_05_the_legend_of_zelda_phantom_hourglass","The Legend of Zelda: Phantom Hourglass • Nintendo DS. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("ds","Animal Crossing: Wild World","Nintendo DS","game_ds_06_animal_crossing_wild_world","Animal Crossing: Wild World • Nintendo DS. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("ds","Kirby Super Star Ultra","Nintendo DS","game_ds_07_kirby_super_star_ultra","Kirby Super Star Ultra • Nintendo DS. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("ds","Mario & Luigi: Bowser's Inside Story","Nintendo DS","game_ds_08_mario_luigi_bowser_s_inside_story","Mario & Luigi: Bowser's Inside Story • Nintendo DS. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("ds","Sonic Rush","Nintendo DS","game_ds_09_sonic_rush","Sonic Rush • Nintendo DS. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("ds","Professor Layton and the Curious Village","Nintendo DS","game_ds_10_professor_layton_and_the_curious_village","Professor Layton and the Curious Village • Nintendo DS. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("ds","Chrono Trigger","Nintendo DS","game_ds_11_chrono_trigger","Chrono Trigger • Nintendo DS. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("3ds","Mario Kart 7","Nintendo 3DS","game_3ds_00_mario_kart_7","Mario Kart 7 • Nintendo 3DS. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("3ds","Super Mario 3D Land","Nintendo 3DS","game_3ds_01_super_mario_3d_land","Super Mario 3D Land • Nintendo 3DS. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("3ds","The Legend of Zelda: A Link Between Worlds","Nintendo 3DS","game_3ds_02_the_legend_of_zelda_a_link_between_worlds","The Legend of Zelda: A Link Between Worlds • Nintendo 3DS. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("3ds","Pokémon X","Nintendo 3DS","game_3ds_03_pok_mon_x","Pokémon X • Nintendo 3DS. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("3ds","Pokémon Y","Nintendo 3DS","game_3ds_04_pok_mon_y","Pokémon Y • Nintendo 3DS. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("3ds","Pokémon Omega Ruby","Nintendo 3DS","game_3ds_05_pok_mon_omega_ruby","Pokémon Omega Ruby • Nintendo 3DS. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("3ds","Pokémon Alpha Sapphire","Nintendo 3DS","game_3ds_06_pok_mon_alpha_sapphire","Pokémon Alpha Sapphire • Nintendo 3DS. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("3ds","Animal Crossing: New Leaf","Nintendo 3DS","game_3ds_07_animal_crossing_new_leaf","Animal Crossing: New Leaf • Nintendo 3DS. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("3ds","Luigi's Mansion: Dark Moon","Nintendo 3DS","game_3ds_08_luigi_s_mansion_dark_moon","Luigi's Mansion: Dark Moon • Nintendo 3DS. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("3ds","Super Smash Bros. for Nintendo 3DS","Nintendo 3DS","game_3ds_09_super_smash_bros_for_nintendo_3ds","Super Smash Bros. for Nintendo 3DS • Nintendo 3DS. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("3ds","Metroid: Samus Returns","Nintendo 3DS","game_3ds_10_metroid_samus_returns","Metroid: Samus Returns • Nintendo 3DS. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        all.add(new Game("3ds","Kirby: Planet Robobot","Nintendo 3DS","game_3ds_11_kirby_planet_robobot","Kirby: Planet Robobot • Nintendo 3DS. Item de catálogo; nenhuma ROM é incluída no aplicativo."));
        ArrayList<Game> out=new ArrayList<>();
        for(Game g:all){
            if("retro".equals(mode)){
                if("retro".equals(g.mode)) out.add(g);
            }else if(mode.equals(g.mode)) out.add(g);
        }
        cb.ok(out);
    }
}