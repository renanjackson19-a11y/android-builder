package com.ativacao.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public class GamePlayerActivity extends Activity {
    private WebView web;
    private String name,url,controls;
    private boolean phone;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        Ui.immersive(this);
        phone=Ui.phone(this);
        name=getIntent().getStringExtra("name");
        url=getIntent().getStringExtra("url");
        controls=getIntent().getStringExtra("controls");
        setContentView(build());
        if(url!=null&&!url.isEmpty())web.loadUrl(url);
    }

    private View build(){
        FrameLayout root=new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        web=new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        web.setFocusable(true);
        web.setFocusableInTouchMode(true);

        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);

        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient(){
            @Override public void onPageFinished(WebView view,String u){
                installBridge();
                view.requestFocus();
            }
        });
        root.addView(web,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout top=new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(Ui.dp(this,12),0,Ui.dp(this,12),0);
        top.setBackgroundColor(0xB8000000);

        TextView title=Ui.text(this,(name==null?"JOGO":name)+"  •  "+(phone?"Controle na tela":"Controle remoto"),10,Color.WHITE,true);
        top.addView(title,new LinearLayout.LayoutParams(0,-1,1));

        TextView start=Ui.button(this,"START");
        start.setOnClickListener(v->startAction());
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(Ui.dp(this,105),Ui.dp(this,38));
        sp.rightMargin=Ui.dp(this,8);
        top.addView(start,sp);

        TextView exit=Ui.button(this,"SAIR");
        exit.setOnClickListener(v->finish());
        top.addView(exit,new LinearLayout.LayoutParams(Ui.dp(this,90),Ui.dp(this,38)));

        FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(-1,Ui.dp(this,52),Gravity.TOP);
        root.addView(top,tp);

        if(phone)addTouchControls(root);
        web.requestFocus();
        return root;
    }

    private void installBridge(){
        if(web==null)return;
        String js="(function(){"+
                "window.__dpTargets=function(){var a=[window,document,document.body,document.activeElement];"+
                "var c=document.querySelector('canvas');if(c)a.push(c);return a.filter(Boolean);};"+
                "window.__dpSend=function(type,key,code,keyCode){"+
                "window.__dpTargets().forEach(function(t){try{var e=new KeyboardEvent(type,{key:key,code:code,bubbles:true,cancelable:true,keyCode:keyCode,which:keyCode});"+
                "try{Object.defineProperty(e,'keyCode',{get:function(){return keyCode;}});Object.defineProperty(e,'which',{get:function(){return keyCode;}});}catch(x){}"+
                "t.dispatchEvent(e);}catch(x){}});};"+
                "window.__dpClickStart=function(){var xs=[].slice.call(document.querySelectorAll('button,a,[role=button],input[type=button],input[type=submit]'));"+
                "var r=/start|new game|play|restart|begin|jogar|iniciar/i;for(var i=0;i<xs.length;i++){var tx=(xs[i].innerText||xs[i].value||'').trim();if(r.test(tx)){try{xs[i].click();return true;}catch(e){}}}return false;};"+
                "})();";
        web.evaluateJavascript(js,null);
    }

    private String eventJs(String type,String key,String code,int keyCode){
        return "try{if(window.__dpSend)window.__dpSend('"+type+"','"+key+"','"+code+"',"+keyCode+");}catch(e){}";
    }

    private void eval(String js){if(web!=null)web.evaluateJavascript(js,null);}

    private void direction(String dir,boolean down){
        String type=down?"keydown":"keyup";
        if("up".equals(dir)){
            eval(eventJs(type,"ArrowUp","ArrowUp",38)+eventJs(type,"w","KeyW",87)+eventJs(type,"W","KeyW",87));
        }else if("down".equals(dir)){
            eval(eventJs(type,"ArrowDown","ArrowDown",40)+eventJs(type,"s","KeyS",83)+eventJs(type,"S","KeyS",83));
        }else if("left".equals(dir)){
            eval(eventJs(type,"ArrowLeft","ArrowLeft",37)+eventJs(type,"a","KeyA",65)+eventJs(type,"A","KeyA",65));
        }else if("right".equals(dir)){
            eval(eventJs(type,"ArrowRight","ArrowRight",39)+eventJs(type,"d","KeyD",68)+eventJs(type,"D","KeyD",68));
        }
    }

    private void actionA(boolean down){
        String type=down?"keydown":"keyup";
        eval(eventJs(type,"Enter","Enter",13)+
             eventJs(type," ","Space",32)+
             eventJs(type,"z","KeyZ",90)+
             eventJs(type,"Z","KeyZ",90));
        if(down)eval("try{if(window.__dpClickStart)window.__dpClickStart();}catch(e){}");
    }

    private void actionB(boolean down){
        String type=down?"keydown":"keyup";
        eval(eventJs(type,"x","KeyX",88)+
             eventJs(type,"X","KeyX",88)+
             eventJs(type,"Escape","Escape",27));
    }

    private void startAction(){
        actionA(true);
        if(web!=null)web.postDelayed(()->actionA(false),120);
    }

    private void addTouchControls(FrameLayout root){
        int size=Ui.dp(this,phone?54:62);

        LinearLayout dpad=Ui.column(this);
        dpad.setGravity(Gravity.CENTER);
        dpad.addView(touchDir("▲","up"),new LinearLayout.LayoutParams(size,size));
        LinearLayout mid=new LinearLayout(this);
        mid.setGravity(Gravity.CENTER);
        mid.addView(touchDir("◀","left"),new LinearLayout.LayoutParams(size,size));
        mid.addView(touchDir("▼","down"),new LinearLayout.LayoutParams(size,size));
        mid.addView(touchDir("▶","right"),new LinearLayout.LayoutParams(size,size));
        dpad.addView(mid,new LinearLayout.LayoutParams(size*3,size));

        FrameLayout.LayoutParams dp=new FrameLayout.LayoutParams(size*3,size*2,Gravity.LEFT|Gravity.BOTTOM);
        dp.leftMargin=Ui.dp(this,16);dp.bottomMargin=Ui.dp(this,16);
        root.addView(dpad,dp);

        LinearLayout actions=Ui.column(this);
        actions.setGravity(Gravity.CENTER);

        LinearLayout ab=new LinearLayout(this);ab.setGravity(Gravity.CENTER);
        TextView b=touchAction("B",false);
        TextView a=touchAction("A",true);
        ab.addView(b,new LinearLayout.LayoutParams(size,size));
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(size,size);ap.leftMargin=Ui.dp(this,12);
        ab.addView(a,ap);
        actions.addView(ab,new LinearLayout.LayoutParams(size*2+Ui.dp(this,12),size));

        TextView st=Ui.button(this,"START");
        st.setOnClickListener(v->startAction());
        LinearLayout.LayoutParams stp=new LinearLayout.LayoutParams(size*2+Ui.dp(this,12),Ui.dp(this,42));
        stp.topMargin=Ui.dp(this,8);
        actions.addView(st,stp);

        FrameLayout.LayoutParams ac=new FrameLayout.LayoutParams(size*2+Ui.dp(this,12),size+Ui.dp(this,50),Gravity.RIGHT|Gravity.BOTTOM);
        ac.rightMargin=Ui.dp(this,22);ac.bottomMargin=Ui.dp(this,18);
        root.addView(actions,ac);
    }

    private TextView touchDir(String label,String dir){
        TextView v=roundButton(label);
        v.setOnTouchListener((x,e)->{
            if(e.getAction()==MotionEvent.ACTION_DOWN){direction(dir,true);return true;}
            if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL){direction(dir,false);return true;}
            return true;
        });
        return v;
    }

    private TextView touchAction(String label,boolean a){
        TextView v=roundButton(label);
        v.setOnTouchListener((x,e)->{
            boolean down=e.getAction()==MotionEvent.ACTION_DOWN;
            if(down||(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL)){
                if(a)actionA(down);else actionB(down);
                return true;
            }
            return true;
        });
        return v;
    }

    private TextView roundButton(String label){
        TextView v=Ui.text(this,label,18,Color.WHITE,true);
        v.setGravity(Gravity.CENTER);
        v.setBackground(Ui.stroke(0xAA111111,Ui.GREEN,30,this));
        return v;
    }

    @Override public boolean onKeyDown(int keyCode,KeyEvent event){
        switch(keyCode){
            case KeyEvent.KEYCODE_DPAD_UP:direction("up",true);return true;
            case KeyEvent.KEYCODE_DPAD_DOWN:direction("down",true);return true;
            case KeyEvent.KEYCODE_DPAD_LEFT:direction("left",true);return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT:direction("right",true);return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_BUTTON_A:actionA(true);return true;
            case KeyEvent.KEYCODE_BUTTON_B:actionB(true);return true;
            case KeyEvent.KEYCODE_MENU:startAction();return true;
            case KeyEvent.KEYCODE_BACK:finish();return true;
        }
        return super.onKeyDown(keyCode,event);
    }

    @Override public boolean onKeyUp(int keyCode,KeyEvent event){
        switch(keyCode){
            case KeyEvent.KEYCODE_DPAD_UP:direction("up",false);return true;
            case KeyEvent.KEYCODE_DPAD_DOWN:direction("down",false);return true;
            case KeyEvent.KEYCODE_DPAD_LEFT:direction("left",false);return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT:direction("right",false);return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_BUTTON_A:actionA(false);return true;
            case KeyEvent.KEYCODE_BUTTON_B:actionB(false);return true;
        }
        return super.onKeyUp(keyCode,event);
    }

    @Override protected void onResume(){super.onResume();Ui.immersive(this);if(web!=null){web.onResume();web.requestFocus();}}
    @Override protected void onPause(){if(web!=null)web.onPause();super.onPause();}
    @Override protected void onDestroy(){if(web!=null){web.stopLoading();web.destroy();web=null;}super.onDestroy();}
}
