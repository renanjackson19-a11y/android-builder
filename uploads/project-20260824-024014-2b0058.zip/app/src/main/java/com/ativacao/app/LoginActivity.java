package com.ativacao.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public class LoginActivity extends Activity {
    private EditText user,pass;private TextView message,serverBadge,enter;private boolean phone;
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);Ui.immersive(this);if(Session.isLogged(this)){openHome();return;}phone=Ui.phone(this);setContentView(build());checkServer();}
    @Override protected void onResume(){super.onResume();Ui.immersive(this);}
    private View build(){
        FrameLayout root=new FrameLayout(this);root.setBackground(makeBackground());
        LinearLayout shell=new LinearLayout(this);shell.setOrientation(LinearLayout.HORIZONTAL);shell.setPadding(Ui.dp(this,phone?18:34),Ui.dp(this,phone?14:26),Ui.dp(this,phone?18:34),Ui.dp(this,phone?14:26));root.addView(shell,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout brand=Ui.column(this);brand.setGravity(Gravity.CENTER_VERTICAL);brand.setPadding(Ui.dp(this,phone?18:34),Ui.dp(this,10),Ui.dp(this,phone?22:42),Ui.dp(this,10));
        TextView kicker=Ui.text(this,"DUBAI PLAY",phone?12:14,Ui.GREEN,true);brand.addView(kicker,new LinearLayout.LayoutParams(-1,Ui.dp(this,30)));
        TextView title=Ui.text(this,"TV, filmes e séries\nsem complicação.",phone?28:40,Color.WHITE,true);title.setLineSpacing(0,1.0f);brand.addView(title,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?90:118)));
        TextView sub=Ui.text(this,"Sua experiência de entretenimento em uma interface rápida, organizada por categorias e preparada para TV Box.",phone?11:13,Color.rgb(181,188,199),false);sub.setMaxLines(3);brand.addView(sub,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?70:78)));
        LinearLayout features=new LinearLayout(this);features.setGravity(Gravity.CENTER_VERTICAL);String[] fs={"TV AO VIVO","FILMES","SÉRIES","EPG"};for(String f:fs){TextView v=Ui.text(this,f,9,Ui.TEXT,true);v.setGravity(Gravity.CENTER);v.setBackground(Ui.stroke(Color.argb(130,20,25,32),Ui.BORDER,10,this));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,Ui.dp(this,38),1);p.rightMargin=Ui.dp(this,6);features.addView(v,p);}brand.addView(features,new LinearLayout.LayoutParams(-1,Ui.dp(this,44)));
        TextView device=Ui.text(this,"APARELHO  "+DeviceInfo.macOrId(this),9,Ui.MUTED,false);LinearLayout.LayoutParams dp=new LinearLayout.LayoutParams(-1,Ui.dp(this,32));dp.topMargin=Ui.dp(this,10);brand.addView(device,dp);
        shell.addView(brand,new LinearLayout.LayoutParams(0,-1,1.12f));

        LinearLayout cardArea=Ui.column(this);cardArea.setGravity(Gravity.CENTER);LinearLayout card=Ui.column(this);card.setPadding(Ui.dp(this,phone?22:30),Ui.dp(this,phone?20:26),Ui.dp(this,phone?22:30),Ui.dp(this,phone?20:24));card.setBackground(Ui.stroke(Color.argb(238,9,12,17),Color.rgb(40,50,44),18,this));
        LinearLayout badgeRow=new LinearLayout(this);badgeRow.setGravity(Gravity.CENTER_VERTICAL);TextView small=Ui.text(this,"ACESSO DUBAI PLAY",9,Ui.MUTED,true);badgeRow.addView(small,new LinearLayout.LayoutParams(0,Ui.dp(this,24),1));serverBadge=Ui.text(this,"● VERIFICANDO",9,Ui.GOLD,true);serverBadge.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);badgeRow.addView(serverBadge,new LinearLayout.LayoutParams(Ui.dp(this,145),Ui.dp(this,24)));card.addView(badgeRow,new LinearLayout.LayoutParams(-1,Ui.dp(this,26)));
        TextView loginTitle=Ui.text(this,"Entre na sua conta",phone?22:28,Ui.TEXT,true);card.addView(loginTitle,new LinearLayout.LayoutParams(-1,Ui.dp(this,48)));TextView desc=Ui.text(this,"Use seu usuário e sua senha para entrar.",10,Ui.MUTED,false);card.addView(desc,new LinearLayout.LayoutParams(-1,Ui.dp(this,34)));
        card.addView(Ui.text(this,"Usuário",10,Ui.TEXT,true),new LinearLayout.LayoutParams(-1,Ui.dp(this,24)));user=field("Digite seu usuário",false);card.addView(user,new LinearLayout.LayoutParams(-1,Ui.dp(this,48)));TextView pl=Ui.text(this,"Senha",10,Ui.TEXT,true);LinearLayout.LayoutParams plp=new LinearLayout.LayoutParams(-1,Ui.dp(this,24));plp.topMargin=Ui.dp(this,8);card.addView(pl,plp);pass=field("Digite sua senha",true);card.addView(pass,new LinearLayout.LayoutParams(-1,Ui.dp(this,48)));
        enter=Ui.primaryButton(this,"ENTRAR");LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,Ui.dp(this,46));ep.topMargin=Ui.dp(this,14);card.addView(enter,ep);TextView test=Ui.button(this,"TESTAR CONEXÃO");LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,Ui.dp(this,42));tp.topMargin=Ui.dp(this,8);card.addView(test,tp);message=Ui.text(this,"",10,Ui.MUTED,false);message.setGravity(Gravity.CENTER);LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,Ui.dp(this,32));mp.topMargin=Ui.dp(this,4);card.addView(message,mp);
        cardArea.addView(card,new LinearLayout.LayoutParams(-1,-2));LinearLayout.LayoutParams cap=new LinearLayout.LayoutParams(0,-1,0.88f);cap.leftMargin=Ui.dp(this,phone?10:24);shell.addView(cardArea,cap);
        enter.setOnClickListener(v->doLogin());test.setOnClickListener(v->showDiagnostic());pass.setOnEditorActionListener((v,a,e)->{doLogin();return true;});user.requestFocus();return root;
    }
    private EditText field(String hint,boolean password){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(Color.rgb(105,112,126));e.setTextColor(Ui.TEXT);e.setTextSize(phone?12:14);e.setSingleLine(true);e.setPadding(Ui.dp(this,14),0,Ui.dp(this,14),0);e.setBackground(Ui.stroke(Ui.PANEL_2,Ui.BORDER,12,this));if(password)e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);e.setOnFocusChangeListener((v,f)->e.setBackground(Ui.stroke(Ui.PANEL_2,f?Ui.GREEN:Ui.BORDER,12,this)));return e;}
    private GradientDrawable makeBackground(){return new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(45,4,10),Color.rgb(20,3,7),Color.rgb(8,2,4)});}
    private void doLogin(){String u=user.getText().toString().trim(),p=pass.getText().toString();if(u.isEmpty()||p.isEmpty()){message.setText("Informe usuário e senha.");message.setTextColor(Ui.RED);return;}enter.setEnabled(false);enter.setText("ENTRANDO...");message.setText("Validando acesso...");message.setTextColor(Ui.MUTED);ApiClient.login(u,p,DeviceInfo.macOrId(this),new ApiClient.Callback<ApiClient.LoginResult>(){public void ok(ApiClient.LoginResult r){runOnUiThread(()->{Session.save(LoginActivity.this,r.username,r.expiresAt,r.plan);openHome();});}public void error(String m){runOnUiThread(()->{enter.setEnabled(true);enter.setText("ENTRAR");message.setText(m);message.setTextColor(Ui.RED);});}});}
    private void checkServer(){ApiClient.status(new ApiClient.Callback<String>(){public void ok(String s){runOnUiThread(()->{serverBadge.setText("● SERVIDOR ONLINE");serverBadge.setTextColor(Ui.GREEN);});}public void error(String m){runOnUiThread(()->{serverBadge.setText("● SERVIDOR OFFLINE");serverBadge.setTextColor(Ui.RED);});}});}
    private boolean hasNetwork(){try{ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);NetworkInfo n=cm==null?null:cm.getActiveNetworkInfo();return n!=null&&n.isConnected();}catch(Throwable e){return false;}}
    private void showDiagnostic(){final Dialog d=new Dialog(this);d.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout box=Ui.column(this);box.setPadding(Ui.dp(this,24),Ui.dp(this,20),Ui.dp(this,24),Ui.dp(this,20));box.setBackground(Ui.stroke(Ui.PANEL,Ui.BORDER,18,this));TextView t=Ui.text(this,"Diagnóstico de rede",18,Ui.TEXT,true);t.setGravity(Gravity.CENTER);box.addView(t,new LinearLayout.LayoutParams(-1,Ui.dp(this,40)));LinearLayout steps=new LinearLayout(this);steps.setGravity(Gravity.CENTER);TextView a=step("BOX",Ui.GREEN),b=step("REDE",hasNetwork()?Ui.GREEN:Ui.RED),c=step("INTERNET",hasNetwork()?Ui.GREEN:Ui.RED),s=step("SERVIDOR",Ui.MUTED);for(TextView v:new TextView[]{a,b,c,s}){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(Ui.dp(this,95),Ui.dp(this,60));p.leftMargin=Ui.dp(this,5);p.rightMargin=Ui.dp(this,5);steps.addView(v,p);}box.addView(steps,new LinearLayout.LayoutParams(-1,Ui.dp(this,72)));TextView result=Ui.text(this,"Testando servidor...",11,Ui.MUTED,true);result.setGravity(Gravity.CENTER);box.addView(result,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));TextView close=Ui.button(this,"FECHAR");close.setOnClickListener(v->d.dismiss());box.addView(close,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));d.setContentView(box);Window w=d.getWindow();d.show();if(w!=null){w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));w.setLayout(Math.min(Ui.dp(this,520),getResources().getDisplayMetrics().widthPixels-Ui.dp(this,24)),WindowManager.LayoutParams.WRAP_CONTENT);}ApiClient.status(new ApiClient.Callback<String>(){public void ok(String x){runOnUiThread(()->{s.setTextColor(Ui.GREEN);result.setText("✓ Servidor online e acessível");result.setTextColor(Ui.GREEN);});}public void error(String m){runOnUiThread(()->{s.setTextColor(Ui.RED);result.setText("Falha: "+m);result.setTextColor(Ui.RED);});}});}
    private TextView step(String txt,int color){TextView v=Ui.text(this,"●\n"+txt,10,color,true);v.setGravity(Gravity.CENTER);v.setBackground(Ui.stroke(Color.rgb(12,16,20),color,11,this));return v;}
    private void openHome(){
        Intent in=new Intent(this,LiveTvActivity.class);
        in.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(in);
        finish();
    }
}
