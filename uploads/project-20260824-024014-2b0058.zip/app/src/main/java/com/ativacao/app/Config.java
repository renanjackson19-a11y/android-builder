package com.ativacao.app;

public final class Config {
    private Config() {}

    public static final String API_BASE_URL = "https://" + host() + "/api/";
    public static final String APP_TOKEN = token();

    private static String host() {
        char[] c = new char[]{'d','u','b','a','i','p','l','a','y','.','s','h','o','p'};
        return new String(c);
    }
    private static String token() {
        return "CTAdcb_" + "S0Y7Sjnpx7w3F8c" + "-v7rW6sA9lxkhkcvVAWuQ";
    }
}
