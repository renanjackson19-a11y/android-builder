package com.ativacao.app;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

final class FreeFootballSource {
    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    private static final String BASE = "https://site.api.espn.com";
    private static final Object LOCK = new Object();
    private static final ArrayList<ApiClient.FootballMatch> CACHE = new ArrayList<>();
    private static final ArrayList<ApiClient.Callback<List<ApiClient.FootballMatch>>> WAITERS = new ArrayList<>();
    private static String cacheDay = "";
    private static boolean loading = false;

    private static final String[] LEAGUES = {
        "fifa.world","fifa.wwc","fifa.world.u20","fifa.world.u17","fifa.cwc",
        "fifa.friendly","fifa.friendly.w","fifa.friendly_u21","fifa.u20.friendly",
        "fifa.olympics","fifa.w.olympics","fifa.worldq","fifa.worldq.uefa",
        "fifa.worldq.caf","fifa.worldq.afc","fifa.worldq.concacaf",
        "fifa.worldq.conmebol","fifa.worldq.ofc",
        "uefa.champions","uefa.champions_qual","uefa.europa","uefa.europa_qual",
        "uefa.europa.conf","uefa.europa.conf_qual","uefa.super_cup","uefa.wchampions",
        "uefa.euro","uefa.euroq","uefa.weuro","uefa.euro_u21",
        "uefa.euro_u21_qual","uefa.euro.u19","uefa.nations","uefa.w.nations",
        "eng.1","eng.2","eng.3","eng.4","eng.5","eng.fa","eng.league_cup",
        "eng.trophy","eng.charity","eng.w.1","eng.w.fa",
        "esp.1","esp.2","esp.copa_del_rey","esp.super_cup","esp.w.1","esp.copa_de_la_reina",
        "ger.1","ger.2","ger.dfb_pokal","ger.super_cup","ger.playoff.relegation","ger.2.promotion.relegation",
        "ita.1","ita.2","ita.coppa_italia","ita.super_cup",
        "fra.1","fra.2","fra.coupe_de_france","fra.super_cup","fra.w.1",
        "ned.1","ned.2","ned.3","ned.cup","ned.supercup","ned.w.1",
        "sco.1","sco.2","sco.3","sco.4","sco.tennents","sco.cis","sco.challenge",
        "por.1","por.taca.portugal","bel.1","aut.1","gre.1","tur.1","den.1",
        "nor.1","swe.1","cyp.1","irl.1","rus.1",
        "usa.1","usa.open","usa.nwsl","usa.nwsl.cup","usa.usl.1","usa.usl.l1",
        "concacaf.champions","concacaf.leagues.cup","concacaf.gold",
        "concacaf.nations.league","campeones.cup",
        "mex.1","mex.2","mex.campeon","mex.supercopa",
        "conmebol.libertadores","conmebol.sudamericana","conmebol.recopa",
        "conmebol.america","conmebol.america_qual",
        "arg.1","arg.copa","bra.1","bra.2","bra.copa_do_brazil",
        "chi.1","col.1","par.1","per.1","uru.1","bol.1","ecu.1","ven.1",
        "caf.nations","caf.nations_qual","caf.champions","caf.confed",
        "rsa.1","nga.1","gha.1",
        "afc.champions","afc.cup","afc.asian.cup","ksa.1","ksa.kings.cup",
        "jpn.1","chn.1","ind.1","tha.1","mys.1","idn.1","sgp.1","aus.1","aus.w.1",
        "club.friendly","nonfifa","friendly.emirates_cup","global.champs_cup"
    };

    static void preload(){ load(null); }

    static void load(ApiClient.Callback<List<ApiClient.FootballMatch>> cb) {
        final String today = dayKey();
        synchronized (LOCK) {
            if (today.equals(cacheDay) && !CACHE.isEmpty()) {
                if (cb != null) cb.ok(new ArrayList<>(CACHE));
                return;
            }
            if (cb != null) WAITERS.add(cb);
            if (loading) return;
            loading = true;
        }
        IO.execute(() -> fetch(today));
    }

    private static void fetch(String today){
        ArrayList<ApiClient.FootballMatch> out = new ArrayList<>();
        String err = null;
        try {
            final String day = new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date());
            final List<ApiClient.FootballMatch> all = Collections.synchronizedList(new ArrayList<ApiClient.FootballMatch>());
            final ExecutorService pool = Executors.newFixedThreadPool(12);
            final CountDownLatch latch = new CountDownLatch(LEAGUES.length);

            for (final String league : LEAGUES) {
                pool.execute(() -> {
                    try {
                        String url = BASE + "/apis/site/v2/sports/soccer/" + league +
                                "/scoreboard?dates=" + day + "&limit=200";
                        parseScoreboard(get(url), all, league);
                    } catch (Exception ignored) {
                    } finally { latch.countDown(); }
                });
            }
            latch.await(18, TimeUnit.SECONDS);
            pool.shutdownNow();
            out.addAll(all);
            dedupe(out);
            Collections.sort(out, new Comparator<ApiClient.FootballMatch>() {
                @Override public int compare(ApiClient.FootballMatch a, ApiClient.FootballMatch b) {
                    return safe(a.clock).compareTo(safe(b.clock));
                }
            });
        } catch (Exception e) { err = e.getMessage()==null?"erro de rede":e.getMessage(); }

        ArrayList<ApiClient.Callback<List<ApiClient.FootballMatch>>> waiters;
        synchronized (LOCK) {
            CACHE.clear(); CACHE.addAll(out); cacheDay = today; loading = false;
            waiters = new ArrayList<>(WAITERS); WAITERS.clear();
        }
        for (ApiClient.Callback<List<ApiClient.FootballMatch>> w : waiters) {
            if (!out.isEmpty()) w.ok(new ArrayList<>(out)); else w.error(err==null?"sem jogos":err);
        }
    }

    private static void parseScoreboard(String raw, List<ApiClient.FootballMatch> out, String leagueSlug) throws Exception {
        Object parsed = new JSONTokener(raw).nextValue();
        if (!(parsed instanceof JSONObject)) return;
        JSONObject root = (JSONObject) parsed;
        JSONArray events = root.optJSONArray("events");
        if (events == null || events.length() == 0) return;

        String leagueName = leagueSlug;
        String leagueLogo = "";
        JSONArray leagues = root.optJSONArray("leagues");
        if (leagues != null && leagues.length() > 0) {
            JSONObject l = leagues.optJSONObject(0);
            if (l != null) {
                String n = first(l, "name", "displayName", "abbreviation", "slug");
                if (!n.isEmpty()) leagueName = translateLeague(n);
                JSONArray logos = l.optJSONArray("logos");
                if (logos != null && logos.length() > 0) {
                    Object one = logos.opt(0);
                    if (one instanceof JSONObject) leagueLogo = first((JSONObject) one, "href", "url");
                }
            }
        }

        for (int i=0;i<events.length();i++) {
            JSONObject ev=events.optJSONObject(i); if(ev==null)continue;
            JSONArray comps=ev.optJSONArray("competitions"); if(comps==null||comps.length()==0)continue;
            JSONObject comp=comps.optJSONObject(0); if(comp==null)continue;
            JSONArray competitors=comp.optJSONArray("competitors"); if(competitors==null||competitors.length()<2)continue;
            JSONObject home=null,away=null;
            for(int j=0;j<competitors.length();j++){
                JSONObject c=competitors.optJSONObject(j); if(c==null)continue;
                String side=c.optString("homeAway","");
                if("home".equalsIgnoreCase(side))home=c; else if("away".equalsIgnoreCase(side))away=c;
            }
            if(home==null||away==null)continue;

            ApiClient.FootballMatch m=new ApiClient.FootballMatch();
            m.league=leagueName; m.leagueLogo=leagueLogo;
            m.home=teamName(home); m.away=teamName(away);
            m.homeLogo=teamLogo(home); m.awayLogo=teamLogo(away);
            m.date=first(ev,"date");
            if(empty(m.home)||empty(m.away))continue;

            String hs=home.optString("score",""); String as=away.optString("score","");
            JSONObject st=ev.optJSONObject("status"); JSONObject type=st==null?null:st.optJSONObject("type");
            String state=type==null?"":type.optString("state","");
            if(!hs.isEmpty()&&!as.isEmpty()&&!"pre".equalsIgnoreCase(state))m.score=hs+" - "+as; else m.score="";
            String rawStatus=type==null?"":first(type,"shortDetail","description","detail","state");
            m.status=translateStatus(rawStatus,state);
            m.clock=localClock(first(ev,"date"));
            m.channel=broadcast(comp,ev);
            out.add(m);
        }
    }

    private static String broadcast(JSONObject comp, JSONObject ev){
        ArrayList<String> names=new ArrayList<>();
        collectBroadcasts(comp.optJSONArray("broadcasts"),names);
        collectBroadcasts(ev.optJSONArray("broadcasts"),names);
        JSONArray geo=comp.optJSONArray("geoBroadcasts");
        if(geo!=null){
            for(int i=0;i<geo.length();i++){
                JSONObject g=geo.optJSONObject(i); if(g==null)continue;
                JSONObject media=g.optJSONObject("media");
                if(media!=null){String n=first(media,"shortName","name");if(!n.isEmpty()&&!names.contains(n))names.add(n);}
            }
        }
        if(names.isEmpty())return "";
        StringBuilder s=new StringBuilder();
        for(String n:names){if(s.length()>0)s.append(" • ");s.append(n);if(s.length()>42)break;}
        return s.toString();
    }

    private static void collectBroadcasts(JSONArray arr,List<String> names){
        if(arr==null)return;
        for(int i=0;i<arr.length();i++){
            JSONObject b=arr.optJSONObject(i); if(b==null)continue;
            JSONArray ns=b.optJSONArray("names");
            if(ns!=null)for(int j=0;j<ns.length();j++){String n=ns.optString(j,"").trim();if(!n.isEmpty()&&!names.contains(n))names.add(n);}
            String n=first(b,"name","shortName");if(!n.isEmpty()&&!names.contains(n))names.add(n);
        }
    }

    private static String translateStatus(String raw,String state){
        String x=safe(raw).toLowerCase(Locale.ROOT);
        if("in".equalsIgnoreCase(state)||x.contains("live")||x.contains("progress"))return "AO VIVO";
        if("post".equalsIgnoreCase(state)||x.contains("final")||x.contains("full time")||x.contains("ended"))return "Encerrado";
        if(x.contains("half"))return "Intervalo";
        if(x.contains("postpon"))return "Adiado";
        if(x.contains("cancel"))return "Cancelado";
        if(x.contains("suspend"))return "Suspenso";
        if(x.contains("delay"))return "Atrasado";
        if(x.contains("scheduled")||x.contains("pre")||x.contains("not started")||x.isEmpty())return "Agendado";
        return raw;
    }

    private static String translateLeague(String s){
        String x=safe(s);
        if(x.equalsIgnoreCase("German Cup"))return "Copa da Alemanha";
        if(x.equalsIgnoreCase("English Premier League"))return "Premier League";
        if(x.equalsIgnoreCase("Spanish LALIGA"))return "LaLiga";
        if(x.equalsIgnoreCase("Italian Serie A"))return "Serie A Italiana";
        if(x.equalsIgnoreCase("French Ligue 1"))return "Ligue 1";
        if(x.equalsIgnoreCase("UEFA Champions League"))return "Liga dos Campeões da UEFA";
        if(x.equalsIgnoreCase("UEFA Europa League"))return "Liga Europa da UEFA";
        return x;
    }

    private static String teamName(JSONObject competitor){JSONObject t=competitor.optJSONObject("team");if(t==null)t=competitor;return first(t,"displayName","shortDisplayName","name","abbreviation");}
    private static String teamLogo(JSONObject competitor){JSONObject t=competitor.optJSONObject("team");if(t==null)t=competitor;String logo=first(t,"logo","image","crest","badge");if(!logo.isEmpty())return logo;JSONArray logos=t.optJSONArray("logos");if(logos!=null&&logos.length()>0){Object one=logos.opt(0);if(one instanceof JSONObject){String x=first((JSONObject)one,"href","url","logo");if(!x.isEmpty())return x;}else if(one instanceof String)return(String)one;}return"";}
    private static String localClock(String iso){if(empty(iso))return"";try{SimpleDateFormat in=new SimpleDateFormat("yyyy-MM-dd'T'HH:mmX",Locale.US);SimpleDateFormat out=new SimpleDateFormat("HH:mm",Locale.getDefault());Date d=in.parse(iso);return d==null?"":out.format(d);}catch(Exception ignored){}try{if(iso.length()>=16)return iso.substring(11,16);}catch(Exception ignored){}return"";}
    private static String first(JSONObject o,String...keys){if(o==null)return"";for(String k:keys){Object v=o.opt(k);if(v==null||v==JSONObject.NULL)continue;String s=String.valueOf(v).trim();if(!s.isEmpty()&&!"null".equalsIgnoreCase(s))return s;}return"";}
    private static void dedupe(List<ApiClient.FootballMatch> list){Set<String> seen=new HashSet<>();for(int i=list.size()-1;i>=0;i--){ApiClient.FootballMatch m=list.get(i);String key=norm(m.home)+"|"+norm(m.away)+"|"+safe(m.clock);if(seen.contains(key))list.remove(i);else seen.add(key);}}
    private static String norm(String s){String x=safe(s).toLowerCase(Locale.ROOT);x=java.text.Normalizer.normalize(x,java.text.Normalizer.Form.NFD).replaceAll("\\p{M}","");return x.replaceAll("[^a-z0-9]","");}
    private static String safe(String s){return s==null?"":s;}
    private static boolean empty(String s){return s==null||s.trim().isEmpty();}
    private static String dayKey(){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());}

    private static String get(String url)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
        c.setConnectTimeout(4500);c.setReadTimeout(6500);
        c.setRequestProperty("User-Agent","Mozilla/5.0 (Android TV) DubaiPlay/4.0.21");
        c.setRequestProperty("Accept","application/json,text/plain,*/*");
        c.setRequestProperty("Accept-Language","pt-BR,pt;q=0.9,en;q=0.8");
        int code=c.getResponseCode();if(code<200||code>=300)throw new Exception("HTTP "+code);
        BufferedReader b=new BufferedReader(new InputStreamReader(c.getInputStream()));StringBuilder s=new StringBuilder();String line;while((line=b.readLine())!=null)s.append(line);b.close();c.disconnect();return s.toString();
    }
}
