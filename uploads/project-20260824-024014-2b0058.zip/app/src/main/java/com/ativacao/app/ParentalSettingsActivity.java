package com.ativacao.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class ParentalSettingsActivity extends Activity {
    private EditText currentPin,newPin;
    @Override public void onCreate(Bundle b){super.onCreate(b);Ui.immersive(this);setContentView(build());}

    private View build(){
        LinearLayout root=Ui.column(this);root.setBackgroundColor(Ui.BG);
        root.addView(YellowNav.bar(this,""),new LinearLayout.LayoutParams(-1,Ui.dp(this,64)));
        LinearLayout body=Ui.column(this);body.setGravity(Gravity.CENTER_HORIZONTAL);
        body.setPadding(Ui.dp(this,40),Ui.dp(this,24),Ui.dp(this,40),Ui.dp(this,24));

        TextView title=Ui.text(this,"CONTROLE ADULTO",28,Ui.GREEN,true);title.setGravity(Gravity.CENTER);
        body.addView(title,new LinearLayout.LayoutParams(-1,Ui.dp(this,52)));
        TextView sub=Ui.text(this,"Proteja a pasta Adultos com um PIN de 4 dígitos.",12,Ui.MUTED,false);sub.setGravity(Gravity.CENTER);
        body.addView(sub,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));

        boolean has=LocalStore.hasAdultPin(this);
        if(has){
            currentPin=field("PIN atual");
            body.addView(currentPin,new LinearLayout.LayoutParams(Ui.dp(this,320),Ui.dp(this,52)));
        }
        newPin=field(has?"Novo PIN de 4 dígitos":"Criar PIN de 4 dígitos");
        LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(Ui.dp(this,320),Ui.dp(this,52));np.topMargin=Ui.dp(this,10);body.addView(newPin,np);

        TextView save=Ui.primaryButton(this,has?"ALTERAR PIN":"CRIAR PIN");save.setOnClickListener(v->save());
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(Ui.dp(this,220),Ui.dp(this,46));sp.topMargin=Ui.dp(this,16);body.addView(save,sp);

        if(has){
            TextView remove=Ui.button(this,"REMOVER PIN");remove.setOnClickListener(v->remove());
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(Ui.dp(this,220),Ui.dp(this,44));rp.topMargin=Ui.dp(this,10);body.addView(remove,rp);
        }
        root.addView(Ui.centered(this,body,780),new LinearLayout.LayoutParams(-1,0,1));
        save.requestFocus();return root;
    }

    private EditText field(String hint){
        EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setHintTextColor(Ui.MUTED);e.setTextColor(Color.WHITE);
        e.setGravity(Gravity.CENTER);e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        e.setBackground(Ui.stroke(Ui.PANEL,Ui.GREEN,8,this));return e;
    }

    private boolean valid(String p){return p!=null&&p.matches("\\d{4}");}
    private void save(){
        String np=newPin.getText().toString().trim();if(!valid(np)){Toast.makeText(this,"Use 4 dígitos",Toast.LENGTH_SHORT).show();return;}
        if(LocalStore.hasAdultPin(this)){
            String cp=currentPin.getText().toString().trim();if(!LocalStore.checkAdultPin(this,cp)){Toast.makeText(this,"PIN atual incorreto",Toast.LENGTH_SHORT).show();return;}
        }
        LocalStore.setAdultPin(this,np);Toast.makeText(this,"PIN salvo",Toast.LENGTH_SHORT).show();finish();
    }
    private void remove(){
        String cp=currentPin.getText().toString().trim();if(!LocalStore.checkAdultPin(this,cp)){Toast.makeText(this,"PIN atual incorreto",Toast.LENGTH_SHORT).show();return;}
        LocalStore.setAdultPin(this,"");Toast.makeText(this,"PIN removido",Toast.LENGTH_SHORT).show();finish();
    }
    @Override protected void onResume(){super.onResume();Ui.immersive(this);}
}
