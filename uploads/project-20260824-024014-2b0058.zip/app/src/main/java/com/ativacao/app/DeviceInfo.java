package com.ativacao.app;

import android.content.Context;
import android.provider.Settings;

import java.net.NetworkInterface;
import java.util.Collections;
import java.util.List;

final class DeviceInfo {
    private DeviceInfo() {}

    static String macOrId(Context c) {
        try {
            List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface ni : interfaces) {
                String n = ni.getName();
                if (n == null || !(n.equalsIgnoreCase("eth0") || n.equalsIgnoreCase("wlan0"))) continue;
                byte[] mac = ni.getHardwareAddress();
                if (mac == null || mac.length == 0) continue;
                StringBuilder sb = new StringBuilder();
                for (byte b : mac) {
                    if (sb.length() > 0) sb.append(':');
                    sb.append(String.format("%02x", b & 0xff));
                }
                String value = sb.toString();
                if (!value.isEmpty() && !"02:00:00:00:00:00".equals(value)) return value;
            }
        } catch (Throwable ignored) {}
        String id = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ANDROID_ID);
        if (id == null || id.trim().isEmpty()) id = "desconhecido";
        return "ID-" + id.toUpperCase();
    }
}
