package com.ativacao.app;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.LruCache;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class ImageLoader {
    private static final ExecutorService IMAGES = Executors.newFixedThreadPool(6);
    private static final Set<String> IN_FLIGHT = Collections.synchronizedSet(new HashSet<>());
    private static final int CACHE_KB = 24 * 1024;
    private static final LruCache<String, Bitmap> CACHE = new LruCache<String, Bitmap>(CACHE_KB) {
        @Override protected int sizeOf(String key, Bitmap value) {
            return Math.max(1, value.getByteCount() / 1024);
        }
    };

    static void into(Activity a, ImageView target, String url) {
        target.setImageDrawable(null);
        if (url == null || url.trim().isEmpty()) return;
        final String u = url.trim();
        target.setTag(u);
        Bitmap hit = CACHE.get(u);
        if (hit != null) {
            target.setImageBitmap(hit);
            return;
        }
        if (!IN_FLIGHT.add(u)) return;

        IMAGES.execute(() -> {
            HttpURLConnection con = null;
            try {
                con = (HttpURLConnection) new URL(u).openConnection();
                con.setConnectTimeout(6000);
                con.setReadTimeout(10000);
                con.setInstanceFollowRedirects(true);
                con.setRequestProperty("User-Agent", "DubaiPlayTV/1.4 Android");
                con.setRequestProperty("Accept", "image/avif,image/webp,image/apng,image/*,*/*;q=0.8");
                int code = con.getResponseCode();
                if (code < 200 || code >= 300) return;
                InputStream in = con.getInputStream();
                ByteArrayOutputStream out = new ByteArrayOutputStream(96 * 1024);
                byte[] buf = new byte[16 * 1024];
                int n;
                int max = 3 * 1024 * 1024;
                while ((n = in.read(buf)) > 0 && out.size() < max) out.write(buf, 0, n);
                in.close();
                byte[] data = out.toByteArray();
                if (data.length == 0) return;

                BitmapFactory.Options bounds = new BitmapFactory.Options();
                bounds.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(data, 0, data.length, bounds);
                int sample = 1;
                while (bounds.outWidth / sample > 720 || bounds.outHeight / sample > 960) sample *= 2;
                BitmapFactory.Options opts = new BitmapFactory.Options();
                opts.inSampleSize = Math.max(1, sample);
                opts.inPreferredConfig = Bitmap.Config.RGB_565;
                Bitmap bmp = BitmapFactory.decodeByteArray(data, 0, data.length, opts);
                if (bmp != null) {
                    CACHE.put(u, bmp);
                    a.runOnUiThread(() -> {
                        Object tag = target.getTag();
                        if (tag != null && u.equals(tag.toString())) target.setImageBitmap(bmp);
                    });
                }
            } catch (Exception ignored) {
            } finally {
                IN_FLIGHT.remove(u);
                if (con != null) con.disconnect();
            }
        });
    }

    static void clear() { CACHE.evictAll(); }
}
