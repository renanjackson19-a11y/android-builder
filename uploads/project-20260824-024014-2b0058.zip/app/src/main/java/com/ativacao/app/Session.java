package com.ativacao.app;

import android.content.Context;

final class Session {
    private static final String PREF="dubai_play_session";
    private Session(){}
    static boolean isLogged(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getBoolean("logged",false);}
    static void save(Context c,String user,String expires){save(c,user,expires,"");}
    static void save(Context c,String user,String expires,String plan){c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putBoolean("logged",true).putString("user",user==null?"":user).putString("expires",expires==null?"":expires).putString("plan",plan==null?"":plan).apply();}
    static String user(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("user","");}
    static String expires(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("expires","");}
    static String plan(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("plan","");}
    static void clear(Context c){c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().clear().apply();}
}
