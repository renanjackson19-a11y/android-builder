DUBAI PLAY TV V2.5.4 FINAL
Base técnica: V2.5.3 COMPILE FIX (mantida)

ENTREGUE NESTA CONSOLIDAÇÃO
- TV automática pela Home.
- Abre o último canal assistido; se ainda não houver histórico, abre o primeiro canal disponível.
- Player de TV com lista lateral de canais sobre o vídeo (preview continua tocando).
- EPG no player com AGORA e A SEGUIR.
- Ao trocar de canal, último canal e EPG são atualizados.
- TMDB tratado pelo painel: poster/capa, backdrop e sinopse, priorizando PT-BR.
- Séries agrupadas por série, depois temporadas e episódios.
- Navegação VOLTAR corrigida: primeiro fecha a lista; depois retorna à tela anterior.
- URLs originais de stream não são entregues nos payloads de catálogo do APK.
- Stream passa pelo endpoint privado/relay do painel.

CONTROLE REMOTO NA TV
- Na TV ao vivo: DPAD CIMA ou MENU abre a lista de canais.
- DPAD BAIXO fecha a lista.
- VOLTAR fecha a lista primeiro; se a lista estiver fechada, sai do player.
- ENTER/OK pausa/retoma quando os controles estiverem ativos.

COMPILAÇÃO
- applicationId preservado.
- Gradle/Media3/estrutura preservados a partir da V2.5.3 que compila.
- versionCode: 147
- versionName: 2.5.4
- Workflow GitHub incluído: Java 17 + Gradle 8.9 + assembleDebug.

IMPORTANTE
O endereço de comunicação com o servidor não é exibido na interface e a URL real do conteúdo não é devolvida pelo catálogo. Como qualquer aplicativo cliente conectado a um servidor, o host usado na comunicação não pode ser considerado impossível de descobrir por análise técnica avançada ou inspeção de rede.
