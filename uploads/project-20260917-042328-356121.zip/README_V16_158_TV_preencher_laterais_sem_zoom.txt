GreenPlay v16.158
- Preenche as laterais do player sem usar zoom/crop no vídeo principal.
- Barras laterais deixam de ficar pretas e passam a usar fundo temático do app.
