GreenPlay Android Nativo v16.30.3

Ajustes sobre a v16.30.2:
- carrossel da Home avanca automaticamente a cada ~4,5 segundos
- volta ao primeiro destaque apos o ultimo
- swipe manual continua funcionando e pausa o automatico enquanto o usuario toca
- automatico retoma alguns segundos depois do swipe
- indicadores acompanham o card ativo
- destaques agora sao diversificados entre as secoes do catalogo, em vez de pegar somente os primeiros itens de uma unica secao
- carrossel so avanca automaticamente quando esta visivel na tela
- assinatura fixa preservada
- versionCode 53 / versionName 1.16.30.3
