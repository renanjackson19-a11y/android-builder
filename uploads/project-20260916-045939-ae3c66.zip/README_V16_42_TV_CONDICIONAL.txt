GreenPlay Android Nativo v16.42

Ajuste sobre a v16.41:
- TV só aparece no aplicativo quando o provedor realmente retorna categorias de TV ao vivo.
- Se a fonte não tiver TV, remove a opção TV da navegação inferior.
- Se a fonte não tiver TV, remove também o card "Canais ao vivo" da Home.
- Na preparação do servidor, a etapa TV só aparece quando TV for detectada.
- Ao trocar de servidor, a disponibilidade de TV é recalculada para o novo provedor.
- Nenhum cache persistente de catálogo foi reintroduzido.
- Mantidos bootstrap real da v16.41, filmes, séries, recentes, TMDB, offline e assinatura existente.

versionCode 64
versionName 1.16.42.0
