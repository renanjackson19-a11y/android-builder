GreenPlay Android v16.76

Correção de compilação sobre a v16.75.

Causa:
- duas expressões regulares em MainActivity.java usavam o escape \s diretamente em String Java;
- o projeto compila com Java source 8, onde esse escape não é aceito dessa forma.

Correção:
- alterado para \\s no código-fonte Java, mantendo a mesma expressão regular;
- nenhuma função, tela, painel, catálogo ou configuração foi removida/revertida.

Base: v16.75 -> v16.76
Painel permanece v72.8.
