GreenPlay Android Nativo v16.41

Correção focada no fluxo de carregamento do provedor:
- a tela "Carregando conteúdo" faz o carregamento real antes de abrir a Home
- section_list completo vem direto da fonte durante a troca/entrada no provedor
- categorias de Filmes, Séries e TV são confirmadas antes de liberar a Home
- imagens essenciais da primeira tela são preparadas antes da Home
- o conteúdo preparado fica somente na memória da sessão (não é cache persistente)
- ao abrir a Home, não aparece mais "Carregando recomendações..." depois de um bootstrap concluído
- abas Filmes e Séries reaproveitam o conteúdo já preparado na troca de servidor
- a Home não repete section_list se o bootstrap já trouxe Filmes e Séries
- ao trocar de servidor, os dados preparados do servidor anterior são descartados
- se a fonte falhar durante a preparação, a Home não finge que terminou; oferece nova tentativa

Base: v16.40
versionCode: 63
versionName: 1.16.41.0
