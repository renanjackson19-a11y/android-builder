GreenPlay Android Nativo v16.20

Base: v16.19 com assinatura debug fixa preservada.

Correções:
- cards/posters carregam somente quando entram na área visível da tela
- evita fila gigante com imagens de todas as categorias
- prioridade prática para categorias que o usuário está vendo
- URLs image.tmdb.org em HTTP são normalizadas para HTTPS
- corrige barra dupla em URLs do TMDB
- retry automático de imagem em falha transitória
- decode de bitmap otimizado para reduzir memória/CPU
- fallback de campos thumbnail/portrait_img/image nos cards
- cache de memória/disco preservado
- assinatura fixa da v16.19 preservada para atualização por cima
