GreenPlay Android v16.72

Correções de navegação e pesquisa sobre a v16.71.

- Remove o AlertDialog padrão de busca.
- Busca agora abre uma tela própria do GreenPlay, com campo no topo e resultados em tempo real usando o catálogo já carregado em memória.
- Botão Voltar em telas internas retorna primeiro à Home.
- Botão Voltar nas abas Filmes/Séries/categorias retorna primeiro para Início.
- Só na Home/Início o Voltar abre confirmação “Sair do aplicativo?”.
- Diálogo de saída customizado, com Cancelar e Sair.
- Nenhuma alteração no painel, catálogo, TMDB, provedores, banco ou configurações.
