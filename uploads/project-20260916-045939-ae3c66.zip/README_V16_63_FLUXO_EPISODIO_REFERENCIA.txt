GreenPlay Android v16.63

Ajuste do fluxo de episódios com base no vídeo de referência.

- tocar em um episódio abre uma folha de ações na parte inferior;
- mostra episódio selecionado e ações Assistir, Espelhar na TV e Baixar;
- Assistir mantém a fila completa e o avanço automático para o próximo episódio;
- progresso do episódio é salvo localmente apenas para retomada;
- ao voltar para os detalhes, aparece cartão “Continuar” com barra de progresso;
- tocar em Continuar retoma do ponto salvo;
- download do episódio reutiliza o sistema offline existente;
- catálogo continua sem cache persistente.

Painel permanece v72.7, sem alteração.
