GreenPlay Android v16.59

Base: v16.58. Painel continua v72.5.

Ajustes:
- tela de detalhes refeita seguindo a composição da referência enviada, preservando o tema GreenPlay;
- imagem de destaque com voltar/favorito sobrepostos e título no rodapé do hero;
- ID do conteúdo, nota, data e quantidade de temporadas no topo;
- sinopse em cartão com Ler mais;
- séries exibem Temporadas e Episódios; troca de temporada carrega os episódios direto da fonte;
- elenco aparece depois dos episódios;
- filmes mantêm Assistir e download offline no novo layout;
- a barra inferior do app não aparece durante os detalhes, como na referência;
- carrossel principal passa a usar até 12 conteúdos e mistura/rotaciona itens do catálogo completo em memória;
- o carrossel não fica mais preso aos mesmos poucos filmes/séries.

Não altera TMDB, logo, provedores, banco, painel nem cache persistente do catálogo.
