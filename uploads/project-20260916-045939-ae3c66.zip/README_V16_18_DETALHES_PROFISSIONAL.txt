GreenPlay Android Nativo v16.18

Base: v16.17.

Ajustes:
- tela de detalhes refinada usando todas as referências enviadas
- duração convertida para horas/minutos (72 min -> 1h 12min; 120 min -> 2h)
- nota padronizada com uma casa decimal
- hero maior e mais cinematográfico
- barra inferior escondida durante Detalhes e restaurada ao voltar
- corrige elenco/conteúdo espremido no final da tela
- botão Offline em destaque secundário; Minha lista fica no coração do topo, evitando ação duplicada
- sinopse e elenco preservados
- TMDB/provider-first preservado; app apenas exibe os dados entregues pelo painel/API
- navegação/cache/offline privado preservados
