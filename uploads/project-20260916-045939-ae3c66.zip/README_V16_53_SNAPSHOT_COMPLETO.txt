GreenPlay Android v16.53 — snapshot completo em memória

Base: v16.52
Painel esperado: patch v72.4 sobre v72.3

Mudanças:
- ao escolher servidor, o app faz UMA chamada de bootstrap;
- recebe Filmes, Séries e TV de uma vez;
- todas as categorias e todos os itens ficam em memória durante a sessão;
- não existe complemento de categorias em segundo plano depois da Home;
- abrir categoria usa os dados já carregados, sem content_by_category quando o snapshot está completo;
- busca de filmes/séries usa o snapshot em memória;
- TV usa categorias e canais do mesmo snapshot em memória;
- não espera imagens antes de abrir a Home;
- suporte a resposta gzip para reduzir transferência;
- catálogo continua sem cache persistente no Android.

Não altera identidade, logo, TMDB, provedores, banco ou configurações.
