GreenPlay Android Nativo v16.2 - Home compacta restaurada

Base: v16.1 (não houve regressão para versões antigas).

Correções visuais:
- removido o cabeçalho grande com avatar + saudação + dois botões circulares;
- restaurado o topo compacto da Home: logo/GP + barra de busca + acesso ao perfil;
- abas Explorar / Filmes / Séries mantidas e distribuídas igualmente;
- carrossel sobe na tela e deixa de ser empurrado por um cabeçalho alto;
- restante da v16.1 preservado: Home completa, categorias completas, TV, favoritos, downloads, perfil e retorno correto do player.
