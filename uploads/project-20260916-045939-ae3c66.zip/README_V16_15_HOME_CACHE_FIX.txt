GreenPlay Android Nativo v16.15

Correções sobre a v16.14:
- Home é pré-carregada logo após login antes de abrir o catálogo
- cache persistente do section_list por usuário/servidor
- voltar de Detalhes pela seta ou pelo botão Início restaura a Home sem nova API
- loader de recomendações possui timeout/fallback e não fica infinito
- imagens agora usam cache de memória e disco; removido no-cache forçado
- primeiras imagens da Home são aquecidas antes da entrada após login
- categorias extras são buscadas uma vez e incorporadas ao cache da Home
- removido método duplicado de Downloads encontrado na v16.14
- offline privado da v16.14 preservado
