GreenPlay Android v16.78

Diálogos e confirmações redesenhados para o padrão visual do GreenPlay.
- saída do aplicativo;
- logout;
- exclusão de conta;
- redefinição de senha;
- criação/alteração de PIN;
- validações internas sem AlertDialog cinza do Android;
- sem toast "Defina um PIN primeiro".

Painel v72.8 permanece inalterado.
