GreenPlay Android Nativo v16.17 - detalhes refinados

Mudanças desta versão:
- Tela de detalhes redesenhada com hero mais bonito e espaçamento melhor.
- Botão voltar e favorito sobre o banner.
- Badge de ID/TMDB quando disponível.
- Linha de metadados (nota, data e duração) mais organizada.
- Chips de gênero com visual melhorado.
- Botões principais refinados: Assistir, Baixar para assistir offline e Minha lista.
- Card de sinopse redesenhado.
- Sinopse com Ler mais / Ler menos quando o texto for grande.
- Elenco com avatar circular e borda melhor.
- Versionamento atualizado para 1.16.17 / versionCode 38.

Base utilizada:
- GreenPlay_Android_Nativo_v16_16_anr_inicio_corrigido.zip
