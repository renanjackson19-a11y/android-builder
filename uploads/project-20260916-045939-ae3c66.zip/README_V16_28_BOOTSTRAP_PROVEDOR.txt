GreenPlay Android Nativo v16.28

Base: v16.27.

Fluxo novo inspirado no comportamento do app de referência:
- Login não abre mais a Home imediatamente.
- Após autenticar, o usuário escolhe o servidor/provedor.
- Após escolher, aparece uma tela de preparação antes da Home.
- A preparação valida Filmes, Séries e Canais ao vivo em paralelo.
- section_list e capas essenciais são preparados antes de liberar a Home.
- Home é salva em cache por usuário + provedor.
- Em abertura futura, se o catálogo daquele provedor já estiver em cache, a Home abre rapidamente e atualizações/prefetch continuam em segundo plano.
- Botão Trocar servidor disponível durante a preparação.
- Mantidas navegação/cache, TMDB via painel/API, offline privado e assinatura debug fixa.

VersionCode: 49
VersionName: 1.16.28
