GreenPlay Android Nativo v16.8

Base: v16.7, sem regressão.

Correções:
- título e subtítulo do login centralizados
- código da revenda removido de baixo do botão Criar uma conta
- código da revenda virou um botão compacto centralizado abaixo da introdução
- campo do código continua recolhido e abre apenas ao toque
- Home continua usando section_list, mas agora consulta get_category de Filmes e Séries
- qualquer categoria ausente na resposta inicial é carregada individualmente com content_by_category
- isso evita a Home parar em Aventura quando a resposta principal vier parcial
- logo do painel, fundo, TV, downloads, perfil e correções do player foram preservados
