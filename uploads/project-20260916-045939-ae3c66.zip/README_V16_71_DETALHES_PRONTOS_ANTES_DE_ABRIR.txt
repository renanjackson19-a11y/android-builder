GreenPlay Android v16.71

Correção do fluxo de abertura dos detalhes.

- A tela de detalhes não é mais exibida parcialmente para depois receber sinopse, elenco, nota ou temporadas.
- Ao tocar em um conteúdo, o app prepara content_detail e content_enrich em paralelo.
- Se o detalhe já estiver no cache de detalhes/prefetch da sessão, a abertura é imediata.
- Enquanto prepara, a Home permanece por trás com um indicador discreto, sem textos.
- A tela de detalhes abre uma única vez já com os dados disponíveis montados.
- Não altera o catálogo, painel, TMDB, provedores, banco nem configurações.

Base anterior: v16.70
Painel compatível: v72.8
