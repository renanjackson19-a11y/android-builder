GreenPlay Android v16.70

Correção do download offline sobre a v16.69.

- tenta todas as qualidades disponíveis do conteúdo quando uma URL falha;
- repete automaticamente falhas transitórias;
- segue redirecionamentos HTTP/HTTPS manualmente;
- tenta novamente sem Origin/Referer em servidores que bloqueiam esses cabeçalhos;
- HLS tenta outras variantes se a qualidade principal falhar;
- segmentos HLS e playlists têm retry;
- preserva extensão de arquivos diretos quando possível;
- mensagem de falha ficou curta e acionável: toque para tentar novamente;
- não altera painel, catálogo, TMDB, logo, provedores ou banco.
