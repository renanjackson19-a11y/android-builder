GreenPlay Android v14.2
- Canais ao vivo exibidos em lista própria.
- Reprodução direta de TV ao vivo sem passar por detalhes de filme.
- Player envia User-Agent, Referer e Origin para maior compatibilidade.
