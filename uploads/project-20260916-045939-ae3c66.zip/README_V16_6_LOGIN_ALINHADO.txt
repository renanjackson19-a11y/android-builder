GreenPlay Android Nativo v16.6

Ajustes aplicados em cima da v16.5:
- link "Usar código de revenda" movido para baixo do botão "Criar uma conta"
- link centralizado para manter o layout limpo
- campo do código continua oculto/recolhido, abrindo ao toque
- redução do espaço entre a mensagem de boas-vindas e o formulário
- demais correções da v16.5 preservadas
