GreenPlay Android v16.57

Ajuste da Home baseado no vídeo de referência enviado.

- topo deslocado para baixo para não ficar colado na barra de status;
- logo menor e barra de busca mais larga/fina;
- menu horizontal mais compacto;
- TV removida do menu superior (continua disponível na navegação própria quando o provedor possui canais);
- ordem do menu: Início, categoria real do provedor, Séries, Filmes e outras categorias reais;
- tocar numa categoria do topo troca o destaque e os trilhos dentro da própria Home, sem abrir outra tela;
- Filmes e Séries agora também mostram destaque grande antes dos trilhos;
- toda troca usa o snapshot completo já em memória, sem nova consulta ao painel/Xtream.

Nenhuma alteração no painel v72.5, TMDB, logo configurada, provedores, banco ou carregamento do catálogo.
