GreenPlay Android Nativo v16.31

Ajustes sobre a v16.30.2:
- carrossel da Home agora mistura destaques de categorias diferentes em vez de pegar apenas os primeiros lançamentos
- card central menor com os cards anterior/próximo aparecendo nas laterais, seguindo a referência enviada
- avanço automático a cada ~4,3 s
- ao chegar ao fim, volta ao primeiro destaque
- swipe manual preservado com snap para o card mais próximo
- autoplay pausa enquanto o usuário toca/arrasta e volta depois
- indicadores (bolinhas) acompanham o destaque atual
- cache, TMDB, offline e assinatura fixa preservados
- versionCode 53
