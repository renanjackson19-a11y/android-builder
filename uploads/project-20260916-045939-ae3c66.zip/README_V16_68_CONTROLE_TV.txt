GreenPlay Android v16.68

Compatibilidade reforçada para Android TV, TV Box e Fire TV usando controle remoto.

Ajustes:
- MainActivity usa orientação paisagem em aparelhos de TV e mantém retrato no celular;
- navegação por DPAD em cards, abas, busca, menus, episódios, downloads, perfil e seleção de servidor;
- elementos de texto estáticos deixam de capturar o foco na TV;
- item focado recebe zoom/elevacao visual e a tela rola para mantê-lo visível;
- folhas de ações de filme/episódio já abrem com “Assistir” focado;
- player recebe foco nos controles e suporta teclas de mídia do controle remoto;
- controles do player podem ser reabertos pelo DPAD;
- opção Espelhar na TV permanece oculta em TVs/TV Box/Fire TV.

Painel não alterado.
