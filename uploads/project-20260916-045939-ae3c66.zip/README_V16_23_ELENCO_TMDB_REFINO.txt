GreenPlay Android Nativo v16.23

Base: v16.22.
- preserva assinatura debug fixa
- TMDB ID zero/inválido nunca aparece
- separa gêneros combinados por vírgula, barra, pipe ou ponto-e-vírgula
- traduz mais gêneros para pt-BR (Soap -> Novela etc.)
- fotos do elenco aceitam URL completa, profile_path, nome de arquivo e caminhos TMDB
- se uma pessoa realmente não tiver foto, mostra iniciais no avatar em vez de círculo vazio
