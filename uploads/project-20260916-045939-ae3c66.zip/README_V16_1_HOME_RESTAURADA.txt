GreenPlay Android Nativo v16.1 - Home restaurada sem regressão

Correção aplicada sobre a v16 mais recente:
- Explorar volta a exibir carrossel + banner Canais ao vivo + Continue assistindo + seções do catálogo.
- Mantida a v16 para Filmes e Séries com TODAS as categorias do provedor.
- Mantida abertura da grade completa por categoria.
- Mantida correção que evita voltar sozinho ao Início ao retornar do player.
- Nenhuma regressão para v15; apenas o bloco visual/conteúdo de Explorar foi restaurado.
