GreenPlay Android Nativo v16.38

Correção da Home / Recomendações:
- categorias de FILMES voltam a aparecer antes das categorias de SÉRIES
- Home não depende mais da ordem em que section_list chega da API
- sempre confere get_category de filmes e séries e completa categorias faltantes
- categorias de filmes e séries usam hosts separados para uma não empurrar/sumir com a outra
- categorias iguais em filmes e séries não se bloqueiam pelo nome
- mantém carrossel, recentes, notas, cache, TMDB, offline e assinatura fixa
- versionCode 60
