GreenPlay Android v16.52

Correção focada no atraso e nas travadas observadas nos vídeos 4585478/4585479.

- A troca de servidor não espera mais o catálogo Xtream inteiro.
- O bootstrap prepara somente as categorias necessárias para a Home inicial.
- A Home abre com o conteúdo inicial pronto e não dispara o preenchimento de todas as categorias em segundo plano.
- As categorias restantes continuam disponíveis nas telas Filmes/Séries e vêm direto da Xtream quando acessadas.
- O carregamento crítico de capas antes da Home foi limitado a 0,9 s.
- Catálogo continua sem cache persistente.
- Logo, TMDB, provedores, banco e configurações permanecem inalterados.
- Requer PATCH de painel v72.3 sobre v72.2 para o bootstrap rápido.
