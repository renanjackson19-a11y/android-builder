GreenPlay Android v16.55

Ajuste somente no topo da Home, mantendo a base v16.54.

O que mudou:
- logo do painel alinhada à esquerda no topo da Home;
- barra de busca reorganizada ao lado da logo;
- ícone de busca posicionado à direita, no estilo da referência;
- primeira aba da Home exibida como “Início” (internamente continua ligada ao fluxo de Recomendações);
- abas da Home com visual mais compacto e horizontal, inspiradas na referência do ZappTV;
- nenhuma alteração em TMDB, provedores, banco, painel ou carregamento do catálogo.

Observação:
- cores/tema do GreenPlay foram preservados; a referência foi usada apenas para composição do topo.
