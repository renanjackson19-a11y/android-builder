GreenPlay Android Nativo v16.43

Correção específica:
- remove a mensagem "Preparando reprodução..."
- usa primeiro a URL de reprodução já entregue no catálogo
- a troca de servidor prepara imagens e detalhes críticos antes de abrir a Home
- não faz prefetch de detalhes depois que a Home já abriu
- fallback de content_detail fica silencioso apenas se algum item realmente não tiver URL pronta
- mantém TV condicional por fonte da v16.42
- versionCode 65

Requer o PATCH do painel v72.1 para que filmes do catálogo já tragam URL de reprodução quando o usuário tem acesso.
