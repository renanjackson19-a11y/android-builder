GreenPlay Android Nativo v16.27

Base: v16.26

Tela de detalhes refeita no código do aplicativo para seguir a referência enviada:
- hero grande com título sobre a arte
- badge TMDB e metadados mais limpos
- gênero em chips
- botão Assistir preenchendo a largura
- botão offline com contorno verde
- Sinopse dentro de card com título e ícone
- Elenco com "Ver todos" e avatares maiores
- barra inferior própria nos detalhes: Início, Buscar, GreenPlay, Minha Lista e Perfil
- GreenPlay central destacado em verde
- navegação, cache, TMDB, offline privado e assinatura fixa preservados
- versionCode 48 / versionName 1.16.27
