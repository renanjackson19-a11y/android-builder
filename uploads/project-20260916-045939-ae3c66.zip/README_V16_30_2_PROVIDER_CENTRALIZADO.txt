GreenPlay Android Nativo v16.30.2

Base: v16.30.1

Ajustes:
- bloco da escolha de servidor centralizado verticalmente
- redução do espaço morto inferior
- cards mais compactos
- quadrado/ícone do servidor reduzido de 62dp para 46dp
- altura dos cards reduzida de 92dp para 74dp
- tipografia e espaçamento refinados
- preservados logo e cor vindos do painel
- preservado o mesmo fundo cinematográfico do login
- preservada a assinatura fixa
- versionCode 52 / versionName 1.16.30.2

Observação: este projeto não inclui o Gradle Wrapper; compile pelo mesmo serviço/processo usado nas versões anteriores.
