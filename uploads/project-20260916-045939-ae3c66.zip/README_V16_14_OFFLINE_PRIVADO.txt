GreenPlay Android Nativo v16.14

Correção sobre a v16.13:
- removido completamente o Android DownloadManager
- downloads offline agora são feitos pelo serviço interno do GreenPlay
- arquivos ficam em getFilesDir()/offline, armazenamento privado do aplicativo
- não aparecem na pasta Downloads nem no gerenciador de Downloads do Android
- aba Downloads mostra progresso/estado e permite reproduzir offline ou excluir
- player abre o arquivo privado do GreenPlay
- mantidas navegação sem recarregar e demais correções da v16.13
