GreenPlay Android Nativo v16.44

Correção do fluxo de troca de servidor:
- ao tocar no servidor, o app faz somente uma leitura do catálogo já pronto no painel/fonte
- remove a etapa extra de preparar Filmes/Séries/TV antes de abrir a Home
- remove prefetch de imagens/detalhes como bloqueio da entrada
- a Home abre assim que section_list retorna com conteúdo
- URLs de reprodução já vindas do painel são usadas imediatamente
- TV continua condicional conforme a capacidade informada pelo provedor
- sem cache persistente do catálogo
- versionCode 66
