GreenPlay Android v16.51

Correção focada no carregamento/troca de servidor:
- A Home não é mais aberta enquanto categorias ainda estão sendo acrescentadas.
- Novo bootstrap único e paralelo: recebe a primeira página de todas as categorias de Filmes e Séries direto da Xtream.
- Filmes e Séries são preparados ao mesmo tempo, sem a cascata de content_by_category depois que a Home abre.
- A primeira tela aquece somente as imagens críticas, com limite curto, para não voltar à demora da v16.47.
- Quando o snapshot está completo, a Home não dispara complementação de categorias nem prefetch de detalhes em segundo plano.
- Sem cache persistente do catálogo: o snapshot continua somente em memória.
- TV permanece condicional ao provedor ter canais.

Requer o PATCH painel v72.2 para usar o bootstrap paralelo. Se o endpoint ainda não estiver instalado, o APK mantém fallback compatível.
