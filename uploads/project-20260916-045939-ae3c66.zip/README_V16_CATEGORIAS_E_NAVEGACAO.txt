GreenPlay Android Nativo v16
- Explorar agora segue o fluxo da referencia: carrossel + continue assistindo.
- Filmes e Series carregam TODAS as categorias do provedor, sem limite artificial de 4.
- Filtro por tipo usa type_id/video_type, nao o texto do nome da categoria.
- Ao tocar na seta da categoria, abre grade completa da categoria.
- MainActivity fixada em retrato para nao ser recriada ao voltar do player em paisagem.
- Retorno do player preserva a tela anterior em vez de cair no Inicio por rotacao.
