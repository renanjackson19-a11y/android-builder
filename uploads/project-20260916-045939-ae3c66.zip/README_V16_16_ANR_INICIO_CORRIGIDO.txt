GreenPlay Android Nativo v16.16

Correções sobre a v16.15:
- corrige ANR ao tocar em Início saindo de Perfil/Favoritos/TV/Downloads
- Home permanece montada em memória e é apenas recolocada na tela
- posição de rolagem da Home é preservada
- abrir uma seção também não destrói a Home
- leitura/decodificação de imagens do cache em disco saiu da thread principal
- carregamento de imagens usa pool limitado de workers para evitar travamentos
- mantém offline privado, TMDB via painel e demais correções anteriores
