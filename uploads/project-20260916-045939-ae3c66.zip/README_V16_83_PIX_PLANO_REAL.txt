GreenPlay Android v16.83
Base direta: v16.82 enviada pelo usuário.

- Planos compactos preservados.
- Fluxo: Planos -> Resumo do plano -> Confirmar e pagar -> Gerando pagamento -> PIX.
- CPF não é solicitado no aplicativo; o backend usa o CPF padrão configurado no painel.
- PIX mostra QR Code quando disponível, copia e cola, botão Copiar PIX, contador e verificação automática.
- Após status COMPLETO, o app atualiza os direitos da assinatura automaticamente.
- TV ao vivo respeita simultaneamente a existência de canais no provedor e o benefício TV ao vivo do plano.
- Conteúdo adulto só pode ser ativado quando o plano comprado possui esse benefício.
- Reprodução online valida no backend o limite real de telas simultâneas; PlayerActivity mantém heartbeat e libera a sessão ao sair.
- Token/API, logo, provedores, catálogo e demais configurações anteriores foram preservados.
- Compatível com PATCH painel v72.13 sobre v72.12.
