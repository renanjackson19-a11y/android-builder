GreenPlay Android Nativo v15 - Fluxo inspirado na referência enviada

Implementado nesta versão:
- Navegação inferior: Explorar, Favoritos, TV, Downloads e Perfil.
- Home com saudação/avatar, busca, notificações, abas Explorar/Filmes/Séries.
- Carrossel de destaque preservado com vizinhos laterais.
- Continue assistindo e seções do catálogo preservadas.
- TV ao vivo refeita: busca, abas Canais/Favoritos, categorias na lateral e somente os canais da categoria selecionada na lateral direita.
- Favoritos específicos para canais.
- Ao trocar servidor, tela de carregamento de conteúdo antes de abrir a Home.
- Detalhes refeitos com capa, metadados, sinopse, elenco, Minha lista, Assistir e Download.
- Player em paisagem com controles próprios: -10s, play/pause, +10s e barra de progresso; modo ao vivo sem seek.
- Login/revenda/MisticPay/perfil existentes preservados.

Observação: o aplicativo continua consumindo as APIs do painel GreenPlay; nenhuma marca ou código do aplicativo de referência foi incorporado.
