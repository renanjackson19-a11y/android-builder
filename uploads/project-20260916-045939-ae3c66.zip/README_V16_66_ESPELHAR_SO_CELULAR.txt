GreenPlay Android v16.66

Ajuste de interface por tipo de dispositivo.

- “Espelhar na TV” permanece disponível no fluxo de filmes e episódios em celulares/tablets.
- Em Android TV, TV Box, Fire TV/Fire Stick e aparelhos reconhecidos como televisão/Leanback, a opção não é exibida.
- O restante das ações (Assistir, Baixar, Compartilhar e Continuar) permanece igual.
- Nenhuma alteração no painel.
