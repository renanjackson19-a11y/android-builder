GreenPlay Android Nativo v16.24

- Tela de detalhes abre imediatamente com dados que já vieram no catálogo.
- Remove a tela vazia bloqueada em "Carregando detalhes...".
- Cache local persistente dos detalhes por provedor + tipo + ID.
- Ao reabrir um título, dados aparecem instantaneamente e a API apenas atualiza em segundo plano.
- Primeira abertura também já mostra hero, metadados disponíveis e ações enquanto a API completa sinopse/elenco/stream.
- Falha ou lentidão da API não apaga a tela já renderizada.
- Mantidas assinatura fixa, offline privado, cache da Home, TMDB provider-first e demais correções.
