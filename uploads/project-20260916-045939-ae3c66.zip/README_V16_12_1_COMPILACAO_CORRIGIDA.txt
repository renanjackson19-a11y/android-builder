GreenPlay Android Nativo v16.12.1

Correção de compilação sobre a v16.12:
- removida referência inválida à variável local `gen` dentro de refreshIdentity()
- mantido o controle viewGen apenas nos callbacks de tela que realmente capturam `gen`
- nenhuma regressão de Home/TMDB/offline/login/TV/perfil
- versionCode incrementado para permitir atualização do APK
