GreenPlay Android Nativo v16.8

Correções aplicadas sobre a v16.7:
- bloco Bem-vindo de volta + subtítulo centralizado
- código da revenda retirado da parte inferior e transformado em botão discreto abaixo do subtítulo
- campo da revenda continua opcional e só abre ao tocar
- Home, Filmes e Séries agora usam get_category para percorrer TODAS as categorias devolvidas pelo painel
- cada categoria é carregada sequencialmente via content_by_category, evitando o corte em Aventura
- logo configurada no painel e demais correções da v16.7 preservadas
