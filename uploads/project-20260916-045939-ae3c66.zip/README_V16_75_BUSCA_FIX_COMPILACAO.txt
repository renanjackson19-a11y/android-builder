GreenPlay Android v16.75

Correção de compilação da v16.74 mantendo o ajuste da barra de busca.

- Base funcional: v16.73.
- Reaplicado somente o ajuste da barra de busca com componentes simples e compatíveis.
- Barra ativa mantém a mesma geometria da barra da Home.
- O slot da logo vira Voltar sem deslocar a busca.
- Painel permanece v72.8.
- Nenhuma alteração em TMDB, logo, provedores, banco ou catálogo.
