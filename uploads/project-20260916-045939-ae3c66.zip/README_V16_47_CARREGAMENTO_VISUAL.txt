GreenPlay Android v16.47
Base: v16.46

Ajuste desta versão
- Ao tocar em um servidor, a lista deixa de ficar apenas com "...".
- Abre imediatamente uma tela de preparação no estilo do vídeo de referência:
  * logo dinâmica do painel;
  * título "Carregando Conteúdo";
  * subtítulo "Preparando tudo para você";
  * etapas Filmes e Séries;
  * etapa Canais ao Vivo somente quando o provedor informa canais;
  * indicador animado na etapa em andamento;
  * marca verde ao concluir;
  * etapa "Finalizando" antes da Home.
- A Home só abre depois que o catálogo crítico, imagens críticas e detalhes essenciais estão preparados (com limite de espera de segurança).
- O catálogo continua vindo direto da Xtream e fica somente em memória.
- Nenhum cache persistente do catálogo foi adicionado.
- Não altera token TMDB, logo, provedores, banco ou configurações do painel.
- Painel v72.1 não foi alterado.
- TV não é exibida para contagem desconhecida/zero; apenas quando channels/live > 0.

Versão
- versionCode: 69
- versionName: 1.16.47.0

Arquivos do app alterados
- app/src/main/java/fun/greenplay/app/MainActivity.java
- app/build.gradle
