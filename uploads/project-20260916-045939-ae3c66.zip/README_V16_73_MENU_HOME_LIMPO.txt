GreenPlay Android v16.73

Ajuste somente no menu horizontal superior da Home.

- Remove repetição visual de “Filmes” e “Séries” nos nomes das categorias.
- Ex.: “Filmes Lançamentos” -> “Lançamentos”; “Filmes Guerra” -> “Guerra”.
- Mantém as abas fixas Início, Séries e Filmes.
- Mantém até 3 categorias reais do provedor, sem nomes duplicados.
- Rótulos longos ficam mais curtos para não poluir o topo.
- Nenhuma alteração no painel, catálogo, TMDB, logo, provedores ou banco.
