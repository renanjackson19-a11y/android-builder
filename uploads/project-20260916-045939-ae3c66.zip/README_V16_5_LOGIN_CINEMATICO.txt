GreenPlay Android Nativo v16.5

Base: v16.4 (sem regressão de Home, categorias, TV, Downloads, Perfil ou player).

Alterações desta versão:
- Login redesenhado no visual cinematográfico GreenPlay solicitado.
- Fundo cinematográfico verde incorporado localmente ao app (drawable-nodpi/login_cinema_bg.png).
- Logo GreenPlay em branco/verde, slogan "MAIS QUE ENTRETENIMENTO".
- Campos Email e Senha com ícones e botão de visibilidade.
- Botão Entrar com gradiente verde e botão Criar uma conta contornado.
- Link "Redefinir senha" e ajuda direcionados ao suporte configurado.
- Código da revenda preservado como opção recolhível para não remover funcionalidade existente.
- Tela de cadastro continua funcional e usa o mesmo fundo cinematográfico.
