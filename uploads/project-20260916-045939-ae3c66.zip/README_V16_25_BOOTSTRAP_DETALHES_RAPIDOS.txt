GreenPlay Android Nativo v16.25 - bootstrap e detalhes rápidos

- No login, prepara Home, imagens críticas e detalhes dos primeiros títulos antes de liberar a navegação (com limite curto de espera).
- Depois da Home, pré-carrega detalhes em segundo plano com no máximo 3 requisições simultâneas.
- Ao tocar em um título, usa catálogo/cache imediatamente, sem tela de carregamento bloqueante.
- content_detail retorna rápido; TMDB completo é pedido em content_enrich separado e assíncrono.
- Reprodução/download resolvem o link atual do cache e só consultam content_detail se ainda faltar.
- Cache de detalhes passa a mesclar respostas, preservando URL do player e metadados já obtidos.
- Assinatura debug fixa preservada.
