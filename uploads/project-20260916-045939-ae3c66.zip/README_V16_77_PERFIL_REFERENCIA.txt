GreenPlay Android v16.77

Tela Perfil redesenhada com base na referência enviada pelo usuário.

Alterações:
- cabeçalho Perfil com ícone e saída;
- cartão do usuário com avatar, nome, e-mail e vínculo GreenPlay;
- aviso de assinatura aparece somente quando a conta está inativa;
- cartão Informações da Conta com Plano, Validade, Telas, Servidor e Assinatura;
- cartão único de Opções com Benefícios, Troca de servidor, Dispositivos, Suporte, Redefinir senha, Conteúdo adulto, PIN e Excluir conta;
- Conteúdo adulto usa chave visual;
- identidade GreenPlay verde preservada;
- nenhuma alteração no painel, catálogo, TMDB, provedores ou banco.
