GreenPlay Android v16.79

Correções sobre a v16.78:
- ao abrir “Trocar de Servidor” pelo Perfil, aparece botão X no topo para cancelar e voltar ao Perfil sem trocar;
- botão Voltar do Android nessa tela também cancela a troca e retorna ao Perfil;
- a seleção obrigatória de servidor após login continua sem X, para não deixar a sessão sem servidor;
- modais de Criar/Alterar PIN e Redefinir senha não usam mais animação de janela que deslocava a tela;
- os campos não recebem foco automaticamente ao abrir, evitando a pequena puxada causada pelo ajuste da janela/teclado;
- teclado fica oculto até o usuário tocar no campo;
- sem alterações no painel, catálogo, TMDB, provedores ou banco.
