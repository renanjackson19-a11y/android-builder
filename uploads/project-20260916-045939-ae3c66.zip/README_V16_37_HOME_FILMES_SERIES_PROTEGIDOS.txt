GreenPlay Android v16.37

Correções:
- Home não aceita mais perder Filmes ou Séries por resposta parcial temporária
- mescla a última família válida do cache quando section_list vem incompleto
- força reparo em segundo plano quando faltar Filmes ou Séries
- tenta carregar categorias da família ausente mesmo se o bootstrap anterior já terminou
- mantém carrossel, recentes, notas, TMDB, offline, logo do painel e assinatura fixa
- versionCode 59
