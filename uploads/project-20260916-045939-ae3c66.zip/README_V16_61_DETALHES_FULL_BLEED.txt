GreenPlay Android v16.61

Ajuste visual da tela de detalhes usando a referência enviada.

Alterações:
- backdrop/foto do topo agora ocupa a largura inteira da tela, sem margens laterais;
- conteúdo textual mantém alinhamento e respiro lateral próprio;
- hero ficou ligeiramente mais alto para preservar o enquadramento da imagem;
- fotos do elenco ficaram maiores e continuam em CENTER_CROP para preencher o círculo;
- ao sair dos detalhes, o padding normal da Home é restaurado.

Não altera painel, catálogo, TMDB, provedores, banco ou configurações.
Base anterior: v16.60.
