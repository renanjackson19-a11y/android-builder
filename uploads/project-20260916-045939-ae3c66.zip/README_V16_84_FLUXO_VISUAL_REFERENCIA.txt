GreenPlay Android v16.84

- Base direta: v16.83.
- Fluxo de pagamento redesenhado após revisão quadro a quadro do vídeo de referência.
- Resumo do plano agora é uma tela completa, não um modal.
- Tela Gerando pagamento em página limpa com indicador central.
- PIX em tela completa: valor, selo do plano, QR compacto em cartão branco, contador, instruções, copiar PIX e status automático.
- Identidade verde dinâmica do GreenPlay preservada.
- Backend/painel v72.13 preservado; nenhuma mudança necessária no painel para este ajuste visual.
- Ativação real do plano, telas e benefícios continua sendo feita pelo backend.
