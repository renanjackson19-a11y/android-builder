GreenPlay Android v16.64

Ajustes de filmes:
- progresso de filme salvo localmente para continuar de onde parou;
- cartão de “Continuar assistindo” na tela de detalhes do filme;
- filmes com progresso aparecem imediatamente na seção “Continue assistindo” da Home;
- botão do filme abre folha de ações com Assistir/Continuar, Recomeçar, Espelhar na TV, Baixar e Compartilhar;
- ao terminar o filme, o progresso salvo é removido;
- episódios e fila automática da v16.63 foram preservados.

O progresso salvo não é cache do catálogo: guarda apenas o ponto de reprodução e metadados mínimos do item.
Painel permanece v72.7, sem alterações.
