GreenPlay Android Nativo v16.35

- Mantém a Home/cache instantânea e atualiza o catálogo em segundo plano pelo painel v69.
- Verifica novidades no máximo a cada 10 minutos por provedor, sem bloquear a interface.
- Quando chegam novos filmes, atualiza o cache da Home e, se o usuário estiver no topo, aplica a lista nova automaticamente.
- O carrossel mantém o badge de nota em todos os cards: nota real quando disponível e traço enquanto o TMDB/cache ainda não trouxe nota.
- Notas reais são formatadas com uma casa decimal.
- versionCode 57 / versionName 1.16.35.0.
