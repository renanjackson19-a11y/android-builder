GreenPlay Android Nativo v16.32

Ajustes sobre a v16.31:
- carrossel principal agora é circular de verdade (loop infinito)
- nunca fica espaço vazio nas laterais no primeiro/último destaque
- card anterior e próximo continuam parcialmente visíveis dos dois lados
- autoplay com transição suave e retorno invisível para o início
- swipe manual com snap central e continuidade circular
- indicadores acompanham o item lógico, inclusive nos clones de borda
- mantém mistura de destaques de categorias diferentes
- preservadas assinatura fixa, cache, TMDB, offline e demais correções

versionCode: 54
versionName: 1.16.32.0
