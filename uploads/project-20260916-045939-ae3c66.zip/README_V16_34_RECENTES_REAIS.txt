GreenPlay Android Nativo v16.34 — Adicionados recentemente reais

- Compatível com Painel GreenPlay v68.
- A Home usa a seção recently_added enviada pelo painel, baseada em first_seen_at por provedor.
- Removido fallback enganoso por ID alto ou ano/data de lançamento.
- O carrossel pode usar os itens realmente recentes junto com outros destaques.
- Mantém loop infinito, autoplay, cache, TMDB, offline privado e assinatura fixa.
- versionCode 56.
