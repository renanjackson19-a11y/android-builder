GreenPlay Android v16.58

Ajuste visual na seção “Adicionados recentemente”.

O que mudou:
- a seção deixou de usar o layout em cards horizontais largos;
- agora usa o mesmo layout de pôster dos demais trilhos da Home;
- mantém o mesmo comportamento de abrir detalhes ao tocar;
- nenhuma alteração em painel, TMDB, provedores, banco ou catálogo.

Base:
- app anterior: v16.57
- nova base: v16.58
