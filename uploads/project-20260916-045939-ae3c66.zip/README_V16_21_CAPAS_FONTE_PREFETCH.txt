GreenPlay Android Nativo v16.21

Correção de capas da fonte/provedor:
- capas continuam vindo diretamente das URLs entregues pelo provedor;
- TMDB não participa do carregamento das capas da Home;
- removido o atraso artificial de depender somente de lazy-load ao rolar;
- após receber o catálogo, o app pré-carrega em segundo plano as primeiras capas de todas as seções;
- imagens visíveis usam pool separado/prioritário;
- cache em memória e disco permanece ativo entre navegações;
- downloads duplicados da mesma URL são evitados com lock por imagem;
- assinatura debug fixa da v16.19 preservada;
- versionCode 42 / versionName 1.16.21.
