GreenPlay Android Nativo v16.9

Ajustes sobre a v16.8:
- centralização vertical do bloco de login
- logo e formulário descem para o meio da tela
- redução do espaço vazio na parte inferior
- topo do login menos colado no alto da tela
- mantidas as demais correções da v16.8
