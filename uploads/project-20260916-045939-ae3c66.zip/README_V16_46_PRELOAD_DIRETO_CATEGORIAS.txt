GreenPlay Android Nativo v16.46

Correção sobre a v16.45:
- corrige a seleção de servidor que parava em "Não foi possível carregar os Filmes desse servidor"
- a preparação da Home agora usa get_category + content_by_category diretamente na fonte Xtream
- carrega até 3 categorias em paralelo e tenta novamente uma categoria quando a fonte oscila
- section_list pesado ficou somente como fallback de emergência
- Filmes e Séries são preparados antes de abrir a Home; falha isolada de uma família não derruba a outra
- mantém o catálogo somente em memória da sessão, sem cache persistente
- não altera logo, token TMDB, provedores, banco, tema ou configurações do painel
- painel v72.1 não precisou ser alterado
- versionCode 68 / versionName 1.16.46.0
