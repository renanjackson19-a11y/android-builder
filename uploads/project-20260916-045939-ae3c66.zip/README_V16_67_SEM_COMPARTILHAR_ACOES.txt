GreenPlay Android v16.67

Ajuste solicitado:
- removida a opção Compartilhar da folha de ações de episódios;
- removida a opção Compartilhar da folha de ações de filmes;
- Assistir/Continuar, Espelhar na TV (somente celular/tablet) e Download permanecem.

Painel permanece v72.7, sem alteração.
