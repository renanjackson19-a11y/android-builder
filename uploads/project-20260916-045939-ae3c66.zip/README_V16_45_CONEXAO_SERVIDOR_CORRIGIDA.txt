GreenPlay Android Nativo v16.45

Correção pontual sobre a v16.44:
- corrige falha ao conectar/trocar servidor mostrada nas telas enviadas
- remove a chamada combinada pesada do section_list na troca de servidor
- Filmes e Séries são carregados separadamente e em paralelo e unidos em memória
- uma tentativa extra é feita automaticamente se uma das partes falhar
- timeout do section_list ampliado para fontes grandes
- a Home só abre com o payload preparado; não foi alterado painel, visual, TMDB, offline ou demais telas
- versionCode 67
