GreenPlay Android v16.69

Correção de colisão de IDs entre Filmes e Séries.

Problema identificado:
- Xtream pode reutilizar o mesmo número de ID para um filme e uma série.
- Ex.: filme ID 1538 e série ID 1538 são conteúdos diferentes.
- respostas antigas erradas podiam contaminar o cache de detalhes do app.

Correções no app:
- valida o tipo (Filme/Série/TV) antes de aceitar detalhe em cache;
- valida também o ID do conteúdo;
- remove automaticamente cache antigo contaminado;
- rejeita qualquer resposta de detalhe cujo tipo não corresponda ao item aberto.

Requer painel patch v72.8 para a correção completa do endpoint.
