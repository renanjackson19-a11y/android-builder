GreenPlay Android v16.49

Correção de reprodução do catálogo Xtream:
- todas as chamadas content_by_category agora enviam user_id;
- busca também envia user_id;
- itens retornados pelo painel v72.1 chegam com URL de reprodução pronta quando o acesso está ativo;
- detailPlayUrl também aceita video_320;
- se content_detail falhar, o app refaz apenas a categoria do item e recupera a URL autenticada direto da fonte, sem recarregar a Home;
- nenhuma mensagem "Preparando reprodução" é exibida;
- não altera logo, TMDB, provedores, banco ou configurações do painel;
- catálogo continua sem cache persistente da Home.

versionCode: 71
versionName: 1.16.49.0
