GreenPlay Android v16.56

Refino do topo da Home sobre a v16.55.

Ajustes:
- logo mais próxima da proporção/posição da referência;
- barra de busca mais longa, alta e com ícone à direita;
- maior respiro abaixo da barra de status;
- menu horizontal sem sublinhado, como na referência;
- ordem: Início, TV ao vivo (somente quando existir), Séries, Filmes e até duas categorias reais do provedor;
- categorias extras usam o catálogo já carregado em memória;
- não altera painel, TMDB, provedores, banco ou fluxo do catálogo.
