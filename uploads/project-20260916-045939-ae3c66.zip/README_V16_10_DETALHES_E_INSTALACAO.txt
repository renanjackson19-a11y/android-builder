GreenPlay Android Nativo v16.10

Ajustes aplicados em cima da v16.9:
- atualização do versionCode/versionName para facilitar instalar por cima da versão anterior
- tela de detalhes refeita com visual mais moderno e limpo
- banner principal maior com botões sobre a arte (voltar e favoritos)
- botões Assistir, Download e Minha Lista reorganizados e padronizados
- sinopse em card escuro com melhor leitura
- elenco exibido em chips quando disponível
- demais correções das versões anteriores preservadas
