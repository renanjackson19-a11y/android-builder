GreenPlay Android v16.85

- Base direta: v16.84.
- Refinamento visual profissional das telas de planos, resumo, geração do PIX e pagamento.
- Carregamento de planos substituído por estado visual com spinner, contexto e skeleton cards animados.
- Cards de planos mais leves, compactos e hierárquicos.
- Resumo do plano refinado e sem exibir data futura como se a assinatura já estivesse ativa.
- Tela de geração de PIX com card de progresso profissional e mensagens de etapa.
- Tela PIX refinada com QR menor, contador mais discreto, status com spinner real e feedback de cópia customizado.
- Nenhuma mudança na integração, lógica de pagamento, token, logo, provedores ou regras do plano.
- Compatível com painel patch v72.13.
