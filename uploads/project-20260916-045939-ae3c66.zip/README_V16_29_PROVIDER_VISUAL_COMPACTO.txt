GreenPlay Android v16.29

Ajustes sobre v16.28:
- tela de escolha de servidor refeita no app real
- visual mais compacto e próximo do fluxo do app de referência
- logo menor, título/subtítulo mais discretos
- cards de servidores menores e com menos espaço vazio
- tipografia e hierarquia refinadas
- tela de "Carregando conteúdo" refeita com 3 etapas compactas (Filmes, Séries, TV)
- preservado bootstrap, cache, TMDB, offline privado e assinatura fixa
