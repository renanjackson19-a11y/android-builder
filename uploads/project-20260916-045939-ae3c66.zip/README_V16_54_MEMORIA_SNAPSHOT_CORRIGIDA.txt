GreenPlay Android v16.54 — snapshot completo sem estouro de memória

Base: v16.53
Painel esperado: patch v72.5 sobre v72.4

Correções:
- remove a serialização/clonagem gigante do catálogo em saveHomeCache/readHomeCache;
- mantém UMA única instância do snapshot completo na memória da sessão;
- elimina o OutOfMemoryError mostrado no relatório (JSONObject.toString / saveHomeCache);
- limpa referências do provedor anterior ao trocar de servidor;
- reduz o cache RAM de bitmaps para preservar espaço para catálogos grandes;
- continua sem cache persistente do catálogo;
- continua recebendo Filmes + Séries + TV de uma vez antes de abrir a Home.

Não altera identidade, logo, TMDB, provedores, banco ou configurações.
