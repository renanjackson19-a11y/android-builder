GreenPlay Android v16.50

Ajuste focado somente em fluidez/travadas sobre a v16.49:
- limita concorrência global das chamadas de rede para evitar tempestade de threads quando a Home completa categorias em segundo plano;
- categorias que faltam na Home são carregadas em no máximo 2 por vez por bloco, sem bloquear ações do usuário;
- remove o OnPreDrawListener por imagem, que fazia centenas de checagens a cada frame durante a rolagem;
- reduz pressão de decode/prefetch de imagens e mantém filas separadas de imagens visíveis e pré-carregamento;
- grades e listas grandes de TV são montadas em blocos por frame para evitar congeladas da interface;
- carrossel atualiza indicadores sem recriar todas as views a cada troca;
- reduz prefetch agressivo de detalhes em segundo plano;
- player recebe URLs 1080/720/480/320 e, em rede móvel, começa priorizando 720; se houver buffering repetido, cai automaticamente para a próxima qualidade sem voltar à tela de detalhes;
- atualização da barra do player passa de 500 ms para 1 s para reduzir trabalho desnecessário durante a reprodução;
- não altera painel, TMDB, logo, provedores, banco ou configurações;
- catálogo da Home continua sem cache persistente.

versionCode: 72
versionName: 1.16.50.0
