GreenPlay Android v14.3
- provider_id enviado também pela query string (evita hospedagens/proxies que removem cabeçalhos customizados)
- provider_id enviado no corpo JSON como redundância
- lista de servidores só mostra TV ao vivo quando channels_count > 0
- compatível com painel v52
