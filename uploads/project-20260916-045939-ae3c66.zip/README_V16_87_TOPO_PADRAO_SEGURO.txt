GreenPlay Android v16.87

- Base direta: v16.86.
- Corrige sobreposição com a barra de status do Android.
- Servidores, Downloads, Favoritos, Perfil e Planos usam margem superior segura e consistente com a Home.
- Detalhes não ficam mais por baixo da barra de status; botões Voltar/Favorito permanecem dentro da área segura.
- Downloads não repete mais o título duas vezes.
- Nenhuma alteração no pagamento, catálogo, TMDB, provedores, banco ou painel.
- Painel permanece v72.14.
