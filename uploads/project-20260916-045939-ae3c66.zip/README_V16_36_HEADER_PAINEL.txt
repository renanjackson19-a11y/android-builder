GreenPlay Android Nativo v16.36

Ajustes sobre a v16.35:
- cabeçalho da Home corrigido
- remove o bloco fixo "GP" quando a logo do painel ainda não chegou
- logo do painel passa a atualizar no cabeçalho assim que general_setting responder, sem recarregar a Home
- slot da marca ficou horizontal/compacto para respeitar a proporção da logo GreenPlay
- busca e perfil alinhados no mesmo eixo
- reduzido o espaço vertical entre cabeçalho e abas Recomendações / Filmes / Séries
- mantidos carrossel, recentes reais, notas, cache, TMDB, offline e assinatura fixa
- versionCode 58 / versionName 1.16.36.0
