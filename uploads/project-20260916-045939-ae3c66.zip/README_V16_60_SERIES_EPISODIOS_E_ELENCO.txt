GreenPlay Android v16.60

Ajustes na tela de detalhes de séries:
- episódios podem vir prontos junto com o detalhe da série;
- removido o texto visível “Carregando episódios…”;
- troca de temporada usa primeiro os episódios já recebidos;
- fallback de rede permanece apenas para compatibilidade com detalhe antigo;
- elenco com fotos circulares maiores, CENTER_CROP e preenchimento total;
- removida a linha de papel/personagem abaixo do ator para ficar igual à referência;
- nomes ficam centralizados logo abaixo das fotos.

Requer painel patch v72.6 para episódios instantâneos no primeiro carregamento.
