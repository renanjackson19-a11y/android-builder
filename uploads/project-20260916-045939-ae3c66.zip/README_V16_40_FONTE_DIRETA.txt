GreenPlay Android Nativo v16.40

- Home não usa mais cache persistente do catálogo.
- Ao abrir/selecionar provedor, Filmes/Séries vêm do painel v72 em modo fonte direta.
- Voltar de detalhes mantém a Home em memória para não recarregar a tela.
- Removido catalog_refresh de fundo do app.
- Mantidos player, TMDB, offline, carrossel, logo do painel e assinatura do projeto.
- versionCode 62
