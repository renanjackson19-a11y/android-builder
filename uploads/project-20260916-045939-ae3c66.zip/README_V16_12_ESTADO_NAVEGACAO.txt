GreenPlay Android Nativo v16.12

Correções:
- callbacks da Home agora pertencem à tela que os iniciou
- respostas antigas não podem mais inserir carrossel/categorias dentro de Detalhes
- evita categorias duplicadas e carrossel fora de ordem após voltar/navegar
- Home mostra estado de carregamento e fallback por categorias quando section_list falha
- tela de detalhes ignora respostas antigas após navegação
- preservado TMDB, offline, login, TV, perfil e demais recursos da v16.11
