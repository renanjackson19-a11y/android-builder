GreenPlay Android v16.86

Base direta: v16.85.

- Perfil refinado: aviso de assinatura não invade mais Informações da Conta.
- Aviso de teste/plano vencido usa somente a identidade GreenPlay (verde/escuro), sem vermelho.
- Ao tentar reproduzir com teste encerrado ou plano vencido, abre modal profissional com Assinar/Renovar e Agora não.
- Foto de perfil real: toque no avatar/câmera para escolher uma imagem da galeria; recorte circular e persistência por usuário no aparelho.
- Placeholder da foto trocado por iniciais do cliente.
- Confirmação de saída/logout ajustada para o tema verde.
- Lógica de pagamento, MisticPay, planos, TMDB, provedores e backend preservada.
