GreenPlay Android Nativo v16.13

Correção de arquitetura sobre a v16.12.1:
- ao abrir Detalhes, a tela anterior NÃO é destruída;
- Home/Filmes/Séries/Seção atual ficam preservados no mesmo ScrollView e na mesma posição;
- ao voltar de um filme, a instância anterior reaparece imediatamente, sem chamar home() e sem "Carregando recomendações...";
- callbacks que ainda estavam completando categorias/Continue assistindo podem terminar no host oculto sem misturar conteúdo na tela de Detalhes;
- ao fechar Detalhes, callbacks de Detalhes atrasados são invalidados para não contaminar a Home;
- voltar do Player mantém a tela de Detalhes aberta, como em apps de streaming;
- botão físico/gesto Voltar fecha Detalhes e restaura a tela anterior;
- versionCode 34 / versionName 1.16.13 para atualização por cima da versão anterior;
- mantidas as correções de TMDB, offline, login, TV, perfil e categorias.
