GreenPlay Android Nativo v16.22

Base: v16.21 (assinatura fixa preservada)

Correções:
- ID/TMDB 0 não aparece mais na tela de detalhes.
- Duração formatada: abaixo de 60 min mostra "45 min"; acima de 60 min mostra "1h 12min".
- Fotos do elenco: suporta photo/profile/profile_path/image/avatar e converte profile_path do TMDB para URL CDN.
- Gêneros comuns do TMDB traduzidos para português, incluindo Action & Adventure e Sci-Fi & Fantasy.
- Nome do elenco usa fallback original_name quando necessário.
- Assinatura fixa, cache, offline e demais correções anteriores preservados.
