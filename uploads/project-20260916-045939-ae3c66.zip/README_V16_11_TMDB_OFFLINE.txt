GreenPlay Android Nativo v16.11

- Consome metadados/backdrop do painel TMDB v56.
- Atualiza hero da tela de detalhes com backdrop TMDB.
- Elenco com fotos via cast_list.
- Download offline interno do GreenPlay, com aba Downloads e exclusão por toque longo.
- Reprodução local sem internet.
- versionCode 31 / versionName 1.16.11.
