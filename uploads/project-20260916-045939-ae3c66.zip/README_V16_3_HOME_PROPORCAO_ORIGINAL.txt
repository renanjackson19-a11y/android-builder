GreenPlay Android Nativo v16.3

Base: v16.2 (sem regressão funcional).

Ajustes visuais da Home:
- Home voltou a usar o rótulo "Recomendações" no topo e "Início" no menu inferior.
- Carrossel principal voltou à proporção grande/refinada (228x318dp), em vez do card achatado da v16.2.
- Primeiro destaque abre centralizado, sem iniciar arbitrariamente no segundo item.
- Mantido o cabeçalho compacto com logo/busca/perfil.
- Mantidas categorias completas, TV, downloads, perfil e navegação corrigida do player.
