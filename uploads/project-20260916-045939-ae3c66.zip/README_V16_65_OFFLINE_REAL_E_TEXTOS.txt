GreenPlay Android v16.65

Correções desta versão:
- mensagens longas de sistema substituídas por textos curtos e profissionais;
- telas e ações de download com nomenclatura mais limpa;
- download offline passa a reconhecer HLS (.m3u8), baixar os segmentos e gerar um arquivo local real;
- suporte a playlists master, URLs relativas, byte-range e HLS AES-128;
- downloads diretos continuam suportados;
- respostas HTML/JSON inválidas não são marcadas como download concluído;
- arquivo só é marcado como pronto depois de existir e ter conteúdo válido;
- reprodução offline continua usando armazenamento privado do aplicativo.

Base anterior: v16.64
Painel: sem alteração (continua v72.7)
