GreenPlay Android v16.62

Ajustes sobre v16.61:
- séries passam a considerar temporadas inferidas de episodes_by_season quando o provedor não manda a lista de seasons no formato padrão;
- detalhes incompletos continuam pedindo enriquecimento quando faltam temporadas/episódios;
- episódios usam primeiro a lista já entregue no detalhe, sem mensagem de carregamento;
- ao terminar um episódio, o player inicia automaticamente o próximo; no fim da temporada, segue para o episódio 1 da temporada seguinte quando estiver disponível;
- título do detalhe recebeu o mesmo recuo lateral da referência.

Requer painel patch v72.7 para normalização robusta de séries.
