GreenPlay Android Nativo v16.4

Base: v16.3 (Home com proporção corrigida).

Correção desta versão:
- removido o limite artificial de 4 seções na aba Recomendações/Início;
- a Home agora percorre todas as seções/categorias retornadas por section_list;
- categorias depois de Aventura deixam de ser cortadas;
- nenhuma alteração no visual da v16.3;
- nenhuma alteração em TV, downloads, perfil, player ou painel.

A lista continua dinâmica: se o painel/API adicionar ou remover uma seção, a Home acompanha o retorno do backend.
