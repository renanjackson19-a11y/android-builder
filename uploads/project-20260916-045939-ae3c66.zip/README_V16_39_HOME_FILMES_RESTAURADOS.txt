GreenPlay Android Nativo v16.39

- Home Recomendações busca Filmes e Séries em chamadas separadas.
- Filmes voltam a ocupar o bloco superior da Home com todas as categorias disponíveis.
- Séries permanecem abaixo, sem substituir as categorias de filmes.
- Falha temporária de uma família não apaga a outra da tela.
- Categorias só são marcadas como carregadas depois que realmente retornam conteúdo.
- Mantidos carrossel, recentes, TMDB, offline, logo do painel e assinatura fixa.
- versionCode 61.
