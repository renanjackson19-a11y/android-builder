GreenPlay Android Nativo v16.30

Tela de seleção de servidor ajustada sobre a v16.29:
- usa a LOGO dinâmica configurada no painel (greenplay_app_logo)
- usa a cor primária dinâmica do painel (greenplay_primary_color / verde GreenPlay)
- usa o mesmo fundo cinematográfico do login
- cards maiores e mais preenchidos, no estilo da referência enviada
- ícone do servidor, bordas e destaques na identidade GreenPlay
- texto: "Selecione o servidor que deseja conectar"
- tela de preparação do conteúdo também usa o mesmo fundo/login e logo do painel
- opção "Trocar servidor" reutiliza a mesma tela visual
- assinatura debug fixa preservada

Base: v16.29
Version code: 48
Version name: 1.16.30
