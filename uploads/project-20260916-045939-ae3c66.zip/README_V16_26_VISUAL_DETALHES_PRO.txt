GreenPlay Android Nativo v16.26

Base: v16.25.

Ajustes:
- tela de detalhes refinada no código real do aplicativo
- hero maior e com melhor acabamento
- botões voltar/favorito em estilo glass
- metadados organizados em card com divisores
- botões Assistir e Offline refinados
- sinopse em card premium
- elenco maior, com foto, nome e papel quando disponível
- chips de gênero refinados
- mais espaço inferior e melhor ritmo visual
- mantidos cache rápido, TMDB, offline privado e assinatura fixa
