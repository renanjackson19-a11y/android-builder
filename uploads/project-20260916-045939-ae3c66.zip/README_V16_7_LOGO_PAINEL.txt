GreenPlay Android Nativo v16.7

Correção aplicada em cima da v16.6:
- login agora usa a logo configurada no painel (greenplay_app_logo)
- marca em texto GreenPlay fica apenas como fallback
- carregador de imagens aceita URL absoluta, //dominio, caminho /assets/... e caminho relativo
- cache HTTP desativado para facilitar atualização da logo
- demais correções da v16.6 preservadas
