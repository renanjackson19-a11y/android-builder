GreenPlay Android v16.48

Correções desta versão:
- O carregamento ao escolher servidor não espera mais todas as categorias da Xtream.
- Filmes e Séries buscam só o conjunto crítico inicial, em paralelo, com limite visual de 9s.
- A Home abre assim que o conteúdo crítico está pronto; imagens/detalhes continuam aquecendo em segundo plano.
- As categorias restantes entram silenciosamente depois, sem “Carregando recomendações”.
- O catálogo continua vindo direto da fonte e continua sem cache persistente.
- O conteúdo preparado passa a ficar em memória de processo para não recarregar ao apenas sair/voltar do app.
- Ao usar Voltar na Home, o app vai para segundo plano em vez de destruir a sessão.
- Se o Android encerrar completamente o processo/forçar parada, o catálogo é preparado novamente (necessário para manter a regra sem cache persistente).
- TV continua aparecendo somente para provedor que informa canais.
- Painel, TMDB, logo, provedores, banco e configurações não foram alterados.

Base: v16.47
versionCode: 70
versionName: 1.16.48.0
