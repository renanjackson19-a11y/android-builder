package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.*;
import java.util.List;

public class UniversalHomeActivity extends Activity {
    private LinearLayout list; private TextView title;
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);Ui.immersive(this);
        LinearLayout root=Ui.column(this);root.setBackground(Ui.diagonalGradient(0xFF07160B,0xFF010402,0,this));root.setPadding(Ui.dp(this,22),Ui.dp(this,14),Ui.dp(this,22),Ui.dp(this,14));
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);title=Ui.text(this,"GREEN PLAY • "+UniversalSession.name(this),20,Color.WHITE,true);head.addView(title,new LinearLayout.LayoutParams(0,Ui.dp(this,52),1));
        TextView exit=Ui.button(this,"TROCAR SERVIDOR");head.addView(exit,new LinearLayout.LayoutParams(Ui.dp(this,180),Ui.dp(this,44)));exit.setOnClickListener(v->{UniversalSession.clear(this);Session.clear(this);startActivity(new Intent(this,LoginActivity.class));finish();});root.addView(head);
        LinearLayout tabs=new LinearLayout(this);String[] labs={"TV AO VIVO","FILMES","SÉRIES"};String[] types={"live","movie","series"};for(int x=0;x<3;x++){final String t=types[x];TextView tabButton=(x==0?Ui.primaryButton(this,labs[x]):Ui.button(this,labs[x]));tabButton.setOnClickListener(v->load(t));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,Ui.dp(this,48),1);bp.leftMargin=Ui.dp(this,4);bp.rightMargin=Ui.dp(this,4);tabs.addView(tabButton,bp);}root.addView(tabs);
        ScrollView sc=new ScrollView(this);list=Ui.column(this);sc.addView(list);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);load("live");
    }
    private void load(String type){list.removeAllViews();list.addView(Ui.text(this,"Carregando "+("live".equals(type)?"canais":"movie".equals(type)?"filmes":"séries")+"...",13,Ui.MUTED,false));
        UniversalXtream.list(UniversalSession.host(this),UniversalSession.user(this),UniversalSession.pass(this),type,new UniversalXtream.Callback<List<UniversalXtream.Entry>>(){
            public void ok(List<UniversalXtream.Entry> rows){runOnUiThread(()->{list.removeAllViews();for(UniversalXtream.Entry e:rows){
                LinearLayout row=new LinearLayout(UniversalHomeActivity.this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(Ui.dp(UniversalHomeActivity.this,12),0,Ui.dp(UniversalHomeActivity.this,12),0);row.setBackground(Ui.stroke(0xD9141921,0xFF253C2D,14,UniversalHomeActivity.this));
                ImageView img=new ImageView(UniversalHomeActivity.this);img.setScaleType(ImageView.ScaleType.CENTER_CROP);row.addView(img,new LinearLayout.LayoutParams(Ui.dp(UniversalHomeActivity.this,54),Ui.dp(UniversalHomeActivity.this,54)));if(e.logo!=null&&!e.logo.isEmpty())ImageLoader.into(UniversalHomeActivity.this,img,e.logo);
                TextView n=Ui.text(UniversalHomeActivity.this,e.name,14,Color.WHITE,true);LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(0,Ui.dp(UniversalHomeActivity.this,58),1);np.leftMargin=Ui.dp(UniversalHomeActivity.this,12);row.addView(n,np);
                LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,Ui.dp(UniversalHomeActivity.this,64));rp.bottomMargin=Ui.dp(UniversalHomeActivity.this,7);list.addView(row,rp);
                row.setOnClickListener(v->{if("series".equals(e.type)){Intent i=new Intent(UniversalHomeActivity.this,UniversalSeriesActivity.class);i.putExtra("series_id",e.seriesId);i.putExtra("name",e.name);startActivity(i);}else{String u=UniversalXtream.stream(UniversalSession.host(UniversalHomeActivity.this),UniversalSession.user(UniversalHomeActivity.this),UniversalSession.pass(UniversalHomeActivity.this),e.type,e.id,e.ext);Intent i=new Intent(UniversalHomeActivity.this,UniversalPlayerActivity.class);i.putExtra("url",u);startActivity(i);}});
            }});}
            public void error(String m){runOnUiThread(()->{list.removeAllViews();list.addView(Ui.text(UniversalHomeActivity.this,m,13,Ui.RED,true));});}
        });
    }
}
