GreenPlay v16.161

Base: v16.159 (render estável)

- removida a tentativa FILL que causava tela cinza;
- vídeo permanece FIT, sem zoom/crop;
- PlayerView é dimensionado pelo aspecto real do canal e centralizado;
- somente as áreas laterais restantes são preenchidas pelo fundo do player;
- EPG continua dentro do vídeo.
