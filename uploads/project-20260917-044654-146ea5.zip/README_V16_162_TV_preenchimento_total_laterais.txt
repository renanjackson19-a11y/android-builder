GreenPlay v16.162

Base: v16.161

- Preenchimento real das laterais no modo TV.
- O vídeo passa a ocupar toda a largura do player, sem crop.
- Sem tela cinza.
- EPG continua dentro do player.
