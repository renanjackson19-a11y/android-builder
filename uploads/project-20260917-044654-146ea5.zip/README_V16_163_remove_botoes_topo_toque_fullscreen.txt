GreenPlay v16.163

Base: v16.162

Ajustes:
- remove os botões Som e Tela cheia do topo do player;
- toque/click no player agora abre tela cheia;
- no preview do modo TV, o OK/Enter no player também abre tela cheia;
- mantém preenchimento lateral e EPG dentro do player.
