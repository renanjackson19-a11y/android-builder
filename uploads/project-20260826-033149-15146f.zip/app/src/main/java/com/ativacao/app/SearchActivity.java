package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.speech.RecognizerIntent;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class SearchActivity extends Activity {
    private final ArrayList<ApiClient.Item> items = new ArrayList<>();
    private GridView grid; private ResultAdapter adapter; private EditText query; private TextView title, status;
    private final Handler handler = new Handler(); private Runnable searchTask; private boolean phone;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b); Ui.immersive(this); phone = Ui.phone(this); setContentView(build()); clearResults();
    }

    private View build() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.HORIZONTAL);
        root.setBackground(Ui.diagonalGradient(Ui.BG_2, Ui.BG, 0, this));
        root.setPadding(Ui.dp(this, phone?14:24), Ui.dp(this, 16), Ui.dp(this, phone?14:24), Ui.dp(this, 16));

        // Painel do teclado: compacto, retangular e pensado para controle remoto.
        LinearLayout left = Ui.column(this);
        left.setPadding(Ui.dp(this, 20), Ui.dp(this, 18), Ui.dp(this, 20), Ui.dp(this, 18));
        left.setBackground(Ui.round(0xFF111411, 8, this));

        TextView h = Ui.text(this, "PESQUISAR CANAL", phone?17:21, Ui.TEXT, true);
        left.addView(h, new LinearLayout.LayoutParams(-1, Ui.dp(this, 42)));

        query = new EditText(this);
        query.setSingleLine(true);
        query.setHint("Digite o nome do canal");
        query.setHintTextColor(Ui.MUTED);
        query.setTextColor(Ui.TEXT);
        query.setTextSize(phone?12:14);
        query.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        query.setBackground(Ui.stroke(0xFF090B09, Ui.GREEN, 4, this));
        query.setPadding(Ui.dp(this, 14),0,Ui.dp(this,14),0);
        if(android.os.Build.VERSION.SDK_INT>=21) query.setShowSoftInputOnFocus(false);
        LinearLayout.LayoutParams qp=new LinearLayout.LayoutParams(-1,Ui.dp(this,48));
        qp.bottomMargin=Ui.dp(this,12); left.addView(query,qp);

        // Ações essenciais, como no aparelho de referência, mas no visual Dubai Play.
        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        TextView space = keyButton("ESPAÇO / PULAR", 9);
        TextView clear = keyButton("LIMPAR", 10);
        TextView erase = keyButton("⌫ APAGAR", 10);
        TextView search = keyButton("BUSCAR", 10);
        space.setOnClickListener(v->{
            String cur=query.getText().toString();
            if(!cur.endsWith(" ")){query.setText(cur+" ");query.setSelection(query.length());}
        });
        clear.setOnClickListener(v->{query.setText("");clearResults();});
        erase.setOnClickListener(v->{int len=query.length();if(len>0){query.getText().delete(len-1,len);query.setSelection(query.length());}});
        erase.setOnLongClickListener(v->{query.setText("");clearResults();return true;});
        search.setOnClickListener(v->runTypedSearch());
        TextView[] actionButtons={space,clear,erase,search};
        for(int i=0;i<actionButtons.length;i++){
            LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,Ui.dp(this,44),1);
            if(i<actionButtons.length-1)ap.rightMargin=Ui.dp(this,5);
            actions.addView(actionButtons[i],ap);
        }
        LinearLayout.LayoutParams actp=new LinearLayout.LayoutParams(-1,Ui.dp(this,44)); actp.bottomMargin=Ui.dp(this,10); left.addView(actions,actp);

        TextView keypad = Ui.text(this, "TECLADO", 10, Ui.GREEN, true);
        LinearLayout.LayoutParams kp = new LinearLayout.LayoutParams(-1, Ui.dp(this, 26)); left.addView(keypad, kp);

        // Teclado completo A-Z + 0-9 em 6x6: tudo visível em TV/TV Box sem cortar linhas.
        String keys="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        LinearLayout keyWrap=Ui.column(this);
        final int cols=6;
        for(int r=0;r<6;r++){
            LinearLayout line=new LinearLayout(this);
            for(int c=0;c<cols;c++){
                int idx=r*cols+c;
                String key=String.valueOf(keys.charAt(idx));
                TextView b=keyButton(key,13);
                b.setOnClickListener(v->{query.setText(query.getText().toString()+key);query.setSelection(query.length());});
                LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,Ui.dp(this,39),1);
                if(c<cols-1)p.rightMargin=Ui.dp(this,4);
                p.bottomMargin=Ui.dp(this,4);
                line.addView(b,p);
            }
            keyWrap.addView(line,new LinearLayout.LayoutParams(-1,Ui.dp(this,43)));
        }
        left.addView(keyWrap,new LinearLayout.LayoutParams(-1,-2));

        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(Ui.dp(this,phone?300:410),-1);
        lp.rightMargin=Ui.dp(this,22);root.addView(left,lp);

        LinearLayout right=Ui.column(this);
        title=Ui.text(this,"CANAIS AO VIVO",phone?19:24,Ui.TEXT,true);
        right.addView(title,new LinearLayout.LayoutParams(-1,Ui.dp(this,46)));
        status=Ui.text(this,"Digite o nome do canal e pressione BUSCAR.",phone?12:15,Ui.MUTED,false);
        status.setGravity(Gravity.CENTER);
        right.addView(status,new LinearLayout.LayoutParams(-1,Ui.dp(this,54)));
        grid=new GridView(this);
        grid.setNumColumns(phone?4:5);
        grid.setHorizontalSpacing(Ui.dp(this,10));grid.setVerticalSpacing(Ui.dp(this,12));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);grid.setSelector(android.R.color.transparent);
        adapter=new ResultAdapter();grid.setAdapter(adapter);
        right.addView(grid,new LinearLayout.LayoutParams(-1,0,1));
        root.addView(right,new LinearLayout.LayoutParams(0,-1,1));

        // Digitar não mostra catálogo inteiro. BUSCAR/Enter executa a consulta.
        query.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b,int c){
                if(s==null||s.toString().trim().isEmpty())clearResults();
                else { items.clear(); if(adapter!=null)adapter.notifyDataSetChanged(); title.setText("CANAIS AO VIVO"); status.setText("Pressione BUSCAR para consultar canais."); }
            }
            public void afterTextChanged(Editable e){}
        });
        query.setOnEditorActionListener((v,actionId,event)->{if(actionId==EditorInfo.IME_ACTION_SEARCH){runTypedSearch();return true;}return false;});
        query.requestFocus();
        return root;
    }

    private TextView keyButton(String text,int size){
        TextView b=Ui.ghostButton(this,text);
        b.setTextSize(size);
        b.setGravity(Gravity.CENTER);
        b.setSingleLine(true);
        b.setPadding(Ui.dp(this,2),0,Ui.dp(this,2),0);
        b.setFocusable(true);b.setClickable(true);
        Ui.focus(b,this,Ui.round(0xFF2A2E2B,2,this),Ui.stroke(0xFF2A2E2B,Ui.GREEN,2,this));
        return b;
    }

    private void runTypedSearch(){
        String q=query.getText()==null?"":query.getText().toString().trim();
        if(q.isEmpty()){clearResults();return;}
        doSearch(q);
    }

    private void clearResults(){
        title.setText("CANAIS AO VIVO");
        status.setText("Digite o nome do canal e pressione BUSCAR.");
        items.clear();
        if(adapter!=null) adapter.notifyDataSetChanged();
    }

    private void doSearch(String q){
        title.setText("Resultados para “"+q+"”");status.setText("Pesquisando canais...");
        ApiClient.catalog("live",1,120,q,"","",new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage live){runOnUiThread(()->{
                items.clear();items.addAll(live.items);adapter.notifyDataSetChanged();
                status.setText(items.isEmpty()?"Nenhum canal encontrado":"");if(!items.isEmpty())grid.requestFocus();
            });}
            public void error(String e){runOnUiThread(()->{items.clear();adapter.notifyDataSetChanged();status.setText("Nenhum canal encontrado");});}
        });
    }

    private void voiceSearch(){
        try{
            Intent in=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            in.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            in.putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.getDefault());
            in.putExtra(RecognizerIntent.EXTRA_PROMPT,"Fale o nome do canal");
            startActivityForResult(in,990);
        }catch(Exception e){Toast.makeText(this,"Busca por voz não disponível neste aparelho",Toast.LENGTH_SHORT).show();}
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==990&&resultCode==RESULT_OK&&data!=null){
            ArrayList<String> r=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if(r!=null&&!r.isEmpty()){query.setText(r.get(0));query.setSelection(query.length());}
        }
    }

    private class ResultAdapter extends BaseAdapter {
        public int getCount(){return items.size();}
        public Object getItem(int p){return items.get(p);}
        public long getItemId(int p){return items.get(p).id;}
        public View getView(int p,View convert,android.view.ViewGroup parent){
            FrameLayout card;ImageView img;TextView n,meta;
            if(convert==null){
                card=new FrameLayout(SearchActivity.this);card.setFocusable(true);card.setClickable(true);card.setClipToOutline(true);
                Ui.focus(card,SearchActivity.this,Ui.round(Color.TRANSPARENT,3,SearchActivity.this),Ui.stroke(Color.argb(75,255,255,255),Ui.GREEN,3,SearchActivity.this));
                img=new ImageView(SearchActivity.this);img.setId(501);img.setScaleType(ImageView.ScaleType.CENTER_CROP);img.setBackgroundColor(Ui.PANEL_2);card.addView(img,new FrameLayout.LayoutParams(-1,-1));
                View shade=new View(SearchActivity.this);shade.setBackground(Ui.verticalGradient(Color.TRANSPARENT,Color.argb(225,0,0,0),0,SearchActivity.this));card.addView(shade,new FrameLayout.LayoutParams(-1,-1));
                LinearLayout labels=Ui.column(SearchActivity.this);labels.setPadding(Ui.dp(SearchActivity.this,6),0,Ui.dp(SearchActivity.this,6),Ui.dp(SearchActivity.this,5));
                n=Ui.text(SearchActivity.this,"",phone?9:11,Ui.TEXT,true);n.setId(502);n.setMaxLines(2);labels.addView(n,new LinearLayout.LayoutParams(-1,0,1));
                meta=Ui.text(SearchActivity.this,"",8,Ui.GREEN,true);meta.setId(503);labels.addView(meta,new LinearLayout.LayoutParams(-1,Ui.dp(SearchActivity.this,18)));
                card.addView(labels,new FrameLayout.LayoutParams(-1,Ui.dp(SearchActivity.this,52),Gravity.BOTTOM));convert=card;
            }
            card=(FrameLayout)convert;img=convert.findViewById(501);n=convert.findViewById(502);meta=convert.findViewById(503);
            ApiClient.Item item=items.get(p);n.setText(clean(item.name,"Sem nome"));
            meta.setText("");
            ImageLoader.into(SearchActivity.this,img,clean(item.logo,item.backdrop));
            card.setOnClickListener(v->{
                Intent in=new Intent(SearchActivity.this,LiveTvActivity.class);
                in.putExtra("open_channel_id",item.id);
                in.putExtra("open_channel_name",clean(item.name,""));
                in.putExtra("open_channel_logo",clean(item.logo,""));
                in.putExtra("open_channel_group",clean(item.group,""));
                startActivity(in);
                finish();
            });
            return convert;
        }
    }

    private String clean(String v,String f){if(v==null)return f;String s=v.trim();return s.isEmpty()||"null".equalsIgnoreCase(s)?f:s;}
    @Override protected void onResume(){super.onResume();Ui.immersive(this);}
    @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);super.onDestroy();}
}
