package com.ativacao.app;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;

public final class DeviceControl {
    private DeviceControl() {}

    public static ComponentName admin(Context c) { return new ComponentName(c, AdminReceiver.class); }

    public static boolean isSupported(Context c) {
        return c.getPackageManager().hasSystemFeature(PackageManager.FEATURE_DEVICE_ADMIN);
    }

    public static boolean isDeviceOwner(Context c) {
        try {
            DevicePolicyManager dpm = (DevicePolicyManager)c.getSystemService(Context.DEVICE_POLICY_SERVICE);
            return dpm != null && dpm.isDeviceOwnerApp(c.getPackageName());
        } catch (Throwable e) { return false; }
    }

    public static boolean protectActivator(Context c) {
        if (!isDeviceOwner(c)) return false;
        try {
            DevicePolicyManager dpm = (DevicePolicyManager)c.getSystemService(Context.DEVICE_POLICY_SERVICE);
            dpm.setUninstallBlocked(admin(c), c.getPackageName(), true);
            return true;
        } catch (Throwable e) { return false; }
    }

    public static boolean setAsPersistentHome(Context c) {
        if (!isDeviceOwner(c)) return false;
        try {
            DevicePolicyManager dpm = (DevicePolicyManager)c.getSystemService(Context.DEVICE_POLICY_SERVICE);
            android.content.IntentFilter filter = new android.content.IntentFilter(android.content.Intent.ACTION_MAIN);
            filter.addCategory(android.content.Intent.CATEGORY_HOME);
            filter.addCategory(android.content.Intent.CATEGORY_DEFAULT);
            ComponentName activity = new ComponentName(c, LauncherActivity.class);
            dpm.addPersistentPreferredActivity(admin(c), filter, activity);
            return true;
        } catch (Throwable e) { return false; }
    }

    public static boolean setPackageBlocked(Context c, String packageName, boolean blocked) {
        if (packageName == null || packageName.trim().isEmpty() || !isDeviceOwner(c)) return false;
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false;
        try {
            DevicePolicyManager dpm = (DevicePolicyManager)c.getSystemService(Context.DEVICE_POLICY_SERVICE);
            String[] failed = dpm.setPackagesSuspended(admin(c), new String[]{packageName.trim()}, blocked);
            return failed == null || failed.length == 0;
        } catch (Throwable e) { return false; }
    }
}
