package com.ativacao.app;

import android.content.Context;
import android.content.SharedPreferences;

public final class PolicyStore {
    private static final String PREFS = "unitv_control";
    private PolicyStore() {}

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static void setLicense(Context c, String license) { p(c).edit().putString("license", license == null ? "" : license).apply(); }
    public static String getLicense(Context c) { return p(c).getString("license", ""); }
    public static void setControlUrl(Context c, String url) { p(c).edit().putString("control_url", clean(url)).apply(); }
    public static String getControlUrl(Context c) { return p(c).getString("control_url", ""); }
    public static void setSyncMinutes(Context c, int minutes) { p(c).edit().putInt("sync_minutes", Math.max(15, minutes)).apply(); }
    public static int getSyncMinutes(Context c) { return Math.max(15, p(c).getInt("sync_minutes", 15)); }
    public static void setLastPolicy(Context c, boolean blocked, String pkg, String message) {
        p(c).edit().putBoolean("blocked", blocked).putString("unitv_package", pkg == null ? "" : pkg)
                .putString("block_message", message == null ? "" : message).apply();
    }
    private static String clean(String s) {
        if (s == null) return "";
        s = s.trim();
        while (s.endsWith("/")) s = s.substring(0, s.length()-1);
        return s;
    }
}
