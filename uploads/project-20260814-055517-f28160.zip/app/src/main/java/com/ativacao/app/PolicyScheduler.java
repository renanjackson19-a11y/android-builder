package com.ativacao.app;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;

public final class PolicyScheduler {
    private static final int JOB_ID = 74123;
    private PolicyScheduler() {}
    public static void schedule(Context c) {
        if (PolicyStore.getControlUrl(c).isEmpty() || PolicyStore.getLicense(c).isEmpty()) return;
        try {
            long interval = Math.max(15, PolicyStore.getSyncMinutes(c)) * 60_000L;
            JobInfo job = new JobInfo.Builder(JOB_ID, new ComponentName(c, PolicyJobService.class))
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                    .setPersisted(true)
                    .setPeriodic(interval)
                    .build();
            JobScheduler js = (JobScheduler)c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            if (js != null) js.schedule(job);
        } catch (Throwable ignored) {}
    }
}
