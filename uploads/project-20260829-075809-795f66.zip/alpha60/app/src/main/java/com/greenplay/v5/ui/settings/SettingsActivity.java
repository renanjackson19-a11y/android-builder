package com.greenplay.v5.ui.settings;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.greenplay.v5.BuildConfig;
import com.greenplay.v5.core.config.AppControlStore;
import com.greenplay.v5.core.config.BrandingStore;
import com.greenplay.v5.core.config.BrandingUi;
import com.greenplay.v5.core.config.ServerDirectoryStore;
import com.greenplay.v5.core.network.NetworkProvider;
import com.greenplay.v5.core.session.SessionStore;
import com.greenplay.v5.data.model.AppConfigResponse;
import com.greenplay.v5.databinding.ActivitySettingsBinding;
import com.greenplay.v5.ui.login.LoginActivity;
import com.squareup.picasso.Target;
import java.io.File;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/** GREEN PLAY settings center. The panel controls global defaults; this screen exposes them inside the app. */
public final class SettingsActivity extends AppCompatActivity {
    private ActivitySettingsBinding b;
    private SessionStore session;
    private BrandingStore branding;
    private AppControlStore control;
    private Target backgroundTarget;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        b = ActivitySettingsBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        session = new SessionStore(this);
        branding = new BrandingStore(this);
        control = new AppControlStore(this);
        render();
        bind();
        refreshFromPanel(false);
    }

    private void render() {
        BrandingUi.applyHeaderBrand(b.settingsBrandName, b.settingsLogo, branding);
        BrandingUi.applyBannerFit(b.settingsPromoBanner, branding);
        backgroundTarget = BrandingUi.applyBackground(b.getRoot(), branding);
        String currentUser = session.user().isEmpty() ? "Cliente GREEN PLAY" : session.user();
        b.accountUser.setText(currentUser);
        b.accountUserInfo.setText(currentUser);
        String welcomeSubtitle = "Sua conta está ativa e pronta para assistir.";
        long days = daysRemaining(session.expires());
        if (!session.expires().trim().isEmpty() && days <= 0L) {
            welcomeSubtitle = "Sua assinatura expirou — renove para continuar.";
        }
        b.welcomeTitle.setText("Olá, " + currentUser + " 👋");
        b.welcomeSubtitle.setText(welcomeSubtitle);
        String initial = currentUser.trim().isEmpty() ? "G" : currentUser.trim().substring(0, 1).toUpperCase(java.util.Locale.ROOT);
        b.accountAvatar.setText(initial);
        BrandingUi.applyProfilePhoto(b.accountPhoto, b.accountAvatar, branding);
        b.accountServer.setText(session.host().isEmpty() ? "Servidor não definido" : session.host());
        String plan = session.plan();
        if (plan == null || plan.trim().isEmpty() || "active".equalsIgnoreCase(plan.trim())) plan = "PREMIUM";
        b.accountPlan.setText("★ " + plan.toUpperCase(java.util.Locale.ROOT));
        b.accountStatus.setText(session.host().isEmpty() ? "Servidor não conectado" : "Conectada ao servidor IPTV");
        b.accountPasswordInfo.setText(session.pass().trim().isEmpty() ? "Não definida" : "Definida");
        b.accountDays.setText(String.valueOf(Math.max(0L, days)));
        b.accountExpires.setText(formatExpiry(session.expires()));
        long last = control.lastSync();
        b.accountSync.setText(last <= 0L ? "Aguardando sincronização com o painel" : "Painel sincronizado • " + DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(new Date(last)));

        List<String> enabled = new ArrayList<>();
        if (control.sectionEnabled("tv")) enabled.add("TV");
        if (control.sectionEnabled("football")) enabled.add("Futebol");
        if (control.sectionEnabled("movies")) enabled.add("Filmes");
        if (control.sectionEnabled("series")) enabled.add("Séries");
        if (control.sectionEnabled("kids")) enabled.add("Kids");
        if (control.sectionEnabled("anime")) enabled.add("Animes");
        if (control.sectionEnabled("hot")) enabled.add("HOT");
        b.cardSectionsInfo.setText("Acesso rápido");
        b.cardPlaybackInfo.setText("Avisos do aplicativo");
        String sub = control.subtitleSize();
        b.cardLanguageInfo.setText("Áudio " + control.preferredAudio().toUpperCase(java.util.Locale.ROOT) + " • legenda " + subtitleLabel(sub));
        boolean hasPin = getSharedPreferences("green_play_parental", MODE_PRIVATE).contains("pin");
        b.cardParentalInfo.setText(hasPin ? "PIN local configurado" : "Definir PIN");
        b.cardCacheInfo.setText("Arquivos temporários");
        int remote = control.updateVersionCode();
        b.cardUpdateInfo.setText(remote > BuildConfig.VERSION_CODE ? "Nova versão disponível" : "Versão atual" );
        b.cardSupportInfo.setText(control.supportWhatsapp().isEmpty() && control.supportWebsite().isEmpty() ? "Não configurado" : "WhatsApp / site");
        b.cardAboutInfo.setText("Versão " + BuildConfig.VERSION_NAME);
        b.cardParental.setVisibility(branding.showParental() ? View.VISIBLE : View.GONE);
        b.cardUpdate.setVisibility(branding.showUpdate() ? View.VISIBLE : View.VISIBLE);
        b.cardCache.setVisibility(branding.showClearCache() ? View.VISIBLE : View.VISIBLE);
        b.cardSupport.setVisibility(branding.showSupport() ? View.VISIBLE : View.VISIBLE);
        b.cardAbout.setVisibility(branding.showAbout() ? View.VISIBLE : View.VISIBLE);
        b.settingsOnline.setText(control.lastSync() > 0L ? "●  PAINEL CONECTADO" : "●  VERIFICANDO PAINEL");
    }

    private void bind() {
        b.settingsBack.setOnClickListener(v -> finish());
        b.settingsLogout.setOnClickListener(v -> confirmLogout());
        b.settingsSwitch.setOnClickListener(v -> switchAccount());
        b.cardRefresh.setOnClickListener(v -> refreshFromPanel(true));
        b.cardSections.setOnClickListener(v -> showFavorites());
        b.cardPlayback.setOnClickListener(v -> showNotifications());
        b.cardLanguage.setOnClickListener(v -> showLanguage());
        b.cardParental.setOnClickListener(v -> configureParentalPin());
        b.cardCache.setOnClickListener(v -> clearCache());
        b.cardUpdate.setOnClickListener(v -> openUpdate());
        b.cardSupport.setOnClickListener(v -> openSupport());
        b.cardAbout.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle(branding.appName())
                .setMessage("Versão " + BuildConfig.VERSION_NAME + "\n\n" + (!branding.about().isEmpty() ? branding.about() : (branding.accountTitle().isEmpty() ? "GREEN PLAY" : branding.accountTitle())))
                .setPositiveButton("OK", null).show());
    }

    private void refreshFromPanel(boolean userAction) {
        if (userAction) {
            b.settingsOnline.setText("●  SINCRONIZANDO...");
            b.cardRefresh.setEnabled(false);
        }
        NetworkProvider.panel().appConfig().enqueue(new Callback<AppConfigResponse>() {
            @Override public void onResponse(Call<AppConfigResponse> call, Response<AppConfigResponse> response) {
                AppConfigResponse cfg = response.body();
                if (!response.isSuccessful() || cfg == null || !cfg.ok) {
                    runOnUiThread(() -> finishSync(false, userAction));
                    return;
                }
                if (cfg.branding != null) new BrandingStore(SettingsActivity.this).save(cfg.branding);
                new AppControlStore(SettingsActivity.this).save(cfg);
                if (cfg.universal != null && cfg.universal.servers != null) new ServerDirectoryStore(SettingsActivity.this).save(cfg.universal.servers);
                runOnUiThread(() -> {
                    branding = new BrandingStore(SettingsActivity.this);
                    control = new AppControlStore(SettingsActivity.this);
                    render();
                    finishSync(true, userAction);
                });
            }
            @Override public void onFailure(Call<AppConfigResponse> call, Throwable t) {
                runOnUiThread(() -> finishSync(false, userAction));
            }
        });
    }

    private void finishSync(boolean ok, boolean toast) {
        b.cardRefresh.setEnabled(true);
        b.settingsOnline.setText(ok ? "●  PAINEL CONECTADO" : "●  PAINEL OFFLINE");
        if (toast) Toast.makeText(this, ok ? "Configuração atualizada" : "Não foi possível atualizar agora", Toast.LENGTH_SHORT).show();
    }

    private void showSections() {
        StringBuilder text = new StringBuilder();
        String[] keys = {"tv","football","movies","series","kids","anime","hot","favorites"};
        String[] labels = {"TV","Futebol","Filmes","Séries","Kids","Animes","HOT","Favoritos"};
        for (int i=0;i<keys.length;i++) {
            text.append(control.sectionEnabled(keys[i]) ? "✓ " : "— ").append(labels[i]);
            if (i < keys.length-1) text.append('\n');
        }
        new AlertDialog.Builder(this).setTitle("Menu do aplicativo").setMessage(text.toString()).setPositiveButton("OK", null).show();
    }

    private void showPlayback() {
        String msg = "Progresso: " + (control.resumeEnabled() ? "ativado" : "desativado")
                + "\nPerguntar Continuar / Do início: " + (control.resumePrompt() ? "sim" : "não")
                + "\nCatálogo: atualizar a cada " + control.catalogRefreshMinutes() + " min";
        new AlertDialog.Builder(this).setTitle("Reprodução").setMessage(msg).setPositiveButton("OK", null).show();
    }

    private void showLanguage() {
        String msg = "Áudio preferido: " + control.preferredAudio().toUpperCase(java.util.Locale.ROOT)
                + "\nLegenda padrão: " + subtitleLabel(control.subtitleSize())
                + "\n\nDurante um filme ou episódio, as opções só aparecem quando a própria mídia possui faixas adicionais.";
        new AlertDialog.Builder(this).setTitle("Áudio e legendas").setMessage(msg).setPositiveButton("OK", null).show();
    }

    private void configureParentalPin() {
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        input.setHint("4 dígitos");
        input.setMaxLines(1);
        new AlertDialog.Builder(this)
                .setTitle("PIN do conteúdo HOT")
                .setMessage("Defina um PIN local de 4 dígitos neste aparelho.")
                .setView(input)
                .setPositiveButton("SALVAR", (d,w) -> {
                    String pin = input.getText().toString().trim();
                    if (pin.matches("\\d{4}")) {
                        getSharedPreferences("green_play_parental", MODE_PRIVATE).edit().putString("pin", pin).apply();
                        render();
                        Toast.makeText(this, "PIN salvo", Toast.LENGTH_SHORT).show();
                    } else Toast.makeText(this, "Use exatamente 4 dígitos", Toast.LENGTH_SHORT).show();
                })
                .setNeutralButton("REMOVER PIN", (d,w) -> {
                    getSharedPreferences("green_play_parental", MODE_PRIVATE).edit().remove("pin").apply();
                    render();
                })
                .setNegativeButton("CANCELAR", null).show();
    }

    private void clearCache() {
        new AlertDialog.Builder(this).setTitle("Limpar cache")
                .setMessage("Isso remove somente arquivos temporários e capas armazenadas. Sua conta permanece conectada.")
                .setPositiveButton("LIMPAR", (d,w) -> {
                    deleteChildren(getCacheDir());
                    Toast.makeText(this, "Cache limpo", Toast.LENGTH_SHORT).show();
                }).setNegativeButton("CANCELAR", null).show();
    }

    private void openUpdate() {
        String url = control.apkUrl();
        if (url.isEmpty()) {
            Toast.makeText(this, "Nenhuma atualização publicada no painel", Toast.LENGTH_SHORT).show();
            return;
        }
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Exception e) { Toast.makeText(this, "Não foi possível abrir a atualização", Toast.LENGTH_SHORT).show(); }
    }

    private void openSupport() {
        String whatsapp = control.supportWhatsapp().replaceAll("[^0-9]", "");
        String url = !whatsapp.isEmpty() ? "https://wa.me/" + whatsapp : control.supportWebsite();
        if (url == null || url.trim().isEmpty()) {
            Toast.makeText(this, "Suporte ainda não configurado no painel", Toast.LENGTH_SHORT).show();
            return;
        }
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Exception e) { Toast.makeText(this, "Não foi possível abrir o suporte", Toast.LENGTH_SHORT).show(); }
    }


    private void switchAccount() {
        session.clear();
        Intent i = new Intent(this, LoginActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }

    private static String formatExpiry(String raw) {
        if (raw == null || raw.trim().isEmpty()) return "Renova em --";
        String v = raw.trim();
        try {
            java.text.SimpleDateFormat in = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US);
            java.util.Date d = in.parse(v);
            if (d != null) return "Renova em " + new java.text.SimpleDateFormat("dd MMM, yyyy", new java.util.Locale("pt", "BR")).format(d);
        } catch (Exception ignored) {}
        return "Renova em " + v;
    }

    private void showFavorites() {
        new AlertDialog.Builder(this)
                .setTitle("Favoritos")
                .setMessage("Seus favoritos ficam dentro de TV, Filmes e Séries. Marque conteúdos com estrela para acesso rápido.")
                .setPositiveButton("OK", null)
                .show();
    }

    private void showNotifications() {
        new AlertDialog.Builder(this)
                .setTitle("Notificações")
                .setMessage("Os avisos do aplicativo e novidades do painel aparecerão aqui nas próximas atualizações.")
                .setPositiveButton("OK", null)
                .show();
    }

    private static long daysRemaining(String raw) {
        if (raw == null || raw.trim().isEmpty()) return 0L;
        try {
            java.text.SimpleDateFormat in = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US);
            java.util.Date d = in.parse(raw.trim());
            if (d == null) return 0L;
            long diff = d.getTime() - System.currentTimeMillis();
            double days = diff / 86400000d;
            return (long) Math.ceil(days);
        } catch (Exception ignored) {
            return 0L;
        }
    }

    private void confirmLogout() {
        new AlertDialog.Builder(this).setTitle("Sair da conta?")
                .setMessage("O GREEN PLAY vai voltar para a tela de login.")
                .setPositiveButton("SAIR", (d,w) -> {
                    session.clear();
                    Intent i = new Intent(this, LoginActivity.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(i);
                    finish();
                }).setNegativeButton("CANCELAR", null).show();
    }

    private static void deleteChildren(File root) {
        if (root == null || !root.exists()) return;
        File[] children = root.listFiles();
        if (children == null) return;
        for (File f : children) {
            if (f.isDirectory()) deleteChildren(f);
            try { f.delete(); } catch (Exception ignored) {}
        }
    }

    private static String subtitleLabel(String raw) {
        if ("small".equalsIgnoreCase(raw)) return "pequena";
        if ("large".equalsIgnoreCase(raw)) return "grande";
        return "normal";
    }

    private static String join(List<String> rows, String separator) {
        if (rows == null || rows.isEmpty()) return "Nenhuma seção ativa";
        StringBuilder out = new StringBuilder();
        for (int i=0;i<rows.size();i++) { if (i>0) out.append(separator); out.append(rows.get(i)); }
        return out.toString();
    }
}
