package com.greenplay.v5.core.config;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

/** Applies the branding cached from /api/app_config.php without changing playback logic. */
public final class BrandingUi {
    private BrandingUi() {}

    public static int color(String raw, int fallback) {
        try { return raw == null || raw.trim().isEmpty() ? fallback : Color.parseColor(raw.trim()); }
        catch (Exception e) { return fallback; }
    }

    public static void applyName(TextView view, BrandingStore store) {
        if (view == null || store == null) return;
        String name = store.appName();
        view.setText("▶  " + (name.isEmpty() ? "GREEN PLAY" : name.toUpperCase()));
    }

    public static void applyLogo(ImageView view, BrandingStore store) {
        if (view == null || store == null) return;
        String logo = store.absolute(store.logo());
        if (logo.isEmpty()) { view.setVisibility(View.GONE); return; }
        view.setVisibility(View.VISIBLE);
        Picasso.get().load(logo).fit().centerInside().noFade().into(view, new com.squareup.picasso.Callback() {
            @Override public void onSuccess() { view.setVisibility(View.VISIBLE); }
            @Override public void onError(Exception e) { view.setVisibility(View.GONE); }
        });
    }

    public static void applyBanner(ImageView view, BrandingStore store) {
        if (view == null || store == null) return;
        String banner = store.absolute(store.banner());
        if (banner.isEmpty()) { view.setVisibility(View.GONE); return; }
        view.setVisibility(View.VISIBLE);
        Picasso.get().load(banner).fit().centerCrop().noFade().into(view, new com.squareup.picasso.Callback() {
            @Override public void onSuccess() { view.setVisibility(View.VISIBLE); }
            @Override public void onError(Exception e) { view.setVisibility(View.GONE); }
        });
    }

    public static void applyProfilePhoto(ImageView photo, TextView fallback, BrandingStore store) {
        if (photo == null || fallback == null || store == null) return;
        String url = store.absolute(store.profilePhoto());
        if (url.isEmpty()) { photo.setVisibility(View.GONE); fallback.setVisibility(View.VISIBLE); return; }
        photo.setVisibility(View.VISIBLE);
        fallback.setVisibility(View.GONE);
        Picasso.get().load(url).fit().centerCrop().noFade().into(photo, new com.squareup.picasso.Callback() {
            @Override public void onSuccess() { photo.setVisibility(View.VISIBLE); fallback.setVisibility(View.GONE); }
            @Override public void onError(Exception e) { photo.setVisibility(View.GONE); fallback.setVisibility(View.VISIBLE); }
        });
    }

    /** Caller must retain returned Target until the Activity is destroyed. */
    public static Target applyBackground(View view, BrandingStore store) {
        if (view == null || store == null) return null;
        String url = store.absolute(store.background());
        if (url.isEmpty()) return null;
        Target target = new Target() {
            @Override public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
                view.setBackground(new BitmapDrawable(view.getResources(), bitmap));
            }
            @Override public void onBitmapFailed(Exception e, Drawable errorDrawable) { }
            @Override public void onPrepareLoad(Drawable placeHolderDrawable) { }
        };
        Picasso.get().load(url).into(target);
        return target;
    }
}
