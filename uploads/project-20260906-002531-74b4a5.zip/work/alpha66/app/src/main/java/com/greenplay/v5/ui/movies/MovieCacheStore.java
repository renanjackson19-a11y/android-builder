package com.greenplay.v5.ui.movies;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.greenplay.v5.data.model.movie.Movie;
import com.greenplay.v5.data.model.movie.MovieCategory;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/** Small last-known catalog cache: instant opening, then network refresh in background. */
public final class MovieCacheStore {
    private static final String PREF = "green_play_v5_movie_cache_v2";
    private final SharedPreferences prefs;
    private final Gson gson = new Gson();
    private final String scope;
    private static final Type MOVIES = new TypeToken<List<Movie>>(){}.getType();
    private static final Type CATEGORIES = new TypeToken<List<MovieCategory>>(){}.getType();

    public MovieCacheStore(Context context, String host, String user) {
        prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        scope = Integer.toHexString(((host == null ? "" : host) + "|" + (user == null ? "" : user)).hashCode());
    }

    public List<Movie> movies() {
        try {
            List<Movie> rows = gson.fromJson(prefs.getString(scope + "_movies", "[]"), MOVIES);
            return rows == null ? new ArrayList<>() : rows;
        } catch (Exception e) { return new ArrayList<>(); }
    }

    public List<MovieCategory> categories() {
        try {
            List<MovieCategory> rows = gson.fromJson(prefs.getString(scope + "_categories", "[]"), CATEGORIES);
            return rows == null ? new ArrayList<>() : rows;
        } catch (Exception e) { return new ArrayList<>(); }
    }

    public void saveMovies(List<Movie> rows) {
        prefs.edit().putString(scope + "_movies", gson.toJson(rows == null ? java.util.Collections.emptyList() : rows)).apply();
    }

    public void saveCategories(List<MovieCategory> rows) {
        prefs.edit().putString(scope + "_categories", gson.toJson(rows == null ? java.util.Collections.emptyList() : rows)).apply();
    }

    /** V5.0.128 — limpa somente o cache VOD desta conta/servidor, sem tocar no login. */
    public void clear() {
        prefs.edit()
                .remove(scope + "_movies")
                .remove(scope + "_categories")
                .apply();
    }
}
