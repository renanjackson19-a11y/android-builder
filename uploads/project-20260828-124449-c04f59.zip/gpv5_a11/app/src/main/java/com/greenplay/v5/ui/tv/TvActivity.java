package com.greenplay.v5.ui.tv;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import com.greenplay.v5.core.player.GreenPlayerFactory;
import com.greenplay.v5.core.player.StreamInspector;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.greenplay.v5.core.network.StreamUrlFactory;
import com.greenplay.v5.core.session.SessionStore;
import com.greenplay.v5.data.model.tv.TvCategory;
import com.greenplay.v5.data.model.tv.TvChannel;
import com.greenplay.v5.data.model.tv.TvEpg;
import com.greenplay.v5.data.repository.TvRepository;
import com.greenplay.v5.databinding.ActivityTvBinding;
import com.greenplay.v5.ui.player.PlayerActivity;
import java.util.ArrayList;
import java.util.List;
import com.squareup.picasso.Picasso;

public final class TvActivity extends AppCompatActivity {
    private enum Mode { ALL, FAVORITES, RECENTS }

    private ActivityTvBinding b;
    private SessionStore session;
    private TvRepository repo;
    private TvCategoryAdapter categories;
    private TvChannelAdapter channels;
    private TvHistoryStore history;
    private ExoPlayer previewPlayer;
    private TvChannel current;
    private Mode mode = Mode.ALL;
    private String currentCategoryId = "";
    private String currentCategoryName = "TODOS";
    private final List<TvChannel> allChannels = new ArrayList<>();
    private final Handler previewHandler = new Handler(Looper.getMainLooper());
    private Runnable pendingPreview;
    private int playbackAttempt = 0;
    private int previewGeneration = 0;
    private long returnFocusChannelId = -1L;
    private boolean returningFromFullscreen = false;
    private boolean fullscreen = false;
    private ViewGroup previewOriginalParent;
    private ViewGroup.LayoutParams previewOriginalLayoutParams;
    private int previewOriginalIndex = -1;

    @Override protected void onCreate(Bundle state){
        super.onCreate(state);
        b=ActivityTvBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        session=new SessionStore(this);
        if(!session.isLogged()||session.host().trim().isEmpty()){finish();return;}
        repo=new TvRepository(session.host(),session.user(),session.pass());
        history=new TvHistoryStore(this);
        setupLists(); setupSearch(); setupPlayer(); bindTopNav(); bindModes(); selectMode(Mode.ALL); loadChannels("","TODOS");
    }

    private void setupLists(){
        channels=new TvChannelAdapter(new TvChannelAdapter.Listener(){
            @Override public void onFocus(TvChannel channel){
                // Apenas move o foco. Trocar de item com o D-pad NÃO abre nem troca o canal.
                if(current!=null && current.id==channel.id) b.previewStatus.setText("OK: tela cheia");
                else b.previewStatus.setText("OK: selecionar canal");
            }
            @Override public void onOpen(TvChannel channel){
                // Comportamento de TV: 1º OK seleciona/toca no preview; 2º OK abre tela cheia.
                if(current==null || current.id!=channel.id){
                    history.markRecent(channel.id);
                    returnFocusChannelId=channel.id;
                    showChannel(channel,true);
                    return;
                }
                history.markRecent(channel.id);
                returnFocusChannelId=channel.id;
                openFull(channel);
            }
            @Override public void onFavorite(TvChannel channel){history.toggleFavorite(channel.id);channels.refreshFavorite(channel.id);if(mode==Mode.FAVORITES)applyMode();}
            @Override public boolean isFavorite(TvChannel channel){return history.isFavorite(channel.id);}
        });
        b.channelList.setLayoutManager(new LinearLayoutManager(this));
        b.channelList.setAdapter(channels);
    }

    private void setupSearch(){
        b.search.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){channels.filter(s.toString());updateTotal();}
            public void afterTextChanged(Editable e){}
        });
    }

    private void setupPlayer(){
        previewPlayer=GreenPlayerFactory.create(this);
        b.previewPlayer.setPlayer(previewPlayer);
        b.previewPlayer.setUseController(false);
        b.previewPlayer.setFocusable(true);
        b.previewPlayer.setClickable(true);
        b.previewPlayer.setOnClickListener(v -> {
            if(fullscreen){ exitFullscreen(); return; }
            if(current!=null){
                history.markRecent(current.id);
                returnFocusChannelId=current.id;
                openFull(current);
            }
        });
        b.previewPlayer.setOnKeyListener((v,keyCode,event) -> {
            if(event.getAction()==KeyEvent.ACTION_UP && (keyCode==KeyEvent.KEYCODE_DPAD_CENTER || keyCode==KeyEvent.KEYCODE_ENTER)){
                if(fullscreen){ exitFullscreen(); return true; }
                if(current!=null){
                    history.markRecent(current.id);
                    returnFocusChannelId=current.id;
                    openFull(current);
                    return true;
                }
            }
            return false;
        });
        previewPlayer.addListener(new Player.Listener(){
            @Override public void onPlaybackStateChanged(int playbackState){
                if(playbackState==Player.STATE_BUFFERING)b.previewStatus.setText("Carregando canal...");
                else if(playbackState==Player.STATE_READY)b.previewStatus.setText("Canal selecionado • OK novamente: tela cheia");
            }
            @Override public void onPlayerError(@NonNull PlaybackException error){
                if(current!=null && playbackAttempt < 1){
                    playbackAttempt++;
                    String primaryExt = current.extension == null ? "" : current.extension.trim();
                    String alt = "m3u8".equalsIgnoreCase(primaryExt)
                            ? StreamUrlFactory.liveTs(session.host(),session.user(),session.pass(),current.id)
                            : StreamUrlFactory.liveHls(session.host(),session.user(),session.pass(),current.id);
                    b.previewStatus.setText("Alternando formato...");
                    playResolvedUrl(alt, alt.toLowerCase(java.util.Locale.US).contains(".m3u8") ? "hls" : "ts");
                }else{
                    b.previewStatus.setText("ERRO "+error.getErrorCodeName()+" • "+shortMessage(error));
                }
            }
        });
    }

    private void bindTopNav(){
        b.navTv.setOnClickListener(v->b.search.requestFocus());
        b.navFootball.setOnClickListener(v->Toast.makeText(this,"Futebol será aberto no módulo próprio",Toast.LENGTH_SHORT).show());
        b.navMovies.setOnClickListener(v->Toast.makeText(this,"Filmes entra depois da TV",Toast.LENGTH_SHORT).show());
        b.navSeries.setOnClickListener(v->Toast.makeText(this,"Séries entra depois de Filmes",Toast.LENGTH_SHORT).show());
        b.navKids.setOnClickListener(v->Toast.makeText(this,"Kids será isolado",Toast.LENGTH_SHORT).show());
        b.navAnime.setOnClickListener(v->Toast.makeText(this,"Anime será isolado",Toast.LENGTH_SHORT).show());
        b.navHot.setOnClickListener(v->Toast.makeText(this,"HOT será protegido por PIN",Toast.LENGTH_SHORT).show());
    }

    private void bindModes(){
        b.filterAll.setOnClickListener(v->{selectMode(Mode.ALL); applyMode();});
        b.filterFavorites.setOnClickListener(v->{selectMode(Mode.FAVORITES); ensureAllThenApply();});
        b.filterRecents.setOnClickListener(v->{selectMode(Mode.RECENTS); ensureAllThenApply();});
    }

    private void selectMode(Mode m){
        mode=m;
        b.filterAll.setSelected(m==Mode.ALL);
        b.filterFavorites.setSelected(m==Mode.FAVORITES);
        b.filterRecents.setSelected(m==Mode.RECENTS);
    }

    private void loadChannels(String categoryId,String categoryName){
        currentCategoryId=categoryId==null?"":categoryId;
        currentCategoryName=categoryName==null?"TODOS":categoryName;
        b.loading.setVisibility(View.VISIBLE);b.error.setText("");
        repo.channels(currentCategoryId,new TvRepository.ChannelsResult(){
            @Override public void success(List<TvChannel> rows){runOnUiThread(()->{
                b.loading.setVisibility(View.GONE);
                if(currentCategoryId.isEmpty()){allChannels.clear();allChannels.addAll(rows);}
                channels.setSectionLabel(currentCategoryName.equals("TODOS")?"TV AO VIVO":"CH: "+currentCategoryName);
                channels.setRows(rows);
                updateTotal();
                TvChannel f=channels.first();if(f!=null)showChannel(f,true);else stopPreview();
            });}
            @Override public void error(String message){runOnUiThread(()->{b.loading.setVisibility(View.GONE);b.error.setText(message);channels.setRows(null);updateTotal();stopPreview();});}
        });
    }

    private void ensureAllThenApply(){
        if(!allChannels.isEmpty()){applyMode();return;}
        b.loading.setVisibility(View.VISIBLE);
        repo.channels("",new TvRepository.ChannelsResult(){
            @Override public void success(List<TvChannel> rows){runOnUiThread(()->{b.loading.setVisibility(View.GONE);allChannels.clear();allChannels.addAll(rows);applyMode();});}
            @Override public void error(String message){runOnUiThread(()->{b.loading.setVisibility(View.GONE);b.error.setText(message);});}
        });
    }

    private void applyMode(){
        b.error.setText("");
        if(mode==Mode.FAVORITES){
            channels.setSectionLabel("FAVORITOS");
            channels.setRows(history.filterFavorites(allChannels));
        }else if(mode==Mode.RECENTS){
            channels.setSectionLabel("RECENTES");
            channels.setRows(history.filterRecents(allChannels));
        }else{
            if(currentCategoryId.isEmpty() && !allChannels.isEmpty()){
                channels.setSectionLabel("TV AO VIVO");channels.setRows(allChannels);
            }
        }
        updateTotal();
        TvChannel f=channels.first();if(f!=null)showChannel(f,true);else stopPreview();
    }

    private void updateTotal(){ b.total.setText(channels.getItemCount()+" canais"); }

    private void showChannel(TvChannel c,boolean autoplay){
        current=c;
        b.previewName.setText(c.name);
        int p = channels.positionOf(c.id);
        b.previewChannelNumber.setText(p >= 0 ? String.valueOf(p + 1) : "");
        b.previewLogo.setImageDrawable(null);
        if(c.logo!=null && !c.logo.trim().isEmpty()) Picasso.get().load(c.logo).fit().centerInside().noFade().into(b.previewLogo);
        b.epgNow.setText("Carregando...");
        b.epgNext.setText("Carregando...");
        b.epgProgress.setProgress(0);
        repo.epg(c.id,new TvRepository.EpgResult(){
            @Override public void success(TvEpg epg){runOnUiThread(()->{
                if(current!=c)return;
                b.epgNow.setText((epg.nowTime.isEmpty()?"":epg.nowTime+"  •  ")+epg.nowTitle);
                b.epgNext.setText((epg.nextTime.isEmpty()?"":epg.nextTime+"  •  ")+epg.nextTitle);
                b.epgProgress.setProgress(epgProgress(epg));
            });}
            @Override public void error(String m){}
        });
        if(autoplay){
            if(pendingPreview!=null)previewHandler.removeCallbacks(pendingPreview);
            playPreview(c);
        }
    }

    private int epgProgress(TvEpg epg){
        if(epg.nowStart<=0||epg.nowStop<=epg.nowStart)return 0;
        long now=System.currentTimeMillis()/1000L;
        long done=Math.max(0,Math.min(epg.nowStop-epg.nowStart,now-epg.nowStart));
        return (int)((done*100L)/(epg.nowStop-epg.nowStart));
    }

    private void playPreview(TvChannel c){
        playbackAttempt=0;
        previewGeneration++;
        String ext=c.extension==null?"":c.extension.trim();
        boolean hls="m3u8".equalsIgnoreCase(ext);
        String first=hls
                ? StreamUrlFactory.liveHls(session.host(),session.user(),session.pass(),c.id)
                : StreamUrlFactory.liveTs(session.host(),session.user(),session.pass(),c.id);
        b.previewStatus.setText("Carregando canal...");
        playResolvedUrl(first, hls ? "hls" : "ts");
    }

    private void inspectAndPlay(TvChannel c, String url, int generation){
        StreamInspector.inspect(url,new StreamInspector.Callback(){
            @Override public void success(StreamInspector.Result r){runOnUiThread(()->{
                if(current!=c || generation!=previewGeneration)return;
                b.previewStatus.setText("HTTP "+r.httpCode+" • "+(r.detected==null?"AUTO":r.detected.toUpperCase(java.util.Locale.US))+
                        (r.contentType.isEmpty()?"":" • "+trimType(r.contentType)));
                if(r.httpCode<200 || r.httpCode>=300){
                    if(playbackAttempt<1){playbackAttempt++;inspectAndPlay(c,StreamUrlFactory.liveHls(session.host(),session.user(),session.pass(),c.id),generation);}
                    else b.previewStatus.setText("STREAM HTTP "+r.httpCode);
                    return;
                }
                playResolvedUrl(r.finalUrl,r.detected);
            });}
            @Override public void error(String message){runOnUiThread(()->{
                if(current!=c || generation!=previewGeneration)return;
                b.previewStatus.setText("FALHA STREAM • "+shortText(message));
                if(playbackAttempt<1){playbackAttempt++;inspectAndPlay(c,StreamUrlFactory.liveHls(session.host(),session.user(),session.pass(),c.id),generation);}
            });}
        });
    }

    private void playResolvedUrl(String url,String detected){
        try{
            MediaItem.Builder item=new MediaItem.Builder().setUri(url);
            if("hls".equalsIgnoreCase(detected)) item.setMimeType(MimeTypes.APPLICATION_M3U8);
            else if("ts".equalsIgnoreCase(detected)) item.setMimeType(MimeTypes.VIDEO_MP2T);
            previewPlayer.stop();
            previewPlayer.clearMediaItems();
            previewPlayer.setMediaItem(item.build());
            previewPlayer.setPlayWhenReady(true);
            previewPlayer.prepare();
        }catch(Exception e){b.previewStatus.setText("ERRO AO ABRIR • "+shortMessage(e));}
    }

    private static String trimType(String t){
        String x=t==null?"":t;int p=x.indexOf(';');if(p>0)x=x.substring(0,p);return x.length()>28?x.substring(0,28):x;
    }
    private static String shortText(String m){if(m==null||m.trim().isEmpty())return "sem detalhe";m=m.replace('\n',' ').replace('\r',' ').trim();return m.length()>70?m.substring(0,70):m;}

    private static String shortMessage(Throwable e){
        String m=e==null?"sem detalhe":e.getMessage();
        if(m==null||m.trim().isEmpty())m=e==null?"sem detalhe":e.getClass().getSimpleName();
        m=m.replace('\n',' ').replace('\r',' ').trim();
        return m.length()>70?m.substring(0,70):m;
    }

    private void stopPreview(){
        if(previewPlayer!=null){previewPlayer.stop();previewPlayer.clearMediaItems();}
        b.previewName.setText("Selecione um canal");b.previewChannelNumber.setText("");b.previewLogo.setImageDrawable(null);b.epgNow.setText("Sem informação");b.epgNext.setText("Sem informação");b.epgProgress.setProgress(0);b.previewStatus.setText("OK: selecionar canal");
    }

    private void openFull(TvChannel c){
        if(fullscreen || c==null)return;
        ViewGroup parent=(ViewGroup)b.previewPlayer.getParent();
        if(parent==null)return;
        fullscreen=true;
        previewOriginalParent=parent;
        previewOriginalIndex=parent.indexOfChild(b.previewPlayer);
        previewOriginalLayoutParams=b.previewPlayer.getLayoutParams();
        parent.removeView(b.previewPlayer);

        ViewGroup root=findViewById(android.R.id.content);
        root.addView(b.previewPlayer,new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));
        b.previewPlayer.bringToFront();
        b.previewPlayer.requestFocus();
        if(previewPlayer!=null)previewPlayer.play();
    }

    private void exitFullscreen(){
        if(!fullscreen)return;
        fullscreen=false;
        ViewGroup currentParent=(ViewGroup)b.previewPlayer.getParent();
        if(currentParent!=null)currentParent.removeView(b.previewPlayer);
        if(previewOriginalParent!=null){
            int index=Math.max(0,Math.min(previewOriginalIndex,previewOriginalParent.getChildCount()));
            previewOriginalParent.addView(b.previewPlayer,index,previewOriginalLayoutParams);
        }
        if(previewPlayer!=null)previewPlayer.play();
        b.channelList.postDelayed(this::restoreChannelFocus,80);
    }

    @Override public boolean onKeyDown(int keyCode,KeyEvent event){
        if(keyCode==KeyEvent.KEYCODE_BACK && fullscreen){exitFullscreen();return true;}
        if(keyCode==KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE&&current!=null){playPreview(current);return true;}
        return super.onKeyDown(keyCode,event);
    }
    @Override protected void onStop(){super.onStop();if(previewPlayer!=null)previewPlayer.pause();}
    @Override protected void onStart(){
        super.onStart();
        if(previewPlayer!=null&&current!=null&&previewPlayer.getMediaItemCount()>0)previewPlayer.play();
    }
    @Override protected void onResume(){
        super.onResume();
        if(returningFromFullscreen){
            returningFromFullscreen=false;
            b.channelList.postDelayed(this::restoreChannelFocus,160);
        }
    }
    private void restoreChannelFocus(){
        long id=returnFocusChannelId>0?returnFocusChannelId:(current==null?-1L:current.id);
        int pos=channels.positionOf(id);
        if(pos<0)return;
        b.channelList.scrollToPosition(pos);
        b.channelList.postDelayed(()->{
            androidx.recyclerview.widget.RecyclerView.ViewHolder vh=b.channelList.findViewHolderForAdapterPosition(pos);
            if(vh!=null)vh.itemView.requestFocus();
        },80);
    }
    @Override protected void onDestroy(){if(pendingPreview!=null)previewHandler.removeCallbacks(pendingPreview);if(previewPlayer!=null)previewPlayer.release();super.onDestroy();}
}
