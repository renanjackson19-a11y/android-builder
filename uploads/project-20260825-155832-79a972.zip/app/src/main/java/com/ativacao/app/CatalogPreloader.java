package com.ativacao.app;

import android.app.Activity;
import android.content.Context;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Pré-carga funcional sem alterar nenhuma tela/layout do aplicativo.
 * No login prepara índices + primeiras capas de todas as áreas antes de entrar.
 * Depois continua, silenciosamente, com mais capas e metadados TMDB.
 */
final class CatalogPreloader {
    private static final String PREF="dubai_content_preload";
    private static final int CACHE_SCHEMA=6;
    private static volatile boolean running=false;
    private static volatile boolean ready=false;

    interface Progress { void onProgress(String text,int done,int total); }

    static void init(Context c){ if(c!=null) ready=isPrepared(c); }
    static boolean isReady(){ return ready; }
    static boolean isPrepared(Context c){
        if(c==null)return ready;
        return c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getBoolean(key(Session.token(c)),false);
    }
    private static String key(String token){return "ready_v"+CACHE_SCHEMA+"_"+Integer.toHexString((token==null?"":token).hashCode());}
    private static void markReady(Context c,boolean v){
        if(c!=null)c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putBoolean(key(Session.token(c)),v).apply();
        ready=v;
    }

    static void start(Activity a,boolean force,Runnable done){start(a,force,null,done);}
    static void start(Activity a,boolean force,Progress progress,Runnable done){
        if(a==null){if(done!=null)done.run();return;}
        if(!force && isPrepared(a)){ready=true;if(done!=null)done.run();return;}
        if(running)return;
        running=true;
        // Login explícito sempre atualiza a primeira página de cada área.
        // Não apaga todo o cache persistente: mantém capas antigas até as novas chegarem,
        // evitando telas vazias/piscadas.
        markReady(a,false);

        final boolean phone=Ui.phone(a);
        final int liveLimit=72, movieLimit=phone?36:48, seriesLimit=30;
        // TV, filmes, séries, Kids(2), Anime(2), HOT(3), categorias(3), config/TMDB
        final int total=14;
        final AtomicInteger pending=new AtomicInteger(total);
        final AtomicInteger doneCount=new AtomicInteger(0);
        final AtomicInteger fatal=new AtomicInteger(0);

        notify(progress,"Carregando conteúdos, aguarde...",0,total);
        preload(a,"live",liveLimit,"","TV ao vivo",true,pending,doneCount,total,fatal,progress,done);
        preload(a,"movie",movieLimit,"","Filmes",true,pending,doneCount,total,fatal,progress,done);
        preload(a,"series",seriesLimit,"","Séries",true,pending,doneCount,total,fatal,progress,done);
        preload(a,"movie",movieLimit,"kids","Kids filmes",false,pending,doneCount,total,fatal,progress,done);
        preload(a,"series",seriesLimit,"kids","Kids séries",false,pending,doneCount,total,fatal,progress,done);
        preload(a,"movie",movieLimit,"anime","Anime filmes",false,pending,doneCount,total,fatal,progress,done);
        preload(a,"series",seriesLimit,"anime","Anime séries",false,pending,doneCount,total,fatal,progress,done);
        preload(a,"live",liveLimit,"adult","HOT canais",false,pending,doneCount,total,fatal,progress,done);
        preload(a,"movie",movieLimit,"adult","HOT filmes",false,pending,doneCount,total,fatal,progress,done);
        preload(a,"series",seriesLimit,"adult","HOT séries",false,pending,doneCount,total,fatal,progress,done);

        ApiClient.categories("movie",new ApiClient.Callback<List<String>>(){public void ok(List<String>x){finish(a,"Categorias de filmes",true,pending,doneCount,total,fatal,progress,done);}public void error(String m){finish(a,"Categorias de filmes",true,pending,doneCount,total,fatal,progress,done);}});
        ApiClient.categories("series",new ApiClient.Callback<List<String>>(){public void ok(List<String>x){finish(a,"Categorias de séries",true,pending,doneCount,total,fatal,progress,done);}public void error(String m){finish(a,"Categorias de séries",true,pending,doneCount,total,fatal,progress,done);}});
        ApiClient.hotCategories(new ApiClient.Callback<List<ApiClient.HotCategory>>(){public void ok(List<ApiClient.HotCategory>x){finish(a,"Categorias HOT",true,pending,doneCount,total,fatal,progress,done);}public void error(String m){finish(a,"Categorias HOT",true,pending,doneCount,total,fatal,progress,done);}});
        ApiClient.statusInfo(new ApiClient.Callback<ApiClient.AppStatus>(){public void ok(ApiClient.AppStatus st){finish(a,"Configuração TMDB",true,pending,doneCount,total,fatal,progress,done);}public void error(String m){finish(a,"Configuração TMDB",true,pending,doneCount,total,fatal,progress,done);}});
    }

    private static void preload(Activity a,String type,int limit,String smart,String label,boolean required,
                                AtomicInteger pending,AtomicInteger doneCount,int total,AtomicInteger fatal,
                                Progress progress,Runnable done){
        ApiClient.invalidateCatalog(type,1,limit,"","",smart);
        ApiClient.catalog(type,1,limit,"","",smart,new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){
                boolean valid=p!=null && p.items!=null && (!required || p.total>0 || !p.items.isEmpty());
                if(valid)warmVisibleCovers(a,p);
                if(required && !valid)fatal.incrementAndGet();
                finish(a,label,valid||!required,pending,doneCount,total,fatal,progress,done);
            }
            public void error(String m){ if(required)fatal.incrementAndGet(); finish(a,label,!required,pending,doneCount,total,fatal,progress,done); }
        });
    }

    private static void finish(Activity a,String label,boolean ok,AtomicInteger pending,AtomicInteger doneCount,int total,
                               AtomicInteger fatal,Progress progress,Runnable done){
        int d=doneCount.incrementAndGet();
        notify(progress,"Preparando "+label+"...",d,total);
        if(pending.decrementAndGet()!=0)return;
        running=false;
        boolean good=fatal.get()==0;
        markReady(a,good);
        notify(progress,good?"Capas e conteúdos principais prontos":"Conteúdo principal carregado com avisos",total,total);
        if(done!=null)done.run();
        backgroundWarm(a);
    }

    private static void backgroundWarm(Activity a){
        final boolean phone=Ui.phone(a);
        final int movieLimit=phone?36:48, seriesLimit=30;
        // Próximas páginas de capas vão chegando sem bloquear a entrada.
        String[][] jobs={{"movie",""},{"series",""},{"movie","kids"},{"series","kids"},{"movie","anime"},{"series","anime"},{"movie","adult"},{"series","adult"}};
        for(String[] j:jobs){
            int limit="series".equals(j[0])?seriesLimit:movieLimit;
            for(int page=2;page<=4;page++){
                final int pg=page;
                ApiClient.catalog(j[0],pg,limit,"","",j[1],new ApiClient.Callback<ApiClient.CatalogPage>(){
                    public void ok(ApiClient.CatalogPage p){warmVisibleCovers(a,p);warmTmdb(p);}
                    public void error(String m){}
                });
            }
        }
    }

    private static void warmVisibleCovers(Activity a,ApiClient.CatalogPage p){
        if(p==null||p.items==null)return;
        int max=Math.min(p.items.size(),48);
        for(int n=0;n<max;n++){
            ApiClient.Item i=p.items.get(n); if(i==null)continue;
            ImageLoader.preload(a,clean(i.logo,i.backdrop));
        }
    }
    private static void warmTmdb(ApiClient.CatalogPage p){
        if(p==null||p.items==null)return;
        int max=Math.min(p.items.size(),12);
        for(int n=0;n<max;n++){
            ApiClient.Item i=p.items.get(n); if(i==null)continue;
            if(!("movie".equals(i.type)||"series".equals(i.type))||i.tmdbLoaded)continue;
            ApiClient.tmdbEnrich(i,new ApiClient.Callback<ApiClient.Item>(){public void ok(ApiClient.Item x){}public void error(String m){}});
        }
    }
    private static void notify(Progress p,String text,int done,int total){if(p!=null)p.onProgress(text,done,total);}
    private static String clean(String a,String b){String x=a==null?"":a.trim();return x.isEmpty()?(b==null?"":b.trim()):x;}
}
