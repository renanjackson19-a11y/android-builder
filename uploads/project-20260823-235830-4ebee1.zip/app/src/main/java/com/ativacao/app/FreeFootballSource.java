package com.ativacao.app;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class FreeFootballSource {
    private static final ExecutorService IO=Executors.newSingleThreadExecutor();
    private static final String[] ESPN_LEAGUES={"bra.1","eng.1","esp.1","ger.1","ita.1","fra.1","por.1","ned.1","uefa.champions","uefa.europa","uefa.europa.conf"};

    static void load(ApiClient.Callback<List<ApiClient.FootballMatch>> cb){
        IO.execute(()->{
            try{
                ArrayList<ApiClient.FootballMatch> out=new ArrayList<>();
                String dayApi=new SimpleDateFormat("yyyyMMdd",Locale.US).format(new Date());
                String today=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());

                // 1) Primary source: today's live scoreboard. Includes team badges when available.
                for(String league:ESPN_LEAGUES){
                    try{parseEspn(get("https://site.api.espn.com/apis/site/v2/sports/soccer/"+league+"/scoreboard?dates="+dayApi),out,today);}catch(Exception ignored){}
                }

                // 2) Fixture fallback: TODAY ONLY. Never show tomorrow/yesterday as "Jogos de hoje".
                if(out.isEmpty()){
                    Map<String,String> logos=loadEspnTeamLogos();
                    String[] seasons={"2026-27","2025-26"};
                    String[] files={"en.1.json","es.1.json","de.1.json","it.1.json","fr.1.json","pt.1.json","br.1.json"};
                    for(String season:seasons){
                        for(String file:files){
                            try{parseOpenFootball(get("https://raw.githubusercontent.com/openfootball/football.json/master/"+season+"/"+file),out,today,logos);}catch(Exception ignored){}
                        }
                        if(!out.isEmpty()) break;
                    }
                }

                // 3) Enrich any missing badges even when the match feed worked but had incomplete images.
                boolean missing=false;
                for(ApiClient.FootballMatch m:out){if(empty(m.homeLogo)||empty(m.awayLogo)){missing=true;break;}}
                if(missing){
                    try{applyLogos(out,loadEspnTeamLogos());}catch(Exception ignored){}
                }

                dedupe(out);
                Collections.sort(out,new Comparator<ApiClient.FootballMatch>(){
                    public int compare(ApiClient.FootballMatch a,ApiClient.FootballMatch b){
                        return safe(a.clock).compareTo(safe(b.clock));
                    }
                });
                cb.ok(out);
            }catch(Exception e){cb.error(e.getMessage()==null?"erro de rede":e.getMessage());}
        });
    }

    private static void parseEspn(String raw,List<ApiClient.FootballMatch> out,String today)throws Exception{
        JSONObject root=new JSONObject(raw);JSONArray events=root.optJSONArray("events");if(events==null)return;
        JSONObject lg=null;JSONArray leagues=root.optJSONArray("leagues");if(leagues!=null&&leagues.length()>0)lg=leagues.optJSONObject(0);
        String leagueName=lg==null?"Futebol":lg.optString("name","Futebol");
        for(int i=0;i<events.length();i++){
            JSONObject ev=events.optJSONObject(i);if(ev==null)continue;
            String rawDate=ev.optString("date","");
            if(!rawDate.isEmpty() && rawDate.length()>=10 && !today.equals(rawDate.substring(0,10))) continue;
            JSONArray comps=ev.optJSONArray("competitions");if(comps==null||comps.length()==0)continue;
            JSONObject comp=comps.optJSONObject(0);JSONArray teams=comp.optJSONArray("competitors");if(teams==null||teams.length()<2)continue;
            JSONObject home=null,away=null;for(int j=0;j<teams.length();j++){JSONObject t=teams.optJSONObject(j);if(t==null)continue;if("home".equals(t.optString("homeAway")))home=t;else if("away".equals(t.optString("homeAway")))away=t;}
            if(home==null||away==null)continue;
            ApiClient.FootballMatch m=new ApiClient.FootballMatch();
            m.league=leagueName;m.home=teamName(home);m.away=teamName(away);m.homeLogo=teamLogo(home);m.awayLogo=teamLogo(away);
            String hs=home.optString("score","");String as=away.optString("score","");if(!hs.isEmpty()&&!as.isEmpty())m.score=hs+" - "+as;
            JSONObject st=ev.optJSONObject("status");JSONObject typ=st==null?null:st.optJSONObject("type");
            m.status=typ==null?"Hoje":typ.optString("shortDetail",typ.optString("description","Hoje"));
            m.clock=eventTime(ev,st);m.date=today;out.add(m);
        }
    }

    private static String eventTime(JSONObject ev,JSONObject st){
        String detail=st==null?"":st.optString("displayClock","");
        JSONObject typ=st==null?null:st.optJSONObject("type");
        String state=typ==null?"":typ.optString("state","");
        if("in".equals(state)||"post".equals(state)) return detail;
        String iso=ev.optString("date","");
        try{
            java.text.SimpleDateFormat in=new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mmX",Locale.US);
            java.text.SimpleDateFormat out=new java.text.SimpleDateFormat("HH:mm",Locale.getDefault());
            Date d=in.parse(iso);if(d!=null)return out.format(d);
        }catch(Exception ignored){}
        return detail;
    }

    private static String teamName(JSONObject c){JSONObject t=c.optJSONObject("team");return t==null?"Time":t.optString("displayName",t.optString("name","Time"));}
    private static String teamLogo(JSONObject c){JSONObject t=c.optJSONObject("team");if(t==null)return "";String logo=t.optString("logo","");if(!logo.isEmpty())return logo;JSONArray logos=t.optJSONArray("logos");if(logos!=null&&logos.length()>0){JSONObject l=logos.optJSONObject(0);if(l!=null)return l.optString("href","");}return "";}

    private static void parseOpenFootball(String raw,List<ApiClient.FootballMatch> out,String today,Map<String,String> logos)throws Exception{
        JSONObject root=new JSONObject(raw);String league=root.optString("name","Futebol");JSONArray a=root.optJSONArray("matches");if(a==null)return;
        for(int i=0;i<a.length();i++){
            JSONObject o=a.optJSONObject(i);if(o==null)continue;String date=o.optString("date","");
            if(!today.equals(date))continue;
            ApiClient.FootballMatch m=new ApiClient.FootballMatch();m.league=league;m.date=date;m.home=team(o.opt("team1"));m.away=team(o.opt("team2"));m.clock=o.optString("time","");m.status="Hoje";
            m.homeLogo=findLogo(logos,m.home);m.awayLogo=findLogo(logos,m.away);out.add(m);
        }
    }

    private static Map<String,String> loadEspnTeamLogos(){
        Map<String,String> map=new HashMap<>();
        for(String league:ESPN_LEAGUES){
            try{
                JSONObject root=new JSONObject(get("https://site.api.espn.com/apis/site/v2/sports/soccer/"+league+"/teams?limit=200"));
                JSONObject sports=root.optJSONArray("sports")==null?null:root.optJSONArray("sports").optJSONObject(0);
                JSONObject lg=sports==null?null:(sports.optJSONArray("leagues")==null?null:sports.optJSONArray("leagues").optJSONObject(0));
                JSONArray teams=lg==null?null:lg.optJSONArray("teams");if(teams==null)continue;
                for(int i=0;i<teams.length();i++){
                    JSONObject wrap=teams.optJSONObject(i);JSONObject t=wrap==null?null:wrap.optJSONObject("team");if(t==null)continue;
                    String name=t.optString("displayName",t.optString("name",""));String logo=t.optString("logo","");
                    if(logo.isEmpty()){JSONArray la=t.optJSONArray("logos");if(la!=null&&la.length()>0){JSONObject l=la.optJSONObject(0);if(l!=null)logo=l.optString("href","");}}
                    if(!name.isEmpty()&&!logo.isEmpty()){
                        map.put(norm(name),logo);
                        String shortName=t.optString("shortDisplayName","");if(!shortName.isEmpty())map.put(norm(shortName),logo);
                        String abbr=t.optString("abbreviation","");if(!abbr.isEmpty())map.put(norm(abbr),logo);
                    }
                }
            }catch(Exception ignored){}
        }
        return map;
    }

    private static void applyLogos(List<ApiClient.FootballMatch> list,Map<String,String> logos){
        for(ApiClient.FootballMatch m:list){if(empty(m.homeLogo))m.homeLogo=findLogo(logos,m.home);if(empty(m.awayLogo))m.awayLogo=findLogo(logos,m.away);}
    }
    private static String findLogo(Map<String,String> logos,String name){
        String n=norm(name);String exact=logos.get(n);if(exact!=null)return exact;
        for(Map.Entry<String,String> e:logos.entrySet()){
            String k=e.getKey();if(k.length()>3&&(n.contains(k)||k.contains(n)))return e.getValue();
        }
        return "";
    }
    private static void dedupe(List<ApiClient.FootballMatch> list){
        java.util.HashSet<String> seen=new java.util.HashSet<>();
        for(int i=list.size()-1;i>=0;i--){ApiClient.FootballMatch m=list.get(i);String k=norm(m.home)+"|"+norm(m.away)+"|"+safe(m.date);if(seen.contains(k))list.remove(i);else seen.add(k);}
    }
    private static String norm(String s){return safe(s).toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]","");}
    private static String safe(String s){return s==null?"":s;}
    private static boolean empty(String s){return s==null||s.trim().isEmpty();}
    private static String team(Object x){if(x instanceof String)return (String)x;if(x instanceof JSONObject)return ((JSONObject)x).optString("name","Time");return "Time";}
    private static String get(String u)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(9000);c.setRequestProperty("User-Agent","DubaiPlayTV/4.0.14");BufferedReader b=new BufferedReader(new InputStreamReader(c.getInputStream()));StringBuilder s=new StringBuilder();String l;while((l=b.readLine())!=null)s.append(l);b.close();return s.toString();}
}
