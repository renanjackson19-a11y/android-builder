package com.ativacao.app;
import java.util.HashSet;
final class BrokenContent{
    private static final HashSet<Long> IDS=new HashSet<>();
    static synchronized void mark(long id){if(id>0)IDS.add(id);}
    static synchronized void clear(long id){IDS.remove(id);}
    static synchronized boolean has(long id){return id>0&&IDS.contains(id);}
}