package com.ativacao.app;
import java.util.HashMap;
import java.util.Map;
final class QuickCache{
    private static final Map<String,ApiClient.CatalogPage> DATA=new HashMap<>();
    static String key(String type,String smart){return (type==null?"":type)+"|"+(smart==null?"":smart);}
    static synchronized void put(String key,ApiClient.CatalogPage src){
        if(key==null||src==null)return;
        ApiClient.CatalogPage p=new ApiClient.CatalogPage();
        p.page=src.page;p.pages=src.pages;p.total=src.total;
        p.items.addAll(src.items);p.categories.addAll(src.categories);DATA.put(key,p);
    }
    static synchronized ApiClient.CatalogPage get(String key){
        ApiClient.CatalogPage src=DATA.get(key);if(src==null)return null;
        ApiClient.CatalogPage p=new ApiClient.CatalogPage();
        p.page=src.page;p.pages=src.pages;p.total=src.total;
        p.items.addAll(src.items);p.categories.addAll(src.categories);return p;
    }
}