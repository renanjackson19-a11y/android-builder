package com.ativacao.app;
final class AppPreloader{
    private static boolean started=false;
    static synchronized void start(){
        if(started)return;started=true;
        warm("live","");warm("movie","");warm("series","");
        warm("movie","kids");warm("series","kids");
        warm("movie","anime");warm("series","anime");
        FreeFootballSource.preload();
    }
    private static void warm(final String type,final String smart){
        ApiClient.catalog(type,1,60,"","",smart,new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage p){QuickCache.put(QuickCache.key(type,smart),p);}
            public void error(String m){}
        });
    }
}