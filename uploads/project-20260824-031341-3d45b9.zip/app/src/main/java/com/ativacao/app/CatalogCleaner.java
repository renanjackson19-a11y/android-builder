package com.ativacao.app;
import java.util.*;
final class CatalogCleaner{
    static List<ApiClient.Item> clean(String type,List<ApiClient.Item> src){
        ArrayList<ApiClient.Item> out=new ArrayList<>();if(src==null)return out;
        HashSet<String> seen=new HashSet<>();
        for(ApiClient.Item i:src){
            if(i==null||i.id<=0||BrokenContent.has(i.id))continue;
            if("series".equals(type)&&i.episodeNumber>0)continue;
            String base=("series".equals(type)&&good(i.seriesTitle))?i.seriesTitle:i.name;
            String key=norm(base);if(key.length()==0)key=String.valueOf(i.id);
            if(seen.add(key))out.add(i);
        }
        Collections.sort(out,new Comparator<ApiClient.Item>(){
            public int compare(ApiClient.Item a,ApiClient.Item b){
                int av=visual(a),bv=visual(b);if(av!=bv)return bv-av;
                if(a.year!=b.year)return b.year-a.year;
                return a.id<b.id?1:(a.id>b.id?-1:0);
            }});
        return out;
    }
    static void animeFirst(List<ApiClient.Item> list){
        if(list==null)return;
        Collections.sort(list,new Comparator<ApiClient.Item>(){
            public int compare(ApiClient.Item a,ApiClient.Item b){
                int av=visual(a),bv=visual(b);if(av!=bv)return bv-av;
                if(a.year!=b.year)return b.year-a.year;return 0;
            }});
    }
    static ApiClient.Item hero(List<ApiClient.Item> a,List<ApiClient.Item> b){
        ApiClient.Item best=null;int score=-1;
        if(a!=null)for(ApiClient.Item i:a){int s=heroScore(i);if(s>score){score=s;best=i;}}
        if(b!=null)for(ApiClient.Item i:b){int s=heroScore(i);if(s>score){score=s;best=i;}}
        return best;
    }
    private static int visual(ApiClient.Item i){if(i==null)return 0;int s=0;if(good(i.logo))s+=4;if(good(i.backdrop))s+=2;if(goodTitle(i.name))s+=2;return s;}
    private static int heroScore(ApiClient.Item i){if(i==null)return -1;int s=visual(i);if(good(i.backdrop))s+=5;if(good(i.synopsis))s+=2;return s;}
    private static boolean goodTitle(String s){if(!good(s))return false;String x=s.toLowerCase(Locale.ROOT);return !x.equals("anime")&&!x.contains("????");}
    private static boolean good(String s){return s!=null&&!s.trim().isEmpty()&&!s.equalsIgnoreCase("null");}
    private static String norm(String s){return s==null?"":s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]","");}
}