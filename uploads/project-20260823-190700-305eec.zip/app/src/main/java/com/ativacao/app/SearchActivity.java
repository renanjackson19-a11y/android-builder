package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.speech.RecognizerIntent;
import android.widget.Toast;
import java.util.Locale;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class SearchActivity extends Activity {
    private final List<ApiClient.Item> items = new ArrayList<>();
    private GridView grid; private ResultAdapter adapter; private EditText query; private TextView title, status;
    private final Handler handler = new Handler(); private Runnable searchTask; private boolean phone;

    @Override public void onCreate(Bundle b) { super.onCreate(b); Ui.immersive(this); phone = Ui.phone(this); setContentView(build()); loadPopular(); }

    private View build() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.HORIZONTAL); root.setBackground(Ui.diagonalGradient(Ui.BG_2, Ui.BG, 0, this)); root.setPadding(Ui.dp(this, phone?18:32), Ui.dp(this, 18), Ui.dp(this, phone?18:32), Ui.dp(this, 18));

        LinearLayout left = Ui.column(this); left.setPadding(Ui.dp(this, 18), Ui.dp(this, 12), Ui.dp(this, 18), Ui.dp(this, 12)); left.setBackground(Ui.round(0xFF0C0E0B, 8, this));
        TextView back = Ui.button(this, "‹ VOLTAR"); back.setOnClickListener(v -> finish()); left.addView(back, new LinearLayout.LayoutParams(Ui.dp(this, 110), Ui.dp(this, 40)));
        TextView h = Ui.text(this, "BUSCAR", phone?18:24, Ui.TEXT, false); LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, Ui.dp(this, 48)); hp.topMargin = Ui.dp(this, 6); left.addView(h, hp);
        query = new EditText(this); query.setSingleLine(true); query.setHint("Filmes, séries, canais..."); query.setHintTextColor(Ui.MUTED); query.setTextColor(Ui.TEXT); query.setTextSize(phone?12:14); query.setImeOptions(EditorInfo.IME_ACTION_SEARCH); query.setBackground(Ui.round(Color.argb(72,255,255,255), 3, this)); query.setPadding(Ui.dp(this, 14),0,Ui.dp(this,14),0); left.addView(query,new LinearLayout.LayoutParams(-1,Ui.dp(this,46)));

        TextView keypad = Ui.text(this, "TECLADO", 11, Ui.GREEN, true); LinearLayout.LayoutParams kp = new LinearLayout.LayoutParams(-1, Ui.dp(this, 34)); kp.topMargin = Ui.dp(this, 8); left.addView(keypad, kp);
        String letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        LinearLayout letterWrap = Ui.column(this);
        for (int r=0;r<4;r++) {
            LinearLayout line = new LinearLayout(this);
            for (int c=0;c<7;c++) {
                int idx=r*7+c; if(idx>=letters.length()) break;
                String s=String.valueOf(letters.charAt(idx)); TextView b=Ui.ghostButton(this,s); b.setOnClickListener(v->{query.setText(s);query.setSelection(query.length());doSearch(s);});
                LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,Ui.dp(this,36),1);p.rightMargin=Ui.dp(this,3);p.bottomMargin=Ui.dp(this,3);line.addView(b,p);
            }
            letterWrap.addView(line,new LinearLayout.LayoutParams(-1,Ui.dp(this,39)));
        }
        left.addView(letterWrap,new LinearLayout.LayoutParams(-1,-2));
        TextView clear=Ui.button(this,"LIMPAR");clear.setOnClickListener(v->{query.setText("");loadPopular();});LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,Ui.dp(this,40));cp.topMargin=Ui.dp(this,8);left.addView(clear,cp);
        TextView voice=Ui.primaryButton(this,"🎤 BUSCA POR VOZ");voice.setOnClickListener(v->voiceSearch());LinearLayout.LayoutParams vp=new LinearLayout.LayoutParams(-1,Ui.dp(this,40));vp.topMargin=Ui.dp(this,8);left.addView(voice,vp);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(Ui.dp(this,phone?300:360),-1);lp.rightMargin=Ui.dp(this,22);root.addView(left,lp);

        LinearLayout right=Ui.column(this); LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);
        title=Ui.text(this,"EM ALTA",phone?20:27,Ui.TEXT,false);head.addView(title,new LinearLayout.LayoutParams(0,Ui.dp(this,48),1));
        TextView refresh=Ui.button(this,"ATUALIZAR");refresh.setOnClickListener(v->loadPopular());head.addView(refresh,new LinearLayout.LayoutParams(Ui.dp(this,105),Ui.dp(this,38)));right.addView(head,new LinearLayout.LayoutParams(-1,Ui.dp(this,50)));
        status=Ui.text(this,"",10,Ui.MUTED,false);right.addView(status,new LinearLayout.LayoutParams(-1,Ui.dp(this,26)));
        grid=new GridView(this);grid.setNumColumns(phone?5:6);grid.setHorizontalSpacing(Ui.dp(this,10));grid.setVerticalSpacing(Ui.dp(this,12));grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);grid.setSelector(android.R.color.transparent);adapter=new ResultAdapter();grid.setAdapter(adapter);right.addView(grid,new LinearLayout.LayoutParams(-1,0,1));root.addView(right,new LinearLayout.LayoutParams(0,-1,1));

        query.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){if(searchTask!=null)handler.removeCallbacks(searchTask);String q=s==null?"":s.toString().trim();if(q.isEmpty())searchTask=SearchActivity.this::loadPopular;else searchTask=()->doSearch(q);handler.postDelayed(searchTask,420);}public void afterTextChanged(Editable e){}});
        back.requestFocus(); return root;
    }

    private void loadPopular(){title.setText("EM ALTA");status.setText("Atualizando...");ApiClient.catalog("movie",1,12,"",new ApiClient.Callback<ApiClient.CatalogPage>(){public void ok(ApiClient.CatalogPage p){runOnUiThread(()->{items.clear();items.addAll(p.items);adapter.notifyDataSetChanged();status.setText("Total: "+items.size());});}public void error(String m){runOnUiThread(()->status.setText("Falha: "+m));}});}
    private void doSearch(String q){
        title.setText("Resultados para “"+q+"”");status.setText("Pesquisando...");
        ApiClient.catalog("movie",1,18,q,new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage m){
                ApiClient.catalog("series",1,18,q,new ApiClient.Callback<ApiClient.CatalogPage>(){
                    public void ok(ApiClient.CatalogPage sr){
                        ApiClient.catalog("live",1,24,q,new ApiClient.Callback<ApiClient.CatalogPage>(){
                            public void ok(ApiClient.CatalogPage lv){runOnUiThread(()->{items.clear();items.addAll(m.items);items.addAll(sr.items);items.addAll(lv.items);adapter.notifyDataSetChanged();status.setText("Total: "+items.size());if(!items.isEmpty())grid.requestFocus();});}
                            public void error(String e){runOnUiThread(()->{items.clear();items.addAll(m.items);items.addAll(sr.items);adapter.notifyDataSetChanged();status.setText("Total: "+items.size());});}
                        });
                    }
                    public void error(String e){runOnUiThread(()->{items.clear();items.addAll(m.items);adapter.notifyDataSetChanged();status.setText("Total: "+items.size());});}
                });
            }
            public void error(String e){runOnUiThread(()->status.setText("Não foi possível pesquisar • "+e));}
        });
    }

    private void voiceSearch(){
        try{
            Intent in=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            in.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            in.putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.getDefault());
            in.putExtra(RecognizerIntent.EXTRA_PROMPT,"Fale o que deseja buscar");
            startActivityForResult(in,990);
        }catch(Exception e){Toast.makeText(this,"Busca por voz não disponível neste aparelho",Toast.LENGTH_SHORT).show();}
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==990&&resultCode==RESULT_OK&&data!=null){
            ArrayList<String> r=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if(r!=null&&!r.isEmpty()){query.setText(r.get(0));query.setSelection(query.length());}
        }
    }
    private String clean(String v,String f){if(v==null)return f;String s=v.trim();return s.isEmpty()||"null".equalsIgnoreCase(s)?f:s;}
}
