package com.greenplay.v5.ui.series;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.greenplay.v5.core.config.AppControlStore;
import com.greenplay.v5.core.config.NavConfigUi;
import com.greenplay.v5.core.config.AppNoticeUi;
import com.greenplay.v5.core.config.AppControlSync;
import com.greenplay.v5.core.config.BrandingStore;
import com.greenplay.v5.core.config.BrandingUi;
import com.greenplay.v5.core.session.SessionStore;
import com.greenplay.v5.data.model.series.SeriesCategory;
import com.greenplay.v5.data.model.series.SeriesItem;
import com.greenplay.v5.data.repository.SeriesRepository;
import com.greenplay.v5.databinding.ActivitySeriesBinding;
import com.greenplay.v5.ui.movies.MovieActivity;
import com.greenplay.v5.ui.settings.SettingsActivity;
import com.greenplay.v5.ui.tv.TvActivity;
import com.squareup.picasso.Target;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class SeriesActivity extends AppCompatActivity {
    private static final int PAGE_SIZE=180, PREFETCH=36;
    private ActivitySeriesBinding b; private SessionStore session; private BrandingStore branding; private AppControlStore control; private Target backgroundTarget; private SeriesRepository repo; private SeriesCategoryAdapter categories; private SeriesAdapter adapter; private GridLayoutManager grid;
    private volatile List<SeriesItem> all=Collections.emptyList(); private final List<SeriesItem> filtered=new ArrayList<>(); private String categoryId="", query=""; private int rendered=0, generation=0; private final ExecutorService filter=Executors.newSingleThreadExecutor(); private final Handler main=new Handler(Looper.getMainLooper()); private final Runnable delayedSearch=this::rebuild;

    @Override protected void onCreate(Bundle state){super.onCreate(state);b=ActivitySeriesBinding.inflate(getLayoutInflater());setContentView(b.getRoot());session=new SessionStore(this);if(!session.isLogged()||session.host().trim().isEmpty()){finish();return;}branding=new BrandingStore(this);control=new AppControlStore(this);repo=new SeriesRepository(session.host(),session.user(),session.pass());applyBranding();setup();bindNav();AppNoticeUi.show(this,control);AppControlSync.refresh(this,ok->runOnUiThread(()->{if(ok&&!isFinishing()){branding=new BrandingStore(this);control=new AppControlStore(this);applyBranding();applySectionVisibility();AppNoticeUi.show(this,control);}}));loadCategories();loadSeries("");}

    private void applyBranding(){BrandingUi.applyHeaderBrand(b.brandNameSeries,b.brandLogoSeries,branding);backgroundTarget=BrandingUi.applyBackground(b.getRoot(),branding);}
    private void setup(){categories=new SeriesCategoryAdapter(c->{categoryId=c.id==null?"":c.id;categories.select(categoryId);rebuild();});b.seriesCategories.setLayoutManager(new LinearLayoutManager(this));b.seriesCategories.setAdapter(categories);b.seriesCategories.setItemAnimator(null);adapter=new SeriesAdapter(this::openDetail);String seriesFallback=branding.seriesCover(); if(seriesFallback==null||seriesFallback.trim().isEmpty()) seriesFallback=branding.fallback(); adapter.setFallback(branding.absolute(seriesFallback));grid=new GridLayoutManager(this,6);b.seriesGrid.setLayoutManager(grid);b.seriesGrid.setAdapter(adapter);b.seriesGrid.setItemAnimator(null);b.seriesGrid.setHasFixedSize(true);b.seriesGrid.setItemViewCacheSize(18);b.seriesGrid.addOnScrollListener(new RecyclerView.OnScrollListener(){@Override public void onScrolled(RecyclerView rv,int dx,int dy){if(dy>0&&rendered<filtered.size()&&grid.findLastVisibleItemPosition()>=adapter.getItemCount()-PREFETCH)append();}});b.seriesSearch.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){query=s==null?"":s.toString().trim();main.removeCallbacks(delayedSearch);main.postDelayed(delayedSearch,180L);}public void afterTextChanged(Editable e){}});}
    private void bindNav(){b.navTv.setOnClickListener(v->startActivity(new Intent(this,TvActivity.class)));b.navMovies.setOnClickListener(v->startActivity(new Intent(this,MovieActivity.class)));b.navSeries.setOnClickListener(v->b.seriesSearch.requestFocus());b.navFootball.setOnClickListener(v->pending("FUTEBOL"));b.navKids.setOnClickListener(v->pending("KIDS"));b.navAnime.setOnClickListener(v->pending("ANIME"));b.navHot.setOnClickListener(v->pending("HOT"));b.seriesSettings.setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class)));applySectionVisibility();}
    private void applySectionVisibility(){NavConfigUi.apply(control,NavConfigUi.e("tv",b.navTv,10),NavConfigUi.e("football",b.navFootball,20),NavConfigUi.e("movies",b.navMovies,30),NavConfigUi.e("series",b.navSeries,40),NavConfigUi.e("kids",b.navKids,50),NavConfigUi.e("anime",b.navAnime,60),NavConfigUi.e("hot",b.navHot,70));}
    private void loadCategories(){repo.categories(new SeriesRepository.CategoriesResult(){public void success(List<SeriesCategory> rows){runOnUiThread(()->categories.submit(rows,categoryId));}public void error(String m){}});}
    private void loadSeries(String ignored){b.seriesLoading.setVisibility(View.VISIBLE);b.seriesError.setText("");repo.series("",new SeriesRepository.SeriesResult(){public void success(List<SeriesItem> rows){runOnUiThread(()->{b.seriesLoading.setVisibility(View.GONE);all=rows==null?Collections.emptyList():rows;rebuild();});}public void error(String m){runOnUiThread(()->{b.seriesLoading.setVisibility(View.GONE);b.seriesError.setText(m);});}});}
    private void rebuild(){final int g=++generation;final List<SeriesItem> snap=all;final String cat=categoryId;final String q=query.toLowerCase(Locale.ROOT);filter.execute(()->{ArrayList<SeriesItem> out=new ArrayList<>();for(SeriesItem x:snap){if(x==null)continue;if(cat!=null&&!cat.isEmpty()&&!cat.equals(x.categoryId))continue;if(!q.isEmpty()&&(x.name==null||!x.name.toLowerCase(Locale.ROOT).contains(q)))continue;out.add(x);}runOnUiThread(()->{if(g!=generation)return;filtered.clear();filtered.addAll(out);rendered=Math.min(PAGE_SIZE,filtered.size());adapter.submit(new ArrayList<>(filtered.subList(0,rendered)));b.seriesEmpty.setVisibility(filtered.isEmpty()?View.VISIBLE:View.GONE);});});}
    private void append(){int end=Math.min(filtered.size(),rendered+PAGE_SIZE);if(end<=rendered)return;rendered=end;adapter.submit(new ArrayList<>(filtered.subList(0,rendered)));}
    private void openDetail(SeriesItem x){Intent i=new Intent(this,SeriesDetailActivity.class);i.putExtra("id",x.id);i.putExtra("name",x.name);i.putExtra("cover",x.cover);i.putExtra("year",x.year);i.putExtra("rating",x.rating);startActivity(i);}
    private void pending(String n){Toast.makeText(this,n+" será aberto no módulo próprio",Toast.LENGTH_SHORT).show();}
    @Override protected void onDestroy(){main.removeCallbacksAndMessages(null);filter.shutdownNow();super.onDestroy();}
}
