package com.greenplay.v5.ui.tv;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.net.TrafficStats;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.exoplayer.ExoPlayer;
import com.greenplay.v5.core.player.GreenPlayerFactory;
import com.greenplay.v5.core.player.StreamInspector;
import com.greenplay.v5.core.catalog.CatalogMemory;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.greenplay.v5.core.network.StreamUrlFactory;
import com.greenplay.v5.core.session.SessionStore;
import com.greenplay.v5.core.config.BrandingStore;
import com.greenplay.v5.core.config.BrandingUi;
import com.greenplay.v5.core.config.AppControlStore;
import com.greenplay.v5.core.config.NavConfigUi;
import com.greenplay.v5.core.config.AppNoticeUi;
import com.greenplay.v5.core.config.AppControlSync;
import com.greenplay.v5.data.model.tv.TvCategory;
import com.greenplay.v5.data.model.tv.TvChannel;
import com.greenplay.v5.data.model.tv.TvEpg;
import com.greenplay.v5.data.repository.TvRepository;
import com.greenplay.v5.databinding.ActivityTvBinding;
import com.greenplay.v5.ui.player.PlayerActivity;
import com.greenplay.v5.ui.movies.MovieActivity;
import com.greenplay.v5.ui.series.SeriesActivity;
import com.greenplay.v5.ui.settings.SettingsActivity;
import java.util.ArrayList;
import java.util.List;
import java.util.HashSet;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

public final class TvActivity extends AppCompatActivity {
    private enum Mode { ALL, FAVORITES, RECENTS }

    private ActivityTvBinding b;
    private SessionStore session;
    private TvRepository repo;
    private TvCategoryAdapter categories;
    private TvChannelAdapter channels;
    private TvHistoryStore history;
    private Target brandingBackgroundTarget;
    private ExoPlayer previewPlayer;
    private TvChannel current;
    private Mode mode = Mode.ALL;
    private String currentCategoryId = "";
    private String currentCategoryName = "TODOS";
    private final List<TvChannel> allChannels = new ArrayList<>();
    private final Set<Long> epgRequested = new HashSet<>();
    private final Map<Long,String> rowEpgCache = new HashMap<>();
    private final Handler previewHandler = new Handler(Looper.getMainLooper());
    private Runnable pendingPreview;
    private int playbackAttempt = 0;
    private int previewGeneration = 0;
    private String lastPreparedUrl = "";
    private String lastPrepareReason = "INICIAL";
    private long lastPrepareAt = 0L;
    private int prepareCount = 0;
    private int bufferCount = 0;
    private boolean hasReachedReady = false;
    private long returnFocusChannelId = -1L;
    private boolean returningFromFullscreen = false;
    private boolean fullscreen = false;
    private ViewGroup previewOriginalParent;
    private ViewGroup.LayoutParams previewOriginalLayoutParams;
    private int previewOriginalIndex = -1;
    private ViewGroup loadingOriginalParent;
    private ViewGroup.LayoutParams loadingOriginalLayoutParams;
    private int loadingOriginalIndex = -1;
    // Fullscreen do V5 segue o comportamento visual da referência antiga, mas com implementação nova:
    // o MESMO PlayerView é ampliado, OK/toque abre uma lista lateral e somente VOLTAR sai do fullscreen.
    private android.widget.FrameLayout fullscreenMenuLayer;
    private boolean fullscreenMenuVisible = false;
    private androidx.recyclerview.widget.RecyclerView fullscreenChannelList;
    private TvChannelAdapter fullscreenChannels;
    private android.widget.EditText fullscreenSearch;
    private android.widget.FrameLayout fullscreenLayer;
    private android.widget.LinearLayout fullscreenInfoPanel;
    private android.widget.ImageView fullscreenLogo;
    private android.widget.TextView fullscreenNumber;
    private android.widget.TextView fullscreenName;
    private android.widget.TextView fullscreenNow;
    private android.widget.TextView fullscreenNext;
    private android.widget.ProgressBar fullscreenProgress;
    private String fullscreenMode = "all";
    private TvEpg lastEpg;
    private long lastEpgChannelId = -1L;
    private boolean appWentToBackground = false;
    private android.widget.TextView fullscreenNetworkSpeed;
    private android.widget.TextView fullscreenClock;
    private android.widget.TextView fullscreenDiagnostic;
    private final Handler uiTickerHandler = new Handler(Looper.getMainLooper());
    private final Handler infoHideHandler = new Handler(Looper.getMainLooper());
    private boolean fullscreenInfoVisible = false;
    private final Runnable fullscreenInfoAutoHide = () -> {
        if(fullscreen && !fullscreenMenuVisible && fullscreenInfoPanel!=null){
            fullscreenInfoPanel.animate().alpha(0f).setDuration(220).withEndAction(() -> {
                if(fullscreenInfoPanel!=null) fullscreenInfoPanel.setVisibility(View.GONE);
                fullscreenInfoVisible=false;
            }).start();
        }
    };
    private final Runnable uiTicker = new Runnable(){
        @Override public void run(){
            updateClockAndEpgProgress();
            uiTickerHandler.postDelayed(this,5000L);
        }
    };
    private final Handler networkHandler = new Handler(Looper.getMainLooper());
    private long lastRxBytes = -1L;
    private long lastRxAt = -1L;
    private final Runnable networkTicker = new Runnable(){
        @Override public void run(){
            updateNetworkSpeed();
            networkHandler.postDelayed(this,1000L);
        }
    };

    @Override protected void onCreate(Bundle state){
        super.onCreate(state);
        b=ActivityTvBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        session=new SessionStore(this);
        if(!session.isLogged()||session.host().trim().isEmpty()){finish();return;}
        repo=new TvRepository(session.host(),session.user(),session.pass());
        history=new TvHistoryStore(this);
        BrandingStore branding=new BrandingStore(this);
        BrandingUi.applyHeaderBrand(b.brandNameTv,b.brandLogoTv,branding);
        brandingBackgroundTarget=BrandingUi.applyBackground(b.getRoot(),branding);
        b.filterFavorites.setTextColor(BrandingUi.color(branding.accent(),0xFF29E76F));
        b.filterFavorites.setVisibility(View.GONE);
        setupLists(); setupSearch(); setupPlayer(); bindTopNav(); bindModes(); selectMode(Mode.ALL);
        AppNoticeUi.show(this,new AppControlStore(this));
        AppControlSync.refresh(this, ok -> runOnUiThread(() -> { if(ok && !isFinishing()){
            BrandingStore latest=new BrandingStore(this);
            BrandingUi.applyHeaderBrand(b.brandNameTv,b.brandLogoTv,latest);
            brandingBackgroundTarget=BrandingUi.applyBackground(b.getRoot(),latest);
            applyConfiguredNav(); AppNoticeUi.show(this,new AppControlStore(this));
        }}));
        List<TvChannel> preparedChannels = CatalogMemory.channels();
        if(!preparedChannels.isEmpty()){
            b.loading.setVisibility(View.GONE);
            renderChannels(preparedChannels,true);
        }else{
            loadChannels("","TODOS");
        }
        lastRxBytes=TrafficStats.getTotalRxBytes(); lastRxAt=android.os.SystemClock.elapsedRealtime(); networkHandler.post(networkTicker); uiTickerHandler.post(uiTicker);
    }

    private void setupLists(){
        channels=new TvChannelAdapter(new TvChannelAdapter.Listener(){
            @Override public void onFocus(TvChannel channel){
                // Navegação rápida no D-pad não deve disparar rede/notify a cada item.
                // O EPG das linhas visíveis é pré-carregado pelo scroll.
                if(current!=null && current.id==channel.id) b.previewStatus.setText("OK: tela cheia");
                else b.previewStatus.setText("OK: selecionar canal");
            }
            @Override public void onOpen(TvChannel channel){
                // Comportamento de TV: 1º OK seleciona/toca no preview; 2º OK abre tela cheia.
                if(current==null || current.id!=channel.id){
                    history.markRecent(channel.id);
                    returnFocusChannelId=channel.id;
                    showChannel(channel,true);
                    return;
                }
                history.markRecent(channel.id);
                returnFocusChannelId=channel.id;
                openFull(channel);
            }
            @Override public void onFavorite(TvChannel channel){history.toggleFavorite(channel.id);channels.refreshFavorite(channel.id);if(mode==Mode.FAVORITES)applyMode();}
            @Override public boolean isFavorite(TvChannel channel){return history.isFavorite(channel.id);}
        });
        b.channelList.setLayoutManager(new LinearLayoutManager(this));
        b.channelList.setAdapter(channels);
        b.channelList.addOnScrollListener(new androidx.recyclerview.widget.RecyclerView.OnScrollListener(){
            @Override public void onScrolled(@NonNull androidx.recyclerview.widget.RecyclerView rv,int dx,int dy){primeVisibleEpg();}
        });
    }

    private void setupSearch(){
        b.search.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){channels.filter(s.toString());updateTotal();}
            public void afterTextChanged(Editable e){}
        });
    }

    private void setupPlayer(){
        previewPlayer=GreenPlayerFactory.create(this);
        b.previewPlayer.setPlayer(previewPlayer);
        b.previewPlayer.setUseController(false);
        b.previewPlayer.setFocusable(true);
        b.previewPlayer.setClickable(true);
        b.previewPlayer.setOnClickListener(v -> {
            if(fullscreen){
                // Igual à referência: toque/OK em tela cheia abre/fecha a lista lateral; não reduz o vídeo.
                toggleFullscreenMenu();
                return;
            }
            if(current!=null){
                history.markRecent(current.id);
                returnFocusChannelId=current.id;
                openFull(current);
            }
        });
        b.previewPlayer.setOnKeyListener((v,keyCode,event) -> {
            if(event.getAction()==KeyEvent.ACTION_UP && (keyCode==KeyEvent.KEYCODE_DPAD_CENTER || keyCode==KeyEvent.KEYCODE_ENTER)){
                if(fullscreen){
                    toggleFullscreenMenu();
                    return true;
                }
                if(current!=null){
                    history.markRecent(current.id);
                    returnFocusChannelId=current.id;
                    openFull(current);
                    return true;
                }
            }
            return false;
        });
        previewPlayer.addListener(new Player.Listener(){
            @Override public void onPlaybackStateChanged(int playbackState){
                if(playbackState==Player.STATE_BUFFERING){
                    bufferCount++;
                    setChannelLoading(true);
                    b.previewStatus.setText("Carregando canal...");
                    long sincePrepare = android.os.SystemClock.elapsedRealtime()-lastPrepareAt;
                    if(hasReachedReady && sincePrepare>2500L){
                        setDiagnostic("BUFFER DA FONTE  •  B"+bufferCount+"  •  sem novo prepare");
                    }else{
                        setDiagnostic("APP ABRINDO STREAM  •  "+lastPrepareReason+"  •  P"+prepareCount);
                    }
                } else if(playbackState==Player.STATE_READY){
                    hasReachedReady=true;
                    setChannelLoading(false);
                    b.previewStatus.setText("Canal selecionado • OK novamente: tela cheia");
                    setDiagnostic("READY  •  P"+prepareCount+"  B"+bufferCount);
                } else if(playbackState==Player.STATE_ENDED){
                    setChannelLoading(false);
                    setDiagnostic("STREAM ENCERRADO");
                }
            }
            @Override public void onPlayerError(@NonNull PlaybackException error){
                setDiagnostic("ERRO FONTE/PLAYER • "+error.getErrorCodeName());
                if(current!=null && playbackAttempt < 1){
                    playbackAttempt++;
                    String primaryExt = current.extension == null ? "" : current.extension.trim();
                    String alt = "m3u8".equalsIgnoreCase(primaryExt)
                            ? StreamUrlFactory.liveTs(session.host(),session.user(),session.pass(),current.id)
                            : StreamUrlFactory.liveHls(session.host(),session.user(),session.pass(),current.id);
                    b.previewStatus.setText("Alternando formato...");
                    playResolvedUrl(alt, alt.toLowerCase(java.util.Locale.US).contains(".m3u8") ? "hls" : "ts");
                }else{
                    setChannelLoading(false);
                    b.previewStatus.setText("ERRO "+error.getErrorCodeName()+" • "+shortMessage(error));
                }
            }
        });
    }

    private void bindTopNav(){
        b.navTv.setOnClickListener(v->b.search.requestFocus());
        b.navFootball.setOnClickListener(v->Toast.makeText(this,"Futebol será aberto no módulo próprio",Toast.LENGTH_SHORT).show());
        b.navMovies.setOnClickListener(v->startActivity(new Intent(this,MovieActivity.class)));
        b.navSeries.setOnClickListener(v->startActivity(new Intent(this,SeriesActivity.class)));
        b.navKids.setOnClickListener(v->Toast.makeText(this,"Kids será isolado",Toast.LENGTH_SHORT).show());
        b.navAnime.setOnClickListener(v->Toast.makeText(this,"Anime será isolado",Toast.LENGTH_SHORT).show());
        b.navHot.setOnClickListener(v->Toast.makeText(this,"HOT será protegido por PIN",Toast.LENGTH_SHORT).show());
        b.mainSettings.setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class)));
        applyConfiguredNav();
    }


    private void applyConfiguredNav(){
        AppControlStore control=new AppControlStore(this);
        NavConfigUi.apply(control,
                NavConfigUi.e("tv",b.navTv,10), NavConfigUi.e("football",b.navFootball,20),
                NavConfigUi.e("movies",b.navMovies,30), NavConfigUi.e("series",b.navSeries,40),
                NavConfigUi.e("kids",b.navKids,50), NavConfigUi.e("anime",b.navAnime,60),
                NavConfigUi.e("hot",b.navHot,70));
        BrandingStore latest=new BrandingStore(this);
        b.filterFavorites.setVisibility(View.GONE);
    }
    private void bindModes(){
        b.filterAll.setOnClickListener(v->{selectMode(Mode.ALL); applyMode();});
        b.filterFavorites.setOnClickListener(v->{if(mode==Mode.FAVORITES){selectMode(Mode.ALL);applyMode();}else{selectMode(Mode.FAVORITES);ensureAllThenApply();}});
        b.filterRecents.setOnClickListener(v->{selectMode(Mode.RECENTS); ensureAllThenApply();});
    }

    private void selectMode(Mode m){
        mode=m;
        b.filterAll.setSelected(m==Mode.ALL);
        b.filterFavorites.setSelected(m==Mode.FAVORITES);
        b.filterRecents.setSelected(m==Mode.RECENTS);
        b.filterFavorites.setText(m==Mode.FAVORITES?"★ FAVORITOS":"☆ FAVORITOS");
        b.filterFavorites.setTextColor(0xFF29E76F);
    }

    private void loadChannels(String categoryId,String categoryName){
        currentCategoryId=categoryId==null?"":categoryId;
        currentCategoryName=categoryName==null?"TODOS":categoryName;
        b.error.setText("");

        // Catálogo vem sempre da permissão atual do bouquet; não exibe lista antiga de outra fonte.
        b.loading.setVisibility(View.VISIBLE);

        final String requestedCategory=currentCategoryId;
        repo.channels(requestedCategory,new TvRepository.ChannelsResult(){
            @Override public void success(List<TvChannel> rows){runOnUiThread(()->{
                if(!requestedCategory.equals(currentCategoryId))return;
                b.loading.setVisibility(View.GONE);
                if(requestedCategory.isEmpty()) CatalogMemory.setChannels(rows);
                renderChannels(rows,true);
            });}
            @Override public void error(String message){runOnUiThread(()->{
                if(!requestedCategory.equals(currentCategoryId))return;
                b.loading.setVisibility(View.GONE);
                if(channels.getItemCount()==0){b.error.setText(message);channels.setRows(null);updateTotal();stopPreview();}
            });}
        });
    }

    private void renderChannels(List<TvChannel> rows,boolean fresh){
        if(currentCategoryId.isEmpty()){allChannels.clear();allChannels.addAll(rows);}
        channels.setSectionLabel(currentCategoryName.equals("TODOS")?"TV AO VIVO":"CH: "+currentCategoryName);
        channels.setRows(rows);
        updateTotal();
        prefetchVisibleLogos(rows);
        b.channelList.postDelayed(TvActivity.this::primeVisibleEpg,220L);
        TvChannel f=channels.first();
        if(f==null){current=null;stopPreview();return;}
        if(current==null){
            showChannel(f,true);
        }else{
            int pos=channels.positionOf(current.id);
            if(pos<0){
                // O bouquet/fonte pode ter mudado no painel enquanto o app estava aberto.
                // Não tenta reproduzir um canal antigo que já saiu da permissão atual.
                current=null;
                showChannel(f,true);
            }else{
                channels.setSelectedChannel(current.id);
                b.channelList.scrollToPosition(pos);
            }
        }
    }

    private void prefetchVisibleLogos(List<TvChannel> rows){
        if(rows==null)return;
        int limit=Math.min(24,rows.size());
        for(int i=0;i<limit;i++){
            String logo=rows.get(i).logo;
            if(logo!=null&&!logo.trim().isEmpty()){
                try{Picasso.get().load(logo).fetch();}catch(Exception ignored){}
            }
        }
    }

    private void ensureAllThenApply(){
        if(!allChannels.isEmpty()){applyMode();return;}
        b.loading.setVisibility(View.VISIBLE);
        repo.channels("",new TvRepository.ChannelsResult(){
            @Override public void success(List<TvChannel> rows){runOnUiThread(()->{b.loading.setVisibility(View.GONE);allChannels.clear();allChannels.addAll(rows);applyMode();});}
            @Override public void error(String message){runOnUiThread(()->{b.loading.setVisibility(View.GONE);b.error.setText(message);});}
        });
    }

    private void applyMode(){
        b.error.setText("");
        if(mode==Mode.FAVORITES){
            channels.setSectionLabel("FAVORITOS");
            channels.setRows(history.filterFavorites(allChannels));
        }else if(mode==Mode.RECENTS){
            channels.setSectionLabel("RECENTES");
            channels.setRows(history.filterRecents(allChannels));
        }else{
            if(currentCategoryId.isEmpty() && !allChannels.isEmpty()){
                channels.setSectionLabel("TV AO VIVO");channels.setRows(allChannels);
            }
        }
        updateTotal();
        TvChannel f=channels.first();if(f!=null)showChannel(f,true);else stopPreview();
    }

    private void updateTotal(){ if(b.total!=null)b.total.setVisibility(View.GONE); }

    private void showChannel(TvChannel c,boolean autoplay){
        current=c;
        channels.setSelectedChannel(c.id);
        if(fullscreenChannels!=null)fullscreenChannels.setSelectedChannel(c.id);
        b.previewName.setText(c.name);
        int p = channels.positionOf(c.id);
        b.previewChannelNumber.setText(p >= 0 ? String.valueOf(p + 1) : "");
        b.previewLogo.setImageDrawable(null);
        if(c.logo!=null && !c.logo.trim().isEmpty()) Picasso.get().load(c.logo).fit().centerInside().noFade().into(b.previewLogo);
        syncFullscreenChannelHeader(c, p);
        if(lastEpgChannelId != c.id){ lastEpg=null; lastEpgChannelId=c.id; }
        b.epgNow.setText("Carregando...");
        b.epgNext.setText("Carregando...");
        b.epgProgress.setProgress(0);
        repo.epg(c.id,new TvRepository.EpgResult(){
            @Override public void success(TvEpg epg){runOnUiThread(()->{
                if(current!=c)return;
                lastEpg=epg; lastEpgChannelId=c.id;
                b.epgNow.setText((epg.nowTime.isEmpty()?"":epg.nowTime+"  •  ")+epg.nowTitle);
                b.epgNext.setText((epg.nextTime.isEmpty()?"":epg.nextTime+"  •  ")+epg.nextTitle);
                String rowEpg=(epg.nowTime.isEmpty()?"":epg.nowTime+" • ")+epg.nowTitle;
                rowEpgCache.put(c.id,rowEpg);
                epgRequested.add(c.id);
                channels.setEpgText(c.id,rowEpg);
                if(fullscreenChannels!=null)fullscreenChannels.setEpgText(c.id,rowEpg);
                int progress = epgProgress(epg);
                b.epgProgress.setProgress(progress);
                syncFullscreenEpg(epg, progress);
            });}
            @Override public void error(String m){}
        });
        if(autoplay){
            if(pendingPreview!=null)previewHandler.removeCallbacks(pendingPreview);
            playPreview(c);
        }
    }

    private void requestRowEpg(TvChannel c){
        if(c==null)return;
        String cached=rowEpgCache.get(c.id);
        if(cached!=null){channels.setEpgText(c.id,cached);if(fullscreenChannels!=null)fullscreenChannels.setEpgText(c.id,cached);return;}
        if(epgRequested.contains(c.id))return;
        epgRequested.add(c.id);
        repo.epg(c.id,new TvRepository.EpgResult(){
            @Override public void success(TvEpg epg){runOnUiThread(()->{
                String text=(epg.nowTime.isEmpty()?"":epg.nowTime+" • ")+epg.nowTitle;
                rowEpgCache.put(c.id,text);
                channels.setEpgText(c.id,text);
                if(fullscreenChannels!=null)fullscreenChannels.setEpgText(c.id,text);
            });}
            @Override public void error(String message){runOnUiThread(()->{
                rowEpgCache.put(c.id,"Programação indisponível");
                channels.setEpgText(c.id,"Programação indisponível");
                if(fullscreenChannels!=null)fullscreenChannels.setEpgText(c.id,"Programação indisponível");
            });}
        });
    }

    private void primeVisibleEpg(){
        if(b==null || b.channelList==null)return;
        androidx.recyclerview.widget.RecyclerView.LayoutManager lm=b.channelList.getLayoutManager();
        if(!(lm instanceof LinearLayoutManager))return;
        LinearLayoutManager ll=(LinearLayoutManager)lm;
        int first=Math.max(0,ll.findFirstVisibleItemPosition());
        int last=ll.findLastVisibleItemPosition();
        if(last<first)last=Math.min(channels.getItemCount()-1,first+8);
        for(int i=first;i<=Math.min(last+2,channels.getItemCount()-1);i++)requestRowEpg(channels.itemAt(i));
    }

    private void zapRelative(int delta){
        List<TvChannel> rows=channels.snapshot();
        if(rows.isEmpty() || current==null)return;
        int idx=-1;
        for(int i=0;i<rows.size();i++)if(rows.get(i).id==current.id){idx=i;break;}
        if(idx<0)idx=0;
        int next=(idx+delta)%rows.size(); if(next<0)next+=rows.size();
        TvChannel target=rows.get(next);
        history.markRecent(target.id); returnFocusChannelId=target.id;
        showChannel(target,true);
        showFullscreenInfoTemporarily();
    }

    private int epgProgress(TvEpg epg){
        if(epg.nowStart<=0||epg.nowStop<=epg.nowStart)return 0;
        long now=System.currentTimeMillis()/1000L;
        long done=Math.max(0,Math.min(epg.nowStop-epg.nowStart,now-epg.nowStart));
        return (int)((done*100L)/(epg.nowStop-epg.nowStart));
    }

    private void playPreview(TvChannel c){
        playPreview(c,"TROCA_CANAL");
    }

    private void playPreview(TvChannel c,String reason){
        playbackAttempt=0;
        lastPrepareReason=reason==null?"DESCONHECIDO":reason;
        hasReachedReady=false;
        previewGeneration++;
        String ext=c.extension==null?"":c.extension.trim();
        boolean hls="m3u8".equalsIgnoreCase(ext);
        String first=hls
                ? StreamUrlFactory.liveHls(session.host(),session.user(),session.pass(),c.id)
                : StreamUrlFactory.liveTs(session.host(),session.user(),session.pass(),c.id);
        setChannelLoading(true);
        b.previewStatus.setText("Carregando canal...");
        playResolvedUrl(first, hls ? "hls" : "ts");
    }

    private void inspectAndPlay(TvChannel c, String url, int generation){
        StreamInspector.inspect(url,new StreamInspector.Callback(){
            @Override public void success(StreamInspector.Result r){runOnUiThread(()->{
                if(current!=c || generation!=previewGeneration)return;
                b.previewStatus.setText("HTTP "+r.httpCode+" • "+(r.detected==null?"AUTO":r.detected.toUpperCase(java.util.Locale.US))+
                        (r.contentType.isEmpty()?"":" • "+trimType(r.contentType)));
                if(r.httpCode<200 || r.httpCode>=300){
                    if(playbackAttempt<1){playbackAttempt++;inspectAndPlay(c,StreamUrlFactory.liveHls(session.host(),session.user(),session.pass(),c.id),generation);}
                    else b.previewStatus.setText("STREAM HTTP "+r.httpCode);
                    return;
                }
                playResolvedUrl(r.finalUrl,r.detected);
            });}
            @Override public void error(String message){runOnUiThread(()->{
                if(current!=c || generation!=previewGeneration)return;
                b.previewStatus.setText("FALHA STREAM • "+shortText(message));
                if(playbackAttempt<1){playbackAttempt++;inspectAndPlay(c,StreamUrlFactory.liveHls(session.host(),session.user(),session.pass(),c.id),generation);}
            });}
        });
    }

    private void playResolvedUrl(String url,String detected){
        try{
            if(url==null || url.trim().isEmpty())return;
            // Diagnóstico: nunca reprepare o MESMO stream sem uma razão explícita.
            // Se o player já chegou em READY e volta a BUFFERING sem este método rodar, o gargalo é a fonte/rede.
            if(url.equals(lastPreparedUrl) && previewPlayer.getMediaItemCount()>0 && previewPlayer.getPlaybackState()!=Player.STATE_IDLE){
                previewPlayer.play();
                setDiagnostic("SEM REPREPARE • stream já ativo");
                return;
            }
            MediaItem.Builder item=new MediaItem.Builder().setUri(url);
            if("hls".equalsIgnoreCase(detected)) item.setMimeType(MimeTypes.APPLICATION_M3U8);
            else if("ts".equalsIgnoreCase(detected)) item.setMimeType(MimeTypes.VIDEO_MP2T);
            lastPreparedUrl=url;
            lastPrepareAt=android.os.SystemClock.elapsedRealtime();
            prepareCount++;
            setDiagnostic("PREPARE #"+prepareCount+" • "+lastPrepareReason);
            previewPlayer.setMediaItem(item.build(), true);
            previewPlayer.prepare();
            previewPlayer.play();
        }catch(Exception e){b.previewStatus.setText("ERRO AO ABRIR • "+shortMessage(e));setDiagnostic("ERRO PREPARE • "+shortMessage(e));}
    }

    private void setDiagnostic(String text){
        // Diagnóstico temporário removido após confirmar que o buffering era da fonte.
    }

    private void buildFullscreenDiagnostic(){
        // Diagnóstico temporário removido.
    }

    private void setChannelLoading(boolean show){
        if(b==null || b.channelLoadingOverlay==null)return;
        b.channelLoadingOverlay.setVisibility(show?View.VISIBLE:View.GONE);
        if(show){
            b.channelLoadingOverlay.setAlpha(0f);
            b.channelLoadingOverlay.animate().alpha(1f).setDuration(140).start();
            b.channelLoadingOverlay.bringToFront();
        }
    }

    private static String trimType(String t){
        String x=t==null?"":t;int p=x.indexOf(';');if(p>0)x=x.substring(0,p);return x.length()>28?x.substring(0,28):x;
    }
    private static String shortText(String m){if(m==null||m.trim().isEmpty())return "sem detalhe";m=m.replace('\n',' ').replace('\r',' ').trim();return m.length()>70?m.substring(0,70):m;}

    private static String shortMessage(Throwable e){
        String m=e==null?"sem detalhe":e.getMessage();
        if(m==null||m.trim().isEmpty())m=e==null?"sem detalhe":e.getClass().getSimpleName();
        m=m.replace('\n',' ').replace('\r',' ').trim();
        return m.length()>70?m.substring(0,70):m;
    }

    private void stopPreview(){
        setChannelLoading(false);
        if(previewPlayer!=null){previewPlayer.stop();previewPlayer.clearMediaItems();}
        lastPreparedUrl=""; hasReachedReady=false;
        b.previewName.setText("Selecione um canal");b.previewChannelNumber.setText("");b.previewLogo.setImageDrawable(null);b.epgNow.setText("Sem informação");b.epgNext.setText("Sem informação");b.epgProgress.setProgress(0);b.previewStatus.setText("OK: selecionar canal");
    }

    private void openFull(TvChannel c){
        if(fullscreen || c==null)return;
        ViewGroup parent=(ViewGroup)b.previewPlayer.getParent();
        if(parent==null)return;
        fullscreen=true;
        fullscreenMenuVisible=false;
        previewOriginalParent=parent;
        previewOriginalIndex=parent.indexOfChild(b.previewPlayer);
        previewOriginalLayoutParams=b.previewPlayer.getLayoutParams();
        loadingOriginalParent=(ViewGroup)b.channelLoadingOverlay.getParent();
        loadingOriginalIndex=loadingOriginalParent==null?-1:loadingOriginalParent.indexOfChild(b.channelLoadingOverlay);
        loadingOriginalLayoutParams=b.channelLoadingOverlay.getLayoutParams();
        parent.removeView(b.previewPlayer);
        if(loadingOriginalParent!=null)loadingOriginalParent.removeView(b.channelLoadingOverlay);

        // Mesmo PlayerView e mesmo stream: apenas mudamos a hierarquia visual.
        ViewGroup root=findViewById(android.R.id.content);
        fullscreenLayer=new android.widget.FrameLayout(this);
        fullscreenLayer.setBackgroundColor(android.graphics.Color.BLACK);
        root.addView(fullscreenLayer,new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));

        b.previewPlayer.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FILL);
        fullscreenLayer.addView(b.previewPlayer,new android.widget.FrameLayout.LayoutParams(-1,-1));
        android.widget.FrameLayout.LayoutParams loadLp=new android.widget.FrameLayout.LayoutParams(dp(150),dp(54),android.view.Gravity.CENTER);
        fullscreenLayer.addView(b.channelLoadingOverlay,loadLp);
        buildFullscreenInfoPanel();
        buildFullscreenMenu();
        buildNetworkSpeedOverlay();
        showFullscreenInfoTemporarily();
        uiTickerHandler.removeCallbacks(uiTicker); uiTickerHandler.post(uiTicker);
        fullscreenLayer.bringToFront();
        b.previewPlayer.requestFocus();
        if(previewPlayer!=null)previewPlayer.play();
    }

    private void buildFullscreenInfoPanel(){
        if(fullscreenLayer==null)return;
        fullscreenInfoPanel=new android.widget.LinearLayout(this);
        fullscreenInfoPanel.setOrientation(android.widget.LinearLayout.VERTICAL);
        fullscreenInfoPanel.setPadding(dp(18),dp(8),dp(18),dp(7));
        android.graphics.drawable.GradientDrawable bg=new android.graphics.drawable.GradientDrawable();
        bg.setColor(0xF0090C0A);
        fullscreenInfoPanel.setBackground(bg);

        android.widget.LinearLayout topRow=new android.widget.LinearLayout(this);
        topRow.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        topRow.setGravity(android.view.Gravity.CENTER_VERTICAL);

        fullscreenLogo=new android.widget.ImageView(this);
        fullscreenLogo.setScaleType(android.widget.ImageView.ScaleType.CENTER_INSIDE);
        topRow.addView(fullscreenLogo,new android.widget.LinearLayout.LayoutParams(dp(64),dp(56)));

        android.widget.LinearLayout nameCol=new android.widget.LinearLayout(this);
        nameCol.setOrientation(android.widget.LinearLayout.VERTICAL);
        nameCol.setGravity(android.view.Gravity.CENTER_VERTICAL);
        android.widget.LinearLayout titleRow=new android.widget.LinearLayout(this);
        titleRow.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        titleRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
        fullscreenNumber=new android.widget.TextView(this);
        fullscreenNumber.setTextColor(0xFF29E76F); fullscreenNumber.setTextSize(18); fullscreenNumber.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);
        fullscreenName=new android.widget.TextView(this);
        fullscreenName.setTextColor(android.graphics.Color.WHITE); fullscreenName.setTextSize(17); fullscreenName.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD); fullscreenName.setMaxLines(1); fullscreenName.setEllipsize(android.text.TextUtils.TruncateAt.END);
        titleRow.addView(fullscreenNumber,new android.widget.LinearLayout.LayoutParams(dp(42),dp(28)));
        titleRow.addView(fullscreenName,new android.widget.LinearLayout.LayoutParams(0,dp(28),1));
        nameCol.addView(titleRow,new android.widget.LinearLayout.LayoutParams(-1,dp(30)));
        android.widget.TextView live=new android.widget.TextView(this); live.setText("• AO VIVO"); live.setTextColor(0xFFFF4C55); live.setTextSize(9); live.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);
        nameCol.addView(live,new android.widget.LinearLayout.LayoutParams(-1,dp(18)));
        topRow.addView(nameCol,new android.widget.LinearLayout.LayoutParams(0,dp(56),1.0f));

        View sep1=new View(this); sep1.setBackgroundColor(0xFF39463F); topRow.addView(sep1,new android.widget.LinearLayout.LayoutParams(dp(1),dp(42)));

        android.widget.LinearLayout nowCol=new android.widget.LinearLayout(this); nowCol.setOrientation(android.widget.LinearLayout.VERTICAL); nowCol.setGravity(android.view.Gravity.CENTER_VERTICAL); nowCol.setPadding(dp(14),0,dp(10),0);
        android.widget.TextView nowLabel=new android.widget.TextView(this); nowLabel.setText("ATUAL"); nowLabel.setTextColor(0xFFFF4C55); nowLabel.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD); nowLabel.setTextSize(9);
        fullscreenNow=new android.widget.TextView(this); fullscreenNow.setTextColor(0xFFFF6B70); fullscreenNow.setTextSize(12); fullscreenNow.setMaxLines(1); fullscreenNow.setEllipsize(android.text.TextUtils.TruncateAt.END);
        nowCol.addView(nowLabel,new android.widget.LinearLayout.LayoutParams(-1,dp(18))); nowCol.addView(fullscreenNow,new android.widget.LinearLayout.LayoutParams(-1,dp(26)));
        topRow.addView(nowCol,new android.widget.LinearLayout.LayoutParams(0,dp(56),1.55f));

        View sep2=new View(this); sep2.setBackgroundColor(0xFF39463F); topRow.addView(sep2,new android.widget.LinearLayout.LayoutParams(dp(1),dp(42)));

        android.widget.LinearLayout nextCol=new android.widget.LinearLayout(this); nextCol.setOrientation(android.widget.LinearLayout.VERTICAL); nextCol.setGravity(android.view.Gravity.CENTER_VERTICAL); nextCol.setPadding(dp(14),0,0,0);
        android.widget.TextView nextLabel=new android.widget.TextView(this); nextLabel.setText("PRÓXIMO"); nextLabel.setTextColor(0xFFC5D0C8); nextLabel.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD); nextLabel.setTextSize(9);
        fullscreenNext=new android.widget.TextView(this); fullscreenNext.setTextColor(android.graphics.Color.WHITE); fullscreenNext.setTextSize(12); fullscreenNext.setMaxLines(1); fullscreenNext.setEllipsize(android.text.TextUtils.TruncateAt.END);
        nextCol.addView(nextLabel,new android.widget.LinearLayout.LayoutParams(-1,dp(18))); nextCol.addView(fullscreenNext,new android.widget.LinearLayout.LayoutParams(-1,dp(26)));
        topRow.addView(nextCol,new android.widget.LinearLayout.LayoutParams(0,dp(56),1.55f));

        fullscreenInfoPanel.addView(topRow,new android.widget.LinearLayout.LayoutParams(-1,0,1));
        fullscreenProgress=new android.widget.ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); fullscreenProgress.setMax(100); fullscreenProgress.setProgressTintList(android.content.res.ColorStateList.valueOf(0xFF29E76F)); fullscreenProgress.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF4B5550));
        fullscreenInfoPanel.addView(fullscreenProgress,new android.widget.LinearLayout.LayoutParams(-1,dp(4)));

        android.widget.FrameLayout.LayoutParams lp=new android.widget.FrameLayout.LayoutParams(-1,dp(96),android.view.Gravity.BOTTOM);
        fullscreenLayer.addView(fullscreenInfoPanel,lp);
        fullscreenInfoVisible=true;
        int p=current==null?-1:channels.positionOf(current.id);
        syncFullscreenChannelHeader(current,p);
        if(current!=null && lastEpg!=null && lastEpgChannelId==current.id){
            syncFullscreenEpg(lastEpg,epgProgress(lastEpg));
        } else {
            if(fullscreenNow!=null) fullscreenNow.setText("Carregando...");
            if(fullscreenNext!=null) fullscreenNext.setText("Carregando...");
        }
    }

    private void syncFullscreenChannelHeader(TvChannel c,int pos){
        if(c==null)return;
        if(fullscreenName!=null)fullscreenName.setText(c.name==null?"Canal":c.name);
        if(fullscreenNumber!=null)fullscreenNumber.setText(pos>=0?String.valueOf(pos+1):"");
        if(fullscreenLogo!=null){
            fullscreenLogo.setImageDrawable(null);
            if(c.logo!=null && !c.logo.trim().isEmpty())Picasso.get().load(c.logo).fit().centerInside().noFade().into(fullscreenLogo);
        }
    }

    private void syncFullscreenEpg(TvEpg epg,int progress){
        if(epg==null)return;
        if(fullscreenNow!=null)fullscreenNow.setText((epg.nowTime.isEmpty()?"":epg.nowTime+"  •  ")+epg.nowTitle);
        if(fullscreenNext!=null)fullscreenNext.setText((epg.nextTime.isEmpty()?"":epg.nextTime+"  •  ")+epg.nextTitle);
        if(fullscreenProgress!=null)fullscreenProgress.setProgress(progress);
    }

    private void buildFullscreenMenu(){
        if(fullscreenLayer==null)return;
        fullscreenMenuLayer=new android.widget.FrameLayout(this);
        fullscreenMenuLayer.setBackgroundColor(0x00000000);
        fullscreenMenuLayer.setVisibility(View.GONE);

        android.widget.LinearLayout menu=new android.widget.LinearLayout(this);
        menu.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        android.graphics.drawable.GradientDrawable menuBg=new android.graphics.drawable.GradientDrawable(); menuBg.setColor(0xF20A100D); menu.setBackground(menuBg);

        android.widget.LinearLayout rail=new android.widget.LinearLayout(this); rail.setOrientation(android.widget.LinearLayout.VERTICAL); rail.setGravity(android.view.Gravity.TOP|android.view.Gravity.CENTER_HORIZONTAL); rail.setPadding(0,dp(14),0,dp(8)); rail.setBackgroundColor(0xEE060A08);
        android.widget.TextView searchIcon=fullscreenRail("⌕");
        android.widget.TextView epgIcon=fullscreenRail("◷");
        android.widget.TextView favIcon=fullscreenRail("★"); favIcon.setVisibility(View.GONE);
        android.widget.TextView allIcon=fullscreenRail("☷");
        rail.addView(searchIcon,new android.widget.LinearLayout.LayoutParams(-1,dp(50)));
        rail.addView(epgIcon,new android.widget.LinearLayout.LayoutParams(-1,dp(50)));
        rail.addView(favIcon,new android.widget.LinearLayout.LayoutParams(-1,dp(50)));
        rail.addView(allIcon,new android.widget.LinearLayout.LayoutParams(-1,dp(50)));
        menu.addView(rail,new android.widget.LinearLayout.LayoutParams(dp(54),-1));

        android.widget.LinearLayout content=new android.widget.LinearLayout(this); content.setOrientation(android.widget.LinearLayout.VERTICAL); content.setPadding(dp(10),dp(8),dp(8),dp(8));
        android.widget.TextView title=new android.widget.TextView(this); title.setText("Lista de canais"); title.setTextColor(android.graphics.Color.WHITE); title.setTextSize(14); title.setGravity(android.view.Gravity.CENTER);
        content.addView(title,new android.widget.LinearLayout.LayoutParams(-1,dp(38)));
        View sep=new View(this); sep.setBackgroundColor(0xFF506157); content.addView(sep,new android.widget.LinearLayout.LayoutParams(-1,dp(1)));

        fullscreenSearch=new android.widget.EditText(this); fullscreenSearch.setSingleLine(true); fullscreenSearch.setHint("Pesquisar canal..."); fullscreenSearch.setHintTextColor(0xFF87938B); fullscreenSearch.setTextColor(android.graphics.Color.WHITE); fullscreenSearch.setTextSize(11); fullscreenSearch.setVisibility(View.GONE);
        android.graphics.drawable.GradientDrawable sBg=new android.graphics.drawable.GradientDrawable(); sBg.setColor(0xFF151D18); sBg.setCornerRadius(dp(8)); sBg.setStroke(dp(1),0xFF30483A); fullscreenSearch.setBackground(sBg); fullscreenSearch.setPadding(dp(12),0,dp(12),0);
        android.widget.LinearLayout.LayoutParams slp=new android.widget.LinearLayout.LayoutParams(-1,dp(38)); slp.topMargin=dp(8); slp.bottomMargin=dp(6); content.addView(fullscreenSearch,slp);

        fullscreenChannelList=new androidx.recyclerview.widget.RecyclerView(this); fullscreenChannelList.setLayoutManager(new androidx.recyclerview.widget.LinearLayoutManager(this));
        fullscreenChannels=new TvChannelAdapter(new TvChannelAdapter.Listener(){
            @Override public void onFocus(TvChannel channel){ /* foco apenas visual; sem I/O durante rajada do D-pad */ }
            @Override public void onOpen(TvChannel channel){
                if(channel==null)return;
                history.markRecent(channel.id); returnFocusChannelId=channel.id;
                if(current==null || current.id!=channel.id)showChannel(channel,true);
                // Mantém a lista lateral aberta e já deixa o novo canal confirmado marcado/focado.
                refreshFullscreenRows();
                fullscreenChannelList.postDelayed(()->focusCurrentFullscreenChannel(false,0),90L);
            }
            @Override public void onFavorite(TvChannel channel){history.toggleFavorite(channel.id);fullscreenChannels.refreshFavorite(channel.id);channels.refreshFavorite(channel.id);}
            @Override public boolean isFavorite(TvChannel channel){return history.isFavorite(channel.id);}
        });
        fullscreenChannelList.setAdapter(fullscreenChannels);
        if(current!=null)fullscreenChannels.setSelectedChannel(current.id);
        content.addView(fullscreenChannelList,new android.widget.LinearLayout.LayoutParams(-1,0,1));
        android.widget.TextView foot=new android.widget.TextView(this); foot.setText(""); foot.setVisibility(View.GONE);
        menu.addView(content,new android.widget.LinearLayout.LayoutParams(0,-1,1));

        int menuWidth=(int)(getResources().getDisplayMetrics().widthPixels*0.36f);
        fullscreenMenuLayer.addView(menu,new android.widget.FrameLayout.LayoutParams(menuWidth,-1,android.view.Gravity.START));
        fullscreenLayer.addView(fullscreenMenuLayer,new android.widget.FrameLayout.LayoutParams(-1,-1));

        searchIcon.setOnClickListener(v->{fullscreenSearch.setVisibility(View.VISIBLE);fullscreenSearch.requestFocus();});
        epgIcon.setOnClickListener(v->{hideFullscreenMenu();showFullscreenInfoTemporarily();});
        favIcon.setOnClickListener(v->{fullscreenMode="fav";refreshFullscreenRows();});
        allIcon.setOnClickListener(v->{fullscreenMode="all";refreshFullscreenRows();});
        fullscreenSearch.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int before,int count){refreshFullscreenRows();} public void afterTextChanged(Editable e){}});
        refreshFullscreenRows();
    }

    private void buildNetworkSpeedOverlay(){
        if(fullscreenLayer==null)return;
        android.widget.LinearLayout top=new android.widget.LinearLayout(this);
        top.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        top.setGravity(android.view.Gravity.CENTER_VERTICAL);
        top.setPadding(dp(10),0,dp(10),0);
        android.graphics.drawable.GradientDrawable bg=new android.graphics.drawable.GradientDrawable();
        bg.setColor(0x66080D0A); bg.setCornerRadius(dp(6)); top.setBackground(bg);
        fullscreenClock=new android.widget.TextView(this); fullscreenClock.setTextColor(android.graphics.Color.WHITE); fullscreenClock.setTextSize(12); fullscreenClock.setGravity(android.view.Gravity.CENTER);
        fullscreenNetworkSpeed=null;
        top.addView(fullscreenClock,new android.widget.LinearLayout.LayoutParams(dp(56),-1));
        android.widget.FrameLayout.LayoutParams lp=new android.widget.FrameLayout.LayoutParams(dp(66),dp(30),android.view.Gravity.TOP|android.view.Gravity.END);
        lp.topMargin=dp(10); lp.rightMargin=dp(14); fullscreenLayer.addView(top,lp);
        lastRxBytes=TrafficStats.getTotalRxBytes(); lastRxAt=android.os.SystemClock.elapsedRealtime();
        networkHandler.removeCallbacks(networkTicker); networkHandler.post(networkTicker);
        updateClockAndEpgProgress();
    }

    private void updateNetworkSpeed(){
        if(b==null)return;
        long now=android.os.SystemClock.elapsedRealtime();
        long rx=TrafficStats.getTotalRxBytes();
        if(lastRxBytes>=0 && lastRxAt>0 && rx>=lastRxBytes){
            long dt=Math.max(1L,now-lastRxAt);
            long bytesPerSecond=((rx-lastRxBytes)*1000L)/dt;
            String speedText=formatSpeed(bytesPerSecond);
            if(fullscreenNetworkSpeed!=null) fullscreenNetworkSpeed.setText(speedText);
            if(b!=null && b.mainNetworkSpeed!=null) b.mainNetworkSpeed.setText(speedText);
        }
        lastRxBytes=rx; lastRxAt=now;
    }

    private void updateClockAndEpgProgress(){
        java.text.SimpleDateFormat df=new java.text.SimpleDateFormat("HH:mm",java.util.Locale.getDefault());
        String clockText=df.format(new java.util.Date());
        if(fullscreenClock!=null) fullscreenClock.setText(clockText);
        if(b!=null && b.mainClock!=null) b.mainClock.setText(clockText);
        if(lastEpg!=null && current!=null && lastEpgChannelId==current.id){
            int progress=epgProgress(lastEpg);
            b.epgProgress.setProgress(progress);
            if(fullscreenProgress!=null)fullscreenProgress.setProgress(progress);
            long now=System.currentTimeMillis()/1000L;
            if(lastEpg.nowStop>0 && now>=lastEpg.nowStop){
                // Virou o programa: busca o EPG novo sem trocar/recarregar o canal.
                final long epgRequestChannelId=current.id;
                repo.epg(epgRequestChannelId,new TvRepository.EpgResult(){
                    @Override public void success(TvEpg epg){runOnUiThread(()->{
                        if(current==null || current.id!=epgRequestChannelId)return;
                        lastEpgChannelId=epgRequestChannelId; lastEpg=epg;
                        b.epgNow.setText((epg.nowTime.isEmpty()?"":epg.nowTime+"  •  ")+epg.nowTitle);
                        b.epgNext.setText((epg.nextTime.isEmpty()?"":epg.nextTime+"  •  ")+epg.nextTitle);
                        syncFullscreenEpg(epg,epgProgress(epg));
                    });}
                    @Override public void error(String message){}
                });
            }
        }
    }

    private void showFullscreenInfoTemporarily(){
        if(!fullscreen || fullscreenInfoPanel==null || fullscreenMenuVisible)return;
        infoHideHandler.removeCallbacks(fullscreenInfoAutoHide);
        fullscreenInfoPanel.setAlpha(1f); fullscreenInfoPanel.setVisibility(View.VISIBLE); fullscreenInfoPanel.bringToFront(); fullscreenInfoVisible=true;
        infoHideHandler.postDelayed(fullscreenInfoAutoHide,3500L);
    }

    private String formatSpeed(long bps){
        if(bps<1024)return bps+"B/S";
        if(bps<1024L*1024L)return (bps/1024L)+"KB/S";
        return String.format(java.util.Locale.US,"%.1fMB/S",bps/(1024f*1024f));
    }

    private android.widget.TextView fullscreenRail(String text){
        android.widget.TextView t=new android.widget.TextView(this); t.setText(text); t.setTextColor(android.graphics.Color.WHITE); t.setTextSize(24); t.setGravity(android.view.Gravity.CENTER); t.setFocusable(true); t.setClickable(true);
        t.setOnFocusChangeListener((v,has)->{((android.widget.TextView)v).setTextColor(has?0xFF29E76F:android.graphics.Color.WHITE); v.setBackgroundColor(has?0x3329E76F:0x00000000);});
        return t;
    }

    private void refreshFullscreenRows(){
        if(fullscreenChannels==null)return;
        List<TvChannel> base;
        if("fav".equals(fullscreenMode))base=history.filterFavorites(allChannels);
        else if("recent".equals(fullscreenMode))base=history.filterRecents(allChannels);
        else base=new ArrayList<>(allChannels);
        fullscreenChannels.setRows(base);
        for(TvChannel c:base){String cached=rowEpgCache.get(c.id);if(cached!=null)fullscreenChannels.setEpgText(c.id,cached);}
        if(current!=null)fullscreenChannels.setSelectedChannel(current.id);
        if(fullscreenSearch!=null)fullscreenChannels.filter(fullscreenSearch.getText().toString());
    }

    private android.widget.TextView fullscreenFilter(String text,boolean selected){
        android.widget.TextView t=new android.widget.TextView(this);
        t.setText(text);t.setTextSize(11);t.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);
        t.setGravity(android.view.Gravity.CENTER);t.setFocusable(true);t.setClickable(true);
        styleFullscreenFilter(t,selected);return t;
    }
    private void styleFullscreenFilter(android.widget.TextView t,boolean selected){
        android.graphics.drawable.GradientDrawable bg=new android.graphics.drawable.GradientDrawable();
        bg.setCornerRadius(dp(20));
        if(selected){bg.setColor(0xFF29E76F);t.setTextColor(android.graphics.Color.BLACK);}else{bg.setColor(0x33131C17);bg.setStroke(dp(1),0xFF294134);t.setTextColor(android.graphics.Color.WHITE);}
        t.setBackground(bg);
    }
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}

    private void toggleFullscreenMenu(){
        if(!fullscreen)return;
        if(fullscreenMenuVisible)hideFullscreenMenu();else showFullscreenMenu();
    }
    private void showFullscreenMenu(){
        if(fullscreenMenuLayer==null)return;
        fullscreenMenuVisible=true;
        infoHideHandler.removeCallbacks(fullscreenInfoAutoHide);
        if(fullscreenInfoPanel!=null)fullscreenInfoPanel.setVisibility(View.GONE);
        refreshFullscreenRows();
        fullscreenMenuLayer.setVisibility(View.VISIBLE);
        fullscreenMenuLayer.bringToFront();
        // Abre a lista exatamente no canal que já está tocando e deixa ele marcado/focado.
        focusCurrentFullscreenChannel(false,0);
    }

    private void focusCurrentFullscreenChannel(boolean moveRelative,int delta){
        if(fullscreenChannelList==null || fullscreenChannels==null)return;
        long currentId=current==null?-1L:current.id;
        int pos=fullscreenChannels.positionOf(currentId);
        if(pos<0)pos=0;
        if(moveRelative && fullscreenChannels.getItemCount()>0){
            pos=(pos+delta)%fullscreenChannels.getItemCount();
            if(pos<0)pos+=fullscreenChannels.getItemCount();
        }
        final int target=Math.max(0,Math.min(pos,Math.max(0,fullscreenChannels.getItemCount()-1)));
        fullscreenChannelList.scrollToPosition(target);
        fullscreenChannelList.postDelayed(()->{
            androidx.recyclerview.widget.RecyclerView.ViewHolder vh=fullscreenChannelList.findViewHolderForAdapterPosition(target);
            if(vh!=null)vh.itemView.requestFocus();
            else {
                fullscreenChannelList.scrollToPosition(target);
                fullscreenChannelList.postDelayed(()->{
                    androidx.recyclerview.widget.RecyclerView.ViewHolder vh2=fullscreenChannelList.findViewHolderForAdapterPosition(target);
                    if(vh2!=null)vh2.itemView.requestFocus();
                },80L);
            }
        },60L);
    }

    private void openFullscreenMenuAndMove(int delta){
        if(!fullscreen)return;
        if(!fullscreenMenuVisible){
            showFullscreenMenu();
            // Primeiro toque em cima/baixo abre a lista já no canal atual e move apenas o foco.
            fullscreenChannelList.postDelayed(()->focusCurrentFullscreenChannel(true,delta),100L);
        }
    }
    private void hideFullscreenMenu(){
        fullscreenMenuVisible=false;
        if(fullscreenMenuLayer!=null)fullscreenMenuLayer.setVisibility(View.GONE);
        b.previewPlayer.requestFocus();
        showFullscreenInfoTemporarily();
    }

    private void exitFullscreen(){
        if(!fullscreen)return;
        if(fullscreenMenuVisible){hideFullscreenMenu();return;}
        // Ao voltar da tela cheia, a prioridade de foco deve ser a lista de canais.
        // Isso evita o estado em que o preview fica com o foco e o controle parece "travado".
        returningFromFullscreen=true;
        fullscreen=false;
        if(fullscreenLayer!=null){
            ViewGroup currentParent=(ViewGroup)b.previewPlayer.getParent();
            if(currentParent!=null)currentParent.removeView(b.previewPlayer);
            ViewGroup loadingParent=(ViewGroup)b.channelLoadingOverlay.getParent();
            if(loadingParent!=null)loadingParent.removeView(b.channelLoadingOverlay);
            ViewGroup layerParent=(ViewGroup)fullscreenLayer.getParent();
            if(layerParent!=null)layerParent.removeView(fullscreenLayer);
        }
        fullscreenLayer=null; fullscreenMenuLayer=null; fullscreenInfoPanel=null; fullscreenChannelList=null; fullscreenChannels=null; fullscreenSearch=null;
        networkHandler.removeCallbacks(networkTicker); uiTickerHandler.removeCallbacks(uiTicker); infoHideHandler.removeCallbacks(fullscreenInfoAutoHide); lastRxBytes=-1L; lastRxAt=-1L; fullscreenNetworkSpeed=null; fullscreenClock=null; fullscreenDiagnostic=null; fullscreenInfoVisible=false;
        fullscreenLogo=null; fullscreenNumber=null; fullscreenName=null; fullscreenNow=null; fullscreenNext=null; fullscreenProgress=null;
        if(previewOriginalParent!=null){
            int index=Math.max(0,Math.min(previewOriginalIndex,previewOriginalParent.getChildCount()));
            previewOriginalParent.addView(b.previewPlayer,index,previewOriginalLayoutParams);
        }
        if(loadingOriginalParent!=null){
            int li=Math.max(0,Math.min(loadingOriginalIndex,loadingOriginalParent.getChildCount()));
            loadingOriginalParent.addView(b.channelLoadingOverlay,li,loadingOriginalLayoutParams);
        }
        b.previewPlayer.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        b.previewPlayer.clearFocus();
        b.channelList.setFocusable(true);
        b.channelList.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS);
        if(previewPlayer!=null)previewPlayer.play();
        // Restaura o canal atual com algumas tentativas curtas porque o RecyclerView pode
        // ainda estar recalculando o layout depois que o PlayerView volta para o preview.
        b.channelList.postDelayed(this::restoreChannelFocus,60);
    }

    @Override public boolean onKeyDown(int keyCode,KeyEvent event){
        if(fullscreen && !fullscreenMenuVisible){
            // Não troca o stream só por passar no controle: abre a lista no canal atual e move o foco.
            // A troca só acontece ao confirmar com OK, evitando o crash visto no TV Box.
            if(keyCode==KeyEvent.KEYCODE_DPAD_UP || keyCode==KeyEvent.KEYCODE_CHANNEL_UP){openFullscreenMenuAndMove(-1);return true;}
            if(keyCode==KeyEvent.KEYCODE_DPAD_DOWN || keyCode==KeyEvent.KEYCODE_CHANNEL_DOWN){openFullscreenMenuAndMove(1);return true;}
        }
        if(keyCode==KeyEvent.KEYCODE_BACK && fullscreen){
            if(fullscreenMenuVisible){hideFullscreenMenu();return true;}
            exitFullscreen();return true;
        }
        if(keyCode==KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE&&current!=null){
            if(previewPlayer!=null){if(previewPlayer.isPlaying())previewPlayer.pause();else previewPlayer.play();}
            return true;
        }
        return super.onKeyDown(keyCode,event);
    }
    @Override protected void onStop(){
        appWentToBackground=true;
        if(previewPlayer!=null)previewPlayer.pause();
        super.onStop();
    }
    @Override protected void onStart(){
        super.onStart();
        if(appWentToBackground){
            appWentToBackground=false;
            // Voltar de Configurações/Filmes/Séries não deve destruir e carregar a lista de novo.
            // Mantemos catálogo, posição e foco; só reconsultamos se realmente não houver canais em memória.
            if(allChannels.isEmpty()) loadChannels(currentCategoryId,currentCategoryName);
            else {
                restoreRowsWithoutChangingChannel();
                if(previewPlayer!=null&&current!=null&&previewPlayer.getMediaItemCount()>0)previewPlayer.play();
                b.channelList.postDelayed(this::restoreChannelFocus,80);
            }
        } else if(previewPlayer!=null&&current!=null&&previewPlayer.getMediaItemCount()>0){
            previewPlayer.play();
        }
    }

    private void restoreRowsWithoutChangingChannel(){
        if(mode==Mode.FAVORITES){
            channels.setSectionLabel("FAVORITOS");
            channels.setRows(history.filterFavorites(allChannels));
        }else if(mode==Mode.RECENTS){
            channels.setSectionLabel("RECENTES");
            channels.setRows(history.filterRecents(allChannels));
        }else if(currentCategoryId.isEmpty()){
            channels.setSectionLabel("TV AO VIVO");
            channels.setRows(allChannels);
        }
        updateTotal();
        if(current!=null)channels.setSelectedChannel(current.id);
    }

    @Override protected void onResume(){
        super.onResume();
        if(returningFromFullscreen){
            b.channelList.postDelayed(this::restoreChannelFocus,80);
        }
    }
    private void restoreChannelFocus(){
        long id=returnFocusChannelId>0?returnFocusChannelId:(current==null?-1L:current.id);
        int pos=channels.positionOf(id);
        if(pos<0){
            b.channelList.requestFocus();
            returningFromFullscreen=false;
            return;
        }
        channels.setSelectedChannel(id);
        b.channelList.stopScroll();
        b.channelList.scrollToPosition(pos);
        requestChannelFocusAt(pos,0);
    }

    private void requestChannelFocusAt(int pos,int attempt){
        if(isFinishing() || isDestroyed())return;
        androidx.recyclerview.widget.RecyclerView.ViewHolder vh=b.channelList.findViewHolderForAdapterPosition(pos);
        if(vh!=null && vh.itemView.requestFocus()){
            returningFromFullscreen=false;
            return;
        }
        if(attempt>=4){
            b.channelList.requestFocus();
            returningFromFullscreen=false;
            return;
        }
        b.channelList.scrollToPosition(pos);
        long delay=60L+(attempt*70L);
        b.channelList.postDelayed(()->requestChannelFocusAt(pos,attempt+1),delay);
    }
    @Override protected void onDestroy(){networkHandler.removeCallbacks(networkTicker);uiTickerHandler.removeCallbacks(uiTicker);infoHideHandler.removeCallbacks(fullscreenInfoAutoHide);if(pendingPreview!=null)previewHandler.removeCallbacks(pendingPreview);if(previewPlayer!=null)previewPlayer.release();super.onDestroy();}
}
