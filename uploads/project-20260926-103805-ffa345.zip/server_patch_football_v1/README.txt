GREENPLAY FOOTBALL V1

1) Copie api/dtlive/football/index.php para:
   /var/www/greenplay/public_html/api/dtlive/football/index.php

2) Copie config/football.php.example para:
   /var/www/greenplay/public_html/config/football.php

3) Crie conta gratuita em https://dashboard.api-football.com/
   e coloque sua API key em config/football.php.

4) Crie cache:
   mkdir -p /var/www/greenplay/public_html/cache/football
   chown -R www-data:www-data /var/www/greenplay/public_html/cache/football
   chmod 775 /var/www/greenplay/public_html/cache/football

Plano grátis: 100 requests/dia. O endpoint usa cache compartilhado de 20 min para hoje e 6h para outras datas.
