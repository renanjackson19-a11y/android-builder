GreenPlay Android Nativo 5.28.14 (52814)

Correção de categorias sem limite:
- exibe todas as categorias reais de filmes e séries da fonte;
- snapshot inicial não é mais confundido com catálogo completo;
- nomes aparecem imediatamente, conteúdo das linhas completa em paralelo;
- categorias recebem marcador Filmes/Séries somente quando o nome original não informa o tipo;
- Home permanente continua sem recarregar ao tocar em Início.

Base: 5.28.13.
