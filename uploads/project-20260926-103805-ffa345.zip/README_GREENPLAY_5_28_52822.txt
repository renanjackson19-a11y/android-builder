GreenPlay 5.28.22

- Novo ícone Filmes enviado pelo usuário aplicado em Filmes.
- Ícone convertido para PNG RGBA com transparência real, sem retângulo preto.
- Mantidos TV ao vivo, Séries, Futebol e GreenShorts com os ícones já aplicados.
- Mantida a separação automática de Reels Shorts / ReelShort / Reel Shorts / RelShort para GreenShorts.
- ZIP completo do projeto Android, não patch.
