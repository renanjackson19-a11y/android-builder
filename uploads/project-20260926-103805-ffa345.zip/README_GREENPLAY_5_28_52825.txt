GreenPlay 5.28.25

Correções desta entrega:
- Topo fixo: TV | Futebol | Filmes | Séries | GreenShorts.
- Os 5 ícones ocupam exatamente a mesma caixa visual.
- Futebol permanece visível e abre a tela de Jogos.
- Filmes, Séries e GreenShorts agora usam snapshot de catálogo preparado antes da troca de tela.
- Não mostra mais categorias chegando uma por uma nem a página vazia “Procurando Reels Shorts”.
- GreenShorts reconhece Reels Shorts / ReelShort / RelShort e tenta também o section_list quando get_category não expõe a pasta.
- Catálogo completo é preparado em segundo plano e persistido por servidor.
- Busca de categorias usa paralelismo controlado para reduzir espera sem limitar itens.
- A abertura da Home não fica bloqueada esperando paginar todos os canais de TV.
