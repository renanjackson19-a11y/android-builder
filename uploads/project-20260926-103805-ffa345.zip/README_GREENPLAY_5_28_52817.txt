GreenPlay Android Nativo 5.28.17 / 52817

Correções:
- remove estado visual feio de categoria com apenas título + reticências;
- categoria entra na Home somente com os cards carregados;
- até 8 categorias carregadas em paralelo;
- cache completo das categorias persiste para reabertura rápida;
- mantém todas as categorias, sem limite.
