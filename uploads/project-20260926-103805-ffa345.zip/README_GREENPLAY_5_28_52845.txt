GreenPlay 5.28.45

- GreenShorts continua na barra superior.
- Filtro estrito por category_id: filmes comuns não entram na aba GreenShorts.
- Itens sem category_id só entram se o próprio item identificar categoria Shorts.
- O mesmo filtro vale para o carrossel destaque e para a grade.
- Mantém conteúdos soltos, sem subcategorias.
- Mantém a arte GreenShorts do usuário como fallback de capa.
- Não altera Filmes, Séries, TV ou Futebol.
