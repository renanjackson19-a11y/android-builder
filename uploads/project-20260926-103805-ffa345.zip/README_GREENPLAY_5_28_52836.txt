GreenPlay 5.28.36
Catalogo completo por provedor.
Home com retry de categorias.
Categorias grandes paginadas em blocos de 120.
Cache separado por usuario e provedor.
Nao marca resposta parcial como catalogo completo.
Mantem correcoes de retorno da Home/Perfil da 5.28.34.
