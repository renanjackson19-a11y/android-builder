GreenPlay 5.28.32

- GreenShorts no celular: quadro vertical grande, centralizado e sem zoom total agressivo; detecta fonte vertical dentro de canvas 16:9.
- Player: controles inferiores redesenhados, responsivos e sem botão cortado/quadrado desproporcional.
- Filmes e séries: modo Completo continua como padrão, sem esticar/cortar imagem.
- Retorno do player: preserva aba/tela/scroll anterior em vez de cair no Início.
- Base: 5.28.31 catálogo completo.
