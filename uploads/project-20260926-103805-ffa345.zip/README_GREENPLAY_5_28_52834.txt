GreenPlay 5.28.34

Correcoes:
- Ao abrir Perfil > Alterar servidor e voltar sem trocar de fonte, a Home pronta e preservada.
- Categorias da Home continuam terminando de montar em segundo plano sem sumir ao visitar Perfil/Favoritos/Downloads.
- Mantem a correcao de memoria da 5.28.33 e o player/retorno da 5.28.32.
