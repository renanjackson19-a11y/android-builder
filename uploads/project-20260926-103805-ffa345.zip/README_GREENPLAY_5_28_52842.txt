GreenPlay 5.28.42

- GreenShorts é detectado dinamicamente por provedor.
- A aba GreenShorts só aparece quando o catálogo ativo realmente contém ReelShort/Reels Shorts/GreenShorts.
- Provedores sem Shorts não mostram a aba, igual à regra da TV ao vivo.
- Regra é provider-scoped e funciona também para provedores adicionados no futuro.
- Todos os nomes ReelShort/Reels Shorts são apresentados como GreenShorts.
- Cards GreenShorts sem capa válida mantêm placeholder GreenShorts em vez de card vazio.
- Cache de catálogo renovado para reavaliar a presença de GreenShorts por provedor.
