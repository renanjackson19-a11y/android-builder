GreenPlay 5.28.54
- GreenShorts agora aparece também no menu superior do modo TV/TV Box.
- GreenShorts fica entre Séries e Kids.
- Foco do controle remoto incluído no item GreenShorts.
- Seleção do GreenShorts fica destacada no menu TV.
- Ao entrar, carrega o catálogo GreenShorts completo em grade para TV.
- Mantém as correções da 5.28.53 no celular e o player vertical.
