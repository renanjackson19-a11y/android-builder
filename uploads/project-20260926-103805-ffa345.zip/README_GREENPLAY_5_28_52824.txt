GreenPlay 5.28.24

Correções desta entrega:
- Topo: TV | Futebol | Filmes | Séries | GreenShorts.
- Cinco ícones com a mesma escala visual e sem fundo preto.
- Atalho Futebol abre a página de Jogos.
- Mantida a separação automática de Reels Shorts em GreenShorts.
