GreenPlay 5.28.39

- Corrige cache antigo marcando preview como categoria completa.
- Novo schema catalog52839 por usuário+provedor.
- Só considera categoria completa quando quantidade carregada >= total real.
- Sempre busca o restante quando a Home tem apenas preview.
- Paginação em blocos de 120 com aliases page/offset/start/skip/from.
- TV mescla preview cacheado com páginas novas sem perder os primeiros itens.
- Mantém contagem por categoria e Home preservada ao voltar do Perfil.
