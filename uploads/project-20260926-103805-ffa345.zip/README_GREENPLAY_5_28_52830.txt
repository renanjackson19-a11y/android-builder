GreenPlay 5.28.30
- Corrige falha de compilacao em MainActivity.java:1994 (JSONArray capturado por lambda depois de reatribuicao).
- Mantem GreenShorts em portrait no celular.
- Mantem protecao da TV contra VOD misturado.
