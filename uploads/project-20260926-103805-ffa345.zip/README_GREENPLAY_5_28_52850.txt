GreenPlay 5.28.50

- GreenShorts: capas sem zoom/corte.
- Imagens centralizadas preservando a proporcao original.
- Ajuste aplicado ao destaque e ao grid/listas do GreenShorts.
- Filmes e series normais continuam com o comportamento anterior.
