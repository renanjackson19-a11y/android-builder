GreenPlay 5.28.47

- GreenShorts agora é um catálogo global do YouTube administrado pelo painel.
- Não usa mais ReelShort/Shorts dos provedores IPTV.
- Busca /api/dtlive/greenshorts e mostra somente vídeos sincronizados do YouTube.
- Canal inicial: Flor da Vida.
- Reprodução dentro do GreenPlay via player incorporado oficial do YouTube.
- Sem download/extracao de MP4 do YouTube.
- GreenShorts continua na barra superior em todos os provedores.
