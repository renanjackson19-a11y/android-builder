GreenPlay 5.28.21

- Ícones enviados pelo usuário aplicados nas categorias correspondentes.
- TV usa o novo logo TV ao vivo.
- Séries usa o novo logo Séries.
- Futebol usa o novo logo Futebol.
- GreenShorts corrigido para PNG RGBA com fundo transparente.
- Os quatro arquivos foram tratados como PNG transparente para não aparecer retângulo preto.
- Filmes foi mantido como estava, pois não foi enviado um novo ícone nesta etapa.
- Mantida a separação automática da categoria Reels Shorts / ReelShort / RelShort.
