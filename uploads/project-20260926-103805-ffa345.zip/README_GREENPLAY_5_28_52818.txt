GreenPlay Android Nativo 5.28.18 / 52818

Correções:
- Voltar dentro de uma categoria restaura exatamente a tela anterior (Home/Filmes/Séries) e a mesma posição;
- categoria não é mais confundida com Início e não abre o diálogo “Sair do aplicativo?” enquanto ainda existe uma tela anterior;
- abrir detalhe e voltar mantém a categoria; um segundo Voltar retorna à tela de categorias anterior;
- Home não é reconstruída ao retornar: o host anterior fica preservado em memória;
- catálogo continua sem limite de categorias ou itens e continua separado por provedor;
- mantém até 8 categorias em paralelo para completar a fonte sem limitar o total.
