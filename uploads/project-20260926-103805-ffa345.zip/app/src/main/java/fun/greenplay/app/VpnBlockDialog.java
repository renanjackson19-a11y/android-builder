package fun.greenplay.app;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.LinearLayout;
import android.widget.TextView;

final class VpnBlockDialog {
 private VpnBlockDialog(){}

 static int dp(Activity a,int n){return (int)(n*a.getResources().getDisplayMetrics().density+.5f);}

 static GradientDrawable solid(Activity a,int color,int radius){
  GradientDrawable g=new GradientDrawable();
  g.setColor(color);g.setCornerRadius(dp(a,radius));
  return g;
 }

 static GradientDrawable outlined(Activity a,int color,int radius,int strokeColor){
  GradientDrawable g=solid(a,color,radius);
  g.setStroke(dp(a,1),strokeColor);
  return g;
 }

 static StateListDrawable secondaryBg(Activity a){
  StateListDrawable s=new StateListDrawable();
  GradientDrawable focus=outlined(a,0xff311825,16,0xffe02080);focus.setStroke(dp(a,2),0xffe02080);
  GradientDrawable normal=outlined(a,0xff191115,16,0xff423039);
  s.addState(new int[]{android.R.attr.state_focused},focus);
  s.addState(new int[]{android.R.attr.state_pressed},focus);
  s.addState(new int[]{},normal);
  return s;
 }

 static StateListDrawable primaryBg(Activity a){
  StateListDrawable s=new StateListDrawable();
  GradientDrawable focus=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0xfff5499f,0xfff678b7});
  focus.setCornerRadius(dp(a,16));focus.setStroke(dp(a,2),Color.WHITE);
  GradientDrawable normal=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0xffdf2080,0xffe94999});
  normal.setCornerRadius(dp(a,16));
  s.addState(new int[]{android.R.attr.state_focused},focus);
  s.addState(new int[]{android.R.attr.state_pressed},focus);
  s.addState(new int[]{},normal);
  return s;
 }

 static TextView text(Activity a,String value,float sp,int color,boolean bold){
  TextView v=new TextView(a);v.setText(value);v.setTextSize(sp);v.setTextColor(color);
  if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
  v.setIncludeFontPadding(false);
  return v;
 }

 static TextView action(Activity a,String value,boolean primary){
  TextView b=text(a,value,13,primary?0xff11040a:0xffe02080,true);
  b.setGravity(Gravity.CENTER);b.setFocusable(true);b.setClickable(true);
  b.setPadding(dp(a,14),0,dp(a,14),0);
  b.setBackground(primary?primaryBg(a):secondaryBg(a));
  return b;
 }

 static Dialog show(Activity a,String message,boolean retryMode,Runnable retry,Runnable exit){
  final Dialog d=new Dialog(a);
  d.requestWindowFeature(Window.FEATURE_NO_TITLE);
  d.setCancelable(false);

  final boolean tv=DeviceCompat.isTelevisionDevice(a);

  LinearLayout card=new LinearLayout(a);
  card.setOrientation(LinearLayout.VERTICAL);
  card.setGravity(Gravity.CENTER_HORIZONTAL);
  card.setPadding(dp(a,tv?30:22),dp(a,tv?24:20),dp(a,tv?30:22),dp(a,tv?24:20));
  GradientDrawable cardBg=outlined(a,0xff170d12,tv?22:20,0xff402a35);
  card.setBackground(cardBg);
  if(Build.VERSION.SDK_INT>=21)card.setElevation(dp(a,18));

  View accent=new View(a);
  accent.setBackground(solid(a,0xffe02080,2));
  LinearLayout.LayoutParams acp=new LinearLayout.LayoutParams(dp(a,tv?58:46),dp(a,3));
  acp.setMargins(0,0,0,dp(a,13));
  card.addView(accent,acp);

  TextView kicker=text(a,"PROTEÇÃO DE REDE",tv?10:9.5f,0xffe02080,true);
  kicker.setLetterSpacing(.14f);kicker.setGravity(Gravity.CENTER);kicker.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
  card.addView(kicker,new LinearLayout.LayoutParams(-1,-2));

  TextView title=text(a,"VPN detectada",tv?24:21,Color.WHITE,true);
  title.setGravity(Gravity.CENTER);title.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
  LinearLayout.LayoutParams tlp=new LinearLayout.LayoutParams(-1,-2);tlp.setMargins(0,dp(a,7),0,0);
  card.addView(title,tlp);

  TextView body=text(a,message,tv?15:14.5f,0xffc8bcc4,false);
  body.setGravity(Gravity.CENTER);body.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);body.setLineSpacing(0,1.10f);
  LinearLayout.LayoutParams blp=new LinearLayout.LayoutParams(-1,-2);blp.setMargins(0,dp(a,12),0,0);
  card.addView(body,blp);

  LinearLayout buttons=new LinearLayout(a);
  buttons.setGravity(Gravity.CENTER);
  LinearLayout.LayoutParams bwrap=new LinearLayout.LayoutParams(-1,-2);bwrap.setMargins(0,dp(a,tv?21:18),0,0);

  if(retryMode){
   TextView out=action(a,"SAIR",false);
   TextView again=action(a,"TENTAR NOVAMENTE",true);
   LinearLayout.LayoutParams olp=new LinearLayout.LayoutParams(0,dp(a,tv?52:48),.38f);olp.setMargins(0,0,dp(a,10),0);
   LinearLayout.LayoutParams alp=new LinearLayout.LayoutParams(0,dp(a,tv?52:48),.62f);
   buttons.addView(out,olp);buttons.addView(again,alp);
   out.setOnClickListener(v->{d.dismiss();if(exit!=null)exit.run();});
   again.setOnClickListener(v->{d.dismiss();if(retry!=null)retry.run();});
   again.requestFocus();
  }else{
   TextView ok=action(a,"OK",true);
   LinearLayout.LayoutParams olp=new LinearLayout.LayoutParams(tv?dp(a,190):dp(a,150),dp(a,tv?52:48));
   buttons.addView(ok,olp);
   ok.setOnClickListener(v->{d.dismiss();if(exit!=null)exit.run();});
   ok.requestFocus();
  }
  card.addView(buttons,bwrap);

  d.setContentView(card);

  Window w=d.getWindow();
  if(w!=null){
   w.setBackgroundDrawableResource(android.R.color.transparent);
   w.setGravity(Gravity.CENTER);
   w.setWindowAnimations(0);
   WindowManager.LayoutParams lp=new WindowManager.LayoutParams();
   lp.copyFrom(w.getAttributes());
   int screen=a.getResources().getDisplayMetrics().widthPixels;
   int target=Math.min(screen-dp(a,tv?100:36),dp(a,tv?700:520));
   lp.width=Math.max(dp(a,280),target);
   lp.height=WindowManager.LayoutParams.WRAP_CONTENT;
   lp.gravity=Gravity.CENTER;
   lp.x=0;lp.y=0;
   lp.dimAmount=.68f;
   lp.windowAnimations=0;
   w.setAttributes(lp);
   w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
  }

  // Important: no horizontal/vertical translation at any point.
  // The modal is born in the exact center and only uses a subtle center scale + fade.
  card.setTranslationX(0f);card.setTranslationY(0f);
  card.setAlpha(0f);card.setScaleX(.94f);card.setScaleY(.94f);
  d.setOnShowListener(x->card.post(()->{
   card.setPivotX(card.getWidth()/2f);card.setPivotY(card.getHeight()/2f);
   card.setTranslationX(0f);card.setTranslationY(0f);
   card.animate().cancel();
   card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(170)
    .setInterpolator(new DecelerateInterpolator()).start();
  }));
  d.show();
  return d;
 }
}
