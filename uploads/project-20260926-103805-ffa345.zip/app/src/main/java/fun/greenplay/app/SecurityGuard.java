package fun.greenplay.app;
import android.os.Debug;
import android.os.Build;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.webkit.WebView;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Locale;
import java.net.NetworkInterface;
import java.util.Enumeration;
final class SecurityGuard{
 private SecurityGuard(){}
 static void hardenWebView(){try{WebView.setWebContentsDebuggingEnabled(false);}catch(Throwable ignored){}}
 static boolean vpnActive(Context context){
  if(vpnInterfaceActive())return true;
  if(context==null)return false;
  try{
   ConnectivityManager cm=(ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
   if(cm!=null){
    if(Build.VERSION.SDK_INT>=23){
     Network active=cm.getActiveNetwork();
     if(active!=null){NetworkCapabilities caps=cm.getNetworkCapabilities(active);if(caps!=null&&caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN))return true;}
     Network[] all=cm.getAllNetworks();
     if(all!=null)for(Network n:all){NetworkCapabilities caps=cm.getNetworkCapabilities(n);if(caps!=null&&caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN))return true;}
    }
    try{NetworkInfo legacy=cm.getNetworkInfo(ConnectivityManager.TYPE_VPN);if(legacy!=null&&legacy.isConnectedOrConnecting())return true;}catch(Throwable ignored){}
   }
  }catch(Throwable ignored){}
  return vpnInterfaceActive();
 }
 static boolean vpnInterfaceActive(){
  try{
   Enumeration<NetworkInterface> all=NetworkInterface.getNetworkInterfaces();
   if(all==null)return false;
   while(all.hasMoreElements()){
    NetworkInterface ni=all.nextElement();
    if(ni==null)continue;
    try{if(!ni.isUp()||ni.isLoopback())continue;}catch(Throwable ignored){}
    String n=ni.getName();if(n==null)continue;n=n.toLowerCase(Locale.US);
    if(n.startsWith("tun")||n.startsWith("tap")||n.startsWith("wg")||n.startsWith("vpn")||n.contains("ipsec"))return true;
   }
  }catch(Throwable ignored){}
  return false;
 }
 static boolean tamperRisk(){
  try{if(Debug.isDebuggerConnected()||Debug.waitingForDebugger())return true;}catch(Throwable ignored){}
  try(BufferedReader r=new BufferedReader(new FileReader("/proc/self/maps"))){String x;while((x=r.readLine())!=null){String z=x.toLowerCase(Locale.US);if(z.contains("frida")||z.contains("xposed")||z.contains("lsposed")||z.contains("substrate"))return true;}}catch(Throwable ignored){}
  return false;
 }
}
