package fun.greenplay.app;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

final class SecretStore{
 private static final String ALIAS="gp_media_v1";
 private SecretStore(){}
 private static SecretKey key() throws Exception{
  KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
  java.security.Key k=ks.getKey(ALIAS,null);if(k instanceof SecretKey)return (SecretKey)k;
  KeyGenerator g=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
  g.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setRandomizedEncryptionRequired(true).build());
  return g.generateKey();
 }
 static String encrypt(String raw){if(raw==null||raw.isEmpty())return "";try{Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());byte[]iv=c.getIV(),ct=c.doFinal(raw.getBytes(StandardCharsets.UTF_8));byte[]out=new byte[1+iv.length+ct.length];out[0]=(byte)iv.length;System.arraycopy(iv,0,out,1,iv.length);System.arraycopy(ct,0,out,1+iv.length,ct.length);return Base64.encodeToString(out,Base64.NO_WRAP);}catch(Throwable ignored){return "";}}
 static String decrypt(String blob){if(blob==null||blob.isEmpty())return "";try{byte[]in=Base64.decode(blob,Base64.NO_WRAP);int n=in[0]&0xff;if(n<8||1+n>=in.length)return "";byte[]iv=new byte[n],ct=new byte[in.length-1-n];System.arraycopy(in,1,iv,0,n);System.arraycopy(in,1+n,ct,0,ct.length);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,iv));return new String(c.doFinal(ct),StandardCharsets.UTF_8);}catch(Throwable ignored){return "";}}
}
