-keepattributes Signature,InnerClasses,EnclosingMethod,*Annotation*
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keepnames class fun.greenplay.app.MainActivity
-keepnames class fun.greenplay.app.PlayerActivity
-keepnames class fun.greenplay.app.YouTubePlayerActivity
-keepnames class fun.greenplay.app.OfflineDownloadService
-keep class fun.greenplay.app.CastOptionsProvider { *; }
-renamesourcefileattribute SourceFile
-assumenosideeffects class android.util.Log {
    public static *** v(...);
    public static *** d(...);
    public static *** i(...);
    public static *** w(...);
    public static *** e(...);
}
