GreenPlay Android Nativo 5.28.15 (52815)

- Barra superior da Home: somente TV | Filmes | Séries.
- Usa os três ícones fornecidos pelo usuário sem gerar artes substitutas.
- Turcas, Doramas, Legendadas e demais pastas permanecem dentro do catálogo correspondente.
- Nenhum limite novo de categorias foi adicionado.
- TMDB/EPG/player não foram alterados nesta versão.
