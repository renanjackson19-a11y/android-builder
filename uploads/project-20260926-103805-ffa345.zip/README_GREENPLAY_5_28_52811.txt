GreenPlay Android Nativo 5.28.11 (52811)

Base: 5.28.10 / 52810.

Correção:
- se a Home recebe um card sem capa mas content_detail já consegue achar imagem TMDB, o aplicativo resolve e baixa essa imagem durante a tela de sincronização;
- a Home só abre depois do lote crítico (ou timeout de segurança);
- primeiros 4 cards por seção entram no preparo;
- nenhuma arte do provedor é usada para Filmes/Séries.
