GREENPLAY 5.27 — HOTFIX 52703

Base atual: GreenPlay 5.27 / versionCode 52702.
Entrega: versionName 5.27 / versionCode 52703.

Correções desta build:
- Envia explicitamente movie/series ao carregar cada categoria; IDs M3U altos não podem mais trocar o tipo do conteúdo.
- Usa o category_id real da fonte, sem depender do offset numérico legado para distinguir Séries.
- Renova o snapshot persistente do catálogo para eliminar itens classificados pela regra antiga.
- Mantém todas as correções anteriores de catálogo, TMDB, logos e carregamento.

Usar junto com o PATCH v131.9 SERIES_TYPE_SAFE desta entrega.
