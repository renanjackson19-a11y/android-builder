GreenPlay 5.28.38

- Corrige categorias presas no primeiro lote.
- full_catalog=0; sem limit=5000.
- all=1 apenas como sinal do catálogo completo paginado do painel.
- TV atualiza a grade a cada página recebida sem voltar ao topo.
- Mantém Home preservada ao voltar do Perfil.
- Mostra quantidade total nas categorias de Filmes/Séries quando o total real está disponível.
