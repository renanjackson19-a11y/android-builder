GreenPlay 5.28.31

- Sincroniza todas as categorias da fonte antes de liberar a Home.
- Remove a tela intermediária “Carregando conteúdo completo...” ao abrir categoria.
- Categorias grandes usam paginação completa (page/page_no/offset + total quando disponível).
- IDs de categoria podem ser numéricos ou texto.
- Categorias adultas também entram na sincronização; a exibição continua protegida pelo PIN/controle adulto.
- Grid no celular cria cards em lotes conforme o scroll para suportar milhares de itens sem travar.
- GreenShorts, Futebol, TV sem VOD misturado e Shorts em pé no celular mantidos.

Build debug desta revisão validada no GitHub Actions com sucesso.
