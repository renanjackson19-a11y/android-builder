GreenPlay 5.28.51

- Mantém a reprodução incorporada atual funcionando.
- Oculta visualmente o cabeçalho externo no topo do vídeo.
- Oculta visualmente a faixa inferior externa com compartilhar, miniatura e marca.
- Mantém os controles próprios do GreenPlay por cima.
- Não altera o catálogo nem a lógica das capas da 5.28.50.
