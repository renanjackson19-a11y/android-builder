GreenPlay Android Nativo 5.28.9 (52809)

Gerado diretamente sobre o arquivo base enviado:
GreenPlay_Android_Nativo_5_28_52801_TMDB_INICIAL_COMPLETO.zip

Objetivo:
- manter TMDB-only para Filmes/Séries;
- remover content_enrich/worker do aplicativo;
- usar a tela de sincronização para preparar as capas visíveis antes da Home;
- não mexer em EPG/canais/player.
