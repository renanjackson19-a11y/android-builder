GreenPlay Android Nativo 5.28.16 / 52816

- Topo mantém somente TV, Filmes e Séries.
- Ícones menores, sem cartão/quadrado de fundo.
- Fundo preto externo removido dos ícones enviados, preservando o desenho.
- Categorias visualmente limpas: remove enfeites como ♦, ⭐, ✔, ⚔, ☠ nas pontas.
- Dentro de Filmes/Séries não repete “• Filmes”/“• Séries”.
- Todas as categorias da fonte continuam sendo carregadas, sem limite.
