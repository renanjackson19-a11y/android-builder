GreenPlay 5.28.52
- GreenShorts sem categorias, no mesmo padrão de carregamento de Filmes/Séries.
- Primeiros itens aparecem assim que a primeira página chega; próximas páginas carregam ao rolar.
- Rodapé "Carregando mais conteúdo..." igual ao catálogo.
- Capas voltaram ao mesmo enquadramento de Filmes/Séries.
- Player GreenShorts continua vertical.
- GreenShorts salva progresso e mostra Continuar assistindo / Assistir do início.
- Filmes e Séries não foram alterados.
