GreenPlay Android Nativo 5.28.13 (52813)

Base: 5.28.12 / 52812.

Correções:
- Início restaura a Home já pronta sem remontar categorias/capas;
- Filmes/Séries/Kids não apagam mais a Home principal;
- categorias de Filmes/Séries usam o snapshot em memória e não reaparecem uma a uma por novas chamadas;
- modo TV cria a categoria inicial Filmes/Séries somente se a fonte não possuir equivalente;
- logo canônica/EPG passa na frente de stream_icon incorreto da fonte;
- cache antigo de logo não impede atualização para a logo correta;
- renderização inicial das categorias foi acelerada mantendo proteção contra ANR;
- TMDB/capas, EPG V87 e player preservados.
