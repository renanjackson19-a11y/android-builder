GreenPlay 5.28.37
Catalogo grande com paginação segura e RecyclerView na TV/TV Box.
Home preservada ao voltar do Perfil.
