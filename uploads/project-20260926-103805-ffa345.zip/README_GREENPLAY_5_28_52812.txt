GreenPlay Android Nativo 5.28.12 (52812)

Base: 5.28.11 / 52811.

Correções:
- remove espera bloqueante por content_detail/TMDB na abertura;
- cache abre imediatamente;
- primeira sincronização possui fallback rápido;
- download inicial de capas tem limite rígido;
- Home grande renderiza em lotes para evitar ANR;
- mantém arte de filmes/séries somente do TMDB;
- sem alteração em EPG, canais ou player.
