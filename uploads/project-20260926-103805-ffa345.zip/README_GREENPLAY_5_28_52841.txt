GreenPlay 5.28.41

- Filmes e Séries: rodapé visível Carregando mais conteúdo durante paginação.
- Última linha não deixa um único card perdido no canto durante carregamento.
- Se o total final terminar em 1 item, ele é centralizado na última linha.
- Cache de catálogo renovado para receber as contagens completas do painel.
- Totais de categorias propagados para Filmes e Séries.
- Paginação continua genérica por provider_id, sem limite lógico de itens.
