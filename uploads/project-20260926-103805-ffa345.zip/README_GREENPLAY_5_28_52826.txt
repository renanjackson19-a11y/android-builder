GreenPlay 5.28.26

Correção crítica da TV:
- VOD/filmes/séries/Shorts não podem mais aparecer como canais.
- Filtra URLs /movie/, /series/, extensões de VOD e type_id de catálogo.
- Sanitiza snapshot/cache live antes de renderizar.
- Mantém catálogo completo e carregamento atômico da Home.
