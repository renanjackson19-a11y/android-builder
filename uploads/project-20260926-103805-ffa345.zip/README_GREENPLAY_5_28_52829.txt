GreenPlay 5.28.29

Correção: a 5.28.28 chamava um método inexistente (isShortContent), impedindo a compilação.
Esta versão remove essa chamada e aplica retrato ao GreenShorts no celular usando a aba ativa.
Base funcional: 5.28.26.
