GreenPlay 5.28.44

- GreenShorts continua na barra superior.
- A aba continua automática por provedor: sem Shorts, ela fica oculta.
- Dentro de GreenShorts não há subcategorias; os conteúdos ficam soltos em uma única grade.
- Capas genéricas ReelShort/Reels Shorts são ignoradas.
- Sem capa válida, usa a arte GreenShorts enviada pelo usuário.
- Filmes, Séries, TV e demais áreas não foram alterados.
