GreenPlay 5.28.53
- GreenShorts continua visível como atalho fixo no topo do aplicativo.
- GreenShorts voltou a ter carrossel/destaque grande acima da grade, como no visual anterior.
- A grade e o carregamento progressivo continuam abaixo do carrossel.
- O cartão "Continuar assistindo" agora mostra o título em até duas linhas, sem esconder o nome.
- Player GreenShorts continua vertical.
- Base: GreenPlay 5.28.52.
