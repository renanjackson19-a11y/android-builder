GreenPlay Android Nativo 5.28.19 / 52819

- Integra tabela de jogos de futebol reais via endpoint /api/dtlive/football/.
- Exibe data, horário, status, placar, campeonato e escudos.
- Sem limite artificial de partidas: renderiza tudo em lotes para não travar a UI.
- Mantém TV / Filmes / Séries atuais; o novo ícone de Jogos pode ser colocado quando o usuário enviar.
- Inclui server_patch_football_v1 com proxy/cache para API-Football.
- O servidor precisa de uma API key gratuita da API-Football em config/football.php.
