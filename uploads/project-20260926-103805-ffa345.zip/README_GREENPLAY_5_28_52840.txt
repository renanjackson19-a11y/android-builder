GreenPlay 5.28.40

- Mobile: paginação real por rolagem nas categorias de Filmes e Séries.
- Não espera baixar milhares de itens para atualizar a grade.
- Lotes de 120, sem limite lógico por categoria.
- Próxima página é solicitada ao aproximar do fim da lista.
- Usa total_rows / more_page para saber quando a categoria realmente terminou.
- Duas novas tentativas automáticas em falha temporária de página.
- Cache/preview da Home não é inflado com o catálogo completo.
- Funciona por provider_id, sem IDs de provedor fixos no APK.
