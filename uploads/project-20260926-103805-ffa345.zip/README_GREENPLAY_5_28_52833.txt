GreenPlay 5.28.33

Correção crítica de memória/OOM na sincronização inicial.
- Home sincroniza todas as categorias, mas mantém somente 12 cards iniciais por categoria em memória.
- Reduz concorrência de 12 para 6 categorias simultâneas.
- Limite de segurança de 24 MB por resposta HTTP para impedir fechamento por OutOfMemoryError.
- Cache persistente antigo gigante é descartado automaticamente.
- Ao abrir uma categoria, os cards já sincronizados aparecem imediatamente e o catálogo completo continua sendo buscado pela rotina existente.
- Mantidas as correções do player/retorno da 5.28.32.
