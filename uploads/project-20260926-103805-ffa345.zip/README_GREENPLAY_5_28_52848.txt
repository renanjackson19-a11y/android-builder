GreenPlay 5.28.48

- GreenShorts: botão mostra somente Assistir.
- Reprodução com moldura/controles próprios do GreenPlay.
- O player incorporado usa controles nativos do app; controles padrão externos ficam desativados.
- Compatível com controle remoto: OK play/pause, esquerda/direita -10/+10s.
- Catálogo GreenShorts continua vindo do endpoint próprio do painel.
- O servidor filtra PT-BR e elimina vídeo/série repetidos entre canais.
