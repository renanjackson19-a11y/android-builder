GreenPlay Android Nativo 5.27 — versionCode 52704

Base: 5.27 / 52703.
Hotfix 52704:
- Série M3U abre assim que temporadas/episódios chegam do painel, sem esperar TMDB.
- Se um snapshot antigo abrir sem temporadas, o app refaz silenciosamente o detalhe estrutural e atualiza a tela.
- TMDB continua como enriquecimento separado de sinopse, gênero, nota e elenco.
- Mantém a separação rígida Filmes/Séries da build 52703.
