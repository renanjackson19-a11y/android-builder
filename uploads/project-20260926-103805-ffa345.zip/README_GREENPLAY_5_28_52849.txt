GreenPlay 5.28.49

- GreenShorts usa controles visuais do player normal GreenPlay.
- Toque não é repassado ao player incorporado: evita abrir compartilhamento/controles externos.
- Remove título duplicado/cabeçalho externo do topo durante a interação.
- Controles GreenPlay: voltar, -10s, play/pause, +10s e barra de progresso.
- Controle remoto: OK play/pause, esquerda/direita -10/+10s.
- Títulos do catálogo são entregues pelo painel já traduzidos para português quando possível.
