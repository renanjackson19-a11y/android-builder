package com.ativacao.app;

import android.app.Activity;
import android.graphics.Color;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;

final class AppBackground {
    private AppBackground(){}

    static View wrap(Activity a, View content){
        FrameLayout frame=new FrameLayout(a);
        frame.setBackgroundColor(Color.BLACK);

        String url=BrandConfig.internalBackground(a);
        if(url!=null&&!url.trim().isEmpty()){
            ImageView bg=new ImageView(a);
            bg.setScaleType(ImageView.ScaleType.FIT_XY);
            bg.setBackgroundColor(Color.BLACK);
            frame.addView(bg,new FrameLayout.LayoutParams(-1,-1));
            ImageLoader.intoBackground(a,bg,url);

            // Escurece levemente para os menus e textos continuarem legíveis.
            View shade=new View(a);
            shade.setBackgroundColor(Color.argb(108,0,0,0));
            frame.addView(shade,new FrameLayout.LayoutParams(-1,-1));
        }

        frame.addView(content,new FrameLayout.LayoutParams(-1,-1));
        return frame;
    }
}
