package com.ativacao.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.ScrollView;
import java.util.ArrayList;
import java.util.List;
import android.widget.Toast;

import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.DataSource;
import androidx.media3.datasource.DataSpec;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.datasource.TransferListener;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.PlayerView;

public class PlayerActivity extends Activity {
    private PlayerView playerView;
    private ExoPlayer player;
    private ProgressBar loading;
    private TextView epgNow, epgNext, playPause, elapsed, durationText, errorText, netStats;
    private SeekBar seek;
    private LinearLayout controls, topBar;
    private FrameLayout liveDrawer;
    private LinearLayout liveRows;
    private TextView channelName;
    private final List<ApiClient.Item> liveItems = new ArrayList<>();
    private final Handler handler = new Handler();
    private boolean live, dragging = false;
    private boolean openLiveListOnStart = false;
    private boolean fromHomeTv = false;
    private long resumePos = 0;
    private int retryCount = 0;
    private String format = "auto";
    private long streamId = 0;
    private boolean probed = false;
    private int formatAttempt = 0, uaAttempt = 0;
    private String userAgent = "VLC/3.0.20 LibVLC/3.0.20";

    private long sessionBytes = 0L;
    private long intervalBytes = 0L;
    private long intervalStartedAt = 0L;
    private int openGeneration = 0;

    private final Runnable progressTask = new Runnable() {
        @Override public void run() {
            if (player != null && !live && !dragging && seek != null) {
                long pos = Math.max(0, player.getCurrentPosition());
                long dur = player.getDuration();
                if (dur > 0 && dur != C.TIME_UNSET && dur < Integer.MAX_VALUE) {
                    seek.setMax((int) dur);
                    seek.setProgress((int) Math.min(pos, dur));
                    elapsed.setText(time(pos));
                    durationText.setText(time(dur));
                }
            }
            handler.postDelayed(this, 750);
        }
    };

    private final Runnable networkTask = new Runnable() {
        @Override public void run() {
            long now = SystemClock.elapsedRealtime();
            long elapsedMs = Math.max(1L, now - intervalStartedAt);
            double bytesPerSecond = intervalBytes * 1000.0 / elapsedMs;
            intervalBytes = 0L;
            intervalStartedAt = now;
            if (netStats != null) {
                netStats.setText("↓ " + speed(bytesPerSecond) + "  •  " + total(sessionBytes));
            }
            handler.postDelayed(this, 1000);
        }
    };

    private final Runnable hideTask = () -> {
        if (player != null && player.isPlaying()) {
            if (controls != null) controls.setVisibility(View.GONE);
            if (topBar != null) topBar.setVisibility(View.GONE);
        }
    };

    private final TransferListener transferListener = new TransferListener() {
        @Override public void onTransferInitializing(DataSource source, DataSpec dataSpec, boolean isNetwork) { }
        @Override public void onTransferStart(DataSource source, DataSpec dataSpec, boolean isNetwork) { }
        @Override public void onBytesTransferred(DataSource source, DataSpec dataSpec, boolean isNetwork, int bytesTransferred) {
            if (!isNetwork || bytesTransferred <= 0) return;
            sessionBytes += bytesTransferred;
            intervalBytes += bytesTransferred;
        }
        @Override public void onTransferEnd(DataSource source, DataSpec dataSpec, boolean isNetwork) { }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        immersive();
        if (b != null) resumePos = b.getLong("pos", 0);
        else resumePos = getIntent().getLongExtra("resume_pos",0);
        live = "live".equals(getIntent().getStringExtra("type"));
        openLiveListOnStart = live && getIntent().getBooleanExtra("open_live_list", false);
        fromHomeTv = live && getIntent().getBooleanExtra("from_home_tv", false);
        String f = getIntent().getStringExtra("format");
        if (f != null && !f.trim().isEmpty()) format = f;
        setContentView(build());
        startPlayer();
    }

    private View build() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        root.setFocusable(true);
        root.setClickable(true);

        playerView = new PlayerView(this);
        playerView.setUseController(false);
        playerView.setKeepScreenOn(true);
        playerView.setBackgroundColor(Color.BLACK);
        playerView.setResizeMode(androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT);
        root.addView(playerView, new FrameLayout.LayoutParams(-1, -1));

        loading = new ProgressBar(this);
        root.addView(loading, new FrameLayout.LayoutParams(Ui.dp(this, 42), Ui.dp(this, 42), Gravity.CENTER));

        errorText = Ui.text(this, "", 12, Color.WHITE, true);
        errorText.setGravity(Gravity.CENTER);
        errorText.setPadding(Ui.dp(this, 20), Ui.dp(this, 12), Ui.dp(this, 20), Ui.dp(this, 12));
        errorText.setBackgroundColor(0xCC1A1118);
        errorText.setVisibility(View.GONE);
        FrameLayout.LayoutParams erp = new FrameLayout.LayoutParams(Ui.dp(this, 520), Ui.dp(this, 70), Gravity.CENTER);
        root.addView(errorText, erp);

        topBar = new LinearLayout(this);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(Ui.dp(this, 18), 0, Ui.dp(this, 18), 0);
        topBar.setBackgroundColor(0x8F040911);
        channelName = Ui.text(this, clean(getIntent().getStringExtra("name"), "Dubai Play"), Ui.phone(this) ? 12 : 15, Color.WHITE, true);
        channelName.setMaxLines(1);
        topBar.addView(channelName, new LinearLayout.LayoutParams(0, Ui.dp(this, 44), 1));
        netStats = Ui.text(this, "↓ 0 KB/s  •  0 MB", 9, Color.rgb(190, 220, 205), true);
        netStats.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        topBar.addView(netStats, new LinearLayout.LayoutParams(Ui.dp(this, Ui.phone(this) ? 155 : 190), Ui.dp(this, 44)));
        TextView brand = Ui.text(this, "DUBAI PLAY", 10, Color.rgb(205, 193, 255), true);
        brand.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        topBar.addView(brand, new LinearLayout.LayoutParams(Ui.dp(this, 120), Ui.dp(this, 44)));
        root.addView(topBar, new FrameLayout.LayoutParams(-1, Ui.dp(this, 44), Gravity.TOP));

        controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        controls.setPadding(Ui.dp(this, 9), Ui.dp(this, 5), Ui.dp(this, 9), Ui.dp(this, 5));
        controls.setBackground(Ui.stroke(0xDB0B111B, 0x663C4F6C, 13, this));

        TextView back = Ui.button(this, "‹");
        back.setOnClickListener(v -> handleBackNavigation());
        controls.addView(back, new LinearLayout.LayoutParams(Ui.dp(this, 46), Ui.dp(this, 40)));

        if (!live) {
            TextView prev = Ui.button(this, "−10");
            prev.setOnClickListener(v -> seekBy(-10000));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(Ui.dp(this, 54), Ui.dp(this, 40));
            p.leftMargin = Ui.dp(this, 6);
            controls.addView(prev, p);
        }

        playPause = Ui.primaryButton(this, "❚❚");
        playPause.setOnClickListener(v -> togglePlayback());
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(Ui.dp(this, 60), Ui.dp(this, 40));
        pp.leftMargin = Ui.dp(this, 6);
        controls.addView(playPause, pp);

        if (!live) {
            TextView next = Ui.button(this, "+10");
            next.setOnClickListener(v -> seekBy(10000));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(Ui.dp(this, 54), Ui.dp(this, 40));
            p.leftMargin = Ui.dp(this, 6);
            controls.addView(next, p);

            elapsed = Ui.text(this, "00:00", 10, Ui.MUTED, true);
            elapsed.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(Ui.dp(this, 52), Ui.dp(this, 40));
            ep.leftMargin = Ui.dp(this, 7);
            controls.addView(elapsed, ep);

            seek = new SeekBar(this);
            seek.setFocusable(true);
            seek.setMax(1);
            LinearLayout.LayoutParams sk = new LinearLayout.LayoutParams(0, Ui.dp(this, 40), 1);
            sk.leftMargin = Ui.dp(this, 4);
            sk.rightMargin = Ui.dp(this, 4);
            controls.addView(seek, sk);

            durationText = Ui.text(this, "00:00", 10, Ui.MUTED, true);
            durationText.setGravity(Gravity.CENTER);
            controls.addView(durationText, new LinearLayout.LayoutParams(Ui.dp(this, 52), Ui.dp(this, 40)));

            seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                public void onProgressChanged(SeekBar s, int p, boolean from) { if (from && elapsed != null) elapsed.setText(time(p)); }
                public void onStartTrackingTouch(SeekBar s) { dragging = true; showControls(); }
                public void onStopTrackingTouch(SeekBar s) { dragging = false; if (player != null) player.seekTo(s.getProgress()); scheduleHide(); }
            });
        } else {
            LinearLayout epg = Ui.column(this);
            LinearLayout.LayoutParams epp = new LinearLayout.LayoutParams(0, Ui.dp(this, 40), 1);
            epp.leftMargin = Ui.dp(this, 10);
            controls.addView(epg, epp);
            epgNow = Ui.text(this, "AGORA  Carregando programação...", 10, Color.WHITE, true);
            epgNow.setMaxLines(1);
            epgNext = Ui.text(this, "A SEGUIR  —", 9, Ui.MUTED, false);
            epgNext.setMaxLines(1);
            epg.addView(epgNow, new LinearLayout.LayoutParams(-1, 0, 1));
            epg.addView(epgNext, new LinearLayout.LayoutParams(-1, 0, 1));
            TextView badge = Ui.text(this, "● AO VIVO", 10, Ui.GREEN, true);
            badge.setGravity(Gravity.CENTER);
            controls.addView(badge, new LinearLayout.LayoutParams(Ui.dp(this, 95), Ui.dp(this, 40)));
        }

        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-1, Ui.dp(this, 52), Gravity.BOTTOM);
        cp.leftMargin = Ui.dp(this, 20);
        cp.rightMargin = Ui.dp(this, 20);
        cp.bottomMargin = Ui.dp(this, 14);
        root.addView(controls, cp);

        if (live) {
            liveDrawer = new FrameLayout(this);
            liveDrawer.setBackgroundColor(0xE810151D);
            LinearLayout box = Ui.column(this);
            box.setPadding(Ui.dp(this, 14), Ui.dp(this, 12), Ui.dp(this, 14), Ui.dp(this, 12));
            TextView hd = Ui.text(this, "LISTA DE CANAIS", 13, Color.WHITE, true);
            box.addView(hd, new LinearLayout.LayoutParams(-1, Ui.dp(this, 38)));
            TextView hint = Ui.text(this, "Selecione um canal • o vídeo continua em preview", 9, Ui.MUTED, false);
            box.addView(hint, new LinearLayout.LayoutParams(-1, Ui.dp(this, 30)));
            ScrollView sc = new ScrollView(this); sc.setVerticalScrollBarEnabled(false);
            liveRows = Ui.column(this); sc.addView(liveRows, new ScrollView.LayoutParams(-1, -2));
            box.addView(sc, new LinearLayout.LayoutParams(-1, 0, 1));
            liveDrawer.addView(box, new FrameLayout.LayoutParams(-1, -1));
            FrameLayout.LayoutParams dp = new FrameLayout.LayoutParams(Ui.dp(this, Ui.phone(this)?300:360), -1, Gravity.LEFT);
            liveDrawer.setVisibility(View.GONE); root.addView(liveDrawer, dp);
        }

        root.setOnClickListener(v -> {
            if (controls.getVisibility() == View.VISIBLE) {
                controls.setVisibility(View.GONE);
                topBar.setVisibility(View.GONE);
            } else showControls();
        });
        showControls();
        back.requestFocus();
        return root;
    }

    private void startPlayer() {
        streamId = getIntent().getLongExtra("id", 0);
        if (live && streamId > 0) { LocalStore.saveLastLive(this, itemFromIntent()); }
        retryCount = 0;
        formatAttempt = 0;
        uaAttempt = 0;
        probed = false;
        userAgent = "VLC/3.0.20 LibVLC/3.0.20";
        sessionBytes = 0L;
        intervalBytes = 0L;
        intervalStartedAt = SystemClock.elapsedRealtime();

        // Para VOD, deixar o ExoPlayer detectar o container evita travas quando a extensão da lista está errada.
        String initialFormat = live ? clean(format, "auto") : "auto";
        openWithFormat(initialFormat);
        handler.post(progressTask);
        handler.post(networkTask);
        if (live) { loadEpg(streamId); loadLiveList(); }
    }

    private void openWithFormat(String chosen) {
        final int generation = ++openGeneration;
        format = clean(chosen, "auto").toLowerCase(java.util.Locale.US);
        if (player != null) {
            try { player.release(); } catch (Exception ignored) { }
            player = null;
        }

        String url = ApiClient.streamUrl(streamId);
        java.util.Map<String, String> headers = new java.util.HashMap<>();
        headers.put("Accept", "*/*");
        headers.put("Accept-Encoding", "identity");
        headers.put("Connection", "keep-alive");

        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                .setUserAgent(userAgent)
                .setConnectTimeoutMs(6000)
                .setReadTimeoutMs(30000)
                .setAllowCrossProtocolRedirects(true)
                .setDefaultRequestProperties(headers)
                .setTransferListener(transferListener);

        // Buffer curto para começar rápido, sem zerar a proteção contra internet oscilando.
        DefaultLoadControl load = new DefaultLoadControl.Builder()
                .setBufferDurationsMs(
                        live ? 1200 : 2500,
                        live ? 9000 : 22000,
                        live ? 250 : 450,
                        live ? 650 : 1000
                ).build();

        DefaultMediaSourceFactory mediaFactory = new DefaultMediaSourceFactory(this).setDataSourceFactory(http);
        player = new ExoPlayer.Builder(this)
                .setLoadControl(load)
                .setMediaSourceFactory(mediaFactory)
                .setSeekBackIncrementMs(10000)
                .setSeekForwardIncrementMs(10000)
                .build();
        player.setHandleAudioBecomingNoisy(true);
        playerView.setPlayer(player);

        player.addListener(new Player.Listener() {
            @Override public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_BUFFERING) {
                    loading.setVisibility(View.VISIBLE);
                } else if (state == Player.STATE_READY) {
                    loading.setVisibility(View.GONE);
                    errorText.setVisibility(View.GONE);
                    retryCount = 0;
                    playPause.setText(player.isPlaying() ? "❚❚" : "▶");
                    if (resumePos > 0 && !live && player.getCurrentPosition() < 1000) {
                        player.seekTo(resumePos);
                        resumePos = 0;
                    }
                    scheduleHide();
                } else if (state == Player.STATE_ENDED) {
                    loading.setVisibility(View.GONE);
                    playPause.setText("▶");
                    showControls();
                }
            }

            @Override public void onIsPlayingChanged(boolean playing) {
                playPause.setText(playing ? "❚❚" : "▶");
                if (playing) scheduleHide(); else showControls();
            }

            @Override public void onPlayerError(PlaybackException error) { handlePlayerError(error); }
        });

        MediaItem.Builder mb = new MediaItem.Builder().setUri(url);
        // Só forçar MIME quando é realmente necessário. Filmes/episódios ficam em AUTO para o extractor detectar.
        if ("hls".equals(format) || "m3u8".equals(format)) mb.setMimeType(MimeTypes.APPLICATION_M3U8);
        else if (live && ("ts".equals(format) || "mpegts".equals(format))) mb.setMimeType(MimeTypes.VIDEO_MP2T);

        player.setMediaItem(mb.build());
        player.setPlayWhenReady(true);
        player.prepare();
        errorText.setVisibility(View.GONE);

        // Se ficar preso em 00:00/carregando, tenta corrigir sem deixar o usuário esperando indefinidamente.
        handler.postDelayed(() -> {
            if (generation != openGeneration || player == null) return;
            int state = player.getPlaybackState();
            if (state == Player.STATE_READY || player.isPlaying()) return;
            if (!probed) {
                probed = true;
                errorText.setText("Otimizando o stream...");
                errorText.setVisibility(View.VISIBLE);
                ApiClient.probeStream(streamId, new ApiClient.Callback<ApiClient.StreamProbe>() {
                    public void ok(ApiClient.StreamProbe p) {
                        runOnUiThread(() -> {
                            if (generation != openGeneration) return;
                            String detected = clean(p.format, "auto");
                            if (p.userAgent != null && !p.userAgent.trim().isEmpty()) userAgent = p.userAgent.trim();
                            openWithFormat(detected);
                        });
                    }
                    public void error(String m) { runOnUiThread(() -> { if (generation == openGeneration) tryNextFormat("START_TIMEOUT"); }); }
                });
            } else {
                tryNextFormat("START_TIMEOUT");
            }
        }, live ? 5000 : 6500);
    }

    private void handlePlayerError(PlaybackException error) {
        loading.setVisibility(View.GONE);
        String code = error.getErrorCodeName();

        // Primeiro tenta uma reconexão curta: é mais rápido em quedas momentâneas.
        if (retryCount < 2 && !code.contains("PARSING_CONTAINER")) {
            retryCount++;
            errorText.setText("Reconectando ao stream...");
            errorText.setVisibility(View.VISIBLE);
            handler.postDelayed(() -> {
                if (player != null) {
                    player.prepare();
                    player.play();
                }
            }, retryCount == 1 ? 450 : 900);
            return;
        }

        // Se veio com container forçado, AUTO é a tentativa mais rápida.
        if (code.contains("PARSING_CONTAINER") && !"auto".equals(format)) {
            errorText.setText("Ajustando formato...");
            errorText.setVisibility(View.VISIBLE);
            openWithFormat("auto");
            return;
        }

        if (!probed && (code.contains("PARSING_CONTAINER") || code.contains("IO_BAD_HTTP") || code.contains("IO_UNSPECIFIED"))) {
            probed = true;
            errorText.setText("Detectando formato do stream...");
            errorText.setVisibility(View.VISIBLE);
            ApiClient.probeStream(streamId, new ApiClient.Callback<ApiClient.StreamProbe>() {
                public void ok(ApiClient.StreamProbe p) {
                    runOnUiThread(() -> {
                        String detected = clean(p.format, "auto");
                        if (p.userAgent != null && !p.userAgent.trim().isEmpty()) userAgent = p.userAgent.trim();
                        if (!detected.equalsIgnoreCase(format) || !userAgent.equals("VLC/3.0.20 LibVLC/3.0.20")) openWithFormat(detected);
                        else tryNextFormat(code);
                    });
                }
                public void error(String m) { runOnUiThread(() -> tryNextFormat(code)); }
            });
            return;
        }
        tryNextFormat(code);
    }

    private void tryNextFormat(String lastCode) {
        String[] attempts = live ? new String[]{"auto", "ts", "hls"} : new String[]{"auto", "mp4", "ts", "hls"};
        while (formatAttempt < attempts.length) {
            String next = attempts[formatAttempt++];
            if (next.equalsIgnoreCase(format)) continue;
            errorText.setText("Tentando " + next.toUpperCase(java.util.Locale.US) + "...");
            errorText.setVisibility(View.VISIBLE);
            openWithFormat(next);
            return;
        }

        String[] agents = {
                "VLC/3.0.20 LibVLC/3.0.20",
                "IPTVSmartersPro",
                "Mozilla/5.0 (Linux; Android 13; TV) AppleWebKit/537.36"
        };
        if (uaAttempt < agents.length) {
            userAgent = agents[uaAttempt++];
            formatAttempt = 0;
            errorText.setText("Tentando compatibilidade...");
            errorText.setVisibility(View.VISIBLE);
            openWithFormat("auto");
            return;
        }

        errorText.setText("Não foi possível abrir este stream.\n" + lastCode);
        errorText.setVisibility(View.VISIBLE);
        Toast.makeText(this, "Falha no stream: " + lastCode, Toast.LENGTH_LONG).show();
    }


    private ApiClient.Item itemFromIntent(){
        ApiClient.Item i=new ApiClient.Item();
        i.id=streamId; i.type=clean(getIntent().getStringExtra("type"),live?"live":"movie");
        i.name=clean(getIntent().getStringExtra("name"),"Canal");
        i.logo=clean(getIntent().getStringExtra("logo"),""); i.backdrop=clean(getIntent().getStringExtra("backdrop"),"");
        i.group=clean(getIntent().getStringExtra("group"),""); i.format=clean(getIntent().getStringExtra("format"),"auto");
        return i;
    }
    private void togglePlayback() { if (player == null) return; if (player.isPlaying()) player.pause(); else player.play(); }
    private void seekBy(long delta) { if (player == null || live) return; long dur = player.getDuration(); long max = dur > 0 && dur != C.TIME_UNSET ? dur : Long.MAX_VALUE; player.seekTo(Math.max(0, Math.min(max, player.getCurrentPosition() + delta))); showControls(); scheduleHide(); }
    private void showControls() { handler.removeCallbacks(hideTask); controls.setVisibility(View.VISIBLE); topBar.setVisibility(View.VISIBLE); }
    private void scheduleHide() { handler.removeCallbacks(hideTask); handler.postDelayed(hideTask, 3500); }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (live) {
            if (keyCode == KeyEvent.KEYCODE_BACK) {
                handleBackNavigation(); return true;
            }
            if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT || keyCode == KeyEvent.KEYCODE_DPAD_UP || keyCode == KeyEvent.KEYCODE_MENU) {
                showLiveDrawer(); return true;
            }
            if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT && liveDrawer != null && liveDrawer.getVisibility()==View.VISIBLE) {
                hideLiveDrawer(); return true;
            }
        }
        if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) { togglePlayback(); return true; }
        if (!live && keyCode == KeyEvent.KEYCODE_DPAD_LEFT) { seekBy(-10000); return true; }
        if (!live && keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) { seekBy(10000); return true; }
        showControls();
        return super.onKeyDown(keyCode, event);
    }

    @Override public void onBackPressed() {
        handleBackNavigation();
    }

    private void handleBackNavigation() {
        if (live && getIntent().getBooleanExtra("from_live_tv_page", false)) {
            finish();
            return;
        }
        if (live) {
            // Igual à referência: tela cheia -> lista/preview -> Home/tela anterior.
            if (liveDrawer != null && liveDrawer.getVisibility() != View.VISIBLE) {
                showLiveDrawer();
                return;
            }
            finish();
            return;
        }
        finish();
    }

    private void loadLiveList() {
        loadLiveListPage(1, new java.util.ArrayList<>());
    }

    private void loadLiveListPage(int page, java.util.List<ApiClient.Item> acc) {
        ApiClient.catalog("live", page, 72, "", "", "", new ApiClient.Callback<ApiClient.CatalogPage>() {
            public void ok(ApiClient.CatalogPage p) {
                if (p != null && p.items != null) acc.addAll(p.items);
                int pages = p == null ? 1 : Math.max(1, p.pages);
                if (page < pages) { loadLiveListPage(page + 1, acc); return; }
                runOnUiThread(() -> renderLiveList(acc));
            }
            public void error(String m) { if (!acc.isEmpty()) runOnUiThread(() -> renderLiveList(acc)); }
        });
    }

    private void renderLiveList(List<ApiClient.Item> list) {
        if (liveRows == null) return; liveRows.removeAllViews(); liveItems.clear(); if (list != null) liveItems.addAll(list);
        View selected = null;
        for (ApiClient.Item i : liveItems) {
            TextView b = Ui.button(this, clean(i.name, "Canal")); b.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL); b.setMaxLines(1);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, Ui.dp(this, 42)); lp.bottomMargin=Ui.dp(this,4); liveRows.addView(b, lp);
            b.setOnClickListener(v -> switchLive(i));
            if (i.id == streamId) selected = b;
        }
        if (openLiveListOnStart) {
            openLiveListOnStart = false;
            liveDrawer.setVisibility(View.VISIBLE);
            liveDrawer.bringToFront();
            if (selected != null) selected.requestFocus();
            else if (liveRows.getChildCount() > 0) liveRows.getChildAt(0).requestFocus();
        }
    }

    private void switchLive(ApiClient.Item i) {
        if (i == null || i.id <= 0) return; streamId=i.id; format=clean(i.format,"auto"); retryCount=0; formatAttempt=0; uaAttempt=0; probed=false;
        if (channelName != null) channelName.setText(clean(i.name,"Canal"));
        LocalStore.saveLastLive(this, i); LocalStore.addHistory(this, i); hideLiveDrawer(); openWithFormat(format); loadEpg(streamId);
    }

    private void showLiveDrawer() {
        if (liveDrawer == null) return;
        liveDrawer.setVisibility(View.VISIBLE);
        liveDrawer.bringToFront();
        if (liveRows != null && liveRows.getChildCount() > 0) {
            View target = null;
            for (int n = 0; n < liveRows.getChildCount() && n < liveItems.size(); n++) {
                if (liveItems.get(n).id == streamId) { target = liveRows.getChildAt(n); break; }
            }
            if (target == null) target = liveRows.getChildAt(0);
            target.requestFocus();
        }
    }
    private void hideLiveDrawer() { if (liveDrawer != null) liveDrawer.setVisibility(View.GONE); showControls(); }

    private void loadEpg(long id) {
        ApiClient.epg(id, new ApiClient.Callback<ApiClient.EpgInfo>() {
            public void ok(ApiClient.EpgInfo i) {
                runOnUiThread(() -> {
                    if (epgNow != null) epgNow.setText(clean(i.nowTitle, "").isEmpty() ? "AGORA  Programação não disponível" : "AGORA  " + i.nowTitle);
                    if (epgNext != null) epgNext.setText(clean(i.nextTitle, "").isEmpty() ? "A SEGUIR  —" : "A SEGUIR  " + i.nextTitle);
                });
            }
            public void error(String m) {
                runOnUiThread(() -> {
                    if (epgNow != null) epgNow.setText("AGORA  Programação não disponível");
                    if (epgNext != null) epgNext.setText("A SEGUIR  —");
                });
            }
        });
    }

    @Override protected void onSaveInstanceState(Bundle out) { if (player != null && !live) out.putLong("pos", player.getCurrentPosition()); super.onSaveInstanceState(out); }
    @Override protected void onStop(){handler.removeCallbacksAndMessages(null);if(player!=null){try{if(!live&&streamId>0){long pos=Math.max(0,player.getCurrentPosition()),dur=player.getDuration();if(dur>0&&dur!=C.TIME_UNSET&&pos>=dur-30000)LocalStore.clearResume(this,streamId);else if(pos>10000)LocalStore.saveResume(this,streamId,pos);}}catch(Throwable ignored){}try{player.release();}catch(Throwable ignored){}player=null;}super.onStop();}

    private String clean(String v, String fallback) { if (v == null) return fallback; String s = v.trim(); return s.isEmpty() || "null".equalsIgnoreCase(s) ? fallback : s; }
    private String time(long ms) { long sec = Math.max(0, ms / 1000), m = sec / 60, s = sec % 60, h = m / 60; m %= 60; return h > 0 ? String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, s) : String.format(java.util.Locale.US, "%02d:%02d", m, s); }
    private String speed(double bytesPerSecond) { double bitsPerSecond = bytesPerSecond * 8.0; if (bitsPerSecond >= 1000_000.0) return String.format(java.util.Locale.US, "%.1f Mbps", bitsPerSecond / 1000_000.0); if (bitsPerSecond >= 1000.0) return String.format(java.util.Locale.US, "%.0f Kbps", bitsPerSecond / 1000.0); return String.format(java.util.Locale.US, "%.0f bps", bitsPerSecond); }
    private String total(long bytes) { if (bytes >= 1024L * 1024L * 1024L) return String.format(java.util.Locale.US, "%.2f GB", bytes / (1024.0 * 1024.0 * 1024.0)); if (bytes >= 1024L * 1024L) return String.format(java.util.Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0)); return String.format(java.util.Locale.US, "%.0f KB", bytes / 1024.0); }
    private void immersive() { getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION); }
}
