SPOTNET ANDROID V57

Base: V53 (última versão confirmada como compilando e abrindo).
Correções aplicadas com baixo risco:
- removidas as alterações do serviço de áudio que causavam fechamento imediato;
- seleção do melhor stream de áudio disponível;
- limpeza e validação segura da URL retornada pela API;
- mantidas as correções visuais e de login da base estável.

Gere primeiro como APK de teste.
