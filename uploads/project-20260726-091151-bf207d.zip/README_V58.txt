SPOTNET MUSIC V58

- Revertido somente o código do player para o comportamento da última base estável V53.
- StreamResolver restaurado exatamente como estava antes das alterações de reprodução.
- Construção da URL de áudio restaurada sem filtros extras que impediam o play.
- Layout e demais melhorias visuais da base atual foram preservados.
- versionCode atualizado para 58.
