GreenPlay Android 5.28.5 (52805)

Correção principal: capas TMDB na Home.
O app não fica preso ao snapshot local antigo por 12 horas.
Na primeira abertura desta versão usa o novo schema catalog52805 e sincroniza novamente.
Durante o carregamento inicial, somente cards visíveis sem arte TMDB são enriquecidos, em fila controlada de até 6 requisições simultâneas.
