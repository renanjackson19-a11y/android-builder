package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

public class ProfileActivity extends Activity {
    private boolean phone;
    @Override public void onCreate(Bundle b){super.onCreate(b);Ui.immersive(this);phone=Ui.phone(this);setContentView(build());}

    private View build(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.HORIZONTAL);root.setBackground(Ui.diagonalGradient(Ui.BG_2,Ui.BG,0,this));root.setPadding(Ui.dp(this,phone?20:34),Ui.dp(this,18),Ui.dp(this,phone?20:34),Ui.dp(this,18));
        LinearLayout profile=Ui.column(this);profile.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL);profile.setPadding(Ui.dp(this,18),Ui.dp(this,18),Ui.dp(this,18),Ui.dp(this,18));profile.setBackground(Ui.round(Color.argb(72,255,255,255),4,this));
        TextView avatar=Ui.text(this,"D",phone?26:36,Color.WHITE,true);avatar.setGravity(Gravity.CENTER);avatar.setBackground(Ui.gradient(Ui.GREEN,Ui.GREEN_2,60,this));profile.addView(avatar,new LinearLayout.LayoutParams(Ui.dp(this,68),Ui.dp(this,68)));
        TextView u=Ui.text(this,clean(Session.user(this),"Usuário"),phone?15:19,Ui.TEXT,true);u.setGravity(Gravity.CENTER);LinearLayout.LayoutParams up=new LinearLayout.LayoutParams(-1,Ui.dp(this,44));up.topMargin=Ui.dp(this,8);profile.addView(u,up);
        TextView plan=Ui.text(this,"Plano: "+clean(Session.plan(this),"Ativo"),11,Ui.GOLD,true);plan.setGravity(Gravity.CENTER);profile.addView(plan,new LinearLayout.LayoutParams(-1,Ui.dp(this,30)));
        TextView exp=Ui.text(this,"Validade: "+clean(Session.expires(this),"não informada"),10,Ui.MUTED,false);exp.setGravity(Gravity.CENTER);profile.addView(exp,new LinearLayout.LayoutParams(-1,Ui.dp(this,28)));
        TextView dev=Ui.text(this,"Aparelho: "+DeviceInfo.macOrId(this),9,Ui.MUTED,false);dev.setGravity(Gravity.CENTER);profile.addView(dev,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));
        TextView settings=Ui.button(this,"CONFIGURAÇÕES");settings.setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class)));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,Ui.dp(this,42));sp.topMargin=Ui.dp(this,10);profile.addView(settings,sp);
        TextView back=Ui.button(this,"VOLTAR");back.setOnClickListener(v->finish());LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,Ui.dp(this,42));bp.topMargin=Ui.dp(this,8);profile.addView(back,bp);
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(Ui.dp(this,phone?245:320),-1);pp.rightMargin=Ui.dp(this,24);root.addView(profile,pp);

        ScrollView scroll=new ScrollView(this);scroll.setVerticalScrollBarEnabled(false);LinearLayout body=Ui.column(this);
        body.addView(Ui.text(this,"Histórico",phone?20:26,Ui.TEXT,false),new LinearLayout.LayoutParams(-1,Ui.dp(this,48)));shelf(body,LocalStore.history(this));
        body.addView(Ui.text(this,"Minha lista",phone?20:26,Ui.TEXT,false),new LinearLayout.LayoutParams(-1,Ui.dp(this,48)));shelf(body,LocalStore.favorites(this));
        LinearLayout shortcuts=new LinearLayout(this);shortcuts.setGravity(Gravity.CENTER_VERTICAL);TextView fav=bigShortcut("★  MEUS FAVORITOS");fav.setOnClickListener(v->{});shortcuts.addView(fav,new LinearLayout.LayoutParams(0,Ui.dp(this,88),1));TextView list=bigShortcut("☰  MINHA LISTA");LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,Ui.dp(this,88),1);lp.leftMargin=Ui.dp(this,10);shortcuts.addView(list,lp);body.addView(shortcuts,new LinearLayout.LayoutParams(-1,Ui.dp(this,92)));
        scroll.addView(body,new ScrollView.LayoutParams(-1,-2));root.addView(scroll,new LinearLayout.LayoutParams(0,-1,1));back.requestFocus();return root;
    }

    private TextView bigShortcut(String s){TextView t=Ui.text(this,s,phone?13:16,Ui.TEXT,true);t.setGravity(Gravity.CENTER);t.setFocusable(true);t.setClickable(true);Ui.focus(t,this,Ui.diagonalGradient(Color.rgb(24,110,145),Color.rgb(21,62,93),5,this),Ui.stroke(Color.rgb(33,126,166),Ui.GREEN,5,this));return t;}

    private void shelf(LinearLayout body,List<ApiClient.Item> items){if(items==null||items.isEmpty()){body.addView(Ui.text(this,"Nenhum item ainda.",11,Ui.MUTED,false),new LinearLayout.LayoutParams(-1,Ui.dp(this,58)));return;}HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setHorizontalScrollBarEnabled(false);LinearLayout row=new LinearLayout(this);for(int x=0;x<Math.min(12,items.size());x++){ApiClient.Item i=items.get(x);FrameLayout card=new FrameLayout(this);card.setFocusable(true);card.setClickable(true);card.setClipToOutline(true);Ui.focus(card,this,Ui.round(Color.TRANSPARENT,3,this),Ui.stroke(Color.argb(75,255,255,255),Ui.GREEN,3,this));ImageView img=new ImageView(this);img.setScaleType(ImageView.ScaleType.CENTER_CROP);img.setBackgroundColor(Ui.PANEL_2);card.addView(img,new FrameLayout.LayoutParams(-1,-1));ImageLoader.into(this,img,i.logo);View shade=new View(this);shade.setBackground(Ui.verticalGradient(Color.TRANSPARENT,Color.argb(220,0,0,0),0,this));card.addView(shade,new FrameLayout.LayoutParams(-1,-1));TextView n=Ui.text(this,clean(i.name,"Sem nome"),9,Ui.TEXT,true);n.setMaxLines(2);n.setPadding(Ui.dp(this,6),0,Ui.dp(this,6),Ui.dp(this,5));card.addView(n,new FrameLayout.LayoutParams(-1,Ui.dp(this,42),Gravity.BOTTOM));card.setOnClickListener(v->open(i));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(Ui.dp(this,phone?118:145),Ui.dp(this,phone?154:188));cp.rightMargin=Ui.dp(this,8);row.addView(card,cp);}hsv.addView(row);body.addView(hsv,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?160:194)));}
    private void open(ApiClient.Item i){if("series".equals(i.type)){Intent in=new Intent(this,SeriesActivity.class);in.putExtra("title",clean(i.seriesTitle,i.name));startActivity(in);}else if("movie".equals(i.type)){Intent in=new Intent(this,DetailActivity.class);MainActivity.putItem(in,i);startActivity(in);}else{Intent in=new Intent(this,PlayerActivity.class);MainActivity.putItem(in,i);startActivity(in);}}
    private String clean(String v,String f){if(v==null)return f;String s=v.trim();return s.isEmpty()||"null".equalsIgnoreCase(s)?f:s;}
}
