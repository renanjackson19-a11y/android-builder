package com.ativacao.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class FootballActivity extends Activity {
    private final List<ApiClient.FootballMatch> matches=new ArrayList<>();
    private GridView grid;private MatchAdapter adapter;private TextView status;private boolean phone;
    @Override public void onCreate(Bundle b){super.onCreate(b);immersive();phone=Ui.phone(this);setContentView(build());load();}
    private View build(){
        LinearLayout root=Ui.column(this);root.setBackgroundColor(Ui.BG);LinearLayout content=Ui.column(this);content.setPadding(Ui.dp(this,phone?14:24),Ui.dp(this,12),Ui.dp(this,phone?14:24),Ui.dp(this,12));
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);TextView back=Ui.button(this,"‹  VOLTAR");back.setOnClickListener(v->finish());top.addView(back,new LinearLayout.LayoutParams(Ui.dp(this,phone?120:145),Ui.dp(this,44)));TextView title=Ui.text(this,"Futebol Hoje",phone?20:25,Ui.TEXT,true);LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,Ui.dp(this,44),1);tp.leftMargin=Ui.dp(this,12);top.addView(title,tp);content.addView(top,new LinearLayout.LayoutParams(-1,Ui.dp(this,48)));
        status=Ui.text(this,"Atualizando jogos do dia...",11,Ui.MUTED,false);content.addView(status,new LinearLayout.LayoutParams(-1,Ui.dp(this,32)));
        grid=new GridView(this);grid.setNumColumns(phone?2:3);grid.setHorizontalSpacing(Ui.dp(this,10));grid.setVerticalSpacing(Ui.dp(this,10));grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);grid.setSelector(android.R.color.transparent);adapter=new MatchAdapter();grid.setAdapter(adapter);content.addView(grid,new LinearLayout.LayoutParams(-1,0,1));FrameLayout centered=Ui.centered(this,content,1260);root.addView(centered,new LinearLayout.LayoutParams(-1,-1));back.requestFocus();return root;
    }
    private void load(){ApiClient.football(new ApiClient.Callback<List<ApiClient.FootballMatch>>(){public void ok(List<ApiClient.FootballMatch> d){runOnUiThread(()->{matches.clear();matches.addAll(d);adapter.notifyDataSetChanged();status.setText(matches.isEmpty()?"Nenhum jogo encontrado para hoje.":matches.size()+" jogos de hoje");if(!matches.isEmpty())grid.requestFocus();});}public void error(String m){runOnUiThread(()->status.setText("Não foi possível atualizar os jogos • "+m));}});}
    private class MatchAdapter extends BaseAdapter{
        public int getCount(){return matches.size();}public Object getItem(int p){return matches.get(p);}public long getItemId(int p){return p;}
        public View getView(int p,View convert,android.view.ViewGroup parent){LinearLayout card;TextView league,home,away,score,state;ImageView hLogo,aLogo;if(convert==null){card=Ui.column(FootballActivity.this);card.setPadding(Ui.dp(FootballActivity.this,14),Ui.dp(FootballActivity.this,12),Ui.dp(FootballActivity.this,14),Ui.dp(FootballActivity.this,12));Ui.focus(card,FootballActivity.this);card.setFocusable(true);
                league=Ui.text(FootballActivity.this,"",10,Ui.PURPLE,true);league.setId(401);card.addView(league,new LinearLayout.LayoutParams(-1,Ui.dp(FootballActivity.this,24)));
                LinearLayout teams=new LinearLayout(FootballActivity.this);teams.setGravity(Gravity.CENTER_VERTICAL);hLogo=new ImageView(FootballActivity.this);hLogo.setId(402);teams.addView(hLogo,new LinearLayout.LayoutParams(Ui.dp(FootballActivity.this,36),Ui.dp(FootballActivity.this,36)));home=Ui.text(FootballActivity.this,"",12,Ui.TEXT,true);home.setId(403);LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(0,Ui.dp(FootballActivity.this,38),1);hp.leftMargin=Ui.dp(FootballActivity.this,8);teams.addView(home,hp);score=Ui.text(FootballActivity.this,"",14,Ui.TEXT,true);score.setGravity(Gravity.CENTER);score.setId(404);teams.addView(score,new LinearLayout.LayoutParams(Ui.dp(FootballActivity.this,68),Ui.dp(FootballActivity.this,38)));away=Ui.text(FootballActivity.this,"",12,Ui.TEXT,true);away.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);away.setId(405);teams.addView(away,new LinearLayout.LayoutParams(0,Ui.dp(FootballActivity.this,38),1));aLogo=new ImageView(FootballActivity.this);aLogo.setId(406);LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(Ui.dp(FootballActivity.this,36),Ui.dp(FootballActivity.this,36));ap.leftMargin=Ui.dp(FootballActivity.this,8);teams.addView(aLogo,ap);card.addView(teams,new LinearLayout.LayoutParams(-1,Ui.dp(FootballActivity.this,52)));
                state=Ui.text(FootballActivity.this,"",10,Ui.GREEN,true);state.setId(407);state.setGravity(Gravity.CENTER);card.addView(state,new LinearLayout.LayoutParams(-1,Ui.dp(FootballActivity.this,28)));convert=card;}else card=(LinearLayout)convert;
            league=convert.findViewById(401);hLogo=convert.findViewById(402);home=convert.findViewById(403);score=convert.findViewById(404);away=convert.findViewById(405);aLogo=convert.findViewById(406);state=convert.findViewById(407);ApiClient.FootballMatch m=matches.get(p);league.setText(m.league);home.setText(m.home);away.setText(m.away);score.setText(m.score.isEmpty()?"×":m.score);state.setText((m.clock.isEmpty()?"":m.clock+" • ")+m.status);ImageLoader.into(FootballActivity.this,hLogo,m.homeLogo);ImageLoader.into(FootballActivity.this,aLogo,m.awayLogo);return convert;}
    }
    private void immersive(){getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);}
}
