package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class DiscoverActivity extends Activity {
    private boolean phone; private LinearLayout body; private String smart,title;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);Ui.immersive(this);phone=Ui.phone(this);
        smart=clean(getIntent().getStringExtra("smart"),"kids");title=clean(getIntent().getStringExtra("title"),smart.toUpperCase());
        setContentView(build());
        if("explore".equals(smart)) renderExplore(); else load();
    }

    private View build(){
        LinearLayout root=Ui.column(this);root.setBackground(Ui.diagonalGradient(Ui.BG_2,Ui.BG,0,this));
        root.addView(header(),new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?56:64)));
        ScrollView s=new ScrollView(this);s.setVerticalScrollBarEnabled(false);s.setFillViewport(true);
        body=Ui.column(this);body.setPadding(Ui.dp(this,phone?14:26),Ui.dp(this,10),Ui.dp(this,phone?14:26),Ui.dp(this,24));
        s.addView(Ui.centered(this,body,1480),new ScrollView.LayoutParams(-1,-2));root.addView(s,new LinearLayout.LayoutParams(-1,0,1));return root;
    }

    private View header(){
        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(Ui.dp(this,18),0,Ui.dp(this,18),0);row.setBackgroundColor(Ui.GLASS_DARK);
        TextView brand=Ui.text(this,"▣  DUBAI PLAY",phone?13:16,Ui.TEXT,true);row.addView(brand,new LinearLayout.LayoutParams(Ui.dp(this,190),-1));
        addNav(row,"TV",false,()->startActivity(new Intent(this,LiveTvActivity.class)));
        addNav(row,"DESTAQUES",false,()->{Intent in=new Intent(this,MainActivity.class);in.putExtra("show_highlights",true);startActivity(in);});
        addNav(row,"FILMES",false,()->openCatalog("movie","Filmes",""));
        addNav(row,"SÉRIES",false,()->openCatalog("series","Séries",""));
        addNav(row,"KIDS","kids".equals(smart),()->openDiscover("kids","Kids"));
        addNav(row,"ANIME","anime".equals(smart),()->openDiscover("anime","Anime"));
        addNav(row,"EXPLORAR","explore".equals(smart),()->openDiscover("explore","Explorar"));
        row.addView(new View(this),new LinearLayout.LayoutParams(0,1,1));
        TextView search=Ui.ghostButton(this,"⌕");search.setOnClickListener(v->startActivity(new Intent(this,SearchActivity.class)));row.addView(search,new LinearLayout.LayoutParams(Ui.dp(this,42),Ui.dp(this,38)));
        return row;
    }

    private void addNav(LinearLayout row,String label,boolean selected,Runnable run){TextView v=Ui.nav(this,label,selected);v.setOnClickListener(x->run.run());row.addView(v,new LinearLayout.LayoutParams(Ui.dp(this,phone?72:96),Ui.dp(this,44)));}

    private void renderExplore(){
        body.removeAllViews();
        TextView h=Ui.text(this,"Explorar",phone?21:28,Ui.TEXT,true);body.addView(h,new LinearLayout.LayoutParams(-1,Ui.dp(this,48)));
        TextView sub=Ui.text(this,"Escolha o que quer assistir",11,Ui.MUTED,false);body.addView(sub,new LinearLayout.LayoutParams(-1,Ui.dp(this,30)));
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        addExploreMosaic(top,"FILMES","Cinema e lançamentos","movies",2.0f,0xFF182218);
        addExploreMosaic(top,"SÉRIES","Temporadas e episódios","series",1.0f,0xFF142018);
        addExploreMosaic(top,"ADULTOS","Acesso por categoria","adult",1.0f,0xFF121A13);
        body.addView(top,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?210:285)));
        LinearLayout bottom=new LinearLayout(this);bottom.setGravity(Gravity.CENTER_VERTICAL);
        addExploreMosaic(bottom,"KIDS","Conteúdo infantil","kids",1.0f,0xFF172319);
        addExploreMosaic(bottom,"ANIME","Animes e animações","anime",1.0f,0xFF122116);
        body.addView(bottom,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?155:205)));
    }

    private void addExploreMosaic(LinearLayout row,String name,String desc,String target,float weight,int fill){
        FrameLayout card=new FrameLayout(this);card.setFocusable(true);card.setClickable(true);Ui.focus(card,this,Ui.gradient(fill,Ui.PANEL,7,this),Ui.stroke(Ui.PANEL_2,Ui.GREEN,7,this));
        LinearLayout text=Ui.column(this);text.setPadding(Ui.dp(this,18),Ui.dp(this,15),Ui.dp(this,18),Ui.dp(this,14));
        TextView n=Ui.text(this,name,phone?18:24,Ui.TEXT,true);text.addView(n,new LinearLayout.LayoutParams(-1,0,1));
        TextView d=Ui.text(this,desc,10,Ui.MUTED,false);text.addView(d,new LinearLayout.LayoutParams(-1,Ui.dp(this,28)));card.addView(text,new FrameLayout.LayoutParams(-1,-1));
        card.setOnClickListener(v->{if("movies".equals(target)||"series".equals(target))openCatalog("movies".equals(target)?"movie":"series",name,"");else openDiscover(target,name);});
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,weight);p.rightMargin=Ui.dp(this,7);p.bottomMargin=Ui.dp(this,7);row.addView(card,p);
    }

    private void load(){
        body.removeAllViews();body.addView(Ui.text(this,"Carregando coleções...",12,Ui.MUTED,false),new LinearLayout.LayoutParams(-1,Ui.dp(this,70)));
        ApiClient.catalog("movie",1,36,"","",smart,new ApiClient.Callback<ApiClient.CatalogPage>(){
            public void ok(ApiClient.CatalogPage movies){ApiClient.catalog("series",1,36,"","",smart,new ApiClient.Callback<ApiClient.CatalogPage>(){
                public void ok(ApiClient.CatalogPage series){runOnUiThread(()->{body.removeAllViews();if("kids".equals(smart))renderKidsMosaic(movies.items,series.items);else{shelf("Filmes",movies.items,"movie");shelf("Séries",series.items,"series");}});}
                public void error(String m){runOnUiThread(()->{body.removeAllViews();if("kids".equals(smart))renderKidsMosaic(movies.items,new ArrayList<>());else shelf("Filmes",movies.items,"movie");});}
            });}
            public void error(String m){runOnUiThread(()->{body.removeAllViews();body.addView(Ui.text(DiscoverActivity.this,"Não foi possível carregar • "+m,12,Ui.RED,false),new LinearLayout.LayoutParams(-1,Ui.dp(DiscoverActivity.this,70)));});}
        });
    }

    private void renderKidsMosaic(List<ApiClient.Item> movies,List<ApiClient.Item> series){
        ArrayList<ApiClient.Item> all=new ArrayList<>();if(movies!=null)all.addAll(movies);if(series!=null)all.addAll(series);
        if(all.isEmpty()){body.addView(Ui.text(this,"Nenhum conteúdo Kids disponível",12,Ui.MUTED,false));return;}
        TextView h=Ui.text(this,"KIDS",phone?18:24,Ui.GREEN,true);body.addView(h,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));
        LinearLayout mosaic=new LinearLayout(this);mosaic.setGravity(Gravity.CENTER_VERTICAL);
        ApiClient.Item hero=item(all,0);FrameLayout big=mediaTile(hero,"TODOS",true);mosaic.addView(big,new LinearLayout.LayoutParams(0,-1,1.8f));
        LinearLayout mid=Ui.column(this);LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(0,-1,1f);mp.leftMargin=Ui.dp(this,5);mosaic.addView(mid,mp);
        FrameLayout a=mediaTile(item(all,1),"MAIS",false);FrameLayout b=mediaTile(item(all,2),"ANIMES",false);mid.addView(a,new LinearLayout.LayoutParams(-1,0,1));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,0,1);bp.topMargin=Ui.dp(this,5);mid.addView(b,bp);
        LinearLayout right=Ui.column(this);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(0,-1,1.15f);rp.leftMargin=Ui.dp(this,5);mosaic.addView(right,rp);
        FrameLayout c=mediaTile(item(all,3),"NOVIDADES",false);FrameLayout d=mediaTile(item(all,4),"AVENTURA",false);right.addView(c,new LinearLayout.LayoutParams(-1,0,1));LinearLayout.LayoutParams dp=new LinearLayout.LayoutParams(-1,0,1);dp.topMargin=Ui.dp(this,5);right.addView(d,dp);
        body.addView(mosaic,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?320:430)));
        shelf("Mais para crianças",all,"movie");
    }

    private ApiClient.Item item(List<ApiClient.Item> x,int n){return x.get(Math.min(n,x.size()-1));}

    private FrameLayout mediaTile(ApiClient.Item i,String label,boolean hero){
        FrameLayout box=new FrameLayout(this);box.setFocusable(true);box.setClickable(true);Ui.focus(box,this,Ui.round(Ui.PANEL,4,this),Ui.stroke(Ui.PANEL_2,Ui.GREEN,4,this));
        ImageView img=new ImageView(this);img.setScaleType(ImageView.ScaleType.CENTER_CROP);img.setBackgroundColor(Ui.PANEL_2);box.addView(img,new FrameLayout.LayoutParams(-1,-1));ImageLoader.into(this,img,clean(i.backdrop,i.logo));
        View shade=new View(this);shade.setBackground(Ui.verticalGradient(Color.TRANSPARENT,Color.argb(210,0,0,0),0,this));box.addView(shade,new FrameLayout.LayoutParams(-1,-1));
        TextView t=Ui.text(this,label,hero?16:13,Ui.TEXT,true);t.setGravity(Gravity.CENTER);t.setBackgroundColor(0x99101810);FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(-1,Ui.dp(this,hero?46:38),Gravity.BOTTOM);box.addView(t,tp);
        box.setOnClickListener(v->openItem(i));return box;
    }

    private void shelf(String label,List<ApiClient.Item> items,String type){
        if(items==null||items.isEmpty())return;LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);head.addView(Ui.text(this,label,phone?17:22,Ui.TEXT,true),new LinearLayout.LayoutParams(0,Ui.dp(this,44),1));
        TextView all=Ui.ghostButton(this,"VER TODOS");all.setOnClickListener(v->{Intent in=new Intent(this,CatalogActivity.class);in.putExtra("type",type);in.putExtra("title",label+" • "+title);in.putExtra("smart",smart);startActivity(in);});head.addView(all,new LinearLayout.LayoutParams(Ui.dp(this,100),Ui.dp(this,34)));body.addView(head,new LinearLayout.LayoutParams(-1,Ui.dp(this,48)));
        HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setHorizontalScrollBarEnabled(false);LinearLayout row=new LinearLayout(this);
        for(ApiClient.Item i:items){FrameLayout card=mediaTile(i,clean(i.name,"Sem nome"),false);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(Ui.dp(this,phone?130:165),Ui.dp(this,phone?180:225));cp.rightMargin=Ui.dp(this,8);row.addView(card,cp);}hsv.addView(row);body.addView(hsv,new LinearLayout.LayoutParams(-1,Ui.dp(this,phone?185:230)));
    }

    private void openItem(ApiClient.Item i){if(i==null)return;if("series".equals(i.type)){Intent in=new Intent(this,SeriesActivity.class);in.putExtra("title",clean(i.seriesTitle,i.name));startActivity(in);}else{Intent in=new Intent(this,DetailActivity.class);MainActivity.putItem(in,i);startActivity(in);}}
    private void openCatalog(String type,String name,String smartKey){Intent in=new Intent(this,CatalogActivity.class);in.putExtra("type",type);in.putExtra("title",name);in.putExtra("smart",smartKey);startActivity(in);}
    private void openDiscover(String key,String name){Intent in=new Intent(this,DiscoverActivity.class);in.putExtra("smart",key);in.putExtra("title",name);startActivity(in);}
    private String clean(String v,String f){if(v==null)return f;String s=v.trim();return s.isEmpty()||"null".equalsIgnoreCase(s)?f:s;}
}
