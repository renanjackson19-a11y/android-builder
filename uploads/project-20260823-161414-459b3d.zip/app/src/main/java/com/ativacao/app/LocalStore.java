package com.ativacao.app;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

final class LocalStore {
    private static final String PREF="dubai_play_local";
    private static final String HISTORY="history";
    private static final String FAVORITES="favorites";
    private static final String LAST_LIVE="last_live";
    private LocalStore(){}

    static void addHistory(Context c, ApiClient.Item item){ saveOne(c,HISTORY,item,true); }
    static void toggleFavorite(Context c, ApiClient.Item item){
        List<ApiClient.Item> all=read(c,FAVORITES); boolean removed=false;
        for(int i=all.size()-1;i>=0;i--) if(all.get(i).id==item.id){all.remove(i);removed=true;}
        if(!removed) all.add(0,item); write(c,FAVORITES,all,50);
    }
    static boolean isFavorite(Context c,long id){for(ApiClient.Item i:read(c,FAVORITES))if(i.id==id)return true;return false;}
    static List<ApiClient.Item> history(Context c){return read(c,HISTORY);}
    static List<ApiClient.Item> favorites(Context c){return read(c,FAVORITES);}
    static void saveLastLive(Context c, ApiClient.Item item){
        if(item==null||item.id<=0)return;
        List<ApiClient.Item> one=new ArrayList<>(); one.add(item); write(c,LAST_LIVE,one,1);
    }
    static ApiClient.Item lastLive(Context c){
        List<ApiClient.Item> one=read(c,LAST_LIVE);
        if(!one.isEmpty() && "live".equals(one.get(0).type)) return one.get(0);
        for(ApiClient.Item i:read(c,HISTORY)) if("live".equals(i.type)) return i;
        return null;
    }
    private static void saveOne(Context c,String key,ApiClient.Item item,boolean front){
        if(item==null||item.id<=0)return; List<ApiClient.Item> all=read(c,key); for(int i=all.size()-1;i>=0;i--)if(all.get(i).id==item.id)all.remove(i); if(front)all.add(0,item);else all.add(item); write(c,key,all,30);
    }
    private static List<ApiClient.Item> read(Context c,String key){
        List<ApiClient.Item> out=new ArrayList<>(); String raw=c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString(key,"[]");
        try{JSONArray a=new JSONArray(raw);for(int n=0;n<a.length();n++){JSONObject o=a.optJSONObject(n);if(o==null)continue;ApiClient.Item i=new ApiClient.Item();i.id=o.optLong("id");i.name=o.optString("name");i.logo=o.optString("logo");i.backdrop=o.optString("backdrop");i.group=o.optString("group");i.type=o.optString("type");i.format=o.optString("format","auto");i.seriesTitle=o.optString("seriesTitle");i.year=o.optInt("year");out.add(i);}}catch(Exception ignored){} return out;
    }
    private static void write(Context c,String key,List<ApiClient.Item> list,int max){
        JSONArray a=new JSONArray();int count=Math.min(max,list.size());for(int n=0;n<count;n++){ApiClient.Item i=list.get(n);JSONObject o=new JSONObject();try{o.put("id",i.id);o.put("name",i.name);o.put("logo",i.logo);o.put("backdrop",i.backdrop);o.put("group",i.group);o.put("type",i.type);o.put("format",i.format);o.put("seriesTitle",i.seriesTitle);o.put("year",i.year);a.put(o);}catch(Exception ignored){}}
        c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putString(key,a.toString()).apply();
    }
}
