package fun.greenplay.tv.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import fun.greenplay.tv.api.ApiClient
import fun.greenplay.tv.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

data class HomeUi(val loading:Boolean=true, val sections:List<HomeSection> = emptyList(), val error:String?=null)
data class DetailUi(val loading:Boolean=false, val item:DetailItem?=null, val error:String?=null)

class GreenPlayViewModel: ViewModel() {
    private val _home = MutableStateFlow(HomeUi())
    val home: StateFlow<HomeUi> = _home
    private val _detail = MutableStateFlow(DetailUi())
    val detail: StateFlow<DetailUi> = _detail

    init { loadHome() }
    fun loadHome() = viewModelScope.launch {
        _home.value = HomeUi(loading=true)
        runCatching { ApiClient.api.home(24) }
            .onSuccess { _home.value = HomeUi(false, it.sections, null) }
            .onFailure { _home.value = HomeUi(false, emptyList(), it.message ?: "Falha ao carregar") }
    }
    fun loadDetails(type:String,id:String)=viewModelScope.launch {
        _detail.value=DetailUi(true)
        runCatching { ApiClient.api.details(type,id) }
            .onSuccess { _detail.value=DetailUi(false,it.item,it.message) }
            .onFailure { _detail.value=DetailUi(false,null,it.message ?: "Falha") }
    }
    suspend fun getPlay(type:String,id:String,episode:Int?=null): PlayResponse = ApiClient.api.play(type,id,episode)
}
