package fun.greenplay.tv

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.tv.material3.*
import coil.compose.AsyncImage
import fun.greenplay.tv.model.CatalogItem
import fun.greenplay.tv.player.PlayerActivity
import fun.greenplay.tv.ui.GreenPlayViewModel

private val Bg = Color(0xFF090B0D)
private val Green = Color(0xFF20D96B)

class MainActivity: ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { GreenPlayHome { openDetails(it) } } }
    }
    private fun openDetails(item: CatalogItem) {
        startActivity(Intent(this, DetailActivity::class.java).putExtra("id",item.id).putExtra("type",item.type).putExtra("title",item.title).putExtra("poster",item.poster))
    }
}

@Composable fun GreenPlayHome(vm: GreenPlayViewModel = viewModel(), onOpen:(CatalogItem)->Unit) {
    val state by vm.home.collectAsState()
    Box(Modifier.fillMaxSize().background(Bg)) {
        when {
            state.loading -> CircularProgressIndicator(Modifier.align(Alignment.Center), color=Green)
            state.error != null -> Text("Erro: ${state.error}", color=Color.White, modifier=Modifier.align(Alignment.Center))
            else -> LazyColumn(Modifier.fillMaxSize().padding(top=24.dp), verticalArrangement=Arrangement.spacedBy(24.dp)) {
                item {
                    Row(Modifier.fillMaxWidth().padding(horizontal=42.dp), verticalAlignment=Alignment.CenterVertically) {
                        Text("GREEN", color=Green, fontSize=30.sp, fontWeight=FontWeight.ExtraBold)
                        Text("PLAY", color=Color.White, fontSize=30.sp, fontWeight=FontWeight.ExtraBold)
                        Spacer(Modifier.width(36.dp)); Text("Início", color=Color.White, fontSize=18.sp)
                        Spacer(Modifier.width(28.dp)); Text("Filmes", color=Color.LightGray, fontSize=18.sp)
                        Spacer(Modifier.width(28.dp)); Text("Séries", color=Color.LightGray, fontSize=18.sp)
                    }
                }
                items(state.sections) { sec ->
                    Column {
                        Text(sec.title, color=Color.White, fontSize=23.sp, fontWeight=FontWeight.SemiBold, modifier=Modifier.padding(horizontal=42.dp, vertical=8.dp))
                        LazyRow(contentPadding=PaddingValues(horizontal=42.dp), horizontalArrangement=Arrangement.spacedBy(14.dp)) {
                            items(sec.items, key={sec.id+it.id}) { item -> PosterCard(item,onOpen) }
                        }
                    }
                }
                item { Spacer(Modifier.height(30.dp)) }
            }
        }
    }
}

@Composable fun PosterCard(item: CatalogItem, onOpen:(CatalogItem)->Unit) {
    var focused by remember { mutableStateOf(false) }
    Surface(onClick={onOpen(item)}, modifier=Modifier.width(if(focused) 162.dp else 148.dp).height(if(focused) 244.dp else 224.dp).onFocusChanged{focused=it.isFocused}, shape=RoundedCornerShape(7.dp), colors=SurfaceDefaults.colors(containerColor=Color(0xFF171A1E))) {
        Column {
            AsyncImage(model=item.poster, contentDescription=item.title, contentScale=ContentScale.Crop, modifier=Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(topStart=7.dp, topEnd=7.dp)))
            Text(item.title, color=Color.White, maxLines=1, overflow=TextOverflow.Ellipsis, fontSize=14.sp, modifier=Modifier.padding(8.dp))
        }
    }
}
