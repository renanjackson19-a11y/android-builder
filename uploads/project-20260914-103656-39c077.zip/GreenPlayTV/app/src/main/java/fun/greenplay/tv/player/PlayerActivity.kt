package fun.greenplay.tv.player

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class PlayerActivity: ComponentActivity() {
    private var player: ExoPlayer? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val url=intent.getStringExtra("url") ?: return finish()
        player=ExoPlayer.Builder(this).build().also { p ->
            val view=PlayerView(this); view.player=p; view.useController=true; setContentView(view)
            p.setMediaItem(MediaItem.fromUri(url)); p.prepare(); p.playWhenReady=true
        }
    }
    override fun onPause(){ super.onPause(); player?.pause() }
    override fun onDestroy(){ player?.release(); player=null; super.onDestroy() }
}
