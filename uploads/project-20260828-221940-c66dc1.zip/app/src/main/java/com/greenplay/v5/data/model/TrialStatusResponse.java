package com.greenplay.v5.data.model;

import com.google.gson.annotations.SerializedName;

public final class TrialStatusResponse {
    public boolean ok;
    public boolean enabled;
    public boolean eligible;
    public boolean used;
    public boolean active;
    public String message;
    @SerializedName("trial_hours") public int trialHours;
    @SerializedName("expires_at") public String expiresAt;
    @SerializedName("remaining_today") public int remainingToday;
}
