package com.ativacao.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class LoginActivity extends Activity {
    private EditText user,pass; private TextView message,serverBadge,enter,trial,brandMark,loadTitle,loadStep; private ImageView bgImage,brandLogo; private FrameLayout loadingOverlay; private boolean phone; private int trialHours=3;
    @Override public void onCreate(Bundle b){super.onCreate(b);ApiClient.setUserToken(Session.token(this));getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);Ui.immersive(this);if(Session.isLogged(this)){openHome();return;}phone=Ui.phone(this);setContentView(build());checkServer();}
    @Override protected void onResume(){super.onResume();Ui.immersive(this);}

    private View build(){
        FrameLayout root=new FrameLayout(this); root.setBackgroundColor(Color.BLACK);

        // O painel controla toda a arte do login. A imagem ocupa a tela inteira, sem overlays no lado esquerdo.
        bgImage=new ImageView(this); bgImage.setScaleType(ImageView.ScaleType.CENTER_CROP); bgImage.setBackgroundColor(0xFF020705);
        root.addView(bgImage,new FrameLayout.LayoutParams(-1,-1));

        // Sombra suave somente atrás do formulário para garantir leitura sem esconder o fundo personalizado.
        View rightShade=new View(this);
        rightShade.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0x00000000,0x52000000,0xA8000000}));
        FrameLayout.LayoutParams shadeLp=new FrameLayout.LayoutParams(phone?Math.round(getResources().getDisplayMetrics().widthPixels*0.72f):Math.round(getResources().getDisplayMetrics().widthPixels*0.58f),-1,Gravity.RIGHT);
        root.addView(rightShade,shadeLp);

        // Formulário no mesmo posicionamento da referência: solto sobre o fundo, sem card/borda externa.
        LinearLayout right=Ui.column(this); right.setGravity(Gravity.CENTER_VERTICAL);
        int padX=Ui.dp(this,phone?20:34); right.setPadding(padX,Ui.dp(this,phone?18:24),padX,Ui.dp(this,phone?18:24));
        FrameLayout.LayoutParams rightLp=new FrameLayout.LayoutParams(phone?Math.round(getResources().getDisplayMetrics().widthPixels*0.72f):Math.round(getResources().getDisplayMetrics().widthPixels*0.48f),-1,Gravity.RIGHT);
        rightLp.rightMargin=Ui.dp(this,phone?10:28); root.addView(right,rightLp);

        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView head=Ui.text(this,"BEM-VINDO!",phone?23:30,Color.WHITE,true); top.addView(head,new LinearLayout.LayoutParams(0,Ui.dp(this,42),1));
        serverBadge=Ui.text(this,"●",phone?12:14,Ui.GREEN,true); serverBadge.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); top.addView(serverBadge,new LinearLayout.LayoutParams(Ui.dp(this,28),Ui.dp(this,36)));
        right.addView(top,new LinearLayout.LayoutParams(-1,Ui.dp(this,44)));

        TextView desc=Ui.text(this,"Digite seu usuário e senha para acessar o aplicativo.",phone?10:12,0xFFD0D4D2,false);
        LinearLayout.LayoutParams descLp=new LinearLayout.LayoutParams(-1,Ui.dp(this,30)); descLp.bottomMargin=Ui.dp(this,10); right.addView(desc,descLp);

        right.addView(label("Usuário"),new LinearLayout.LayoutParams(-1,Ui.dp(this,22)));
        user=field("Por favor insira seu usuário",false); LinearLayout.LayoutParams up=new LinearLayout.LayoutParams(-1,Ui.dp(this,58)); up.bottomMargin=Ui.dp(this,14); right.addView(user,up);

        right.addView(label("Senha"),new LinearLayout.LayoutParams(-1,Ui.dp(this,22)));
        FrameLayout passBox=new FrameLayout(this); pass=field("Por favor insira sua senha",true); passBox.addView(pass,new FrameLayout.LayoutParams(-1,Ui.dp(this,58)));
        TextView eye=Ui.text(this,"◉",22,Ui.GREEN,true); eye.setGravity(Gravity.CENTER); eye.setFocusable(true); eye.setClickable(true);
        FrameLayout.LayoutParams eyp=new FrameLayout.LayoutParams(Ui.dp(this,58),Ui.dp(this,58),Gravity.RIGHT|Gravity.CENTER_VERTICAL); passBox.addView(eye,eyp); pass.setPadding(Ui.dp(this,20),0,Ui.dp(this,62),0);
        final boolean[] showing={false}; eye.setOnClickListener(v->{showing[0]=!showing[0];int pos=pass.getSelectionStart();pass.setInputType(InputType.TYPE_CLASS_TEXT|(showing[0]?InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD:InputType.TYPE_TEXT_VARIATION_PASSWORD));pass.setSelection(Math.max(0,Math.min(pos,pass.length())));eye.setText(showing[0]?"◌":"◉");});
        LinearLayout.LayoutParams pbp=new LinearLayout.LayoutParams(-1,Ui.dp(this,58)); pbp.bottomMargin=Ui.dp(this,16); right.addView(passBox,pbp);

        enter=Ui.primaryButton(this,"↪   ENTRAR"); LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,Ui.dp(this,58)); right.addView(enter,ep);
        TextView test=Ui.button(this,"⌁   TESTAR CONEXÃO"); LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,Ui.dp(this,50)); tp.topMargin=Ui.dp(this,12); right.addView(test,tp);
        trial=Ui.button(this,"◷   TESTE AUTOMÁTICO  •  3 HORAS"); LinearLayout.LayoutParams trp=new LinearLayout.LayoutParams(-1,Ui.dp(this,50)); trp.topMargin=Ui.dp(this,10); right.addView(trial,trp);
        message=Ui.text(this,"",10,Ui.MUTED,false); message.setGravity(Gravity.CENTER); LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,Ui.dp(this,22)); mp.topMargin=Ui.dp(this,4); right.addView(message,mp);

        // Informações discretas sobre o próprio fundo, como na referência.
        TextView dev=Ui.text(this,"▣  ID Dispositivo: "+DeviceInfo.macOrId(this)+"\nⓘ  Versão: 4.0.124",phone?9:11,0xFFE0E6E2,false);
        dev.setLineSpacing(Ui.dp(this,2),1.15f);
        FrameLayout.LayoutParams devLp=new FrameLayout.LayoutParams(phone?Ui.dp(this,340):Ui.dp(this,470),Ui.dp(this,54),Gravity.LEFT|Gravity.BOTTOM);
        devLp.leftMargin=Ui.dp(this,phone?18:52); devLp.bottomMargin=Ui.dp(this,phone?16:28); root.addView(dev,devLp);

        // Objetos mantidos apenas para compatibilidade com a configuração de marca do painel.
        brandLogo=new ImageView(this); brandMark=null;

        enter.setOnClickListener(v->doLogin()); trial.setOnClickListener(v->doTrial()); test.setOnClickListener(v->showDiagnostic());
        pass.setOnEditorActionListener((v,a,e)->{doLogin();return true;}); user.requestFocus();
        loadingOverlay=buildLoadingOverlay(); root.addView(loadingOverlay,new FrameLayout.LayoutParams(-1,-1)); loadingOverlay.setVisibility(View.GONE); return root;
    }
    private TextView label(String s){return Ui.text(this,s,10,Color.WHITE,true);}
    private EditText field(String hint,boolean password){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(0xFF727B86);e.setTextColor(Color.WHITE);e.setTextSize(phone?12:14);e.setSingleLine(true);e.setPadding(Ui.dp(this,18),0,Ui.dp(this,18),0);e.setBackground(Ui.stroke(0xD9141921,0xFF33414B,28,this));if(password)e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);e.setOnFocusChangeListener((v,f)->e.setBackground(Ui.stroke(0xD9141921,f?Ui.GREEN:0xFF33414B,28,this)));return e;}
    private void doLogin(){String u=user.getText().toString().trim(),p=pass.getText().toString();if(u.isEmpty()||p.isEmpty()){message.setText("Informe usuário e senha.");message.setTextColor(Ui.RED);return;}enter.setEnabled(false);enter.setText("ENTRANDO...");message.setText("Validando acesso...");message.setTextColor(Ui.MUTED);ApiClient.login(u,p,DeviceInfo.macOrId(this),new ApiClient.Callback<ApiClient.LoginResult>(){public void ok(ApiClient.LoginResult r){runOnUiThread(()->{Session.save(LoginActivity.this,r.username,r.expiresAt,r.plan,r.adultAccess,r.bouquet,r.userToken);ApiClient.setUserToken(r.userToken);if(CatalogPreloader.isPrepared(LoginActivity.this)){message.setText("Conteúdo pronto.");openHome();}else{startInitialPreparation();}});}public void error(String m){runOnUiThread(()->{enter.setEnabled(true);enter.setText("ENTRAR");message.setText(m);message.setTextColor(Ui.RED);});}});}
    private void checkServer(){ApiClient.statusInfo(new ApiClient.Callback<ApiClient.AppStatus>(){public void ok(ApiClient.AppStatus st){runOnUiThread(()->{serverBadge.setText("● SERVIDOR ONLINE");serverBadge.setTextColor(Ui.GREEN);trialHours=Math.max(1,st.trialHours);trial.setVisibility(View.VISIBLE);trial.setEnabled(st.trialEnabled);trial.setText((st.trialEnabled?"TESTE AUTOMÁTICO • ":"TESTE INDISPONÍVEL • ")+trialHours+(trialHours==1?" HORA":" HORAS"));if(st.loginBackground!=null&&!st.loginBackground.trim().isEmpty())ImageLoader.into(LoginActivity.this,bgImage,st.loginBackground); if(st.appLogo!=null&&!st.appLogo.trim().isEmpty()){BrandConfig.save(LoginActivity.this,st.appLogo);}});}public void error(String m){runOnUiThread(()->{serverBadge.setText("● SERVIDOR OFFLINE");serverBadge.setTextColor(Ui.RED);trial.setEnabled(false);trial.setText("TESTE AUTOMÁTICO • SERVIDOR OFFLINE");});}});}
    private void doTrial(){if(trial==null)return;trial.setEnabled(false);trial.setText("CRIANDO TESTE...");message.setText("Gerando acesso de teste...");message.setTextColor(Ui.MUTED);ApiClient.trial(DeviceInfo.macOrId(this),new ApiClient.Callback<ApiClient.LoginResult>(){public void ok(ApiClient.LoginResult r){runOnUiThread(()->{Session.save(LoginActivity.this,r.username,r.expiresAt,r.plan,r.adultAccess,r.bouquet,r.userToken);ApiClient.setUserToken(r.userToken);if(CatalogPreloader.isPrepared(LoginActivity.this)){message.setText("Conteúdo pronto.");openHome();}else{startInitialPreparation();}});}public void error(String m){runOnUiThread(()->{trial.setEnabled(true);trial.setText("TESTE AUTOMÁTICO • "+trialHours+(trialHours==1?" HORA":" HORAS"));message.setText(m);message.setTextColor(Ui.RED);});}});}
    private FrameLayout buildLoadingOverlay(){
        FrameLayout ov=new FrameLayout(this); ov.setBackgroundColor(0xF7000905); ov.setClickable(true); ov.setFocusable(true);
        LinearLayout box=Ui.column(this); box.setGravity(Gravity.CENTER); box.setPadding(Ui.dp(this,24),Ui.dp(this,24),Ui.dp(this,24),Ui.dp(this,24));
        ImageView logo=new ImageView(this); logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE); String l=BrandConfig.logo(this); if(l!=null&&!l.trim().isEmpty())ImageLoader.into(this,logo,l); else logo.setImageResource(R.mipmap.ic_launcher);
        box.addView(logo,new LinearLayout.LayoutParams(Ui.dp(this,180),Ui.dp(this,82)));
        loadTitle=Ui.text(this,"Preparando seu conteúdo",phone?20:27,Color.WHITE,true); loadTitle.setGravity(Gravity.CENTER); LinearLayout.LayoutParams t=new LinearLayout.LayoutParams(-1,Ui.dp(this,48)); t.topMargin=Ui.dp(this,12); box.addView(loadTitle,t);
        loadStep=Ui.text(this,"Atualizando canais, filmes e séries...",phone?11:14,Ui.MUTED,true); loadStep.setGravity(Gravity.CENTER); box.addView(loadStep,new LinearLayout.LayoutParams(-1,Ui.dp(this,34)));
        TextView hint=Ui.text(this,"Isso acontece somente na primeira entrada deste cliente.",phone?9:11,0xFF8FA79A,false); hint.setGravity(Gravity.CENTER); box.addView(hint,new LinearLayout.LayoutParams(-1,Ui.dp(this,28)));
        FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(phone?Ui.dp(this,560):Ui.dp(this,720),Ui.dp(this,240),Gravity.CENTER); ov.addView(box,bp); return ov;
    }

    private void startInitialPreparation(){
        if(loadingOverlay!=null){loadingOverlay.setVisibility(View.VISIBLE);loadingOverlay.bringToFront();loadingOverlay.requestFocus();}
        CatalogPreloader.start(this,true,(text,done,total)->runOnUiThread(()->{
            if(loadStep!=null)loadStep.setText(text+(total>0?"   "+done+"/"+total:""));
        }),()->runOnUiThread(this::openHome));
    }

    private boolean hasNetwork(){try{ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);NetworkInfo n=cm==null?null:cm.getActiveNetworkInfo();return n!=null&&n.isConnected();}catch(Throwable e){return false;}}
    private void showDiagnostic(){final Dialog d=new Dialog(this);d.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout box=Ui.column(this);box.setPadding(Ui.dp(this,24),Ui.dp(this,20),Ui.dp(this,24),Ui.dp(this,20));box.setBackground(Ui.stroke(Ui.PANEL,Ui.BORDER,18,this));TextView t=Ui.text(this,"Diagnóstico de rede",18,Ui.TEXT,true);t.setGravity(Gravity.CENTER);box.addView(t,new LinearLayout.LayoutParams(-1,Ui.dp(this,40)));LinearLayout steps=new LinearLayout(this);steps.setGravity(Gravity.CENTER);TextView a=step("BOX",Ui.GREEN),b=step("REDE",hasNetwork()?Ui.GREEN:Ui.RED),c=step("INTERNET",hasNetwork()?Ui.GREEN:Ui.RED),s=step("SERVIDOR",Ui.MUTED);for(TextView v:new TextView[]{a,b,c,s}){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(Ui.dp(this,95),Ui.dp(this,60));p.leftMargin=Ui.dp(this,5);p.rightMargin=Ui.dp(this,5);steps.addView(v,p);}box.addView(steps,new LinearLayout.LayoutParams(-1,Ui.dp(this,72)));TextView result=Ui.text(this,"Testando servidor...",11,Ui.MUTED,true);result.setGravity(Gravity.CENTER);box.addView(result,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));TextView close=Ui.button(this,"FECHAR");close.setOnClickListener(v->d.dismiss());box.addView(close,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));d.setContentView(box);Window w=d.getWindow();d.show();if(w!=null){w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));w.setLayout(Math.min(Ui.dp(this,520),getResources().getDisplayMetrics().widthPixels-Ui.dp(this,24)),WindowManager.LayoutParams.WRAP_CONTENT);}ApiClient.status(new ApiClient.Callback<String>(){public void ok(String x){runOnUiThread(()->{s.setTextColor(Ui.GREEN);result.setText("✓ Servidor online e acessível");result.setTextColor(Ui.GREEN);});}public void error(String m){runOnUiThread(()->{s.setTextColor(Ui.RED);result.setText("Falha: "+m);result.setTextColor(Ui.RED);});}});}
    private TextView step(String txt,int color){TextView v=Ui.text(this,"●\n"+txt,10,color,true);v.setGravity(Gravity.CENTER);v.setBackground(Ui.stroke(Color.rgb(12,16,20),color,11,this));return v;}
    private void openHome(){Intent in=new Intent(this,LiveTvActivity.class);in.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(in);finish();}
}
