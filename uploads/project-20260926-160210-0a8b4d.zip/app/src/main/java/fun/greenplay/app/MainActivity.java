package fun.greenplay.app;
import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.graphics.drawable.*;import android.net.Uri;import android.text.InputType;import android.view.*;import android.widget.*;import org.json.*;import java.util.*;
public class MainActivity extends Activity{ // GreenPlay 5.28.37
 android.app.Dialog vpnBlockDialog; android.net.ConnectivityManager.NetworkCallback vpnWatch; boolean vpnStartupBlocked=false; android.os.Handler vpnPollHandler=new android.os.Handler(android.os.Looper.getMainLooper()); Runnable vpnPollTask;
 interface PreparedHomeCB{void ok(JSONObject j);void err(String e);} interface DetailPrepareCB{void done(JSONObject d);} interface LiveProbeCB{void done(boolean hasLive,boolean known,JSONArray sample);} interface ScreenResolveCB{void done(int used,int total);}
 static final int REQ_PROFILE_PHOTO=8601,REQ_FOOTBALL_NOTIFICATIONS=8602; int mobileBottomInsetPx=0; static final int TAG_SKIP_TV_FOCUS_FX=0x4f120001; static final int TAG_EPG_LOADING=0x4f120002; static final int TAG_SCROLL_TOP_INSTALLED=0x4f120003; int GREEN=Color.rgb(255,79,154); final int BG=Color.rgb(12,7,11),CARD=Color.rgb(31,16,25); LinearLayout root,body,navBar,continueHost,detailNavOverlay; boolean tvMode=false; java.util.WeakHashMap<View,Boolean> tvFocusArmed=new java.util.WeakHashMap<>(); FrameLayout contentFrame; ScrollView mainScroll,savedScroll,homeScrollCache,sectionParentScroll; LinearLayout savedBody,homeBodyCache,tvPageRoot,sectionParentBody; ImageView homeHeaderLogo,tvEpgLogo,tvPreviewLoadingLogo; TextView homeHeaderBrandFallback; ProgressBar tvPreviewLoadingProgress; TextView tvPreviewLoadingStatus; int homeScrollY=0,sectionParentScrollY=0,sectionParentViewGen=0; boolean homeViewAvailable=false,sectionPageOpen=false; String sectionReturnTab=""; TextView navHome,navFav,navTv,navFootball,navMovies,navSeries,navShorts,navKids,navDownloads,navProfile,scrollTopButton; ScrollView scrollTopHost; ImageView globalCastButton; android.content.SharedPreferences sp; String uid="",reseller="",appName="Yelly Doramas",logoUrl="",bgUrl=""; boolean authScreen=false,detailOpen=false,searchScreenOpen=false,exitDialogOpen=false,providerSwitchScreen=false,plansScreen=false,providerAvailabilityCheckBusy=false,tvImeActive=false; java.util.WeakHashMap<EditText,Boolean> tvInputArmed=new java.util.WeakHashMap<>(); long providerAvailabilityLastCheck=0; int liveOffset=0,currentNavIndex=0,savedNavIndex=0,savedViewGen=0,requestedStartNav=-1; String liveSearch="",activeHomeTab="Shorts",homeCachedTab="",tvPendingCategoryHint="",footballSelectedDate=""; boolean footballPrefetchBusy=false,openFootballFromNotification=false; LinearLayout liveListHost,tvCategoryHost,tvChannelHost,tvPreviewPlaceholder; TextView liveState,tvPreviewTitle,tvPreviewSubtitle,tvNowPlaying,tvEpgNow,tvEpgNext,tvSoundButton,tvCastButton,tvFullButton; EditText liveSearchBox; String tvSelectedCategory=""; int tvFocusedCategoryIndex=-1; FrameLayout tvPreviewFrame; ImageView tvVideoBackdrop; androidx.media3.ui.PlayerView tvInlinePlayerView; androidx.media3.exoplayer.ExoPlayer tvInlinePlayer; int tvVideoWidth=0,tvVideoHeight=0; float tvVideoPixelRatio=1f; boolean tvBackdropCapturePending=false; Runnable tvBackdropBeat; JSONObject tvActiveChannel; ScrollView tvCategoryScroll,tvChannelScroll; HorizontalScrollView tvCategoryRail; View tvTopBar,tvTabsBar,tvPanesView,tvWideLeftPanel; LinearLayout tvWideSplit; boolean tvCinemaMode=false,tvCinemaDrawerOpen=false; boolean tvInlineMuted=false,tvInlinePrepared=false,tvInlineSessionHeld=false,tvInlineSessionAcquiring=false,tvResumeAfterFullscreen=false,tvInlineFullscreen=false,tvInlineSwitching=false,tvResumeAfterBackground=false,tvOrientationTransition=false,tvUiTransitioning=false,tvAutoPlayPending=false; int tvInlineSourceIndex=0,tvInlineFormatAttemptIndex=-1,tvInlineFormatAttemptMask=0,tvInlineFormatMode=0,tvInlineBufferStarts=0,tvSavedScrollY=0,tvEpgRequestToken=0,tvInlineRecoveryCount=0; long tvInlineLastBufferAt=0,tvBackgroundAt=0,tvInlineBufferingSince=0,tvInlineLastPosition=-1,tvInlineLastAdvanceAt=0; java.util.ArrayList<String> tvInlineSources=new java.util.ArrayList<>(); Handler tvInlineHandler=new Handler(Looper.getMainLooper()); Runnable tvInlineBeat,tvInlinePendingAcquire,tvEpgBeat,tvInlineWatchdog,tvEpgHide; View tvEpgOverlay; ViewGroup tvPreviewHomeParent; ViewGroup.LayoutParams tvPreviewHomeLayoutParams; int tvPreviewHomeIndex=-1; int viewGen=0; int featuredShuffleTick=0; boolean homeExtrasStarted=false; boolean sessionHasLive=false,sessionLiveKnown=false,planLiveAllowed=true,planAdultAllowed=true; int planScreens=1; String activePlanName=""; int planFlowStage=0; android.os.CountDownTimer pixTimer=null; static JSONObject preparedHomeData=null; static String preparedHomeProvider=""; java.util.HashMap<String,String> detailMemoryCache=new java.util.HashMap<>(); java.util.ArrayDeque<JSONObject> detailPrefetchQueue=new java.util.ArrayDeque<>(); java.util.HashSet<String> detailPrefetchKeys=new java.util.HashSet<>(); int detailPrefetchActive=0; boolean detailPreparing=false; View detailPrepareOverlay,accessExpiredOverlay; LinearLayout activeSeriesResumeHost; JSONObject activeSeriesDetail,activeSeriesSource; boolean modeSwitchPending=false,modeSwitchTargetTv=false,modeSwitchOrientationReady=false,modeSwitchImagesReady=false,modeReloadScreen=false; JSONObject modeSwitchCache=null; final Handler modeSwitchHandler=new Handler(Looper.getMainLooper()); Runnable modeSwitchFallback=null; JSONArray modeReadyFeatured=null; ProgressBar modeTransitionProgress=null; TextView modeTransitionPercent=null,modeTransitionStatus=null,modeTransitionDetail=null; Runnable tvQueuedChannelSwitch=null; JSONObject tvQueuedChannel=null; int tvChannelSwitchGeneration=0,tvPlaybackGeneration=0; JSONArray tvCurrentChannels=new JSONArray(); FrameLayout tvFullscreenChannelOverlay=null; HorizontalScrollView tvFullscreenChannelScroll=null; LinearLayout tvFullscreenChannelRow=null; boolean tvFullscreenChannelOverlayVisible=false; int tvFullscreenOverlayIndex=-1; Runnable tvFullscreenOverlayHide=null; long tvFullscreenLastNavAt=0; int tvChannelListGeneration=0,tvBrowserGridGeneration=0; Runnable tvChannelRefreshTask=null; boolean tvChannelChunkPending=false; GridLayout tvShortsGrid=null; int tvShortsCardW=0,tvShortsGridGen=0; ScrollView tvCatalogGridScroll=null; GridLayout tvCatalogGrid=null; androidx.recyclerview.widget.RecyclerView tvCatalogRecycler=null; TextView tvCatalogState=null; TvCatalogAdapter tvCatalogAdapter=null; JSONArray tvCatalogRows=new JSONArray(); int tvCatalogNextIndex=0,tvCatalogCols=6,tvCatalogCardW=0,tvCatalogImgH=0,tvCatalogGap=0,tvCatalogRenderRequest=0; boolean tvCatalogChunkPending=false; final Handler tvHeaderNavHandler=new Handler(Looper.getMainLooper()); boolean tvHeaderNavBusy=false; Runnable tvHeaderNavUnlock=null;
 interface AllPagesCB{void ok(JSONArray rows);void err(String error);}
 interface PersistentHomeCB{void ok(JSONObject j);void miss();}
 static final long HOME_INACTIVITY_RESYNC_MS=72L*60L*60L*1000L;
 static final long HOME_BACKGROUND_REFRESH_MS=12L*60L*60L*1000L;
 static final java.util.concurrent.ExecutorService CATALOG_IO=java.util.concurrent.Executors.newSingleThreadExecutor();
 boolean persistentHomeReadPending=false; boolean catalogPrefetchBusy=false,catalogTabPrepareBusy=false; String catalogTabPending=""; long catalogPrefetchAt=0L; GridLayout mobileCategoryGrid=null; JSONArray mobileCategoryRows=new JSONArray(); int mobileCategoryNextIndex=0,mobileCategoryCardW=0,mobileCategoryGen=0; boolean mobileCategoryChunkPending=false; int mobileCategoryTypeId=0,mobileCategoryNextPageNo=1,mobileCategoryNetworkTotal=0,mobileCategoryNetworkRetries=0; String mobileCategoryId=""; boolean mobileCategoryNetworkBusy=false,mobileCategoryNetworkDone=false,mobileCategoryGreenShorts=false; java.util.HashSet<String> mobileCategorySeen=new java.util.HashSet<>(); LinearLayout mobileCategoryLoadingFooter=null; TextView mobileCategoryLoadingText=null; ProgressBar mobileCategoryLoadingProgress=null;
 final java.util.HashMap<String,String[]> tvEpgCache=new java.util.HashMap<>(); final java.util.HashMap<String,Long> tvEpgCacheAt=new java.util.HashMap<>(); static final long TV_EPG_CACHE_MS=50000L;
 boolean playerRoundTrip=false; ScrollView playerReturnScroll=null; LinearLayout playerReturnBody=null; int playerReturnY=0,playerReturnNav=0; String playerReturnTab="";
 public void onCreate(Bundle b){super.onCreate(b);SecurityGuard.hardenWebView();new Handler(Looper.getMainLooper()).postDelayed(()->AppUpdater.check(this),1200);if(SecurityGuard.vpnActive(this)){vpnStartupBlocked=true;showVpnBlocked(true);return;}sp=getSharedPreferences("yelly",0);tvMode=DeviceCompat.isTelevisionDevice(this)||sp.getBoolean("force_tv_mode",false);requestedStartNav=getIntent()!=null?getIntent().getIntExtra("gp_restore_nav",-1):-1;openFootballFromNotification=false;configureWindowForCurrentMode();migrateLegacyOfflineDownloads();uid=sp.getString("uid","");reseller=sp.getString("reseller","");Api.PROVIDER="";loadIdentityCache();boolean modeChange=getIntent()!=null&&getIntent().getBooleanExtra("gp_mode_change",false);boolean hardModeReload=getIntent()!=null&&getIntent().getBooleanExtra("gp_hard_mode_reload",false);if(uid.isEmpty()){authScreen=false;startYellyStartupSync(()->shell());}else if(hardModeReload)startAfterHardModeReload();else if(modeChange)startAfterModeChange();else startExistingSession();refreshIdentity();}
 @Override protected void onResume(){super.onResume();new Handler(Looper.getMainLooper()).postDelayed(()->AppUpdater.check(this),700);if(vpnStartupBlocked||SecurityGuard.vpnActive(this)){showVpnBlocked(vpnStartupBlocked);return;}startVpnWatch();if(tvMode&&!modeSwitchPending&&!tvImeActive)enterTvImmersiveUi();if(!wideTvUi())enforceGlobalBottomNav();updateGlobalCastButtonState();if(detailOpen&&activeSeriesResumeHost!=null&&activeSeriesDetail!=null)renderSeriesResume(activeSeriesSource,activeSeriesDetail,activeSeriesResumeHost);if(tvResumeAfterFullscreen){tvResumeAfterFullscreen=false;}if(playerRoundTrip)new Handler(Looper.getMainLooper()).postDelayed(()->restorePlayerReturnState(),60);}
 @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);if(i!=null&&i.getBooleanExtra("gp_open_football",false)){openFootballFromNotification=true;if(uid!=null&&!uid.isEmpty()&&body!=null){openFootballFromNotification=false;openTvFootball();}}}
 @Override protected void onPause(){stopVpnWatch();try{if(!tvOrientationTransition){tvResumeAfterBackground=tvInlinePlayer!=null&&tvActiveChannel!=null;tvBackgroundAt=android.os.SystemClock.elapsedRealtime();if(tvInlinePlayer!=null)tvInlinePlayer.pause();}}catch(Exception ignored){}super.onPause();}
 @Override protected void onStop(){try{if(!tvOrientationTransition&&tvInlinePlayer!=null)tvInlinePlayer.pause();}catch(Exception ignored){}super.onStop();}
 @Override protected void onDestroy(){try{destroyTvInlinePlayer();}catch(Exception ignored){}try{getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);}catch(Exception ignored){}super.onDestroy();}
 @Override public void onLowMemory(){super.onLowMemory();if(!modeSwitchPending)trimGreenPlayMemory(true);}
 @Override public void onTrimMemory(int level){super.onTrimMemory(level);if(!modeSwitchPending&&level>=android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW)trimGreenPlayMemory(level>=android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL);}
 void trimGreenPlayMemory(boolean aggressive){try{if(Img.MEM!=null)Img.MEM.trimToSize(aggressive?4*1024:10*1024);}catch(Exception ignored){}try{detailMemoryCache.clear();detailPrefetchQueue.clear();detailPrefetchKeys.clear();}catch(Exception ignored){}if(aggressive&&currentNavIndex==2){try{if(homeScrollCache!=null&&homeScrollCache.getParent()==null){homeScrollCache.removeAllViews();homeScrollCache=null;homeBodyCache=null;homeViewAvailable=false;homeScrollY=0;}}catch(Exception ignored){}}}

 void configureWindowForCurrentMode(){
  try{getWindow().setBackgroundDrawable(new ColorDrawable(BG));getWindow().getDecorView().setBackgroundColor(BG);}catch(Exception ignored){}
  try{setRequestedOrientation(tvMode?android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE:android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);}catch(Exception ignored){}
  try{
   if(tvMode){getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);enterTvImmersiveUi();}
   else{
    getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON|WindowManager.LayoutParams.FLAG_FULLSCREEN);
    try{getWindow().setStatusBarColor(Color.BLACK);}catch(Exception ignored2){}
    try{getWindow().setNavigationBarColor(BG);}catch(Exception ignored2){}
    getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
   }
  }catch(Exception ignored){}
 }
 void startAfterHardModeReload(){
  modeReloadScreen=true;showModeReloadScreenNow();
  new Handler(Looper.getMainLooper()).postDelayed(()->{if(isFinishing())return;modeReloadScreen=false;shell();refreshEntitlements(()->{});},260);
 }
 void startAfterModeChange(){
  shell();refreshEntitlements(()->{});
 }
 
 void showModeReloadScreenNow(){
  modeReloadScreen=true;base(true);root.setPadding(dp(22),dp(10),dp(22),dp(18));
  LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setGravity(Gravity.CENTER_HORIZONTAL);root.addView(c,new LinearLayout.LayoutParams(-1,-1));
  Space topFlex=new Space(this);c.addView(topFlex,new LinearLayout.LayoutParams(1,0,1));
  ImageView logo=new ImageView(this);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);applyAppLogo(logo);LinearLayout.LayoutParams llp=new LinearLayout.LayoutParams(-1,dp(tvMode?66:84));llp.setMargins(dp(54),0,dp(54),dp(tvMode?8:14));c.addView(logo,llp);
  TextView title=t("Carregando…",tvMode?24:26);title.setTypeface(null,1);title.setGravity(Gravity.CENTER);title.setPadding(0,0,0,0);title.setIncludeFontPadding(true);c.addView(title,new LinearLayout.LayoutParams(-1,dp(tvMode?38:42)));
  TextView sub=t("Sincronizando doramas, minisséries e imagens",tvMode?12:13);sub.setTextColor(0xffb8adb4);sub.setGravity(Gravity.CENTER);sub.setPadding(dp(12),0,dp(12),0);sub.setMaxLines(2);LinearLayout.LayoutParams subLp=new LinearLayout.LayoutParams(-1,-2);subLp.setMargins(0,0,0,dp(tvMode?8:18));c.addView(sub,subLp);
  LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);panel.setGravity(Gravity.CENTER_HORIZONTAL);panel.setPadding(dp(tvMode?28:22),dp(tvMode?20:18),dp(tvMode?28:22),dp(tvMode?18:16));GradientDrawable panelBg=round(0xff170d12,24);panelBg.setStroke(dp(1),0xff422936);panel.setBackground(panelBg);int maxPanel=dp(tvMode?720:520);LinearLayout.LayoutParams panelLp=new LinearLayout.LayoutParams(-1,-2);panelLp.setMargins(dp(tvMode?70:14),0,dp(tvMode?70:14),dp(18));c.addView(panel,panelLp);panel.setMinimumWidth(Math.min(getResources().getDisplayMetrics().widthPixels-dp(48),maxPanel));
  TextView eyebrow=t("PREPARANDO YELLY",tvMode?10:10);eyebrow.setTextColor(0xffe37fb1);eyebrow.setTypeface(null,1);eyebrow.setLetterSpacing(.12f);eyebrow.setGravity(Gravity.CENTER);eyebrow.setIncludeFontPadding(false);LinearLayout.LayoutParams eyeLp=new LinearLayout.LayoutParams(-1,dp(tvMode?30:28));eyeLp.setMargins(0,dp(2),0,dp(2));panel.addView(eyebrow,eyeLp);
  modeTransitionPercent=t("10%",tvMode?36:36);modeTransitionPercent.setTextColor(GREEN);modeTransitionPercent.setTypeface(null,1);modeTransitionPercent.setGravity(Gravity.CENTER);modeTransitionPercent.setIncludeFontPadding(false);LinearLayout.LayoutParams pctLp=new LinearLayout.LayoutParams(-1,dp(tvMode?42:48));pctLp.setMargins(0,dp(3),0,0);panel.addView(modeTransitionPercent,pctLp);
  modeTransitionStatus=t("Conectando ao servidor",tvMode?18:18);modeTransitionStatus.setTypeface(null,1);modeTransitionStatus.setGravity(Gravity.CENTER);modeTransitionStatus.setTextColor(Color.WHITE);modeTransitionStatus.setMaxLines(2);modeTransitionStatus.setIncludeFontPadding(true);panel.addView(modeTransitionStatus,new LinearLayout.LayoutParams(-1,-2));
  modeTransitionDetail=t("Validando acesso e sincronizando o catálogo Yelly…",tvMode?13:12);modeTransitionDetail.setTextColor(0xffb0a5ac);modeTransitionDetail.setGravity(Gravity.CENTER);modeTransitionDetail.setMaxLines(3);modeTransitionDetail.setEllipsize(android.text.TextUtils.TruncateAt.END);modeTransitionDetail.setLineSpacing(0,1.08f);modeTransitionDetail.setPadding(dp(18),dp(2),dp(18),dp(2));LinearLayout.LayoutParams detailLp=new LinearLayout.LayoutParams(-1,-2);detailLp.setMargins(0,0,0,dp(2));panel.addView(modeTransitionDetail,detailLp);
  modeTransitionProgress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);modeTransitionProgress.setIndeterminate(false);modeTransitionProgress.setMax(100);modeTransitionProgress.setProgress(10);try{modeTransitionProgress.getProgressDrawable().setColorFilter(GREEN,android.graphics.PorterDuff.Mode.SRC_IN);}catch(Exception ignored){}LinearLayout.LayoutParams prLp=new LinearLayout.LayoutParams(-1,dp(5));prLp.setMargins(dp(28),dp(12),dp(28),dp(8));panel.addView(modeTransitionProgress,prLp);
  TextView footer=t("CANAIS  •  FILMES  •  SÉRIES  •  LOGOS  •  EPG",tvMode?8:9);footer.setTextColor(0xff766f74);footer.setGravity(Gravity.CENTER);footer.setLetterSpacing(.04f);footer.setIncludeFontPadding(true);footer.setMaxLines(2);panel.addView(footer,new LinearLayout.LayoutParams(-1,-2));
  Space bottomFlex=new Space(this);c.addView(bottomFlex,new LinearLayout.LayoutParams(1,0,1));
 }
 void updateModeTransition(int value,String main,String sub){
  int v=Math.max(0,Math.min(100,value));if(modeTransitionProgress!=null)modeTransitionProgress.setProgress(v);if(modeTransitionPercent!=null)modeTransitionPercent.setText(v+"%");if(modeTransitionStatus!=null&&main!=null)modeTransitionStatus.setText(main);if(modeTransitionDetail!=null&&sub!=null)modeTransitionDetail.setText(sub);
 }
 void relaunchForModeChange(boolean enable){
  if(modeSwitchPending)return;
  modeSwitchPending=true;modeSwitchImagesReady=false;modeSwitchOrientationReady=false;
  modeSwitchTargetTv=DeviceCompat.isTelevisionDevice(this)||enable;modeSwitchCache=readHomeCache();
  sp.edit().putBoolean("force_tv_mode",enable).apply();
  // v5.19: troca limpa. Nao abre loading de 100% nem Toast; mantem a tela atual
  // visivel durante a rotacao e remonta o layout assim que a orientacao estiver pronta.
  try{releaseTvInlinePlayer();}catch(Exception ignored){}
  int wanted=modeSwitchTargetTv?android.content.res.Configuration.ORIENTATION_LANDSCAPE:android.content.res.Configuration.ORIENTATION_PORTRAIT;
  if(getResources().getConfiguration().orientation==wanted)modeSwitchOrientationReady=true;
  try{setRequestedOrientation(modeSwitchTargetTv?android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE:android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);}catch(Exception ignored){modeSwitchOrientationReady=true;}
  modeSwitchFallback=()->{if(!modeSwitchPending)return;modeSwitchOrientationReady=true;finishModeSwitchClean();};modeSwitchHandler.postDelayed(modeSwitchFallback,700);
  if(modeSwitchOrientationReady)finishModeSwitchClean();
 }
 void finishModeSwitchClean(){
  if(!modeSwitchPending||!modeSwitchOrientationReady||isFinishing())return;
  if(modeSwitchFallback!=null)modeSwitchHandler.removeCallbacks(modeSwitchFallback);modeSwitchFallback=null;
  modeSwitchCache=null;
  final int restoreNav=currentNavIndex;
  modeSwitchPending=false;modeSwitchImagesReady=false;modeReloadScreen=false;
  // v5.20: NÃO remonta o layout dentro da Activity antiga. Em alguns celulares isso
  // deixava a barra inferior do modo mobile presa no landscape do modo TV.
  // Reabrimos a MainActivity sem animação, já com force_tv_mode salvo e orientação pronta.
  try{
   Intent next=new Intent(this,MainActivity.class);
   next.putExtra("gp_mode_change",true);
   next.putExtra("gp_restore_nav",restoreNav);
   next.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
   startActivity(next);
   overridePendingTransition(0,0);
   finish();
  }catch(Exception ex){
   // fallback seguro: se o relaunch falhar, monta o shell correto na Activity atual.
   tvMode=modeSwitchTargetTv;configureWindowForCurrentMode();homeScrollY=0;homeViewAvailable=false;homeScrollCache=null;homeBodyCache=null;requestedStartNav=restoreNav;shell();
  }
 }
 java.util.ArrayList<String> modeSwitchImageUrls(JSONObject j){
  java.util.ArrayList<String> out=new java.util.ArrayList<>();java.util.HashSet<String> seen=new java.util.HashSet<>();
  if(j==null)return out;try{JSONArray sections=j.optJSONArray("result");if(sections!=null){for(int i=0;i<sections.length()&&out.size()<48;i++){JSONObject sec=sections.optJSONObject(i);if(sec==null)continue;JSONArray data=sec.optJSONArray("data");if(data==null)continue;for(int k=0;k<data.length()&&k<4&&out.size()<48;k++){JSONObject x=data.optJSONObject(k);if(x==null)continue;String poster=x.optString("thumbnail",x.optString("portrait_img",x.optString("image","")));String land=x.optString("landscape",x.optString("landscape_img",""));if(!poster.isEmpty()&&seen.add(poster))out.add(poster);if(out.size()<48&&!land.isEmpty()&&seen.add(land))out.add(land);}}}}catch(Exception ignored){}
  return out;
 }
 JSONArray buildModeReadyFeatured(JSONObject cache){
  JSONArray out=new JSONArray();if(cache==null)return out;JSONArray sections=cache.optJSONArray("result");if(sections==null)return out;java.util.ArrayList<JSONObject> cached=new java.util.ArrayList<>(),uncached=new java.util.ArrayList<>();java.util.HashSet<String> seen=new java.util.HashSet<>();int scanned=0;for(int i=0;i<sections.length()&&scanned<180;i++){JSONObject sec=sections.optJSONObject(i);if(sec==null)continue;JSONArray data=sec.optJSONArray("data");if(data==null)continue;int take=Math.min(8,data.length());for(int k=0;k<take&&scanned<180;k++,scanned++){JSONObject x=data.optJSONObject(k);if(x==null)continue;String key=itemKey(x);if(!seen.add(key))continue;boolean hit=Img.hasCached(this,x.optString("thumbnail",""),x.optString("portrait_img",""),x.optString("image",""),x.optString("landscape",""),x.optString("landscape_img",""));(hit?cached:uncached).add(x);}}for(JSONObject x:cached){if(out.length()>=12)break;out.put(x);}for(JSONObject x:uncached){if(out.length()>=12)break;out.put(x);}return out;
 }
 java.util.ArrayList<String> modeFeaturedImageUrls(JSONArray featured){
  java.util.ArrayList<String> out=new java.util.ArrayList<>();java.util.HashSet<String> seen=new java.util.HashSet<>();if(featured==null)return out;
  int n=Math.min(4,featured.length());for(int i=0;i<n;i++){JSONObject x=featured.optJSONObject(i);if(x==null)continue;String[] c={x.optString("thumbnail",""),x.optString("portrait_img",""),x.optString("image",""),x.optString("landscape",""),x.optString("landscape_img","")};for(String u:c){if(u!=null&&!u.trim().isEmpty()&&seen.add(u.trim()))out.add(u.trim());}}
  if(featured.length()>1){JSONObject x=featured.optJSONObject(featured.length()-1);if(x!=null){String[] c={x.optString("thumbnail",""),x.optString("portrait_img",""),x.optString("image","")};for(String u:c){if(u!=null&&!u.trim().isEmpty()&&seen.add(u.trim()))out.add(u.trim());}}}
  return out;
 }
 void warmModeSwitchReady(JSONObject cache,Runnable done){
  modeReadyFeatured=buildModeReadyFeatured(cache);java.util.ArrayList<String> regular=modeSwitchImageUrls(cache);java.util.ArrayList<String> hero=modeFeaturedImageUrls(modeReadyFeatured);java.util.ArrayList<String> all=new java.util.ArrayList<>();all.addAll(hero);all.addAll(regular);if(all.isEmpty()){done.run();return;}Img.warmCached(this,all,40,420,()->{Img.prefetchBackground(this,regular);if(hero.isEmpty()){done.run();return;}Img.prefetchCritical(this,hero,Math.min(8,hero.size()),1500,done);});
 }
 void finishModeSwitchReady(JSONObject cache){
  if(isFinishing())return;modeSwitchPending=false;modeSwitchImagesReady=false;modeReloadScreen=false;
  if(modeSwitchFallback!=null)modeSwitchHandler.removeCallbacks(modeSwitchFallback);modeSwitchFallback=null;
  modeTransitionProgress=null;modeTransitionPercent=null;modeTransitionStatus=null;modeTransitionDetail=null;
  if(cache!=null)saveHomeCache(cache);
  // Dá um frame para o Android concluir a rotação antes de montar a Home inteira.
  modeSwitchHandler.postDelayed(()->{if(isFinishing())return;shell();if(cache!=null){try{Img.prefetchBackground(this,modeSwitchImageUrls(cache));prefetchDetailsFromCatalog(cache,6);}catch(Exception ignored){}}refreshEntitlements(()->{try{updateGlobalCastButtonState();}catch(Exception ignored){}});},120);
 }
 void tryFinishModeSwitch(){
  if(!modeSwitchPending||!modeSwitchOrientationReady||modeSwitchImagesReady||isFinishing())return;
  modeSwitchImagesReady=true;try{releaseTvInlinePlayer();}catch(Exception ignored){}
  tvMode=modeSwitchTargetTv;configureWindowForCurrentMode();homeScrollY=0;homeViewAvailable=false;homeScrollCache=null;homeBodyCache=null;
  final JSONObject cache=modeSwitchCache;modeSwitchCache=null;updateModeTransition(24,"Sincronizando conteúdo","Preparando filmes, séries, canais, capas, logos e EPG…");
  if(cache!=null&&cache.optJSONArray("result")!=null&&cache.optJSONArray("result").length()>0){
   updateModeTransition(42,"Filmes e séries sincronizados","Preparando capas, detalhes e canais…");
   final boolean[] delivered={false};Runnable ready=()->{if(delivered[0]||isFinishing())return;delivered[0]=true;runOnUiThread(()->{updateModeTransition(88,"Preparando logos e EPG","Finalizando logos dos canais e programação…");modeSwitchHandler.postDelayed(()->{updateModeTransition(100,"Tudo pronto","Abrindo sua experiência…");modeSwitchHandler.postDelayed(()->finishModeSwitchReady(cache),420);},120);});};
   // Tudo que pode envolver disco/rede fica nos pools de imagem. O timeout impede
   // que uma URL ruim prenda a troca de modo e evita o aviso de aplicativo travado.
   modeSwitchHandler.postDelayed(ready,2600);warmModeSwitchReady(cache,ready);return;
  }
  modeSwitchPending=false;modeSwitchImagesReady=false;modeReloadScreen=true;shell();
 }
 void enterTvImmersiveUi(){
  if(!tvMode)return;try{
   getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
   getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
   getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
   if(android.os.Build.VERSION.SDK_INT>=28){WindowManager.LayoutParams lp=getWindow().getAttributes();lp.layoutInDisplayCutoutMode=WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;getWindow().setAttributes(lp);}
  }catch(Exception ignored){}
 }
 @Override public void onWindowFocusChanged(boolean hasFocus){super.onWindowFocusChanged(hasFocus);if(hasFocus&&tvMode&&!tvInlineFullscreen&&!authScreen){View f=getCurrentFocus();if(!(f instanceof EditText))tvImeActive=false;if(!tvImeActive)enterTvImmersiveUi();}}
 boolean isTvConfirmKeyCode(int k){return k==KeyEvent.KEYCODE_DPAD_CENTER||k==KeyEvent.KEYCODE_ENTER||k==KeyEvent.KEYCODE_NUMPAD_ENTER||k==KeyEvent.KEYCODE_BUTTON_A;}
 @Override public boolean dispatchKeyEvent(KeyEvent e){
  if(tvMode&&e!=null){
   int key=e.getKeyCode();
   // v16.204: controles da TV continuam ativos em tela cheia.
   // OK abre a faixa de canais (estilo Xprime); CIMA/BAIXO troca canal direto.
   if(tvInlineFullscreen){
    boolean navKey=key==KeyEvent.KEYCODE_DPAD_UP||key==KeyEvent.KEYCODE_DPAD_DOWN||key==KeyEvent.KEYCODE_DPAD_LEFT||key==KeyEvent.KEYCODE_DPAD_RIGHT||isTvConfirmKeyCode(key)||key==KeyEvent.KEYCODE_BACK||key==KeyEvent.KEYCODE_ESCAPE||key==KeyEvent.KEYCODE_BUTTON_B;
    if(e.getAction()==KeyEvent.ACTION_UP&&navKey)return true;
    if(e.getAction()==KeyEvent.ACTION_DOWN){
     if(key==KeyEvent.KEYCODE_BACK||key==KeyEvent.KEYCODE_ESCAPE||key==KeyEvent.KEYCODE_BUTTON_B){if(tvFullscreenChannelOverlayVisible)hideTvFullscreenChannelOverlay();else closeTvInlineFullscreen();return true;}
     if(key==KeyEvent.KEYCODE_DPAD_UP){switchTvFullscreenChannelBy(-1);return true;}
     if(key==KeyEvent.KEYCODE_DPAD_DOWN){switchTvFullscreenChannelBy(1);return true;}
     if(key==KeyEvent.KEYCODE_DPAD_LEFT){if(!tvFullscreenChannelOverlayVisible)showTvFullscreenChannelOverlay(false);moveTvFullscreenOverlaySelection(-1);return true;}
     if(key==KeyEvent.KEYCODE_DPAD_RIGHT){if(!tvFullscreenChannelOverlayVisible)showTvFullscreenChannelOverlay(false);moveTvFullscreenOverlaySelection(1);return true;}
     if(isTvConfirmKeyCode(key)){if(e.getRepeatCount()==0){if(tvFullscreenChannelOverlayVisible)selectTvFullscreenOverlayChannel();else showTvFullscreenChannelOverlay(false);}return true;}
    }
   }
   if(e.getAction()==KeyEvent.ACTION_DOWN&&(key==KeyEvent.KEYCODE_BACK||key==KeyEvent.KEYCODE_ESCAPE||key==KeyEvent.KEYCODE_BUTTON_B)){onBackPressed();return true;}
   if(e.getAction()==KeyEvent.ACTION_UP&&(key==KeyEvent.KEYCODE_BACK||key==KeyEvent.KEYCODE_ESCAPE||key==KeyEvent.KEYCODE_BUTTON_B))return true;
   if(isTvConfirmKeyCode(key)){
    if(e.getAction()==KeyEvent.ACTION_DOWN&&e.getRepeatCount()==0){
     View f=getCurrentFocus();
     if(f instanceof EditText&&f.isShown()&&f.isEnabled()){showTvKeyboard((EditText)f);return true;}
     if(f!=null&&f.isShown()&&f.isEnabled()&&f.isClickable()&&!(f instanceof SeekBar)){f.performClick();return true;}
    }
    if(e.getAction()==KeyEvent.ACTION_UP)return true;
   }
  }
  return super.dispatchKeyEvent(e);
 }
 void chooseProfilePhoto(){try{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("image/*");startActivityForResult(i,REQ_PROFILE_PHOTO);}catch(Exception e){try{Intent i=new Intent(Intent.ACTION_GET_CONTENT);i.setType("image/*");startActivityForResult(Intent.createChooser(i,"Escolher foto"),REQ_PROFILE_PHOTO);}catch(Exception ignored){showAppNotice("Não foi possível abrir a galeria.",true);}}}
 String savedProfilePhoto(){if(uid==null||uid.isEmpty())return "";return getSharedPreferences("gp_profile",0).getString("photo_"+uid,"");}
 @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode!=REQ_PROFILE_PHOTO||resultCode!=RESULT_OK||data==null||data.getData()==null)return;Uri uri=data.getData();try{int flags=data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);getContentResolver().takePersistableUriPermission(uri,flags|Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}if(uid!=null&&!uid.isEmpty())getSharedPreferences("gp_profile",0).edit().putString("photo_"+uid,uri.toString()).apply();profile();}
 String deviceId(){String d=sp.getString("device_id","");if(d.isEmpty()){d=java.util.UUID.randomUUID().toString();sp.edit().putString("device_id",d).apply();}return d;}
 void cacheAccessStatus(JSONObject st){if(st==null||uid==null||uid.isEmpty())return;sp.edit().putString("access_status_"+uid,st.toString()).apply();}
 JSONObject readCachedAccessStatus(){if(uid==null||uid.isEmpty())return null;try{String raw=sp.getString("access_status_"+uid,"");return raw.isEmpty()?null:new JSONObject(raw);}catch(Exception e){return null;}}
 int jsonPositiveInt(JSONObject o,String... keys){if(o==null||keys==null)return 0;for(String k:keys){try{if(!o.has(k)||o.isNull(k))continue;Object v=o.opt(k);if(v instanceof Number){int n=((Number)v).intValue();if(n>0)return n;}String raw=String.valueOf(v).trim();if(raw.isEmpty())continue;String digits=raw.replaceAll("[^0-9]","");if(!digits.isEmpty()){int n=Integer.parseInt(digits);if(n>0)return n;}}catch(Exception ignored){}}return 0;}
 String jsonFirstString(JSONObject o,String... keys){if(o==null||keys==null)return "";for(String k:keys){String v=o.optString(k,"").trim();if(!v.isEmpty()&&!"null".equalsIgnoreCase(v))return v;}return "";}
 int totalScreensFrom(JSONObject st){if(st==null)return 0;String[] keys={"_resolved_screens","screens_total","screens","telas","plan_screens","package_screens","max_screens","screen_limit","screens_limit","allowed_screens","device_limit","max_devices","max_connections","simultaneous_streams","simultaneous_connections","connections"};int n=jsonPositiveInt(st,keys);if(n>0)return n;String[] nested={"plan","package","subscription","entitlement","access","data","user","account"};for(String nk:nested){JSONObject x=st.optJSONObject(nk);n=jsonPositiveInt(x,keys);if(n>0)return n;}return 0;}
 int usedScreensFrom(JSONObject st){if(st==null)return 0;String[] keys={"used_screens","screens_in_use","active_screens","current_screens","active_sessions","sessions_in_use","connected_devices_count","devices_in_use","current_connections","active_connections"};int n=jsonPositiveInt(st,keys);if(n>0)return n;String[] nested={"subscription","entitlement","access","data","user","account"};for(String nk:nested){JSONObject x=st.optJSONObject(nk);n=jsonPositiveInt(x,keys);if(n>0)return n;}return 0;}
 String planNameFrom(JSONObject st){if(st==null)return "";String n=jsonFirstString(st,"plan_name","package_name","plan","package","title","name");if(!n.isEmpty())return n;JSONObject p=st.optJSONObject("plan");if(p==null)p=st.optJSONObject("package");return jsonFirstString(p,"plan_name","package_name","title","name");}
 String planIdFrom(JSONObject st){if(st==null)return "";String n=jsonFirstString(st,"plan_id","package_id","subscription_package_id","subscription_id");if(!n.isEmpty())return n;JSONObject p=st.optJSONObject("plan");if(p==null)p=st.optJSONObject("package");return jsonFirstString(p,"id","plan_id","package_id");}
 void rememberResolvedScreens(JSONObject st,int used,int total){if(total<1)return;try{st.put("_resolved_screens",total);if(used>0)st.put("_resolved_used_screens",used);}catch(Exception ignored){}if(uid!=null&&!uid.isEmpty())sp.edit().putInt("plan_screens_"+uid,total).putInt("plan_used_screens_"+uid,Math.max(1,used)).apply();cacheAccessStatus(st);}
 void resolveScreensFromPanel(JSONObject st,ScreenResolveCB cb){int direct=Math.max(totalScreensFrom(st),uid==null?0:sp.getInt("plan_screens_"+uid,0));int used=Math.max(usedScreensFrom(st),uid==null?0:sp.getInt("plan_used_screens_"+uid,0));if(used<1)used=1;final int initialTotal=Math.max(1,direct),initialUsed=used;if(direct>1){if(cb!=null)runOnUiThread(()->cb.done(Math.min(initialUsed,initialTotal),initialTotal));return;}final String wantedName=planNameFrom(st).trim(),wantedId=planIdFrom(st).trim();Api.post("subscription_package",Api.m("user_id",uid,"reseller_code",reseller),new Api.CB(){public void ok(JSONObject j){int best=initialTotal;JSONArray a=j.optJSONArray("result");if(a!=null){for(int i=0;i<a.length();i++){JSONObject p=a.optJSONObject(i);if(p==null)continue;String id=jsonFirstString(p,"id","plan_id","package_id");String name=jsonFirstString(p,"plan_name","package_name","title","name");boolean match=(!wantedId.isEmpty()&&wantedId.equals(id))||(!wantedName.isEmpty()&&wantedName.equalsIgnoreCase(name.trim()));if(!match)continue;best=Math.max(best,totalScreensFrom(p));if(best>1)break;}}final int total=Math.max(1,best);final int u=Math.min(Math.max(1,initialUsed),total);if(total>1)rememberResolvedScreens(st,u,total);if(cb!=null)runOnUiThread(()->cb.done(u,total));}public void err(String e){if(cb!=null)runOnUiThread(()->cb.done(Math.min(initialUsed,initialTotal),initialTotal));}});}
 void applyEntitlements(JSONObject st){if(st==null)return;cacheAccessStatus(st);planLiveAllowed=st.optInt("live_allowed",st.optBoolean("live_allowed",true)?1:0)==1;planAdultAllowed=st.optInt("adult_allowed",st.optBoolean("adult_allowed",true)?1:0)==1;int cached=(uid==null||uid.isEmpty())?0:sp.getInt("plan_screens_"+uid,0);planScreens=Math.max(1,Math.max(totalScreensFrom(st),cached));activePlanName=planNameFrom(st);int liveCount=sp.getInt("provider_live_count",-1);if(liveCount>=0){sessionHasLive=liveCount>0;sessionLiveKnown=true;}else sessionHasLive=sp.getBoolean("provider_has_live",sessionHasLive);if(!planAdultAllowed&&sp.getBoolean("adult",false))sp.edit().putBoolean("adult",false).apply();}
 void refreshEntitlements(Runnable done){if(uid==null||uid.isEmpty()){if(done!=null)done.run();return;}Api.post("access_status",Api.m("user_id",uid),new Api.CB(){public void ok(JSONObject j){JSONArray a=j.optJSONArray("result");JSONObject st=(a!=null&&a.length()>0)?a.optJSONObject(0):null;if(st!=null){applyEntitlements(st);resolveScreensFromPanel(st,(used,total)->{planScreens=Math.max(planScreens,total);if(done!=null)done.run();});}else if(done!=null)runOnUiThread(done);}public void err(String e){if(done!=null)runOnUiThread(done);}});}
 boolean adultContentVisible(){return planAdultAllowed&&sp.getBoolean("adult",false);}
 String adultNorm(String raw){if(raw==null)return "";String x=java.text.Normalizer.normalize(raw,java.text.Normalizer.Form.NFD).replaceAll("\\p{M}+","").toLowerCase(java.util.Locale.ROOT);return x;}
 boolean isAdultLabel(String raw){String x=adultNorm(raw);if(x.isEmpty())return false;return x.matches(".*(^|[^a-z0-9])(adult|adulto|adultos|xxx|18\\+|erotico|erotica|porn|porno|sex)([^a-z0-9]|$).*");}
 JSONArray filterAdultCategories(JSONArray src){if(src==null)return new JSONArray();if(adultContentVisible())return src;JSONArray out=new JSONArray();for(int i=0;i<src.length();i++){JSONObject c=src.optJSONObject(i);if(c==null)continue;String n=c.optString("category_name",c.optString("name",c.optString("title","")));if(!isAdultLabel(n))out.put(c);}return out;}
 boolean adultSectionBlocked(JSONObject sec){if(adultContentVisible()||sec==null)return false;return isAdultLabel(sec.optString("title",""))||isAdultLabel(sec.optString("category_name",""));}
 java.util.HashSet<String> adultLiveCategoryIds(){java.util.HashSet<String> ids=new java.util.HashSet<>();if(adultContentVisible())return ids;JSONObject cache=readHomeCache();JSONArray cats=cache==null?null:cache.optJSONArray("live_categories");if(cats!=null)for(int i=0;i<cats.length();i++){JSONObject c=cats.optJSONObject(i);if(c==null)continue;String n=c.optString("category_name",c.optString("name",""));if(isAdultLabel(n))ids.add(c.optString("category_id",c.optString("id","")));}return ids;}
 boolean adultLiveBlocked(JSONObject x,java.util.HashSet<String> blocked){if(adultContentVisible()||x==null)return false;String cid=x.optString("category_id","");if(blocked!=null&&blocked.contains(cid))return true;return isAdultLabel(x.optString("category_name",""))||isAdultLabel(x.optString("name",""));}

 void applyProfileAccessUi(JSONObject st,TextView planValue,TextView validityValue,TextView screensValue,TextView serverValue,TextView subscriptionValue,LinearLayout renewal,TextView renewTitle,TextView renewSub){if(st==null)return;String mode=st.optString("mode","");String msg=st.optString("message","");String exp=st.optString("expires_at","");String plan=planNameFrom(st);String srv=st.optString("provider_name",st.optString("server_name",sp.getString("provider_name","Yelly")));boolean trial=st.optInt("trial_active",0)==1||st.optInt("is_trial",0)==1||mode.toLowerCase(java.util.Locale.ROOT).contains("trial")||msg.toLowerCase(java.util.Locale.ROOT).contains("teste");boolean active=st.optBoolean("allowed",st.optBoolean("active",true));if(trial&&active)plan="Teste Grátis";else if(plan.isEmpty())plan=active?"Premium":"Sem plano";planValue.setText(plan);validityValue.setText(exp.isEmpty()?"—":shortDate(exp));int total=Math.max(totalScreensFrom(st),(uid==null||uid.isEmpty())?0:sp.getInt("plan_screens_"+uid,0));if(total<1)total=1;int used=Math.max(usedScreensFrom(st),(uid==null||uid.isEmpty())?0:sp.getInt("plan_used_screens_"+uid,0));if(used<1)used=1;used=Math.min(used,total);screensValue.setText(used+" de "+total);serverValue.setText(srv.isEmpty()?"Yelly":srv);subscriptionValue.setText(active?(trial?"Teste grátis ativo":"Ativa"):"Inativa");subscriptionValue.setTextColor(active?GREEN:0xffb4a9b0);validityValue.setTextColor(active?0xffd3d7d5:0xff999096);if(active&&trial){String tt=st.optString("trial_title","Teste grátis ativo");String ts=st.optString("trial_subtitle","Conheça os planos disponíveis");renewTitle.setText(tt.isEmpty()?"Teste grátis ativo":tt);renewSub.setText(ts.isEmpty()?"Conheça os planos disponíveis":ts);renewal.setVisibility(View.VISIBLE);}else if(!active){boolean wasTrial=trial||msg.toLowerCase(java.util.Locale.ROOT).contains("teste");renewTitle.setText(wasTrial?"Teste encerrado":"Plano vencido");renewSub.setText(wasTrial?"Assine para continuar assistindo":"Renove para continuar assistindo");renewal.setVisibility(View.VISIBLE);}else renewal.setVisibility(View.GONE);}

 void migrateLegacyOfflineDownloads(){try{JSONArray a=new JSONArray(sp.getString("offline_items","[]"));JSONArray keep=new JSONArray();boolean changed=false;java.io.File privateDir=new java.io.File(getFilesDir(),"offline");String privatePrefix=privateDir.getAbsolutePath();for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;long did=o.optLong("download_id",0);String path=o.optString("path","");boolean legacy=did>0||(!path.isEmpty()&&!path.startsWith(privatePrefix));if(legacy){changed=true;if(did>0)try{android.app.DownloadManager dm=(android.app.DownloadManager)getSystemService(DOWNLOAD_SERVICE);dm.remove(did);}catch(Exception ignored){}if(!path.isEmpty())try{new java.io.File(path).delete();}catch(Exception ignored){}continue;}keep.put(o);}if(changed)sp.edit().putString("offline_items",keep.toString()).apply();}catch(Exception ignored){}}
 void loadIdentityCache(){appName=sp.getString("app_name","Yelly Doramas");logoUrl=sp.getString("app_logo","");bgUrl=sp.getString("app_background","");try{GREEN=Color.parseColor(sp.getString("app_color","#B8007D"));}catch(Exception e){GREEN=Color.rgb(184,0,125);}}
 void refreshIdentity(){Api.post("general_setting",Api.m(),new Api.CB(){public void ok(JSONObject j){JSONArray a=j.optJSONArray("result");if(a==null)return;android.content.SharedPreferences.Editor ed=sp.edit();for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;String k=x.optString("key"),v=x.optString("value");if(k.equals("greenplay_app_name")&&!v.trim().isEmpty())ed.putString("app_name",v);if(k.equals("greenplay_app_logo"))ed.putString("app_logo",v);if(k.equals("greenplay_app_background"))ed.putString("app_background",v);if(k.equals("greenplay_primary_color")&&!v.trim().isEmpty())ed.putString("app_color",v);if(k.equals("greenplay_support_whatsapp")&&!v.trim().isEmpty()&&(reseller==null||reseller.isEmpty()||sp.getString("support","").trim().isEmpty()))ed.putString("support",v);if(k.equals("greenplay_preview_series_episodes"))try{ed.putInt("preview_series_episodes",Math.max(0,Integer.parseInt(v)));}catch(Exception ignored){}if(k.equals("greenplay_preview_movie_minutes"))try{ed.putInt("preview_movie_minutes",Math.max(0,Integer.parseInt(v)));}catch(Exception ignored){}}ed.apply();loadIdentityCache();runOnUiThread(()->{if(uid.isEmpty()){if(!authScreen)refreshHomeHeaderBranding();}else refreshHomeHeaderBranding();});}public void err(String e){}});}
 void applyAppLogo(ImageView im){if(im==null)return;try{im.setImageResource(R.drawable.yelly_logo);im.setAlpha(1f);}catch(Exception ignored){}String u=logoUrl==null?"":logoUrl.trim();if(!u.isEmpty())Img.load(im,u);}
 float tvUiScale(){if(!tvMode)return getResources().getDisplayMetrics().density;android.util.DisplayMetrics dm=getResources().getDisplayMetrics();float shortPx=Math.min(dm.widthPixels,dm.heightPixels);float scale=shortPx/720f;if(scale<0.82f)scale=0.82f;if(scale>3.20f)scale=3.20f;return scale;}
 void uiTextSize(TextView v,float size){if(v==null)return;if(tvMode)v.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX,size*tvUiScale());else v.setTextSize(size);}
 TextView t(String s,int z){TextView v=new TextView(this);v.setText(s);v.setTextColor(Color.WHITE);uiTextSize(v,z);v.setPadding(dp(8),dp(8),dp(8),dp(8));v.setFocusable(true);return v;}
 EditText e(String hint,boolean pass){EditText v=new EditText(this);v.setHint(hint);v.setHintTextColor(0xff90878d);v.setTextColor(Color.WHITE);uiTextSize(v,17);v.setSingleLine();v.setPadding(dp(16),dp(14),dp(16),dp(14));v.setBackground(round(CARD,14));if(pass)v.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);if(tvMode)prepareTvTextInput(v);return v;}
 GradientDrawable round(int c,int r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));return g;} int dp(int n){float scale=tvMode?tvUiScale():getResources().getDisplayMetrics().density;return(int)(n*scale+.5f);} int screenWidthDp(){android.util.DisplayMetrics dm=getResources().getDisplayMetrics();float scale=tvMode?tvUiScale():Math.max(.75f,dm.density);return(int)(dm.widthPixels/Math.max(.75f,scale));} boolean wideTvUi(){return tvMode;} int tvContentSide(){if(!wideTvUi())return dp(18);int w=getResources().getDisplayMetrics().widthPixels;return Math.max(dp(28),(w-dp(1180))/2);} int tvGridColumns(){if(!wideTvUi())return 3;int usable=Math.max(720,screenWidthDp()-72);return Math.max(6,Math.min(10,usable/142));} int statusBarHeightPx(){try{int id=getResources().getIdentifier("status_bar_height","dimen","android");if(id>0)return getResources().getDimensionPixelSize(id);}catch(Exception ignored){}return dp(24);} int systemSafeTopPx(){int top=statusBarHeightPx();try{if(android.os.Build.VERSION.SDK_INT>=23){android.view.WindowInsets wi=getWindow().getDecorView().getRootWindowInsets();if(wi!=null){top=Math.max(top,wi.getSystemWindowInsetTop());if(android.os.Build.VERSION.SDK_INT>=28&&wi.getDisplayCutout()!=null)top=Math.max(top,wi.getDisplayCutout().getSafeInsetTop());}}}catch(Exception ignored){}return top;} int standardPageTopPx(){return dp(18);} void standardPageInsets(){if(body!=null){int side=wideTvUi()?dp(28):dp(18);body.setPadding(side,wideTvUi()?dp(10):dp(2),side,wideTvUi()?dp(18):dp(10));}}
 void standardRootInsets(){if(root!=null)root.setPadding(0,wideTvUi()?0:dp(18),0,0);}
 int navigationBottomInsetPx(android.view.WindowInsets wi){
  int bottom=0;try{
   if(wi!=null){
    if(android.os.Build.VERSION.SDK_INT>=30){
     // Para posicionar a barra do app devemos respeitar apenas a barra de
     // navegacao do sistema. systemGestures() e maior em muitos aparelhos
     // com gestos e fazia a barra do GreenPlay ficar duas vezes mais alta.
     android.graphics.Insets nav=wi.getInsets(android.view.WindowInsets.Type.navigationBars());
     bottom=nav.bottom;
    }else{
     // stableInsetBottom pode continuar com a altura antiga dos 3 botoes mesmo
     // quando o usuario usa gestos. O inset atual e o valor correto aqui.
     bottom=wi.getSystemWindowInsetBottom();
    }
   }
  }catch(Throwable ignored){}
  if(bottom<0)bottom=0;
  // Protecao contra valores anormais de OEM/ROM. Uma barra de navegacao real
  // nao precisa reservar mais que 64dp para manter os controles do app seguros.
  return Math.min(bottom,dp(64));
 }
 int currentNavigationBottomInsetPx(){
  try{
   if(android.os.Build.VERSION.SDK_INT>=23){
    android.view.WindowInsets wi=getWindow().getDecorView().getRootWindowInsets();
    if(wi!=null)return navigationBottomInsetPx(wi);
   }
  }catch(Throwable ignored){}
  return Math.max(0,mobileBottomInsetPx);
 }
 void applyMobileBottomNavInsets(android.view.WindowInsets wi){
  if(wideTvUi()||navBar==null)return;
  int inset=wi!=null?navigationBottomInsetPx(wi):currentNavigationBottomInsetPx();
  mobileBottomInsetPx=Math.max(0,inset);

  // Base mais compacta. O espaco extra e exatamente o que o Android informa
  // para a navegacao daquele aparelho.
  int baseH=dp(58);
  navBar.setGravity(Gravity.CENTER);
  navBar.setPadding(0,dp(2),0,dp(2)+mobileBottomInsetPx);
  ViewGroup.LayoutParams raw=navBar.getLayoutParams();
  if(raw instanceof LinearLayout.LayoutParams){
   LinearLayout.LayoutParams lp=(LinearLayout.LayoutParams)raw;
   lp.width=-1;lp.height=baseH+mobileBottomInsetPx;lp.setMargins(0,0,0,0);navBar.setLayoutParams(lp);
  }
 }
 void installMobileBottomNavInsets(){
  if(wideTvUi()||navBar==null)return;
  if(android.os.Build.VERSION.SDK_INT>=20){
   navBar.setOnApplyWindowInsetsListener((v,wi)->{applyMobileBottomNavInsets(wi);return wi;});
   navBar.post(()->{try{navBar.requestApplyInsets();}catch(Throwable ignored){applyMobileBottomNavInsets(null);}});
  }else applyMobileBottomNavInsets(null);
 }
 void tvRootInsets(){if(root!=null)root.setPadding(0,wideTvUi()?0:Math.max(dp(34),systemSafeTopPx()+dp(8)),0,0);}
 int tvPreviewHeightPx(){android.util.DisplayMetrics dm=getResources().getDisplayMetrics();int w=Math.min(dm.widthPixels,dm.heightPixels);return Math.max(dp(180),(int)(w*9f/16f+.5f));}
 GradientDrawable tvPlayerControlBg(){GradientDrawable g=round(0xaa111614,16);g.setStroke(dp(1),0xff827a7f);return g;}
 void enableTvRemoteTree(ViewGroup host){
  if(!tvMode||host==null)return;
  // v16.210 TV-only: a tela de canais ja arma seus focos explicitamente.
  // Nela nao fazemos varredura global da arvore, porque cada lote de canais,
  // imagem e scroll gera layout e TVs mais fracas podem travar a UI.
  final boolean[] scanPosted={false};
  final Runnable scan=()->{scanPosted[0]=false;if(!tvMode||host.getWindowToken()==null||tvInlineFullscreen||tvUiTransitioning)return;if(currentNavIndex==2&&tvPageRoot!=null)return;prepareTvFocusTree(host);};
  host.getViewTreeObserver().addOnGlobalLayoutListener(()->{if(!tvMode||tvInlineFullscreen||tvUiTransitioning||scanPosted[0])return;if(currentNavIndex==2&&tvPageRoot!=null)return;scanPosted[0]=true;host.postDelayed(scan,240);});
  host.post(()->{if(!(currentNavIndex==2&&tvPageRoot!=null))prepareTvFocusTree(host);});
 }
 void prepareTvFocusTree(View v){if(!tvMode||v==null||v.getVisibility()!=View.VISIBLE)return;boolean input=v instanceof EditText||v instanceof SeekBar;boolean action=v.isClickable()||v instanceof Button||input;if(action){v.setFocusable(true);v.setFocusableInTouchMode(input);if(v instanceof EditText)prepareTvTextInput((EditText)v);armTvFocus(v);}else if(v instanceof TextView){v.setFocusable(false);v.setFocusableInTouchMode(false);}if(v instanceof ViewGroup){ViewGroup g=(ViewGroup)v;for(int i=0;i<g.getChildCount();i++)prepareTvFocusTree(g.getChildAt(i));}}
 GradientDrawable tvFocusRing(){GradientDrawable g=new GradientDrawable();g.setColor(Color.TRANSPARENT);g.setCornerRadius(dp(12));g.setStroke(dp(3),GREEN);return g;}
 void armTvFocus(View v){if(!tvMode||v==null||tvFocusArmed.containsKey(v))return;tvFocusArmed.put(v,Boolean.TRUE);if(Boolean.TRUE.equals(v.getTag(TAG_SKIP_TV_FOCUS_FX)))return;v.setOnFocusChangeListener((x,has)->{x.animate().scaleX(1f).scaleY(1f).setDuration(0).start();if(android.os.Build.VERSION.SDK_INT>=21){x.setTranslationZ(has?dp(8):0);x.setForeground(has?tvFocusRing():null);}if(has)x.post(()->{try{android.graphics.Rect r=new android.graphics.Rect(0,0,x.getWidth(),x.getHeight());x.requestRectangleOnScreen(r,false);}catch(Exception ignored){}});});}
 void requestTvFocus(View v){if(!tvMode||v==null)return;boolean input=v instanceof EditText||v instanceof SeekBar;v.setFocusable(true);v.setFocusableInTouchMode(input);armTvFocus(v);boolean done=false;try{if(v.isShown()&&v.isEnabled())done=v.requestFocus();}catch(Exception ignored){}if(!done)v.postDelayed(()->{try{if(v.isShown()&&v.isEnabled()&&!v.hasFocus())v.requestFocus();}catch(Exception ignored){}},16);}
 void hideKeyboard(View anchor){tvImeActive=false;try{android.view.inputmethod.InputMethodManager im=(android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);View v=anchor!=null?anchor:getCurrentFocus();if(im!=null&&v!=null)im.hideSoftInputFromWindow(v.getWindowToken(),0);}catch(Exception ignored){}if(tvMode)new Handler(Looper.getMainLooper()).postDelayed(()->{try{if(!tvImeActive)enterTvImmersiveUi();}catch(Exception ignored){}},260);}
 void prepareTvTextInput(EditText input){if(!tvMode||input==null)return;input.setFocusable(true);input.setFocusableInTouchMode(true);input.setClickable(true);input.setCursorVisible(true);if(android.os.Build.VERSION.SDK_INT>=21)try{input.setShowSoftInputOnFocus(true);}catch(Exception ignored){}if(tvInputArmed.containsKey(input))return;tvInputArmed.put(input,Boolean.TRUE);input.setOnKeyListener((v,key,event)->{if(event==null||event.getAction()!=KeyEvent.ACTION_DOWN||event.getRepeatCount()!=0)return false;if(isTvConfirmKeyCode(key)){showTvKeyboard((EditText)v);return true;}return false;});}
 ScrollView parentScroll(View v){View cur=v;while(cur!=null){android.view.ViewParent p=cur.getParent();if(p instanceof ScrollView)return (ScrollView)p;if(!(p instanceof View))break;cur=(View)p;}return null;}
 void keepInputAboveKeyboard(EditText input){if(input==null)return;ScrollView sv=parentScroll(input);if(sv==null)return;Runnable move=()->{try{android.graphics.Rect visible=new android.graphics.Rect();View decor=getWindow().getDecorView();decor.getWindowVisibleDisplayFrame(visible);int[] loc=new int[2];input.getLocationOnScreen(loc);int fieldBottom=loc[1]+input.getHeight();int safeBottom=visible.bottom-dp(tvMode?72:46);if(fieldBottom>safeBottom){int delta=fieldBottom-safeBottom+dp(tvMode?36:22);sv.scrollBy(0,Math.max(0,delta));}android.graphics.Rect r=new android.graphics.Rect(0,0,input.getWidth(),input.getHeight()+dp(tvMode?90:58));input.requestRectangleOnScreen(r,true);}catch(Exception ignored){}};sv.post(move);sv.postDelayed(move,90);sv.postDelayed(move,220);sv.postDelayed(move,420);sv.postDelayed(move,650);}
 void installAuthKeyboardLift(ScrollView sv,LinearLayout content){if(sv==null||content==null)return;final View decor=getWindow().getDecorView();decor.getViewTreeObserver().addOnGlobalLayoutListener(()->{try{android.graphics.Rect visible=new android.graphics.Rect();decor.getWindowVisibleDisplayFrame(visible);int rootH=decor.getRootView().getHeight();int hidden=Math.max(0,rootH-visible.bottom);boolean keyboardOpen=hidden>Math.max(dp(140),rootH/6);content.setGravity((keyboardOpen?Gravity.TOP:Gravity.CENTER_VERTICAL)|Gravity.CENTER_HORIZONTAL);if(keyboardOpen){View f=getCurrentFocus();if(f instanceof EditText){EditText e=(EditText)f;keepInputAboveKeyboard(e);sv.postDelayed(()->keepInputAboveKeyboard(e),120);}}}catch(Exception ignored){}});}
 void showTvKeyboard(EditText input){if(input==null)return;tvImeActive=true;prepareTvTextInput(input);try{getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE);getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE|WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);input.setFocusable(true);input.setFocusableInTouchMode(true);input.setCursorVisible(true);if(android.os.Build.VERSION.SDK_INT>=21)input.setShowSoftInputOnFocus(true);input.requestFocus();input.setSelection(input.length());keepInputAboveKeyboard(input);}catch(Exception ignored){}Runnable open=()->{try{android.view.inputmethod.InputMethodManager im=(android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);if(im!=null&&input.getWindowToken()!=null){input.requestFocus();im.restartInput(input);boolean shown=im.showSoftInput(input,android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT);keepInputAboveKeyboard(input);input.postDelayed(()->{try{if(!shown||!im.isActive(input)){input.requestFocus();im.restartInput(input);im.showSoftInput(input,android.view.inputmethod.InputMethodManager.SHOW_FORCED);}keepInputAboveKeyboard(input);}catch(Exception ignored2){}},180);input.postDelayed(()->{try{im.showSoftInput(input,android.view.inputmethod.InputMethodManager.SHOW_FORCED);keepInputAboveKeyboard(input);}catch(Exception ignored3){}},420);}}catch(Exception ignored){}};input.post(open);input.postDelayed(open,80);}
 boolean isEnterKey(KeyEvent e){if(e==null||e.getAction()!=KeyEvent.ACTION_DOWN)return false;int k=e.getKeyCode();return k==KeyEvent.KEYCODE_ENTER||k==KeyEvent.KEYCODE_DPAD_CENTER||k==KeyEvent.KEYCODE_NUMPAD_ENTER;}
 int focusId(View v){if(v==null)return View.NO_ID;if(v.getId()==View.NO_ID)v.setId(View.generateViewId());return v.getId();}
 void linkTvVertical(View upper,View lower){if(!tvMode||upper==null||lower==null)return;int a=focusId(upper),b=focusId(lower);upper.setNextFocusDownId(b);lower.setNextFocusUpId(a);}
 void linkTvHorizontal(View left,View right){if(!tvMode||left==null||right==null)return;int a=focusId(left),b=focusId(right);left.setNextFocusRightId(b);right.setNextFocusLeftId(a);}
 void bindImeMove(EditText from,View next,int action){if(from==null)return;from.setImeOptions(action);from.setOnEditorActionListener((v,a,event)->{boolean accepted=a==action||a==android.view.inputmethod.EditorInfo.IME_ACTION_NEXT||a==android.view.inputmethod.EditorInfo.IME_ACTION_DONE||a==android.view.inputmethod.EditorInfo.IME_ACTION_GO||a==android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH||(tvMode&&a==android.view.inputmethod.EditorInfo.IME_ACTION_UNSPECIFIED)||(!tvMode&&isEnterKey(event));if(!accepted)return false;if(next!=null){next.setFocusable(true);next.requestFocus();if(tvMode){armTvFocus(next);if(next instanceof EditText){EditText target=(EditText)next;target.postDelayed(()->showTvKeyboard(target),60);}else hideKeyboard(from);}}else hideKeyboard(from);return true;});if(tvMode){from.setOnClickListener(v->showTvKeyboard(from));from.setOnKeyListener((v,key,event)->{if(event==null||event.getAction()!=KeyEvent.ACTION_DOWN||event.getRepeatCount()!=0)return false;if(isTvConfirmKeyCode(key)){showTvKeyboard(from);return true;}return false;});}}
 View firstFocusableChild(View v){if(v==null||v.getVisibility()!=View.VISIBLE)return null;if(v.isFocusable()&&v.isEnabled()&&v.isShown())return v;if(v instanceof ViewGroup){ViewGroup g=(ViewGroup)v;for(int i=0;i<g.getChildCount();i++){View hit=firstFocusableChild(g.getChildAt(i));if(hit!=null)return hit;}}return null;}
 void requestFirstTvFocus(View host){if(!tvMode||host==null)return;host.postDelayed(()->{prepareTvFocusTree(host);View hit=firstFocusableChild(host);if(hit!=null)requestTvFocus(hit);},100);}
 void updateGlobalCastButtonState(){if(contentFrame==null)return;updateCastButtonsIn(contentFrame);}
 void updateCastButtonsIn(View v){if(v==null)return;if(v instanceof ImageView&&"gp_cast_header".equals(v.getTag())){try{((ImageView)v).setColorFilter(CastHelper.isConnected(this)?GREEN:0xffebdde6);}catch(Exception ignored){}}if(v instanceof ViewGroup){ViewGroup g=(ViewGroup)v;for(int i=0;i<g.getChildCount();i++)updateCastButtonsIn(g.getChildAt(i));}}
 void ensureGlobalCastButton(){if(globalCastButton!=null&&globalCastButton.getParent()==contentFrame){try{contentFrame.removeView(globalCastButton);}catch(Exception ignored){}}globalCastButton=null;updateGlobalCastButtonState();}
 ImageView headerCastButton(){
  ImageView b=new ImageView(this);b.setTag("gp_cast_header");b.setImageResource(R.drawable.ic_cast);b.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
  b.setPadding(dp(8),dp(7),dp(8),dp(7));GradientDrawable cb=round(0x44181114,19);cb.setStroke(dp(1),0xff464245);b.setBackground(cb);
  b.setContentDescription("Transmitir para Chromecast");b.setClickable(true);b.setFocusable(true);
  b.setOnClickListener(v->CastHelper.openChooser(MainActivity.this));
  b.setOnLongClickListener(v->{CastHelper.openSystemMirror(MainActivity.this);return true;});
  b.setColorFilter(CastHelper.isConnected(this)?GREEN:0xffebdde6);
  return b;
 }
 Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.BLACK);uiTextSize(b,16);b.setAllCaps(false);b.setBackground(round(GREEN,14));b.setFocusable(true);return b;}
 GradientDrawable authBox(){GradientDrawable g=new GradientDrawable();g.setColor(0xe621191d);g.setCornerRadius(dp(28));g.setStroke(dp(1),0xff585356);return g;}
 Drawable authFieldSelector(){StateListDrawable s=new StateListDrawable();GradientDrawable focus=new GradientDrawable();focus.setColor(0xff2b1522);focus.setCornerRadius(dp(28));focus.setStroke(dp(3),GREEN);s.addState(new int[]{android.R.attr.state_focused},focus);s.addState(new int[]{android.R.attr.state_pressed},focus);s.addState(new int[]{},authBox());return s;}
 Drawable authPrimarySelector(){StateListDrawable s=new StateListDrawable();GradientDrawable focus=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{GREEN,0xffff78b7,GREEN});focus.setCornerRadius(dp(30));focus.setStroke(dp(3),Color.WHITE);GradientDrawable normal=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{GREEN,0xffff5aa6,GREEN});normal.setCornerRadius(dp(30));s.addState(new int[]{android.R.attr.state_focused},focus);s.addState(new int[]{android.R.attr.state_pressed},focus);s.addState(new int[]{},normal);return s;}
 Drawable authSecondarySelector(){StateListDrawable s=new StateListDrawable();GradientDrawable focus=new GradientDrawable();focus.setColor(0xff331321);focus.setCornerRadius(dp(30));focus.setStroke(dp(3),GREEN);GradientDrawable normal=new GradientDrawable();normal.setColor(0x66180d14);normal.setCornerRadius(dp(30));normal.setStroke(dp(1),GREEN);s.addState(new int[]{android.R.attr.state_focused},focus);s.addState(new int[]{android.R.attr.state_pressed},focus);s.addState(new int[]{},normal);return s;}
 EditText authEdit(String hint,boolean pass,int icon){EditText v=new EditText(this);v.setHint(hint);v.setHintTextColor(0xffa9aeac);v.setTextColor(Color.WHITE);uiTextSize(v,17);v.setSingleLine();v.setPadding(dp(20),0,dp(18),0);v.setBackground(authFieldSelector());v.setCompoundDrawablesWithIntrinsicBounds(icon,0,pass?R.drawable.ic_eye_off:0,0);v.setCompoundDrawablePadding(dp(14));v.setFocusable(true);v.setFocusableInTouchMode(true);if(pass)v.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);if(tvMode)prepareTvTextInput(v);return v;}
 Button authPrimary(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);uiTextSize(b,18);b.setTypeface(null,1);b.setAllCaps(false);b.setBackground(authPrimarySelector());b.setFocusable(true);return b;}
 Button authSecondary(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);uiTextSize(b,15);b.setTypeface(null,1);b.setAllCaps(false);b.setBackground(authSecondarySelector());b.setFocusable(true);return b;}
 TextView authLabel(String s){TextView v=t(s,15);v.setPadding(dp(2),0,0,dp(6));v.setTextColor(0xfff2f2f2);return v;}
 boolean openExternalUri(String uri){if(uri==null||uri.trim().isEmpty())return false;try{Intent in=new Intent(Intent.ACTION_VIEW,Uri.parse(uri));if(in.resolveActivity(getPackageManager())==null)return false;startActivity(in);return true;}catch(Exception ignored){return false;}}
 String currentDeviceName(){
  String maker=android.os.Build.MANUFACTURER==null?"":android.os.Build.MANUFACTURER.trim();
  String model=android.os.Build.MODEL==null?"Android":android.os.Build.MODEL.trim();
  if(!maker.isEmpty()&&!model.toLowerCase(java.util.Locale.ROOT).startsWith(maker.toLowerCase(java.util.Locale.ROOT)))return maker+" "+model;
  return model.isEmpty()?"Android":model;
 }
 String currentDeviceType(){return DeviceCompat.isTelevisionDevice(this)||tvMode?"tv":"android";}
 void syncDevice(Runnable done){
  if(uid==null||uid.isEmpty()){if(done!=null)done.run();return;}
  Api.post("device_sync",Api.m("user_id",uid,"device_id",deviceId(),"device_name",currentDeviceName(),"device_type",currentDeviceType()),new Api.CB(){
   public void ok(JSONObject j){if(done!=null)runOnUiThread(done);}
   public void err(String e){if(done!=null)runOnUiThread(done);}
  });
 }
 void refreshAccountContext(Runnable done){
  if(uid==null||uid.isEmpty()){if(done!=null)done.run();return;}
  Api.post("get_profile",Api.m("user_id",uid,"device_id",deviceId(),"device_name",currentDeviceName(),"device_type",currentDeviceType()),new Api.CB(){public void ok(JSONObject j){
   JSONArray a=j.optJSONArray("result");JSONObject u=a!=null&&a.length()>0?a.optJSONObject(0):null;
   android.content.SharedPreferences.Editor ed=sp.edit();
   if(u!=null){
    String n=u.optString("full_name",u.optString("user_name",""));if(!n.isEmpty())ed.putString("name",n);
    String em=u.optString("email","");if(!em.isEmpty())ed.putString("email",em);String un=u.optString("username",u.optString("user_name",""));if(!un.isEmpty())ed.putString("username",un);
    String rc=u.optString("reseller_code","");String rn=u.optString("reseller_name","");String sw=u.optString("support_whatsapp","");
    if(!rc.isEmpty()){reseller=rc;ed.putString("reseller",rc);}else if(u.optInt("reseller_id",0)==0){reseller="";ed.remove("reseller");}
    if(!rn.isEmpty())ed.putString("reseller_name",rn);
    ed.putString("support",sw);
    ed.putBoolean("parent_pin_set",u.optInt("parent_control_has_pin",0)==1);
    boolean enabled=u.optInt("parent_control_status",0)==1;
    ed.putBoolean("adult",enabled);
   }
   ed.apply();if(done!=null)runOnUiThread(done);
  }public void err(String e){if(done!=null)runOnUiThread(done);}});
 }

void showForgotPasswordDialog(EditText identifierField){
 final Dialog d=new Dialog(this);
 LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(18),dp(16),dp(18),dp(14));
 GradientDrawable bg=round(0xff170b11,26);bg.setStroke(dp(1),0xff5b2d44);card.setBackground(bg);
 LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);
 ImageView lock=new ImageView(this);lock.setImageResource(R.drawable.ic_password);lock.setColorFilter(GREEN);lock.setPadding(dp(9),dp(9),dp(9),dp(9));lock.setBackground(round(0xff331223,18));head.addView(lock,new LinearLayout.LayoutParams(dp(42),dp(42)));
 LinearLayout hw=new LinearLayout(this);hw.setOrientation(LinearLayout.VERTICAL);hw.setPadding(dp(11),0,0,0);TextView title=t("Recuperar acesso",20);title.setTypeface(null,1);title.setPadding(0,0,0,0);TextView sub=t("Receba no e-mail um link para criar uma nova senha.",12);sub.setTextColor(0xffa49aa1);sub.setPadding(0,dp(2),0,0);hw.addView(title);hw.addView(sub);head.addView(hw,new LinearLayout.LayoutParams(0,-2,1));card.addView(head);
 EditText ident=e("Usuário, e-mail ou código de acesso",false);String pre=identifierField==null?"":identifierField.getText().toString().trim();if(!pre.isEmpty())ident.setText(pre);ident.setSingleLine(true);ident.setPadding(dp(15),0,dp(15),0);GradientDrawable ib=round(0xff221019,16);ib.setStroke(dp(1),0xff523142);ident.setBackground(ib);LinearLayout.LayoutParams ilp=new LinearLayout.LayoutParams(-1,dp(50));ilp.setMargins(0,dp(14),0,0);card.addView(ident,ilp);
 TextView status=t("",12);status.setTextColor(0xffb6abb2);status.setPadding(dp(2),dp(7),dp(2),dp(5));status.setMinHeight(dp(27));card.addView(status,new LinearLayout.LayoutParams(-1,-2));
 TextView send=t("Enviar link por e-mail",14);send.setGravity(Gravity.CENTER);send.setTypeface(null,1);send.setTextColor(0xff11040a);send.setBackground(round(GREEN,16));send.setFocusable(true);card.addView(send,new LinearLayout.LayoutParams(-1,dp(48)));
 TextView cancel=t("Cancelar",13);cancel.setGravity(Gravity.CENTER);cancel.setTextColor(0xffb8adb4);cancel.setPadding(0,dp(10),0,dp(2));cancel.setFocusable(true);card.addView(cancel,new LinearLayout.LayoutParams(-1,dp(42)));
 cancel.setOnClickListener(v->d.dismiss());
 send.setOnClickListener(v->{String id=ident.getText().toString().trim();if(id.isEmpty()){status.setTextColor(0xffff7b82);status.setText("Informe sua conta.");return;}send.setEnabled(false);send.setAlpha(.62f);status.setTextColor(0xffb6abb2);status.setText("Enviando link…");sendPasswordResetRequest(id,status,send,ident);});
 d.setContentView(card);stabilizeInputDialog(d,card);d.setOnShowListener(x->{Window w=d.getWindow();if(w!=null){int max=tvMode?dp(470):dp(360);w.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(48),max),-2);}if(tvMode)requestTvFocus(ident);});d.show();
}

 void sendPasswordResetRequest(String id,TextView status,TextView send,EditText ident){
  final Map<String,String> data=Api.m("identifier",id);
  final Api.CB finish=new Api.CB(){
   public void ok(JSONObject j){runOnUiThread(()->{send.setEnabled(true);send.setAlpha(1f);int st=j.optInt("status",500);if(st==200){status.setTextColor(GREEN);status.setText(j.optString("message","Link enviado. Verifique seu e-mail."));hideKeyboard(ident);ident.clearFocus();}else{status.setTextColor(0xffff7b82);status.setText(st>=500?"Não foi possível enviar o e-mail de recuperação. Tente novamente em instantes.":j.optString("message","Não foi possível enviar o e-mail."));}});}
   public void err(String e){runOnUiThread(()->{send.setEnabled(true);send.setAlpha(1f);status.setTextColor(0xffff7b82);status.setText("Não foi possível enviar o e-mail de recuperação. Tente novamente em instantes.");});}
  };
  // v5.16: uma única chamada de recuperação. O fluxo antigo tentava até três
  // endpoints; se a primeira mensagem fosse aceita mas a resposta JSON falhasse,
  // o fallback podia enviar o mesmo e-mail novamente.
  Api.post("forgot_password.php",data,finish);
 }
 void openSupport(){
  String w=sp.getString("support","").replaceAll("\\D","");
  if(!w.isEmpty()){
   if(!w.startsWith("55"))w="55"+w;
   if(!openExternalUri("https://wa.me/"+w))showAppNotice("Suporte: +"+w,false);
  }else{
   refreshAccountContext(()->{String fresh=sp.getString("support","").replaceAll("\\D","");if(!fresh.isEmpty())openSupport();else showAppNotice("O suporte ainda não foi configurado pelo vendedor.",true);});
  }
 }
 void base(){base(false);} void base(boolean loginBackground){FrameLayout frame=new FrameLayout(this);frame.setBackgroundColor(BG);if(loginBackground){getWindow().setStatusBarColor(0xff0b060a);getWindow().setNavigationBarColor(0xff0b060a);ImageView bg=new ImageView(this);bg.setScaleType(ImageView.ScaleType.CENTER_CROP);bg.setBackgroundColor(0xff120910);String panelBg=bgUrl==null?"":bgUrl.trim();if(!panelBg.isEmpty())Img.load(bg,panelBg);frame.addView(bg,new FrameLayout.LayoutParams(-1,-1));View shade=new View(this);shade.setBackgroundColor(0x8a090408);frame.addView(shade,new FrameLayout.LayoutParams(-1,-1));}else{getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);}root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(loginBackground?dp(22):dp(18),loginBackground?dp(14):dp(18),loginBackground?dp(22):dp(18),loginBackground?dp(18):dp(12));frame.addView(root,new FrameLayout.LayoutParams(-1,-1));setContentView(frame);if(tvMode)enableTvRemoteTree(root);} 
 void brand(){brandInto(root);} void brandInto(LinearLayout host){if(host==null)return;ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.FIT_CENTER);applyAppLogo(im);LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,dp(78));ip.setMargins(0,0,0,dp(4));host.addView(im,ip);}
 void login(){authScreen=true;base(true);try{getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE|WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);}catch(Exception ignored){}ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setClipToPadding(false);scroll.setPadding(0,0,0,dp(tvMode?72:28));LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setGravity(Gravity.CENTER_VERTICAL|Gravity.CENTER_HORIZONTAL);c.setMinimumHeight(getResources().getDisplayMetrics().heightPixels-dp(170));int authSide=wideTvUi()?Math.max(dp(48),(getResources().getDisplayMetrics().widthPixels-dp(560))/2):0;c.setPadding(authSide,dp(12),authSide,dp(tvMode?110:52));scroll.addView(c,new ScrollView.LayoutParams(-1,-2));root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));installAuthKeyboardLift(scroll,c);
  ImageView logo=new ImageView(this);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);logo.setAdjustViewBounds(true);logo.setContentDescription(appName);applyAppLogo(logo);LinearLayout.LayoutParams logoLp=new LinearLayout.LayoutParams(-1,dp(82));logoLp.setMargins(dp(24),dp(2),dp(24),0);c.addView(logo,logoLp);TextView tag=t("MAIS QUE ENTRETENIMENTO",11);tag.setTextColor(0xffcfc3cb);tag.setGravity(Gravity.CENTER);tag.setLetterSpacing(.28f);tag.setPadding(0,0,0,dp(22));c.addView(tag);
  TextView title=t("Bem-vindo de volta!",27);title.setTypeface(null,1);title.setGravity(Gravity.CENTER);title.setPadding(0,dp(4),0,0);c.addView(title);TextView sub=t("Faça login para continuar assistindo.",16);sub.setTextColor(0xffb6b9b7);sub.setGravity(Gravity.CENTER);sub.setPadding(0,dp(4),0,dp(12));c.addView(sub);

  // v5.15: login identifica automaticamente a conta e a revenda pelo usuário/e-mail/código de acesso.
c.addView(authLabel("Usuário, e-mail ou código de acesso"));EditText email=authEdit("Digite usuário, e-mail ou código",false,R.drawable.ic_email);c.addView(email,new LinearLayout.LayoutParams(-1,dp(58)));Space g1=new Space(this);c.addView(g1,new LinearLayout.LayoutParams(1,dp(14)));c.addView(authLabel("Senha"));LinearLayout passRow=new LinearLayout(this);passRow.setOrientation(LinearLayout.HORIZONTAL);passRow.setGravity(Gravity.CENTER_VERTICAL);EditText pass=authEdit("Sua senha",true,R.drawable.ic_lock);pass.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_lock,0,0,0);LinearLayout.LayoutParams passLp=new LinearLayout.LayoutParams(0,dp(58),1);passRow.addView(pass,passLp);ImageButton eye=new ImageButton(this);eye.setImageResource(R.drawable.ic_eye_off);eye.setColorFilter(Color.WHITE);eye.setScaleType(ImageView.ScaleType.CENTER_INSIDE);eye.setPadding(dp(7),dp(7),dp(7),dp(7));eye.setBackground(authSecondarySelector());eye.setFocusable(true);eye.setFocusableInTouchMode(false);eye.setContentDescription("Mostrar senha");LinearLayout.LayoutParams eyeLp=new LinearLayout.LayoutParams(dp(36),dp(36));eyeLp.setMargins(dp(8),0,0,0);passRow.addView(eye,eyeLp);c.addView(passRow,new LinearLayout.LayoutParams(-1,dp(58)));final boolean[] vis={false};eye.setOnClickListener(v->{vis[0]=!vis[0];int cursor=Math.max(0,pass.getSelectionStart());pass.setTransformationMethod(vis[0]?android.text.method.HideReturnsTransformationMethod.getInstance():android.text.method.PasswordTransformationMethod.getInstance());pass.setSelection(Math.min(cursor,pass.length()));eye.setImageResource(vis[0]?R.drawable.ic_eye:R.drawable.ic_eye_off);eye.setContentDescription(vis[0]?"Ocultar senha":"Mostrar senha");if(pass.hasFocus()){keepInputAboveKeyboard(pass);if(tvMode)pass.postDelayed(()->showTvKeyboard(pass),80);}});
TextView reset=t("Esqueci minha senha",13);reset.setTextColor(0xffb9bebc);reset.setGravity(Gravity.RIGHT);reset.setPadding(0,dp(6),dp(4),dp(10));reset.setOnClickListener(v->showForgotPasswordDialog(email));c.addView(reset);
  Button go=authPrimary("Entrar  →");c.addView(go,new LinearLayout.LayoutParams(-1,dp(62)));Space g2=new Space(this);c.addView(g2,new LinearLayout.LayoutParams(1,dp(12)));Button create=authSecondary("Fazer teste grátis");c.addView(create,new LinearLayout.LayoutParams(-1,dp(60)));TextView support=t("Precisa de ajuda? Contate o suporte",14);support.setTextColor(0xffb1b5b3);support.setGravity(Gravity.CENTER);support.setPadding(dp(4),dp(14),dp(4),dp(8));support.setOnClickListener(v->openSupport());c.addView(support);TextView msg=t("",14);msg.setTextColor(0xffff7777);msg.setGravity(Gravity.CENTER);c.addView(msg);create.setOnClickListener(v->registerScreen());email.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_NORMAL);bindImeMove(email,pass,android.view.inputmethod.EditorInfo.IME_ACTION_NEXT);bindImeMove(pass,go,android.view.inputmethod.EditorInfo.IME_ACTION_DONE);if(tvMode){linkTvVertical(email,pass);linkTvHorizontal(pass,eye);linkTvVertical(pass,go);linkTvVertical(eye,go);linkTvVertical(go,create);requestTvFocus(email);}
  go.setOnClickListener(v->{if(email.getText().toString().trim().isEmpty()||pass.getText().length()==0){msg.setText("Informe usuário, e-mail ou código e a senha.");return;}go.setEnabled(false);reseller="";sp.edit().remove("reseller").remove("reseller_name").remove("support").apply();doLogin(email.getText().toString(),pass.getText().toString(),msg,go);});}
 void registerScreen(){
  authScreen=true;base(true);
  TextView back=t("‹ Voltar",16);back.setTextColor(GREEN);back.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);back.setOnClickListener(v->login());root.addView(back,new LinearLayout.LayoutParams(-1,dp(44)));
  ScrollView screen=new ScrollView(this);screen.setFillViewport(true);screen.setClipToPadding(false);screen.setVerticalScrollBarEnabled(false);LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setGravity(Gravity.CENTER_HORIZONTAL);int side=wideTvUi()?Math.max(dp(48),(getResources().getDisplayMetrics().widthPixels-dp(620))/2):0;page.setPadding(side,dp(4),side,dp(34));screen.addView(page,new ScrollView.LayoutParams(-1,-2));root.addView(screen,new LinearLayout.LayoutParams(-1,0,1));installAuthKeyboardLift(screen,page);
  brandInto(page);TextView title=t("Fazer teste grátis",23);title.setTypeface(null,1);title.setGravity(Gravity.CENTER);page.addView(title);TextView sub=t("Crie seu acesso e inicie seu período de teste grátis.",15);sub.setTextColor(0xffb8adb4);sub.setGravity(Gravity.CENTER);page.addView(sub);Space topGap=new Space(this);page.addView(topGap,new LinearLayout.LayoutParams(1,dp(10)));
  LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setVisibility(View.VISIBLE);EditText name=e("Nome completo",false),username=e("Usuário para entrar no aplicativo",false),email=e("E-mail",false),phone=e("WhatsApp (opcional)",false),pass=e("Senha (mínimo 6 caracteres)",true);name.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PERSON_NAME);username.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_NORMAL);username.setSingleLine(true);email.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);phone.setInputType(InputType.TYPE_CLASS_PHONE);form.addView(name,new LinearLayout.LayoutParams(-1,dp(58)));Space g1=new Space(this);form.addView(g1,new LinearLayout.LayoutParams(1,dp(10)));form.addView(username,new LinearLayout.LayoutParams(-1,dp(58)));TextView userHint=t("Use 3 a 24 caracteres: letras, números, ponto, traço ou underline.",11);userHint.setTextColor(0xff978e94);userHint.setPadding(dp(4),dp(3),dp(4),dp(6));form.addView(userHint);form.addView(email,new LinearLayout.LayoutParams(-1,dp(58)));Space g2=new Space(this);form.addView(g2,new LinearLayout.LayoutParams(1,dp(10)));form.addView(phone,new LinearLayout.LayoutParams(-1,dp(58)));Space g3=new Space(this);form.addView(g3,new LinearLayout.LayoutParams(1,dp(10)));form.addView(pass,new LinearLayout.LayoutParams(-1,dp(58)));TextView show=t("Mostrar senha",14);show.setTextColor(GREEN);show.setGravity(Gravity.RIGHT);show.setOnClickListener(v->{boolean visible=(pass.getInputType()&InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD)==InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD;pass.setInputType(InputType.TYPE_CLASS_TEXT|(visible?InputType.TYPE_TEXT_VARIATION_PASSWORD:InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD));pass.setSelection(pass.length());show.setText(visible?"Mostrar senha":"Ocultar senha");});form.addView(show,new LinearLayout.LayoutParams(-1,dp(42)));Space g4=new Space(this);form.addView(g4,new LinearLayout.LayoutParams(1,dp(8)));Button go=btn("Iniciar teste grátis");form.addView(go,new LinearLayout.LayoutParams(-1,dp(58)));TextView msg=t("",14);msg.setTextColor(0xffff7777);msg.setGravity(Gravity.CENTER);form.addView(msg);page.addView(form,new LinearLayout.LayoutParams(-1,-2));
  bindImeMove(name,username,android.view.inputmethod.EditorInfo.IME_ACTION_NEXT);bindImeMove(username,email,android.view.inputmethod.EditorInfo.IME_ACTION_NEXT);bindImeMove(email,phone,android.view.inputmethod.EditorInfo.IME_ACTION_NEXT);bindImeMove(phone,pass,android.view.inputmethod.EditorInfo.IME_ACTION_NEXT);bindImeMove(pass,go,android.view.inputmethod.EditorInfo.IME_ACTION_DONE);
  if(tvMode){linkTvVertical(name,username);linkTvVertical(username,email);linkTvVertical(email,phone);linkTvVertical(phone,pass);linkTvVertical(pass,go);}
  go.setOnClickListener(v->{hideKeyboard(go);String un=username.getText().toString().trim().toLowerCase(java.util.Locale.ROOT);if(name.getText().toString().trim().isEmpty()||un.isEmpty()||email.getText().toString().trim().isEmpty()){msg.setText("Informe nome, usuário e e-mail.");if(tvMode)requestTvFocus(name);return;}if(!un.matches("[a-z0-9._-]{3,24}")){msg.setText("Usuário inválido. Use 3 a 24 letras, números, ponto, traço ou underline.");if(tvMode)requestTvFocus(username);return;}if(pass.getText().length()<6){msg.setText("A senha precisa ter pelo menos 6 caracteres.");if(tvMode)requestTvFocus(pass);return;}go.setEnabled(false);msg.setText("");Api.post("register",Api.m("name",name.getText().toString().trim(),"username",un,"email",email.getText().toString().trim(),"password",pass.getText().toString(),"mobile_number",phone.getText().toString().trim(),"device_type","android"),new Api.CB(){public void ok(JSONObject x){JSONArray a=x.optJSONArray("result");if(x.optInt("status")!=200||a==null||a.length()==0){msg.setText(x.optString("message","Não foi possível iniciar o teste grátis"));go.setEnabled(true);if(tvMode)requestTvFocus(go);return;}JSONObject u=a.optJSONObject(0);uid=u.optString("id");sp.edit().putString("uid",uid).putString("name",u.optString("full_name",name.getText().toString().trim())).putString("username",u.optString("username",un)).putString("email",u.optString("email",email.getText().toString().trim())).apply();Toast.makeText(MainActivity.this,"Teste grátis criado. Você pode entrar com usuário, e-mail ou código.",Toast.LENGTH_LONG).show();refreshEntitlements(()->shell());}public void err(String e){msg.setText("Falha de conexão: "+e);go.setEnabled(true);if(tvMode)requestTvFocus(go);}});});
  if(tvMode){prepareTvFocusTree(page);requestTvFocus(name);}
 }
 void doLogin(String email,String pass,TextView msg,Button go){String id=email==null?"":email.trim();Api.post("login",Api.m("identifier",id,"email",id,"password",pass,"device_type",currentDeviceType(),"device_id",deviceId(),"device_name",currentDeviceName()),new Api.CB(){public void ok(JSONObject j){JSONArray a=j.optJSONArray("result");if(j.optInt("status")!=200||a==null||a.length()==0){msg.setText(j.optString("message","Dados incorretos"));go.setEnabled(true);return;}JSONObject u=a.optJSONObject(0);uid=u.optString("id");android.content.SharedPreferences.Editor ed=sp.edit().putString("uid",uid).putString("name",u.optString("full_name")).putString("username",u.optString("username",u.optString("user_name",""))).putString("email",u.optString("email"));String rc=u.optString("reseller_code","");String rn=u.optString("reseller_name","");String sw=u.optString("support_whatsapp","");if(!rc.isEmpty()){reseller=rc;ed.putString("reseller",rc);}if(!rn.isEmpty())ed.putString("reseller_name",rn);if(!sw.isEmpty())ed.putString("support",sw);ed.apply();authScreen=false;shell();syncDevice(null);refreshAccountContext(null);refreshEntitlements(()->{});}public void err(String x){msg.setText("Falha de conexão: "+x);go.setEnabled(true);}});}
 void startExistingSession(){
  syncDevice(null);refreshAccountContext(null);
  JSONObject access=readCachedAccessStatus();if(access!=null)applyEntitlements(access);
  startYellyStartupSync(()->{shell();refreshEntitlements(()->{if(accessDenied(readCachedAccessStatus()))showAccessExpiredDialog(accessDeniedMessage(readCachedAccessStatus()));});});
 }
 void startExistingSessionReady(){
  if(Api.PROVIDER==null||Api.PROVIDER.trim().isEmpty()){providerSelectAfterLogin();return;}
  validateCurrentProviderAvailability(()->startExistingSessionReadyConfirmed());
 }
 
 void startExistingSessionReadyConfirmed(){
  if(Api.PROVIDER==null||Api.PROVIDER.trim().isEmpty()){providerSelectAfterLogin();return;}
  JSONObject cache=readHomeCache();
  if(cache!=null&&cache.optJSONArray("result")!=null&&cache.optJSONArray("result").length()>0&&catalogFlagsReady(cache)){
   // 5.28.31: só abre a Home quando o snapshot possui todas as categorias com
   // primeira página sincronizada. Cache parcial volta para a tela única de sync.
   final JSONObject readyCache=cache;
   shell();markPersistentHomeUsed();
   new Handler(Looper.getMainLooper()).postDelayed(()->{
    if(isFinishing())return;
    warmHomeImages(readyCache,()->{});
    prefetchDetailsFromCatalog(readyCache,16);
    warmCachedHomeAssets(readyCache);
    scheduleCatalogRefreshIfNeeded();
   },220);
   return;
  }
  showQuickResumeScreen();
  loadPersistentHomeAsync(new PersistentHomeCB(){public void ok(JSONObject disk){
   if(isFinishing())return;saveHomeCache(disk);
   if(!catalogFlagsReady(disk)){shell();return;}
   shell();markPersistentHomeUsed();
   new Handler(Looper.getMainLooper()).postDelayed(()->{
    if(isFinishing())return;
    warmHomeImages(disk,()->{});
    prefetchDetailsFromCatalog(disk,16);
    warmCachedHomeAssets(disk);
    scheduleCatalogRefreshIfNeeded();
   },220);
  }public void miss(){if(!isFinishing())shell();}});
 }
 void validateCurrentProviderAvailability(Runnable available){
  final String current=Api.PROVIDER==null?"":Api.PROVIDER.trim();if(current.isEmpty()){providerSelectAfterLogin();return;}if(providerAvailabilityCheckBusy){if(available!=null)available.run();return;}providerAvailabilityCheckBusy=true;
  Api.post("get_providers",Api.m("user_id",uid,"reseller_code",reseller),new Api.CB(){public void ok(JSONObject j){providerAvailabilityCheckBusy=false;JSONArray a=j.optJSONArray("result");boolean found=false;if(a!=null){for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;String id=o.optString("id",o.optString("provider_id",""));if(current.equals(id)){found=true;syncCurrentProviderCounts(o,false);break;}}}if(found){providerAvailabilityLastCheck=android.os.SystemClock.elapsedRealtime();if(available!=null)available.run();return;}forgetUnavailableProvider();providerSelectAfterLogin();}public void err(String e){providerAvailabilityCheckBusy=false;if(available!=null)available.run();}});
 }
 void forgetUnavailableProvider(){
  clearPreparedHome();Api.PROVIDER="";sessionHasLive=false;sessionLiveKnown=false;tvActiveChannel=null;tvSelectedCategory="";sp.edit().remove("provider_id").remove("provider_name").remove("provider_movies_count").remove("provider_series_count").remove("provider_live_count").remove("provider_has_live").apply();
 }
 void checkCurrentProviderAvailability(boolean force){
  if(uid==null||uid.isEmpty()||Api.PROVIDER==null||Api.PROVIDER.trim().isEmpty()||authScreen||providerSwitchScreen||providerAvailabilityCheckBusy)return;long now=android.os.SystemClock.elapsedRealtime();if(!force&&providerAvailabilityLastCheck>0&&now-providerAvailabilityLastCheck<30000)return;providerAvailabilityCheckBusy=true;final String current=Api.PROVIDER.trim();Api.post("get_providers",Api.m("user_id",uid,"reseller_code",reseller),new Api.CB(){public void ok(JSONObject j){providerAvailabilityCheckBusy=false;providerAvailabilityLastCheck=android.os.SystemClock.elapsedRealtime();JSONArray a=j.optJSONArray("result");boolean found=false;if(a!=null){for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;String id=o.optString("id",o.optString("provider_id",""));if(current.equals(id)){found=true;syncCurrentProviderCounts(o,true);break;}}}if(!found&&current.equals(Api.PROVIDER==null?"":Api.PROVIDER.trim())){forgetUnavailableProvider();providerSelectAfterLogin();}}public void err(String e){providerAvailabilityCheckBusy=false;}});
 }
 void providerSelectAfterLogin(){providerSelectAfterLogin(false);}
 void providerSelectAfterLogin(boolean canCancel){
  authScreen=false;
  boolean hasPreviousProvider=(Api.PROVIDER!=null&&!Api.PROVIDER.trim().isEmpty())||!sp.getString("provider_id","").trim().isEmpty();
  final boolean canReturn=canCancel||hasPreviousProvider;
  providerSwitchScreen=canReturn;
  base(true);
  int providerSafeTop=Math.max(standardPageTopPx(),statusBarHeightPx()+dp(8));
  root.setPadding(dp(12),providerSafeTop,dp(12),dp(6));

  // Cabeçalho fixo e compacto. O título fica no centro geométrico da tela.
  LinearLayout top=new LinearLayout(this);
  top.setGravity(Gravity.CENTER_VERTICAL);
  top.setPadding(0,0,0,dp(2));

  ImageView back=new ImageView(this);
  back.setImageResource(R.drawable.ic_arrow_back);
  back.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
  back.setPadding(dp(9),dp(9),dp(9),dp(9));
  back.setAlpha(canReturn?1f:0f);
  back.setFocusable(canReturn);
  back.setClickable(canReturn);
  back.setContentDescription("Voltar");
  if(canReturn){
   if(Build.VERSION.SDK_INT>=21)back.setImageTintList(android.content.res.ColorStateList.valueOf(Color.WHITE));
   GradientDrawable bbg=round(0x851d1318,18);bbg.setStroke(dp(1),0xff492b3a);back.setBackground(bbg);
   back.setOnClickListener(v->cancelProviderSwitch());
   if(tvMode)armTvFocus(back);
  }
  LinearLayout.LayoutParams backLp=new LinearLayout.LayoutParams(dp(42),dp(42));backLp.setMargins(0,dp(1),0,0);top.addView(back,backLp);

  TextView header=t("Servidores",19);
  header.setTypeface(null,1);header.setGravity(Gravity.CENTER);header.setIncludeFontPadding(true);
  top.addView(header,new LinearLayout.LayoutParams(0,dp(40),1));

  View spacer=new View(this);
  top.addView(spacer,new LinearLayout.LayoutParams(dp(42),dp(42)));
  root.addView(top,new LinearLayout.LayoutParams(-1,dp(42)));

  ScrollView screen=new ScrollView(this);
  screen.setFillViewport(true);screen.setVerticalScrollBarEnabled(false);screen.setClipToPadding(false);
  screen.setPadding(0,0,0,dp(16));

  LinearLayout wrap=new LinearLayout(this);
  wrap.setOrientation(LinearLayout.VERTICAL);
  wrap.setGravity(Gravity.CENTER_HORIZONTAL);
  int providerSide=wideTvUi()?Math.max(dp(48),(getResources().getDisplayMetrics().widthPixels-dp(720))/2):0;
  wrap.setPadding(providerSide,0,providerSide,dp(10));
  // Sem translationY: evita cortar logo/cabeçalho e mantém a tela estável ao voltar.
  screen.addView(wrap,new ScrollView.LayoutParams(-1,-2));
  root.addView(screen,new LinearLayout.LayoutParams(-1,0,1));

  LinearLayout intro=new LinearLayout(this);intro.setOrientation(LinearLayout.VERTICAL);intro.setGravity(Gravity.CENTER_HORIZONTAL);intro.setPadding(0,dp(4),0,dp(10));

  LinearLayout introMain=new LinearLayout(this);introMain.setOrientation(LinearLayout.HORIZONTAL);introMain.setGravity(Gravity.CENTER_VERTICAL);
  ImageView logo=new ImageView(this);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);applyAppLogo(logo);
  introMain.addView(logo,new LinearLayout.LayoutParams(dp(tvMode?48:42),dp(tvMode?38:32)));
  TextView title=t("Selecione um servidor",17);title.setTypeface(null,1);title.setTextColor(Color.WHITE);title.setGravity(Gravity.CENTER_VERTICAL);title.setIncludeFontPadding(true);
  LinearLayout.LayoutParams titleLp=new LinearLayout.LayoutParams(-2,-2);titleLp.setMargins(dp(9),0,0,0);introMain.addView(title,titleLp);
  intro.addView(introMain,new LinearLayout.LayoutParams(-2,-2));

  TextView sub=t("Escolha a fonte que deseja usar",10);sub.setTextColor(0xff978e94);sub.setGravity(Gravity.CENTER);sub.setIncludeFontPadding(true);
  LinearLayout.LayoutParams slp=new LinearLayout.LayoutParams(-2,-2);slp.setMargins(0,dp(3),0,0);intro.addView(sub,slp);
  wrap.addView(intro,new LinearLayout.LayoutParams(-1,-2));

  LinearLayout list=new LinearLayout(this);
  list.setOrientation(LinearLayout.VERTICAL);list.setGravity(Gravity.CENTER_HORIZONTAL);
  list.setPadding(dp(2),0,dp(2),dp(10));wrap.addView(list,new LinearLayout.LayoutParams(-1,-2));

  TextView loading=t("Carregando servidores…",13);
  loading.setTextColor(0xffb8adb4);loading.setGravity(Gravity.CENTER);
  list.addView(loading,new LinearLayout.LayoutParams(-1,dp(54)));
  loadProviderChoices(list,loading);
 }
 void loadProviderChoices(final LinearLayout host,final TextView loading){
  if(host!=null)host.setTag("provider_loading");
  Api.post("get_providers",Api.m("user_id",uid,"reseller_code",reseller,"fresh","1"),new Api.CB(){public void ok(JSONObject j){JSONArray a=j.optJSONArray("result");host.removeAllViews();if(a==null||a.length()==0){providerChoiceError(host,"Nenhum servidor disponível.");return;}renderProviderChoices(host,a);}public void err(String e){loadProviderChoicesLegacy(host);}});
 }
 int providerCount(JSONObject o,String kind){
  if(o==null)return 0;
  int v=0;
  if("movies".equals(kind)){
   if(o.has("movies_count"))v=o.optInt("movies_count",0);else if(o.has("movies"))v=o.optInt("movies",0);
  }else if("series".equals(kind)){
   if(o.has("series_count"))v=o.optInt("series_count",0);else if(o.has("series"))v=o.optInt("series",0);
  }else if("live".equals(kind)){
   if(o.has("channels_count"))v=o.optInt("channels_count",0);else if(o.has("live_count"))v=o.optInt("live_count",0);else if(o.has("channels"))v=o.optInt("channels",0);else if(o.has("tv_count"))v=o.optInt("tv_count",0);
  }
  return Math.max(0,v);
 }
 String providerCapKey(String id,String name,String kind){String base=(id==null||id.trim().isEmpty()?name:id);if(base==null)base="";base=base.trim().toLowerCase(java.util.Locale.ROOT).replaceAll("[^a-z0-9_-]+","_");return "provider_cap_v52870_"+base+"_"+kind;}
 int cachedProviderCap(String id,String name,String kind){return sp.getInt(providerCapKey(id,name,kind),-1);}
 void rememberProviderCaps(String id,String name,int movies,int series,int live){android.content.SharedPreferences.Editor e=sp.edit();if(movies>=0)e.putInt(providerCapKey(id,name,"movies"),movies);if(series>=0)e.putInt(providerCapKey(id,name,"series"),series);if(live>=0)e.putInt(providerCapKey(id,name,"live"),live);e.apply();}
 boolean currentProviderHasLive(){
  int direct=sp.getInt("provider_live_count",-1);
  if(direct>=0){sessionLiveKnown=true;sessionHasLive=direct>0;return sessionHasLive;}
  if(sessionLiveKnown)return sessionHasLive;
  return false;
 }
 boolean syncCurrentProviderCounts(JSONObject o,boolean refreshUi){
  if(o==null)return false;String id=o.optString("id",o.optString("provider_id",""));String current=Api.PROVIDER==null?"":Api.PROVIDER;if(id.isEmpty()||!id.equals(current))return false;
  String name=o.optString("name",sp.getString("provider_name","Servidor"));int mv=providerCount(o,"movies"),se=providerCount(o,"series"),lv=providerCount(o,"live");
  int oldMv=sp.getInt("provider_movies_count",-1),oldSe=sp.getInt("provider_series_count",-1),oldLv=sp.getInt("provider_live_count",-1);
  boolean changed=oldMv!=mv||oldSe!=se||oldLv!=lv;
  sessionLiveKnown=true;sessionHasLive=lv>0;rememberProviderCaps(id,name,mv,se,lv);
  sp.edit().putString("provider_name",name).putInt("provider_movies_count",mv).putInt("provider_series_count",se).putInt("provider_live_count",lv).putBoolean("provider_has_live",sessionHasLive).apply();
  if(changed){clearPreparedHome();if(refreshUi&&!authScreen&&!providerSwitchScreen){runOnUiThread(()->{if(currentNavIndex==2&&!sessionHasLive)home();else if(currentNavIndex==0)home();else shell();});}}
  return changed;
 }
 void probeCurrentProviderLive(int fallbackLiveCount,LiveProbeCB cb){probeCurrentProviderLiveAttempt(fallbackLiveCount,1,cb);}
 void probeCurrentProviderLiveAttempt(int fallbackLiveCount,int retries,LiveProbeCB cb){
  final String providerAtRequest=Api.PROVIDER==null?"":Api.PROVIDER;
  // Primeiro usa exatamente o formato antigo que sempre carregou canais no celular e nas versões estáveis.
  Api.post("get_channel",Api.m("user_id",uid,"category_id","","limit","5","offset","0","search",""),new Api.CB(){public void ok(JSONObject j){
   if(!providerAtRequest.equals(Api.PROVIDER==null?"":Api.PROVIDER))return;JSONArray a=j.optJSONArray("result");if(j.optInt("status",200)==200&&a!=null&&a.length()>0){rememberLiveProbe(providerAtRequest,a,cb);return;}probeCurrentProviderLiveTyped(fallbackLiveCount,retries,providerAtRequest,cb);
  }public void err(String e){if(!providerAtRequest.equals(Api.PROVIDER==null?"":Api.PROVIDER))return;probeCurrentProviderLiveTyped(fallbackLiveCount,retries,providerAtRequest,cb);}});
 }
 void probeCurrentProviderLiveTyped(int fallbackLiveCount,int retries,String providerAtRequest,LiveProbeCB cb){
  Api.post("get_channel",Api.m("user_id",uid,"type","live","category_id","","limit","5","offset","0","search",""),new Api.CB(){public void ok(JSONObject j){if(!providerAtRequest.equals(Api.PROVIDER==null?"":Api.PROVIDER))return;JSONArray a=j.optJSONArray("result");if(j.optInt("status",200)==200&&a!=null&&a.length()>0){rememberLiveProbe(providerAtRequest,a,cb);return;}if(retries>0){new Handler(Looper.getMainLooper()).postDelayed(()->probeCurrentProviderLiveAttempt(fallbackLiveCount,retries-1,cb),450);return;}boolean fallback=fallbackLiveCount>0;sessionHasLive=fallback;sessionLiveKnown=fallbackLiveCount>=0;cb.done(fallback,sessionLiveKnown,a);}public void err(String e){if(!providerAtRequest.equals(Api.PROVIDER==null?"":Api.PROVIDER))return;if(retries>0){new Handler(Looper.getMainLooper()).postDelayed(()->probeCurrentProviderLiveAttempt(fallbackLiveCount,retries-1,cb),450);return;}boolean fallback=fallbackLiveCount>0;sessionHasLive=fallback;sessionLiveKnown=fallbackLiveCount>=0;cb.done(fallback,sessionLiveKnown,null);}});
 }
 void rememberLiveProbe(String providerAtRequest,JSONArray a,LiveProbeCB cb){sessionHasLive=true;sessionLiveKnown=true;String name=sp.getString("provider_name","");rememberProviderCaps(providerAtRequest,name,-1,-1,Math.max(1,a==null?1:a.length()));sp.edit().putBoolean("provider_has_live",true).putInt("provider_live_count",Math.max(1,a==null?1:a.length())).apply();cb.done(true,true,a);}

 JSONArray mergeProviderCapabilities(JSONArray configured,JSONArray actual){
  JSONArray out=new JSONArray();if(configured==null)return out;for(int i=0;i<configured.length();i++){JSONObject base=configured.optJSONObject(i);if(base==null)continue;JSONObject copy;try{copy=new JSONObject(base.toString());}catch(Exception e){copy=base;}String id=copy.optString("id",copy.optString("provider_id",""));String name=copy.optString("name","");JSONObject hit=null;if(actual!=null){for(int k=0;k<actual.length();k++){JSONObject m=actual.optJSONObject(k);if(m==null)continue;String mid=m.optString("id",m.optString("provider_id",""));String mn=m.optString("name","");if((!id.isEmpty()&&id.equals(mid))||(id.isEmpty()&&!name.isEmpty()&&name.equalsIgnoreCase(mn))){hit=m;break;}}}
   int mv=providerCount(hit!=null?hit:copy,"movies"),se=providerCount(hit!=null?hit:copy,"series"),lv=providerCount(hit!=null?hit:copy,"live");
   // get_providers já remove fontes desativadas/offline. Se não veio na resposta real, não deve reaparecer pelo JSON configurado.
   if(actual!=null&&hit==null)continue;
   try{if(hit!=null){if(hit.has("counts_ready"))copy.put("counts_ready",hit.optInt("counts_ready",1));if(hit.has("cache_ready"))copy.put("cache_ready",hit.optInt("cache_ready",1));if(hit.has("source_type"))copy.put("source_type",hit.optString("source_type",""));if(hit.has("available"))copy.put("available",hit.optInt("available",1));if(hit.has("online"))copy.put("online",hit.optInt("online",1));if(hit.has("provider_status"))copy.put("provider_status",hit.optString("provider_status",""));}if(mv>=0)copy.put("movies_count",mv);if(se>=0)copy.put("series_count",se);if(lv>=0)copy.put("channels_count",lv);}catch(Exception ignored){}
   rememberProviderCaps(id,name,mv,se,lv);out.put(copy);
  }return out;
 }
 void loadProviderChoicesLegacy(final LinearLayout host){
  Api.post("get_providers",Api.m("user_id",uid,"reseller_code",reseller),new Api.CB(){public void ok(JSONObject j){JSONArray a=j.optJSONArray("result");host.removeAllViews();if(a==null||a.length()==0){providerChoiceError(host,"Nenhum servidor disponível.");return;}renderProviderChoices(host,a);}public void err(String e){host.removeAllViews();providerChoiceError(host,"Não foi possível carregar os servidores.");}});
 }
 void providerChoiceError(LinearLayout host,String message){host.setTag("provider_error_wait");TextView m=t(message,15);m.setTextColor(0xffff7777);m.setGravity(Gravity.CENTER);host.addView(m,new LinearLayout.LayoutParams(-1,dp(70)));Button retry=authSecondary("Tentar novamente");LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(56));rp.setMargins(0,dp(8),0,0);host.addView(retry,rp);retry.setOnClickListener(v->{host.setTag("provider_loading");host.removeAllViews();TextView l=t("Carregando servidores…",14);l.setTextColor(0xffa79da4);l.setGravity(Gravity.CENTER);host.addView(l,new LinearLayout.LayoutParams(-1,dp(64)));loadProviderChoices(host,l);});host.postDelayed(()->{if(isFinishing()||host.getWindowToken()==null||!"provider_error_wait".equals(String.valueOf(host.getTag())))return;host.setTag("provider_loading");host.removeAllViews();TextView l=t("Verificando provedores disponíveis…",14);l.setTextColor(0xffa79da4);l.setGravity(Gravity.CENTER);host.addView(l,new LinearLayout.LayoutParams(-1,dp(64)));loadProviderChoices(host,l);},15000);if(tvMode)requestTvFocus(retry);}
 void renderProviderChoices(LinearLayout host,JSONArray a){if(a==null||a.length()==0){providerChoiceError(host,"Nenhum servidor disponível no momento.");return;}host.setTag("provider_ready");for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null)providerChoiceCard(host,o);}if(tvMode&&host!=null&&host.getChildCount()>0)requestTvFocus(host.getChildAt(0));}
 String providerContentLabel(boolean movies,boolean series,boolean live){
  StringBuilder b=new StringBuilder();
  if(movies)b.append("Filmes");
  if(series){if(b.length()>0)b.append("  •  ");b.append("Séries");}
  if(live){if(b.length()>0)b.append("  •  ");b.append("TV ao vivo");}
  if(b.length()==0)b.append("Conteúdo disponível");
  return b.toString();
 }
 void providerChoiceCard(LinearLayout host,JSONObject o){
  String id=o.optString("id",o.optString("provider_id",""));if(id.isEmpty())return;String name=o.optString("name","Servidor");int movies=providerCount(o,"movies"),series=providerCount(o,"series"),live=providerCount(o,"live");rememberProviderCaps(id,name,movies,series,live);
  boolean active=id.equals(Api.PROVIDER==null?"":Api.PROVIDER);boolean hasMovies=movies>0||o.optInt("app_movie",0)==1||o.optInt("has_movies",0)==1;boolean hasSeries=series>0||o.optInt("app_series",0)==1||o.optInt("has_series",0)==1;boolean hasLive=live>0||o.optInt("app_live",0)==1||o.optInt("has_live",0)==1;
  LinearLayout card=new LinearLayout(this);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(12),dp(4),dp(10),dp(4));GradientDrawable bg=round(active?0xf021131a:0xf0171013,17);bg.setStroke(dp(1),active?0xffdb3588:0xff37252e);card.setBackground(bg);if(Build.VERSION.SDK_INT>=21)card.setElevation(dp(active?3:1));
  ImageView icon=new ImageView(this);icon.setImageResource(R.drawable.ic_server);icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);icon.setPadding(dp(9),dp(9),dp(9),dp(9));if(Build.VERSION.SDK_INT>=21)icon.setImageTintList(android.content.res.ColorStateList.valueOf(active?GREEN:0xffd06fa0));GradientDrawable ig=round(active?0xff3a1427:0xff221019,11);ig.setStroke(dp(1),active?0xffe7348d:0xff52283d);icon.setBackground(ig);LinearLayout.LayoutParams iLp=new LinearLayout.LayoutParams(dp(40),dp(40));iLp.setMargins(0,0,dp(11),0);card.addView(icon,iLp);
  LinearLayout mid=new LinearLayout(this);mid.setOrientation(LinearLayout.VERTICAL);mid.setGravity(Gravity.CENTER_VERTICAL);mid.setPadding(0,0,dp(6),0);mid.setMinimumHeight(dp(44));
  LinearLayout nameRow=new LinearLayout(this);nameRow.setGravity(Gravity.CENTER_VERTICAL);
  TextView n=t(name,15);n.setTypeface(null,1);n.setTextColor(Color.WHITE);n.setIncludeFontPadding(true);n.setGravity(Gravity.CENTER_VERTICAL);n.setMaxLines(1);n.setEllipsize(android.text.TextUtils.TruncateAt.END);nameRow.addView(n,new LinearLayout.LayoutParams(0,-2,1));
  if(active){TextView activeLabel=t("ATIVO",8);activeLabel.setTextColor(GREEN);activeLabel.setTypeface(null,1);activeLabel.setGravity(Gravity.CENTER);activeLabel.setIncludeFontPadding(true);activeLabel.setPadding(dp(7),0,dp(7),0);GradientDrawable ag=round(0xff26101b,9);ag.setStroke(dp(1),0xff6d2c4c);activeLabel.setBackground(ag);LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-2,dp(20));ap.setMargins(dp(7),0,0,0);nameRow.addView(activeLabel,ap);}
  mid.addView(nameRow,new LinearLayout.LayoutParams(-1,-2));

  TextView contentLine=t(providerContentLabel(hasMovies,hasSeries,hasLive),10);
  contentLine.setTextColor(0xffb5aab1);contentLine.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);contentLine.setIncludeFontPadding(true);contentLine.setSingleLine(true);contentLine.setEllipsize(android.text.TextUtils.TruncateAt.END);contentLine.setPadding(0,dp(1),0,dp(1));
  LinearLayout.LayoutParams clp=new LinearLayout.LayoutParams(-1,-2);clp.setMargins(0,0,0,0);mid.addView(contentLine,clp);
  card.addView(mid,new LinearLayout.LayoutParams(0,-2,1));

  TextView ar=t(active?"✓":"›",active?19:26);ar.setTextColor(active?GREEN:0xffbeb3ba);ar.setGravity(Gravity.CENTER);ar.setPadding(0,0,0,0);
  if(active){GradientDrawable ab=round(0xff26101b,15);ab.setStroke(dp(1),0xff6d2c4c);ar.setBackground(ab);}
  card.addView(ar,new LinearLayout.LayoutParams(dp(36),dp(40)));
  final int providerMovies=movies,providerSeries=series,providerLive=live;card.setFocusable(true);if(tvMode)armTvFocus(card);
  card.setOnClickListener(v->connectProviderReady(id,name,providerMovies,providerSeries,providerLive,card,ar));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(72));lp.setMargins(0,0,0,dp(6));host.addView(card,lp);
 }
 void connectProviderReady(String id,String name,int movieCount,int seriesCount,int liveCount,View card,TextView arrow){
  providerSwitchScreen=false;
  if(card!=null&&"loading".equals(String.valueOf(card.getTag())))return;
  if(card!=null){card.setTag("loading");card.setEnabled(false);}if(arrow!=null){arrow.setText("…");arrow.setTextColor(GREEN);}
  clearPreparedHome();Api.PROVIDER=id;rememberProviderCaps(id,name,movieCount,seriesCount,liveCount);sessionLiveKnown=liveCount>=0;sessionHasLive=liveCount>0;
  tvSelectedCategory="";liveSearch="";tvPendingCategoryHint="";tvAutoPlayPending=true;tvFocusedCategoryIndex=-1;tvActiveChannel=null;
  sp.edit().putString("provider_id",id).putString("provider_name",name).putInt("provider_movies_count",movieCount).putInt("provider_series_count",seriesCount).putInt("provider_live_count",liveCount).putBoolean("provider_has_live",sessionHasLive).apply();
  // v16.47: ao escolher o servidor, sai imediatamente da lista e abre a tela de
  // preparação visual. O catálogo continua vindo direto da Xtream e permanece só
  // em memória; a Home só abre depois que o conteúdo crítico estiver pronto.
  showProviderBootstrap(name,movieCount,seriesCount,liveCount);
 }
 void fetchPreparedHome(int movieCount,int seriesCount,PreparedHomeCB cb){
  final boolean wantMovies=movieCount!=0,wantSeries=seriesCount!=0;
  final JSONObject[] moviePart={null},seriesPart={null};final boolean[] movieDone={!wantMovies},seriesDone={!wantSeries};final String[] movieError={""},seriesError={""};
  Runnable finish=()->{if(!movieDone[0]||!seriesDone[0])return;JSONObject merged=mergeHomeParts(moviePart[0],seriesPart[0]);JSONArray a=merged.optJSONArray("result");if(a!=null&&a.length()>0){cb.ok(merged);return;}String error=!movieError[0].isEmpty()?movieError[0]:seriesError[0];cb.err(error.isEmpty()?"Esse servidor não retornou conteúdo agora.":"Não foi possível carregar o conteúdo desse servidor.");};
  if(wantMovies)fetchHomePart(1,1,new PreparedHomeCB(){public void ok(JSONObject j){moviePart[0]=j;movieDone[0]=true;finish.run();}public void err(String e){movieError[0]=e==null?"":e;movieDone[0]=true;finish.run();}});
  if(wantSeries)fetchHomePart(2,1,new PreparedHomeCB(){public void ok(JSONObject j){seriesPart[0]=j;seriesDone[0]=true;finish.run();}public void err(String e){seriesError[0]=e==null?"":e;seriesDone[0]=true;finish.run();}});
  finish.run();
 }


 // GREENPLAY APP TMDB DIRETO 5.28
 // v16.52: bootstrap curto direto da Xtream. O painel devolve somente as categorias
 // necessárias para a Home inicial já pronta. O catálogo completo não é percorrido
 // durante a troca de servidor; as demais categorias ficam para as telas Filmes/Séries.
 // 5.28.33: Home compacta: todas as categorias, somente os primeiros cards de cada uma.
 // Evita carregar milhares de filmes de dezenas de categorias simultaneamente na RAM.
 void fetchProviderSnapshot(int movieCount,int seriesCount,PreparedHomeCB cb){
  // 5.28.31: a entrada no app so acontece depois que TODAS as categorias da fonte
  // tiveram a primeira pagina consultada. Sem fallback de 2/6 categorias e sem
  // linhas aparecendo depois que a Home ja abriu.
  fetchPreparedHome(-1,-1,new PreparedHomeCB(){public void ok(JSONObject j){
   try{j.put("movie_first_pages_complete",1);j.put("series_first_pages_complete",1);j.put("shorts_checked",1);j.put("catalog_mode","atomic_all_categories");}catch(Exception ignored){}cb.ok(j);
  }public void err(String e){JSONObject empty=new JSONObject();try{empty.put("status",200);empty.put("result",new JSONArray());empty.put("movie_first_pages_complete",1);empty.put("series_first_pages_complete",1);empty.put("shorts_checked",1);empty.put("catalog_mode","atomic_live_only");}catch(Exception ignored){}cb.ok(empty);}});
 }
 void fetchProviderSnapshotAttempt(int movieCount,int seriesCount,int retries,PreparedHomeCB cb){
  // v16.53: UM snapshot completo. Nada de fallback curto ou waterfall por categoria.
  final boolean wantMovies=movieCount!=0,wantSeries=seriesCount!=0,wantLive=planLiveAllowed;
  Api.post("bootstrap_home/index.php",Api.m("user_id",uid,"want_movie",wantMovies?"1":"0","want_series",wantSeries?"1":"0","want_live",wantLive?"1":"0","full_catalog","0"),new Api.CB(){public void ok(JSONObject j){
   JSONArray a=j.optJSONArray("result");JSONArray live=j.optJSONArray("live_channels");
   boolean hasMain=a!=null&&a.length()>0;boolean hasLive=live!=null&&live.length()>0;
   if(j.optInt("status",200)==200&&(hasMain||hasLive)){cb.ok(j);return;}
   if(retries>0){new Handler(Looper.getMainLooper()).postDelayed(()->fetchProviderSnapshotAttempt(movieCount,seriesCount,retries-1,cb),450);return;}fetchProviderSnapshotFallback(movieCount,seriesCount,cb);
  }public void err(String e){if(retries>0){new Handler(Looper.getMainLooper()).postDelayed(()->fetchProviderSnapshotAttempt(movieCount,seriesCount,retries-1,cb),450);return;}fetchProviderSnapshotFallback(movieCount,seriesCount,cb);}});
 }
 void fetchProviderSnapshotFallback(int movieCount,int seriesCount,PreparedHomeCB cb){
  final boolean wantMovies=movieCount!=0,wantSeries=seriesCount!=0;final JSONObject[] moviePart={null},seriesPart={null};final boolean[] md={!wantMovies},sd={!wantSeries};final boolean[] delivered={false};
  Runnable finish=()->{if(delivered[0]||!md[0]||!sd[0])return;delivered[0]=true;JSONObject merged=mergeHomeParts(moviePart[0],seriesPart[0]);try{merged.put("catalog_complete",0);merged.put("catalog_mode","bootstrap_fallback");}catch(Exception ignored){}JSONArray a=merged.optJSONArray("result");if(a!=null&&a.length()>0)cb.ok(merged);else cb.err("A fonte Xtream não retornou conteúdo agora.");};
  if(wantMovies)fetchBootstrapHomePart(1,new PreparedHomeCB(){public void ok(JSONObject j){moviePart[0]=j;md[0]=true;finish.run();}public void err(String e){md[0]=true;finish.run();}});
  if(wantSeries)fetchBootstrapHomePart(2,new PreparedHomeCB(){public void ok(JSONObject j){seriesPart[0]=j;sd[0]=true;finish.run();}public void err(String e){sd[0]=true;finish.run();}});
  finish.run();
 }

 // v16.48: bootstrap rápido. Para abrir a Home não esperamos TODAS as categorias
 // do servidor. Buscamos apenas as primeiras categorias úteis de Filmes/Séries, em
 // paralelo, e o restante continua sendo acrescentado silenciosamente depois da Home.
 // O catálogo segue direto da fonte e não é gravado de forma persistente.
 void fetchBootstrapHomePart(int typeId,PreparedHomeCB cb){
  final String type=typeId==2?"series":"movie";
  Api.post("get_category",Api.m("type",type,"user_id",uid),new Api.CB(){public void ok(JSONObject j){
   if(j.optInt("status",200)!=200){cb.err(j.optString("message","Não foi possível carregar as categorias."));return;}
   JSONArray cats=j.optJSONArray("result");if(cats==null){cb.err("Resposta de categorias inválida.");return;}
   if(cats.length()==0){cb.ok(homePartFromSections(new JSONArray(),"bootstrap_quick"));return;}
   fetchBootstrapCategories(typeId,cats,cb);
  }public void err(String e){cb.err(e==null?"Falha ao carregar categorias.":e);}});
 }
 void fetchBootstrapCategories(int typeId,JSONArray cats,PreparedHomeCB cb){
  final int inspect=Math.min(cats.length(),6),target=Math.min(2,inspect);
  final JSONObject[] built=new JSONObject[inspect];final int[] next={0},active={0},finished={0},okCount={0};final boolean[] delivered={false};
  final Handler h=new Handler(Looper.getMainLooper());final Runnable[] pump=new Runnable[1];
  final Runnable deliver=()->{
   if(delivered[0])return;delivered[0]=true;
   JSONArray sections=new JSONArray();for(JSONObject sec:built)if(sec!=null)sections.put(sec);
   if(sections.length()>0)cb.ok(homePartFromSections(sections,"bootstrap_quick"));else cb.err("A fonte não respondeu a tempo.");
  };
  final Runnable softTimeout=()->{if(!delivered[0])deliver.run();};h.postDelayed(softTimeout,5500);
  pump[0]=()->{
   if(delivered[0])return;
   while(active[0]<4&&next[0]<inspect){final int index=next[0]++;final JSONObject cat=cats.optJSONObject(index);if(cat==null){finished[0]++;continue;}active[0]++;
    fetchCategoryHomeSection(typeId,cat,2,new PreparedHomeCB(){public void ok(JSONObject part){
     if(delivered[0])return;active[0]--;finished[0]++;JSONArray a=part==null?null:part.optJSONArray("result");if(a!=null&&a.length()>0){built[index]=a.optJSONObject(0);okCount[0]++;}
     if(okCount[0]>=target){h.removeCallbacks(softTimeout);deliver.run();return;}pump[0].run();
    }public void err(String e){if(delivered[0])return;active[0]--;finished[0]++;pump[0].run();}});
   }
   if(finished[0]>=inspect&&active[0]==0&&!delivered[0]){h.removeCallbacks(softTimeout);deliver.run();}
  };
  pump[0].run();
 }
 // v16.46: a preparação da Home não depende mais do section_list pesado. Primeiro
 // busca a lista de categorias e carrega a primeira página de cada categoria direto
 // da fonte. Assim provedores com get_vod_streams/get_series gigantes não travam a
 // seleção do servidor. O section_list tipado fica apenas como fallback de emergência.
 void fetchHomePart(int typeId,int retries,PreparedHomeCB cb){
  fetchHomePartByCategories(typeId,new PreparedHomeCB(){public void ok(JSONObject j){cb.ok(j);}public void err(String directError){
   Api.post("section_list",Api.m("user_id",uid,"type_id",String.valueOf(typeId)),new Api.CB(){public void ok(JSONObject j){JSONArray a=j.optJSONArray("result");if(j.optInt("status",200)==200&&a!=null){cb.ok(j);return;}retryHomePart(typeId,retries-1,cb,j.optString("message",directError));}public void err(String e){retryHomePart(typeId,retries-1,cb,(e==null||e.isEmpty())?directError:e);}});
  }});
 }
 void fetchHomePartByCategories(int typeId,PreparedHomeCB cb){
  final String type=typeId==2?"series":"movie";
  Api.post("get_category",Api.m("type",type,"user_id",uid),new Api.CB(){public void ok(JSONObject j){
   if(j.optInt("status",200)!=200){cb.err(j.optString("message","Não foi possível carregar as categorias."));return;}
   JSONArray cats=j.optJSONArray("result");if(cats==null){cb.err("Resposta de categorias inválida.");return;}
   if(cats.length()==0){cb.ok(homePartFromSections(new JSONArray(),"direct_categories"));return;}
   fetchHomeCategoriesBatch(typeId,cats,cb);
  }public void err(String e){cb.err(e==null?"Falha ao carregar categorias.":e);}});
 }
 void fetchHomeCategoriesBatch(int typeId,JSONArray cats,PreparedHomeCB cb){
  final int total=cats.length();final JSONObject[] built=new JSONObject[total];
  for(int i=0;i<total;i++){JSONObject cat=cats.optJSONObject(i);if(cat==null)continue;String cid=cat.optString("category_id",cat.optString("id",""));String title=fixTitle(cat.optString("category_name",cat.optString("name",typeId==2?"Séries":"Filmes")));JSONObject sec=new JSONObject();try{sec.put("title",title);sec.put("category_id",cid);sec.put("type_id",typeId);sec.put("video_type",typeId);sec.put("screen_layout","portrait");sec.put("data",new JSONArray());sec.put("category_complete",0);}catch(Exception ignored){}built[i]=sec;}
  final int[] next={0},active={0},finished={0};final boolean[] delivered={false};final Runnable[] pump=new Runnable[1];
  pump[0]=()->{
   if(delivered[0])return;
   while(active[0]<6&&next[0]<total){final int index=next[0]++;final JSONObject cat=cats.optJSONObject(index);if(cat==null){finished[0]++;continue;}active[0]++;
    fetchCategoryHomeSection(typeId,cat,2,new PreparedHomeCB(){public void ok(JSONObject part){active[0]--;finished[0]++;JSONArray a=part==null?null:part.optJSONArray("result");if(a!=null&&a.length()>0){JSONObject sec=a.optJSONObject(0);if(sec!=null)built[index]=sec;}pump[0].run();}public void err(String e){active[0]--;finished[0]++;pump[0].run();}});
   }
   if(finished[0]>=total&&active[0]==0&&!delivered[0]){delivered[0]=true;JSONArray sections=new JSONArray();for(JSONObject sec:built)if(sec!=null)sections.put(sec);JSONObject out=homePartFromSections(sections,"direct_categories_atomic");try{out.put(typeId==1?"movie_first_pages_complete":"series_first_pages_complete",1);}catch(Exception ignored){}cb.ok(out);}
  };
  pump[0].run();
 }
 void fetchCategoryHomeSection(int typeId,JSONObject cat,int retries,PreparedHomeCB cb){
  final String cid=cat.optString("category_id",cat.optString("id","")).trim();if(cid.isEmpty()){cb.ok(homePartFromSections(new JSONArray(),"direct_category"));return;}
  final String contentType=typeId==2?"series":"movie";final String title=fixTitle(cat.optString("category_name",cat.optString("name",typeId==2?"Séries":"Filmes")));
  Api.post("content_by_category",Api.m("user_id",uid,"type",contentType,"category_id",cid,"page_no","1","page","1","offset","0","limit","12","per_page","12","page_size","12","full_catalog","0"),new Api.CB(){public void ok(JSONObject j){
   if(j.optInt("status",200)!=200){retryCategoryHomeSection(typeId,cat,retries,cb,j.optString("message","Resposta inválida"));return;}
   JSONArray data=j.optJSONArray("result");if(data==null){retryCategoryHomeSection(typeId,cat,retries,cb,"Resposta sem conteúdo");return;}
   JSONArray sections=new JSONArray();JSONObject sec=new JSONObject();try{sec.put("title",title);sec.put("category_id",cid);sec.put("type_id",typeId);sec.put("video_type",typeId);sec.put("screen_layout","portrait");sec.put("data",data);int total=categoryResponseTotal(j);if(total>0)sec.put("category_total",total);if(total>0&&data.length()>=total)sec.put("category_complete",1);sections.put(sec);}catch(Exception ignored){}
   cb.ok(homePartFromSections(sections,"direct_category"));
  }public void err(String e){retryCategoryHomeSection(typeId,cat,retries,cb,e);}});
 }
 void retryCategoryHomeSection(int typeId,JSONObject cat,int retries,PreparedHomeCB cb,String error){if(retries<=0){cb.err(error);return;}new Handler(Looper.getMainLooper()).postDelayed(()->fetchCategoryHomeSection(typeId,cat,retries-1,cb),350);}
 JSONObject homePartFromSections(JSONArray sections,String mode){JSONObject out=new JSONObject();try{out.put("status",200);out.put("message","Success");out.put("result",sections==null?new JSONArray():sections);out.put("total_rows",sections==null?0:sections.length());out.put("catalog_mode",mode);}catch(Exception ignored){}return out;}
 void retryHomePart(int typeId,int retries,PreparedHomeCB cb,String error){if(retries<=0){cb.err(error);return;}new Handler(Looper.getMainLooper()).postDelayed(()->fetchHomePart(typeId,retries-1,cb),650);}
 JSONObject mergeHomeParts(JSONObject movies,JSONObject series){
  JSONObject out=new JSONObject();JSONArray result=new JSONArray();java.util.HashSet<String> seen=new java.util.HashSet<>();
  try{JSONObject[] parts={movies,series};for(JSONObject part:parts){if(part==null)continue;JSONArray a=part.optJSONArray("result");if(a==null)continue;for(int i=0;i<a.length();i++){JSONObject sec=a.optJSONObject(i);if(sec==null)continue;String key=sec.optInt("type_id",sec.optInt("video_type",0))+"|"+sec.optString("section_key","")+"|"+sec.optString("category_id","")+"|"+sec.optString("title","");if(seen.add(key))result.put(sec);}}out.put("status",200);out.put("message","Success");out.put("result",result);out.put("total_rows",result.length());out.put("catalog_mode","direct_source_split_atomic");out.put("movie_first_pages_complete",1);out.put("series_first_pages_complete",1);out.put("shorts_checked",1);}catch(Exception ignored){}return out;
 }
 class BootstrapRow{
  LinearLayout view;TextView icon,label,check;ProgressBar spinner;
 }
 void setBootstrapProgress(ProgressBar bar,TextView percent,TextView status,TextView detail,int value,String main,String sub){
  if(bar!=null){bar.setIndeterminate(false);bar.setMax(100);bar.setProgress(Math.max(0,Math.min(100,value)));}
  if(percent!=null)percent.setText(Math.max(0,Math.min(100,value))+"%");
  if(status!=null)status.setText(main==null?"":main);
  if(detail!=null)detail.setText(sub==null?"":sub);
 }
 void finishProviderBootstrapWithLive(LinearLayout c,ProgressBar progress,TextView percent,TextView status,TextView detail,String name,int movieCount,int seriesCount,int liveCount,JSONObject snapshot,boolean hasLive,boolean liveKnown,JSONArray liveSample){
  sessionHasLive=hasLive;sessionLiveKnown=liveKnown;
  // v16.216: o painel v84 já devolve os canais enriquecidos com logo atual e EPG.
  // Mantemos a lista em memória para a tela de TV abrir pronta, sem refazer a carga.
  JSONArray data=snapshot.optJSONArray("result");if((data==null||data.length()==0)&&!sessionHasLive){showBootstrapFailure(c,progress,percent,status,detail,name,movieCount,seriesCount,liveCount);return;}
  try{snapshot.put("catalog_complete",0);snapshot.put("movie_first_pages_complete",1);snapshot.put("series_first_pages_complete",1);snapshot.put("shorts_checked",1);}catch(Exception ignored){}
  try{JSONArray cleanLive=sanitizeLiveChannels(snapshot.optJSONArray("live_channels"));snapshot.put("live_channels",cleanLive);snapshot.put("live_count",cleanLive.length());}catch(Exception ignored){}saveHomeCache(snapshot);persistHomeCacheAsync(snapshot);int knownLive=Math.max(liveCount,liveSample==null?0:sanitizeLiveChannels(liveSample).length());android.content.SharedPreferences.Editor liveEd=sp.edit().putBoolean(homeExtrasKey(),true).putBoolean("provider_has_live",sessionHasLive);if(liveKnown)liveEd.putInt("provider_live_count",sessionHasLive?Math.max(1,knownLive):0);liveEd.apply();homeExtrasStarted=true;
  setBootstrapProgress(progress,percent,status,detail,100,"Tudo pronto","Abrindo sua experiência…");
  modeReloadScreen=false;new Handler(Looper.getMainLooper()).postDelayed(()->shell(),700);
 }
 void showProviderBootstrap(String name){
  int movies=sp.getInt("provider_movies_count",-1),series=sp.getInt("provider_series_count",-1),live=sp.getInt("provider_live_count",sp.getBoolean("provider_has_live",false)?1:0);
  showProviderBootstrap(name,movies,series,live);
 }
 void showProviderBootstrap(String name,int movieCount,int seriesCount,int liveCount){
  clearPreparedHome();authScreen=false;sessionLiveKnown=liveCount>=0;sessionHasLive=liveCount>0;base(true);root.setPadding(dp(22),dp(10),dp(22),dp(18));
  LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setGravity(Gravity.CENTER_HORIZONTAL);root.addView(c,new LinearLayout.LayoutParams(-1,-1));
  Space topFlex=new Space(this);c.addView(topFlex,new LinearLayout.LayoutParams(1,0,1));
  ImageView logo=new ImageView(this);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);applyAppLogo(logo);LinearLayout.LayoutParams llp=new LinearLayout.LayoutParams(-1,dp(tvMode?66:84));llp.setMargins(dp(54),0,dp(54),dp(tvMode?8:14));c.addView(logo,llp);
  TextView title=t("Preparando sua experiência",tvMode?22:24);title.setTypeface(null,1);title.setGravity(Gravity.CENTER);title.setPadding(0,0,0,0);title.setIncludeFontPadding(true);c.addView(title,new LinearLayout.LayoutParams(-1,dp(tvMode?38:42)));
  TextView sub=t("Conteúdo, canais, capas e programação em um só lugar",tvMode?12:13);sub.setTextColor(0xffb8adb4);sub.setGravity(Gravity.CENTER);sub.setPadding(dp(12),0,dp(12),0);sub.setMaxLines(2);LinearLayout.LayoutParams subLp=new LinearLayout.LayoutParams(-1,-2);subLp.setMargins(0,0,0,dp(tvMode?8:18));c.addView(sub,subLp);

  // v16.216: loading cinematográfico, sem card/quadrado no centro da tela.
  LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);panel.setGravity(Gravity.CENTER_HORIZONTAL);panel.setPadding(dp(8),dp(4),dp(8),dp(4));LinearLayout.LayoutParams panelLp=new LinearLayout.LayoutParams(-1,-2);panelLp.setMargins(dp(14),0,dp(14),dp(18));c.addView(panel,panelLp);
  TextView eyebrow=t("SINCRONIZANDO CONTEÚDO",tvMode?11:10);eyebrow.setTextColor(0xffe37fb1);eyebrow.setTypeface(null,1);eyebrow.setLetterSpacing(.12f);eyebrow.setGravity(Gravity.CENTER);eyebrow.setIncludeFontPadding(false);LinearLayout.LayoutParams eyeLp=new LinearLayout.LayoutParams(-1,dp(tvMode?30:28));eyeLp.setMargins(0,dp(2),0,dp(2));panel.addView(eyebrow,eyeLp);
  TextView percent=t("8%",tvMode?30:30);percent.setTextColor(GREEN);percent.setTypeface(null,1);percent.setGravity(Gravity.CENTER);percent.setIncludeFontPadding(false);LinearLayout.LayoutParams pctLp=new LinearLayout.LayoutParams(-1,dp(tvMode?48:56));pctLp.setMargins(0,dp(3),0,0);panel.addView(percent,pctLp);
  TextView status=t("Conectando ao servidor",tvMode?18:18);status.setTypeface(null,1);status.setGravity(Gravity.CENTER);status.setTextColor(Color.WHITE);status.setMaxLines(2);status.setIncludeFontPadding(true);panel.addView(status,new LinearLayout.LayoutParams(-1,-2));
  TextView detail=t("Preparando catálogo e serviços…",tvMode?13:12);detail.setTextColor(0xffb0a5ac);detail.setGravity(Gravity.CENTER);detail.setMaxLines(3);detail.setEllipsize(android.text.TextUtils.TruncateAt.END);detail.setLineSpacing(0,1.08f);detail.setPadding(dp(18),dp(2),dp(18),dp(2));LinearLayout.LayoutParams detailLp=new LinearLayout.LayoutParams(-1,-2);detailLp.setMargins(0,0,0,dp(2));panel.addView(detail,detailLp);
  ProgressBar progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setIndeterminate(false);progress.setMax(100);progress.setProgress(8);try{progress.getProgressDrawable().setColorFilter(GREEN,android.graphics.PorterDuff.Mode.SRC_IN);}catch(Exception ignored){}LinearLayout.LayoutParams prLp=new LinearLayout.LayoutParams(-1,dp(5));prLp.setMargins(dp(28),dp(12),dp(28),dp(8));panel.addView(progress,prLp);
  TextView footer=t("FILMES  •  SÉRIES  •  CANAIS  •  CAPAS  •  LOGOS  •  EPG",tvMode?8:9);footer.setTextColor(0xff766f74);footer.setGravity(Gravity.CENTER);footer.setLetterSpacing(.04f);footer.setIncludeFontPadding(true);footer.setMaxLines(2);panel.addView(footer,new LinearLayout.LayoutParams(-1,-2));
  Space bottomFlex=new Space(this);c.addView(bottomFlex,new LinearLayout.LayoutParams(1,0,1));

  final boolean[] snapshotReady={false};setBootstrapProgress(progress,percent,status,detail,10,"Conectando ao servidor","Validando acesso e preparando a Home…");
  fetchProviderSnapshot(movieCount,seriesCount,new PreparedHomeCB(){public void ok(JSONObject snapshot){
   if(snapshotReady[0])return;snapshotReady[0]=true;
   int mc=snapshot.optInt("movie_count",Math.max(0,movieCount)),sc=snapshot.optInt("series_count",Math.max(0,seriesCount));
   setBootstrapProgress(progress,percent,status,detail,32,"Filmes e séries sincronizados",formatBootstrapCount(mc)+" filmes  •  "+formatBootstrapCount(sc)+" séries preparados…");
   setBootstrapProgress(progress,percent,status,detail,44,"Preparando capas","Carregando as imagens que aparecem primeiro na Home…");
   final boolean[] catalogDone={false};Runnable catalogReady=()->{if(catalogDone[0])return;catalogDone[0]=true;
    setBootstrapProgress(progress,percent,status,detail,58,"Conferindo canais","Validando a lista completa para não deixar nenhum canal de fora…");
    reconcileBootstrapLiveChannels(snapshot,()->{
     JSONArray liveSnapshot=snapshot.optJSONArray("live_channels");boolean hasLive=liveSnapshot!=null&&liveSnapshot.length()>0;
     if(!hasLive){
      setBootstrapProgress(progress,percent,status,detail,96,"Finalizando","Catálogo, capas e detalhes iniciais preparados…");
      finishProviderBootstrapWithLive(c,progress,percent,status,detail,name,movieCount,seriesCount,liveCount,snapshot,false,true,null);return;
     }
     sessionHasLive=true;sessionLiveKnown=true;
     setBootstrapProgress(progress,percent,status,detail,62,"Canais sincronizados",formatBootstrapCount(liveSnapshot.length())+" canais conferidos e organizados…");
     prepareBootstrapLiveAssets(liveSnapshot,progress,percent,status,detail,()->finishProviderBootstrapWithLive(c,progress,percent,status,detail,name,movieCount,seriesCount,Math.max(liveCount,liveSnapshot.length()),snapshot,true,true,liveSnapshot));
    });
   };
   // 5.28.1: a tela de carregamento já existente prepara o TMDB dos cards
   // visíveis ANTES de abrir a Home. Arte da fonte nunca é usada como fallback.
   stripUnverifiedCatalogArt(snapshot);
   // 5.28.11: primeiro resolve os cards visiveis que ainda vieram sem arte via
   // content_detail (TMDB-only); depois baixa as imagens e so entao abre a Home.
   prepareCriticalDetails(snapshot,()->{
    setBootstrapProgress(progress,percent,status,detail,50,"Capas TMDB preparadas","Baixando as imagens visíveis antes de abrir a Home…");
    warmHomeImages(snapshot,catalogReady);
   });
  }public void err(String e){if(snapshotReady[0])return;snapshotReady[0]=true;showBootstrapFailure(c,progress,percent,status,detail,name,movieCount,seriesCount,liveCount);}});
 }
 void reconcileBootstrapLiveChannels(JSONObject snapshot,Runnable done){
  if(snapshot==null||!planLiveAllowed){done.run();return;}
  JSONArray already=snapshot.optJSONArray("live_channels");int declared=snapshot.optInt("live_count",already==null?0:already.length());
  // 5.28.26: nunca segura a abertura da Home e nunca aceita VOD/Shorts dentro da TV.
  // A TV completa a lista ao ser aberta; se o bootstrap ja trouxe uma amostra, entra agora.
  if(already!=null&&already.length()>0){done.run();return;}
  boolean liveComplete=snapshot.optInt("live_complete",0)==1||snapshot.optInt("catalog_complete",0)==1;
  if(liveComplete&&(declared==0)){done.run();return;}
  final String providerAtRequest=Api.PROVIDER==null?"":Api.PROVIDER;
  fetchAllLiveChannelPages("","",false,0,new JSONArray(),new java.util.HashSet<String>(),new AllPagesCB(){public void ok(JSONArray full){
   if(!providerAtRequest.equals(Api.PROVIDER==null?"":Api.PROVIDER)){done.run();return;}
   try{
    JSONArray base=snapshot.optJSONArray("live_channels");if(base==null)base=new JSONArray();
    java.util.LinkedHashMap<String,JSONObject> merged=new java.util.LinkedHashMap<>();
    for(int i=0;i<base.length();i++){JSONObject x=base.optJSONObject(i);if(!isRealLiveChannel(x))continue;String k=tvChannelKey(x);if(k.isEmpty())k="base|"+i+"|"+tvChannelName(x);merged.put(k,x);}
    if(full!=null)for(int i=0;i<full.length();i++){JSONObject x=full.optJSONObject(i);if(!isRealLiveChannel(x))continue;String k=tvChannelKey(x);if(k.isEmpty())k="full|"+i+"|"+tvChannelName(x);JSONObject old=merged.get(k);if(old==null)merged.put(k,x);else mergeLiveChannelFields(old,x);}
    JSONArray all=new JSONArray();for(JSONObject x:merged.values())all.put(x);snapshot.put("live_channels",all);snapshot.put("live_count",all.length());
   }catch(Exception ignored){}
   done.run();
  }public void err(String e){done.run();}});
 }
 void mergeLiveChannelFields(JSONObject dst,JSONObject src){
  if(dst==null||src==null)return;
  // Logos canônicas mais novas substituem cache antigo. Campos crus do provedor
  // continuam apenas preenchendo lacunas, para não trazer de volta logo errada.
  String[] canonical={"greenplay_logo","epg_logo","tvg_logo","tvg-logo","logo_url","channel_logo","logo_alt","fallback_logo"};for(String k:canonical){String b=src.optString(k,"").trim();if(!b.isEmpty())try{dst.put(k,src.opt(k));}catch(Exception ignored){}}
  String[] keys={"provider_icon","stream_icon","source_logo","thumbnail","image","landscape","portrait_img","landscape_img","logo","icon","channel_icon","channel_logo","logo_url","tvg_logo","tvg-logo","cover","poster","epg_channel_id","epg_id","tvg_id","tvg-id","tvg_name","tvg-name","channel_number","num","category_name","video_320","video_480","video_720","video_1080","video_extension"};
  for(String k:keys){String a=dst.optString(k,"").trim(),b=src.optString(k,"").trim();if(a.isEmpty()&&!b.isEmpty())try{dst.put(k,src.opt(k));}catch(Exception ignored){}}
  String[] ep=tvExtractEpg(src);if(!ep[0].isEmpty()||!ep[1].isEmpty())tvCacheEpg(dst,ep);
 }
 String formatBootstrapCount(int n){try{return java.text.NumberFormat.getIntegerInstance(new java.util.Locale("pt","BR")).format(Math.max(0,n));}catch(Exception e){return String.valueOf(Math.max(0,n));}}
 void prepareBootstrapLiveAssets(JSONArray sample,ProgressBar progress,TextView percent,TextView status,TextView detail,Runnable done){
  if(sample==null||sample.length()==0){setBootstrapProgress(progress,percent,status,detail,98,"Finalizando","Dados essenciais preparados…");done.run();return;}
  // v5.26: o painel é a fonte da verdade para logos. A abertura do app não baixa
  // centenas de imagens uma a uma. Só aquece um pequeno grupo visível e possui
  // timeout rígido; o restante continua carregando do painel sem bloquear a Home.
  java.util.ArrayList<java.util.List<String>> critical=new java.util.ArrayList<>();int epgReady=0,logoReady=0,localReady=0;
  for(int i=0;i<sample.length();i++){
   JSONObject ch=sample.optJSONObject(i);if(ch==null)continue;String[] ep=tvExtractEpg(ch);if(!ep[0].isEmpty()||!ep[1].isEmpty()){epgReady++;tvCacheEpg(ch,ep);}
   String[] lc=tvChannelLogoCandidates(ch);if(lc.length==0)continue;logoReady++;
   String chosen="";for(String u:lc){if(u==null)continue;String x=u.trim();if(x.isEmpty())continue;if(x.contains("/storage/channel_logos/")){chosen=x;localReady++;break;}}
   if(chosen.isEmpty()&&lc.length>0&&lc[0]!=null)chosen=lc[0].trim();
   if(!chosen.isEmpty()&&critical.size()<24){java.util.ArrayList<String> one=new java.util.ArrayList<>();one.add(chosen);critical.add(one);}
  }
  final int total=sample.length(),withLogo=logoReady,fromPanel=localReady;
  setBootstrapProgress(progress,percent,status,detail,76,"Logos indexadas",formatBootstrapCount(withLogo)+" de "+formatBootstrapCount(total)+" canais com logo; preparando a tela inicial…");
  if(critical.isEmpty()){setBootstrapProgress(progress,percent,status,detail,97,"Tudo sincronizado",formatBootstrapCount(total)+" canais preparados…");done.run();return;}
  final java.util.concurrent.atomic.AtomicBoolean fired=new java.util.concurrent.atomic.AtomicBoolean(false);final Handler h=new Handler(Looper.getMainLooper());
  final Runnable finish=()->{if(!fired.compareAndSet(false,true))return;setBootstrapProgress(progress,percent,status,detail,97,"Tudo sincronizado",formatBootstrapCount(total)+" canais prontos; "+formatBootstrapCount(fromPanel)+" logos já estão no painel.");done.run();};
  h.postDelayed(finish,2200);
  Img.prefetchLogoGroups(this,critical,(finished,all)->{if(fired.get())return;int pct=76+(int)Math.round(18.0*finished/Math.max(1,all));setBootstrapProgress(progress,percent,status,detail,Math.min(94,pct),"Preparando logos",finished+" de "+all+" logos iniciais prontas…");},()->{h.removeCallbacks(finish);finish.run();});
 }


 void prefetchBootstrapEpg(JSONArray sample,int limit,Runnable done){
  if(sample==null||sample.length()==0||limit<=0){done.run();return;}java.util.ArrayList<JSONObject> chans=new java.util.ArrayList<>();for(int i=0;i<sample.length()&&chans.size()<limit;i++){JSONObject ch=sample.optJSONObject(i);if(ch!=null&&!tvChannelKey(ch).isEmpty())chans.add(ch);}if(chans.isEmpty()){done.run();return;}
  final java.util.concurrent.atomic.AtomicInteger remain=new java.util.concurrent.atomic.AtomicInteger(chans.size());final java.util.concurrent.atomic.AtomicBoolean fired=new java.util.concurrent.atomic.AtomicBoolean(false);Handler h=new Handler(Looper.getMainLooper());Runnable finish=()->{if(fired.compareAndSet(false,true))done.run();};h.postDelayed(finish,1800);
  for(JSONObject ch:chans){Api.post("get_short_epg",tvEpgArgs(ch,2),new Api.CB(){public void ok(JSONObject j){if(!fired.get()){try{JSONObject payload=tvSelectEpgPayload(j,ch);String[] e=payload==null?new String[]{"",""}:tvExtractEpg(payload);if(!e[0].isEmpty()||!e[1].isEmpty())tvCacheEpg(ch,e);}catch(Exception ignored){}if(remain.decrementAndGet()<=0){h.removeCallbacks(finish);finish.run();}}}public void err(String e){if(!fired.get()&&remain.decrementAndGet()<=0){h.removeCallbacks(finish);finish.run();}}});}
 }
 void showBootstrapFailure(LinearLayout c,ProgressBar progress,TextView percent,TextView status,TextView detail,String name,int movieCount,int seriesCount,int liveCount){
  setBootstrapProgress(progress,percent,status,detail,100,"Não foi possível preparar o conteúdo","Confira sua conexão ou tente o servidor novamente.");if(percent!=null){percent.setText("!");percent.setTextColor(0xffff747d);}if(progress!=null)try{progress.getProgressDrawable().setColorFilter(0xffff5d68,android.graphics.PorterDuff.Mode.SRC_IN);}catch(Exception ignored){}
  Button retry=authSecondary("Tentar novamente");LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(52));rp.setMargins(0,dp(8),0,dp(6));c.addView(retry,Math.max(0,c.getChildCount()-1),rp);retry.setOnClickListener(v->showProviderBootstrap(name,movieCount,seriesCount,liveCount));
  TextView change=t("Escolher outro servidor",14);change.setTextColor(GREEN);change.setGravity(Gravity.CENTER);c.addView(change,Math.max(0,c.getChildCount()-1),new LinearLayout.LayoutParams(-1,dp(44)));change.setOnClickListener(v->providerSelectAfterLogin());
 }
 BootstrapRow bootstrapRow(String iconText,String labelText){
  BootstrapRow r=new BootstrapRow();r.view=new LinearLayout(this);r.view.setGravity(Gravity.CENTER_VERTICAL);r.view.setPadding(dp(12),dp(6),dp(10),dp(6));GradientDrawable bg=round(0xd61c1619,13);bg.setStroke(dp(1),0xff352a30);r.view.setBackground(bg);LinearLayout.LayoutParams vp=new LinearLayout.LayoutParams(-1,dp(60));vp.setMargins(0,0,0,dp(9));r.view.setLayoutParams(vp);
  r.icon=t(iconText,17);r.icon.setTextColor(0xff938a90);r.icon.setGravity(Gravity.CENTER);r.icon.setPadding(0,0,0,0);r.icon.setBackground(round(0xff282024,10));r.view.addView(r.icon,new LinearLayout.LayoutParams(dp(40),dp(40)));
  r.label=t(labelText,14);r.label.setTypeface(null,1);r.label.setTextColor(0xffccc0c8);r.label.setGravity(Gravity.CENTER_VERTICAL);r.label.setPadding(dp(12),0,dp(8),0);r.view.addView(r.label,new LinearLayout.LayoutParams(0,-1,1));
  FrameLayout end=new FrameLayout(this);r.spinner=new ProgressBar(this);r.spinner.setIndeterminate(true);try{r.spinner.getIndeterminateDrawable().setColorFilter(GREEN,android.graphics.PorterDuff.Mode.SRC_IN);}catch(Exception ignored){}FrameLayout.LayoutParams pp=new FrameLayout.LayoutParams(dp(28),dp(28),Gravity.CENTER);end.addView(r.spinner,pp);r.check=t("",18);r.check.setGravity(Gravity.CENTER);r.check.setPadding(0,0,0,0);end.addView(r.check,new FrameLayout.LayoutParams(-1,-1));r.view.addView(end,new LinearLayout.LayoutParams(dp(42),dp(42)));return r;
 }
 void setBootstrapRow(BootstrapRow r,int state){
  if(r==null)return;boolean active=state==1,ok=state==2,err=state==3;r.spinner.setVisibility(active?View.VISIBLE:View.GONE);r.check.setVisibility(active?View.GONE:View.VISIBLE);r.check.setText(ok?"✓":err?"!":"○");r.check.setTextColor(ok?GREEN:err?0xffff626d:0xff827a7f);r.label.setTextColor(ok?0xfff4e5ef:err?0xffff8b92:active?Color.WHITE:0xffb7acb3);r.icon.setTextColor(ok||active?GREEN:err?0xffff626d:0xff938a90);r.icon.setBackground(round(ok?0xff351424:active?0xff321624:err?0xff3a1c20:0xff282024,10));GradientDrawable g=round(0xd61c1619,13);g.setStroke(dp(1),ok?0xff6b2b4b:err?0xff743039:active?GREEN:0xff352a30);r.view.setBackground(g);
 }
 String homeCacheKey(){return "home_sections_"+uid+"_"+(Api.PROVIDER==null?"":Api.PROVIDER);}
 String homeExtrasKey(){return "home_extras_52870_"+uid+"_"+(Api.PROVIDER==null?"":Api.PROVIDER);}
 // v16.237: o catálogo continua compartilhado em memória durante a sessão, mas agora
 // também possui snapshot persistente comprimido por usuário+servidor. Assim fechar e
 // abrir o app não obriga uma sincronização completa. A sincronização bloqueante só
 // volta quando o snapshot passa 72h sem uso ou quando o servidor/conta muda.
 void saveHomeCache(JSONObject j){if(j==null)return;stripUnverifiedCatalogArt(j);preparedHomeProvider=Api.PROVIDER==null?"":Api.PROVIDER;preparedHomeData=j;}
 JSONObject readHomeCache(){String p=Api.PROVIDER==null?"":Api.PROVIDER;if(preparedHomeData==null||!p.equals(preparedHomeProvider))return null;return preparedHomeData;}
 String persistentHomeId(){// 52703: novo schema descarta snapshots com categorias M3U roteadas pelo ID numérico.
  String raw="catalog52870_"+(uid==null?"":uid)+"_"+(Api.PROVIDER==null?"":Api.PROVIDER);return raw.replaceAll("[^A-Za-z0-9._-]","_");}
 java.io.File persistentHomeFile(){java.io.File dir=new java.io.File(getFilesDir(),"gp_catalog");if(!dir.exists())dir.mkdirs();return new java.io.File(dir,"home_"+persistentHomeId()+".json.gz");}
 String persistentHomeStampKey(){return "catalog_sync_at_"+persistentHomeId();}
 String persistentHomeUseKey(){return "catalog_last_use_"+persistentHomeId();}
 boolean isPersistentHomeStale(){long last=sp.getLong(persistentHomeUseKey(),0L);return last<=0L||System.currentTimeMillis()-last>HOME_INACTIVITY_RESYNC_MS;}
 void markPersistentHomeUsed(){sp.edit().putLong(persistentHomeUseKey(),System.currentTimeMillis()).apply();}
 boolean shouldRefreshCatalogInBackground(){long at=sp.getLong(persistentHomeStampKey(),0L);return at<=0L||System.currentTimeMillis()-at>HOME_BACKGROUND_REFRESH_MS;}
 void scheduleCatalogRefreshIfNeeded(){if(!shouldRefreshCatalogInBackground()&&catalogFlagsReady(readHomeCache()))return;new Handler(Looper.getMainLooper()).postDelayed(()->prefetchUnifiedCatalogSnapshot(),1200);}
 static void writeJsonStream(java.io.Writer w,Object v)throws Exception{
  if(v==null||v==JSONObject.NULL){w.write("null");return;}
  if(v instanceof JSONObject){JSONObject o=(JSONObject)v;w.write('{');java.util.Iterator<String> it=o.keys();boolean first=true;while(it.hasNext()){String k=it.next();if(!first)w.write(',');first=false;w.write(JSONObject.quote(k));w.write(':');writeJsonStream(w,o.opt(k));}w.write('}');return;}
  if(v instanceof JSONArray){JSONArray a=(JSONArray)v;w.write('[');for(int i=0;i<a.length();i++){if(i>0)w.write(',');writeJsonStream(w,a.opt(i));}w.write(']');return;}
  if(v instanceof Number||v instanceof Boolean){w.write(String.valueOf(v));return;}w.write(JSONObject.quote(String.valueOf(v)));
 }
 void persistHomeCacheAsync(JSONObject j){if(j==null)return;final String id=persistentHomeId();final java.io.File target=persistentHomeFile();CATALOG_IO.execute(()->{java.io.File tmp=new java.io.File(target.getParentFile(),target.getName()+".tmp");try{java.io.OutputStream fos=new java.io.FileOutputStream(tmp);java.util.zip.GZIPOutputStream gz=new java.util.zip.GZIPOutputStream(fos,32768);java.io.Writer w=new java.io.BufferedWriter(new java.io.OutputStreamWriter(gz,java.nio.charset.StandardCharsets.UTF_8),32768);writeJsonStream(w,j);w.flush();w.close();if(target.exists())target.delete();if(!tmp.renameTo(target)){java.io.InputStream in=new java.io.FileInputStream(tmp);java.io.OutputStream out=new java.io.FileOutputStream(target);byte[] b=new byte[32768];int n;while((n=in.read(b))>0)out.write(b,0,n);in.close();out.close();tmp.delete();}runOnUiThread(()->{if(id.equals(persistentHomeId()))sp.edit().putLong(persistentHomeStampKey(),System.currentTimeMillis()).putLong(persistentHomeUseKey(),System.currentTimeMillis()).apply();});}catch(Throwable e){try{tmp.delete();}catch(Exception ignored){}}});}
 void loadPersistentHomeAsync(PersistentHomeCB cb){if(persistentHomeReadPending)return;persistentHomeReadPending=true;final java.io.File f=persistentHomeFile();CATALOG_IO.execute(()->{JSONObject out=null;try{if(f.exists()&&f.length()>64){java.io.InputStream in=new java.util.zip.GZIPInputStream(new java.io.BufferedInputStream(new java.io.FileInputStream(f),32768),32768);java.io.Reader r=new java.io.BufferedReader(new java.io.InputStreamReader(in,java.nio.charset.StandardCharsets.UTF_8),32768);final int maxChars=24*1024*1024;StringBuilder b=new StringBuilder((int)Math.min(2*1024*1024,Math.max(65536,f.length()*3)));char[] c=new char[32768];int n;while((n=r.read(c))>0){if(b.length()+n>maxChars)throw new java.io.IOException("cache antigo muito grande");b.append(c,0,n);}r.close();out=new JSONObject(b.toString());}}catch(Throwable e){try{f.delete();}catch(Exception ignored){}}final JSONObject ready=out;runOnUiThread(()->{persistentHomeReadPending=false;if(ready!=null)cb.ok(ready);else cb.miss();});});}
 void warmCachedHomeAssets(JSONObject cache){if(cache==null)return;try{warmCriticalHomeImages(cache,()->{});prefetchDetailsFromCatalog(cache,12);JSONArray live=cache.optJSONArray("live_channels");if(live!=null){warmLiveLogosFromDisk(live,96);prefetchMissingLiveLogoFamilies(live);}}catch(Exception ignored){}}
 void prefetchMissingLiveLogoFamilies(JSONArray live){if(live==null||live.length()==0)return;java.util.ArrayList<java.util.List<String>> work=new java.util.ArrayList<>();for(int i=0;i<live.length()&&work.size()<48;i++){JSONObject ch=live.optJSONObject(i);if(ch==null)continue;String[] c=tvChannelLogoCandidates(ch);if(c.length==0)continue;boolean cached=false;for(String u:c)if(Img.hasCached(this,u)){cached=true;break;}if(cached)continue;String chosen="";for(String u:c){if(u!=null&&u.contains("/storage/channel_logos/")){chosen=u;break;}}if(chosen.isEmpty())continue;java.util.ArrayList<String> own=new java.util.ArrayList<>();own.add(chosen);work.add(own);}if(work.isEmpty())return;Img.prefetchLogoGroups(this,work,null,()->{});}
 void warmLiveLogosFromDisk(JSONArray live,int max){if(live==null)return;java.util.ArrayList<String> urls=new java.util.ArrayList<>();for(int i=0;i<live.length()&&urls.size()<max;i++){JSONObject ch=live.optJSONObject(i);if(ch==null)continue;String[] a=tvChannelLogoCandidates(ch);for(String u:a){if(u!=null&&!u.trim().isEmpty()){urls.add(u);break;}}}Img.warmCachedLogos(this,urls,max,1400,()->{});}
 void showQuickResumeScreen(){base(true);root.setPadding(dp(22),dp(10),dp(22),dp(18));LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setGravity(Gravity.CENTER);ImageView logo=new ImageView(this);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);applyAppLogo(logo);c.addView(logo,new LinearLayout.LayoutParams(-1,dp(tvMode?72:92)));TextView t=t("Abrindo Yelly…",tvMode?18:19);t.setTypeface(null,1);t.setGravity(Gravity.CENTER);t.setTextColor(Color.WHITE);c.addView(t,new LinearLayout.LayoutParams(-1,dp(48)));TextView sub=t("Restaurando seu catálogo salvo",12);sub.setTextColor(0xffa1979e);sub.setGravity(Gravity.CENTER);c.addView(sub,new LinearLayout.LayoutParams(-1,dp(34)));root.addView(c,new LinearLayout.LayoutParams(-1,-1));}
 void clearPreparedHome(){preparedHomeData=null;preparedHomeProvider="";homeExtrasStarted=false;homeCachedTab="";homeViewAvailable=false;homeScrollY=0;detailMemoryCache.clear();detailPrefetchQueue.clear();detailPrefetchKeys.clear();}
 boolean homeHasType(JSONObject root,int wanted){JSONArray a=root==null?null:root.optJSONArray("result");if(a==null)return false;for(int i=0;i<a.length();i++){JSONObject sec=a.optJSONObject(i);if(sec==null)continue;int t=sec.optInt("type_id",sec.optInt("video_type",1));JSONArray d=sec.optJSONArray("data");if(t==wanted&&d!=null&&d.length()>0)return true;}return false;}
 JSONObject protectHomePayload(JSONObject fresh){ return fresh; }

 int homeTmdbCoveragePct(JSONObject rootJson){
  int total=0,ready=0;
  try{
   JSONArray sections=rootJson==null?null:rootJson.optJSONArray("result");
   if(sections==null)return 0;
   for(int i=0;i<sections.length()&&total<240;i++){
    JSONObject sec=sections.optJSONObject(i);if(sec==null)continue;
    int t=sec.optInt("type_id",sec.optInt("video_type",1));if(t!=1&&t!=2)continue;
    JSONArray a=sec.optJSONArray("data");if(a==null)continue;
    for(int k=0;k<a.length()&&k<4&&total<240;k++){
     JSONObject x=a.optJSONObject(k);if(x==null)continue;total++;
     String u=detailValue(x,"thumbnail","portrait_img","image","poster","landscape","landscape_img","backdrop");
     if(x.optInt("tmdb_id",0)>0&&!u.trim().isEmpty())ready++;
    }
   }
  }catch(Exception ignored){}
  if(total==0)return 0;
  return Math.round((ready*100f)/total);
 }

 
 void warmCriticalHomeImages(JSONObject j,Runnable done){
  java.util.ArrayList<String> urls=new java.util.ArrayList<>();java.util.HashSet<String> seen=new java.util.HashSet<>();
  try{JSONArray sections=j==null?null:j.optJSONArray("result");if(sections!=null){for(int i=0;i<sections.length()&&urls.size()<12;i++){JSONObject sec=sections.optJSONObject(i);if(sec==null)continue;int vt=sec.optInt("type_id",sec.optInt("video_type",1));if(vt!=1&&vt!=2)continue;JSONArray data=sec.optJSONArray("data");if(data==null)continue;for(int k=0;k<data.length()&&k<3&&urls.size()<12;k++){JSONObject x=data.optJSONObject(k);if(x==null||x.optInt("tmdb_id",0)<=0)continue;String poster=detailValue(x,"thumbnail","portrait_img","image","poster","backdrop");if(!poster.isEmpty()&&seen.add(poster))urls.add(poster);}}}}catch(Exception ignored){}
  Img.prefetchCritical(this,urls,Math.min(12,urls.size()),2800,done);
 }
 
 void warmHomeImages(JSONObject j,Runnable done){
  java.util.ArrayList<String> critical=new java.util.ArrayList<>();java.util.ArrayList<String> background=new java.util.ArrayList<>();java.util.HashSet<String> seen=new java.util.HashSet<>();
  try{
   JSONArray sections=j==null?null:j.optJSONArray("result");
   if(sections!=null)for(int i=0;i<sections.length()&&background.size()<96;i++){
    JSONObject sec=sections.optJSONObject(i);if(sec==null)continue;int vt=sec.optInt("type_id",sec.optInt("video_type",1));if(vt!=1&&vt!=2)continue;
    JSONArray data=sec.optJSONArray("data");if(data==null)continue;
    for(int k=0;k<data.length()&&k<4&&background.size()<96;k++){
     JSONObject source=data.optJSONObject(k);if(source==null)continue;
     JSONObject x=mergeDetailJson(source,readDetailCache(source));if(x==null)x=source;
     String poster=detailValue(x,"thumbnail","portrait_img","image","poster","backdrop","landscape","landscape_img");
     String land=detailValue(x,"landscape","landscape_img","backdrop","poster","thumbnail");
     if(!poster.isEmpty()&&seen.add(poster)){background.add(poster);if(k<2&&critical.size()<20)critical.add(poster);}
     if(i<6&&k==0&&!land.isEmpty()&&seen.add(land)){background.add(land);if(critical.size()<20)critical.add(land);}
    }
   }
  }catch(Exception ignored){}
  if(critical.isEmpty()){done.run();return;}
  Img.prefetchCritical(this,critical,Math.min(20,critical.size()),4200,()->{done.run();Img.prefetchBackground(this,background);});
 }
 void prefetchRowImages(JSONArray a){if(a==null)return;java.util.ArrayList<String> urls=new java.util.ArrayList<>();for(int i=0;i<a.length()&&i<12;i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;String u=x.optString("thumbnail",x.optString("portrait_img",x.optString("image","")));if(!u.isEmpty())urls.add(u);}Img.prefetchBackground(this,urls);}
 // 5.28 TMDB DIRETO: a fonte nunca decide a arte de filmes/séries.
 // O card só usa arte já confirmada pelo cache TMDB ou pelo content_enrich.
 void stripUnverifiedCatalogArt(JSONObject rootJson){/* 5.28.67: preserva arte válida da fonte/cache; fallback é decidido no servidor. */}
 void applyTmdbCard(JSONObject dst,JSONObject src){
  if(dst==null||src==null)return;String[] keys={"name","title","thumbnail","portrait_img","image","landscape","landscape_img","poster","backdrop","description_pt","overview_pt","synopsis_pt","sinopse","description","plot","overview","genre","category_name","rating","imdb_rating","tmdb_id","release_date"};for(String key:keys){try{if(!src.has(key))continue;Object v=src.opt(key);if(v==null)continue;if(v instanceof String&&((String)v).trim().isEmpty())continue;dst.put(key,v);}catch(Exception ignored){}}
 }
 java.util.ArrayList<JSONObject> collectCriticalTmdbCards(JSONObject rootJson){
  java.util.ArrayList<JSONObject> out=new java.util.ArrayList<>();java.util.HashSet<String> seen=new java.util.HashSet<>();try{JSONArray sections=rootJson==null?null:rootJson.optJSONArray("result");if(sections==null)return out;for(int wanted=1;wanted<=2;wanted++){int usedSections=0;for(int i=0;i<sections.length()&&usedSections<4;i++){JSONObject sec=sections.optJSONObject(i);if(sec==null)continue;int t=sec.optInt("type_id",sec.optInt("video_type",1));if(t!=wanted)continue;JSONArray a=sec.optJSONArray("data");if(a==null||a.length()==0)continue;usedSections++;for(int k=0;k<Math.min(3,a.length());k++){JSONObject x=a.optJSONObject(k);if(x==null)continue;String key=detailCacheKey(x);if(seen.add(key))out.add(x);}}}}catch(Exception ignored){}return out;
 }
 
 void prepareHomeThenShell(TextView msg,Button action){
  if(msg!=null){msg.setTextColor(0xffb8adb4);msg.setText("Sincronizando capas e conteúdo…");}
  fetchPreparedHome(-1,-1,new PreparedHomeCB(){public void ok(JSONObject j){
   JSONArray a=j.optJSONArray("result");
   if(a!=null&&a.length()>0){
    stripUnverifiedCatalogArt(j);saveHomeCache(j);sp.edit().putBoolean(homeExtrasKey(),false).apply();homeExtrasStarted=false;
    // Resolve cards visiveis ainda sem arte e baixa as imagens antes de abrir.
    prepareCriticalDetails(j,()->warmHomeImages(j,()->{saveHomeCache(j);shell();prefetchDetailsFromCatalog(j,18);}));
   }else shell();
  }public void err(String e){shell();}});
 }
 
 void prepareCriticalDetails(JSONObject rootJson,Runnable done){
  // 5.28.12: nunca bloquear a abertura esperando content_detail. O servidor já
  // entrega o que tem; o restante é enriquecido depois que a Home está utilizável.
  if(rootJson!=null)saveHomeCache(rootJson);
  if(done!=null)done.run();
  if(rootJson!=null)new Handler(Looper.getMainLooper()).postDelayed(()->{
   if(!isFinishing())prefetchDetailsFromCatalog(rootJson,16);
  },300);
 }

 void prepareCriticalDetailsBatch(JSONObject rootJson,java.util.ArrayList<JSONObject> pending,int start,java.util.concurrent.atomic.AtomicBoolean delivered,Handler h,Runnable finish){
  if(delivered.get())return;
  if(start>=pending.size()){h.removeCallbacks(finish);finish.run();return;}
  final int end=Math.min(start+4,pending.size());final int[] left={end-start};
  for(int i=start;i<end;i++){
   final JSONObject x=pending.get(i);int vt=x.optInt("video_type",x.optInt("type_id",1));String vid=x.optString("id",x.optString("video_id",""));
   if(vid.trim().isEmpty()){if(--left[0]<=0)prepareCriticalDetailsBatch(rootJson,pending,end,delivered,h,finish);continue;}
   Api.post("content_detail",Api.m("user_id",uid,"video_id",vid,"video_type",String.valueOf(vt),"category_id",x.optString("category_id",""),"provider_id",x.optString("provider_id","")),new Api.CB(){
    void next(){if(--left[0]<=0)prepareCriticalDetailsBatch(rootJson,pending,end,delivered,h,finish);}
    public void ok(JSONObject j){
     JSONArray a=j.optJSONArray("result");JSONObject d=(a!=null&&a.length()>0)?a.optJSONObject(0):null;
     if(d!=null){saveDetailCache(x,d);JSONObject merged=mergeDetailJson(x,d);if(merged!=null)applyTmdbCard(x,merged);}next();
    }
    public void err(String e){next();}
   });
  }
 }

 java.util.ArrayList<JSONObject> collectDetailPrefetchItems(JSONObject rootJson,int limit){java.util.ArrayList<JSONObject> out=new java.util.ArrayList<>();java.util.HashSet<String> seen=new java.util.HashSet<>();try{JSONArray sections=rootJson.optJSONArray("result");if(sections==null)return out;for(int i=0;i<sections.length()&&out.size()<limit;i++){JSONObject sec=sections.optJSONObject(i);if(sec==null)continue;JSONArray a=sec.optJSONArray("data");if(a==null)continue;for(int k=0;k<Math.min(4,a.length())&&out.size()<limit;k++){JSONObject x=a.optJSONObject(k);if(x==null)continue;String key=detailCacheKey(x);if(seen.add(key))out.add(x);}}}catch(Exception ignored){}return out;}

 void prefetchDetailsFromCatalog(JSONObject rootJson,int limit){for(JSONObject x:collectDetailPrefetchItems(rootJson,limit))queueDetailPrefetch(x);pumpDetailPrefetch();}
 void prefetchVisibleSeriesDetails(JSONArray rows,int limit){if(rows==null)return;for(int i=0;i<Math.min(limit,rows.length());i++){JSONObject x=rows.optJSONObject(i);if(x!=null)queueDetailPrefetch(x);}pumpDetailPrefetch();}
 void queueDetailPrefetch(JSONObject x){if(x==null)return;JSONObject c=mergeDetailJson(x,readDetailCache(x));if(c!=null&&!detailNeedsEnrich(c))return;String k=detailCacheKey(x);if(detailPrefetchKeys.contains(k))return;detailPrefetchKeys.add(k);try{detailPrefetchQueue.add(x);}catch(Exception ignored){detailPrefetchKeys.remove(k);}}
 void finishDetailPrefetch(String key){detailPrefetchActive--;detailPrefetchKeys.remove(key);pumpDetailPrefetch();}
 
 void pumpDetailPrefetch(){
  while(detailPrefetchActive<3&&!detailPrefetchQueue.isEmpty()){
   JSONObject x=detailPrefetchQueue.poll();if(x==null)continue;String key=detailCacheKey(x);detailPrefetchActive++;
   String ep=isYoutubeShort(x)?"dorama_enrich":"content_detail";java.util.Map<String,String> args=isYoutubeShort(x)?doramaEnrichArgs(x):Api.m("user_id",uid,"video_id",x.optString("id"),"video_type",x.optString("video_type",x.optString("type_id","1")),"category_id",x.optString("category_id",""),"provider_id",x.optString("provider_id",""));
   Api.post(ep,args,new Api.CB(){
    public void ok(JSONObject j){JSONArray a=j.optJSONArray("result");JSONObject d=(a!=null&&a.length()>0)?a.optJSONObject(0):null;if(d!=null)saveDetailCache(x,d);finishDetailPrefetch(key);}
    public void err(String e){finishDetailPrefetch(key);}
   });
  }
 }
 void showVpnBlocked(boolean startup){
  if(isFinishing())return;vpnStartupBlocked=vpnStartupBlocked||startup;
  try{if(vpnBlockDialog!=null&&vpnBlockDialog.isShowing())return;}catch(Exception ignored){}
  final android.app.Dialog[] ref=new android.app.Dialog[1];
  android.app.Dialog d=VpnBlockDialog.show(this,
   "Desative a VPN para usar o GreenPlay. Enquanto a VPN estiver ativa, Filmes, Séries e Canais ficam bloqueados.",
   true,
   ()->{vpnBlockDialog=null;if(SecurityGuard.vpnActive(this)){new Handler(Looper.getMainLooper()).postDelayed(()->showVpnBlocked(vpnStartupBlocked),180);}else{boolean restart=vpnStartupBlocked;vpnStartupBlocked=false;if(restart)recreate();else startVpnWatch();}},
   ()->{vpnBlockDialog=null;try{finishAndRemoveTask();}catch(Exception e){finish();}}
  );
  ref[0]=d;vpnBlockDialog=d;d.setOnDismissListener(x->{if(vpnBlockDialog==ref[0])vpnBlockDialog=null;});
 }
 boolean blockVpnProtectedContent(){if(!SecurityGuard.vpnActive(this))return false;showVpnBlocked(false);return true;}
 void startVpnWatch(){
  if(vpnWatch==null&&Build.VERSION.SDK_INT>=21){
   try{android.net.ConnectivityManager cm=(android.net.ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);if(cm!=null){android.net.NetworkRequest req=new android.net.NetworkRequest.Builder().addTransportType(android.net.NetworkCapabilities.TRANSPORT_VPN).build();vpnWatch=new android.net.ConnectivityManager.NetworkCallback(){@Override public void onAvailable(android.net.Network n){runOnUiThread(()->{if(!isFinishing()&&SecurityGuard.vpnActive(MainActivity.this))showVpnBlocked(false);});}@Override public void onCapabilitiesChanged(android.net.Network n,android.net.NetworkCapabilities c){if(c!=null&&c.hasTransport(android.net.NetworkCapabilities.TRANSPORT_VPN))runOnUiThread(()->{if(!isFinishing())showVpnBlocked(false);});}};cm.registerNetworkCallback(req,vpnWatch);}}catch(Throwable ignored){vpnWatch=null;}
  }
  if(vpnPollTask==null)vpnPollTask=new Runnable(){public void run(){if(!isFinishing()&&SecurityGuard.vpnActive(MainActivity.this))showVpnBlocked(false);if(vpnPollHandler!=null)vpnPollHandler.postDelayed(this,650);}};
  vpnPollHandler.removeCallbacks(vpnPollTask);vpnPollHandler.postDelayed(vpnPollTask,350);
 }
 void stopVpnWatch(){
  try{if(vpnWatch!=null){android.net.ConnectivityManager cm=(android.net.ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);if(cm!=null)cm.unregisterNetworkCallback(vpnWatch);}}catch(Throwable ignored){}
  vpnWatch=null;
  try{if(vpnPollTask!=null)vpnPollHandler.removeCallbacks(vpnPollTask);}catch(Throwable ignored){}
 }
 void shell(){
  authScreen=false;providerSwitchScreen=false;detailOpen=false;savedScroll=null;savedBody=null;sectionPageOpen=false;sectionParentScroll=null;sectionParentBody=null;sectionReturnTab="";sectionParentScrollY=0;sectionParentViewGen=0;
  base(false);standardRootInsets();
  if(wideTvUi()){
   navBar=buildTvAppHeader();root.addView(navBar,new LinearLayout.LayoutParams(-1,dp(102)));
  }
  contentFrame=new FrameLayout(this);
  mainScroll=new ScrollView(this);mainScroll.setFillViewport(true);mainScroll.setVerticalScrollBarEnabled(false);
  body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);int side=wideTvUi()?dp(28):dp(18);body.setPadding(side,wideTvUi()?dp(12):dp(2),side,wideTvUi()?dp(18):dp(10));mainScroll.addView(body);
  contentFrame.addView(mainScroll,new FrameLayout.LayoutParams(-1,-1));bindScrollTopButton(mainScroll);
  homeScrollCache=mainScroll;homeBodyCache=body;homeViewAvailable=true;homeScrollY=0;
  root.addView(contentFrame,new LinearLayout.LayoutParams(-1,0,1));
  if(!wideTvUi()){
   navBar=new LinearLayout(this);navBar.setGravity(Gravity.CENTER);navBar.setPadding(0,dp(3),0,0);navBar.setBackgroundColor(0xff201018);if(android.os.Build.VERSION.SDK_INT>=21)navBar.setElevation(0);
   navHome=navItem("","Início",0);navFav=navItem("","Favoritos",1);navTv=navItem("","Stories",2);navDownloads=navItem("","Downloads",3);navProfile=navItem("","Perfil",4);ensureGlobalCastButton();
   root.addView(navBar,new LinearLayout.LayoutParams(-1,dp(64)));installMobileBottomNavInsets();enforceGlobalBottomNav();
  }
  int firstNav=requestedStartNav;requestedStartNav=-1;
  if(openFootballFromNotification){openFootballFromNotification=false;openTvFootball();}
  else if(firstNav>=0){openInitialNav(firstNav);}
  else if(shouldDefaultToTvLanding()){liveContent();if(tvMode)new Handler(Looper.getMainLooper()).postDelayed(()->{if(currentNavIndex==2&&navTv!=null)requestTvFocus(navTv);},180);}
  else{home();if(tvMode)keepTvHomeAnchored();}
 }
 void openInitialNav(int nav){
  // 5.21: ao restaurar uma tela depois da troca de modo, nunca reutilizar o host
  // permanente da Home para Perfil/Favoritos/Downloads. Na 5.20 isso fazia a tela
  // restaurada sobrescrever o cache da Home e o botão Início parecia não funcionar.
  if(nav<=0){home();if(tvMode)keepTvHomeAnchored();return;}
  if(nav==2){home();launchStories();return;}
  if(mainScroll==homeScrollCache)leaveHomeForPage();
  if(nav==1){favorites();return;}
  if(nav==3){downloads();return;}
  if(nav==4){profile();return;}
  home();if(tvMode)keepTvHomeAnchored();
 }
 LinearLayout buildTvAppHeader(){
  LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(16),0,dp(16),0);bar.setBackgroundColor(0xff0c080b);if(android.os.Build.VERSION.SDK_INT>=21)bar.setElevation(dp(3));
  FrameLayout brand=new FrameLayout(this);brand.setFocusable(false);brand.setClickable(false);brand.setBackgroundColor(Color.TRANSPARENT);brand.setContentDescription("Yelly Doramas");ImageView logo=new ImageView(this);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);logo.setAdjustViewBounds(true);logo.setPadding(dp(8),dp(6),dp(8),dp(6));brand.addView(logo,new FrameLayout.LayoutParams(-1,-1));applyAppLogo(logo);bar.addView(brand,new LinearLayout.LayoutParams(dp(230),-1));
  LinearLayout menu=new LinearLayout(this);menu.setGravity(Gravity.CENTER);navShorts=tvHeroNavAction("Doramas",()->{if(detailOpen)closeDetails();homeTab("Shorts");});navHome=navShorts;uiTextSize(navShorts,17);menu.addView(navShorts,new LinearLayout.LayoutParams(dp(112),dp(60)));navFav=tvHeroNavAction("Favoritos",()->tvNavigate(1));uiTextSize(navFav,16);menu.addView(navFav,new LinearLayout.LayoutParams(dp(112),dp(60)));navTv=tvHeroNavAction("Stories",()->tvNavigate(2));uiTextSize(navTv,16);menu.addView(navTv,new LinearLayout.LayoutParams(dp(112),dp(60)));navDownloads=tvHeroNavAction("Downloads",()->tvNavigate(3));uiTextSize(navDownloads,16);menu.addView(navDownloads,new LinearLayout.LayoutParams(dp(112),dp(60)));bar.addView(menu,new LinearLayout.LayoutParams(0,-1,1));
  LinearLayout tools=new LinearLayout(this);tools.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);TextView profileTop=tvUtilityAction("♙","Perfil",()->tvNavigate(4));navProfile=profileTop;tools.addView(profileTop,new LinearLayout.LayoutParams(dp(46),dp(46)));TextView clock=t("",14);clock.setGravity(Gravity.CENTER);clock.setTextColor(0xfff7d5e4);clock.setTypeface(null,1);tools.addView(clock,new LinearLayout.LayoutParams(dp(72),-1));Runnable tick=new Runnable(){public void run(){try{clock.setText(new java.text.SimpleDateFormat("HH:mm",java.util.Locale.getDefault()).format(new java.util.Date()));clock.postDelayed(this,30000);}catch(Exception ignored){}}};clock.post(tick);bar.addView(tools,new LinearLayout.LayoutParams(dp(230),-1));
  linkTvHorizontal(navShorts,navFav);linkTvHorizontal(navFav,navTv);linkTvHorizontal(navTv,navDownloads);linkTvHorizontal(navDownloads,profileTop);return bar;
 }
 Drawable tvHeaderNavBackground(boolean active,boolean focused){
 GradientDrawable base=new GradientDrawable();
 base.setCornerRadius(dp(18));
 base.setColor(focused?0x24dc1f7e:Color.TRANSPARENT);
 base.setStroke(dp(focused?2:0),focused?0xfffff0fa:Color.TRANSPARENT);
 if(!active&&!focused)return base;
 GradientDrawable line=new GradientDrawable();
 line.setCornerRadius(dp(2));
 line.setColor(focused?Color.WHITE:GREEN);
 LayerDrawable layer=new LayerDrawable(new Drawable[]{base,line});
 layer.setLayerInset(1,dp(12),dp(52),dp(12),dp(2));
 return layer;
}
void styleTvHeaderItem(TextView v,boolean active,boolean focused){
 if(v==null)return;
 v.setTypeface(android.graphics.Typeface.create(android.graphics.Typeface.SANS_SERIF,android.graphics.Typeface.BOLD_ITALIC));
 // v16.236: foco do menu superior sem escala/elevação. Em TV Box isso evita
 // relayout/composição a cada seta e elimina a tremida perceptível da barra.
 v.setScaleX(1f);v.setScaleY(1f);if(android.os.Build.VERSION.SDK_INT>=21)v.setTranslationZ(0);
 if(focused){v.setTextColor(Color.WHITE);v.setShadowLayer(0f,0f,0f,0);v.setBackground(tvHeaderNavBackground(active,true));}
 else{v.setTextColor(active?0xffff86c2:0xfff4e5ef);v.setShadowLayer(active?0f:6f,0f,0f,active?0:0xaa000000);v.setBackground(tvHeaderNavBackground(active,false));}
}
boolean isTvHeaderActive(TextView v){
 if(v==null)return false;if(currentNavIndex==1)return v==navFav;if(currentNavIndex==3)return v==navDownloads;if(currentNavIndex==4)return v==navProfile;return v==navShorts||v==navHome;
}
void runTvHeaderAction(Runnable action){
 if(action==null||tvHeaderNavBusy)return;tvHeaderNavBusy=true;if(tvHeaderNavUnlock!=null)tvHeaderNavHandler.removeCallbacks(tvHeaderNavUnlock);
 // Executa no próximo frame: o foco termina de desenhar antes de desmontar a página atual.
 tvHeaderNavHandler.post(()->{try{action.run();}finally{tvHeaderNavUnlock=()->tvHeaderNavBusy=false;tvHeaderNavHandler.postDelayed(tvHeaderNavUnlock,180);}});
}
TextView tvHeroNavAction(String title,Runnable action){TextView v=t(title,24);v.setSingleLine(true);v.setGravity(Gravity.CENTER);v.setPadding(dp(10),0,dp(10),0);v.setTextColor(0xfff4e5ef);v.setTypeface(android.graphics.Typeface.create(android.graphics.Typeface.SANS_SERIF,android.graphics.Typeface.BOLD_ITALIC));v.setShadowLayer(6f,0f,0f,0xaa000000);v.setBackgroundColor(Color.TRANSPARENT);v.setFocusable(true);v.setFocusableInTouchMode(false);v.setOnClickListener(x->runTvHeaderAction(action));if(tvMode){tvFocusArmed.put(v,Boolean.TRUE);v.setOnFocusChangeListener((x,has)->styleTvHeaderItem((TextView)x,isTvHeaderActive((TextView)x),has));v.setOnKeyListener((x,key,event)->{if(event==null)return false;if(key==KeyEvent.KEYCODE_DPAD_CENTER||key==KeyEvent.KEYCODE_ENTER||key==KeyEvent.KEYCODE_NUMPAD_ENTER||key==KeyEvent.KEYCODE_BUTTON_A){if(event.getAction()==KeyEvent.ACTION_UP&&event.getRepeatCount()==0)x.performClick();return true;}return false;});}return v;}
 void openTvFootball(){
  if(detailOpen)closeDetails();
  if(currentNavIndex==2&&tvPageRoot!=null){releaseTvInlinePlayer();createTransientPageHost();}
  else if(currentNavIndex==0&&mainScroll==homeScrollCache)leaveHomeForPage();
  else if(mainScroll==null||body==null)createTransientPageHost();
  activeHomeTab="Futebol";clear();setNav(0);standardRootInsets();if(!tvMode)homeTop("Futebol");footballTablePage();if(tvMode)syncTvHeader("Futebol");
 }
 String footballDayKey(java.util.Calendar c){return new java.text.SimpleDateFormat("yyyy-MM-dd",java.util.Locale.US).format(c.getTime());}
 String footballDayLabel(java.util.Calendar c,int offset){String head=offset==0?"HOJE":(offset==-1?"ONTEM":(offset==1?"AMANHÃ":new java.text.SimpleDateFormat("EEE",java.util.Locale.getDefault()).format(c.getTime()).toUpperCase(java.util.Locale.getDefault())));String date=new java.text.SimpleDateFormat("dd/MM",java.util.Locale.getDefault()).format(c.getTime());return head+"\n"+date;}
 void centerFootballDateChip(HorizontalScrollView scroll,View chip,boolean smooth){
  if(scroll==null||chip==null)return;
  scroll.post(()->{try{int x=Math.max(0,chip.getLeft()-(scroll.getWidth()-chip.getWidth())/2);if(smooth)scroll.smoothScrollTo(x,0);else scroll.scrollTo(x,0);}catch(Exception ignored){}});
 }
 void footballTablePage(){
  body.setPadding(tvMode?tvContentSide():dp(14),dp(10),tvMode?tvContentSide():dp(14),tvMode?dp(34):dp(104));

  LinearLayout heading=new LinearLayout(this);
  heading.setOrientation(LinearLayout.VERTICAL);
  heading.setGravity(Gravity.CENTER_HORIZONTAL);

  TextView title=t("Jogos",tvMode?29:25);
  title.setTypeface(null,1);
  title.setTextColor(Color.WHITE);
  title.setGravity(Gravity.CENTER);
  heading.addView(title,new LinearLayout.LayoutParams(-1,dp(40)));

  TextView sub=t("Futebol ao vivo e próximos jogos",13);
  sub.setTextColor(0xffa399a0);
  sub.setGravity(Gravity.CENTER);
  sub.setIncludeFontPadding(false);
  heading.addView(sub,new LinearLayout.LayoutParams(-1,dp(30)));

  LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,dp(76));
  hp.setMargins(0,dp(2),0,dp(6));
  body.addView(heading,hp);

  HorizontalScrollView datesScroll=new HorizontalScrollView(this);
  datesScroll.setHorizontalScrollBarEnabled(false);
  datesScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
  datesScroll.setFillViewport(false);

  LinearLayout dates=new LinearLayout(this);
  dates.setOrientation(LinearLayout.HORIZONTAL);
  dates.setGravity(Gravity.CENTER_VERTICAL);
  dates.setClipToPadding(false);
  datesScroll.addView(dates,new HorizontalScrollView.LayoutParams(-2,-1));

  LinearLayout.LayoutParams dlp=new LinearLayout.LayoutParams(-1,dp(62));
  dlp.setMargins(0,0,0,dp(10));
  body.addView(datesScroll,dlp);

  java.util.ArrayList<TextView> chips=new java.util.ArrayList<>();
  java.util.Calendar base=java.util.Calendar.getInstance();
  for(int off=-2;off<=2;off++){
   java.util.Calendar d=(java.util.Calendar)base.clone();d.add(java.util.Calendar.DAY_OF_MONTH,off);
   TextView chip=t(footballDayLabel(d,off),12);
   chip.setGravity(Gravity.CENTER);chip.setLines(2);chip.setTypeface(null,1);chip.setTag(footballDayKey(d));
   final int pos=off+2;
   GradientDrawable cg=round(off==0?0xff351424:0xff171013,15);
   cg.setStroke(dp(off==0?2:1),off==0?GREEN:0xff402934);
   chip.setBackground(cg);chip.setTextColor(off==0?Color.WHITE:0xffcfc3cb);

   LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(tvMode?126:94),dp(50));
   cp.setMargins(0,0,dp(9),0);
   dates.addView(chip,cp);chips.add(chip);
   if(tvMode)armTvFocus(chip);

   final int selected=pos;
   chip.setOnClickListener(v->{
    for(int i=0;i<chips.size();i++){
     TextView c=chips.get(i);boolean on=i==selected;
     GradientDrawable g=round(on?0xff351424:0xff171013,15);
     g.setStroke(dp(on?2:1),on?GREEN:0xff402934);
     c.setBackground(g);c.setTextColor(on?Color.WHITE:0xffcfc3cb);
    }
    if(!tvMode)centerFootballDateChip(datesScroll,v,true);
    loadFootballDate(String.valueOf(v.getTag()));
   });
  }

  if(tvMode)for(int i=0;i+1<chips.size();i++)linkTvHorizontal(chips.get(i),chips.get(i+1));
  if(chips.size()>2&&!tvMode){
   datesScroll.post(()->{
    try{
     int side=Math.max(0,(datesScroll.getWidth()-chips.get(2).getWidth())/2);
     dates.setPadding(side,0,side,0);
     dates.requestLayout();
     centerFootballDateChip(datesScroll,chips.get(2),false);
    }catch(Exception ignored){}
   });
  }

  LinearLayout section=new LinearLayout(this);
  section.setGravity(Gravity.CENTER_VERTICAL);
  section.setPadding(dp(2),0,dp(2),0);

  TextView sectionTitle=t("PARTIDAS",11);
  sectionTitle.setTypeface(null,1);
  sectionTitle.setTextColor(0xff90878d);
  section.addView(sectionTitle,new LinearLayout.LayoutParams(0,dp(28),1));

  View line=new View(this);
  line.setBackgroundColor(0xff2a1c23);
  section.addView(line,new LinearLayout.LayoutParams(dp(72),dp(1)));
  body.addView(section,new LinearLayout.LayoutParams(-1,dp(34)));

  LinearLayout host=new LinearLayout(this);
  host.setOrientation(LinearLayout.VERTICAL);
  host.setTag("football_rows");
  body.addView(host,new LinearLayout.LayoutParams(-1,-2));

  renderFootballLoading();

  if(chips.size()>2){
   if(tvMode){linkTvVertical(navFootball,chips.get(2));requestTvFocus(chips.get(2));}
   loadFootballDate(String.valueOf(chips.get(2).getTag()));
  }
 }
 void renderFootballLoading(){View v=body==null?null:body.findViewWithTag("football_rows");if(!(v instanceof LinearLayout))return;LinearLayout host=(LinearLayout)v;host.removeAllViews();TextView msg=t("Carregando jogos...",15);msg.setGravity(Gravity.CENTER);msg.setTextColor(0xffb6abb2);host.addView(msg,new LinearLayout.LayoutParams(-1,dp(86)));}
 void renderFootballEmptyState(){View v=body==null?null:body.findViewWithTag("football_rows");if(!(v instanceof LinearLayout))return;LinearLayout host=(LinearLayout)v;host.removeAllViews();TextView ball=t("⚽",30);ball.setGravity(Gravity.CENTER);host.addView(ball,new LinearLayout.LayoutParams(-1,dp(48)));TextView msg=t("Nenhum jogo encontrado para esta data",15);msg.setTypeface(null,1);msg.setGravity(Gravity.CENTER);msg.setTextColor(0xffe0d3dc);host.addView(msg,new LinearLayout.LayoutParams(-1,dp(42)));}
 String footballCacheKey(String date){
  String p=Api.PROVIDER==null?"":Api.PROVIDER.trim();
  p=p.replaceAll("[^a-zA-Z0-9_-]","_");
  return "football_rows_"+p+"_"+date;
 }
 long footballCacheAge(String date){
  if(sp==null)return Long.MAX_VALUE;
  long ts=sp.getLong(footballCacheKey(date)+"_ts",0L);
  if(ts<=0)return Long.MAX_VALUE;
  return Math.max(0L,System.currentTimeMillis()-ts);
 }
 JSONArray footballCachedRows(String date,long maxAgeMs){
  try{
   if(sp==null||footballCacheAge(date)>maxAgeMs)return null;
   String raw=sp.getString(footballCacheKey(date),"");
   if(raw==null||raw.trim().isEmpty())return null;
   JSONArray a=new JSONArray(raw);
   return a.length()>0?a:null;
  }catch(Exception ignored){return null;}
 }
 void saveFootballCache(String date,JSONArray rows){
  if(sp==null||rows==null||rows.length()==0)return;
  try{
   sp.edit().putString(footballCacheKey(date),rows.toString())
    .putLong(footballCacheKey(date)+"_ts",System.currentTimeMillis()).apply();
  }catch(Exception ignored){}
 }
 void prefetchFootballToday(){
  if(footballPrefetchBusy||sp==null)return;
  String date=footballDayKey(java.util.Calendar.getInstance());
  if(footballCacheAge(date)<45000L)return;
  footballPrefetchBusy=true;
  Api.post("football",Api.m("date",date),new Api.CB(){
   public void ok(JSONObject j){
    footballPrefetchBusy=false;
    JSONArray a=j.optJSONArray("result");
    if(j.optInt("status",200)==200&&a!=null&&a.length()>0){
     saveFootballCache(date,a);
     if(date.equals(footballSelectedDate)&&body!=null){
      View v=body.findViewWithTag("football_rows");
      if(v instanceof LinearLayout)renderFootballRows(a);
     }
    }
   }
   public void err(String e){footballPrefetchBusy=false;}
  });
 }
 void loadFootballDate(String date){
  footballSelectedDate=date;
  final JSONArray cached=footballCachedRows(date,24L*60L*60L*1000L);
  final boolean hadCached=cached!=null&&cached.length()>0;
  if(hadCached)renderFootballRows(cached);else renderFootballLoading();

  if(hadCached&&footballCacheAge(date)<45000L)return;
  String today=footballDayKey(java.util.Calendar.getInstance());
  if(footballPrefetchBusy&&date.equals(today))return;

  Api.post("football",Api.m("date",date),new Api.CB(){
   public void ok(JSONObject j){
    JSONArray a=j.optJSONArray("result");
    boolean good=j.optInt("status",200)==200&&a!=null&&a.length()>0;
    if(good)saveFootballCache(date,a);
    if(body==null||!date.equals(footballSelectedDate))return;
    if(!good){if(!hadCached)renderFootballEmptyState();return;}
    renderFootballRows(a);
   }
   public void err(String e){
    if(body==null||!date.equals(footballSelectedDate)||hadCached)return;
    View v=body.findViewWithTag("football_rows");
    if(!(v instanceof LinearLayout))return;
    LinearLayout host=(LinearLayout)v;
    host.removeAllViews();
    TextView msg=t("Não foi possível carregar os jogos agora.",15);
    msg.setGravity(Gravity.CENTER);
    msg.setTextColor(0xffffb4ab);
    host.addView(msg,new LinearLayout.LayoutParams(-1,dp(54)));
    TextView sub=t("Tente novamente em alguns instantes.",12);
    sub.setGravity(Gravity.CENTER);
    sub.setTextColor(0xff9c9399);
    host.addView(sub,new LinearLayout.LayoutParams(-1,dp(34)));
   }
  });
 }
 String footballKickoff(JSONObject x){long ts=x.optLong("timestamp",0);if(ts<=0)return "--:--";try{return new java.text.SimpleDateFormat("HH:mm",java.util.Locale.getDefault()).format(new java.util.Date(ts*1000L));}catch(Exception e){return "--:--";}}
 void renderFootballRows(JSONArray rows){View v=body==null?null:body.findViewWithTag("football_rows");if(!(v instanceof LinearLayout))return;LinearLayout host=(LinearLayout)v;host.removeAllViews();final int gen=++viewGen;final int[] idx={0};final Handler h=new Handler(Looper.getMainLooper());Runnable add=new Runnable(){public void run(){if(gen!=viewGen||host.getParent()==null)return;int end=Math.min(rows.length(),idx[0]+12);for(;idx[0]<end;idx[0]++){JSONObject x=rows.optJSONObject(idx[0]);if(x!=null)host.addView(footballGameRow(x),new LinearLayout.LayoutParams(-1,-2));}if(idx[0]<rows.length())h.postDelayed(this,16);}};h.post(add);}
 JSONObject bestFootballChannel(JSONArray rows,String search){
  if(rows==null||rows.length()==0)return null;String q=search==null?"":search.trim().toLowerCase(java.util.Locale.ROOT);JSONObject best=null;int bestScore=-999;
  for(int i=0;i<rows.length();i++){JSONObject x=rows.optJSONObject(i);if(x==null||!isRealLiveChannel(x))continue;String n=tvChannelName(x).toLowerCase(java.util.Locale.ROOT);int score=0;if(!q.isEmpty()){if(n.equals(q))score+=100;else if(n.startsWith(q))score+=70;else if(n.contains(q))score+=50;else continue;}if(n.contains("4k"))score+=9;else if(n.contains("fhd"))score+=8;else if(n.contains(" hd"))score+=6;else if(n.contains("sd"))score-=2;if(score>bestScore){best=x;bestScore=score;}}
  return best;
 }
 void openFootballMappedChannel(String search,boolean typed){
  if(search==null||search.trim().isEmpty()){Toast.makeText(this,"Canal deste jogo ainda não foi definido no painel.",Toast.LENGTH_LONG).show();liveContent();return;}
  JSONArray cached=filterLiveSnapshot("",search);JSONObject hit=bestFootballChannel(cached,search);if(hit!=null){openLiveAllowed(hit);return;}
  fetchAllLiveChannelPages("",search,typed,0,new JSONArray(),new java.util.HashSet<String>(),new AllPagesCB(){public void ok(JSONArray a){runOnUiThread(()->{JSONObject ch=bestFootballChannel(a,search);if(ch!=null){openLiveAllowed(ch);return;}if(!typed){openFootballMappedChannel(search,true);return;}Toast.makeText(MainActivity.this,"Canal configurado não foi encontrado neste servidor.",Toast.LENGTH_LONG).show();liveContent();});}public void err(String e){runOnUiThread(()->{if(!typed){openFootballMappedChannel(search,true);return;}Toast.makeText(MainActivity.this,"Não foi possível localizar o canal da transmissão.",Toast.LENGTH_LONG).show();liveContent();});}});
 }
 void watchFootballGame(JSONObject game){
  if(game==null||!game.optBoolean("live",false))return;if(blockVpnProtectedContent())return;
  JSONObject direct=game.optJSONObject("watch_channel");
  if(direct!=null&&direct.optString("video_720",direct.optString("video_1080","")).trim().length()>0){openLiveAllowed(direct);return;}
  String search=game.optString("watch_search","").trim();openFootballMappedChannel(search,false);
 }
 void requestFootballReminderPermission(){
  if(Build.VERSION.SDK_INT>=33&&checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=android.content.pm.PackageManager.PERMISSION_GRANTED){
   try{requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},REQ_FOOTBALL_NOTIFICATIONS);}catch(Exception ignored){}
  }
 }
 void styleFootballReminderButton(TextView v,boolean active){
  if(v==null)return;
  v.setText(active?"🔔  Lembrete ativado":"🔔  Lembrar-me");
  v.setTextColor(active?0xffff8dc6:0xffddd0d9);
  v.setTypeface(null,1);v.setGravity(Gravity.CENTER);
  GradientDrawable b=round(active?0xff2b0d1c:0xff1f151a,12);
  b.setStroke(dp(1),active?GREEN:0xff523544);v.setBackground(b);
 }
 View footballGameRow(JSONObject x){
  JSONObject league=x.optJSONObject("league"),home=x.optJSONObject("home"),away=x.optJSONObject("away");
  if(league==null)league=new JSONObject();
  if(home==null)home=new JSONObject();
  if(away==null)away=new JSONObject();

  boolean live=x.optBoolean("live",false);
  String status=x.optString("status","").trim();
  String time=footballKickoff(x);
  Object hg=home.opt("goals"),ag=away.opt("goals");
  String score=(hg!=null&&hg!=JSONObject.NULL&&ag!=null&&ag!=JSONObject.NULL)?String.valueOf(hg)+" x "+String.valueOf(ag):"x";
  if(status.isEmpty())status=live?"Ao vivo":"Agendado";

  JSONArray broadcastNames=x.optJSONArray("broadcast_names");
  StringBuilder bt=new StringBuilder();
  if(broadcastNames!=null){
   for(int bi=0;bi<broadcastNames.length()&&bi<6;bi++){
    String bn=broadcastNames.optString(bi,"").trim();
    if(bn.isEmpty())continue;
    if(bt.length()>0)bt.append(" • ");
    bt.append(bn);
   }
  }

  JSONObject linked=x.optJSONObject("watch_channel");
  String linkedName=linked==null?"":linked.optString("name",linked.optString("stream_name","")).trim();

  LinearLayout wrap=new LinearLayout(this);
  wrap.setOrientation(LinearLayout.VERTICAL);
  wrap.setPadding(dp(12),dp(9),dp(12),dp(10));

  GradientDrawable bg=round(live?0xff1b0d14:0xff170e12,18);
  bg.setStroke(dp(1),live?GREEN:0xff3a242f);
  wrap.setBackground(bg);

  LinearLayout.LayoutParams wp=new LinearLayout.LayoutParams(-1,-2);
  wp.setMargins(0,0,0,dp(10));
  wrap.setLayoutParams(wp);

  LinearLayout top=new LinearLayout(this);
  top.setGravity(Gravity.CENTER_VERTICAL);

  TextView lg=t(league.optString("name","Futebol"),11);
  lg.setTypeface(null,1);
  lg.setSingleLine(true);
  lg.setEllipsize(android.text.TextUtils.TruncateAt.END);
  lg.setTextColor(0xffb0a5ac);
  top.addView(lg,new LinearLayout.LayoutParams(0,dp(28),1));

  TextView st=t(live?("●  "+status):(time+"   "+status),11);
  st.setTypeface(null,1);
  st.setTextColor(live?GREEN:0xffddd0d9);
  st.setGravity(Gravity.CENTER);
  st.setPadding(dp(9),0,dp(9),0);
  GradientDrawable stBg=round(live?0xff3d1228:0xff23181e,11);
  stBg.setStroke(dp(1),live?0xff762d52:0xff402a35);
  st.setBackground(stBg);
  top.addView(st,new LinearLayout.LayoutParams(-2,dp(26)));
  wrap.addView(top,new LinearLayout.LayoutParams(-1,dp(29)));

  LinearLayout teams=new LinearLayout(this);
  teams.setGravity(Gravity.CENTER_VERTICAL);
  teams.setPadding(0,dp(2),0,dp(1));

  ImageView hi=new ImageView(this);
  hi.setScaleType(ImageView.ScaleType.FIT_CENTER);
  String hl=home.optString("logo","");
  if(!hl.isEmpty())Img.loadVisible(hi,hl);
  teams.addView(hi,new LinearLayout.LayoutParams(dp(39),dp(39)));

  TextView hn=t(home.optString("name",""),13);
  hn.setTypeface(null,1);
  hn.setMaxLines(2);
  hn.setEllipsize(android.text.TextUtils.TruncateAt.END);
  hn.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
  hn.setPadding(dp(8),0,dp(3),0);
  teams.addView(hn,new LinearLayout.LayoutParams(0,dp(54),1));

  TextView sc=t(score,16);
  sc.setTypeface(null,1);
  sc.setGravity(Gravity.CENTER);
  sc.setTextColor(Color.WHITE);
  teams.addView(sc,new LinearLayout.LayoutParams(dp(50),dp(54)));

  TextView an=t(away.optString("name",""),13);
  an.setTypeface(null,1);
  an.setMaxLines(2);
  an.setEllipsize(android.text.TextUtils.TruncateAt.END);
  an.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
  an.setPadding(dp(3),0,dp(8),0);
  teams.addView(an,new LinearLayout.LayoutParams(0,dp(54),1));

  ImageView ai=new ImageView(this);
  ai.setScaleType(ImageView.ScaleType.FIT_CENTER);
  String al=away.optString("logo","");
  if(!al.isEmpty())Img.loadVisible(ai,al);
  teams.addView(ai,new LinearLayout.LayoutParams(dp(39),dp(39)));

  wrap.addView(teams,new LinearLayout.LayoutParams(-1,dp(56)));

  String round=league.optString("round","").trim();
  String roundNorm=round.toLowerCase(java.util.Locale.ROOT);
  boolean validRound=!round.isEmpty()&&!round.equals("-")&&!round.equals("--")&&!roundNorm.equals("null")&&!roundNorm.equals("n/a")&&!roundNorm.equals("na");
  if(validRound){
   TextView r=t(round,10);
   r.setTextColor(0xff867e83);
   r.setSingleLine(true);
   r.setEllipsize(android.text.TextUtils.TruncateAt.END);
   r.setGravity(Gravity.CENTER);
   LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(17));
   rp.setMargins(0,0,0,dp(3));
   wrap.addView(r,rp);
  }

  if(bt.length()>0){
   TextView tv=t("📺  Onde assistir\n"+bt,11);
   tv.setTextColor(0xffcec2ca);
   tv.setMaxLines(3);
   tv.setEllipsize(android.text.TextUtils.TruncateAt.END);
   tv.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
   tv.setPadding(dp(10),dp(5),dp(10),dp(5));
   GradientDrawable ib=round(0xff1c1116,12);
   ib.setStroke(dp(1),0xff3c2631);
   tv.setBackground(ib);

   LinearLayout.LayoutParams ilp=new LinearLayout.LayoutParams(-1,dp(bt.length()>55?50:44));
   ilp.setMargins(0,dp(3),0,dp(6));
   wrap.addView(tv,ilp);
  }

  if(!linkedName.isEmpty()){
   TextView lc=t("✓  GreenPlay  •  "+linkedName,11);
   lc.setTextColor(0xffff8dc6);
   lc.setTypeface(null,1);
   lc.setMaxLines(2);
   lc.setEllipsize(android.text.TextUtils.TruncateAt.END);
   lc.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
   lc.setPadding(dp(10),dp(4),dp(10),dp(4));
   GradientDrawable lb=round(0xff2b0d1c,12);
   lb.setStroke(dp(1),0xff5b2440);
   lc.setBackground(lb);

   LinearLayout.LayoutParams llp=new LinearLayout.LayoutParams(-1,dp(38));
   llp.setMargins(0,0,0,dp(1));
   wrap.addView(lc,llp);
  }

  long reminderTs=x.optLong("timestamp",0);
  boolean reminderEligible=!live&&reminderTs>System.currentTimeMillis()/1000L-60L;
  if(reminderEligible){
   final TextView remind=t("",12);
   boolean activeReminder=FootballReminderManager.isActive(this,x);
   styleFootballReminderButton(remind,activeReminder);
   remind.setFocusable(tvMode);
   remind.setContentDescription(activeReminder?"Lembrete ativado":"Lembrar quando o jogo começar");
   remind.setOnClickListener(v->{
    boolean now=FootballReminderManager.toggle(MainActivity.this,x);
    styleFootballReminderButton(remind,now);
    remind.setContentDescription(now?"Lembrete ativado":"Lembrar quando o jogo começar");
    if(now){
     requestFootballReminderPermission();
     Toast.makeText(MainActivity.this,"Lembrete ativado. Vou avisar quando o jogo começar.",Toast.LENGTH_SHORT).show();
    }else Toast.makeText(MainActivity.this,"Lembrete removido.",Toast.LENGTH_SHORT).show();
   });
   if(tvMode)armTvFocus(remind);
   LinearLayout.LayoutParams rlp=new LinearLayout.LayoutParams(-1,dp(38));
   rlp.setMargins(0,dp(6),0,0);
   wrap.addView(remind,rlp);
  }

  if(live&&x.optBoolean("watch_available",false)){
   TextView watch=t("▶  Assistir",14);
   watch.setTypeface(null,1);
   watch.setTextColor(0xff15070e);
   watch.setGravity(Gravity.CENTER);
   watch.setFocusable(tvMode);
   GradientDrawable wb=round(GREEN,14);
   watch.setBackground(wb);
   watch.setContentDescription("Assistir jogo ao vivo");
   watch.setOnClickListener(v->watchFootballGame(x));
   if(tvMode)armTvFocus(watch);

   LinearLayout.LayoutParams wlp=new LinearLayout.LayoutParams(-1,dp(44));
   wlp.setMargins(0,dp(7),0,0);
   wrap.addView(watch,wlp);
  }else if(live){
   TextView wait=t("● AO VIVO  •  procurando canal no GreenPlay",11);
   wait.setGravity(Gravity.CENTER);
   wait.setTextColor(0xffffc875);
   LinearLayout.LayoutParams wlp=new LinearLayout.LayoutParams(-1,dp(30));
   wlp.setMargins(0,dp(4),0,0);
   wrap.addView(wait,wlp);
  }

  return wrap;
 }

 int tvCatalogSideWidthPx(){int w=getResources().getDisplayMetrics().widthPixels;return Math.max(dp(210),Math.min(dp(270),(int)(w*.175f)));}
 int tvCatalogColumnsForCount(int count){if(count==10)return 5;if(count==8)return 4;if(count<=6&&count>=4)return count;return 6;}
 void openTvCatalogBrowser(int typeId,String title,boolean kidsOnly){
  if(!kidsOnly&&blockVpnProtectedContent())return;
  if(!tvMode){homeTab(title);return;}if(detailOpen)closeDetails();try{releaseTvInlinePlayer();}catch(Exception ignored){}createTvPageHost();
  activeHomeTab=title;clear();setNav(0);standardRootInsets();syncTvHeader(title);body.setPadding(0,0,0,0);
  LinearLayout split=new LinearLayout(this);split.setOrientation(LinearLayout.HORIZONTAL);split.setBackgroundColor(Color.BLACK);body.addView(split,new LinearLayout.LayoutParams(-1,0,1));
  int sideW=tvCatalogSideWidthPx();
  LinearLayout side=new LinearLayout(this);side.setOrientation(LinearLayout.VERTICAL);side.setPadding(dp(12),dp(12),dp(10),dp(12));GradientDrawable sb=round(0xff14060d,18);sb.setStroke(dp(1),0xff561f3b);side.setBackground(sb);split.addView(side,new LinearLayout.LayoutParams(sideW,-1));
  TextView searchBar=t("Pesquisar...",12);searchBar.setTextColor(0xffa399a0);searchBar.setGravity(Gravity.CENTER_VERTICAL);searchBar.setPadding(dp(14),0,dp(12),0);GradientDrawable searchBg=round(0xff170b11,12);searchBg.setStroke(dp(1),0xff523142);searchBar.setBackground(searchBg);searchBar.setContentDescription("Pesquisar "+title);searchBar.setOnClickListener(v->searchDialog());side.addView(searchBar,new LinearLayout.LayoutParams(-1,dp(38)));
  TextView heading=t(title.toUpperCase(java.util.Locale.getDefault()),16);heading.setTypeface(null,1);heading.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);heading.setPadding(dp(2),dp(10),0,0);side.addView(heading,new LinearLayout.LayoutParams(-1,dp(40)));
  TextView catLabel=t("Categorias",12);catLabel.setTypeface(null,1);catLabel.setTextColor(0xffd6c9d2);catLabel.setPadding(dp(2),0,0,0);side.addView(catLabel,new LinearLayout.LayoutParams(-1,dp(28)));
  ScrollView catScroll=new ScrollView(this);catScroll.setFillViewport(true);catScroll.setVerticalScrollBarEnabled(false);catScroll.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);LinearLayout catHost=new LinearLayout(this);catHost.setOrientation(LinearLayout.VERTICAL);catScroll.addView(catHost,new ScrollView.LayoutParams(-1,-2));side.addView(catScroll,new LinearLayout.LayoutParams(-1,0,1));enableIndependentTvScroll(catScroll);
  FrameLayout catalogHost=new FrameLayout(this);catalogHost.setBackgroundColor(Color.BLACK);split.addView(catalogHost,new LinearLayout.LayoutParams(0,-1,1));androidx.recyclerview.widget.RecyclerView recycler=new androidx.recyclerview.widget.RecyclerView(this);recycler.setClipToPadding(false);recycler.setPadding(dp(14),dp(14),dp(2),dp(24));recycler.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);recycler.setItemViewCacheSize(18);recycler.setHasFixedSize(false);recycler.setLayoutManager(new androidx.recyclerview.widget.GridLayoutManager(this,6));catalogHost.addView(recycler,new FrameLayout.LayoutParams(-1,-1));TextView state=t("Carregando conteúdo…",13);state.setTextColor(0xffa0969d);state.setGravity(Gravity.CENTER);catalogHost.addView(state,new FrameLayout.LayoutParams(-1,-1));tvCatalogRecycler=recycler;tvCatalogState=state;tvCatalogAdapter=new TvCatalogAdapter();recycler.setAdapter(tvCatalogAdapter);tvCatalogGridScroll=null;tvCatalogGrid=null;
  if(kidsOnly)loadTvKidsBrowserCategoriesRv(catHost,recycler);else loadTvBrowserCategoriesRv(typeId,catHost,recycler);
 }

 class TvCatalogHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder{LinearLayout card;ImageView image;TextView name;TvCatalogHolder(LinearLayout v,ImageView i,TextView n){super(v);card=v;image=i;name=n;}}
 class TvCatalogAdapter extends androidx.recyclerview.widget.RecyclerView.Adapter<TvCatalogHolder>{
  JSONArray rows=new JSONArray();int cols=6,cardW=dp(150),imgH=dp(210),gap=dp(9);
  void submit(JSONArray a){rows=a==null?new JSONArray():a;int count=rows.length();cols=tvCatalogColumnsForCount(count);int sideW=tvCatalogSideWidthPx();int available=Math.max(dp(480),getResources().getDisplayMetrics().widthPixels-sideW-dp(34));cardW=Math.max(dp(132),(available-gap*(cols-1))/Math.max(1,cols));imgH=(int)(cardW*1.40f);if(tvCatalogRecycler!=null&&tvCatalogRecycler.getLayoutManager() instanceof androidx.recyclerview.widget.GridLayoutManager)((androidx.recyclerview.widget.GridLayoutManager)tvCatalogRecycler.getLayoutManager()).setSpanCount(cols);notifyDataSetChanged();}
  public int getItemCount(){return rows==null?0:rows.length();}
  public TvCatalogHolder onCreateViewHolder(ViewGroup parent,int viewType){LinearLayout card=new LinearLayout(MainActivity.this);card.setOrientation(LinearLayout.VERTICAL);card.setFocusable(true);card.setFocusableInTouchMode(false);card.setPadding(dp(2),dp(2),dp(2),dp(2));ImageView im=new ImageView(MainActivity.this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);im.setBackground(round(0xff1b1116,12));im.setClipToOutline(true);card.addView(im,new LinearLayout.LayoutParams(-1,dp(210)));TextView nm=t("",12);nm.setMaxLines(2);nm.setEllipsize(android.text.TextUtils.TruncateAt.END);nm.setPadding(dp(3),dp(5),dp(3),0);card.addView(nm,new LinearLayout.LayoutParams(-1,dp(38)));armTvFocus(card);return new TvCatalogHolder(card,im,nm);}
  public void onBindViewHolder(TvCatalogHolder h,int position){JSONObject x=rows.optJSONObject(position);if(x==null)return;RecyclerView.LayoutParamsHack.apply(h.card,imgH+dp(43),gap,position,cols);LinearLayout.LayoutParams ip=(LinearLayout.LayoutParams)h.image.getLayoutParams();ip.height=imgH;h.image.setLayoutParams(ip);h.image.setImageDrawable(null);Img.loadCatalogBest(h.image,x.optString("thumbnail",""),x.optString("portrait_img",""),x.optString("image",""),x.optString("landscape",""),x.optString("landscape_img",""));h.name.setText(x.optString("name",x.optString("title","")));h.card.setOnClickListener(v->details(x));}
  public void onViewRecycled(TvCatalogHolder h){super.onViewRecycled(h);try{h.image.setImageDrawable(null);}catch(Exception ignored){}}
 }
 static class RecyclerView{static class LayoutParamsHack{static void apply(View v,int height,int gap,int position,int cols){androidx.recyclerview.widget.RecyclerView.LayoutParams lp=v.getLayoutParams() instanceof androidx.recyclerview.widget.RecyclerView.LayoutParams?(androidx.recyclerview.widget.RecyclerView.LayoutParams)v.getLayoutParams():new androidx.recyclerview.widget.RecyclerView.LayoutParams(-1,height);lp.width=-1;lp.height=height;lp.setMargins(0,0,(position%Math.max(1,cols)==Math.max(1,cols)-1)?0:gap,14);v.setLayoutParams(lp);}}}
 void showTvCatalogRowsRv(JSONArray rows,androidx.recyclerview.widget.RecyclerView recycler){if(recycler==null||tvCatalogAdapter==null)return;tvCatalogState.setVisibility(View.GONE);recycler.setVisibility(View.VISIBLE);tvCatalogRows=rows==null?new JSONArray():rows;tvCatalogAdapter.submit(tvCatalogRows);}
 void showTvCatalogStateRv(String msg){if(tvCatalogRecycler!=null)tvCatalogRecycler.setVisibility(View.GONE);if(tvCatalogState!=null){tvCatalogState.setText(msg);tvCatalogState.setVisibility(View.VISIBLE);}}
 void loadTvBrowserCategoriesRv(int typeId,LinearLayout catHost,androidx.recyclerview.widget.RecyclerView recycler){JSONArray cached=filterAdultCategories(cachedTvCatalogCategories(typeId));if(cached!=null&&cached.length()>0){catHost.removeAllViews();renderTvBrowserCategoryListRv(ensureGenericTvCatalogCategory(cached,typeId),typeId,catHost,recycler,false);return;}catHost.removeAllViews();TextView wait=t("Carregando categorias...",13);wait.setTextColor(0xffa0969d);wait.setGravity(Gravity.CENTER);catHost.addView(wait,new LinearLayout.LayoutParams(-1,dp(54)));String type=typeId==2?"series":"movie";Api.post("get_category",Api.m("type",type,"user_id",uid),new Api.CB(){public void ok(JSONObject j){JSONArray a=filterAdultCategories(j.optJSONArray("result"));catHost.removeAllViews();if(a==null||a.length()==0){catHost.addView(t("Nenhuma categoria disponível",14));return;}renderTvBrowserCategoryListRv(ensureGenericTvCatalogCategory(a,typeId),typeId,catHost,recycler,false);}public void err(String e){catHost.removeAllViews();catHost.addView(t("Não foi possível carregar categorias",14));}});}
 void loadTvKidsBrowserCategoriesRv(LinearLayout catHost,androidx.recyclerview.widget.RecyclerView recycler){catHost.removeAllViews();TextView wait=t("Carregando categorias...",13);wait.setTextColor(0xffa0969d);wait.setGravity(Gravity.CENTER);catHost.addView(wait,new LinearLayout.LayoutParams(-1,dp(54)));JSONArray combined=new JSONArray();int[] done={0};Runnable finish=()->{done[0]++;if(done[0]<2)return;catHost.removeAllViews();if(combined.length()==0){catHost.addView(t("Nenhuma categoria Kids encontrada",14));return;}renderTvBrowserCategoryListRv(combined,1,catHost,recycler,true);};for(int tid:new int[]{1,2}){String type=tid==2?"series":"movie";final int ftype=tid;Api.post("get_category",Api.m("type",type,"user_id",uid),new Api.CB(){public void ok(JSONObject j){JSONArray a=j.optJSONArray("result");if(a!=null)for(int i=0;i<a.length();i++){JSONObject c=a.optJSONObject(i);if(c==null)continue;String nm=cleanCategoryDisplayTitle(c.optString("category_name",c.optString("name","")),ftype);if(!tvKidsCategoryName(nm))continue;try{JSONObject copy=new JSONObject(c.toString());copy.put("_tv_type",ftype);combined.put(copy);}catch(Exception ignored){}}finish.run();}public void err(String e){finish.run();}});}}
 void renderTvBrowserCategoryListRv(JSONArray a,int defaultType,LinearLayout catHost,androidx.recyclerview.widget.RecyclerView recycler,boolean mixed){a=filterAdultCategories(a);java.util.ArrayList<TextView> chips=new java.util.ArrayList<>();for(int i=0;i<a.length();i++){JSONObject c=a.optJSONObject(i);if(c==null)continue;String id=c.optString("category_id",c.optString("id",""));if(id.isEmpty())continue;int typeId=mixed?c.optInt("_tv_type",defaultType):defaultType;String name=cleanCategoryDisplayTitle(c.optString("category_name",c.optString("name","Categoria")),typeId);String label=categoryNameWithCount(name,c);TextView chip=t(label,13);chip.setGravity(Gravity.CENTER_VERTICAL);chip.setPadding(dp(12),0,dp(7),0);chip.setSingleLine(true);chip.setEllipsize(android.text.TextUtils.TruncateAt.END);chip.setTag(typeId+"|"+id);GradientDrawable g=round(i==0?0xff46162e:0xff170a10,12);g.setStroke(dp(i==0?2:1),i==0?GREEN:0xff4a2839);chip.setBackground(g);chip.setTextColor(i==0?GREEN:0xffe8dae3);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(46));lp.setMargins(0,0,0,dp(6));catHost.addView(chip,lp);chips.add(chip);final int pos=chips.size()-1;chip.setOnClickListener(v->{for(int k=0;k<chips.size();k++){TextView cc=chips.get(k);boolean on=k==pos;GradientDrawable gg=round(on?0xff46162e:0xff170a10,14);gg.setStroke(dp(on?2:1),on?GREEN:0xff4a2839);cc.setBackground(gg);cc.setTextColor(on?GREEN:0xffe8dae3);}String[] parts=String.valueOf(v.getTag()).split("\\|");if(parts.length==2){try{loadTvBrowserGridRv(Integer.parseInt(parts[0]),parts[1],recycler);}catch(Exception ignored){}}});armTvFocus(chip);if(pos>0)linkTvVertical(chips.get(pos-1),chip);if(pos==0){loadTvBrowserGridRv(typeId,id,recycler);requestTvFocus(chip);}}}
 boolean categorySectionActuallyComplete(JSONObject sec){if(sec==null)return false;JSONArray d=sec.optJSONArray("data");int have=d==null?0:d.length();int total=categoryKnownTotal(sec);return total>0&&have>=total;}
 boolean cachedTvBrowserCategoryComplete(int typeId,String categoryId){JSONObject cache=readHomeCache();JSONArray secs=cache==null?null:cache.optJSONArray("result");if(secs==null)return false;for(int i=0;i<secs.length();i++){JSONObject sec=secs.optJSONObject(i);if(sec==null)continue;int t=sec.optInt("type_id",sec.optInt("video_type",1));if(t==typeId&&categoryId.equals(sec.optString("category_id","")))return categorySectionActuallyComplete(sec);}return false;}
 void loadTvBrowserGridRv(int typeId,String categoryId,androidx.recyclerview.widget.RecyclerView recycler){if(recycler==null)return;final int request=++tvBrowserGridGeneration;try{Img.cancelCatalogLoads();}catch(Exception ignored){}try{recycler.scrollToPosition(0);}catch(Exception ignored){}tvCatalogRows=new JSONArray();if("__all__".equals(categoryId)){JSONArray all=aggregateCachedTypeItems(typeId);if(all.length()==0){showTvCatalogStateRv("Nenhum conteúdo disponível");return;}showTvCatalogRowsRv(all,recycler);return;}JSONArray cached=cachedTvBrowserCategory(typeId,categoryId);if(cached!=null&&cached.length()>0){showTvCatalogRowsRv(cached,recycler);if(cachedTvBrowserCategoryComplete(typeId,categoryId))return;}else showTvCatalogStateRv("Carregando conteúdo…");fetchAllCategoryPagesCancelable(typeId,categoryId,request,new AllPagesCB(){public void ok(JSONArray a){if(request!=tvBrowserGridGeneration||recycler.getParent()==null)return;if(a==null||a.length()==0){if(cached==null||cached.length()==0)showTvCatalogStateRv("Nenhum conteúdo nesta categoria");return;}showTvCatalogRowsRv(mergeCategoryRows(cached,a),recycler);}public void err(String e){if(request!=tvBrowserGridGeneration||recycler.getParent()==null)return;if(cached==null||cached.length()==0)showTvCatalogStateRv("Não foi possível carregar. Tente novamente.");}});}
 int categoryKnownTotal(JSONObject c){if(c==null)return 0;String[] keys={"category_total","total_rows","total","total_count","recordsTotal","records_total","count","content_count","items_count","movie_count","movies_count","series_count"};for(String k:keys){int n=jsonPositiveInt(c,k);if(n>0)return n;}return 0;}
 String categoryCountText(int n){if(n<=0)return "";try{return java.text.NumberFormat.getIntegerInstance(new java.util.Locale("pt","BR")).format(n);}catch(Exception e){return String.valueOf(n);}}
 String categoryNameWithCount(String name,JSONObject c){int n=categoryKnownTotal(c);return n>0?name+"  ·  "+categoryCountText(n):name;}
 boolean tvKidsCategoryName(String raw){String n=tvNormalizeMatch(raw);return n.contains("kids")||n.contains("infantil")||n.contains("crianc")||n.contains("animacao")||n.contains("animation")||n.contains("familia")||n.contains("family");}
 boolean genericCatalogCategoryName(String raw,int typeId){String n=tvNormalizeMatch(fixTitle(raw)).replace(" ","");if(typeId==2)return n.equals("series")||n.equals("serie")||n.equals("seriados")||n.equals("tvseries");return n.equals("filmes")||n.equals("filme")||n.equals("movies")||n.equals("movie");}
 JSONArray cachedTvCatalogCategories(int typeId){
  JSONArray out=new JSONArray();JSONObject cache=readHomeCache();JSONArray secs=cache==null?null:cache.optJSONArray("result");if(secs==null)return out;java.util.HashSet<String> ids=new java.util.HashSet<>();
  for(int i=0;i<secs.length();i++){JSONObject sec=secs.optJSONObject(i);if(sec==null||adultSectionBlocked(sec)||"recently_added".equals(sec.optString("section_key","")))continue;int t=sec.optInt("type_id",sec.optInt("video_type",1));if(t!=typeId)continue;String id=sec.optString("category_id","");String name=cleanCategoryDisplayTitle(sec.optString("title",typeId==2?"Séries":"Filmes"),typeId);String nk=tvNormalizeMatch(name);String key=!id.isEmpty()?id:(nk+"|"+i);if(key.isEmpty()||!ids.add(key))continue;JSONObject c=new JSONObject();try{c.put("category_id",id.isEmpty()?"__cached_"+i:id);c.put("category_name",name);c.put("_tv_type",typeId);int total=categoryKnownTotal(sec);if(total>0)c.put("category_total",total);}catch(Exception ignored){}out.put(c);}
  return out;
 }
 JSONArray ensureGenericTvCatalogCategory(JSONArray src,int typeId){
  JSONArray out=new JSONArray();boolean has=false;if(src!=null)for(int i=0;i<src.length();i++){JSONObject c=src.optJSONObject(i);if(c==null)continue;String n=c.optString("category_name",c.optString("name",""));if(genericCatalogCategoryName(n,typeId))has=true;}
  if(!has){JSONObject all=new JSONObject();try{all.put("category_id","__all__");all.put("category_name",typeId==2?"Séries":"Filmes");all.put("_tv_type",typeId);all.put("_virtual_all",1);}catch(Exception ignored){}out.put(all);}
  if(src!=null)for(int i=0;i<src.length();i++){JSONObject c=src.optJSONObject(i);if(c!=null)out.put(c);}return out;
 }
 JSONArray aggregateCachedTypeItems(int typeId){
  JSONArray out=new JSONArray();JSONObject cache=readHomeCache();JSONArray secs=cache==null?null:cache.optJSONArray("result");if(secs==null)return out;java.util.HashSet<String> seen=new java.util.HashSet<>();
  for(int i=0;i<secs.length();i++){JSONObject sec=secs.optJSONObject(i);if(sec==null||adultSectionBlocked(sec)||"recently_added".equals(sec.optString("section_key","")))continue;int t=sec.optInt("type_id",sec.optInt("video_type",1));if(t!=typeId)continue;JSONArray d=sec.optJSONArray("data");if(d==null)continue;for(int k=0;k<d.length();k++){JSONObject x=d.optJSONObject(k);if(x==null)continue;String key=itemKey(x);if(key==null||key.trim().isEmpty())key=x.optString("id",x.optString("video_id",x.optString("name","")));if(seen.add(key))out.put(x);}}
  return out;
 }
 void loadTvBrowserCategories(int typeId,LinearLayout catHost,GridLayout grid){
  // 5.28.13: categorias da fonte já estão no snapshot. Mostra instantaneamente e
  // não repete get_category toda vez que Filmes/Séries é aberto.
  JSONArray cached=filterAdultCategories(cachedTvCatalogCategories(typeId));
  if(cached!=null&&cached.length()>0){catHost.removeAllViews();renderTvBrowserCategoryList(ensureGenericTvCatalogCategory(cached,typeId),typeId,catHost,grid,false);return;}
  catHost.removeAllViews();TextView wait=t("Carregando categorias...",13);wait.setTextColor(0xffa0969d);wait.setGravity(Gravity.CENTER);catHost.addView(wait,new LinearLayout.LayoutParams(-1,dp(54)));String type=typeId==2?"series":"movie";
  Api.post("get_category",Api.m("type",type,"user_id",uid),new Api.CB(){public void ok(JSONObject j){JSONArray a=filterAdultCategories(j.optJSONArray("result"));catHost.removeAllViews();if(a==null||a.length()==0){catHost.addView(t("Nenhuma categoria disponível",14));return;}renderTvBrowserCategoryList(ensureGenericTvCatalogCategory(a,typeId),typeId,catHost,grid,false);}public void err(String e){catHost.removeAllViews();catHost.addView(t("Não foi possível carregar categorias",14));}});
 }
 void loadTvKidsBrowserCategories(LinearLayout catHost,GridLayout grid){
  catHost.removeAllViews();TextView wait=t("Carregando categorias...",13);wait.setTextColor(0xffa0969d);wait.setGravity(Gravity.CENTER);catHost.addView(wait,new LinearLayout.LayoutParams(-1,dp(54)));JSONArray combined=new JSONArray();int[] done={0};Runnable finish=()->{done[0]++;if(done[0]<2)return;catHost.removeAllViews();if(combined.length()==0){catHost.addView(t("Nenhuma categoria Kids encontrada",14));return;}renderTvBrowserCategoryList(combined,1,catHost,grid,true);};
  for(int tid:new int[]{1,2}){String type=tid==2?"series":"movie";final int ftype=tid;Api.post("get_category",Api.m("type",type,"user_id",uid),new Api.CB(){public void ok(JSONObject j){JSONArray a=j.optJSONArray("result");if(a!=null)for(int i=0;i<a.length();i++){JSONObject c=a.optJSONObject(i);if(c==null)continue;String nm=cleanCategoryDisplayTitle(c.optString("category_name",c.optString("name","")),ftype);if(!tvKidsCategoryName(nm))continue;try{JSONObject copy=new JSONObject(c.toString());copy.put("_tv_type",ftype);combined.put(copy);}catch(Exception ignored){}}finish.run();}public void err(String e){finish.run();}});}
 }
 void renderTvBrowserCategoryList(JSONArray a,int defaultType,LinearLayout catHost,GridLayout grid,boolean mixed){a=filterAdultCategories(a);
  java.util.ArrayList<TextView> chips=new java.util.ArrayList<>();for(int i=0;i<a.length();i++){JSONObject c=a.optJSONObject(i);if(c==null)continue;String id=c.optString("category_id",c.optString("id",""));if(id.isEmpty())continue;int typeId=mixed?c.optInt("_tv_type",defaultType):defaultType;String name=cleanCategoryDisplayTitle(c.optString("category_name",c.optString("name","Categoria")),typeId);String label=categoryNameWithCount(name,c);TextView chip=t(label,13);chip.setGravity(Gravity.CENTER_VERTICAL);chip.setPadding(dp(12),0,dp(7),0);chip.setSingleLine(true);chip.setEllipsize(android.text.TextUtils.TruncateAt.END);chip.setTag(typeId+"|"+id);GradientDrawable g=round(i==0?0xff46162e:0xff170a10,12);g.setStroke(dp(i==0?2:1),i==0?GREEN:0xff4a2839);chip.setBackground(g);chip.setTextColor(i==0?GREEN:0xffe8dae3);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(46));lp.setMargins(0,0,0,dp(6));catHost.addView(chip,lp);chips.add(chip);final int pos=chips.size()-1;chip.setOnClickListener(v->{for(int k=0;k<chips.size();k++){TextView cc=chips.get(k);boolean on=k==pos;GradientDrawable gg=round(on?0xff46162e:0xff170a10,14);gg.setStroke(dp(on?2:1),on?GREEN:0xff4a2839);cc.setBackground(gg);cc.setTextColor(on?GREEN:0xffe8dae3);}String[] parts=String.valueOf(v.getTag()).split("\\|");if(parts.length==2){try{loadTvBrowserGrid(Integer.parseInt(parts[0]),parts[1],grid);}catch(Exception ignored){}}});armTvFocus(chip);if(pos>0)linkTvVertical(chips.get(pos-1),chip);if(pos==0){loadTvBrowserGrid(typeId,id,grid);requestTvFocus(chip);}}
 }
 JSONArray cachedTvBrowserCategory(int typeId,String categoryId){
  JSONObject cache=readHomeCache();JSONArray secs=cache==null?null:cache.optJSONArray("result");if(secs==null)return null;for(int i=0;i<secs.length();i++){JSONObject sec=secs.optJSONObject(i);if(sec==null)continue;int t=sec.optInt("type_id",sec.optInt("video_type",1));String cid=sec.optString("category_id","");if(t==typeId&&categoryId.equals(cid)){JSONArray d=sec.optJSONArray("data");if(d!=null&&d.length()>0)return d;}}return null;
 }
 
 void loadTvBrowserGrid(int typeId,String categoryId,GridLayout grid){
  if(grid==null)return;final int request=++tvBrowserGridGeneration;try{Img.cancelCatalogLoads();}catch(Exception ignored){}tvCatalogChunkPending=false;tvCatalogRows=new JSONArray();tvCatalogNextIndex=0;if(tvCatalogGridScroll!=null){try{tvCatalogGridScroll.scrollTo(0,0);}catch(Exception ignored){}}
  if("__all__".equals(categoryId)){JSONArray all=aggregateCachedTypeItems(typeId);grid.removeAllViews();if(all.length()==0){TextView empty=t("Nenhum conteúdo disponível",14);empty.setTextColor(0xffa0969d);grid.addView(empty);return;}renderTvBrowserGrid(all,grid);return;}
  JSONArray cached=cachedTvBrowserCategory(typeId,categoryId);JSONObject homeCache=readHomeCache();boolean snapshotComplete=homeCache!=null&&homeCache.optInt("catalog_complete",0)==1;
  if(cached!=null&&cached.length()>0){grid.removeAllViews();renderTvBrowserGrid(cached,grid);prefetchTvBrowserFirstImages(cached,()->{});if(snapshotComplete)return;}
  else{grid.removeAllViews();TextView wait=t("Carregando conteúdo…",13);wait.setTextColor(0xffa0969d);wait.setGravity(Gravity.CENTER);GridLayout.LayoutParams wp=new GridLayout.LayoutParams();wp.width=dp(220);wp.height=dp(70);grid.addView(wait,wp);}
  fetchAllCategoryPagesCancelable(typeId,categoryId,request,new AllPagesCB(){public void ok(JSONArray a){if(request!=tvBrowserGridGeneration||grid.getParent()==null)return;if(a==null||a.length()==0){if(cached==null||cached.length()==0){grid.removeAllViews();TextView empty=t("Nenhum conteúdo nesta categoria",14);empty.setTextColor(0xffa0969d);GridLayout.LayoutParams ep=new GridLayout.LayoutParams();ep.width=dp(260);ep.height=dp(70);grid.addView(empty,ep);}return;}grid.removeAllViews();renderTvBrowserGrid(a,grid);prefetchTvBrowserFirstImages(a,()->{});}public void err(String e){if(request!=tvBrowserGridGeneration||grid.getParent()==null)return;if(cached==null||cached.length()==0){grid.removeAllViews();TextView er=t("Não foi possível carregar. Tente novamente.",13);er.setTextColor(0xffa0969d);grid.addView(er);}}});
 }
 int categoryResponseTotal(JSONObject j){if(j==null)return 0;String[] keys={"total_rows","total_count","recordsTotal","records_total","total"};for(String k:keys){int n=jsonPositiveInt(j,k);if(n>0)return n;}JSONObject p=j.optJSONObject("pagination");if(p!=null){int n=jsonPositiveInt(p,"total_rows","total_count","recordsTotal","records_total","total");if(n>0)return n;}JSONObject d=j.optJSONObject("data");if(d!=null){int n=jsonPositiveInt(d,"total_rows","total_count","recordsTotal","records_total","total");if(n>0)return n;}return 0;}
 int categoryPageSize(){return 120;}
 Map<String,String> categoryPageArgs(int typeId,String categoryId,int page,int offset){String contentType=typeId==2?"series":"movie";String size=String.valueOf(categoryPageSize()),off=String.valueOf(Math.max(0,offset));return Api.m("user_id",uid,"type",contentType,"category_id",categoryId,"page_no",String.valueOf(page),"page",String.valueOf(page),"current_page",String.valueOf(page),"page_index",String.valueOf(Math.max(0,page-1)),"offset",off,"start",off,"skip",off,"from",off,"start_index",off,"length",size,"limit",size,"per_page",size,"page_size",size,"full_catalog","0","all","1");}
 void fetchAllCategoryPagesCancelable(int typeId,String categoryId,int request,AllPagesCB cb){
  String cid=categoryId==null?"":categoryId.trim();if(cid.isEmpty()){cb.err("Categoria inválida");return;}fetchAllCategoryPagesRawCancelable(typeId,cid,1,new JSONArray(),new java.util.HashSet<String>(),request,cb);
 }
 void fetchAllCategoryPagesRawCancelable(int typeId,String raw,int page,JSONArray acc,java.util.HashSet<String> seen,int request,AllPagesCB cb){
  if(request!=tvBrowserGridGeneration)return;if(page>500){cb.ok(acc);return;}Api.post("content_by_category",categoryPageArgs(typeId,raw,page,(page-1)*categoryPageSize()),new Api.CB(){public void ok(JSONObject j){
   if(request!=tvBrowserGridGeneration)return;if(j.optInt("status",200)!=200){cb.err(j.optString("message","Resposta inválida"));return;}
   JSONArray rows=j.optJSONArray("result");int total=categoryResponseTotal(j);if(rows==null||rows.length()==0){if(total>0&&acc.length()<total){cb.err("Catálogo incompleto");return;}cb.ok(acc);return;}int added=0;for(int i=0;i<rows.length();i++){JSONObject x=rows.optJSONObject(i);if(x==null)continue;String key=itemKey(x);if(key==null||key.trim().isEmpty())key=x.optString("id",x.optString("video_id",x.optString("name","")))+"|"+x.optString("stream_url",x.optString("url",""));if(seen.add(key)){acc.put(x);added++;}}if(total>0&&acc.length()>=total){cb.ok(acc);return;}if(added==0){if(total>0&&acc.length()<total){cb.err("Catálogo incompleto");return;}cb.ok(acc);return;}cb.ok(acc);if(request!=tvBrowserGridGeneration)return;fetchAllCategoryPagesRawCancelable(typeId,raw,page+1,acc,seen,request,cb);
  }public void err(String e){if(request!=tvBrowserGridGeneration)return;cb.err(e);}});
 }
 void fetchAllCategoryPages(int typeId,String categoryId,AllPagesCB cb){
  String cid=categoryId==null?"":categoryId.trim();if(cid.isEmpty()){cb.err("Categoria inválida");return;}fetchAllCategoryPagesRaw(typeId,cid,1,new JSONArray(),new java.util.HashSet<String>(),cb);
 }
 void fetchAllCategoryPagesRaw(int typeId,String raw,int page,JSONArray acc,java.util.HashSet<String> seen,AllPagesCB cb){
  if(page>500){cb.ok(acc);return;}Api.post("content_by_category",categoryPageArgs(typeId,raw,page,(page-1)*categoryPageSize()),new Api.CB(){public void ok(JSONObject j){
   if(j.optInt("status",200)!=200){cb.err(j.optString("message","Resposta inválida"));return;}
   JSONArray rows=j.optJSONArray("result");int total=categoryResponseTotal(j);if(rows==null||rows.length()==0){if(total>0&&acc.length()<total){cb.err("Catálogo incompleto");return;}cb.ok(acc);return;}int added=0;
   for(int i=0;i<rows.length();i++){JSONObject x=rows.optJSONObject(i);if(x==null)continue;String key=itemKey(x);if(key==null||key.trim().isEmpty())key=x.optString("id",x.optString("video_id",x.optString("name","")))+"|"+x.optString("stream_url",x.optString("url",""));if(seen.add(key)){acc.put(x);added++;}}
   if(total>0&&acc.length()>=total){cb.ok(acc);return;}if(added==0){if(total>0&&acc.length()<total){cb.err("Catálogo incompleto");return;}cb.ok(acc);return;}fetchAllCategoryPagesRaw(typeId,raw,page+1,acc,seen,cb);
  }public void err(String e){cb.err(e);}});
 }
 void storeFullCategoryInHomeCache(int typeId,String categoryId,JSONArray rows){/* 5.28.37: intencionalmente vazio. A Home guarda apenas previews; categorias completas vivem somente na tela aberta. */}
 void prefetchTvBrowserFirstImages(JSONArray a,Runnable done){
  // 5.3: não cria uma segunda fila de capas para o catálogo de TV. Os cards visíveis
  // já usam Img.loadCatalogBest(), com fila própria e bitmap reduzido. Prefetch genérico
  // aqui duplicava download/decodificação e era uma das causas de memória alta.
  if(done!=null)done.run();
 }
 void renderTvBrowserGrid(JSONArray a,GridLayout grid){
  int count=a==null?0:a.length();if(count<=0)return;int cols=tvCatalogColumnsForCount(count);grid.setColumnCount(cols);grid.setTag(Integer.valueOf(cols));int sideW=tvCatalogSideWidthPx();int measured=grid.getWidth()>dp(300)?grid.getWidth():getResources().getDisplayMetrics().widthPixels-sideW;int available=Math.max(dp(480),measured-grid.getPaddingLeft()-grid.getPaddingRight()-dp(4));int gap=dp(9);int cardW=Math.max(dp(132),(available-gap*(cols-1))/Math.max(1,cols));int imgH=(int)(cardW*1.40f);final int request=tvBrowserGridGeneration;tvCatalogRows=a;tvCatalogGrid=grid;tvCatalogCols=cols;tvCatalogCardW=cardW;tvCatalogImgH=imgH;tvCatalogGap=gap;tvCatalogNextIndex=0;tvCatalogRenderRequest=request;tvCatalogChunkPending=false;addTvBrowserGridChunk(a,grid,0,cols,cardW,imgH,gap,request);
 }
 void addTvBrowserGridChunk(JSONArray a,GridLayout grid,int start,int cols,int cardW,int imgH,int gap,int request){
  if(request!=tvBrowserGridGeneration||grid==null||grid.getParent()==null||a==null)return;int end=Math.min(a.length(),start+24);View previous=grid.getChildCount()>0?grid.getChildAt(grid.getChildCount()-1):null;
  for(int i=start;i<end;i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setFocusable(true);card.setPadding(dp(2),dp(2),dp(2),dp(2));ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);im.setBackground(round(0xff1b1116,12));im.setClipToOutline(true);Img.loadCatalogBest(im,x.optString("thumbnail",""),x.optString("portrait_img",""),x.optString("image",""),x.optString("landscape",""),x.optString("landscape_img",""));card.addView(im,new LinearLayout.LayoutParams(-1,imgH));TextView nm=t(x.optString("name",x.optString("title","")),12);nm.setMaxLines(2);nm.setEllipsize(android.text.TextUtils.TruncateAt.END);nm.setPadding(dp(3),dp(5),dp(3),0);card.addView(nm,new LinearLayout.LayoutParams(-1,dp(38)));card.setOnClickListener(v->details(x));armTvFocus(card);GridLayout.LayoutParams cp=new GridLayout.LayoutParams();cp.width=cardW;cp.height=imgH+dp(43);cp.setMargins(0,0,(i%cols==cols-1)?0:gap,dp(14));grid.addView(card,cp);if(previous!=null&&i%cols!=0)linkTvHorizontal(previous,card);previous=card;}
  tvCatalogNextIndex=end;tvCatalogChunkPending=false;if(end<a.length()&&tvCatalogGridScroll!=null)tvCatalogGridScroll.postDelayed(()->maybeLoadMoreTvCatalog(),40);
 }
 void maybeLoadMoreTvCatalog(){
  if(tvCatalogChunkPending||tvCatalogGridScroll==null||tvCatalogGrid==null||tvCatalogRows==null||tvCatalogRows.length()==0||tvCatalogNextIndex>=tvCatalogRows.length()||tvCatalogRenderRequest!=tvBrowserGridGeneration)return;try{View child=tvCatalogGridScroll.getChildAt(0);if(child==null)return;int viewport=tvCatalogGridScroll.getHeight();if(viewport<=0){tvCatalogGridScroll.postDelayed(()->maybeLoadMoreTvCatalog(),60);return;}int bottom=tvCatalogGridScroll.getScrollY()+viewport;int remaining=child.getHeight()-bottom;if(remaining>Math.max(dp(180),viewport/2))return;tvCatalogChunkPending=true;final int start=tvCatalogNextIndex;tvCatalogGrid.postDelayed(()->{if(tvCatalogRenderRequest!=tvBrowserGridGeneration){tvCatalogChunkPending=false;return;}addTvBrowserGridChunk(tvCatalogRows,tvCatalogGrid,start,tvCatalogCols,tvCatalogCardW,tvCatalogImgH,tvCatalogGap,tvCatalogRenderRequest);},16);}catch(Exception ignored){tvCatalogChunkPending=false;}
 }
 void openTvKids(){JSONObject prepared=readHomeCache();JSONArray secs=prepared==null?null:prepared.optJSONArray("result");if(secs!=null){for(int i=0;i<secs.length();i++){JSONObject sec=secs.optJSONObject(i);if(sec==null)continue;String title=fixTitle(sec.optString("title","")).toLowerCase(java.util.Locale.ROOT);if(title.contains("kids")||title.contains("infantil")||title.contains("crianc")){homeSectionTab("Kids",sec);return;}}}homeTab("Recomendações");}
 void selectTvCategoryByHint(String hint){if(tvCategoryHost==null||hint==null||hint.trim().isEmpty())return;String h=tvNormalizeMatch(hint);for(int i=0;i<tvCategoryHost.getChildCount();i++){View c=tvCategoryHost.getChildAt(i);if(!(c instanceof TextView))continue;String n=tvNormalizeMatch(((TextView)c).getText().toString());if(n.contains(h)||(h.contains("futebol")&&(n.contains("esporte")||n.contains("sport")))){tvPendingCategoryHint="";requestTvFocus(c);c.performClick();return;}}}
 TextView tvUtilityAction(String glyph,String description,Runnable action){TextView v=t(glyph,22);v.setGravity(Gravity.CENTER);v.setTextColor(0xffddd0d9);v.setContentDescription(description);GradientDrawable g=round(0xff191014,22);g.setStroke(dp(1),0xff422c37);v.setBackground(g);v.setFocusable(true);v.setFocusableInTouchMode(false);v.setOnClickListener(x->{if(action!=null)action.run();});if(tvMode){tvFocusArmed.put(v,Boolean.TRUE);v.setOnFocusChangeListener((x,has)->{TextView n=(TextView)x;n.setTextColor(has?0xff10030a:0xffddd0d9);GradientDrawable b=round(has?GREEN:0xff191014,22);b.setStroke(dp(has?3:1),has?Color.WHITE:0xff422c37);n.setBackground(b);});}return v;}
 TextView tvNavAction(String title,Runnable action){TextView v=t(title,15);v.setSingleLine(true);v.setGravity(Gravity.CENTER);v.setPadding(dp(7),0,dp(7),0);v.setTextColor(0xffdacdd6);v.setTypeface(null,1);v.setBackgroundColor(Color.TRANSPARENT);v.setOnClickListener(x->{if(action!=null)action.run();});return v;}
 void tvNavigate(int idx){
  if(searchScreenOpen){searchScreenOpen=false;try{android.view.inputmethod.InputMethodManager im=(android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);View f=getCurrentFocus();if(im!=null&&f!=null)im.hideSoftInputFromWindow(f.getWindowToken(),0);}catch(Exception ignored){}}
  if(detailOpen){int previous=savedNavIndex;closeDetails();if(idx==previous&&idx!=0)return;}
  if(idx==0){goHomeNow();return;}
  if(idx==2){launchStories();return;}
  if(currentNavIndex==2&&tvPageRoot!=null&&idx!=2){releaseTvInlinePlayer();createTransientPageHost();}
  else if(currentNavIndex==0&&mainScroll==homeScrollCache)leaveHomeForPage();
  if(idx==1)favorites();else if(idx==3)downloads();else profile();
 }
 boolean shouldDefaultToTvLanding(){return false;}
 void keepTvHomeAnchored(){
  if(!tvMode||mainScroll==null||mainScroll!=homeScrollCache||detailOpen||currentNavIndex!=0)return;
  Runnable pin=()->{if(!tvMode||detailOpen||currentNavIndex!=0||mainScroll==null||mainScroll!=homeScrollCache)return;mainScroll.scrollTo(0,0);if(navHome!=null)requestTvFocus(navHome);};
  pin.run();
  if(mainScroll!=null)mainScroll.post(pin);
  new Handler(Looper.getMainLooper()).postDelayed(pin,220);
  new Handler(Looper.getMainLooper()).postDelayed(pin,700);
 }
 void syncTvHeader(String selected){
  if(!wideTvUi())return;TextView[] all={navShorts,navFav,navDownloads,navProfile};TextView active=null;if(currentNavIndex==1)active=navFav;else if(currentNavIndex==3)active=navDownloads;else if(currentNavIndex==4)active=navProfile;else active=navShorts;for(TextView v:all)if(v!=null)styleTvHeaderItem(v,v==active,v.hasFocus());
 }
 void cancelProviderSwitch(){
  // 5.28.34: abrir "Alterar servidor" e voltar sem escolher outro servidor
  // nao pode desmontar a Home que ja estava pronta. A tela de selecao chama
  // base(true), mas o host antigo da Home continua valido e deve ser preservado.
  final ScrollView keepHomeScroll=homeScrollCache;
  final LinearLayout keepHomeBody=homeBodyCache;
  final boolean keepHomeAvailable=homeViewAvailable&&keepHomeScroll!=null&&keepHomeBody!=null&&keepHomeBody.getChildCount()>0;
  final int keepHomeY=homeScrollY;
  final String keepHomeTab=homeCachedTab;
  providerSwitchScreen=false;
  requestedStartNav=4; // volta direto ao Perfil; nao recria uma Home parcial no caminho.
  shell();
  if(keepHomeAvailable){
   homeScrollCache=keepHomeScroll;homeBodyCache=keepHomeBody;homeViewAvailable=true;homeScrollY=keepHomeY;homeCachedTab=keepHomeTab;
  }
 }
 void bindScrollTopButton(ScrollView sv){
  if(wideTvUi()||contentFrame==null||sv==null){scrollTopHost=null;if(scrollTopButton!=null)scrollTopButton.setVisibility(View.GONE);return;}
  scrollTopHost=sv;
  if(scrollTopButton==null){
   TextView up=t("↑",25);up.setTextColor(GREEN);up.setGravity(Gravity.CENTER);up.setIncludeFontPadding(false);up.setPadding(0,0,0,dp(3));up.setContentDescription("Voltar ao topo");up.setFocusable(false);up.setClickable(true);
   GradientDrawable bg=new GradientDrawable();bg.setShape(GradientDrawable.OVAL);bg.setColor(0xee201018);bg.setStroke(dp(1),0xff723d58);up.setBackground(bg);if(android.os.Build.VERSION.SDK_INT>=21)up.setElevation(dp(8));
   up.setOnClickListener(v->{ScrollView target=scrollTopHost;if(target!=null){target.smoothScrollTo(0,0);target.postDelayed(()->{if(scrollTopHost==target&&scrollTopButton!=null)scrollTopButton.setVisibility(View.GONE);},280);}});
   scrollTopButton=up;FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(48),dp(48),Gravity.RIGHT|Gravity.BOTTOM);lp.setMargins(0,0,dp(12),dp(14));contentFrame.addView(up,lp);
  }else{
   ViewParent pp=scrollTopButton.getParent();if(pp instanceof ViewGroup&&pp!=contentFrame)((ViewGroup)pp).removeView(scrollTopButton);if(scrollTopButton.getParent()==null){FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(48),dp(48),Gravity.RIGHT|Gravity.BOTTOM);lp.setMargins(0,0,dp(12),dp(14));contentFrame.addView(scrollTopButton,lp);}
  }
  scrollTopButton.setVisibility(sv.getScrollY()>dp(360)?View.VISIBLE:View.GONE);scrollTopButton.bringToFront();
  if(sv.getTag(TAG_SCROLL_TOP_INSTALLED)==null){sv.setTag(TAG_SCROLL_TOP_INSTALLED,Boolean.TRUE);final java.lang.ref.WeakReference<ScrollView> wr=new java.lang.ref.WeakReference<>(sv);sv.getViewTreeObserver().addOnScrollChangedListener(()->{ScrollView x=wr.get();if(x==null||scrollTopButton==null||scrollTopHost!=x)return;scrollTopButton.setVisibility(x.getScrollY()>dp(360)?View.VISIBLE:View.GONE);if(scrollTopButton.getVisibility()==View.VISIBLE)scrollTopButton.bringToFront();});}
 }
 void hideScrollTopButton(){scrollTopHost=null;if(scrollTopButton!=null)scrollTopButton.setVisibility(View.GONE);}
 int bottomNavIconRes(int idx){if(idx==0)return R.drawable.ic_nav_home;if(idx==1)return R.drawable.ic_nav_favorite;if(idx==2)return R.drawable.ic_nav_stories;if(idx==3)return R.drawable.ic_nav_download;return R.drawable.ic_nav_profile;}
 void applyBottomNavIcon(TextView v,int idx,int color){if(v==null)return;try{Drawable d=getDrawable(bottomNavIconRes(idx));if(d!=null){d=d.mutate();d.setTint(color);int sz=dp(idx==2?21:20);d.setBounds(0,0,sz,sz);v.setCompoundDrawables(null,d,null,null);v.setCompoundDrawablePadding(dp(4));}}catch(Exception ignored){}}
 void enforceGlobalBottomNav(){if(wideTvUi()||navBar==null)return;if(root!=null&&!detailOpen&&!plansScreen&&!providerSwitchScreen&&!authScreen)standardRootInsets();navBar.setBackgroundColor(0xff201018);applyMobileBottomNavInsets(null);}
 TextView navItem(String icon,String title,int idx){TextView v=t(title,11);v.setGravity(Gravity.CENTER);v.setPadding(0,dp(4),0,dp(3));v.setSingleLine(true);v.setIncludeFontPadding(false);v.setContentDescription(title);v.setBackgroundColor(Color.TRANSPARENT);applyBottomNavIcon(v,idx,0xffc2b6be);v.setOnClickListener(x->{
  if(searchScreenOpen){searchScreenOpen=false;try{android.view.inputmethod.InputMethodManager im=(android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);View f=getCurrentFocus();if(im!=null&&f!=null)im.hideSoftInputFromWindow(f.getWindowToken(),0);}catch(Exception ignored){}}
  if(detailOpen){int previous=savedNavIndex;closeDetails();if(idx==previous&&idx!=0)return;}
  if(idx==0){goHomeNow();return;}
  if(idx==2){launchStories();return;}
  if(currentNavIndex==2&&tvPageRoot!=null&&idx!=2){releaseTvInlinePlayer();createTransientPageHost();}
  else if(currentNavIndex==0&&mainScroll==homeScrollCache)leaveHomeForPage();
  if(idx==1)favorites();else if(idx==3)downloads();else profile();
 });navBar.addView(v,new LinearLayout.LayoutParams(0,-1,1));return v;}

 void launchStories(){try{Intent in=new Intent(this,StoriesActivity.class);in.putExtra("user_id",uid);startActivity(in);}catch(Exception e){Toast.makeText(this,"Não foi possível abrir os Stories agora.",Toast.LENGTH_SHORT).show();}}
 void setNav(int idx){currentNavIndex=idx;if(navHome==null)return;if(wideTvUi()){syncTvHeader(activeHomeTab);updateGlobalCastButtonState();return;}enforceGlobalBottomNav();TextView[] n={navHome,navFav,navTv,navDownloads,navProfile};for(int i=0;i<n.length;i++)if(n[i]!=null){boolean active=i==idx;int color=active?GREEN:0xffc2b6be;n[i].setTextColor(color);n[i].setTypeface(null,active?android.graphics.Typeface.BOLD:android.graphics.Typeface.NORMAL);n[i].setBackgroundColor(Color.TRANSPARENT);applyBottomNavIcon(n[i],i,color);}updateGlobalCastButtonState();}
 void rememberHomeView(){if(mainScroll!=null&&body!=null&&currentNavIndex==0&&mainScroll==homeScrollCache&&!detailOpen){homeScrollY=mainScroll.getScrollY();homeBodyCache=body;homeViewAvailable=true;}}
 void createTransientPageHost(){if(contentFrame==null)return;standardRootInsets();if(tvPageRoot!=null&&tvPageRoot.getParent()==contentFrame)contentFrame.removeView(tvPageRoot);tvPageRoot=null;if(mainScroll!=null&&mainScroll.getParent()==contentFrame)contentFrame.removeView(mainScroll);mainScroll=new ScrollView(this);mainScroll.setFillViewport(true);mainScroll.setVerticalScrollBarEnabled(false);body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);int side=wideTvUi()?dp(28):dp(18);body.setPadding(side,wideTvUi()?dp(12):dp(2),side,wideTvUi()?dp(22):dp(10));mainScroll.addView(body);contentFrame.addView(mainScroll,new FrameLayout.LayoutParams(-1,-1));bindScrollTopButton(mainScroll);ensureGlobalCastButton();}
 void createTvPageHost(){if(contentFrame==null)return;rememberHomeView();if(mainScroll!=null&&mainScroll.getParent()==contentFrame)contentFrame.removeView(mainScroll);if(tvPageRoot!=null&&tvPageRoot.getParent()==contentFrame)contentFrame.removeView(tvPageRoot);mainScroll=null;hideScrollTopButton();tvPageRoot=new LinearLayout(this);tvPageRoot.setOrientation(LinearLayout.VERTICAL);tvPageRoot.setPadding(0,0,0,0);body=tvPageRoot;contentFrame.addView(tvPageRoot,new FrameLayout.LayoutParams(-1,-1));ensureGlobalCastButton();}
 void leaveHomeForPage(){rememberHomeView();createTransientPageHost();}
 void attachPermanentHomeHost(){
  if(contentFrame==null)return;if(tvPageRoot!=null&&tvPageRoot.getParent()==contentFrame)contentFrame.removeView(tvPageRoot);tvPageRoot=null;
  if(homeScrollCache==null||homeBodyCache==null){
   homeScrollCache=new ScrollView(this);homeScrollCache.setFillViewport(true);homeScrollCache.setVerticalScrollBarEnabled(false);
   homeBodyCache=new LinearLayout(this);homeBodyCache.setOrientation(LinearLayout.VERTICAL);int side=wideTvUi()?dp(28):dp(18);homeBodyCache.setPadding(side,wideTvUi()?dp(12):dp(2),side,wideTvUi()?dp(18):dp(10));homeScrollCache.addView(homeBodyCache);homeViewAvailable=true;homeScrollY=0;
  }
  if(mainScroll!=homeScrollCache||body!=homeBodyCache){
   if(mainScroll!=null&&mainScroll.getParent()==contentFrame)contentFrame.removeView(mainScroll);
   ViewParent hp=homeScrollCache.getParent();if(hp instanceof ViewGroup&&hp!=contentFrame)((ViewGroup)hp).removeView(homeScrollCache);
   mainScroll=homeScrollCache;body=homeBodyCache;
   if(homeScrollCache.getParent()==null)contentFrame.addView(homeScrollCache,new FrameLayout.LayoutParams(-1,-1));bindScrollTopButton(mainScroll);ensureGlobalCastButton();
  }else bindScrollTopButton(mainScroll);
 }
 void restoreHomeView(){
  if(homeScrollCache!=null&&homeBodyCache!=null&&contentFrame!=null&&homeBodyCache.getChildCount()==0){attachPermanentHomeHost();homeViewAvailable=true;homeScrollY=0;homeTab("Shorts");return;}
  if(homeViewAvailable&&homeScrollCache!=null&&homeBodyCache!=null&&contentFrame!=null){activeHomeTab="Shorts";homeCachedTab="Shorts";attachPermanentHomeHost();setNav(0);if(wideTvUi())syncTvHeader("Shorts");final int y=homeScrollY;mainScroll.setVisibility(View.VISIBLE);mainScroll.post(()->{mainScroll.scrollTo(0,y);mainScroll.requestLayout();});return;}
  attachPermanentHomeHost();home();
 }
 void discardSectionPageState(){
  sectionPageOpen=false;sectionParentScroll=null;sectionParentBody=null;sectionReturnTab="";sectionParentScrollY=0;sectionParentViewGen=0;
 }
 void beginSectionPage(String returnTab){
  if(sectionPageOpen)return;
  sectionPageOpen=true;sectionReturnTab=(returnTab==null||returnTab.trim().isEmpty())?"Shorts":returnTab;
  sectionParentScroll=mainScroll;sectionParentBody=body;sectionParentScrollY=mainScroll==null?0:mainScroll.getScrollY();sectionParentViewGen=viewGen;
  // A página da categoria recebe host próprio. A tela anterior permanece inteira
  // na memória, portanto Voltar não refaz categorias, capas nem posição.
  createTransientPageHost();
 }
 void closeSectionPage(){
  if(!sectionPageOpen)return;
  ScrollView parentScroll=sectionParentScroll;LinearLayout parentBody=sectionParentBody;String returnTab=sectionReturnTab;int returnY=sectionParentScrollY;int returnGen=sectionParentViewGen;
  sectionPageOpen=false;sectionParentScroll=null;sectionParentBody=null;sectionReturnTab="";sectionParentScrollY=0;sectionParentViewGen=0;
  viewGen=returnGen;cancelTvCatalogWork();releaseTvInlinePlayer();
  if(contentFrame!=null&&mainScroll!=null&&mainScroll.getParent()==contentFrame){try{contentFrame.removeView(mainScroll);}catch(Exception ignored){}}
  if(parentScroll!=null&&parentBody!=null&&contentFrame!=null){
   mainScroll=parentScroll;body=parentBody;ViewParent pp=parentScroll.getParent();if(pp instanceof ViewGroup&&pp!=contentFrame)((ViewGroup)pp).removeView(parentScroll);if(parentScroll.getParent()==null)contentFrame.addView(parentScroll,new FrameLayout.LayoutParams(-1,-1));bindScrollTopButton(parentScroll);
   activeHomeTab=(returnTab==null||returnTab.isEmpty())?"Shorts":returnTab;setNav(0);if(wideTvUi())syncTvHeader(activeHomeTab);parentScroll.setVisibility(View.VISIBLE);final int y=Math.max(0,returnY);parentScroll.post(()->{parentScroll.scrollTo(0,y);parentScroll.requestLayout();});ensureGlobalCastButton();return;
  }
  activeHomeTab=(returnTab==null||returnTab.isEmpty())?"Shorts":returnTab;
  if("Shorts".equals(activeHomeTab))restoreHomeView();else homeTab(activeHomeTab);
 }
 void goHomeNow(){
  discardSectionPageState();releaseTvInlinePlayer();standardRootInsets();plansScreen=false;planFlowStage=0;providerSwitchScreen=false;searchScreenOpen=false;
  if(pixTimer!=null){try{pixTimer.cancel();}catch(Exception ignored){}pixTimer=null;}
  if(accessExpiredOverlay!=null)dismissAccessExpiredOverlay();if(detailOpen)closeDetails();if(navBar!=null)navBar.setVisibility(View.VISIBLE);
  if(contentFrame==null){shell();return;}homeScrollY=0;
  if(!"Shorts".equals(activeHomeTab))homeTab("Shorts");else{restoreHomeView();if(mainScroll!=null){mainScroll.scrollTo(0,0);mainScroll.post(()->{if(mainScroll==homeScrollCache)mainScroll.scrollTo(0,0);});}if(tvMode)keepTvHomeAnchored();}
 }
  void clear(){viewGen++;cancelTvCatalogWork();releaseTvInlinePlayer();try{if(mainScroll!=null)mainScroll.setOnScrollChangeListener((View.OnScrollChangeListener)null);}catch(Exception ignored){}mobileCategoryGrid=null;mobileCategoryRows=new JSONArray();mobileCategoryNextIndex=0;mobileCategoryChunkPending=false;mobileCategoryTypeId=0;mobileCategoryNextPageNo=1;mobileCategoryNetworkTotal=0;mobileCategoryNetworkRetries=0;mobileCategoryId="";mobileCategoryNetworkBusy=false;mobileCategoryNetworkDone=false;mobileCategoryGreenShorts=false;mobileCategorySeen.clear();mobileCategoryLoadingFooter=null;mobileCategoryLoadingText=null;mobileCategoryLoadingProgress=null;tvShortsGrid=null;tvShortsCardW=0;tvShortsGridGen=0;if(body!=null){body.removeAllViews();/* v5.2: nunca herdar a largura da tela anterior. A Home/Destaque usa sempre o mesmo inset TV; páginas especiais aplicam o próprio inset depois de clear(). */int side=wideTvUi()?dp(28):dp(18);body.setPadding(side,wideTvUi()?dp(12):dp(2),side,wideTvUi()?dp(18):dp(10));}}
 void cancelTvCatalogWork(){tvBrowserGridGeneration++;tvCatalogChunkPending=false;tvCatalogRows=new JSONArray();tvCatalogNextIndex=0;tvCatalogCols=6;tvCatalogCardW=0;tvCatalogImgH=0;tvCatalogGap=0;tvCatalogRenderRequest=0;try{if(tvCatalogGridScroll!=null)tvCatalogGridScroll.setOnScrollChangeListener((View.OnScrollChangeListener)null);}catch(Exception ignored){}if(tvCatalogAdapter!=null)tvCatalogAdapter.submit(new JSONArray());tvCatalogRecycler=null;tvCatalogState=null;tvCatalogAdapter=null;tvCatalogGridScroll=null;tvCatalogGrid=null;try{Img.cancelCatalogLoads();}catch(Exception ignored){}}
 void home(){homeTab("Shorts");if(tvMode)keepTvHomeAnchored();}
 void homeTab(String selected){
  if(selected==null||selected.trim().isEmpty())selected="Shorts";
  if("Shorts".equals(selected)){
   activeHomeTab="Shorts";
   if(contentFrame!=null)attachPermanentHomeHost();
   clear();setNav(0);if(wideTvUi()&&body!=null)body.setPadding(dp(28),dp(12),dp(28),dp(18));homeViewAvailable=true;homeScrollY=0;homeCachedTab="Shorts";homeTop("Shorts");final int yellyGen=viewGen;if(tvMode)keepTvHomeAnchored();loadShortsCategorySections(yellyGen);return;
  }
  if(("Filmes".equals(selected)||"Séries".equals(selected)||"Turcas".equals(selected))&&blockVpnProtectedContent())return;
  /* 5.28.47: GreenShorts é catálogo global do YouTube, independente do provedor IPTV. */
  final boolean recommendations="Recomendações".equals(selected);
  // Yelly 1.0.46: Filmes/Séries abrem imediatamente. Não prender o usuário no Toast
  // “Preparando…” enquanto o catálogo é buscado; categorias faltantes entram progressivamente.
  final boolean yellyCatalogWasReady=catalogTabReady(selected);
  activeHomeTab=selected;

  // 5.28.13: a Home principal é um host permanente de verdade. Abas Filmes/Séries/Kids
  // usam uma página transitória, então tocar em Início nunca desmonta/recria categorias,
  // cards ou capas que já estavam prontas.
  if(recommendations){
   if(contentFrame!=null&&homeViewAvailable&&homeScrollCache!=null&&homeBodyCache!=null&&homeBodyCache.getChildCount()>0&&"Recomendações".equals(homeCachedTab)){
    attachPermanentHomeHost();setNav(0);if(wideTvUi())syncTvHeader("Recomendações");homeScrollY=0;if(mainScroll!=null){mainScroll.setVisibility(View.VISIBLE);mainScroll.scrollTo(0,0);mainScroll.post(()->{if(mainScroll==homeScrollCache)mainScroll.scrollTo(0,0);});}if(tvMode)keepTvHomeAnchored();return;
   }
   if(contentFrame!=null)attachPermanentHomeHost();
   clear();setNav(0);if(wideTvUi()&&body!=null)body.setPadding(dp(28),dp(12),dp(28),dp(18));homeViewAvailable=true;homeScrollY=0;homeCachedTab="Recomendações";homeTop(selected);final int gen=viewGen;if(tvMode)keepTvHomeAnchored();
   if(wideTvUi())renderTvLandingHeader();loadExplore(gen);return;
  }

  // Abas secundárias não podem apagar a Home já montada.
  if(contentFrame!=null){
   if(mainScroll==homeScrollCache)leaveHomeForPage();
   else if(mainScroll==null||body==null||body==homeBodyCache)createTransientPageHost();
  }
  clear();setNav(0);if(wideTvUi()&&body!=null)body.setPadding(dp(28),dp(12),dp(28),dp(18));homeTop(selected);final int gen=viewGen;if(tvMode)keepTvHomeAnchored();
  if("Shorts".equals(selected)||"Filmes".equals(selected)){loadShortsCategorySections(gen);return;}
  if("Turcas".equals(selected)){loadYellySeriesFromPanel(true,gen);return;}
  int typeId=2;
  loadYellySeriesFromPanel(false,gen);
  if(!yellyCatalogWasReady && !"Filmes".equals(selected) && !"Séries".equals(selected) && !"Turcas".equals(selected)){
   java.util.HashSet<String> noneIds=new java.util.HashSet<>();
   java.util.HashSet<String> noneNames=new java.util.HashSet<>();
   appendMissingHomeCategories(typeId==2?"series":"movie",typeId,noneIds,noneNames,gen);
   // Atualiza o cache em segundo plano para as próximas aberturas, sem bloquear a tela.
   if(!catalogPrefetchBusy)prefetchUnifiedCatalogSnapshot();
  }
 }
 void homeSectionTab(String key,JSONObject sec){
  if(sec==null)return;activeHomeTab=key;
  if(contentFrame!=null){if(mainScroll==homeScrollCache)leaveHomeForPage();else if(mainScroll==null||body==null||body==homeBodyCache)createTransientPageHost();}
  clear();setNav(0);if(wideTvUi()&&body!=null)body.setPadding(dp(28),dp(12),dp(28),dp(18));homeTop(key);final int gen=viewGen;if(tvMode)keepTvHomeAnchored();
  JSONArray data=sec.optJSONArray("data");if(data==null||data.length()==0)return;
  featureCarousel(data);
  String title=fixTitle(sec.optString("title","Conteúdos"));
  JSONObject same=sec;sectionHeader(title,()->openSection(same));posterRow(data);
  int typeId=sec.optInt("type_id",sec.optInt("video_type",1));
  JSONObject prepared=readHomeCache();JSONArray sections=prepared==null?null:prepared.optJSONArray("result");int added=0;
  if(sections!=null){for(int i=0;i<sections.length()&&added<2;i++){if(gen!=viewGen)return;JSONObject other=sections.optJSONObject(i);if(other==null||other==sec||adultSectionBlocked(other))continue;int t=other.optInt("type_id",other.optInt("video_type",1));JSONArray a=other.optJSONArray("data");if(t!=typeId||a==null||a.length()==0)continue;String ot=fixTitle(other.optString("title",""));if(ot.equalsIgnoreCase(title))continue;final JSONObject f=other;sectionHeader(ot,()->openSection(f));posterRow(a);added++;}}
 }
 JSONArray featuredForType(int typeId,int max){
  JSONArray out=new JSONArray();JSONObject prepared=readHomeCache();JSONArray sections=prepared==null?null:prepared.optJSONArray("result");if(sections==null||max<=0)return out;
  java.util.ArrayList<JSONObject> pool=new java.util.ArrayList<>();java.util.HashSet<String> seen=new java.util.HashSet<>();
  for(int i=0;i<sections.length();i++){JSONObject sec=sections.optJSONObject(i);if(sec==null||adultSectionBlocked(sec))continue;int t=sec.optInt("type_id",sec.optInt("video_type",1));if(t!=typeId)continue;if(typeId==1&&isShortsSection(sec))continue;JSONArray a=sec.optJSONArray("data");if(a==null)continue;for(int j=0;j<a.length();j++){JSONObject x=a.optJSONObject(j);if(x==null)continue;String k=itemKey(x);if(seen.add(k))pool.add(x);}}
  java.util.Collections.shuffle(pool,new java.util.Random(System.nanoTime()^((long)(++featuredShuffleTick)*1103515245L)^typeId));
  for(int i=0;i<Math.min(max,pool.size());i++)out.put(pool.get(i));return out;
 }
 JSONArray featuredForShorts(int max){
  JSONArray out=new JSONArray();JSONObject prepared=readHomeCache();JSONArray sections=prepared==null?null:prepared.optJSONArray("result");if(sections==null||max<=0)return out;java.util.HashSet<String> seen=new java.util.HashSet<>();
  for(int i=0;i<sections.length()&&out.length()<max;i++){JSONObject sec=sections.optJSONObject(i);if(sec==null||!isShortsSection(sec))continue;JSONArray a=filterShortsSectionItems(sec,sec.optJSONArray("data"));if(a==null)continue;for(int j=0;j<a.length()&&out.length()<max;j++){JSONObject x=a.optJSONObject(j);if(x==null)continue;String k=itemKey(x);if(seen.add(k))out.put(x);}}return out;
 }
 void renderTvLandingHeader(){
  // v16.144: sem banner gigante na Home de TV. O menu superior já cobre a navegação
  // e o conteúdo começa imediatamente em Destaques, como na referência.
 }
 TextView tvLandingButton(String label){TextView v=t(label,14);v.setTypeface(null,1);v.setGravity(Gravity.CENTER);v.setTextColor(Color.WHITE);GradientDrawable g=round(0xff23101a,11);g.setStroke(dp(1),0xff62314a);v.setBackground(g);return v;}
 void loadExplore(final int gen){
  JSONObject cached=readHomeCache();
  if(cached!=null&&cached.optJSONArray("result")!=null&&cached.optJSONArray("result").length()>0){renderExplore(cached,gen,false);refreshCatalogInBackground();return;}
  final TextView loading=t("Atualizando conteúdo…",14);loading.setTextColor(0xff999096);loading.setGravity(Gravity.CENTER);body.addView(loading,new LinearLayout.LayoutParams(-1,dp(64)));
  final Handler timeout=new Handler(Looper.getMainLooper());final boolean[] finished={false};final Runnable failSafe=()->{if(gen==viewGen&&!finished[0]){if(loading.getParent()!=null)body.removeView(loading);TextView m=t("Não foi possível carregar agora. Toque para tentar novamente.",14);m.setTextColor(0xffa79da4);m.setGravity(Gravity.CENTER);m.setOnClickListener(v->home());body.addView(m,new LinearLayout.LayoutParams(-1,dp(64)));finished[0]=true;}};timeout.postDelayed(failSafe,14000);
  fetchPreparedHome(-1,-1,new PreparedHomeCB(){public void ok(JSONObject j){if(gen!=viewGen||finished[0])return;timeout.removeCallbacks(failSafe);if(loading.getParent()!=null)body.removeView(loading);JSONObject stable=protectHomePayload(j);JSONArray a=stable==null?null:stable.optJSONArray("result");if(a==null||a.length()==0){failSafe.run();return;}finished[0]=true;saveHomeCache(stable);sp.edit().putBoolean(homeExtrasKey(),false).apply();homeExtrasStarted=false;renderExplore(stable,gen,false);refreshCatalogInBackground();}public void err(String x){if(gen!=viewGen||finished[0])return;timeout.removeCallbacks(failSafe);failSafe.run();}});
 }
 void refreshCatalogInBackground(){ /* v16.40: painel v72 lê o catálogo direto da fonte */ }
 void renderExplore(JSONObject rootJson,final int gen,boolean useOneTimeExtras){
  if(gen!=viewGen)return;final java.util.HashSet<String> shownCats=new java.util.HashSet<>();final java.util.HashSet<String> shownNames=new java.util.HashSet<>();
  JSONArray sections=rootJson.optJSONArray("result");boolean rendered=false;
  if(sections!=null&&sections.length()>0){
   JSONArray featured=(modeReadyFeatured!=null&&modeReadyFeatured.length()>0)?modeReadyFeatured:buildFeaturedMix(sections,12);
   modeReadyFeatured=null;
   if(featured.length()>0&&gen==viewGen){featureCarousel(featured);promoLive();rendered=true;}
   if(gen!=viewGen)return;
   final JSONArray recentMovies=buildRecentlyAddedMovies(sections,12);
   if(recentMovies.length()>0){
    final JSONObject recentSec=new JSONObject();try{recentSec.put("title","Adicionados recentemente");recentSec.put("category_id",0);recentSec.put("type_id",1);recentSec.put("data",recentMovies);}catch(Exception ignored){}
    sectionHeader("Adicionados recentemente",()->openSection(recentSec));posterRow(recentMovies);rendered=true;
   }
   if(gen!=viewGen)return;continueHost=new LinearLayout(MainActivity.this);continueHost.setOrientation(LinearLayout.VERTICAL);body.addView(continueHost,new LinearLayout.LayoutParams(-1,-2));loadContinueWatchingSafe(gen);

   // A Home de Recomendações deve manter FILMES antes de SÉRIES, independentemente
   // da ordem em que o painel devolve as seções. Também reservamos hosts separados
   // para que categorias de filmes recuperadas de get_category não apareçam depois
   // das categorias de séries por causa do retorno assíncrono.
   final LinearLayout movieHost=new LinearLayout(MainActivity.this);movieHost.setOrientation(LinearLayout.VERTICAL);body.addView(movieHost,new LinearLayout.LayoutParams(-1,-2));
   final LinearLayout seriesHost=new LinearLayout(MainActivity.this);seriesHost.setOrientation(LinearLayout.VERTICAL);body.addView(seriesHost,new LinearLayout.LayoutParams(-1,-2));
   final LinearLayout otherHost=new LinearLayout(MainActivity.this);otherHost.setOrientation(LinearLayout.VERTICAL);body.addView(otherHost,new LinearLayout.LayoutParams(-1,-2));

   // Primeiro registra todas as categorias presentes no payload para evitar duplicação.
   for(int i=0;i<sections.length();i++){JSONObject sec=sections.optJSONObject(i);if(sec==null||adultSectionBlocked(sec))continue;if("recently_added".equals(sec.optString("section_key","")))continue;JSONArray data=sec.optJSONArray("data");if(data==null||data.length()==0)continue;int typeId=sec.optInt("type_id",sec.optInt("video_type",1));int cid=sec.optInt("category_id",0);if(cid>0)shownCats.add(typeId+":"+cid);String title=fixTitle(sec.optString("title","Conteúdos"));shownNames.add((typeId+":"+title.trim().toLowerCase(java.util.Locale.ROOT)));}

   // 5.28.12: renderização em lotes. Criar dezenas de linhas + centenas de cards
   // no mesmo frame podia disparar ANR logo depois de chegar em 100%.
   renderHomeSectionsChunked(sections,1,movieHost,gen,0);
   renderHomeSectionsChunked(sections,2,seriesHost,gen,0);
   renderHomeOtherSectionsChunked(sections,otherHost,gen,0);
   rendered=true;

   // v16.39: a Home não depende mais do payload misto para decidir se existem Filmes.
   // Busca cada família explicitamente no endpoint section_list (type_id=1/2). Isso evita
   // o bug em que um payload/cache dominado por Séries fazia todas as categorias de Filmes
   // desaparecerem da Home. Os hosts continuam em ordem fixa: Filmes primeiro, Séries depois.
   // O bootstrap já carregou o section_list completo direto da fonte. Não refaz a mesma
   // consulta ao entrar na Home; só busca um tipo separadamente se ele realmente estiver ausente.
   // v16.48: a Home abre com o conjunto crítico já pronto e completa o restante
   // silenciosamente, sem mostrar “Carregando recomendações”.
   // 5.28.14: sempre completa TODAS as categorias reais da fonte, sem limite.
   // A Home já aparece com o snapshot; os nomes restantes entram imediatamente e
   // os cards são preenchidos em segundo plano sem bloquear a tela.
   // 5.28.25: a Home nao acrescenta mais categorias aos poucos na tela.
   // O catalogo completo e preparado em segundo plano e trocado de forma atomica no cache.
   // Assim nao existe efeito de pagina recarregando/linhas aparecendo uma por uma.
  }
  if(!rendered){TextView m=t("Nenhuma recomendação disponível no momento.",14);m.setTextColor(0xff999096);m.setGravity(Gravity.CENTER);body.addView(m,new LinearLayout.LayoutParams(-1,dp(64)));}
  if(tvMode)keepTvHomeAnchored();
 }

 void renderHomeSectionsChunked(JSONArray sections,int wanted,LinearLayout target,int gen,int start){
  // 5.28.34: a Home permanente continua terminando de montar mesmo enquanto o
  // usuário visita Perfil/Favoritos/Downloads. Antes o clear() da página nova
  // incrementava viewGen, abortava estes lotes e deixava movieHost/seriesHost
  // em GONE para sempre; ao voltar sobrava apenas "Adicionados recentemente".
  if((gen!=viewGen&&!cachedHomeHostValid(target))||sections==null||target==null||target.getParent()==null)return;
  if(start==0)target.setVisibility(View.VISIBLE);int added=0,i=start;
  for(;i<sections.length()&&added<12;i++){JSONObject sec=sections.optJSONObject(i);if(sec==null||adultSectionBlocked(sec))continue;if("recently_added".equals(sec.optString("section_key","")))continue;JSONArray data=sec.optJSONArray("data");if(data==null||data.length()==0)continue;int typeId=sec.optInt("type_id",sec.optInt("video_type",1));if(typeId!=wanted)continue;if(wanted==1&&isShortsSection(sec))continue;String rawTitle=fixTitle(sec.optString("title",wanted==1?"Filmes":"Séries"));String title=categoryNameWithCount(typedCategoryTitle(rawTitle,wanted),sec);final JSONObject fsec=sec;sectionHeaderInto(target,title,()->openSection(fsec));posterRowInto(target,data);added++;}
  final int next=i;if(next<sections.length())target.post(()->renderHomeSectionsChunked(sections,wanted,target,gen,next));
 }
 void renderHomeOtherSectionsChunked(JSONArray sections,LinearLayout target,int gen,int start){
  if((gen!=viewGen&&!cachedHomeHostValid(target))||sections==null||target==null||target.getParent()==null)return;
  if(start==0)target.setVisibility(View.VISIBLE);int added=0,i=start;
  for(;i<sections.length()&&added<12;i++){JSONObject sec=sections.optJSONObject(i);if(sec==null||adultSectionBlocked(sec))continue;if("recently_added".equals(sec.optString("section_key","")))continue;JSONArray data=sec.optJSONArray("data");if(data==null||data.length()==0)continue;int typeId=sec.optInt("type_id",sec.optInt("video_type",1));if(typeId==1||typeId==2)continue;String title=fixTitle(sec.optString("title","Conteúdos"));final JSONObject fsec=sec;sectionHeaderInto(target,title,()->openSection(fsec));posterRowInto(target,data);added++;}
  final int next=i;if(next<sections.length())target.post(()->renderHomeOtherSectionsChunked(sections,target,gen,next));
 }

 void loadTypedHomeSectionsInto(final int typeId,final LinearLayout host,final java.util.HashSet<String> shownCats,final java.util.HashSet<String> shownNames,final int gen,final JSONObject rootJson){
  final String type=typeId==2?"series":"movie";
  fetchHomePart(typeId,0,new PreparedHomeCB(){public void ok(JSONObject j){
   if(!hostValid(gen,host))return;JSONArray secs=j.optJSONArray("result");
   if(secs!=null&&secs.length()>0){
    // Só substitui o conteúdo desse bloco quando a resposta tipada realmente trouxe dados.
    // Assim uma oscilação de rede não apaga o que já estava visível.
    host.removeAllViews();
    for(int i=0;i<secs.length();i++){JSONObject sec=secs.optJSONObject(i);if(sec==null)continue;if("recently_added".equals(sec.optString("section_key","")))continue;if(typeId==1&&isShortsSection(sec))continue;JSONArray data=sec.optJSONArray("data");if(data==null||data.length()==0)continue;int cid=sec.optInt("category_id",0);String title=fixTitle(sec.optString("title",typeId==2?"Séries":"Filmes"));if(cid>0)shownCats.add(typeId+":"+cid);shownNames.add(typeId+":"+title.trim().toLowerCase(java.util.Locale.ROOT));final JSONObject fsec=sec;sectionHeaderInto(host,categoryNameWithCount(typedCategoryTitle(title,typeId),sec),()->openSection(fsec));posterRowInto(host,data);}
   }
   appendMissingHomeCategoriesCachedInto(type,typeId,shownCats,shownNames,gen,rootJson,host);
  }public void err(String e){
   if(hostValid(gen,host))appendMissingHomeCategoriesCachedInto(type,typeId,shownCats,shownNames,gen,rootJson,host);
  }});
 }

 void appendMissingHomeCategoriesCachedInto(String type,int typeId,java.util.HashSet<String> shownCats,java.util.HashSet<String> shownNames,final int gen,final JSONObject rootJson,final LinearLayout host){
  // 5.28.17: nunca mais mostra o nome solto com "…" esperando os cards.
  // A categoria só entra na tela quando a primeira página já chegou completa.
  // O cache expandido é persistido depois, então nas próximas aberturas entra pá-pum.
  Api.post("get_category",Api.m("type",type,"user_id",uid),new Api.CB(){public void ok(JSONObject j){
   if(!hostValid(gen,host))return;JSONArray cats=filterAdultCategories(j.optJSONArray("result"));if(cats==null)return;
   java.util.ArrayList<JSONObject> pending=new java.util.ArrayList<>();java.util.HashSet<String> queuedCats=new java.util.HashSet<>(shownCats);java.util.HashSet<String> queuedNames=new java.util.HashSet<>(shownNames);
   for(int i=0;i<cats.length();i++){
    JSONObject cat=cats.optJSONObject(i);if(cat==null)continue;if(typeId==1&&isShortsCategory(cat))continue;String cid=cat.optString("category_id",cat.optString("id",""));if(cid.isEmpty())continue;String key=typeId+":"+cid;if(queuedCats.contains(key))continue;
    String name=fixTitle(cat.optString("category_name",cat.optString("name",typeId==2?"Séries":"Filmes")));queuedCats.add(key);queuedNames.add(typeId+":"+name.trim().toLowerCase(java.util.Locale.ROOT));pending.add(cat);
   }
   if(pending.isEmpty()){if(rootJson!=null){saveHomeCache(rootJson);persistHomeCacheAsync(rootJson);}return;}
   int[] next={0},active={0};pumpMissingHomeCategoriesFast(pending,next,active,typeId,shownCats,shownNames,gen,rootJson,host);
  }public void err(String e){} });
 }
 void pumpMissingHomeCategoriesFast(java.util.ArrayList<JSONObject> pending,int[] next,int[] active,int typeId,java.util.HashSet<String> shownCats,java.util.HashSet<String> shownNames,int gen,JSONObject rootJson,LinearLayout host){
  if(!hostValid(gen,host))return;
  while(active[0]<8&&next[0]<pending.size()){
   final JSONObject cat=pending.get(next[0]++);String cid=cat.optString("category_id",cat.optString("id",""));String name=fixTitle(cat.optString("category_name",cat.optString("name",typeId==2?"Séries":"Filmes")));int raw;
   try{raw=Integer.parseInt(cid);}catch(Exception e){continue;}
   final String fcid=cid, fname=name, contentType=typeId==2?"series":"movie";final int ftotal=categoryKnownTotal(cat);active[0]++;
   Api.post("content_by_category",Api.m("user_id",uid,"type",contentType,"category_id",String.valueOf(raw),"page_no","1"),new Api.CB(){public void ok(JSONObject r){
    active[0]--;if(hostValid(gen,host)){JSONArray a=r.optJSONArray("result");if(a!=null&&a.length()>0){shownCats.add(typeId+":"+fcid);shownNames.add(typeId+":"+fname.trim().toLowerCase(java.util.Locale.ROOT));JSONObject sec=new JSONObject();try{sec.put("title",fname);sec.put("category_id",Integer.parseInt(fcid));sec.put("type_id",typeId);if(ftotal>0)sec.put("category_total",ftotal);sec.put("data",a);JSONArray rootSections=rootJson==null?null:rootJson.optJSONArray("result");if(rootSections!=null){rootSections.put(sec);saveHomeCache(rootJson);}sectionHeaderInto(host,categoryNameWithCount(typedCategoryTitle(fname,typeId),sec),()->openSection(sec));posterRowInto(host,a);}catch(Exception ignored){}}}
    pumpMissingHomeCategoriesFast(pending,next,active,typeId,shownCats,shownNames,gen,rootJson,host);finishMissingHomeCategoriesFast(pending,next,active,gen,rootJson,host);
   }public void err(String e){active[0]--;pumpMissingHomeCategoriesFast(pending,next,active,typeId,shownCats,shownNames,gen,rootJson,host);finishMissingHomeCategoriesFast(pending,next,active,gen,rootJson,host);}});
  }
  finishMissingHomeCategoriesFast(pending,next,active,gen,rootJson,host);
 }
 void finishMissingHomeCategoriesFast(java.util.ArrayList<JSONObject> pending,int[] next,int[] active,int gen,JSONObject rootJson,LinearLayout host){
  if(rootJson==null||pending==null||next==null||active==null)return;
  if(next[0]<pending.size()||active[0]>0)return;
  saveHomeCache(rootJson);
  persistHomeCacheAsync(rootJson);
 }

 boolean catalogFlagsReady(JSONObject c){return c!=null&&c.optInt("movie_first_pages_complete",0)==1&&c.optInt("series_first_pages_complete",0)==1;}
 boolean catalogTabReady(String tab){if("Shorts".equals(tab))return true;JSONObject c=readHomeCache();if(c==null)return false;if("Filmes".equals(tab))return c.optInt("movie_first_pages_complete",0)==1;if("Séries".equals(tab))return c.optInt("series_first_pages_complete",0)==1;return true;}
 boolean hasShortsSections(JSONObject c){JSONArray a=c==null?null:c.optJSONArray("result");if(a==null)return false;for(int i=0;i<a.length();i++){JSONObject sec=a.optJSONObject(i);if(sec!=null&&isShortsSection(sec)){JSONArray d=sec.optJSONArray("data");if(d!=null&&d.length()>0)return true;}}return false;}
 boolean currentProviderHasShorts(){JSONObject c=readHomeCache();return hasShortsSections(c);}
 JSONObject onlyTypePart(JSONObject src,int typeId){JSONObject out=new JSONObject();JSONArray r=new JSONArray();try{JSONArray a=src==null?null:src.optJSONArray("result");if(a!=null)for(int i=0;i<a.length();i++){JSONObject sec=a.optJSONObject(i);if(sec==null)continue;int t=sec.optInt("type_id",sec.optInt("video_type",1));if(t==typeId)r.put(sec);}out.put("status",200);out.put("result",r);}catch(Exception ignored){}return out;}
 void mergeTypePartIntoCache(JSONObject part,int typeId,boolean complete){JSONObject base=readHomeCache();if(base==null)base=new JSONObject();JSONArray old=base.optJSONArray("result");JSONArray fresh=part==null?null:part.optJSONArray("result");JSONArray merged=new JSONArray();try{if(old!=null)for(int i=0;i<old.length();i++){JSONObject sec=old.optJSONObject(i);if(sec==null)continue;int t=sec.optInt("type_id",sec.optInt("video_type",1));if(t!=typeId)merged.put(sec);}if(fresh!=null)for(int i=0;i<fresh.length();i++){JSONObject sec=fresh.optJSONObject(i);if(sec!=null)merged.put(sec);}base.put("status",200);base.put("result",merged);if(typeId==1&&complete)base.put("movie_first_pages_complete",1);if(typeId==2&&complete)base.put("series_first_pages_complete",1);if(typeId==1&&complete)base.put("shorts_checked",hasShortsSections(base)?1:base.optInt("shorts_checked",0));}catch(Exception ignored){}saveHomeCache(base);persistHomeCacheAsync(base);}
 void mergeShortsPartIntoCache(JSONObject part,boolean checked){JSONObject base=readHomeCache();if(base==null)base=new JSONObject();JSONArray old=base.optJSONArray("result");JSONArray fresh=part==null?null:part.optJSONArray("result");JSONArray merged=new JSONArray();try{if(old!=null)for(int i=0;i<old.length();i++){JSONObject sec=old.optJSONObject(i);if(sec!=null&&!isShortsSection(sec))merged.put(sec);}if(fresh!=null)for(int i=0;i<fresh.length();i++){JSONObject sec=fresh.optJSONObject(i);if(sec!=null&&isShortsSection(sec))merged.put(sec);}base.put("status",200);base.put("result",merged);if(checked)base.put("shorts_checked",1);}catch(Exception ignored){}saveHomeCache(base);persistHomeCacheAsync(base);}
 void prefetchUnifiedCatalogSnapshot(){
  if(catalogPrefetchBusy||Api.PROVIDER==null||Api.PROVIDER.trim().isEmpty()||uid==null||uid.isEmpty())return;JSONObject c=readHomeCache();if(catalogFlagsReady(c)&&hasShortsSections(c))return;catalogPrefetchBusy=true;final String provider=Api.PROVIDER;catalogPrefetchAt=System.currentTimeMillis();
  fetchPreparedHome(-1,-1,new PreparedHomeCB(){public void ok(JSONObject j){if(!provider.equals(Api.PROVIDER)){catalogPrefetchBusy=false;return;}JSONObject m=onlyTypePart(j,1),sr=onlyTypePart(j,2);mergeTypePartIntoCache(m,1,true);mergeTypePartIntoCache(sr,2,true);catalogPrefetchBusy=false;if(!hasShortsSections(readHomeCache()))prefetchShortsOnly();String pending=catalogTabPending;catalogTabPending="";if(pending!=null&&!pending.isEmpty()&&!catalogTabPrepareBusy)homeTab(pending);}public void err(String e){catalogPrefetchBusy=false;String pending=catalogTabPending;catalogTabPending="";if(pending!=null&&!pending.isEmpty()&&!catalogTabPrepareBusy)prepareCatalogTabAtomic(pending);}});
 }
 void prefetchShortsOnly(){if(Api.PROVIDER==null||Api.PROVIDER.trim().isEmpty())return;fetchShortsPart(new PreparedHomeCB(){public void ok(JSONObject j){mergeShortsPartIntoCache(j,true);}public void err(String e){JSONObject c=readHomeCache();if(c!=null){try{c.put("shorts_checked",1);}catch(Exception ignored){}saveHomeCache(c);persistHomeCacheAsync(c);}}});}
 void prepareCatalogTabAtomic(String tab){
  if(catalogTabReady(tab)){homeTab(tab);return;}if(catalogPrefetchBusy){catalogTabPending=tab;Toast.makeText(this,"Preparando "+("Shorts".equals(tab)?"Yelly Doramas":tab)+"…",Toast.LENGTH_SHORT).show();return;}if(catalogTabPrepareBusy){catalogTabPending=tab;Toast.makeText(this,"Preparando "+("Shorts".equals(tab)?"Yelly Doramas":tab)+"…",Toast.LENGTH_SHORT).show();return;}catalogTabPrepareBusy=true;catalogTabPending=tab;Toast.makeText(this,"Preparando "+("Shorts".equals(tab)?"Yelly Doramas":tab)+"…",Toast.LENGTH_SHORT).show();
  if("Shorts".equals(tab)){fetchShortsPart(new PreparedHomeCB(){public void ok(JSONObject j){mergeShortsPartIntoCache(j,true);finishCatalogTabPrepare(tab);}public void err(String e){JSONObject c=readHomeCache();if(c!=null){try{c.put("shorts_checked",1);}catch(Exception ignored){}saveHomeCache(c);persistHomeCacheAsync(c);}finishCatalogTabPrepare(tab);}});return;}
  final int typeId="Séries".equals(tab)?2:1;fetchHomePart(typeId,0,new PreparedHomeCB(){public void ok(JSONObject j){mergeTypePartIntoCache(j,typeId,true);finishCatalogTabPrepare(tab);}public void err(String e){catalogTabPrepareBusy=false;catalogTabPending="";Toast.makeText(MainActivity.this,"Não foi possível preparar "+tab+" agora.",Toast.LENGTH_SHORT).show();}});
 }
 void finishCatalogTabPrepare(String tab){catalogTabPrepareBusy=false;catalogTabPending="";homeTab(tab);}
 void fetchShortsPart(PreparedHomeCB cb){
  Api.post("get_category",Api.m("type","movie","user_id",uid),new Api.CB(){public void ok(JSONObject j){JSONArray cats=j.optJSONArray("result");java.util.ArrayList<JSONObject> found=new java.util.ArrayList<>();if(cats!=null)for(int i=0;i<cats.length();i++){JSONObject c=cats.optJSONObject(i);if(c!=null&&isShortsCategory(c))found.add(c);}if(!found.isEmpty()){fetchShortsCategories(found,cb);return;}fetchShortsFromSectionList(cb);}public void err(String e){fetchShortsFromSectionList(cb);}});
 }
 void fetchShortsCategories(java.util.ArrayList<JSONObject> cats,PreparedHomeCB cb){final JSONArray sections=new JSONArray();final int[] next={0},active={0},done={0};final boolean[] delivered={false};final Runnable[] pump=new Runnable[1];pump[0]=()->{if(delivered[0])return;while(active[0]<4&&next[0]<cats.size()){JSONObject cat=cats.get(next[0]++);String cid=cat.optString("category_id",cat.optString("id",""));if(cid.isEmpty()){done[0]++;continue;}final String fcid=cid,ftitle=cat.optString("category_name",cat.optString("name","Reels Shorts"));active[0]++;Api.post("content_by_category",Api.m("user_id",uid,"type","movie","category_id",fcid,"page_no","1","page","1","offset","0","limit","12","per_page","12","page_size","12","full_catalog","0"),new Api.CB(){public void ok(JSONObject r){active[0]--;done[0]++;JSONArray a=r.optJSONArray("result");if(a!=null&&a.length()>0){JSONObject sec=new JSONObject();try{sec.put("title",ftitle);sec.put("category_id",fcid);sec.put("type_id",1);sec.put("video_type",1);sec.put("section_kind","shorts");JSONArray clean=filterShortsSectionItems(sec,a);if(clean.length()>0){sec.put("data",clean);sections.put(sec);}}catch(Exception ignored){}}pump[0].run();}public void err(String e){active[0]--;done[0]++;pump[0].run();}});}if(done[0]>=cats.size()&&active[0]==0&&!delivered[0]){delivered[0]=true;if(sections.length()>0)cb.ok(homePartFromSections(sections,"shorts_categories"));else fetchShortsFromSectionList(cb);}};pump[0].run();}
 void fetchShortsFromSectionList(PreparedHomeCB cb){Api.post("section_list",Api.m("user_id",uid,"type_id","1"),new Api.CB(){public void ok(JSONObject j){JSONArray a=j.optJSONArray("result"),out=new JSONArray();java.util.ArrayList<JSONObject> cats=new java.util.ArrayList<>();if(a!=null)for(int i=0;i<a.length();i++){JSONObject sec=a.optJSONObject(i);if(sec==null||!isShortsSection(sec))continue;JSONArray d=sec.optJSONArray("data");if(d!=null&&d.length()>0){try{sec.put("section_kind","shorts");JSONArray clean=filterShortsSectionItems(sec,d);if(clean.length()>0){sec.put("data",clean);out.put(sec);continue;}}catch(Exception ignored){}}String cid=sec.optString("category_id",sec.optString("id",""));if(!cid.isEmpty()){JSONObject c=new JSONObject();try{c.put("category_id",cid);c.put("category_name",sec.optString("title",sec.optString("category_name","Reels Shorts")));}catch(Exception ignored){}cats.add(c);}}if(out.length()>0){cb.ok(homePartFromSections(out,"shorts_section_list"));return;}if(!cats.isEmpty()){fetchShortsCategories(cats,cb);return;}cb.err("Shorts não encontrado");}public void err(String e){cb.err(e==null?"Shorts não encontrado":e);}});}

 void loadContinueWatchingSafe(final int gen){
  final LinearLayout target=continueHost;final LinearLayout host=body;
  if(!hostValid(gen,host)||target==null)return;final JSONArray local=localMovieContinueItems();if(local.length()>0)renderContinueItems(target,local);
  Api.post("get_continue_watching",Api.m("user_id",uid),new Api.CB(){public void ok(JSONObject j){if(!hostValid(gen,host)||target==null)return;JSONArray merged=mergeContinueItems(j.optJSONArray("result"),local);if(merged.length()>0)renderContinueItems(target,merged);}public void err(String e){if(local.length()>0&&hostValid(gen,host))renderContinueItems(target,local);}});
 }
 boolean cachedHomeHostValid(View host){
  if(!homeViewAvailable||host==null||homeBodyCache==null)return false;
  View cur=host;while(cur!=null){if(cur==homeBodyCache)return true;ViewParent p=cur.getParent();cur=p instanceof View?(View)p:null;}return false;
 }
 boolean hostValid(int gen,LinearLayout host){return gen==viewGen||cachedHomeHostValid(host)||(detailOpen&&savedBody==host)||(sectionPageOpen&&sectionParentBody==host);}
 void appendMissingHomeCategories(String type,int typeId,java.util.HashSet<String> shownCats,java.util.HashSet<String> shownNames,final int gen){
  final LinearLayout host=body;
  Api.post("get_category",Api.m("type",type,"user_id",uid),new Api.CB(){public void ok(JSONObject j){if(!hostValid(gen,host))return;JSONArray cats=filterAdultCategories(j.optJSONArray("result"));if(cats==null)return;for(int i=0;i<cats.length();i++){if(!hostValid(gen,host))return;JSONObject cat=cats.optJSONObject(i);if(cat==null)continue;if(typeId==1&&isShortsCategory(cat))continue;String cid=cat.optString("category_id",cat.optString("id",""));if(cid.isEmpty())continue;String key=typeId+":"+cid;if(shownCats.contains(key))continue;shownCats.add(key);String name=fixTitle(cat.optString("category_name",cat.optString("name",typeId==2?"Séries":"Filmes")));String nameKey=name.trim().toLowerCase(java.util.Locale.ROOT);if(shownNames.contains(nameKey))continue;shownNames.add(nameKey);LinearLayout holder=new LinearLayout(MainActivity.this);holder.setOrientation(LinearLayout.VERTICAL);String countLabel=categoryNameWithCount(typedCategoryTitle(name,typeId),cat);TextView wait=t(countLabel+"  ·  carregando…",15);wait.setTextColor(0xffa79da4);holder.addView(wait,new LinearLayout.LayoutParams(-1,dp(42)));host.addView(holder,new LinearLayout.LayoutParams(-1,-2));int raw;try{raw=Integer.parseInt(cid);}catch(Exception e){host.removeView(holder);continue;}final int fraw=raw;final String fcid=cid, contentType=typeId==2?"series":"movie";Api.post("content_by_category",Api.m("user_id",uid,"type",contentType,"category_id",String.valueOf(fraw),"page_no","1"),new Api.CB(){public void ok(JSONObject r){if(!hostValid(gen,host))return;JSONArray a=r.optJSONArray("result");if(a==null||a.length()==0){host.removeView(holder);return;}holder.removeAllViews();JSONObject sec=new JSONObject();try{sec.put("title",name);sec.put("category_id",Integer.parseInt(fcid));sec.put("type_id",typeId);int ctotal=categoryKnownTotal(cat);if(ctotal>0)sec.put("category_total",ctotal);sec.put("data",a);}catch(Exception e){}sectionHeaderInto(holder,categoryNameWithCount(typedCategoryTitle(name,typeId),sec),()->openSection(sec));posterRowInto(holder,a);}public void err(String e){if(hostValid(gen,host))host.removeView(holder);}});}}public void err(String e){}});
 }
 void addDirectCatalogEmpty(String msg){TextView empty=t(msg,14);empty.setTextColor(0xffa79da4);empty.setGravity(Gravity.CENTER);body.addView(empty,new LinearLayout.LayoutParams(-1,dp(72)));}

 JSONArray yellyPreloadedSeries=new JSONArray(),yellyPreloadedTurcas=new JSONArray();
 String yellyPreloadedSeriesCategory="",yellyPreloadedTurcasCategory="";
 boolean yellyCatalogPreloadDone=false,yellyCatalogPreloadBusy=false,yellyStartupSyncBusy=false,yellyStartupSyncDone=false;
 ProgressBar yellyStartupProgress=null;TextView yellyStartupStatus=null,yellyStartupDetail=null;final Handler yellyStartupHandler=new Handler(Looper.getMainLooper());Runnable yellyStartupTimeout=null;
 String yellySeriesSeedKey(boolean turkish){return turkish?"yelly_turcas_seed_v6":"yelly_series_seed_v6";}
 String yellySeriesCategoryKey(boolean turkish){return turkish?"yelly_turcas_category_v6":"yelly_series_category_v6";}
 JSONArray readYellySeriesSeed(boolean turkish){try{String raw=sp.getString(yellySeriesSeedKey(turkish),"");return raw.isEmpty()?new JSONArray():new JSONArray(raw);}catch(Exception e){return new JSONArray();}}
 void saveYellySeriesSeed(boolean turkish,JSONArray rows,String categoryId){if(rows==null||rows.length()==0)return;JSONArray out=new JSONArray();for(int i=0;i<Math.min(categoryPageSize(),rows.length());i++){JSONObject x=rows.optJSONObject(i);if(x!=null)out.put(x);}sp.edit().putString(yellySeriesSeedKey(turkish),out.toString()).putString(yellySeriesCategoryKey(turkish),categoryId==null?"":categoryId).apply();}
 void showYellyStartupScreen(){
  FrameLayout frame=new FrameLayout(this);frame.setBackgroundColor(BG);LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setGravity(Gravity.CENTER_HORIZONTAL);box.setPadding(dp(28),dp(24),dp(28),dp(24));
  ImageView logo=new ImageView(this);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);applyAppLogo(logo);box.addView(logo,new LinearLayout.LayoutParams(dp(tvMode?230:180),dp(tvMode?105:82)));
  TextView title=t("Preparando seu catálogo",tvMode?24:20);title.setTypeface(null,1);title.setGravity(Gravity.CENTER);title.setTextColor(Color.WHITE);LinearLayout.LayoutParams tlp=new LinearLayout.LayoutParams(-1,-2);tlp.setMargins(0,dp(20),0,dp(8));box.addView(title,tlp);
  yellyStartupStatus=t("Sincronizando conteúdo…",tvMode?16:14);yellyStartupStatus.setGravity(Gravity.CENTER);yellyStartupStatus.setTextColor(0xffffb3d2);box.addView(yellyStartupStatus,new LinearLayout.LayoutParams(-1,dp(32)));
  yellyStartupDetail=t("Filmes • Séries • Turcas",tvMode?14:12);yellyStartupDetail.setGravity(Gravity.CENTER);yellyStartupDetail.setTextColor(0xffaa9da5);LinearLayout.LayoutParams dlp=new LinearLayout.LayoutParams(-1,dp(28));dlp.setMargins(0,0,0,dp(12));box.addView(yellyStartupDetail,dlp);
  yellyStartupProgress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);yellyStartupProgress.setIndeterminate(false);yellyStartupProgress.setMax(100);yellyStartupProgress.setProgress(6);box.addView(yellyStartupProgress,new LinearLayout.LayoutParams(Math.min(getResources().getDisplayMetrics().widthPixels-dp(72),dp(tvMode?520:360)),dp(8)));
  FrameLayout.LayoutParams blp=new FrameLayout.LayoutParams(-1,-2,Gravity.CENTER);frame.addView(box,blp);setContentView(frame);
 }
 void updateYellyStartup(int progress,String status,String detail){runOnUiThread(()->{try{if(yellyStartupProgress!=null)yellyStartupProgress.setProgress(Math.max(0,Math.min(100,progress)));if(yellyStartupStatus!=null&&status!=null)yellyStartupStatus.setText(status);if(yellyStartupDetail!=null&&detail!=null)yellyStartupDetail.setText(detail);}catch(Exception ignored){}});}
 void startYellyStartupSync(final Runnable done){
  if(yellyStartupSyncDone){if(done!=null)done.run();return;}if(yellyStartupSyncBusy)return;yellyStartupSyncBusy=true;showYellyStartupScreen();
  yellyPreloadedSeries=readYellySeriesSeed(false);yellyPreloadedTurcas=readYellySeriesSeed(true);yellyPreloadedSeriesCategory=sp.getString(yellySeriesCategoryKey(false),"");yellyPreloadedTurcasCategory=sp.getString(yellySeriesCategoryKey(true),"");
  final int[] pending={2};final boolean[] finished={false};
  final Runnable finish=()->{if(finished[0])return;finished[0]=true;if(yellyStartupTimeout!=null)yellyStartupHandler.removeCallbacks(yellyStartupTimeout);yellyStartupSyncBusy=false;yellyStartupSyncDone=true;yellyCatalogPreloadDone=yellyPreloadedSeries.length()>0||yellyPreloadedTurcas.length()>0;updateYellyStartup(100,"Catálogo pronto","Abrindo Yelly Doramas…");yellyStartupHandler.postDelayed(()->{if(done!=null&&!isFinishing())done.run();},90);};
  final Runnable one=()->{pending[0]--;if(pending[0]<=0)finish.run();};
  updateYellyStartup(14,"Sincronizando filmes","Preparando catálogo inicial…");
  Api.post("greenshorts",Api.m("user_id",uid,"page_no","1","page","1","offset","0","limit",String.valueOf(greenShortsPageSize()),"per_page",String.valueOf(greenShortsPageSize())),new Api.CB(){public void ok(JSONObject j){JSONArray rows=j.optJSONArray("result");if(rows!=null&&rows.length()>0)saveGreenShortsSeedCache(rows);updateYellyStartup(48,"Filmes prontos","Preparando Séries e Turcas…");one.run();}public void err(String e){updateYellyStartup(42,"Filmes em cache","Preparando Séries e Turcas…");one.run();}});
  Api.post("get_category",Api.m("type","series","user_id",uid),new Api.CB(){public void ok(JSONObject j){JSONArray cats=j.optJSONArray("result");if(cats==null)cats=new JSONArray();java.util.ArrayList<JSONObject> list=new java.util.ArrayList<>();for(int i=0;i<cats.length();i++){JSONObject c=cats.optJSONObject(i);if(c!=null)list.add(c);}if(list.isEmpty()){yellyCatalogPreloadDone=yellyPreloadedSeries.length()>0||yellyPreloadedTurcas.length()>0;updateYellyStartup(86,"Séries prontas","Usando catálogo salvo…");one.run();return;}final int[] left={list.size()};final JSONArray freshSeries=new JSONArray(),freshTurcas=new JSONArray();for(JSONObject c:list){final String cid=c.optString("category_id","");final String n=fixTitle(c.optString("category_name",c.optString("name",""))).toLowerCase(java.util.Locale.ROOT);final boolean turkish=n.contains("turc")||n.contains("turk");Api.post("content_by_category",Api.m("user_id",uid,"type","series","category_id",cid,"page_no","1","page","1","offset","0","limit",String.valueOf(categoryPageSize()),"per_page",String.valueOf(categoryPageSize()),"page_size",String.valueOf(categoryPageSize()),"full_catalog","0"),new Api.CB(){void complete(){left[0]--;int doneCats=list.size()-left[0];updateYellyStartup(52+Math.min(38,(doneCats*38)/Math.max(1,list.size())),turkish?"Turcas sincronizadas":"Séries sincronizadas","Finalizando catálogo…");if(left[0]<=0){if(freshSeries.length()>0){yellyPreloadedSeries=freshSeries;saveYellySeriesSeed(false,freshSeries,yellyPreloadedSeriesCategory);}if(freshTurcas.length()>0){yellyPreloadedTurcas=freshTurcas;saveYellySeriesSeed(true,freshTurcas,yellyPreloadedTurcasCategory);}yellyCatalogPreloadDone=yellyPreloadedSeries.length()>0||yellyPreloadedTurcas.length()>0;one.run();}}public void ok(JSONObject x){JSONArray a=x.optJSONArray("result");if(a!=null){JSONArray target=turkish?freshTurcas:freshSeries;if(turkish&&yellyPreloadedTurcasCategory.isEmpty())yellyPreloadedTurcasCategory=cid;if(!turkish&&yellyPreloadedSeriesCategory.isEmpty())yellyPreloadedSeriesCategory=cid;for(int k=0;k<a.length();k++){JSONObject row=a.optJSONObject(k);if(row!=null)target.put(row);}}complete();}public void err(String e){complete();}});}}public void err(String e){yellyCatalogPreloadDone=yellyPreloadedSeries.length()>0||yellyPreloadedTurcas.length()>0;updateYellyStartup(82,"Séries em cache","Finalizando catálogo…");one.run();}});
  yellyStartupTimeout=()->{if(finished[0])return;updateYellyStartup(96,"Catálogo disponível","Abrindo com o conteúdo já salvo…");finish.run();};yellyStartupHandler.postDelayed(yellyStartupTimeout,10000);
 }

 void preloadYellyCatalogs(final Runnable done){
  if(yellyCatalogPreloadDone){if(done!=null)done.run();return;}
  if(yellyCatalogPreloadBusy){new Handler(Looper.getMainLooper()).postDelayed(()->preloadYellyCatalogs(done),120);return;}
  yellyCatalogPreloadBusy=true;
  Api.post("get_category",Api.m("type","series"),new Api.CB(){public void ok(JSONObject j){
   JSONArray cats=j.optJSONArray("result");if(cats==null)cats=new JSONArray();java.util.ArrayList<JSONObject> list=new java.util.ArrayList<>();
   for(int i=0;i<cats.length();i++){JSONObject c=cats.optJSONObject(i);if(c!=null)list.add(c);}
   if(list.isEmpty()){yellyCatalogPreloadBusy=false;yellyCatalogPreloadDone=true;if(done!=null)done.run();return;}
   final int[] left={list.size()};
   for(JSONObject c:list){final String n=fixTitle(c.optString("category_name",c.optString("name",""))).toLowerCase(java.util.Locale.ROOT);final boolean turkish=n.contains("turc")||n.contains("turk");String cid=c.optString("category_id","");
    Api.post("content_by_category",Api.m("type","series","category_id",cid,"page_no","1","limit","300"),new Api.CB(){void one(){left[0]--;if(left[0]<=0){yellyCatalogPreloadBusy=false;yellyCatalogPreloadDone=true;if(done!=null)done.run();}}public void ok(JSONObject x){JSONArray a=x.optJSONArray("result");if(a!=null){JSONArray target=turkish?yellyPreloadedTurcas:yellyPreloadedSeries;for(int k=0;k<a.length();k++)target.put(a.opt(k));}one();}public void err(String e){one();}});
   }
  }public void err(String e){yellyCatalogPreloadBusy=false;if(done!=null)done.run();}});
 }
 void loadYellySeriesFromPanel(final boolean turkish,final int gen){
  final LinearLayout host=body;JSONArray ready=turkish?yellyPreloadedTurcas:yellyPreloadedSeries;
  if(yellyCatalogPreloadDone&&ready.length()>0){featureCarousel(ready);grid(ready);prefetchVisibleSeriesDetails(ready,2);String cachedCid=turkish?yellyPreloadedTurcasCategory:yellyPreloadedSeriesCategory;if(!wideTvUi()&&cachedCid!=null&&!cachedCid.isEmpty())startMobileCategoryPaging(2,cachedCid,ready,gen);return;}
  final TextView wait=t(turkish?"Carregando séries turcas…":"Carregando séries…",14);wait.setTextColor(0xffb8aab2);wait.setGravity(Gravity.CENTER);host.addView(wait,new LinearLayout.LayoutParams(-1,dp(58)));
  Api.post("get_category",Api.m("type","series"),new Api.CB(){public void ok(JSONObject j){if(!hostValid(gen,host))return;
   JSONArray cats=j.optJSONArray("result");if(cats==null)cats=new JSONArray();final JSONArray wanted=new JSONArray();
   for(int i=0;i<cats.length();i++){JSONObject c=cats.optJSONObject(i);if(c==null)continue;String n=fixTitle(c.optString("category_name",c.optString("name",""))).toLowerCase(java.util.Locale.ROOT);boolean isTurk=n.contains("turc")||n.contains("turk");if(turkish==isTurk)wanted.put(c);}
   if(wanted.length()==0){if(wait.getParent()!=null)host.removeView(wait);addDirectCatalogEmpty(turkish?"Nenhuma série turca liberada no painel.":"Nenhuma série disponível nesta fonte.");return;}
   final JSONArray all=new JSONArray();final int[] pending={wanted.length()};
   for(int i=0;i<wanted.length();i++){JSONObject c=wanted.optJSONObject(i);String cid=c==null?"":c.optString("category_id","");Api.post("content_by_category",Api.m("user_id",uid,"type","series","category_id",cid,"page_no","1","page","1","offset","0","limit","60","per_page","60","page_size","60","full_catalog","0"),new Api.CB(){public void ok(JSONObject x){JSONArray a=x.optJSONArray("result");if(a!=null)for(int k=0;k<a.length();k++)all.put(a.opt(k));done();}public void err(String e){done();}void done(){if(--pending[0]==0&&hostValid(gen,host)){if(wait.getParent()!=null)host.removeView(wait);if(all.length()>0){featureCarousel(all);grid(all);prefetchVisibleSeriesDetails(all,4);if(!wideTvUi()&&wanted.length()==1){JSONObject only=wanted.optJSONObject(0);String onlyCid=only==null?"":only.optString("category_id","");if(!onlyCid.isEmpty())startMobileCategoryPaging(2,onlyCid,all,gen);}}else addDirectCatalogEmpty(turkish?"Nenhuma série turca disponível.":"Nenhuma série disponível.");}}});}
  }public void err(String e){if(hostValid(gen,host)){if(wait.getParent()!=null)host.removeView(wait);addDirectCatalogEmpty("Não foi possível carregar as séries.");}}});
 }
 JSONArray aggregateTurkishSeries(){JSONArray out=new JSONArray();JSONObject c=readHomeCache();JSONArray secs=c==null?null:c.optJSONArray("result");java.util.HashSet<String> seen=new java.util.HashSet<>();if(secs==null)return out;for(int i=0;i<secs.length();i++){JSONObject sec=secs.optJSONObject(i);if(sec==null||sec.optInt("type_id",sec.optInt("video_type",1))!=2)continue;String n=fixTitle(sec.optString("title","")).toLowerCase(java.util.Locale.ROOT);if(!(n.contains("turc")||n.contains("turk")))continue;JSONArray a=sec.optJSONArray("data");if(a==null)continue;for(int j=0;j<a.length();j++){JSONObject x=a.optJSONObject(j);if(x==null)continue;String k=itemKey(x);if(seen.add(k))out.put(x);}}return out;}
 void loadAllCategorySections(int typeId,String selected,final int gen){
  final LinearLayout host=body;JSONObject prepared=readHomeCache();JSONArray secs=prepared==null?null:prepared.optJSONArray("result");boolean any=false;
  if(secs!=null){for(int i=0;i<secs.length();i++){JSONObject sec=secs.optJSONObject(i);if(sec==null||adultSectionBlocked(sec)||"recently_added".equals(sec.optString("section_key","")))continue;int t=sec.optInt("type_id",sec.optInt("video_type",1));JSONArray data=sec.optJSONArray("data");if(t!=typeId||data==null||data.length()==0)continue;if(typeId==1&&isShortsSection(sec))continue;String rawTitle=fixTitle(sec.optString("title",typeId==2?"Séries":"Filmes"));String title=categoryNameWithCount(typedCategoryTitle(rawTitle,typeId),sec);final JSONObject fsec=sec;sectionHeaderInto(host,title,()->openSection(fsec));posterRowInto(host,data);any=true;}}
  if(!any){TextView empty=t(typeId==2?"Nenhuma série disponível nesta fonte.":"Nenhum filme disponível nesta fonte.",14);empty.setTextColor(0xffa79da4);empty.setGravity(Gravity.CENTER);host.addView(empty,new LinearLayout.LayoutParams(-1,dp(72)));}
 }
 String shortsItemCategoryId(JSONObject x){if(x==null)return "";String cid=x.optString("category_id","").trim();if(cid.isEmpty())cid=x.optString("categoryId","").trim();if(cid.isEmpty())cid=x.optString("raw_category_id","").trim();return cid;}
 boolean shortsItemMatchesSection(JSONObject x,JSONObject sec){if(x==null||sec==null)return false;String expected=sec.optString("category_id",sec.optString("id","")).trim();String actual=shortsItemCategoryId(x);if(!expected.isEmpty()&&!actual.isEmpty())return expected.equals(actual);String itemCategory=x.optString("category_name",x.optString("category",""));return !itemCategory.trim().isEmpty()&&isShortsCategoryTitle(itemCategory);}
 JSONArray filterShortsSectionItems(JSONObject sec,JSONArray data){JSONArray out=new JSONArray();if(sec==null||data==null)return out;for(int i=0;i<data.length();i++){JSONObject x=data.optJSONObject(i);if(x!=null&&shortsItemMatchesSection(x,sec))out.put(x);}return out;}
 JSONArray collectShortsLooseItems(JSONArray secs){JSONArray out=new JSONArray();java.util.HashSet<String> seen=new java.util.HashSet<>();if(secs==null)return out;for(int i=0;i<secs.length();i++){JSONObject sec=secs.optJSONObject(i);if(sec==null||!isShortsSection(sec))continue;JSONArray data=filterShortsSectionItems(sec,sec.optJSONArray("data"));for(int j=0;j<data.length();j++){JSONObject x=data.optJSONObject(j);if(x==null)continue;String k=itemKey(x);if(k==null||k.trim().isEmpty())k=x.optString("id",x.optString("video_id",x.optString("name","")))+"|"+x.optString("stream_url",x.optString("url",""));if(seen.add(k))out.put(x);}}return out;}
 JSONArray randomCatalogStart(JSONArray src){
  JSONArray out=new JSONArray();if(src==null||src.length()==0)return out;
  java.util.ArrayList<JSONObject> pool=new java.util.ArrayList<>();
  for(int i=0;i<src.length();i++){JSONObject x=src.optJSONObject(i);if(x!=null)pool.add(x);}
  java.util.Collections.shuffle(pool,new java.util.Random(System.nanoTime()^((long)(++featuredShuffleTick)*2654435761L)));
  for(JSONObject x:pool)out.put(x);
  return out;
 }
 JSONArray shortsSeedFromHomeCache(int max){
  JSONArray out=new JSONArray();java.util.HashSet<String> seen=new java.util.HashSet<>();JSONObject c=readHomeCache();JSONArray secs=c==null?null:c.optJSONArray("result");if(secs==null)return out;
  for(int i=0;i<secs.length()&&out.length()<max;i++){JSONObject sec=secs.optJSONObject(i);if(sec==null||!isShortsSection(sec))continue;JSONArray rows=sec.optJSONArray("data");if(rows==null)continue;for(int k=0;k<rows.length()&&out.length()<max;k++){JSONObject x=rows.optJSONObject(k);if(x==null)continue;String key=itemKey(x);if(key==null||key.trim().isEmpty())key=x.optString("youtube_id",x.optString("id",x.optString("name","")));if(seen.add(key))out.put(x);}}
  return out;
 }
 void loadShortsCategorySections(final int gen){
  final LinearLayout host=body;if(host==null)return;
  JSONArray seed=readGreenShortsSeedCache();if(seed.length()==0){seed=shortsSeedFromHomeCache(greenShortsPageSize());if(seed.length()>0)saveGreenShortsSeedCache(seed);}
  JSONArray startRows=randomCatalogStart(seed);
  if(wideTvUi()){
   final java.util.HashSet<String> seen=new java.util.HashSet<>();
   for(int i=0;i<seed.length();i++){JSONObject x=seed.optJSONObject(i);if(x==null)continue;String y=x.optString("youtube_id","").trim();String k=!y.isEmpty()?"yt|"+y:itemKey(x);if(k!=null&&!k.trim().isEmpty())seen.add(k);}
   if(startRows.length()>0)grid(startRows);
   fetchYoutubeShortsTvProgressive(1,0,seen,gen,host);
   loadExternalDoramasHome(gen);
   return;
  }
  if(seed.length()>0){prefetchGreenShortDetails(seed,24);featureCarousel(startRows);grid(startRows);startGreenShortsPaging(startRows,gen);loadExternalDoramasHome(gen);return;}
  loadInitialShortsHome(gen,host);
 }
 void loadInitialShortsHome(final int gen,final LinearLayout host){
  if(!hostValid(gen,host))return;final TextView wait=t("Carregando destaques…",14);wait.setTextColor(0xffb8aab2);wait.setGravity(Gravity.CENTER);host.addView(wait,new LinearLayout.LayoutParams(-1,dp(62)));
  Api.post("greenshorts",Api.m("user_id",uid,"page_no","1","page","1","offset","0","limit",String.valueOf(greenShortsPageSize()),"per_page",String.valueOf(greenShortsPageSize())),new Api.CB(){public void ok(JSONObject j){if(!hostValid(gen,host)||gen!=viewGen)return;if(wait.getParent()!=null)host.removeView(wait);JSONArray rows=j.optJSONArray("result");if(rows==null)rows=new JSONArray();JSONArray startRows=randomCatalogStart(rows);if(rows.length()>0){saveGreenShortsSeedCache(rows);prefetchGreenShortDetails(rows,24);featureCarousel(startRows);}grid(startRows);startGreenShortsPaging(startRows,gen);loadExternalDoramasHome(gen);}public void err(String e){if(!hostValid(gen,host)||gen!=viewGen)return;if(wait.getParent()!=null)host.removeView(wait);grid(new JSONArray());startGreenShortsPaging(new JSONArray(),gen);loadExternalDoramasHome(gen);}});
 }
 void loadExternalDoramasHome(final int gen){
  ExternalDoramas.fetchAll(new ExternalDoramas.CB(){
   public void ok(JSONArray ext){
    if(gen!=viewGen||body==null||ext==null||ext.length()==0)return;
    JSONArray hub=filterExternalSource(ext,"dramahub"), tall=filterExternalSource(ext,"dramatall");
    renderExternalSourceRow("DramaHub",hub,gen);
    renderExternalSourceRow("DramaTall",tall,gen);
   }
   public void err(String e){}
  });
 }
 JSONArray filterExternalSource(JSONArray src,String provider){
  JSONArray out=new JSONArray();if(src==null)return out;
  for(int i=0;i<src.length();i++){JSONObject x=src.optJSONObject(i);if(x!=null&&provider.equalsIgnoreCase(x.optString("provider_source","")))out.put(x);}
  return out;
 }
 void renderExternalSourceRow(String label,JSONArray rows,int gen){
  if(gen!=viewGen||body==null||rows==null||rows.length()==0)return;
  TextView h=t("Fonte:  "+label,17);h.setTypeface(null,1);h.setTextColor(GREEN);h.setPadding(dp(4),dp(14),0,dp(6));
  body.addView(h,new LinearLayout.LayoutParams(-1,dp(46)));
  posterRowInto(body,rows);
 }
 boolean isExternalDorama(JSONObject x){return x!=null&&("external".equalsIgnoreCase(x.optString("source",""))||!x.optString("provider_source","").trim().isEmpty());}
 String doramaSourceName(JSONObject x){
  if(x==null)return "Yelly";
  String p=x.optString("provider_source","").toLowerCase(java.util.Locale.ROOT);
  if("dramahub".equals(p))return "DramaHub";
  if("dramatall".equals(p))return "DramaTall";
  if(!x.optString("youtube_id","").trim().isEmpty()||"youtube".equalsIgnoreCase(x.optString("source",""))||"greenshorts".equalsIgnoreCase(x.optString("source","")))return "Yelly";
  return "Yelly";
 }
 int greenShortsPageSize(){return 60;}
 String greenShortsSeedKey(){return "greenshorts_seed_v52852";}
 JSONArray readGreenShortsSeedCache(){try{String raw=sp.getString(greenShortsSeedKey(),"");return raw.isEmpty()?new JSONArray():new JSONArray(raw);}catch(Exception e){return new JSONArray();}}
 void saveGreenShortsSeedCache(JSONArray rows){if(rows==null||rows.length()==0)return;JSONArray out=new JSONArray();for(int i=0;i<Math.min(greenShortsPageSize(),rows.length());i++){JSONObject x=rows.optJSONObject(i);if(x!=null)out.put(x);}sp.edit().putString(greenShortsSeedKey(),out.toString()).apply();}
 void startGreenShortsPaging(JSONArray first,int gen){
  if(wideTvUi()||gen!=viewGen)return;mobileCategoryGreenShorts=true;mobileCategoryTypeId=1;mobileCategoryId="__greenshorts__";mobileCategoryNextPageNo=(first!=null&&first.length()>0)?2:1;mobileCategoryNetworkTotal=0;mobileCategoryNetworkRetries=0;mobileCategoryNetworkBusy=false;mobileCategoryNetworkDone=false;mobileCategorySeen.clear();setMobileCategoryLoading(true,"Carregando mais conteúdo…");
  JSONArray seed=mobileCategoryRows==null?new JSONArray():mobileCategoryRows;for(int i=0;i<seed.length();i++){JSONObject x=seed.optJSONObject(i);if(x==null)continue;String y=x.optString("youtube_id","").trim();String k=!y.isEmpty()?"yt|"+y:itemKey(x);if(k==null||k.trim().isEmpty())k=x.optString("id",x.optString("name",""));mobileCategorySeen.add(k);}
  maybeLoadNextMobileCategoryPage();
 }
 void fetchYoutubeShortsTvProgressive(final int page,final int offset,final java.util.HashSet<String> seen,final int gen,final LinearLayout host){
  if(!hostValid(gen,host)||!wideTvUi()||gen!=viewGen)return;
  Api.post("greenshorts",Api.m("user_id",uid,"page_no",String.valueOf(page),"page",String.valueOf(page),"offset",String.valueOf(offset),"limit","120","per_page","120"),new Api.CB(){public void ok(JSONObject j){
   if(!hostValid(gen,host)||gen!=viewGen)return;
   JSONArray rows=j.optJSONArray("result");JSONArray fresh=new JSONArray();if(rows!=null)for(int i=0;i<rows.length();i++){JSONObject x=rows.optJSONObject(i);if(x==null)continue;String y=x.optString("youtube_id","").trim();String k=!y.isEmpty()?"yt|"+y:itemKey(x);if(k==null||k.trim().isEmpty())continue;if(seen.add(k))fresh.put(x);}
   if(page==1&&rows!=null&&rows.length()>0)saveGreenShortsSeedCache(rows);
   if(tvShortsGrid==null||tvShortsGridGen!=gen){if(fresh.length()>0)grid(fresh);}else if(fresh.length()>0&&tvShortsCardW>0){addGridChunk(tvShortsGrid,fresh,0,tvShortsCardW,gen);}
   boolean more=j.optBoolean("more_page",rows!=null&&rows.length()>=120);
   if(more&&rows!=null&&rows.length()>0)host.postDelayed(()->fetchYoutubeShortsTvProgressive(page+1,offset+rows.length(),seen,gen,host),35);
   else if(tvShortsGrid==null&&fresh.length()==0){TextView empty=t("Nenhum Dorama disponível no momento.",14);empty.setTextColor(0xffa79da4);empty.setGravity(Gravity.CENTER);host.addView(empty,new LinearLayout.LayoutParams(-1,dp(72)));}
  }public void err(String e){if(!hostValid(gen,host)||gen!=viewGen)return;if(tvShortsGrid==null){TextView empty=t("Não foi possível carregar os Doramas.",14);empty.setTextColor(0xffa79da4);empty.setGravity(Gravity.CENTER);host.addView(empty,new LinearLayout.LayoutParams(-1,dp(72)));}}});
 }
 void fetchYoutubeShortsPage(final int page,final int offset,final JSONArray acc,final java.util.HashSet<String> seen,final int gen,final LinearLayout host,final TextView loading){
  if(!hostValid(gen,host))return;Api.post("greenshorts",Api.m("user_id",uid,"page_no",String.valueOf(page),"page",String.valueOf(page),"offset",String.valueOf(offset),"limit","120","per_page","120"),new Api.CB(){public void ok(JSONObject j){
   if(!hostValid(gen,host))return;JSONArray rows=j.optJSONArray("result");int added=0;if(rows!=null)for(int i=0;i<rows.length();i++){JSONObject x=rows.optJSONObject(i);if(x==null)continue;String y=x.optString("youtube_id","").trim();if(y.isEmpty())continue;String k="yt|"+y;if(seen.add(k)){acc.put(x);added++;}}
   boolean more=j.optBoolean("more_page",false);if(more&&rows!=null&&rows.length()>0&&added>0){fetchYoutubeShortsPage(page+1,offset+rows.length(),acc,seen,gen,host,loading);return;}
   if(loading.getParent()!=null)host.removeView(loading);if(acc.length()==0){TextView empty=t("Nenhum Dorama disponível no momento.",14);empty.setTextColor(0xffa79da4);empty.setGravity(Gravity.CENTER);host.addView(empty,new LinearLayout.LayoutParams(-1,dp(72)));return;}grid(acc);
  }public void err(String e){if(!hostValid(gen,host))return;if(loading.getParent()!=null)host.removeView(loading);TextView empty=t("Não foi possível carregar os Doramas.",14);empty.setTextColor(0xffa79da4);empty.setGravity(Gravity.CENTER);host.addView(empty,new LinearLayout.LayoutParams(-1,dp(72)));}});
 }
 void loadEveryCategory(String type,int typeId,boolean continueWithSeries,final int gen,final LinearLayout host){
  Api.post("get_category",Api.m("type",type,"user_id",uid),new Api.CB(){public void ok(JSONObject j){if(!hostValid(gen,host))return;JSONArray cats=filterAdultCategories(j.optJSONArray("result"));if(cats==null||cats.length()==0){if(continueWithSeries)loadEveryCategory("series",2,false,gen,host);else host.addView(t("Nenhuma categoria disponível.",14));return;}loadCategoryAt(cats,0,typeId,continueWithSeries,gen,host);}public void err(String x){if(!hostValid(gen,host))return;if(continueWithSeries)loadEveryCategory("series",2,false,gen,host);else host.addView(t("Não foi possível carregar todas as categorias.",14));}});
 }
 void loadCategoryAt(JSONArray cats,int index,int typeId,boolean continueWithSeries,final int gen,final LinearLayout host){
  if(!hostValid(gen,host))return;if(index>=cats.length()){if(continueWithSeries)loadEveryCategory("series",2,false,gen,host);return;}
  JSONObject cat=cats.optJSONObject(index);if(cat==null){loadCategoryAt(cats,index+1,typeId,continueWithSeries,gen,host);return;}
  final String cid=cat.optString("category_id",cat.optString("id","")).trim();final String title=fixTitle(cat.optString("category_name",cat.optString("name",typeId==2?"Séries":"Filmes")));final int catTotal=categoryKnownTotal(cat);
  if(cid.isEmpty()){loadCategoryAt(cats,index+1,typeId,continueWithSeries,gen,host);return;}String contentType=typeId==2?"series":"movie";
  Api.post("content_by_category",Api.m("user_id",uid,"type",contentType,"category_id",cid,"page_no","1","page","1","offset","0","limit","12","per_page","12","page_size","12","full_catalog","0"),new Api.CB(){public void ok(JSONObject j){if(!hostValid(gen,host))return;JSONArray data=j.optJSONArray("result");if(data!=null&&data.length()>0){JSONObject sec=new JSONObject();try{sec.put("title",title);sec.put("category_id",cid);sec.put("type_id",typeId);if(catTotal>0)sec.put("category_total",catTotal);sec.put("data",data);}catch(Exception ignored){}sectionHeaderInto(host,categoryNameWithCount(typedCategoryTitle(title,typeId),sec),()->openSection(sec));posterRowInto(host,data);}loadCategoryAt(cats,index+1,typeId,continueWithSeries,gen,host);}public void err(String x){if(hostValid(gen,host))loadCategoryAt(cats,index+1,typeId,continueWithSeries,gen,host);}});
 }
 void openSection(JSONObject sec){
  final String returnTab=activeHomeTab;beginSectionPage(returnTab);
  int typeId=sec.optInt("type_id",sec.optInt("video_type",1));clear();setNav(0);final int gen=viewGen;String title=cleanCategoryDisplayTitle(sec.optString("title","Conteúdos"),typeId);pageTitle(title,()->closeSectionPage());
  final String cid=sec.optString("category_id","").trim();final boolean categoryComplete=categorySectionActuallyComplete(sec);final JSONArray first=sec.optJSONArray("data");
  if(!wideTvUi()){
   grid(first==null?new JSONArray():first);
   if(!cid.isEmpty()&&!categoryComplete)startMobileCategoryPaging(typeId,cid,first,gen);
   return;
  }
  if(first!=null&&first.length()>0)grid(first);
  if(cid.isEmpty()||categoryComplete)return;
  fetchAllCategoryPages(typeId,cid,new AllPagesCB(){public void ok(JSONArray full){if(gen!=viewGen||full==null||full.length()==0)return;JSONArray merged=mergeCategoryRows(first,full);if(first==null||first.length()==0){grid(merged);return;}if(merged.length()>first.length()){grid(merged);}}public void err(String e){/* Mantem a amostra e permite nova tentativa ao reabrir. */}});
 }
 void grid(JSONArray a){
  int cols=wideTvUi()?tvGridColumns():3;GridLayout g=new GridLayout(this);g.setColumnCount(cols);g.setUseDefaultMargins(false);body.addView(g,new LinearLayout.LayoutParams(-1,-2));
  int usable;if(wideTvUi()){int screen=getResources().getDisplayMetrics().widthPixels;int left=body==null?dp(28):body.getPaddingLeft();int right=body==null?dp(28):body.getPaddingRight();usable=Math.max(dp(720),screen-left-right);int gaps=dp(10)*cols;usable=Math.max(dp(720),usable-gaps);}else usable=getResources().getDisplayMetrics().widthPixels-dp(52);int w=Math.max(dp(112),usable/cols);int gen=viewGen;
  if(wideTvUi()){if("Shorts".equals(activeHomeTab)){tvShortsGrid=g;tvShortsCardW=w;tvShortsGridGen=gen;}if(a!=null&&a.length()>0)addGridChunk(g,a,0,w,gen);return;}
  mobileCategoryGrid=g;mobileCategoryRows=mergeCategoryRows(null,a);mobileCategoryNextIndex=0;mobileCategoryCardW=w;mobileCategoryGen=gen;mobileCategoryChunkPending=false;buildMobileCategoryLoadingFooter();maybeLoadMoreMobileCategory(true);
  if(mainScroll!=null)mainScroll.setOnScrollChangeListener((v,sx,sy,ox,oy)->{if(gen!=viewGen||mobileCategoryGrid!=g)return;int remaining=body==null?0:body.getHeight()-(sy+mainScroll.getHeight());if(remaining<dp(900)){maybeLoadMoreMobileCategory(false);maybeLoadNextMobileCategoryPage();}});
 }
 void buildMobileCategoryLoadingFooter(){if(body==null||wideTvUi())return;LinearLayout f=new LinearLayout(this);f.setGravity(Gravity.CENTER);f.setOrientation(LinearLayout.HORIZONTAL);f.setPadding(dp(8),dp(12),dp(8),dp(18));ProgressBar pb=new ProgressBar(this,null,android.R.attr.progressBarStyleSmall);pb.setIndeterminate(true);f.addView(pb,new LinearLayout.LayoutParams(dp(26),dp(26)));TextView tx=t("Carregando mais conteúdo…",14);tx.setTextColor(0xffb5aab1);LinearLayout.LayoutParams tlp=new LinearLayout.LayoutParams(-2,dp(32));tlp.setMargins(dp(10),0,0,0);f.addView(tx,tlp);f.setVisibility(View.GONE);body.addView(f,new LinearLayout.LayoutParams(-1,dp(62)));mobileCategoryLoadingFooter=f;mobileCategoryLoadingText=tx;mobileCategoryLoadingProgress=pb;}
 void setMobileCategoryLoading(boolean show,String text){if(mobileCategoryLoadingFooter==null)return;if(mobileCategoryLoadingText!=null&&text!=null&&!text.isEmpty())mobileCategoryLoadingText.setText(text);if(mobileCategoryLoadingProgress!=null)mobileCategoryLoadingProgress.setVisibility(show?View.VISIBLE:View.GONE);mobileCategoryLoadingFooter.setVisibility(show?View.VISIBLE:View.GONE);}
 void startMobileCategoryPaging(int typeId,String categoryId,JSONArray first,int gen){
  if(wideTvUi()||gen!=viewGen)return;mobileCategoryTypeId=typeId;mobileCategoryId=categoryId==null?"":categoryId.trim();mobileCategoryNextPageNo=(first!=null&&first.length()>0)?2:1;mobileCategoryNetworkTotal=0;mobileCategoryNetworkRetries=0;mobileCategoryNetworkBusy=false;mobileCategoryNetworkDone=mobileCategoryId.isEmpty();mobileCategorySeen.clear();setMobileCategoryLoading(!mobileCategoryNetworkDone,"Carregando mais conteúdo…");
  JSONArray seed=mobileCategoryRows==null?new JSONArray():mobileCategoryRows;for(int i=0;i<seed.length();i++){JSONObject x=seed.optJSONObject(i);if(x==null)continue;String k=itemKey(x);if(k==null||k.trim().isEmpty())k=x.optString("id",x.optString("video_id",x.optString("name","")))+"|"+x.optString("stream_url",x.optString("url",""));mobileCategorySeen.add(k);}
  maybeLoadNextMobileCategoryPage();
 }
 void maybeLoadNextMobileCategoryPage(){
  if(wideTvUi()||mobileCategoryNetworkDone||mobileCategoryNetworkBusy||mobileCategoryId==null||mobileCategoryId.isEmpty()||mobileCategoryGrid==null||mobileCategoryGen!=viewGen)return;
  final int gen=mobileCategoryGen,page=mobileCategoryNextPageNo;final String cid=mobileCategoryId;final int typeId=mobileCategoryTypeId;final boolean greenShorts=mobileCategoryGreenShorts;final int pageSize=greenShorts?greenShortsPageSize():categoryPageSize();mobileCategoryNetworkBusy=true;setMobileCategoryLoading(true,"Carregando mais conteúdo…");
  String endpoint=greenShorts?"greenshorts":"content_by_category";java.util.Map<String,String> args=greenShorts?Api.m("user_id",uid,"page_no",String.valueOf(page),"page",String.valueOf(page),"offset",String.valueOf((page-1)*pageSize),"limit",String.valueOf(pageSize),"per_page",String.valueOf(pageSize)):categoryPageArgs(typeId,cid,page,(page-1)*pageSize);
  Api.post(endpoint,args,new Api.CB(){public void ok(JSONObject j){
   if(gen!=viewGen||mobileCategoryGen!=gen)return;mobileCategoryNetworkBusy=false;mobileCategoryNetworkRetries=0;if(j.optInt("status",200)!=200){mobileCategoryNetworkDone=false;setMobileCategoryLoading(true,"Carregando mais conteúdo…");return;}
   JSONArray rows=j.optJSONArray("result");int total=categoryResponseTotal(j);if(total>0)mobileCategoryNetworkTotal=total;if(greenShorts&&page==1&&rows!=null&&rows.length()>0)saveGreenShortsSeedCache(rows);if(rows!=null)for(int i=0;i<rows.length();i++){JSONObject x=rows.optJSONObject(i);if(x==null)continue;String k;if(greenShorts){String y=x.optString("youtube_id","").trim();k=!y.isEmpty()?"yt|"+y:itemKey(x);}else k=itemKey(x);if(k==null||k.trim().isEmpty())k=x.optString("id",x.optString("video_id",x.optString("name","")))+"|"+x.optString("stream_url",x.optString("url",""));if(mobileCategorySeen.add(k))mobileCategoryRows.put(x);}
   boolean more=j.optBoolean("more_page",rows!=null&&rows.length()>=pageSize);if((mobileCategoryNetworkTotal>0&&mobileCategoryRows.length()>=mobileCategoryNetworkTotal)||!more||rows==null||rows.length()==0){mobileCategoryNetworkDone=true;}else{mobileCategoryNextPageNo=page+1;}setMobileCategoryLoading(!mobileCategoryNetworkDone,"Carregando mais conteúdo…");
   maybeLoadMoreMobileCategory(true);if(!mobileCategoryNetworkDone&&mainScroll!=null&&body!=null){int remaining=body.getHeight()-(mainScroll.getScrollY()+mainScroll.getHeight());if(remaining<dp(900))mainScroll.postDelayed(()->maybeLoadNextMobileCategoryPage(),60);}
  }public void err(String e){if(gen!=viewGen||mobileCategoryGen!=gen)return;mobileCategoryNetworkBusy=false;setMobileCategoryLoading(true,mobileCategoryNetworkRetries<2?"Carregando mais conteúdo…":"Não foi possível carregar mais. Role para tentar novamente.");if(mobileCategoryNetworkRetries<2){mobileCategoryNetworkRetries++;new Handler(Looper.getMainLooper()).postDelayed(()->maybeLoadNextMobileCategoryPage(),250L*mobileCategoryNetworkRetries);}}});
 }
 JSONArray mergeCategoryRows(JSONArray first,JSONArray full){JSONArray out=new JSONArray();java.util.HashSet<String> seen=new java.util.HashSet<>();JSONArray[] arrays={first,full};for(JSONArray a:arrays){if(a==null)continue;for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;String k=itemKey(x);if(k==null||k.trim().isEmpty())k=x.optString("id",x.optString("video_id",x.optString("name","")))+"|"+x.optString("stream_url",x.optString("url",""));if(seen.add(k))out.put(x);}}return out;}
 void maybeLoadMoreMobileCategory(boolean immediate){if(wideTvUi()||mobileCategoryChunkPending||mobileCategoryGrid==null||mobileCategoryRows==null||mobileCategoryGen!=viewGen)return;if(mobileCategoryNextIndex>=mobileCategoryRows.length())return;mobileCategoryChunkPending=true;Runnable run=()->{if(mobileCategoryGrid==null||mobileCategoryGen!=viewGen){mobileCategoryChunkPending=false;return;}int start=mobileCategoryNextIndex,len=mobileCategoryRows.length(),end=Math.min(len,start+48),h=dp(196);if(!mobileCategoryNetworkDone){int n=end-start;n-=n%3;if(n<=0){mobileCategoryChunkPending=false;maybeLoadNextMobileCategoryPage();return;}end=start+n;}else if(end>=len){int n=end-start;if(n>1&&n%3==1)end--;}boolean finalSingle=mobileCategoryNetworkDone&&start==len-1&&end==len;if(finalSingle){Space pre=new Space(this);GridLayout.LayoutParams sp=new GridLayout.LayoutParams();sp.width=mobileCategoryCardW;sp.height=dp(1);mobileCategoryGrid.addView(pre,sp);}for(int i=start;i<end;i++){JSONObject x=mobileCategoryRows.optJSONObject(i);if(x==null)continue;LinearLayout c=card(x);GridLayout.LayoutParams lp=new GridLayout.LayoutParams();lp.width=mobileCategoryCardW;lp.height=h;lp.setMargins(dp(4),dp(5),dp(6),dp(9));mobileCategoryGrid.addView(c,lp);}if(finalSingle){Space post=new Space(this);GridLayout.LayoutParams sp2=new GridLayout.LayoutParams();sp2.width=mobileCategoryCardW;sp2.height=dp(1);mobileCategoryGrid.addView(post,sp2);}mobileCategoryNextIndex=end;mobileCategoryChunkPending=false;if(mainScroll!=null&&mobileCategoryNextIndex<mobileCategoryRows.length()&&body!=null&&body.getHeight()<=mainScroll.getHeight()+dp(300))mainScroll.postDelayed(()->maybeLoadMoreMobileCategory(false),20);};if(immediate)run.run();else mobileCategoryGrid.postDelayed(run,12);}
 void addGridChunk(GridLayout g,JSONArray a,int start,int w,int gen){
  if(gen!=viewGen||g==null||g.getParent()==null)return;int end=Math.min(a.length(),start+(wideTvUi()?24:12));int h=wideTvUi()?dp(246):dp(196);
  for(int i=start;i<end;i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;LinearLayout c=card(x);GridLayout.LayoutParams lp=new GridLayout.LayoutParams();lp.width=w;lp.height=h;lp.setMargins(dp(4),dp(5),dp(6),dp(9));g.addView(c,lp);}
  if(end<a.length())g.postDelayed(()->addGridChunk(g,a,end,w,gen),16);
 }
 void refreshHomeHeaderBranding(){
  if(homeHeaderLogo==null||homeHeaderBrandFallback==null)return;
  homeHeaderLogo.setVisibility(View.VISIBLE);homeHeaderBrandFallback.setVisibility(View.GONE);applyAppLogo(homeHeaderLogo);
 }
 void homeTop(String selected){
  if(wideTvUi()){syncTvHeader(selected);return;}
  LinearLayout topWrap=new LinearLayout(this);topWrap.setOrientation(LinearLayout.VERTICAL);topWrap.setPadding(0,dp(20),0,dp(8));LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
  FrameLayout brandSlot=new FrameLayout(this);homeHeaderLogo=new ImageView(this);homeHeaderLogo.setScaleType(ImageView.ScaleType.FIT_CENTER);homeHeaderLogo.setAdjustViewBounds(true);brandSlot.addView(homeHeaderLogo,new FrameLayout.LayoutParams(-1,-1));homeHeaderBrandFallback=t("Yelly Doramas",14);homeHeaderBrandFallback.setVisibility(View.GONE);brandSlot.addView(homeHeaderBrandFallback,new FrameLayout.LayoutParams(-1,-1));LinearLayout.LayoutParams brandLp=new LinearLayout.LayoutParams(dp(128),dp(40));brandLp.setMargins(0,0,dp(10),0);top.addView(brandSlot,brandLp);refreshHomeHeaderBranding();
  LinearLayout searchBox=new LinearLayout(this);searchBox.setGravity(Gravity.CENTER_VERTICAL);searchBox.setPadding(dp(13),0,dp(5),0);GradientDrawable sBg=round(0xff23171d,21);sBg.setStroke(dp(1),0xff5a3445);searchBox.setBackground(sBg);TextView hint=t("Buscar doramas",14);hint.setTextColor(0xffc9aeb9);hint.setGravity(Gravity.CENTER_VERTICAL);hint.setSingleLine(true);hint.setPadding(0,0,0,0);searchBox.addView(hint,new LinearLayout.LayoutParams(0,dp(38),1));TextView si=t("⌕",22);si.setTextColor(Color.WHITE);si.setGravity(Gravity.CENTER);si.setPadding(0,0,0,0);searchBox.addView(si,new LinearLayout.LayoutParams(dp(34),dp(38)));searchBox.setOnClickListener(v->searchDialog());top.addView(searchBox,new LinearLayout.LayoutParams(0,dp(38),1));View cast=headerCastButton();LinearLayout.LayoutParams clp=new LinearLayout.LayoutParams(dp(44),dp(40));clp.setMargins(dp(8),0,0,0);top.addView(cast,clp);topWrap.addView(top,new LinearLayout.LayoutParams(-1,dp(42)));
  TextView label=t("Doramas & Minisséries",16);label.setTypeface(null,1);label.setTextColor(0xffffb3d2);label.setPadding(dp(2),dp(8),0,dp(4));topWrap.addView(label,new LinearLayout.LayoutParams(-1,dp(38)));
  // Yelly 1.0.45: categorias principais no topo, usando a identidade visual Yelly.
  LinearLayout yellyCats=new LinearLayout(this);yellyCats.setOrientation(LinearLayout.HORIZONTAL);yellyCats.setGravity(Gravity.CENTER);yellyCats.setPadding(0,dp(4),0,dp(8));
  ImageView filmesCat=new ImageView(this);filmesCat.setImageResource(R.drawable.yelly_cat_filmes);filmesCat.setScaleType(ImageView.ScaleType.CENTER_CROP);filmesCat.setContentDescription("Filmes Dorama");filmesCat.setFocusable(true);filmesCat.setOnClickListener(v->homeTab("Filmes"));
  ImageView seriesCat=new ImageView(this);seriesCat.setImageResource(R.drawable.yelly_cat_series);seriesCat.setScaleType(ImageView.ScaleType.CENTER_CROP);seriesCat.setContentDescription("Séries Dorama");seriesCat.setFocusable(true);seriesCat.setOnClickListener(v->homeTab("Séries"));
  ImageView turcasCat=new ImageView(this);turcasCat.setImageResource(R.drawable.yelly_cat_turcas);turcasCat.setScaleType(ImageView.ScaleType.CENTER_CROP);turcasCat.setContentDescription("Séries Turcas");turcasCat.setFocusable(true);turcasCat.setOnClickListener(v->homeTab("Turcas"));
  GradientDrawable filmesBg=round(0xff160b12,14);filmesBg.setStroke(dp(1),"Filmes".equals(selected)?0xffff4f9a:0xff4b2538);filmesCat.setBackground(filmesBg);filmesCat.setClipToOutline(true);
  GradientDrawable seriesBg=round(0xff160b12,14);seriesBg.setStroke(dp(1),"Séries".equals(selected)?0xffff4f9a:0xff4b2538);seriesCat.setBackground(seriesBg);seriesCat.setClipToOutline(true);
  GradientDrawable turcasBg=round(0xff160b12,14);turcasBg.setStroke(dp(1),"Turcas".equals(selected)?0xffff4f9a:0xff4b2538);turcasCat.setBackground(turcasBg);turcasCat.setClipToOutline(true);
  LinearLayout.LayoutParams catLp1=new LinearLayout.LayoutParams(0,dp(54),1);catLp1.setMargins(0,0,dp(5),0);yellyCats.addView(filmesCat,catLp1);
  LinearLayout.LayoutParams catLp2=new LinearLayout.LayoutParams(0,dp(54),1);catLp2.setMargins(dp(5),0,dp(5),0);yellyCats.addView(seriesCat,catLp2);
  LinearLayout.LayoutParams catLp3=new LinearLayout.LayoutParams(0,dp(54),1);catLp3.setMargins(dp(5),0,0,0);yellyCats.addView(turcasCat,catLp3);
  topWrap.addView(yellyCats,new LinearLayout.LayoutParams(-1,dp(70)));
  body.addView(topWrap,new LinearLayout.LayoutParams(-1,-2));
 }
 boolean validTopSection(JSONObject sec){
  if(sec==null||"recently_added".equals(sec.optString("section_key","")))return false;JSONArray data=sec.optJSONArray("data");if(data==null||data.length()==0)return false;String title=fixTitle(sec.optString("title",""));if(title.isEmpty())return false;String low=title.toLowerCase(java.util.Locale.ROOT);return !(low.equals("filmes")||low.equals("séries")||low.equals("series")||low.contains("adicionados recentemente")||low.equals("recentes"));
 }
 String cleanTopLabel(String s){
  if(s==null)return "";s=s.trim();if(s.isEmpty())return "";
  // Remove prefixos genéricos que já são representados pelas abas fixas Filmes/Séries.
  String out=s.replaceFirst("(?i)^\\s*(filmes?|movies?|s[eé]ries?|series)\\s*[-:|/•·–—]*\\s*","").trim();
  // Alguns painéis repetem o tipo duas vezes: "Filmes - Filmes Guerra".
  out=out.replaceFirst("(?i)^\\s*(filmes?|movies?|s[eé]ries?|series)\\s*[-:|/•·–—]*\\s*","").trim();
  if(out.isEmpty())out=s;
  return out;
 }
 String shortTopLabel(String s){if(s==null)return "Categoria";s=s.trim();return s.length()>20?s.substring(0,19)+"…":s;}
 String topSectionKey(JSONObject sec){return "sec:"+sec.optInt("type_id",sec.optInt("video_type",1))+":"+sec.optInt("category_id",0)+":"+fixTitle(sec.optString("title","")).toLowerCase(java.util.Locale.ROOT);}
 void addHomeTopMediaTab(LinearLayout tabs,int iconRes,String action,String selected){
  final boolean active=action.equals(selected)||("TV".equals(action)&&currentNavIndex==2);
  LinearLayout item=new LinearLayout(this);item.setOrientation(LinearLayout.VERTICAL);item.setGravity(Gravity.CENTER);item.setPadding(0,0,0,0);item.setClickable(true);item.setFocusable(true);item.setContentDescription(action);
  // 5.28.16: sem cartão/quadrado atrás dos ícones. O PNG é transparente
  // e o atalho fica leve, pequeno e integrado ao fundo da Home.
  item.setBackgroundColor(Color.TRANSPARENT);
  if("Shorts".equals(action))item.setContentDescription("Yelly Doramas");
  ImageView icon=new ImageView(this);icon.setImageResource(iconRes);icon.setScaleType(ImageView.ScaleType.FIT_XY);icon.setAdjustViewBounds(false);
  icon.setAlpha(active?1.0f:0.90f);
  // Cinco itens precisam caber no celular sem sobrepor. A arte de cada PNG já foi
  // normalizada para ocupar exatamente a mesma área visual.
  LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(dp(60),dp(38));ip.gravity=Gravity.CENTER;item.addView(icon,ip);
  View indicator=new View(this);indicator.setBackgroundColor(active?GREEN:Color.TRANSPARENT);LinearLayout.LayoutParams ilp=new LinearLayout.LayoutParams(dp(26),dp(2));ilp.setMargins(0,dp(1),0,0);item.addView(indicator,ilp);
  item.setOnClickListener(v->{
   if("TV".equals(action)){if(currentProviderHasLive())liveContent();else goHomeNow();}
   else if("Futebol".equals(action)){openTvFootball();}
   else homeTab(action);
  });
  LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,1);lp.setMargins(dp(2),0,dp(2),0);tabs.addView(item,lp);
 }

 void addHomeTopTab(LinearLayout tabs,String label,String action,String selected,JSONObject section){
  boolean active=action.equals(selected);TextView tv=t(label,13);tv.setSingleLine(true);tv.setGravity(Gravity.CENTER_VERTICAL);tv.setPadding(0,0,0,0);tv.setTextColor(active?GREEN:0xffb7bab8);tv.setTypeface(null,active?1:0);
  LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,dp(38));lp.setMargins(0,0,dp(18),0);tabs.addView(tv,lp);
  if(section!=null){tv.setOnClickListener(v->homeSectionTab(action,section));return;}tv.setOnClickListener(v->homeTab(action));
 }

 void featureCarousel(JSONArray a){
  if(wideTvUi()){tvFeaturedRail(a);return;}
  final HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);hs.setOverScrollMode(View.OVER_SCROLL_NEVER);hs.setClipToPadding(false);hs.setFillViewport(false);
  final LinearLayout rail=new LinearLayout(this);rail.setOrientation(LinearLayout.HORIZONTAL);final int n=Math.min(12,a.length());if(n<=0)return;
  final int contentW=Math.max(dp(300),getResources().getDisplayMetrics().widthPixels-dp(36));final int cardW=Math.min(dp(250),(int)(contentW*.68f));final int cardH=(int)(cardW*1.27f);final int gap=dp(12);final int step=cardW+gap;final int side=Math.max(dp(18),(contentW-cardW)/2);rail.setPadding(side,dp(4),side,0);hs.addView(rail,new HorizontalScrollView.LayoutParams(-2,-1));
  if(n==1){JSONObject only=a.optJSONObject(0);FrameLayout card=featureCard(only);rail.addView(card,new LinearLayout.LayoutParams(cardW,cardH));body.addView(hs,new LinearLayout.LayoutParams(-1,cardH+dp(8)));final LinearLayout oneDot=new LinearLayout(this);oneDot.setGravity(Gravity.CENTER);body.addView(oneDot,new LinearLayout.LayoutParams(-1,dp(30)));updateDots(oneDot,1,0);hs.post(()->hs.scrollTo(0,0));return;}
  // Trilho circular: clone do último antes do primeiro e clone do primeiro depois do último.
  // Assim sempre existe um card vizinho dos dois lados, inclusive nas bordas do carrossel.
  JSONObject last=a.optJSONObject(n-1);FrameLayout firstClone=featureCard(last);LinearLayout.LayoutParams cloneLp=new LinearLayout.LayoutParams(cardW,cardH);cloneLp.setMargins(0,0,gap,0);rail.addView(firstClone,cloneLp);
  for(int i=0;i<n;i++){JSONObject x=a.optJSONObject(i);FrameLayout card=featureCard(x);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(cardW,cardH);lp.setMargins(0,0,gap,0);rail.addView(card,lp);}
  JSONObject first=a.optJSONObject(0);FrameLayout lastClone=featureCard(first);LinearLayout.LayoutParams endLp=new LinearLayout.LayoutParams(cardW,cardH);rail.addView(lastClone,endLp);
  body.addView(hs,new LinearLayout.LayoutParams(-1,cardH+dp(8)));
  final LinearLayout dotBar=new LinearLayout(this);dotBar.setGravity(Gravity.CENTER);body.addView(dotBar,new LinearLayout.LayoutParams(-1,dp(30)));
  final int[] physical={1};final boolean[] touching={false};final boolean[] normalizing={false};final Handler autoHandler=new Handler(Looper.getMainLooper());final int carouselGen=viewGen;
  updateDots(dotBar,n,0);hs.post(()->hs.scrollTo(step,0));
  final Runnable[] normalize=new Runnable[1];normalize[0]=()->{if(carouselGen!=viewGen||hs.getWindowToken()==null)return;int p=physical[0];if(p==0){normalizing[0]=true;physical[0]=n;hs.scrollTo(n*step,0);normalizing[0]=false;}else if(p==n+1){normalizing[0]=true;physical[0]=1;hs.scrollTo(step,0);normalizing[0]=false;}};
  final Runnable[] auto=new Runnable[1];auto[0]=new Runnable(){public void run(){
   if(detailOpen){autoHandler.postDelayed(this,900);return;}if(carouselGen!=viewGen||hs.getWindowToken()==null)return;if(touching[0]||normalizing[0]||!hs.isShown()){autoHandler.postDelayed(this,1200);return;}
   int next=physical[0]+1;if(next>n+1)next=1;physical[0]=next;int logical=(next==n+1)?0:Math.max(0,next-1);hs.smoothScrollTo(next*step,0);updateDots(dotBar,n,logical);if(next==n+1)autoHandler.postDelayed(normalize[0],520);autoHandler.postDelayed(this,4800);
  }};
  hs.setOnTouchListener((v,e)->{int action=e.getActionMasked();if(action==MotionEvent.ACTION_DOWN){touching[0]=true;autoHandler.removeCallbacks(auto[0]);autoHandler.removeCallbacks(normalize[0]);}else if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_CANCEL){int p=Math.round(hs.getScrollX()/(float)step);p=Math.max(0,Math.min(n+1,p));physical[0]=p;int logical=p==0?n-1:(p==n+1?0:p-1);hs.smoothScrollTo(p*step,0);updateDots(dotBar,n,logical);if(p==0||p==n+1)autoHandler.postDelayed(normalize[0],520);touching[0]=false;autoHandler.removeCallbacks(auto[0]);autoHandler.postDelayed(auto[0],6200);}return false;});
  if(!tvMode)autoHandler.postDelayed(auto[0],4800);
 }
 void tvFeaturedRail(JSONArray a){
  if(a==null||a.length()==0)return;TextView heading=t("Destaques",19);heading.setTypeface(null,1);heading.setTextColor(Color.WHITE);heading.setPadding(dp(4),dp(4),0,dp(5));body.addView(heading,new LinearLayout.LayoutParams(-1,dp(38)));
  HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);hs.setOverScrollMode(View.OVER_SCROLL_NEVER);hs.setClipToPadding(false);
  LinearLayout rail=new LinearLayout(this);rail.setOrientation(LinearLayout.HORIZONTAL);rail.setPadding(dp(2),dp(2),dp(10),dp(4));
  int available=Math.max(dp(900),getResources().getDisplayMetrics().widthPixels-dp(80));int visible=Math.max(6,Math.min(8,screenWidthDp()/165));int gap=dp(12);int cardW=Math.max(dp(128),Math.min(dp(166),(available-gap*(visible-1))/visible));int cardH=(int)(cardW*1.38f);
  int n=Math.min(12,a.length());for(int i=0;i<n;i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;FrameLayout card=featureCard(x);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(cardW,cardH);lp.setMargins(0,0,gap,0);rail.addView(card,lp);}
  hs.addView(rail,new HorizontalScrollView.LayoutParams(-2,-1));body.addView(hs,new LinearLayout.LayoutParams(-1,cardH+dp(12)));
 }
 JSONArray buildFeaturedMix(JSONArray sections,int max){
  JSONArray out=new JSONArray();if(sections==null||max<=0)return out;
  java.util.ArrayList<JSONObject> movies=new java.util.ArrayList<>(),series=new java.util.ArrayList<>(),other=new java.util.ArrayList<>();java.util.HashSet<String> seen=new java.util.HashSet<>();
  for(int i=0;i<sections.length();i++){JSONObject sec=sections.optJSONObject(i);if(sec==null||adultSectionBlocked(sec)||isShortsSection(sec))continue;int type=sec.optInt("type_id",sec.optInt("video_type",1));JSONArray d=sec.optJSONArray("data");if(d==null)continue;for(int j=0;j<Math.min(12,d.length());j++){JSONObject x=d.optJSONObject(j);if(x==null)continue;String k=itemKey(x);if(!seen.add(k))continue;if(type==2)series.add(x);else if(type==1)movies.add(x);else other.add(x);}}
  long seed=System.nanoTime()^((long)(++featuredShuffleTick)*2654435761L);java.util.Random rnd=new java.util.Random(seed);java.util.Collections.shuffle(movies,rnd);java.util.Collections.shuffle(series,rnd);java.util.Collections.shuffle(other,rnd);
  int mi=0,si=0,oi=0;boolean preferSeries=(featuredShuffleTick%2)==0;
  while(out.length()<max&&(mi<movies.size()||si<series.size()||oi<other.size())){
   if(preferSeries&&si<series.size())out.put(series.get(si++));else if(!preferSeries&&mi<movies.size())out.put(movies.get(mi++));
   if(out.length()>=max)break;
   if(preferSeries&&mi<movies.size())out.put(movies.get(mi++));else if(!preferSeries&&si<series.size())out.put(series.get(si++));
   if(out.length()>=max)break;
   if(oi<other.size())out.put(other.get(oi++));
   preferSeries=!preferSeries;
   if(mi>=movies.size()&&si>=series.size()&&oi<other.size())while(out.length()<max&&oi<other.size())out.put(other.get(oi++));
   if(si>=series.size()&&mi<movies.size()&&out.length()<max)out.put(movies.get(mi++));
   if(mi>=movies.size()&&si<series.size()&&out.length()<max)out.put(series.get(si++));
  }
  return out;
 }
 void addFeaturedUnique(JSONArray out,JSONObject x,java.util.HashSet<String> seen,int max){if(x==null||out.length()>=max)return;String key=itemKey(x);if(seen.add(key))out.put(x);}
 String itemKey(JSONObject x){return x.optString("id","")+"|"+x.optString("name",x.optString("title","")).trim().toLowerCase(java.util.Locale.ROOT);}
 JSONObject firstItemFromType(JSONArray sections,int typeId){for(int i=0;i<sections.length();i++){JSONObject sec=sections.optJSONObject(i);if(sec==null||sec.optInt("type_id",sec.optInt("video_type",1))!=typeId)continue;JSONArray d=sec.optJSONArray("data");if(d!=null&&d.length()>0)return d.optJSONObject(0);}return null;}
 JSONObject firstItemFromSectionKind(JSONArray sections,int typeId,boolean launch){for(int i=0;i<sections.length();i++){JSONObject sec=sections.optJSONObject(i);if(sec==null||sec.optInt("type_id",sec.optInt("video_type",1))!=typeId)continue;String title=sec.optString("title","").toLowerCase(java.util.Locale.ROOT);boolean isLaunch=title.contains("lanç")||title.contains("lanc")||title.contains("estreia")||title.contains("novidade");if(isLaunch!=launch)continue;JSONArray d=sec.optJSONArray("data");if(d!=null&&d.length()>0)return d.optJSONObject(0);}return null;}
 JSONArray buildRecentlyAddedMovies(JSONArray sections,int max){
  JSONArray out=new JSONArray();if(sections==null||max<=0)return out;
  // O painel v68 envia uma seção dedicada, calculada por first_seen_at por provedor.
  // Assim "recentemente adicionado" significa que o item apareceu agora na fonte,
  // e não que tem ID alto ou ano de lançamento recente.
  for(int i=0;i<sections.length();i++){JSONObject sec=sections.optJSONObject(i);if(sec==null)continue;if(!"recently_added".equals(sec.optString("section_key","")))continue;JSONArray d=sec.optJSONArray("data");if(d==null)break;for(int j=0;j<Math.min(max,d.length());j++){JSONObject x=d.optJSONObject(j);if(x!=null)out.put(x);}return out;}
  java.util.ArrayList<JSONObject> list=new java.util.ArrayList<>();java.util.HashSet<String> seen=new java.util.HashSet<>();
  for(int i=0;i<sections.length();i++){JSONObject sec=sections.optJSONObject(i);if(sec==null||sec.optInt("type_id",sec.optInt("video_type",1))!=1)continue;JSONArray d=sec.optJSONArray("data");if(d==null)continue;for(int j=0;j<Math.min(24,d.length());j++){JSONObject x=d.optJSONObject(j);if(x==null||recentScore(x)<=0)continue;String key=itemKey(x);if(seen.add(key))list.add(x);}}
  java.util.Collections.sort(list,(a,b)->Long.compare(recentScore(b),recentScore(a)));
  for(int i=0;i<Math.min(max,list.size());i++)out.put(list.get(i));return out;
 }
 long recentScore(JSONObject x){
  String[] fields={"first_seen_at","source_added_at","added"};for(String f:fields){String v=x.optString(f,"").trim();if(v.matches("\\d{9,13}")){try{long n=Long.parseLong(v);return n>20000000000L?n/1000L:n;}catch(Exception ignored){}}}
  return 0L;
 }
 FrameLayout featureCard(JSONObject x){
  FrameLayout f=new FrameLayout(this);GradientDrawable outline=round(0xff211a1e,24);outline.setStroke(dp(1),0xff333032);f.setBackground(outline);f.setClipToOutline(true);f.setElevation(dp(2));
  ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);if("Shorts".equals(activeHomeTab))loadGreenShortsCover(im,x);else Img.loadBest(im,x.optString("thumbnail",""),x.optString("portrait_img",""),x.optString("image",""),x.optString("landscape",""),x.optString("landscape_img",""));f.addView(im,new FrameLayout.LayoutParams(-1,-1));
  GradientDrawable shade=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0x00000000,0x12000000,0xe0000000});View v=new View(this);v.setBackground(shade);f.addView(v,new FrameLayout.LayoutParams(-1,-1));
  String rating=x.optString("rating",x.optString("imdb_rating",x.optString("score",""))).trim();boolean hasRating=!rating.isEmpty()&&!rating.equals("0")&&!rating.equals("0.0");TextView r=t(hasRating?"★  "+formatRatingDisplay(rating):"★  —",13);r.setTypeface(null,1);r.setTextColor(hasRating?Color.WHITE:0xffa79da4);r.setGravity(Gravity.CENTER);GradientDrawable rg=round(0xc7171114,11);rg.setStroke(dp(1),hasRating?GREEN:0xff504b4e);r.setBackground(rg);FrameLayout.LayoutParams rp=new FrameLayout.LayoutParams(dp(82),dp(34),Gravity.LEFT|Gravity.BOTTOM);rp.setMargins(dp(14),0,0,dp(58));f.addView(r,rp);
  TextView name=t(x.optString("name",x.optString("title","")),17);name.setTypeface(null,1);name.setMaxLines(2);name.setEllipsize(android.text.TextUtils.TruncateAt.END);name.setGravity(Gravity.LEFT|Gravity.BOTTOM);name.setPadding(0,0,0,0);FrameLayout.LayoutParams np=new FrameLayout.LayoutParams(-1,dp(62),Gravity.BOTTOM);np.setMargins(dp(14),0,dp(12),dp(6));f.addView(name,np);f.setOnClickListener(z->details(x));f.setOnLongClickListener(z->{toggleFav(x);return true;});return f;
 }
 void updateDots(LinearLayout d,int n,int active){
  if(d.getChildCount()!=n){d.removeAllViews();for(int i=0;i<n;i++){View x=new View(this);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(8),dp(7));lp.setMargins(dp(4),dp(2),dp(4),dp(5));d.addView(x,lp);}}
  for(int i=0;i<n;i++){View x=d.getChildAt(i);if(x==null)continue;x.setBackground(round(i==active?GREEN:0xff534e51,6));LinearLayout.LayoutParams lp=(LinearLayout.LayoutParams)x.getLayoutParams();int wanted=i==active?dp(22):dp(8);if(lp.width!=wanted){lp.width=wanted;x.setLayoutParams(lp);}}
 }
 void promoLive(){
  if(!currentProviderHasLive())return;
  LinearLayout promo=new LinearLayout(this);promo.setGravity(Gravity.CENTER_VERTICAL);promo.setPadding(dp(14),dp(7),dp(12),dp(7));GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0xff351224,0xff751646});g.setCornerRadius(dp(18));promo.setBackground(g);
  TextView icon=t("▶",19);icon.setTextColor(GREEN);icon.setGravity(Gravity.CENTER);icon.setBackground(round(0x33000000,14));promo.addView(icon,new LinearLayout.LayoutParams(dp(48),dp(48)));
  LinearLayout text=new LinearLayout(this);text.setOrientation(LinearLayout.VERTICAL);text.setPadding(dp(10),0,0,0);TextView tt=t("Canais ao vivo",16);tt.setTypeface(null,1);tt.setPadding(0,0,0,0);TextView ss=t("TV em tempo real",12);ss.setTextColor(0xffd8cbd4);ss.setPadding(0,0,0,0);text.addView(tt);text.addView(ss);promo.addView(text,new LinearLayout.LayoutParams(0,-2,1));TextView ar=t("›",28);ar.setGravity(Gravity.CENTER);promo.addView(ar,new LinearLayout.LayoutParams(dp(38),dp(48)));promo.setOnClickListener(v->liveContent());LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,dp(70));pp.setMargins(dp(2),dp(6),dp(2),dp(12));body.addView(promo,pp);
 }
 void sectionHeader(String title,Runnable more){sectionHeaderInto(body,title,more);}
 void sectionHeaderInto(LinearLayout host,String title,Runnable more){LinearLayout h=new LinearLayout(this);h.setGravity(Gravity.CENTER_VERTICAL);h.setPadding(dp(2),dp(6),0,dp(1));TextView t1=t(title,18);t1.setTypeface(null,1);h.addView(t1,new LinearLayout.LayoutParams(0,dp(44),1));TextView ar=t("›",27);ar.setTextColor(GREEN);ar.setGravity(Gravity.CENTER);ar.setOnClickListener(v->more.run());h.addView(ar,new LinearLayout.LayoutParams(dp(38),dp(44)));host.addView(h);}
 void posterRow(JSONArray a){posterRowInto(body,a);}
 void posterRowInto(LinearLayout host,JSONArray a){
  if(wideTvUi()){tvPosterRowInto(host,a);return;}HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);if(a!=null)for(int i=0;i<Math.min(12,a.length());i++){JSONObject source=a.optJSONObject(i);if(source==null)continue;JSONObject x=mergeDetailJson(source,readDetailCache(source));if(x==null)x=source;final JSONObject clickItem=source;LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);im.setBackground(round(CARD,15));im.setClipToOutline(true);if("Shorts".equals(activeHomeTab))loadGreenShortsCover(im,x);else Img.loadBest(im,x.optString("thumbnail",""),x.optString("portrait_img",""),x.optString("image",""),x.optString("landscape",""),x.optString("landscape_img",""));c.addView(im,new LinearLayout.LayoutParams(-1,dp(150)));TextView n=t(x.optString("name",x.optString("title","")),12);n.setMaxLines(2);n.setEllipsize(android.text.TextUtils.TruncateAt.END);n.setPadding(dp(3),dp(5),dp(3),0);c.addView(n,new LinearLayout.LayoutParams(-1,dp(40)));c.setOnClickListener(v->details(clickItem));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(104),dp(194));cp.setMargins(dp(3),0,dp(8),0);r.addView(c,cp);}hs.addView(r);host.addView(hs,new LinearLayout.LayoutParams(-1,dp(198)));}
 void tvPosterRowInto(LinearLayout host,JSONArray a){
  HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);hs.setOverScrollMode(View.OVER_SCROLL_NEVER);LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);r.setPadding(dp(2),0,dp(10),0);int w=Math.max(dp(136),Math.min(dp(160),(getResources().getDisplayMetrics().widthPixels-dp(110))/Math.max(6,Math.min(8,screenWidthDp()/165))));int imageH=(int)(w*1.42f);if(a!=null)for(int i=0;i<Math.min(18,a.length());i++){JSONObject source=a.optJSONObject(i);if(source==null)continue;JSONObject x=mergeDetailJson(source,readDetailCache(source));if(x==null)x=source;final JSONObject clickItem=source;LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setFocusable(true);ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);im.setBackground(round(CARD,12));im.setClipToOutline(true);Img.loadBest(im,x.optString("thumbnail",""),x.optString("portrait_img",""),x.optString("image",""),x.optString("landscape",""),x.optString("landscape_img",""));c.addView(im,new LinearLayout.LayoutParams(-1,imageH));TextView n=t(x.optString("name",x.optString("title","")),13);n.setMaxLines(1);n.setEllipsize(android.text.TextUtils.TruncateAt.END);n.setPadding(dp(2),dp(6),dp(2),0);c.addView(n,new LinearLayout.LayoutParams(-1,dp(34)));c.setOnClickListener(v->details(clickItem));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(w,imageH+dp(38));cp.setMargins(0,0,dp(14),0);r.addView(c,cp);}hs.addView(r);host.addView(hs,new LinearLayout.LayoutParams(-1,(int)(w*1.42f)+dp(44)));}
 void loadContinueWatching(){Api.post("get_continue_watching",Api.m("user_id",uid),new Api.CB(){public void ok(JSONObject j){JSONArray a=j.optJSONArray("result");if(a==null||a.length()==0||continueHost==null)return;continueHost.removeAllViews();LinearLayout h=new LinearLayout(MainActivity.this);h.setGravity(Gravity.CENTER_VERTICAL);TextView ttl=t("Continue assistindo",18);ttl.setTypeface(null,1);h.addView(ttl,new LinearLayout.LayoutParams(0,dp(44),1));TextView ar=t("›",27);ar.setTextColor(GREEN);ar.setGravity(Gravity.CENTER);h.addView(ar,new LinearLayout.LayoutParams(dp(38),dp(44)));continueHost.addView(h);continueLandscapeRow(continueHost,a);}public void err(String x){}});}
 void continueLandscapeRow(LinearLayout host,JSONArray a){HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);for(int i=0;i<Math.min(8,a.length());i++){JSONObject x=a.optJSONObject(i);LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);im.setBackground(round(CARD,14));im.setClipToOutline(true);Img.loadBest(im,x.optString("landscape",""),x.optString("landscape_img",""),x.optString("thumbnail",""),x.optString("portrait_img",""),x.optString("image",""));c.addView(im,new LinearLayout.LayoutParams(-1,dp(78)));TextView n=t(x.optString("name",x.optString("title","")),12);n.setMaxLines(1);n.setEllipsize(android.text.TextUtils.TruncateAt.END);n.setPadding(dp(2),dp(4),dp(2),0);c.addView(n,new LinearLayout.LayoutParams(-1,dp(30)));c.setOnClickListener(v->details(x));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(wideTvUi()?dp(230):dp(158),wideTvUi()?dp(154):dp(126));lp.setMargins(dp(3),0,wideTvUi()?dp(14):dp(9),0);r.addView(c,lp);}hs.addView(r);host.addView(hs,new LinearLayout.LayoutParams(-1,wideTvUi()?dp(160):dp(132)));}
 void landscapeRow(JSONArray a){HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);for(int i=0;i<Math.min(8,a.length());i++){JSONObject x=a.optJSONObject(i);LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);im.setBackground(round(CARD,14));im.setClipToOutline(true);Img.loadBest(im,x.optString("landscape",""),x.optString("landscape_img",""),x.optString("thumbnail",""),x.optString("portrait_img",""),x.optString("image",""));c.addView(im,new LinearLayout.LayoutParams(-1,dp(78)));TextView n=t(x.optString("name",x.optString("title","")),12);n.setMaxLines(1);n.setEllipsize(android.text.TextUtils.TruncateAt.END);n.setPadding(dp(2),dp(4),dp(2),0);c.addView(n,new LinearLayout.LayoutParams(-1,dp(30)));c.setOnClickListener(v->details(x));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(wideTvUi()?dp(230):dp(158),wideTvUi()?dp(154):dp(126));lp.setMargins(dp(3),0,wideTvUi()?dp(14):dp(9),0);r.addView(c,lp);}hs.addView(r);body.addView(hs,new LinearLayout.LayoutParams(-1,wideTvUi()?dp(160):dp(132)));}
 void liveContent(){
  if(blockVpnProtectedContent())return;
  // v16.132: em TV/TV Box usamos uma composição de sala: listas à esquerda e player à direita.
  if(!currentProviderHasLive()&&!tvMode){goHomeNow();return;}
  if(wideTvUi()){liveContentWideTv();return;}
  createTvPageHost();clear();setNav(2);tvRootInsets();body.setPadding(0,0,0,0);

  // v16.131: o topo da TV replica a Home de verdade. Antes havia um símbolo "▣"
  // usado como voltar; além de parecer um ícone sem função, ele mudava a largura da
  // busca. Agora a TV usa a mesma marca, medidas e espaçamentos do cabeçalho da Home.
  LinearLayout top=new LinearLayout(this);tvTopBar=top;top.setGravity(Gravity.CENTER_VERTICAL);top.setPadding(dp(18),dp(1),dp(18),dp(4));
  FrameLayout brandSlot=new FrameLayout(this);brandSlot.setClickable(true);brandSlot.setFocusable(true);brandSlot.setContentDescription("Voltar ao início");brandSlot.setOnClickListener(v->goHomeNow());
  ImageView tvHeaderLogo=new ImageView(this);tvHeaderLogo.setScaleType(ImageView.ScaleType.FIT_CENTER);tvHeaderLogo.setAdjustViewBounds(true);brandSlot.addView(tvHeaderLogo,new FrameLayout.LayoutParams(-1,-1));
  TextView tvHeaderBrandFallback=t(appName==null||appName.trim().isEmpty()?"Yelly":appName.trim(),14);tvHeaderBrandFallback.setTextColor(Color.WHITE);tvHeaderBrandFallback.setTypeface(null,1);tvHeaderBrandFallback.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);tvHeaderBrandFallback.setPadding(0,0,0,0);brandSlot.addView(tvHeaderBrandFallback,new FrameLayout.LayoutParams(-1,-1));
  tvHeaderLogo.setVisibility(View.VISIBLE);tvHeaderBrandFallback.setVisibility(View.GONE);applyAppLogo(tvHeaderLogo);
  LinearLayout.LayoutParams brandLp=new LinearLayout.LayoutParams(dp(56),dp(36));brandLp.setMargins(0,0,dp(9),0);top.addView(brandSlot,brandLp);
  LinearLayout searchShell=new LinearLayout(this);searchShell.setGravity(Gravity.CENTER_VERTICAL);searchShell.setPadding(dp(13),0,dp(5),0);GradientDrawable searchBg=round(0xff292b2c,21);searchBg.setStroke(dp(1),0xff444748);searchShell.setBackground(searchBg);
  liveSearchBox=e("Buscar",false);liveSearchBox.setSingleLine(true);uiTextSize(liveSearchBox,14);liveSearchBox.setGravity(Gravity.CENTER_VERTICAL);liveSearchBox.setPadding(0,0,0,0);liveSearchBox.setMinHeight(0);liveSearchBox.setMinimumHeight(0);liveSearchBox.setBackgroundColor(Color.TRANSPARENT);liveSearchBox.setTextColor(Color.WHITE);liveSearchBox.setHintTextColor(0xffaeb2b4);liveSearchBox.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);searchShell.addView(liveSearchBox,new LinearLayout.LayoutParams(0,dp(38),1));
  TextView go=t("⌕",22);go.setGravity(Gravity.CENTER);go.setTextColor(Color.WHITE);go.setPadding(0,0,0,0);searchShell.addView(go,new LinearLayout.LayoutParams(dp(34),dp(38)));
  LinearLayout.LayoutParams searchLp=new LinearLayout.LayoutParams(0,dp(38),1);top.addView(searchShell,searchLp);if(!tvMode){View cast=headerCastButton();LinearLayout.LayoutParams clp=new LinearLayout.LayoutParams(dp(44),dp(40));clp.setMargins(dp(8),0,0,0);top.addView(cast,clp);}body.addView(top,new LinearLayout.LayoutParams(-1,dp(48)));

  tvPreviewFrame=new FrameLayout(this);tvPreviewFrame.setBackgroundColor(0xff020403);
  tvVideoBackdrop=null;tvInlinePlayerView=new androidx.media3.ui.PlayerView(this);tvInlinePlayerView.setUseController(false);tvInlinePlayerView.setResizeMode(androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FILL);tvInlinePlayerView.setShutterBackgroundColor(Color.BLACK);tvInlinePlayerView.setBackgroundColor(Color.BLACK);tvInlinePlayerView.setScaleX(1f);tvInlinePlayerView.setScaleY(1f);tvInlinePlayerView.setVisibility(View.GONE);tvPreviewFrame.addView(tvInlinePlayerView,new FrameLayout.LayoutParams(-1,-1));
  buildTvPreviewPlaceholder(false);tvPreviewFrame.addView(tvPreviewPlaceholder,new FrameLayout.LayoutParams(-1,-1));

  LinearLayout previewControls=new LinearLayout(this);previewControls.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);previewControls.setPadding(dp(6),dp(7),dp(8),0);
  tvSoundButton=t("Som",10);tvSoundButton.setGravity(Gravity.CENTER);tvSoundButton.setTextColor(Color.WHITE);tvSoundButton.setPadding(0,0,0,0);tvSoundButton.setBackground(tvPlayerControlBg());tvSoundButton.setVisibility(View.GONE);
  tvFullButton=t("Tela cheia",10);tvFullButton.setGravity(Gravity.CENTER);tvFullButton.setTextColor(Color.WHITE);tvFullButton.setPadding(0,0,0,0);tvFullButton.setBackground(tvPlayerControlBg());tvFullButton.setVisibility(View.GONE);
  previewControls.addView(tvSoundButton,new LinearLayout.LayoutParams(dp(60),dp(30)));LinearLayout.LayoutParams fbp=new LinearLayout.LayoutParams(dp(72),dp(30));fbp.setMargins(dp(5),0,0,0);previewControls.addView(tvFullButton,fbp);previewControls.setVisibility(View.GONE);tvPreviewFrame.addView(previewControls,new FrameLayout.LayoutParams(-1,dp(45),Gravity.TOP));

  LinearLayout liveInfo=new LinearLayout(this);liveInfo.setGravity(Gravity.CENTER_VERTICAL);liveInfo.setPadding(dp(12),dp(5),dp(10),dp(5));liveInfo.setVisibility(View.GONE);liveInfo.setBackgroundColor(0xcc10060b);TextView liveBadge=t("AO VIVO",9);liveBadge.setTypeface(null,1);liveBadge.setGravity(Gravity.CENTER);liveBadge.setPadding(0,0,0,0);liveBadge.setTextColor(Color.WHITE);liveBadge.setBackground(round(GREEN,6));liveInfo.addView(liveBadge,new LinearLayout.LayoutParams(dp(58),dp(25)));LinearLayout liveWords=new LinearLayout(this);liveWords.setOrientation(LinearLayout.VERTICAL);liveWords.setPadding(dp(8),0,0,0);tvNowPlaying=t("",12);tvNowPlaying.setTypeface(null,1);tvNowPlaying.setSingleLine(true);tvNowPlaying.setEllipsize(android.text.TextUtils.TruncateAt.END);tvNowPlaying.setPadding(0,0,0,0);liveWords.addView(tvNowPlaying,new LinearLayout.LayoutParams(-1,dp(20)));tvEpgNow=t("",10);tvEpgNow.setVisibility(View.GONE);tvEpgNow.setTextColor(0xffd8cbd4);tvEpgNow.setSingleLine(true);tvEpgNow.setEllipsize(android.text.TextUtils.TruncateAt.END);tvEpgNow.setPadding(0,0,0,0);liveWords.addView(tvEpgNow,new LinearLayout.LayoutParams(-1,dp(18)));tvEpgNext=t("",9);tvEpgNext.setVisibility(View.GONE);tvEpgNext.setTextColor(0xffa79da4);tvEpgNext.setSingleLine(true);tvEpgNext.setEllipsize(android.text.TextUtils.TruncateAt.END);tvEpgNext.setPadding(0,0,0,0);liveWords.addView(tvEpgNext,new LinearLayout.LayoutParams(-1,dp(17)));liveInfo.addView(liveWords,new LinearLayout.LayoutParams(0,dp(56),1));liveInfo.setTag("live_info");tvEpgOverlay=liveInfo;tvPreviewFrame.addView(liveInfo,new FrameLayout.LayoutParams(-1,dp(66),Gravity.BOTTOM));
  LinearLayout.LayoutParams prevLp=new LinearLayout.LayoutParams(-1,tvPreviewHeightPx());prevLp.setMargins(0,0,0,0);body.addView(tvPreviewFrame,prevLp);

  LinearLayout tabs=new LinearLayout(this);tvTabsBar=tabs;tabs.setGravity(Gravity.CENTER_VERTICAL);tabs.setBackgroundColor(0xff090d12);
  LinearLayout canalTab=new LinearLayout(this);canalTab.setOrientation(LinearLayout.VERTICAL);canalTab.setGravity(Gravity.CENTER);TextView canais=t("▣  Canais",12);canais.setGravity(Gravity.CENTER);canais.setPadding(0,0,0,0);View canalLine=new View(this);canalTab.addView(canais,new LinearLayout.LayoutParams(-1,dp(38)));canalTab.addView(canalLine,new LinearLayout.LayoutParams(-1,dp(3)));
  LinearLayout favTab=new LinearLayout(this);favTab.setOrientation(LinearLayout.VERTICAL);favTab.setGravity(Gravity.CENTER);TextView fav=t("♥  Favoritos",12);fav.setGravity(Gravity.CENTER);fav.setPadding(0,0,0,0);View favLine=new View(this);favTab.addView(fav,new LinearLayout.LayoutParams(-1,dp(38)));favTab.addView(favLine,new LinearLayout.LayoutParams(-1,dp(3)));
  tabs.addView(canalTab,new LinearLayout.LayoutParams(0,dp(41),1));tabs.addView(favTab,new LinearLayout.LayoutParams(0,dp(41),1));styleTvTab(canais,canalLine,true);styleTvTab(fav,favLine,false);body.addView(tabs,new LinearLayout.LayoutParams(-1,dp(41)));

  LinearLayout panes=new LinearLayout(this);tvPanesView=panes;panes.setOrientation(LinearLayout.HORIZONTAL);panes.setGravity(Gravity.TOP);panes.setPadding(0,0,0,0);
  tvCategoryScroll=new ScrollView(this);tvCategoryScroll.setFillViewport(false);tvCategoryScroll.setVerticalScrollBarEnabled(false);tvCategoryScroll.setClipToPadding(false);tvCategoryScroll.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);tvCategoryHost=new LinearLayout(this);tvCategoryHost.setOrientation(LinearLayout.VERTICAL);tvCategoryHost.setPadding(0,0,0,dp(18));tvCategoryScroll.addView(tvCategoryHost,new ScrollView.LayoutParams(-1,-2));panes.addView(tvCategoryScroll,new LinearLayout.LayoutParams(dp(tvMode?136:118),-1));
  View divider=new View(this);divider.setBackgroundColor(0xff272526);LinearLayout.LayoutParams dlp=new LinearLayout.LayoutParams(dp(1),-1);dlp.setMargins(0,0,dp(5),0);panes.addView(divider,dlp);
  tvChannelScroll=new ScrollView(this);tvChannelScroll.setFillViewport(false);tvChannelScroll.setVerticalScrollBarEnabled(false);tvChannelScroll.setClipToPadding(false);tvChannelScroll.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);tvChannelHost=new LinearLayout(this);tvChannelHost.setOrientation(LinearLayout.VERTICAL);tvChannelHost.setPadding(0,0,0,dp(18));tvChannelScroll.addView(tvChannelHost,new ScrollView.LayoutParams(-1,-2));panes.addView(tvChannelScroll,new LinearLayout.LayoutParams(0,-1,1));body.addView(panes,new LinearLayout.LayoutParams(-1,0,1));
  enableIndependentTvScroll(tvCategoryScroll);enableIndependentTvScroll(tvChannelScroll);

  View.OnClickListener showChannels=v->{styleTvTab(canais,canalLine,true);styleTvTab(fav,favLine,false);tvLoadChannels(tvSelectedCategory,"",false);};
  View.OnClickListener showFavs=v->{styleTvTab(canais,canalLine,false);styleTvTab(fav,favLine,true);tvLoadChannels("","",true);};
  canalTab.setOnClickListener(showChannels);canais.setOnClickListener(showChannels);favTab.setOnClickListener(showFavs);fav.setOnClickListener(showFavs);
  View.OnClickListener doSearch=v->{String q=liveSearchBox.getText().toString().trim();styleTvTab(canais,canalLine,true);styleTvTab(fav,favLine,false);tvLoadChannels("",q,false);};go.setOnClickListener(doSearch);liveSearchBox.setOnEditorActionListener((v,a,event)->{if(a==android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH||(tvMode&&a==android.view.inputmethod.EditorInfo.IME_ACTION_UNSPECIFIED)||isEnterKey(event)){doSearch.onClick(v);if(tvMode){hideKeyboard(liveSearchBox);requestFirstTvFocus(tvChannelHost);}return true;}return false;});if(tvMode)liveSearchBox.setOnKeyListener((v,key,event)->{if(event!=null&&event.getAction()==KeyEvent.ACTION_DOWN&&isTvConfirmKeyCode(key)){doSearch.onClick(v);hideKeyboard(liveSearchBox);requestFirstTvFocus(tvChannelHost);return true;}return false;});
  tvSoundButton.setOnClickListener(v->{showTvEpgOverlayTemporarily();toggleTvInlineMute();});tvFullButton.setOnClickListener(v->{showTvEpgOverlayTemporarily();if(tvInlineFullscreen)closeTvInlineFullscreen();else openTvInlineFullscreen();});armTvPreviewInteractions();if(tvMode){linkTvHorizontal(brandSlot,liveSearchBox);linkTvHorizontal(liveSearchBox,go);linkTvVertical(liveSearchBox,canalTab);linkTvVertical(go,favTab);linkTvHorizontal(canalTab,favTab);linkTvHorizontal(tvSoundButton,tvFullButton);}tvLoadCategories();prewarmTvLive();
 }
 void liveContentWideTv(){
  createTvPageHost();clear();setNav(2);standardRootInsets();enterTvImmersiveUi();
  // v16.150: tela TV alinhada ao modo TV real: painel de canais à esquerda
  // e EPG dentro do player, em overlay inferior, sem faixa fora do vídeo.
  body.setPadding(0,0,0,0);syncTvHeader("TV");
  LinearLayout split=new LinearLayout(this);tvWideSplit=split;tvCinemaMode=false;tvCinemaDrawerOpen=false;split.setOrientation(LinearLayout.HORIZONTAL);split.setGravity(Gravity.TOP);split.setBackgroundColor(Color.BLACK);body.addView(split,new LinearLayout.LayoutParams(-1,0,1));
  int screenW=getResources().getDisplayMetrics().widthPixels;int leftW=Math.max(dp(340),Math.min(dp(420),(int)(screenW*.275f)));

  LinearLayout left=new LinearLayout(this);tvWideLeftPanel=left;left.setOrientation(LinearLayout.VERTICAL);left.setMinimumWidth(leftW);left.setPadding(dp(16),dp(9),dp(13),dp(9));GradientDrawable leftBg=round(0xff14060d,22);leftBg.setStroke(dp(1),0xff6b1d44);left.setBackground(leftBg);tvPanesView=left;LinearLayout.LayoutParams llp=new LinearLayout.LayoutParams(leftW,-1);llp.setMargins(0,0,dp(6),0);split.addView(left,llp);
  TextView title=t("LISTA DE CANAIS",18);title.setTypeface(null,1);title.setGravity(Gravity.CENTER);title.setTextColor(Color.WHITE);LinearLayout.LayoutParams titleLp=new LinearLayout.LayoutParams(-1,dp(38));titleLp.setMargins(0,dp(3),0,dp(6));left.addView(title,titleLp);

  tvTopBar=null;tvTabsBar=null;liveSearchBox=null;
  LinearLayout searchShell=new LinearLayout(this);searchShell.setGravity(Gravity.CENTER_VERTICAL);searchShell.setPadding(dp(12),0,dp(8),0);GradientDrawable searchBg=round(0xff180b12,16);searchBg.setStroke(dp(1),0xff422a36);searchShell.setBackground(searchBg);TextView searchIcon=t("⌕",18);searchIcon.setGravity(Gravity.CENTER);searchIcon.setTextColor(0xffa0969d);searchShell.addView(searchIcon,new LinearLayout.LayoutParams(dp(28),dp(42)));liveSearchBox=e("Buscar canal",false);liveSearchBox.setSingleLine(true);uiTextSize(liveSearchBox,14);liveSearchBox.setGravity(Gravity.CENTER_VERTICAL);liveSearchBox.setPadding(dp(6),0,dp(6),0);liveSearchBox.setMinHeight(0);liveSearchBox.setMinimumHeight(0);liveSearchBox.setBackground(null);liveSearchBox.setTextColor(Color.WHITE);liveSearchBox.setHintTextColor(0xff91888e);liveSearchBox.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);liveSearchBox.setTag(TAG_SKIP_TV_FOCUS_FX,Boolean.TRUE);liveSearchBox.setFocusable(true);liveSearchBox.setFocusableInTouchMode(true);tvFocusArmed.put(liveSearchBox,Boolean.TRUE);if(liveSearch!=null&&!liveSearch.trim().isEmpty())liveSearchBox.setText(liveSearch.trim());searchShell.addView(liveSearchBox,new LinearLayout.LayoutParams(0,dp(42),1));TextView go=t("OK",11);go.setTypeface(null,1);go.setGravity(Gravity.CENTER);go.setTextColor(0xffecbdd4);GradientDrawable goBg=round(0xff201018,11);goBg.setStroke(dp(1),0xff612d47);go.setBackground(goBg);go.setTag(TAG_SKIP_TV_FOCUS_FX,Boolean.TRUE);go.setFocusable(true);go.setFocusableInTouchMode(false);tvFocusArmed.put(go,Boolean.TRUE);LinearLayout.LayoutParams goLp=new LinearLayout.LayoutParams(dp(44),dp(30));goLp.setMargins(dp(6),0,0,0);searchShell.addView(go,goLp);LinearLayout.LayoutParams searchLp=new LinearLayout.LayoutParams(-1,dp(46));searchLp.setMargins(dp(2),0,dp(2),dp(14));left.addView(searchShell,searchLp);final boolean[] searchFieldFocus={false};final boolean[] searchGoFocus={false};final Runnable[] updateSearchChrome={null};updateSearchChrome[0]=()->{boolean active=searchFieldFocus[0]||searchGoFocus[0];GradientDrawable shellBg=round(active?0xff1d0e16:0xff180b12,16);shellBg.setStroke(dp(active?2:1),active?0xffc82b79:0xff422a36);searchShell.setBackground(shellBg);searchIcon.setTextColor(active?0xfff7c9e0:0xffa0969d);GradientDrawable okBg=round(searchGoFocus[0]?0xffcf2278:0xff201018,11);okBg.setStroke(dp(1),searchGoFocus[0]?0xffee3692:0xff612d47);go.setBackground(okBg);go.setTextColor(searchGoFocus[0]?0xff10040a:0xffecbdd4);};View.OnFocusChangeListener searchFieldFx=(v,has)->{searchFieldFocus[0]=has;updateSearchChrome[0].run();if(has)v.post(()->{try{android.graphics.Rect r=new android.graphics.Rect(0,0,v.getWidth(),v.getHeight());searchShell.requestRectangleOnScreen(r,false);}catch(Exception ignored){}});};View.OnFocusChangeListener searchGoFx=(v,has)->{searchGoFocus[0]=has;updateSearchChrome[0].run();if(has)v.post(()->{try{android.graphics.Rect r=new android.graphics.Rect(0,0,searchShell.getWidth(),searchShell.getHeight());searchShell.requestRectangleOnScreen(r,false);}catch(Exception ignored){}});};liveSearchBox.setOnFocusChangeListener(searchFieldFx);go.setOnFocusChangeListener(searchGoFx);updateSearchChrome[0].run();

  tvCategoryRail=new HorizontalScrollView(this);tvCategoryRail.setHorizontalScrollBarEnabled(false);tvCategoryRail.setOverScrollMode(View.OVER_SCROLL_NEVER);tvCategoryRail.setClipToPadding(false);tvCategoryHost=new LinearLayout(this);tvCategoryHost.setOrientation(LinearLayout.HORIZONTAL);tvCategoryHost.setGravity(Gravity.CENTER_VERTICAL);tvCategoryHost.setPadding(0,dp(2),dp(8),dp(2));tvCategoryRail.addView(tvCategoryHost,new HorizontalScrollView.LayoutParams(-2,-1));LinearLayout.LayoutParams railLp=new LinearLayout.LayoutParams(-1,dp(52));railLp.setMargins(0,0,0,dp(7));left.addView(tvCategoryRail,railLp);tvCategoryScroll=null;

  tvChannelScroll=new ScrollView(this);tvChannelScroll.setFillViewport(false);tvChannelScroll.setVerticalScrollBarEnabled(false);tvChannelScroll.setClipToPadding(false);tvChannelScroll.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);tvChannelHost=new LinearLayout(this);tvChannelHost.setOrientation(LinearLayout.VERTICAL);tvChannelHost.setPadding(0,dp(4),0,dp(18));tvChannelScroll.addView(tvChannelHost,new ScrollView.LayoutParams(-1,-2));left.addView(tvChannelScroll,new LinearLayout.LayoutParams(-1,0,1));enableIndependentTvScroll(tvChannelScroll);

  LinearLayout right=new LinearLayout(this);right.setOrientation(LinearLayout.VERTICAL);right.setPadding(0,0,0,0);split.addView(right,new LinearLayout.LayoutParams(0,-1,1));
  FrameLayout stage=new FrameLayout(this);stage.setBackgroundColor(Color.BLACK);right.addView(stage,new LinearLayout.LayoutParams(-1,0,1));
  tvPreviewFrame=new FrameLayout(this);tvPreviewFrame.setBackgroundColor(Color.BLACK);tvPreviewFrame.setFocusable(true);tvPreviewFrame.setFocusableInTouchMode(false);tvPreviewFrame.setContentDescription("Player da TV ao vivo");stage.addView(tvPreviewFrame,new FrameLayout.LayoutParams(-1,-1));
  tvVideoBackdrop=null;tvInlinePlayerView=new androidx.media3.ui.PlayerView(this);tvInlinePlayerView.setUseController(false);tvInlinePlayerView.setResizeMode(androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FILL);tvInlinePlayerView.setShutterBackgroundColor(Color.BLACK);tvInlinePlayerView.setBackgroundColor(Color.BLACK);tvInlinePlayerView.setScaleX(1f);tvInlinePlayerView.setScaleY(1f);tvInlinePlayerView.setVisibility(View.GONE);tvPreviewFrame.addView(tvInlinePlayerView,new FrameLayout.LayoutParams(-1,-1));
  buildTvPreviewPlaceholder(true);tvPreviewFrame.addView(tvPreviewPlaceholder,new FrameLayout.LayoutParams(-1,-1));

  LinearLayout controls=new LinearLayout(this);controls.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);controls.setPadding(dp(8),dp(8),dp(10),0);tvSoundButton=t("Som",11);tvSoundButton.setGravity(Gravity.CENTER);tvSoundButton.setBackground(tvPlayerControlBg());tvSoundButton.setVisibility(View.GONE);tvFullButton=t("Tela cheia",11);tvFullButton.setGravity(Gravity.CENTER);tvFullButton.setBackground(tvPlayerControlBg());tvFullButton.setVisibility(View.GONE);controls.addView(tvSoundButton,new LinearLayout.LayoutParams(dp(78),dp(38)));LinearLayout.LayoutParams flp=new LinearLayout.LayoutParams(dp(108),dp(38));flp.setMargins(dp(7),0,0,0);controls.addView(tvFullButton,flp);controls.setVisibility(View.GONE);tvPreviewFrame.addView(controls,new FrameLayout.LayoutParams(-1,dp(52),Gravity.TOP));

  LinearLayout info=new LinearLayout(this);info.setGravity(Gravity.CENTER_VERTICAL);info.setPadding(dp(24),dp(14),dp(24),dp(12));info.setClipToPadding(false);GradientDrawable epgBg=new GradientDrawable();epgBg.setColor(0xf210060b);epgBg.setCornerRadii(new float[]{dp(18),dp(18),dp(18),dp(18),0,0,0,0});epgBg.setStroke(dp(1),0xff6a2b4a);info.setBackground(epgBg);info.setTag("live_info");info.setAlpha(0f);info.setVisibility(View.GONE);tvEpgOverlay=info;FrameLayout.LayoutParams infoLp=new FrameLayout.LayoutParams(-1,dp(170),Gravity.BOTTOM);infoLp.setMargins(0,0,0,0);tvPreviewFrame.addView(info,infoLp);
  LinearLayout chan=new LinearLayout(this);chan.setGravity(Gravity.CENTER_VERTICAL);chan.setPadding(0,0,dp(20),0);tvEpgLogo=new ImageView(this);tvEpgLogo.setScaleType(ImageView.ScaleType.FIT_CENTER);GradientDrawable logoBg=round(0xff191014,10);logoBg.setStroke(dp(1),0xff652846);tvEpgLogo.setBackground(logoBg);tvEpgLogo.setPadding(dp(5),dp(5),dp(5),dp(5));chan.addView(tvEpgLogo,new LinearLayout.LayoutParams(dp(62),dp(62)));LinearLayout cwords=new LinearLayout(this);cwords.setOrientation(LinearLayout.VERTICAL);cwords.setGravity(Gravity.CENTER_VERTICAL);cwords.setPadding(dp(14),0,0,0);tvNowPlaying=t("",15);tvNowPlaying.setTypeface(null,1);tvNowPlaying.setSingleLine(true);tvNowPlaying.setEllipsize(android.text.TextUtils.TruncateAt.END);tvNowPlaying.setTextColor(Color.WHITE);tvNowPlaying.setIncludeFontPadding(false);cwords.addView(tvNowPlaying,new LinearLayout.LayoutParams(-1,-2));TextView live=t("●  AO VIVO",11);live.setTextColor(0xffff5f6d);live.setTypeface(null,1);live.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);live.setIncludeFontPadding(false);LinearLayout.LayoutParams liveLp=new LinearLayout.LayoutParams(-1,-2);liveLp.setMargins(0,dp(8),0,0);cwords.addView(live,liveLp);chan.addView(cwords,new LinearLayout.LayoutParams(0,-2,1));info.addView(chan,new LinearLayout.LayoutParams(0,-1,30));
  View d1=new View(this);d1.setBackgroundColor(0xff6f3f57);LinearLayout.LayoutParams d1p=new LinearLayout.LayoutParams(dp(1),dp(74));d1p.gravity=Gravity.CENTER_VERTICAL;d1p.setMargins(0,0,dp(16),0);info.addView(d1,d1p);
  LinearLayout nowCol=new LinearLayout(this);nowCol.setOrientation(LinearLayout.VERTICAL);nowCol.setGravity(Gravity.CENTER_VERTICAL);nowCol.setPadding(0,0,dp(16),0);TextView nowLabel=t("ATUAL",12);nowLabel.setTypeface(null,1);nowLabel.setTextColor(GREEN);nowLabel.setIncludeFontPadding(false);nowCol.addView(nowLabel,new LinearLayout.LayoutParams(-1,-2));tvEpgNow=t("Sem informação",13);tvEpgNow.setTextColor(0xfff4f6f5);tvEpgNow.setMaxLines(3);tvEpgNow.setEllipsize(android.text.TextUtils.TruncateAt.END);tvEpgNow.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);tvEpgNow.setIncludeFontPadding(false);LinearLayout.LayoutParams nowTextLp=new LinearLayout.LayoutParams(-1,-2);nowTextLp.setMargins(0,dp(10),0,0);nowCol.addView(tvEpgNow,nowTextLp);info.addView(nowCol,new LinearLayout.LayoutParams(0,-1,35));
  View d2=new View(this);d2.setBackgroundColor(0xff6f3f57);LinearLayout.LayoutParams d2p=new LinearLayout.LayoutParams(dp(1),dp(74));d2p.gravity=Gravity.CENTER_VERTICAL;d2p.setMargins(0,0,dp(16),0);info.addView(d2,d2p);
  LinearLayout nextCol=new LinearLayout(this);nextCol.setOrientation(LinearLayout.VERTICAL);nextCol.setGravity(Gravity.CENTER_VERTICAL);TextView nextLabel=t("PRÓXIMO",12);nextLabel.setTypeface(null,1);nextLabel.setTextColor(GREEN);nextLabel.setIncludeFontPadding(false);nextCol.addView(nextLabel,new LinearLayout.LayoutParams(-1,-2));tvEpgNext=t("Sem informação",13);tvEpgNext.setTextColor(0xfff4f6f5);tvEpgNext.setMaxLines(3);tvEpgNext.setEllipsize(android.text.TextUtils.TruncateAt.END);tvEpgNext.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);tvEpgNext.setIncludeFontPadding(false);LinearLayout.LayoutParams nextTextLp=new LinearLayout.LayoutParams(-1,-2);nextTextLp.setMargins(0,dp(10),0,0);nextCol.addView(tvEpgNext,nextTextLp);info.addView(nextCol,new LinearLayout.LayoutParams(0,-1,35));

  View.OnClickListener doWideSearch=v->{String q=currentTvSearchQuery();tvLoadChannels(q.isEmpty()?tvSelectedCategory:"",q,false);if(tvMode){hideKeyboard(liveSearchBox);requestFirstTvFocus(tvChannelHost);}};
  go.setOnClickListener(doWideSearch);liveSearchBox.setOnEditorActionListener((v,a,event)->{if(a==android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH||(tvMode&&a==android.view.inputmethod.EditorInfo.IME_ACTION_UNSPECIFIED)||isEnterKey(event)){doWideSearch.onClick(v);return true;}return false;});if(tvMode)liveSearchBox.setOnKeyListener((v,key,event)->{if(event!=null&&event.getAction()==KeyEvent.ACTION_DOWN&&isTvConfirmKeyCode(key)){doWideSearch.onClick(v);return true;}return false;});
  final Handler wideSearchHandler=new Handler(Looper.getMainLooper());final Runnable[] wideSearchTask={null};liveSearchBox.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}public void onTextChanged(CharSequence s,int start,int before,int count){}public void afterTextChanged(android.text.Editable e){String q=e==null?"":e.toString().trim();liveSearch=q;if(wideSearchTask[0]!=null)wideSearchHandler.removeCallbacks(wideSearchTask[0]);wideSearchTask[0]=()->{if(liveSearchBox==null)return;String now=liveSearchBox.getText()==null?"":liveSearchBox.getText().toString().trim();if(!now.equals(liveSearch))return;tvLoadChannels(now.isEmpty()?tvSelectedCategory:"",now,false);};wideSearchHandler.postDelayed(wideSearchTask[0],320);}});
  tvSoundButton.setOnClickListener(v->{showTvEpgOverlayTemporarily();toggleTvInlineMute();});tvFullButton.setOnClickListener(v->{showTvEpgOverlayTemporarily();if(tvInlineFullscreen)closeTvInlineFullscreen();else openTvInlineFullscreen();});armTvPreviewInteractions();linkTvHorizontal(tvPreviewFrame,tvSoundButton);linkTvHorizontal(tvSoundButton,tvFullButton);if(tvMode){linkTvHorizontal(liveSearchBox,go);}tvAutoPlayPending=true;tvLoadCategories();prewarmTvLive();new Handler(Looper.getMainLooper()).postDelayed(()->{if(tvChannelHost!=null&&tvChannelHost.getChildCount()>0)requestTvFocus(tvChannelHost.getChildAt(0));},180);
 }
 
 void enterTvCinemaMode(){
  if(!wideTvUi()||currentNavIndex!=2||tvInlineFullscreen||tvPreviewFrame==null)return;
  tvCinemaMode=true;tvCinemaDrawerOpen=false;if(navBar!=null)navBar.setVisibility(View.GONE);if(body!=null)body.setPadding(0,body.getPaddingTop(),0,body.getPaddingBottom());
  if(tvInlinePlayerView!=null){tvInlinePlayerView.setResizeMode(androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FILL);tvInlinePlayerView.setScaleX(1f);tvInlinePlayerView.setScaleY(1f);tvInlinePlayerView.setLayoutParams(new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));}
  if(tvWideLeftPanel!=null)tvWideLeftPanel.setVisibility(View.GONE);
  if(tvWideSplit!=null){ViewGroup.LayoutParams raw=tvWideSplit.getLayoutParams();if(raw instanceof LinearLayout.LayoutParams){LinearLayout.LayoutParams lp=(LinearLayout.LayoutParams)raw;lp.setMargins(0,0,0,0);tvWideSplit.setLayoutParams(lp);}tvWideSplit.requestLayout();tvWideSplit.forceLayout();}
  if(tvPreviewFrame!=null){tvPreviewFrame.setPadding(0,0,0,0);tvPreviewFrame.requestLayout();tvPreviewFrame.forceLayout();}
  Runnable fill=()->{if(tvCinemaMode&&!tvCinemaDrawerOpen&&tvPreviewFrame!=null){try{if(tvWideSplit!=null)tvWideSplit.requestLayout();tvPreviewFrame.requestLayout();applyTvSafeSideFill(tvVideoWidth,tvVideoHeight,tvVideoPixelRatio);}catch(Exception ignored){}}};
  fill.run();if(tvInlineHandler!=null){tvInlineHandler.post(fill);tvInlineHandler.postDelayed(fill,32);tvInlineHandler.postDelayed(fill,96);tvInlineHandler.postDelayed(fill,220);}
  requestTvFocus(tvPreviewFrame);showTvEpgOverlayTemporarily();
 }
 void showTvChannelDrawer(){
  if(!wideTvUi()||currentNavIndex!=2||tvPreviewFrame==null)return;tvCinemaMode=true;tvCinemaDrawerOpen=true;if(navBar!=null)navBar.setVisibility(View.GONE);if(tvWideLeftPanel!=null)tvWideLeftPanel.setVisibility(View.VISIBLE);if(tvWideSplit!=null)tvWideSplit.requestLayout();View hit=null;if(tvChannelHost!=null){String id=tvChannelKey(tvActiveChannel);for(int i=0;i<tvChannelHost.getChildCount();i++){View c=tvChannelHost.getChildAt(i);if(c!=null&&id.equals(String.valueOf(c.getTag()))){hit=c;break;}}if(hit==null)hit=firstFocusableChild(tvChannelHost);}if(hit!=null)requestTvFocus(hit);
 }
 
 void hideTvChannelDrawer(){
  if(!tvCinemaMode)return;tvCinemaDrawerOpen=false;if(tvWideLeftPanel!=null)tvWideLeftPanel.setVisibility(View.GONE);
  if(tvWideSplit!=null){tvWideSplit.requestLayout();tvWideSplit.forceLayout();}
  Runnable fill=()->{if(tvCinemaMode&&!tvCinemaDrawerOpen&&tvPreviewFrame!=null){try{tvPreviewFrame.requestLayout();applyTvSafeSideFill(tvVideoWidth,tvVideoHeight,tvVideoPixelRatio);}catch(Exception ignored){}}};
  fill.run();if(tvInlineHandler!=null){tvInlineHandler.post(fill);tvInlineHandler.postDelayed(fill,48);tvInlineHandler.postDelayed(fill,140);}
  if(tvPreviewFrame!=null)requestTvFocus(tvPreviewFrame);showTvEpgOverlayTemporarily();
 }
 void exitTvCinemaMode(){
  tvCinemaMode=false;tvCinemaDrawerOpen=false;if(contentFrame!=null)contentFrame.setBackgroundColor(Color.TRANSPARENT);if(root!=null){root.setBackgroundColor(BG);root.setPadding(0,0,0,0);}if(body!=null){body.setVisibility(View.VISIBLE);body.setPadding(0,0,0,0);}if(navBar!=null)navBar.setVisibility(View.VISIBLE);if(tvWideLeftPanel!=null)tvWideLeftPanel.setVisibility(View.VISIBLE);if(tvWideSplit!=null){tvWideSplit.setVisibility(View.VISIBLE);tvWideSplit.requestLayout();}if(tvPanesView!=null)tvPanesView.setVisibility(View.VISIBLE);syncTvHeader("TV");View hit=tvChannelHost==null?null:firstFocusableChild(tvChannelHost);if(hit!=null)requestTvFocus(hit);else if(navTv!=null)requestTvFocus(navTv);
 }
 void styleTvWideTab(TextView v,boolean active){if(v==null)return;v.setTextColor(active?0xff11060c:0xffd7cad3);v.setTypeface(null,1);GradientDrawable g=round(active?GREEN:0xff1c1116,18);g.setStroke(dp(1),active?GREEN:0xff4b2b3b);v.setBackground(g);}
 void styleTvTab(TextView v,View indicator,boolean active){
  v.setTypeface(null,active?1:0);v.setTextColor(active?GREEN:0xffb0a5ac);v.setBackgroundColor(Color.TRANSPARENT);if(indicator!=null)indicator.setBackgroundColor(active?GREEN:Color.TRANSPARENT);
 }
 String tvFirstString(JSONObject x,String...keys){if(x==null||keys==null)return "";for(String k:keys){Object o=x.opt(k);if(o==null||o==JSONObject.NULL)continue;if(o instanceof String||o instanceof Number){String v=String.valueOf(o).trim();if(!v.isEmpty()&&!"null".equalsIgnoreCase(v))return v;}}return "";}
 String tvChannelMetaString(JSONObject x,String...keys){String v=tvFirstString(x,keys);if(!v.isEmpty())return v;if(x!=null){JSONObject raw=x.optJSONObject("source");if(raw==null)raw=x.optJSONObject("raw");v=tvFirstString(raw,keys);}return v;}
 String tvChannelName(JSONObject x){String v=tvChannelMetaString(x,"name","stream_name","channel_name","tvg-name","tvg_name");return v.isEmpty()?"Canal":v;}
 String[] tvChannelLogoCandidates(JSONObject x){
  if(x==null)return new String[0];java.util.ArrayList<String> out=new java.util.ArrayList<>();java.util.HashSet<String> seen=new java.util.HashSet<>();
  // 5.28.13: logo canônica/EPG ganha da arte declarada pela lista. Algumas fontes
  // enviam stream_icon de outra afiliada (ex.: SBT Brasília com logo da Band).
  String[] canonicalKeys={"greenplay_logo","epg_logo","tvg_logo","tvg-logo","logo_url","channel_logo","logo_alt","fallback_logo"};for(String k:canonicalKeys){String v=x.optString(k,"").trim();if(!v.isEmpty()){v=v.replace("&amp;","&").replace(" ","%20");if(seen.add(v))out.add(v);}}
  JSONObject raw=x.optJSONObject("source");if(raw==null)raw=x.optJSONObject("raw");if(raw!=null){String[] rawCanonical={"greenplay_logo","epg_logo","tvg_logo","tvg-logo","logo_url","channel_logo","logo_alt","fallback_logo"};for(String k:rawCanonical){String v=raw.optString(k,"").trim();if(!v.isEmpty()){v=v.replace("&amp;","&").replace(" ","%20");if(seen.add(v))out.add(v);}}}
  // Arte específica do canal associada pelo painel.
  String[] ownKeys={"logo","icon","channel_icon","channel_logo","logo_url","tvg_logo","tvg-logo","thumbnail","image","landscape","portrait_img","landscape_img","cover","poster"};for(String k:ownKeys){String v=x.optString(k,"").trim();if(!v.isEmpty()){v=v.replace("&amp;","&").replace(" ","%20");if(seen.add(v))out.add(v);}}
  // Fonte original só fica como último fallback, pois pode vir incorreta.
  String[] sourceKeys={"provider_icon","stream_icon","source_logo"};for(String k:sourceKeys){String v=x.optString(k,"").trim();if(!v.isEmpty()){v=v.replace("&amp;","&").replace(" ","%20");if(seen.add(v))out.add(v);}}
  if(raw!=null){String[] rawSource={"logo","icon","channel_icon","channel_logo","logo_url","tvg_logo","tvg-logo","thumbnail","image","provider_icon","stream_icon","source_logo"};for(String k:rawSource){String v=raw.optString(k,"").trim();if(!v.isEmpty()){v=v.replace("&amp;","&").replace(" ","%20");if(seen.add(v))out.add(v);}}}
  return out.toArray(new String[out.size()]);
 }
 String tvChannelLogo(JSONObject x){String[] c=tvChannelLogoCandidates(x);return c.length==0?"":c[0];}
 String tvDecodeEpgText(String raw){if(raw==null)return "";String v=raw.trim();if(v.isEmpty()||"null".equalsIgnoreCase(v))return "";try{if(v.length()>=8&&v.length()%4==0&&v.matches("[A-Za-z0-9+/]+={0,2}")){byte[] b=android.util.Base64.decode(v,android.util.Base64.DEFAULT);String d=new String(b,java.nio.charset.StandardCharsets.UTF_8).trim();int good=0,letters=0;boolean replacement=false;for(int i=0;i<d.length();i++){char c=d.charAt(i);if(c=='\uFFFD')replacement=true;if(Character.isLetterOrDigit(c))letters++;if(c=='\n'||c=='\r'||c=='\t'||c==' '||Character.isLetterOrDigit(c)||".,:;!?()[]{}+-_/&'\"%ºª–—".indexOf(c)>=0)good++;}boolean padded=v.endsWith("=");if(!replacement&&!d.isEmpty()&&letters>0&&good>=Math.max(1,(int)(d.length()*.85f))&&(padded||d.indexOf(' ')>=0))v=d;}}catch(Exception ignored){}return v.replace("&amp;","&").replace("&quot;","\"").replace("&#039;","'").trim();}
 String tvEpgTitle(JSONObject o){if(o==null)return "";String v=tvFirstString(o,"title","name","program_title","programme_title","program","programme");return tvDecodeEpgText(v);}
 long tvEpgTimestamp(JSONObject o,String...keys){String v=tvFirstString(o,keys);if(v.isEmpty())return 0;try{long n=Long.parseLong(v);if(n>0&&n<100000000000L)n*=1000L;return n;}catch(Exception ignored){}String[] fmts={"yyyy-MM-dd HH:mm:ss","yyyy-MM-dd'T'HH:mm:ssXXX","yyyy-MM-dd'T'HH:mm:ss'Z'","yyyyMMddHHmmss Z","yyyyMMddHHmmss"};for(String f:fmts){try{java.text.SimpleDateFormat df=new java.text.SimpleDateFormat(f,java.util.Locale.US);if(f.endsWith("'Z'"))df.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));java.util.Date d=df.parse(v);if(d!=null)return d.getTime();}catch(Exception ignored){}}return 0;}
 String tvFormatEpgTime(long t){if(t<=0)return "";try{return new java.text.SimpleDateFormat("HH:mm",java.util.Locale.getDefault()).format(new java.util.Date(t));}catch(Exception e){return "";}}
 boolean tvEpgNowTextIsCurrent(String value){if(value==null)return false;String v=value.trim();if(v.isEmpty())return false;try{java.util.regex.Matcher m=java.util.regex.Pattern.compile("^\\s*(\\d{1,2}):(\\d{2})\\s*[–—-]\\s*(\\d{1,2}):(\\d{2})").matcher(v);if(!m.find())return true;int sh=Integer.parseInt(m.group(1)),sm=Integer.parseInt(m.group(2)),eh=Integer.parseInt(m.group(3)),em=Integer.parseInt(m.group(4));if(sh>23||eh>23||sm>59||em>59)return true;java.util.Calendar c=java.util.Calendar.getInstance();int now=c.get(java.util.Calendar.HOUR_OF_DAY)*60+c.get(java.util.Calendar.MINUTE),start=sh*60+sm,end=eh*60+em;if(start==end)return true;if(start<end)return now>=start&&now<end;return now>=start||now<end;}catch(Exception ignored){return true;}}
 String tvEpgDisplay(JSONObject o){if(o==null)return "";String title=tvEpgTitle(o);if(title.isEmpty())return "";long st=tvEpgTimestamp(o,"start_timestamp","start_ts","start_time","start"),en=tvEpgTimestamp(o,"stop_timestamp","end_timestamp","end_ts","stop_time","end_time","stop","end");String a=tvFormatEpgTime(st),b=tvFormatEpgTime(en);if(!a.isEmpty()&&!b.isEmpty())return a+"–"+b+"  "+title;if(!a.isEmpty())return a+"  "+title;return title;}
 JSONArray tvEpgArray(JSONObject p){if(p==null)return null;String[] keys={"epg_listings","programs","programmes","listings","epg"};for(String k:keys){JSONArray a=p.optJSONArray(k);if(a!=null&&a.length()>0)return a;}Object r=p.opt("result");if(r instanceof JSONArray&&((JSONArray)r).length()>0){JSONArray ra=(JSONArray)r;JSONObject first=ra.optJSONObject(0);if(first!=null){for(String k:keys){JSONArray a=first.optJSONArray(k);if(a!=null&&a.length()>0)return a;}}return ra;}if(r instanceof JSONObject){JSONObject ro=(JSONObject)r;for(String k:keys){JSONArray a=ro.optJSONArray(k);if(a!=null&&a.length()>0)return a;}}return null;}
 String tvNormalizeMatch(String v){if(v==null)return "";String clean=v.trim().replace("&amp;","&").replace("&quot;","\"").replace("&#039;","'");String n=java.text.Normalizer.normalize(clean,java.text.Normalizer.Form.NFD).replaceAll("\\p{M}+","").toLowerCase(java.util.Locale.ROOT);return n.replaceAll("[^a-z0-9]+","").trim();}
 void tvAddMatchValue(java.util.HashSet<String> out,Object value){if(out==null||value==null||value==JSONObject.NULL)return;if(value instanceof JSONArray){JSONArray a=(JSONArray)value;for(int i=0;i<a.length();i++)tvAddMatchValue(out,a.opt(i));return;}if(value instanceof JSONObject){JSONObject o=(JSONObject)value;java.util.Iterator<String> it=o.keys();while(it.hasNext())tvAddMatchValue(out,o.opt(it.next()));return;}String raw=String.valueOf(value).trim();if(raw.isEmpty())return;try{if(raw.startsWith("[")&&raw.endsWith("]")){JSONArray a=new JSONArray(raw);tvAddMatchValue(out,a);return;}}catch(Exception ignored){}for(String part:raw.split("[|,;]")){String n=tvNormalizeMatch(part);if(!n.isEmpty())out.add(n);}}
 java.util.HashSet<String> tvChannelMatchTokens(JSONObject x){java.util.HashSet<String> out=new java.util.HashSet<>();if(x==null)return out;String[] keys={"tvg-id","tvg_id","epg_channel_id","epg_id","name","channel_name","stream_name","tvg-name","tvg_name","aliases","alias"};for(String k:keys)tvAddMatchValue(out,x.opt(k));JSONObject raw=x.optJSONObject("source");if(raw==null)raw=x.optJSONObject("raw");if(raw!=null)for(String k:keys)tvAddMatchValue(out,raw.opt(k));return out;}
 String tvAliasPayload(JSONObject x){if(x==null)return "";Object a=x.opt("aliases");if(a==null||a==JSONObject.NULL)a=x.opt("alias");JSONObject nested=x.optJSONObject("source");if(nested==null)nested=x.optJSONObject("raw");if((a==null||a==JSONObject.NULL)&&nested!=null){a=nested.opt("aliases");if(a==null||a==JSONObject.NULL)a=nested.opt("alias");}return a==null||a==JSONObject.NULL?"":String.valueOf(a);}
 boolean tvLooksLikeProgramme(JSONObject o){if(o==null)return false;return !tvEpgTitle(o).isEmpty()&&(tvEpgTimestamp(o,"start_timestamp","start_ts","start_time","start")>0||tvEpgTimestamp(o,"stop_timestamp","end_timestamp","end_ts","stop_time","end_time","stop","end")>0);}
 JSONObject tvSelectEpgPayload(JSONObject response,JSONObject channel){if(response==null)return null;Object rr=response.opt("result");if(!(rr instanceof JSONArray))return response;JSONArray a=(JSONArray)rr;if(a.length()==0)return response;JSONObject first=a.optJSONObject(0);if(first==null||tvLooksLikeProgramme(first))return response;java.util.HashSet<String> wanted=tvChannelMatchTokens(channel);if(wanted.isEmpty())return a.length()==1?first:null;for(int i=0;i<a.length();i++){JSONObject c=a.optJSONObject(i);if(c==null)continue;java.util.HashSet<String> got=tvChannelMatchTokens(c);if(got.isEmpty()&&a.length()==1)return c;for(String token:got)if(wanted.contains(token))return c;}return null;}
 String[] tvExtractEpg(JSONObject p){String now="",next="";if(p==null)return new String[]{now,next};for(String nk:new String[]{"guide","programming","epg_data"}){JSONObject nested=p.optJSONObject(nk);if(nested!=null){String[] sub=tvExtractEpg(nested);if(!sub[0].isEmpty()||!sub[1].isEmpty())return sub;}}JSONObject epgObj=p.optJSONObject("epg");if(epgObj!=null){String[] sub=tvExtractEpg(epgObj);if(!sub[0].isEmpty()||!sub[1].isEmpty())return sub;}String[] nowKeys={"epg_now_title","current_program_title","current_title","now_title","program_title","epg_now","current_program","now_program","current"};for(String k:nowKeys){Object o=p.opt(k);if(o instanceof JSONObject)now=tvEpgDisplay((JSONObject)o);else if(o!=null&&!JSONObject.NULL.equals(o))now=tvDecodeEpgText(String.valueOf(o));if(!now.isEmpty())break;}String[] nextKeys={"epg_next_title","next_program_title","next_title","up_next_title","epg_next","next_program","up_next","next"};for(String k:nextKeys){Object o=p.opt(k);if(o instanceof JSONObject)next=tvEpgDisplay((JSONObject)o);else if(o!=null&&!JSONObject.NULL.equals(o))next=tvDecodeEpgText(String.valueOf(o));if(!next.isEmpty())break;}if(!now.isEmpty()&&!now.matches("^\\d{1,2}:\\d{2}.*")){long st=tvEpgTimestamp(p,"epg_now_start_timestamp","current_start_timestamp","now_start_timestamp","epg_now_start","current_start"),en=tvEpgTimestamp(p,"epg_now_end_timestamp","current_end_timestamp","now_end_timestamp","epg_now_end","current_end");String a=tvFormatEpgTime(st),b=tvFormatEpgTime(en);if(!a.isEmpty())now=a+(!b.isEmpty()?"–"+b:"")+"  "+now;}if(!next.isEmpty()&&!next.matches("^\\d{1,2}:\\d{2}.*")){long st=tvEpgTimestamp(p,"epg_next_start_timestamp","next_start_timestamp","up_next_start_timestamp","epg_next_start","next_start"),en=tvEpgTimestamp(p,"epg_next_end_timestamp","next_end_timestamp","up_next_end_timestamp","epg_next_end","next_end");String a=tvFormatEpgTime(st),b=tvFormatEpgTime(en);if(!a.isEmpty())next=a+(!b.isEmpty()?"–"+b:"")+"  "+next;}Object rr=p.opt("result");if(rr instanceof JSONObject){String[] sub=tvExtractEpg((JSONObject)rr);if(now.isEmpty())now=sub[0];if(next.isEmpty())next=sub[1];}JSONArray a=tvEpgArray(p);if(a!=null&&a.length()>0){long t=System.currentTimeMillis();JSONObject current=null,up=null;for(int i=0;i<a.length();i++){JSONObject e=a.optJSONObject(i);if(e==null||!tvLooksLikeProgramme(e))continue;long st=tvEpgTimestamp(e,"start_timestamp","start_ts","start_time","start"),en=tvEpgTimestamp(e,"stop_timestamp","end_timestamp","end_ts","stop_time","end_time","stop","end");if(st>0&&en>0&&t>=st&&t<en){current=e;for(int k=i+1;k<a.length();k++){JSONObject cand=a.optJSONObject(k);if(cand!=null&&tvLooksLikeProgramme(cand)){up=cand;break;}}break;}if(st>t&&up==null)up=e;}String arrayNow=tvEpgDisplay(current),arrayNext=tvEpgDisplay(up);if(!arrayNow.isEmpty())now=arrayNow;if(!arrayNext.isEmpty())next=arrayNext;}return new String[]{now,next};}
 void updateTvEpgUi(String now,String next){String n=now==null?"":now.trim(),x=next==null?"":next.trim();if(tvEpgNow!=null){if(wideTvUi()){tvEpgNow.setText(n.isEmpty()?"Sem informação":n);tvEpgNow.setVisibility(View.VISIBLE);}else{tvEpgNow.setText(n.isEmpty()?"":"Agora: "+n);tvEpgNow.setVisibility(n.isEmpty()?View.GONE:View.VISIBLE);}}if(tvEpgNext!=null){if(wideTvUi()){tvEpgNext.setText(x.isEmpty()?"Sem informação":x);tvEpgNext.setVisibility(View.VISIBLE);}else{tvEpgNext.setText(x.isEmpty()?"":"Próximo: "+x);tvEpgNext.setVisibility(x.isEmpty()?View.GONE:View.VISIBLE);}}}
 void showTvEpgOverlayTemporarily(){if(tvEpgOverlay==null||tvActiveChannel==null)return;if(tvNowPlaying!=null){String no=tvFirstString(tvActiveChannel,"channel_number","stream_num","number","num","position");String name=tvChannelName(tvActiveChannel);tvNowPlaying.setText(wideTvUi()&&!no.isEmpty()?no+"  "+name:name);}if(tvEpgLogo!=null&&wideTvUi()){String[] lc=tvChannelLogoCandidates(tvActiveChannel);if(lc.length>0){tvEpgLogo.setVisibility(View.VISIBLE);Img.loadLogoBest(tvEpgLogo,lc);}else tvEpgLogo.setVisibility(View.INVISIBLE);}tvEpgOverlay.setVisibility(View.VISIBLE);tvEpgOverlay.setAlpha(1f);if(tvInlineHandler!=null){if(tvEpgHide!=null)tvInlineHandler.removeCallbacks(tvEpgHide);tvEpgHide=()->{if(tvEpgOverlay!=null){if(wideTvUi()){tvEpgOverlay.animate().alpha(0f).setDuration(180).withEndAction(()->{if(tvEpgOverlay!=null)tvEpgOverlay.setVisibility(View.GONE);}).start();}else tvEpgOverlay.setVisibility(View.GONE);}};tvInlineHandler.postDelayed(tvEpgHide,4200);}}
 void hideTvEpgOverlay(){if(tvInlineHandler!=null&&tvEpgHide!=null)tvInlineHandler.removeCallbacks(tvEpgHide);tvEpgHide=null;if(tvEpgOverlay!=null){if(wideTvUi()){tvEpgOverlay.setAlpha(0f);tvEpgOverlay.setVisibility(View.GONE);}else tvEpgOverlay.setVisibility(View.GONE);}}
 void armTvPreviewInteractions(){if(tvPreviewFrame==null||tvInlinePlayerView==null)return;View.OnClickListener tapPreview=v->{if(tvInlinePrepared&&!tvInlineFullscreen){openTvInlineFullscreen();return;}if(tvInlineFullscreen){showTvEpgOverlayTemporarily();return;}showTvEpgOverlayTemporarily();};tvPreviewFrame.setOnClickListener(tapPreview);tvInlinePlayerView.setOnClickListener(tapPreview);if(tvMode){tvPreviewFrame.setFocusable(true);tvPreviewFrame.setFocusableInTouchMode(false);armTvFocus(tvPreviewFrame);View.OnKeyListener keys=(v,key,event)->{if(event==null||event.getAction()!=KeyEvent.ACTION_DOWN)return false;showTvEpgOverlayTemporarily();if(key==KeyEvent.KEYCODE_DPAD_LEFT&&tvChannelHost!=null){if(wideTvUi()){showTvChannelDrawer();return true;}View hit=firstFocusableChild(tvChannelHost);if(hit!=null)requestTvFocus(hit);return true;}if((key==KeyEvent.KEYCODE_DPAD_CENTER||key==KeyEvent.KEYCODE_ENTER)&&v==tvPreviewFrame){if(tvInlinePrepared&&!tvInlineFullscreen){openTvInlineFullscreen();return true;}return true;}return false;};tvPreviewFrame.setOnKeyListener(keys);tvInlinePlayerView.setOnKeyListener(keys);if(tvSoundButton!=null)tvSoundButton.setOnKeyListener(keys);if(tvFullButton!=null)tvFullButton.setOnKeyListener(keys);}}
 String tvEpgCacheKey(JSONObject channel){if(channel==null)return "";String provider=Api.PROVIDER==null?"":Api.PROVIDER.trim();String cid=tvChannelKey(channel);String tvg=tvChannelMetaString(channel,"tvg-id","tvg_id","epg_channel_id","epg_id");return provider+"|"+cid+"|"+tvg;}
 String[] tvCachedEpg(JSONObject channel){String key=tvEpgCacheKey(channel);if(key.isEmpty())return null;Long at=tvEpgCacheAt.get(key);String[] e=tvEpgCache.get(key);if(at==null||e==null||android.os.SystemClock.elapsedRealtime()-at>TV_EPG_CACHE_MS){tvEpgCache.remove(key);tvEpgCacheAt.remove(key);return null;}String now=e.length>0&&e[0]!=null?e[0]:"",next=e.length>1&&e[1]!=null?e[1]:"";if(!now.isEmpty()&&!tvEpgNowTextIsCurrent(now)){tvEpgCache.remove(key);tvEpgCacheAt.remove(key);return null;}return new String[]{now,next};}
 void tvCacheEpg(JSONObject channel,String[] e){if(channel==null||e==null)return;String key=tvEpgCacheKey(channel);if(key.isEmpty())return;String now=e.length>0&&e[0]!=null?e[0]:"",next=e.length>1&&e[1]!=null?e[1]:"";if(now.isEmpty()&&next.isEmpty())return;tvEpgCache.put(key,new String[]{now,next});tvEpgCacheAt.put(key,android.os.SystemClock.elapsedRealtime());}
 java.util.Map<String,String> tvEpgArgs(JSONObject channel,int limit){String cid=tvChannelKey(channel);String tvg=tvChannelMetaString(channel,"tvg-id","tvg_id","epg_channel_id","epg_id"),name=tvChannelName(channel),streamName=tvChannelMetaString(channel,"stream_name","name","channel_name"),aliases=tvAliasPayload(channel);return Api.m("user_id",uid,"channel_id",cid,"stream_id",cid,"epg_channel_id",tvg,"epg_id",tvg,"tvg_id",tvg,"tvg-id",tvg,"name",name,"channel_name",name,"stream_name",streamName,"aliases",aliases,"limit",String.valueOf(limit));}
 void requestTvEpgEndpoint(String ep,JSONObject channel,int token){String cid=tvChannelKey(channel);if(cid.isEmpty())return;Api.post(ep,tvEpgArgs(channel,6),new Api.CB(){public void ok(JSONObject j){if(token!=tvEpgRequestToken||tvActiveChannel==null||!cid.equals(tvChannelKey(tvActiveChannel)))return;JSONObject payload=tvSelectEpgPayload(j,channel);if(payload==null)return;String[] e=tvExtractEpg(payload);if(!e[0].isEmpty()||!e[1].isEmpty()){tvCacheEpg(channel,e);updateTvEpgUi(e[0],e[1]);}}public void err(String e){}});}
 void updateTvListEpgForChannel(JSONObject channel,String now){if(channel==null||now==null||now.trim().isEmpty()||tvChannelHost==null)return;String cid=tvChannelKey(channel);if(cid.isEmpty())return;for(int i=0;i<tvChannelHost.getChildCount();i++){View card=tvChannelHost.getChildAt(i);if(card==null||!cid.equals(String.valueOf(card.getTag())))continue;View hit=card.findViewWithTag("epg_program");if(hit instanceof TextView){((TextView)hit).setText(now.trim());hit.setTag(TAG_EPG_LOADING,Boolean.FALSE);}break;}}
 void requestTvEpgTv75(JSONObject channel,int token,boolean full){String cid=tvChannelKey(channel);if(cid.isEmpty())return;String ep=full?"get_epg":"get_short_epg";Api.post(ep,tvEpgArgs(channel,full?6:3),new Api.CB(){public void ok(JSONObject j){if(token!=tvEpgRequestToken||tvActiveChannel==null||!cid.equals(tvChannelKey(tvActiveChannel)))return;JSONObject payload=tvSelectEpgPayload(j,channel);String[] e=payload==null?new String[]{"",""}:tvExtractEpg(payload);if(!e[0].isEmpty()&&!tvEpgNowTextIsCurrent(e[0]))e[0]="";if(!e[0].isEmpty()){tvCacheEpg(channel,e);updateTvEpgUi(e[0],e[1]);updateTvListEpgForChannel(channel,e[0]);return;}if(!full){requestTvEpgTv75(channel,token,true);return;}if(!e[1].isEmpty())updateTvEpgUi("",e[1]);}public void err(String e){if(!full&&token==tvEpgRequestToken)requestTvEpgTv75(channel,token,true);}});}
 void loadTvEpgForChannel(JSONObject channel){if(channel==null)return;int token=++tvEpgRequestToken;String[] local=tvExtractEpg(channel);if(!local[0].isEmpty()&&!tvEpgNowTextIsCurrent(local[0])){local[0]="";local[1]="";}String[] cached=tvCachedEpg(channel);if(cached!=null){if(!cached[0].isEmpty())local[0]=cached[0];if(!cached[1].isEmpty())local[1]=cached[1];}updateTvEpgUi(local[0],local[1]);if(cached==null)requestTvEpgTv75(channel,token,false);if(tvInlineHandler!=null){if(tvEpgBeat!=null)tvInlineHandler.removeCallbacks(tvEpgBeat);String key=tvChannelKey(channel);tvEpgBeat=()->{try{if(isFinishing()||(android.os.Build.VERSION.SDK_INT>=17&&isDestroyed()))return;if(tvActiveChannel!=null&&key.equals(tvChannelKey(tvActiveChannel)))loadTvEpgForChannel(tvActiveChannel);}catch(Exception ignored){}};tvInlineHandler.postDelayed(tvEpgBeat,60000);}}
 void prewarmTvLive(){if(tvInlineHandler==null)return;tvInlineHandler.postDelayed(()->{if(tvInlinePlayerView==null)return;try{ensureTvInlinePlayer();}catch(Exception ignored){}},120);}
 void snapTvToLiveEdge(){/* v16.135: nao fazemos seek forçado em live. Em streams TS/HLS isso pode entrar no meio de um GOP e gerar macroblocos/congelamento. */}
 void resumeTvAtLiveEdge(){if(tvInlinePlayer==null||tvActiveChannel==null)return;try{if(tvInlineSourceIndex>=0&&tvInlineSourceIndex<tvInlineSources.size()){tvStartInlineSource(tvInlineSourceIndex);return;}tvInlinePlayer.play();}catch(Exception e){if(tvInlineSourceIndex>=0&&tvInlineSourceIndex<tvInlineSources.size())tvStartInlineSource(tvInlineSourceIndex);}}
 // v16.105: TV restaurada ao comportamento funcional da v16.92.
 
 void tvLoadCategories(){
  if(tvCategoryHost==null)return;tvCategoryHost.removeAllViews();JSONObject prepared=readHomeCache();final JSONArray mem=prepared==null?null:prepared.optJSONArray("live_categories");final boolean hadMem=mem!=null&&mem.length()>0;
  if(hadMem)renderTvCategoriesFromMemory(mem);else{TextView wait=t("Carregando…",13);wait.setTextColor(0xff999096);tvCategoryHost.addView(wait);}
  final String providerAtRequest=Api.PROVIDER==null?"":Api.PROVIDER;Api.post("get_category",Api.m("type","live","user_id",uid),new Api.CB(){public void ok(JSONObject j){if(tvCategoryHost==null||!providerAtRequest.equals(Api.PROVIDER==null?"":Api.PROVIDER))return;JSONArray remote=j.optJSONArray("result");JSONArray merged=mergeLiveCategoryArrays(mem,remote);if(merged.length()==0){if(!hadMem){renderTvCategoriesFromMemory(new JSONArray());tvSelectedCategory="";tvLoadChannels("","",false);}return;}sessionHasLive=true;sessionLiveKnown=true;sp.edit().putBoolean("provider_has_live",true).apply();saveCompleteLiveCategories(merged);if(!hadMem||merged.length()!=mem.length())renderTvCategoriesFromMemory(merged);}public void err(String x){if(tvCategoryHost!=null&&!providerAtRequest.equals(Api.PROVIDER==null?"":Api.PROVIDER))return;if(!hadMem&&tvCategoryHost!=null){renderTvCategoriesFromMemory(new JSONArray());tvSelectedCategory="";tvLoadChannels("","",false);}}});
 }
 JSONArray mergeLiveCategoryArrays(JSONArray first,JSONArray second){
  JSONArray out=new JSONArray();java.util.HashSet<String> seen=new java.util.HashSet<>();JSONArray[] sets={first,second};for(JSONArray a:sets){if(a==null)continue;for(int i=0;i<a.length();i++){JSONObject c=a.optJSONObject(i);if(c==null)continue;String id=c.optString("category_id",c.optString("id",""));String name=fixTitle(c.optString("category_name",c.optString("name","")));String key=!id.isEmpty()?id:name.toLowerCase(java.util.Locale.ROOT);if(key.isEmpty()||!seen.add(key))continue;out.put(c);}}return out;
 }
 void saveCompleteLiveCategories(JSONArray cats){
  try{JSONObject cache=readHomeCache();if(cache==null)return;cache.put("live_categories",cats);saveHomeCache(cache);}catch(Exception ignored){}
 }
 void styleTvCategoryCard(View v,boolean active){
  if(v instanceof TextView){TextView chip=(TextView)v;chip.setTextColor(active?GREEN:0xffd7cad3);chip.setTypeface(null,active?1:0);GradientDrawable cg=round(active?0xff3d1529:0xff1f1218,14);cg.setStroke(dp(active?2:1),active?GREEN:0xff583144);chip.setBackground(cg);return;}
  if(!(v instanceof LinearLayout))return;LinearLayout r=(LinearLayout)v;r.setBackgroundColor(active?0xff27121c:Color.TRANSPARENT);
  if(r.getChildCount()>0){View accent=r.getChildAt(0);accent.setBackgroundColor(active?GREEN:Color.TRANSPARENT);}
  if(r.getChildCount()>1&&r.getChildAt(1) instanceof TextView)((TextView)r.getChildAt(1)).setTextColor(active?GREEN:0xffb1a6ad);
  if(r.getChildCount()>2&&r.getChildAt(2) instanceof TextView){TextView label=(TextView)r.getChildAt(2);label.setTextColor(active?GREEN:0xffcbbfc7);label.setTypeface(null,active?1:0);}
 }
 void keepTvCategoryVisible(int index){
  // v16.234: não recentraliza/ANIMA a faixa a cada toque do controle.
  // Isso era a principal fonte da "tremidinha" horizontal em Android TV/TV Box.
  if(tvCategoryRail==null||tvCategoryHost==null||index<0||index>=tvCategoryHost.getChildCount())return;final int wanted=index;tvCategoryRail.post(()->{if(tvCategoryHost==null||wanted<0||wanted>=tvCategoryHost.getChildCount())return;View v=tvCategoryHost.getChildAt(wanted);if(v==null||v.getWidth()<=0)return;int viewport=tvCategoryRail.getWidth();if(viewport<=0)return;int current=tvCategoryRail.getScrollX();int max=Math.max(0,tvCategoryHost.getWidth()-viewport);int margin=dp(18);int target=current;if(wanted<=1)target=0;else if(v.getLeft()<current+margin)target=Math.max(0,v.getLeft()-margin);else if(v.getRight()>current+viewport-margin)target=Math.min(max,v.getRight()-viewport+margin);if(target!=current)tvCategoryRail.scrollTo(target,0);});
 }
 void focusTvCategoryAt(int index){
  if(!tvMode||tvCategoryHost==null)return;int n=tvCategoryHost.getChildCount();if(n<=0)return;index=Math.max(0,Math.min(n-1,index));View target=tvCategoryHost.getChildAt(index);if(target==null)return;tvFocusedCategoryIndex=index;target.setFocusable(true);target.setFocusableInTouchMode(false);try{target.requestFocus();}catch(Exception ignored){}keepTvCategoryVisible(index);
 }
 View tvPreferredCategoryFocusView(){if(tvCategoryHost==null||tvCategoryHost.getChildCount()==0)return null;if(tvFocusedCategoryIndex>=0&&tvFocusedCategoryIndex<tvCategoryHost.getChildCount()){View v=tvCategoryHost.getChildAt(tvFocusedCategoryIndex);if(v!=null&&v.isShown())return v;}for(int i=0;i<tvCategoryHost.getChildCount();i++){View v=tvCategoryHost.getChildAt(i);if(v!=null&&tvSelectedCategory.equals(String.valueOf(v.getTag())))return v;}return tvCategoryHost.getChildAt(0);}
 void linkTvCategoryToFirstChannel(){if(!tvMode||tvChannelHost==null||tvChannelHost.getChildCount()==0)return;View first=tvChannelHost.getChildAt(0);View cat=tvPreferredCategoryFocusView();if(first==null||cat==null)return;int firstId=focusId(first),catId=focusId(cat);cat.setNextFocusDownId(firstId);first.setNextFocusUpId(catId);}

 void styleTvCategoryFocus(View v,boolean focused){
  if(!(v instanceof TextView))return;TextView chip=(TextView)v;boolean selected=tvSelectedCategory.equals(String.valueOf(v.getTag()));if(focused){chip.setTextColor(0xff11040a);chip.setTypeface(null,1);GradientDrawable g=round(GREEN,14);g.setStroke(dp(4),Color.WHITE);chip.setBackground(g);if(android.os.Build.VERSION.SDK_INT>=21)chip.setTranslationZ(dp(10));}else{if(android.os.Build.VERSION.SDK_INT>=21)chip.setTranslationZ(0);styleTvCategoryCard(chip,selected);}}
 void armTvCategoryNavigation(View chip,int pos){
  if(!tvMode||chip==null)return;tvFocusArmed.put(chip,Boolean.TRUE);chip.setFocusable(true);chip.setFocusableInTouchMode(false);focusId(chip);chip.setOnFocusChangeListener((v,has)->{styleTvCategoryFocus(v,has);if(has){tvFocusedCategoryIndex=pos;keepTvCategoryVisible(pos);linkTvCategoryToFirstChannel();}});chip.setOnKeyListener((v,key,event)->{if(event==null||event.getAction()!=KeyEvent.ACTION_DOWN)return false;int repeat=event.getRepeatCount();if(key==KeyEvent.KEYCODE_DPAD_CENTER||key==KeyEvent.KEYCODE_ENTER||key==KeyEvent.KEYCODE_NUMPAD_ENTER){if(repeat==0)v.performClick();return true;}if(key==KeyEvent.KEYCODE_DPAD_UP){if(navTv!=null)requestTvFocus(navTv);return true;}if(key==KeyEvent.KEYCODE_DPAD_DOWN){View first=firstFocusableChild(tvChannelHost);if(first!=null)requestTvFocus(first);return true;}return false;});
 }
 void wireTvCategoryHorizontalFocus(){if(!tvMode||tvCategoryHost==null)return;int n=tvCategoryHost.getChildCount();for(int i=0;i<n;i++){View cur=tvCategoryHost.getChildAt(i);if(cur==null)continue;int self=focusId(cur);View l=i>0?tvCategoryHost.getChildAt(i-1):cur;View r=i+1<n?tvCategoryHost.getChildAt(i+1):cur;cur.setNextFocusLeftId(l==null?self:focusId(l));cur.setNextFocusRightId(r==null?self:focusId(r));}}
 void renderTvCategoriesFromMemory(JSONArray a){a=filterAdultCategories(a);
  if(tvCategoryHost==null)return;tvCategoryHost.removeAllViews();
  if(wideTvUi()){
   tvCategoryHost.setOrientation(LinearLayout.HORIZONTAL);String previous=tvSelectedCategory==null?"":tvSelectedCategory;boolean previousExists=previous.isEmpty();for(int i=0;i<a.length();i++){JSONObject c=a.optJSONObject(i);if(c==null)continue;String id=c.optString("category_id",c.optString("id",""));if(id.equals(previous))previousExists=true;}if(!previousExists)previous="";tvSelectedCategory=previous;tvFocusedCategoryIndex=-1;
   int childPos=0;TextView allChip=t("TODOS",11);allChip.setSingleLine(true);allChip.setGravity(Gravity.CENTER);allChip.setTag("");styleTvCategoryCard(allChip,tvSelectedCategory.isEmpty());LinearLayout.LayoutParams allLp=new LinearLayout.LayoutParams(dp(78),dp(46));allLp.setMargins(0,0,dp(8),0);tvCategoryHost.addView(allChip,allLp);final int allPos=childPos++;allChip.setOnClickListener(v->{boolean changed=!tvSelectedCategory.isEmpty();tvSelectedCategory="";tvFocusedCategoryIndex=allPos;for(int k=0;k<tvCategoryHost.getChildCount();k++){View cv=tvCategoryHost.getChildAt(k);styleTvCategoryCard(cv,tvSelectedCategory.equals(String.valueOf(cv.getTag())));if(cv.hasFocus())styleTvCategoryFocus(cv,true);}keepTvCategoryVisible(allPos);if(changed)tvLoadChannels("",currentTvSearchQuery(),false);});armTvCategoryNavigation(allChip,allPos);
   for(int i=0;i<a.length();i++){JSONObject c=a.optJSONObject(i);if(c==null)continue;String id=c.optString("category_id",c.optString("id",""));if(id.isEmpty())continue;String name=fixTitle(c.optString("category_name",c.optString("name","Canais")));TextView chip=t(name,11);chip.setSingleLine(true);chip.setEllipsize(android.text.TextUtils.TruncateAt.END);chip.setGravity(Gravity.CENTER);chip.setPadding(dp(7),0,dp(7),0);chip.setTag(id);styleTvCategoryCard(chip,id.equals(tvSelectedCategory));int chipW=Math.max(dp(118),Math.min(dp(172),dp(64)+name.length()*dp(5)));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(chipW,dp(46));lp.setMargins(0,0,dp(8),0);tvCategoryHost.addView(chip,lp);final int pos=childPos++;chip.setOnClickListener(v->{String picked=String.valueOf(v.getTag());boolean changed=!picked.equals(tvSelectedCategory);tvSelectedCategory=picked;tvFocusedCategoryIndex=pos;for(int k=0;k<tvCategoryHost.getChildCount();k++){View cview=tvCategoryHost.getChildAt(k);styleTvCategoryCard(cview,tvSelectedCategory.equals(String.valueOf(cview.getTag())));if(cview.hasFocus())styleTvCategoryFocus(cview,true);}keepTvCategoryVisible(pos);if(changed)tvLoadChannels(picked,currentTvSearchQuery(),false);});armTvCategoryNavigation(chip,pos);}
   wireTvCategoryHorizontalFocus();if(tvCategoryHost.getChildCount()>0){View first=tvCategoryHost.getChildAt(0);if(liveSearchBox!=null)linkTvVertical(liveSearchBox,first);}
   if(tvPendingCategoryHint!=null&&!tvPendingCategoryHint.isEmpty()){String hint=tvPendingCategoryHint;tvCategoryHost.postDelayed(()->selectTvCategoryByHint(hint),80);}
   if(!tvSelectedCategory.isEmpty())tvLoadChannels(tvSelectedCategory,currentTvSearchQuery(),false);else tvLoadChannels("",currentTvSearchQuery(),false);return;
  }
  tvCategoryHost.setOrientation(LinearLayout.VERTICAL);for(int i=0;i<a.length();i++){JSONObject c=a.optJSONObject(i);if(c==null)continue;String id=c.optString("category_id",c.optString("id",""));String name=fixTitle(c.optString("category_name",c.optString("name","Canais")));
   LinearLayout item=new LinearLayout(this);item.setGravity(Gravity.CENTER_VERTICAL);item.setPadding(0,dp(3),dp(5),dp(3));View accent=new View(this);item.addView(accent,new LinearLayout.LayoutParams(dp(3),-1));TextView ico=t("▶",10);ico.setGravity(Gravity.CENTER);ico.setPadding(0,0,0,0);item.addView(ico,new LinearLayout.LayoutParams(dp(28),dp(46)));TextView label=t(name,12);label.setMaxLines(2);label.setEllipsize(android.text.TextUtils.TruncateAt.END);label.setGravity(Gravity.CENTER_VERTICAL);label.setPadding(dp(1),0,0,0);item.addView(label,new LinearLayout.LayoutParams(0,dp(46),1));item.setTag(id);styleTvCategoryCard(item,i==0);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(54));lp.setMargins(0,0,0,dp(1));tvCategoryHost.addView(item,lp);final int pos=i;item.setOnClickListener(v->{for(int k=0;k<tvCategoryHost.getChildCount();k++)styleTvCategoryCard(tvCategoryHost.getChildAt(k),k==pos);tvSelectedCategory=id;tvLoadChannels(id,"",false);});if(i==0)tvSelectedCategory=id;
  }tvLoadChannels(tvSelectedCategory,currentTvSearchQuery(),false);if(tvMode&&tvCategoryHost.getChildCount()>0){View first=tvCategoryHost.getChildAt(0);if(tvTabsBar instanceof ViewGroup&&((ViewGroup)tvTabsBar).getChildCount()>0)linkTvVertical(((ViewGroup)tvTabsBar).getChildAt(0),first);}
 }
 boolean isRealLiveChannel(JSONObject x){
  if(x==null)return false;
  String kind=(x.optString("stream_type",x.optString("content_type",x.optString("media_type",x.optString("type",""))))).trim().toLowerCase(java.util.Locale.ROOT);
  if(kind.contains("movie")||kind.contains("vod")||kind.contains("series")||kind.contains("episode")||kind.contains("short"))return false;
  int typeId=x.optInt("type_id",0),videoType=x.optInt("video_type",0);
  boolean explicitLive=kind.contains("live")||kind.contains("channel")||kind.equals("tv")||kind.equals("stream");
  if(!explicitLive&&(typeId==1||typeId==2||videoType==1||videoType==2))return false;
  String u=tvLiveUrl(x).trim().toLowerCase(java.util.Locale.ROOT);
  if(u.contains("/movie/")||u.contains("/series/")||u.contains("/episode/"))return false;
  String ext=x.optString("video_extension",x.optString("container_extension","")).trim().toLowerCase(java.util.Locale.ROOT);
  if(!explicitLive&&(ext.equals("mp4")||ext.equals("mkv")||ext.equals("avi")||ext.equals("mov")||ext.equals("webm")))return false;
  if(explicitLive)return !u.isEmpty();
  if(u.contains("/live/")||u.contains(".m3u8")||u.matches(".*\\.ts(?:\\?.*)?$"))return true;
  String tvg=tvFirstString(x,"tvg-id","tvg_id","epg_channel_id","epg_id","channel_number","stream_num");
  return !u.isEmpty();
 }
 JSONArray sanitizeLiveChannels(JSONArray src){
  JSONArray out=new JSONArray();if(src==null)return out;java.util.HashSet<String> seen=new java.util.HashSet<>();
  for(int i=0;i<src.length();i++){JSONObject x=src.optJSONObject(i);if(!isRealLiveChannel(x))continue;String k=tvChannelKey(x);if(k.isEmpty())k=tvLiveUrl(x)+"|"+tvChannelName(x);if(seen.add(k))out.put(x);}return out;
 }
 JSONArray filterLiveSnapshot(String categoryId,String search){JSONArray out=new JSONArray();JSONObject prepared=readHomeCache();JSONArray all=prepared==null?null:prepared.optJSONArray("live_channels");if(all==null)return out;java.util.HashSet<String> blocked=adultLiveCategoryIds();String needle=search==null?"":search.trim().toLowerCase(java.util.Locale.ROOT);for(int i=0;i<all.length();i++){JSONObject x=all.optJSONObject(i);if(!isRealLiveChannel(x)||adultLiveBlocked(x,blocked))continue;if(categoryId!=null&&!categoryId.isEmpty()&&!categoryId.equals(x.optString("category_id","")))continue;String name=x.optString("name","").toLowerCase(java.util.Locale.ROOT);if(!needle.isEmpty()&&!name.contains(needle))continue;out.put(x);}return out;}
 void resetTvChannelListPosition(){if(tvChannelScroll==null)return;try{tvChannelScroll.scrollTo(0,0);}catch(Exception ignored){}tvChannelScroll.post(()->{try{if(tvChannelScroll!=null)tvChannelScroll.scrollTo(0,0);}catch(Exception ignored){}});}
 void keepTvChannelVisible(View v){if(!tvMode||tvChannelScroll==null||v==null)return;try{int viewport=tvChannelScroll.getHeight();if(viewport<=0)return;int current=tvChannelScroll.getScrollY();int margin=dp(12);int top=v.getTop(),bottom=v.getBottom();int target=current;if(top<current+margin)target=Math.max(0,top-margin);else if(bottom>current+viewport-margin)target=Math.max(0,bottom-viewport+margin);if(target!=current)tvChannelScroll.scrollTo(0,target);}catch(Exception ignored){}}
 void tvLoadChannels(String categoryId,String search,boolean favoritesOnly){
  if(tvChannelHost==null)return;final int listGen=++tvChannelListGeneration;tvChannelChunkPending=false;if(tvChannelRefreshTask!=null){try{tvChannelHost.removeCallbacks(tvChannelRefreshTask);}catch(Exception ignored){}tvChannelRefreshTask=null;}resetTvChannelListPosition();tvChannelHost.removeAllViews();
  if(favoritesOnly){JSONArray a=liveFavArray();if(a.length()==0){TextView m=t("Nenhum canal favorito",14);m.setTextColor(0xffa399a0);m.setGravity(Gravity.CENTER);m.setPadding(dp(8),dp(20),dp(8),dp(20));tvChannelHost.addView(m);return;}renderTvChannelsChunk(tvChannelHost,a,0,listGen);resetTvChannelListPosition();return;}
  // v5.27: se o bootstrap já trouxe canais ao vivo, usa essa fotografia imediatamente.
  // Xtream não precisa esperar buscar novamente 10+ páginas para abrir uma categoria.
  // Assim não substitui os canais enriquecidos por uma resposta posterior e a troca fica instantânea.
  JSONObject prepared=readHomeCache();JSONArray preparedLive=prepared==null?null:sanitizeLiveChannels(prepared.optJSONArray("live_channels"));if(preparedLive!=null&&preparedLive.length()>0){JSONArray a=filterLiveSnapshot(categoryId,search);if(a.length()>0){sessionHasLive=true;sessionLiveKnown=true;renderTvChannelsChunk(tvChannelHost,a,0,listGen);resetTvChannelListPosition();return;}TextView m=t(search!=null&&!search.trim().isEmpty()?"Nenhum canal encontrado.":"Nenhum canal nesta categoria.",14);m.setTextColor(0xffa399a0);m.setGravity(Gravity.CENTER);m.setPadding(dp(8),dp(20),dp(8),dp(20));tvChannelHost.addView(m);resetTvChannelListPosition();return;}
  TextView wait=t("Carregando canais…",13);wait.setTextColor(0xff999096);wait.setGravity(Gravity.CENTER);wait.setPadding(dp(8),dp(20),dp(8),dp(20));tvChannelHost.addView(wait);
  tvLoadChannelsDirect(categoryId,search,categoryId!=null&&!categoryId.isEmpty()&&(search==null||search.trim().isEmpty()),listGen);
 }
 
 void tvLoadChannelsDirect(String categoryId,String search,boolean retryAll,int listGen){
  if(listGen!=tvChannelListGeneration)return;final String providerAtRequest=Api.PROVIDER==null?"":Api.PROVIDER;String cat=categoryId==null?"":categoryId;String q=search==null?"":search;
  fetchLiveChannelPagesProgressive(cat,q,false,0,new JSONArray(),new java.util.HashSet<String>(),providerAtRequest,listGen,retryAll);
 }
 void fetchLiveChannelPagesProgressive(String cat,String q,boolean typed,int offset,JSONArray acc,java.util.HashSet<String> seen,String providerAtRequest,int listGen,boolean retryAll){
  if(listGen!=tvChannelListGeneration||tvChannelHost==null||!providerAtRequest.equals(Api.PROVIDER==null?"":Api.PROVIDER))return;
  final int pageSize=100;java.util.Map<String,String> args=Api.m("user_id",uid,"category_id",cat,"limit",String.valueOf(pageSize),"offset",String.valueOf(offset),"search",q);if(typed)args.put("type","live");
  Api.post("get_channel",args,new Api.CB(){public void ok(JSONObject j){
   if(listGen!=tvChannelListGeneration||tvChannelHost==null||!providerAtRequest.equals(Api.PROVIDER==null?"":Api.PROVIDER))return;
   if(j.optInt("status",200)!=200){if(acc.length()==0){if(!typed)tvLoadChannelsTypedFallback(cat,q,retryAll,providerAtRequest,listGen);else tvShowNoLiveResult(q,providerAtRequest,listGen);}return;}
   JSONArray rows=j.optJSONArray("result");if(rows==null||rows.length()==0){if(acc.length()==0){if(!typed)tvLoadChannelsTypedFallback(cat,q,retryAll,providerAtRequest,listGen);else tvShowNoLiveResult(q,providerAtRequest,listGen);}return;}
   int before=acc.length();for(int i=0;i<rows.length();i++){JSONObject x=rows.optJSONObject(i);if(!isRealLiveChannel(x))continue;String key=tvChannelKey(x);if(key==null||key.trim().isEmpty())key=x.optString("stream_url",x.optString("url",""))+"|"+tvChannelName(x);if(seen.add(key))acc.put(x);}
   if(acc.length()>before){
    if(before==0)tvRenderLiveResult(providerAtRequest,acc,listGen);
    else{JSONArray clean=sanitizeLiveChannels(acc);int rendered=tvCurrentChannels==null?0:tvCurrentChannels.length();tvCurrentChannels=clean;if(clean.length()>rendered)renderTvChannelsChunk(tvChannelHost,clean,rendered,listGen);}
   }
   boolean more=j.has("has_more")?j.optBoolean("has_more",false):rows.length()>=pageSize;int next=j.optInt("next_offset",offset+rows.length());if(more&&next>offset){tvChannelHost.postDelayed(()->fetchLiveChannelPagesProgressive(cat,q,typed,next,acc,seen,providerAtRequest,listGen,retryAll),8);return;}
   if(acc.length()==0){if(!typed)tvLoadChannelsTypedFallback(cat,q,retryAll,providerAtRequest,listGen);else tvShowNoLiveResult(q,providerAtRequest,listGen);}
  }public void err(String e){if(acc.length()==0){if(!typed)tvLoadChannelsTypedFallback(cat,q,retryAll,providerAtRequest,listGen);else tvShowNoLiveResult(q,providerAtRequest,listGen);}}});
 }
 void fetchAllLiveChannelPages(String cat,String q,boolean typed,int offset,JSONArray acc,java.util.HashSet<String> seen,AllPagesCB cb){
  final int pageSize=300;java.util.Map<String,String> args=Api.m("user_id",uid,"category_id",cat,"limit",String.valueOf(pageSize),"offset",String.valueOf(offset),"search",q);if(typed)args.put("type","live");
  Api.post("get_channel",args,new Api.CB(){public void ok(JSONObject j){if(j.optInt("status",200)!=200){if(acc.length()>0)cb.ok(acc);else cb.err(j.optString("message","Resposta inválida"));return;}JSONArray rows=j.optJSONArray("result");if(rows==null||rows.length()==0){cb.ok(acc);return;}int added=0;for(int i=0;i<rows.length();i++){JSONObject x=rows.optJSONObject(i);if(!isRealLiveChannel(x))continue;String key=tvChannelKey(x);if(key==null||key.trim().isEmpty())key=x.optString("stream_url",x.optString("url",""))+"|"+tvChannelName(x);if(seen.add(key)){acc.put(x);added++;}}if(added==0){cb.ok(acc);return;}/* v16.235: avança pelo que o servidor REALMENTE devolveu; não pula canais quando a fonte limita a página internamente. */fetchAllLiveChannelPages(cat,q,typed,offset+rows.length(),acc,seen,cb);}public void err(String e){if(acc.length()>0)cb.ok(acc);else cb.err(e);}});
 }
 void tvLoadChannelsTypedFallback(String cat,String q,boolean retryAll,String providerAtRequest,int listGen){
  if(listGen!=tvChannelListGeneration)return;fetchLiveChannelPagesProgressive(cat,q,true,0,new JSONArray(),new java.util.HashSet<String>(),providerAtRequest,listGen,retryAll);
 }
 void tvRenderLiveResult(String providerAtRequest,JSONArray a,int listGen){if(listGen!=tvChannelListGeneration||tvChannelHost==null||!providerAtRequest.equals(Api.PROVIDER==null?"":Api.PROVIDER))return;tvChannelHost.removeAllViews();sessionHasLive=true;sessionLiveKnown=true;sp.edit().putBoolean("provider_has_live",true).putInt("provider_live_count",Math.max(sp.getInt("provider_live_count",0),a.length())).apply();renderTvChannelsChunk(tvChannelHost,a,0,listGen);}
 boolean tvHasRenderedChannelCards(){if(tvChannelHost==null)return false;for(int i=0;i<tvChannelHost.getChildCount();i++){View v=tvChannelHost.getChildAt(i);Object tag=v==null?null:v.getTag();if(tag!=null&&!String.valueOf(tag).trim().isEmpty())return true;}return false;}
 void tvShowNoLiveResult(String q,String providerAtRequest,int listGen){if(listGen!=tvChannelListGeneration||tvChannelHost==null||!providerAtRequest.equals(Api.PROVIDER==null?"":Api.PROVIDER))return;if(tvHasRenderedChannelCards())return;tvChannelHost.removeAllViews();TextView m=t(q.trim().isEmpty()?"Nenhum canal disponível neste servidor.":"Nenhum canal encontrado.",14);m.setTextColor(0xffa399a0);m.setGravity(Gravity.CENTER);m.setPadding(dp(8),dp(20),dp(8),dp(20));tvChannelHost.addView(m);tvChannelHost.postDelayed(()->{if(listGen==tvChannelListGeneration&&tvChannelHost!=null&&providerAtRequest.equals(Api.PROVIDER==null?"":Api.PROVIDER)&&tvChannelHost.getChildCount()==1)tvLoadChannelsDirect("",q,false,listGen);},2500);}


 void renderTvChannelsChunk(LinearLayout host,JSONArray a,int start,int listGen){
  if(listGen!=tvChannelListGeneration||host==null||host!=tvChannelHost||host.getParent()==null||a==null)return;
  final JSONArray rows=(start==0)?sanitizeLiveChannels(a):a;
  tvChannelChunkPending=false;if(start==0)tvCurrentChannels=rows;
  // v16.234 TV/TV Box: a categoria entra COMPLETA. Nada de liberar 16 e criar mais cards durante o D-pad.
  int chunk=tvMode?Math.max(0,rows.length()-start):12;int end=Math.min(rows.length(),start+chunk);View previous=host.getChildCount()>0?host.getChildAt(host.getChildCount()-1):null;for(int i=start;i<end;i++){JSONObject x=rows.optJSONObject(i);if(x!=null){View card=tvChannelCard(x,i+1);host.addView(card);if(tvMode&&previous!=null)linkTvVertical(previous,card);previous=card;}}if(tvMode&&start==0&&rows.length()>0&&tvAutoPlayPending){final JSONObject auto=tvFindAutoPlayChannel(rows);tvAutoPlayPending=false;if(auto!=null)host.postDelayed(()->{if(listGen==tvChannelListGeneration)playLiveInline(auto);},160);}if(tvMode&&start==0&&host.getChildCount()>0&&tvCategoryHost!=null){View selected=tvPreferredCategoryFocusView();if(selected!=null){if(wideTvUi())linkTvCategoryToFirstChannel();else linkTvHorizontal(selected,host.getChildAt(0));}resetTvChannelListPosition();if(wideTvUi()&&currentNavIndex==2&&!detailOpen){host.postDelayed(()->{if(listGen!=tvChannelListGeneration||host.getChildCount()==0)return;View f=getCurrentFocus();if(f==null||f==liveSearchBox||f==navTv)requestTvFocus(host.getChildAt(0));},120);}}if(!tvMode&&end<rows.length())host.postDelayed(()->renderTvChannelsChunk(host,rows,end,listGen),16);
 }
 void maybeExtendTvChannelList(int focusedOrder){if(!tvMode||tvChannelHost==null||tvCurrentChannels==null||tvChannelChunkPending)return;int rendered=tvChannelHost.getChildCount(),total=tvCurrentChannels.length();if(total<=rendered||focusedOrder<Math.max(1,rendered-4))return;final int gen=tvChannelListGeneration;final int next=rendered;tvChannelChunkPending=true;tvChannelHost.postDelayed(()->{if(gen!=tvChannelListGeneration||tvChannelHost==null){tvChannelChunkPending=false;return;}renderTvChannelsChunk(tvChannelHost,tvCurrentChannels,next,gen);},24);}

 String currentTvSearchQuery(){
  if(liveSearchBox==null)return liveSearch==null?"":liveSearch.trim();
  String q=liveSearchBox.getText()==null?"":liveSearchBox.getText().toString().trim();
  liveSearch=q;
  return q;
 }
 String tvLastChannelPrefKey(){String p=Api.PROVIDER==null?"":Api.PROVIDER.trim();if(p.isEmpty())p="default";return "last_live_channel_"+p.replaceAll("[^A-Za-z0-9_-]","_");}
 JSONObject tvFindAutoPlayChannel(JSONArray a){if(a==null||a.length()==0)return null;String last=sp.getString(tvLastChannelPrefKey(),"");if(!last.isEmpty()){for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&last.equals(tvChannelKey(x)))return x;}}return a.optJSONObject(0);}
 View tvChannelCard(JSONObject x,int order){
  LinearLayout card=new LinearLayout(this);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(4),dp(4),dp(4),dp(4));if(tvMode)card.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
  String cid=x.optString("id",x.optString("channel_id",x.optString("stream_id","")));card.setTag(cid);
  boolean active=tvActiveChannel!=null&&cid.equals(tvActiveChannel.optString("id",tvActiveChannel.optString("channel_id",tvActiveChannel.optString("stream_id",""))));
  String rawNo=tvFirstString(x,"channel_number","stream_num","number","num","position");String channelNo=(rawNo.matches("\\d{1,4}")?rawNo:String.valueOf(order));
  LinearLayout noBox=new LinearLayout(this);noBox.setGravity(Gravity.CENTER);noBox.setPadding(0,0,0,0);noBox.setTag("number_box");
  TextView arrow=t("",14);arrow.setTag("active_arrow");arrow.setTextColor(GREEN);arrow.setGravity(Gravity.CENTER);noBox.addView(arrow,new LinearLayout.LayoutParams(dp(34),-1));
  TextView num=t(channelNo,wideTvUi()?14:12);num.setTag("channel_number");num.setTypeface(null,1);num.setGravity(Gravity.CENTER);num.setSingleLine(true);num.setMaxLines(1);num.setIncludeFontPadding(false);noBox.addView(num,new LinearLayout.LayoutParams(dp(48),-1));
  int numberW=wideTvUi()?68:34;int arrowW=wideTvUi()?26:0;int digitW=wideTvUi()?40:34;((LinearLayout.LayoutParams)arrow.getLayoutParams()).width=dp(arrowW);((LinearLayout.LayoutParams)num.getLayoutParams()).width=dp(digitW);if(!wideTvUi()){GradientDrawable nb=round(0xff1a1015,9);nb.setStroke(dp(1),0xff432634);noBox.setBackground(nb);}card.addView(noBox,new LinearLayout.LayoutParams(dp(numberW),wideTvUi()?-1:dp(40)));
  FrameLayout logoBox=new FrameLayout(this);logoBox.setBackgroundColor(0xff170b11);ImageView logo=new ImageView(this);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);logo.setPadding(dp(4),dp(4),dp(4),dp(4));String[] logoCandidates=tvChannelLogoCandidates(x);String logoSrc=logoCandidates.length==0?"":logoCandidates[0];/* v16.235: fonte atual primeiro; EPG e logos irmãs entram como fallback automático. */if(logoCandidates.length>0)Img.loadLogoBest(logo,logoCandidates);logoBox.addView(logo,new FrameLayout.LayoutParams(-1,-1));int logoW=wideTvUi()?58:52;int logoH=wideTvUi()?50:56;LinearLayout.LayoutParams llp=new LinearLayout.LayoutParams(dp(logoW),dp(logoH));llp.setMargins(dp(wideTvUi()?8:3),0,dp(wideTvUi()?10:5),0);card.addView(logoBox,llp);
  LinearLayout words=new LinearLayout(this);words.setOrientation(LinearLayout.VERTICAL);words.setGravity(Gravity.CENTER_VERTICAL);words.setPadding(dp(5),0,dp(3),0);
  TextView name=t(tvChannelName(x),wideTvUi()?13:13);name.setTypeface(null,1);name.setSingleLine(true);name.setEllipsize(android.text.TextUtils.TruncateAt.END);name.setGravity(Gravity.CENTER_VERTICAL);name.setIncludeFontPadding(true);name.setPadding(0,0,0,0);words.addView(name,new LinearLayout.LayoutParams(-1,dp(34)));
  String localEpgRaw=tvExtractEpg(x)[0];final String localEpg=(!localEpgRaw.isEmpty()&&!tvEpgNowTextIsCurrent(localEpgRaw))?"":localEpgRaw;TextView program=t(localEpg.isEmpty()?"Carregando programação...":localEpg,wideTvUi()?10:10);program.setTag("epg_program");program.setTextColor(0xffa399a0);program.setSingleLine(false);program.setMaxLines(2);program.setEllipsize(android.text.TextUtils.TruncateAt.END);program.setLineSpacing(0,1.02f);program.setGravity(Gravity.TOP|Gravity.LEFT);program.setIncludeFontPadding(false);program.setPadding(0,0,0,0);words.addView(program,new LinearLayout.LayoutParams(-1,dp(wideTvUi()?30:28)));card.addView(words,new LinearLayout.LayoutParams(0,dp(wideTvUi()?68:66),1));
  // v16.210 TV-only: EPG individual carrega quando o card recebe foco; evita dezenas de requisicoes simultaneas ao abrir/trocar categoria.
  TextView heart=t("☆",wideTvUi()?22:26);heart.setGravity(Gravity.CENTER);heart.setTextColor(isLiveFav(x)?GREEN:0xffaba1a8);card.addView(heart,new LinearLayout.LayoutParams(dp(wideTvUi()?36:36),dp(wideTvUi()?68:66)));
  heart.setOnClickListener(v->{toggleLiveFav(x);heart.setTextColor(isLiveFav(x)?GREEN:0xffaba1a8);});card.setFocusable(true);card.setFocusableInTouchMode(false);card.setOnClickListener(v->{if(!tvMode&&localEpg.isEmpty()&&Boolean.TRUE!=program.getTag(TAG_EPG_LOADING)){program.setTag(TAG_EPG_LOADING,Boolean.TRUE);loadTvListEpg(x,program);}queueTvChannelSwitch(x);});if(tvMode)tvFocusArmed.put(card,Boolean.TRUE);card.setOnFocusChangeListener((v,has)->{if(has){styleTvChannelCard(v,true);if(logoCandidates.length>0&&logo.getDrawable()==null)Img.loadLogoBest(logo,logoCandidates);if(!tvMode&&Boolean.TRUE!=program.getTag(TAG_EPG_LOADING)&&localEpg.isEmpty()){program.setTag(TAG_EPG_LOADING,Boolean.TRUE);loadTvListEpg(x,program);}keepTvChannelVisible(v);}else{String activeId=tvActiveChannel==null?"":tvChannelKey(tvActiveChannel);styleTvChannelCard(v,cid.equals(activeId));}});if(!tvMode&&localEpg.isEmpty()&&order<=12){card.postDelayed(()->{if(program.getParent()!=null&&Boolean.TRUE!=program.getTag(TAG_EPG_LOADING)){program.setTag(TAG_EPG_LOADING,Boolean.TRUE);loadTvListEpg(x,program);}},180L+(order*70L));}
  if(tvMode)card.setOnKeyListener((v,key,event)->{if(event==null)return false;if((key==KeyEvent.KEYCODE_DPAD_CENTER||key==KeyEvent.KEYCODE_ENTER||key==KeyEvent.KEYCODE_NUMPAD_ENTER||key==KeyEvent.KEYCODE_BUTTON_A)&&event.getAction()==KeyEvent.ACTION_DOWN){if(event.getRepeatCount()==0)queueTvChannelSwitch(x);return true;}if(event.getAction()!=KeyEvent.ACTION_DOWN)return false;if(key==KeyEvent.KEYCODE_DPAD_UP&&order==1&&wideTvUi()){View cat=tvPreferredCategoryFocusView();if(cat!=null)requestTvFocus(cat);return true;}if(key==KeyEvent.KEYCODE_DPAD_RIGHT){if(wideTvUi())enterTvCinemaMode();if(tvPreviewFrame!=null)requestTvFocus(tvPreviewFrame);return true;}if(key==KeyEvent.KEYCODE_DPAD_LEFT){return true;}return false;});
  LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,wideTvUi()?dp(74):dp(82));lp.setMargins(0,0,0,wideTvUi()?dp(6):dp(6));card.setLayoutParams(lp);styleTvChannelCard(card,active);return card;
 }
 void loadTvListEpg(JSONObject channel,TextView target){if(channel==null||target==null)return;String cid=tvChannelKey(channel);if(cid.isEmpty()){target.setText("Sem informação");return;}String[] cached=tvCachedEpg(channel);if(cached!=null&&!cached[0].isEmpty()&&tvEpgNowTextIsCurrent(cached[0])){target.setText(cached[0]);return;}requestTvListEpg(channel,target,false);}
 void requestTvListEpg(JSONObject channel,TextView target,boolean full){if(channel==null||target==null)return;String ep=full?"get_epg":"get_short_epg";Api.post(ep,tvEpgArgs(channel,full?6:2),new Api.CB(){public void ok(JSONObject j){if(target.getParent()==null)return;JSONObject payload=tvSelectEpgPayload(j,channel);String[] e=payload==null?new String[]{"",""}:tvExtractEpg(payload);if(!e[0].isEmpty()&&!tvEpgNowTextIsCurrent(e[0]))e[0]="";if(!e[0].isEmpty()){tvCacheEpg(channel,e);target.setText(e[0]);target.setTag(TAG_EPG_LOADING,Boolean.FALSE);}else if(!full)requestTvListEpg(channel,target,true);else{target.setText("Sem informação");target.setTag(TAG_EPG_LOADING,Boolean.FALSE);}}public void err(String e){if(!full&&target.getParent()!=null)requestTvListEpg(channel,target,true);else if(target.getParent()!=null){target.setText("Sem informação");target.setTag(TAG_EPG_LOADING,Boolean.FALSE);}}});}
 void styleTvChannelCard(View card,boolean active){if(card==null)return;if(wideTvUi()){GradientDrawable g=round(active?0xff23101a:0xff11060c,18);g.setStroke(dp(2),active?GREEN:0xff462134);card.setBackground(g);if(card instanceof ViewGroup){ViewGroup vg=(ViewGroup)card;View nb=vg.findViewWithTag("number_box");if(nb!=null)nb.setBackgroundColor(active?0xff4b1731:0xff13070d);View av=vg.findViewWithTag("active_arrow");if(av instanceof TextView)((TextView)av).setText(active?"▶":"");View nv=vg.findViewWithTag("channel_number");if(nv instanceof TextView)((TextView)nv).setTextColor(active?GREEN:0xffe1d4dc);}return;}GradientDrawable g=round(active?0xff381526:0x00000000,5);if(active)g.setStroke(dp(2),GREEN);card.setBackground(g);}
 void refreshTvChannelSelection(){if(tvChannelHost==null)return;String id=tvActiveChannel==null?"":tvActiveChannel.optString("id",tvActiveChannel.optString("channel_id",tvActiveChannel.optString("stream_id","")));for(int i=0;i<tvChannelHost.getChildCount();i++){View c=tvChannelHost.getChildAt(i);Object tag=c.getTag();if(tag!=null)styleTvChannelCard(c,id.equals(String.valueOf(tag)));}}
 int tvFullscreenChannelIndex(JSONObject channel){if(channel==null||tvCurrentChannels==null)return -1;String key=tvChannelKey(channel);for(int i=0;i<tvCurrentChannels.length();i++){JSONObject c=tvCurrentChannels.optJSONObject(i);if(c!=null&&key.equals(tvChannelKey(c)))return i;}return -1;}
 int tvWrapChannelIndex(int index){int n=tvCurrentChannels==null?0:tvCurrentChannels.length();if(n<=0)return -1;while(index<0)index+=n;while(index>=n)index-=n;return index;}
 void switchTvFullscreenChannelBy(int delta){if(!tvInlineFullscreen||tvCurrentChannels==null||tvCurrentChannels.length()==0)return;long now=android.os.SystemClock.elapsedRealtime();if(now-tvFullscreenLastNavAt<130)return;tvFullscreenLastNavAt=now;int base=tvFullscreenChannelIndex(tvActiveChannel);if(base<0)base=0;int next=tvWrapChannelIndex(base+delta);JSONObject target=tvCurrentChannels.optJSONObject(next);if(target==null)return;tvFullscreenOverlayIndex=next;queueTvChannelSwitch(target);showTvFullscreenChannelOverlay(true);}
 void showTvFullscreenChannelOverlay(boolean autoHide){if(!tvInlineFullscreen||tvPreviewFrame==null||tvCurrentChannels==null||tvCurrentChannels.length()==0)return;tvFullscreenChannelOverlayVisible=true;if(tvEpgOverlay!=null)tvEpgOverlay.setVisibility(View.GONE);if(tvFullscreenChannelOverlay==null||tvFullscreenChannelOverlay.getParent()!=tvPreviewFrame){tvFullscreenChannelOverlay=new FrameLayout(this);GradientDrawable ob=round(0xdd0b0206,18);ob.setStroke(dp(1),0xff4b2a3b);tvFullscreenChannelOverlay.setBackground(ob);LinearLayout wrap=new LinearLayout(this);wrap.setOrientation(LinearLayout.VERTICAL);wrap.setPadding(dp(16),dp(8),dp(16),dp(10));TextView title=t("Canais  •  ↑/↓ troca direto  •  ←/→ escolhe  •  OK confirma",12);title.setTextColor(0xffd2c5ce);title.setSingleLine(true);title.setGravity(Gravity.CENTER_VERTICAL);wrap.addView(title,new LinearLayout.LayoutParams(-1,dp(30)));tvFullscreenChannelScroll=new HorizontalScrollView(this);tvFullscreenChannelScroll.setHorizontalScrollBarEnabled(false);tvFullscreenChannelScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);tvFullscreenChannelRow=new LinearLayout(this);tvFullscreenChannelRow.setOrientation(LinearLayout.HORIZONTAL);tvFullscreenChannelRow.setGravity(Gravity.CENTER_VERTICAL);tvFullscreenChannelScroll.addView(tvFullscreenChannelRow,new HorizontalScrollView.LayoutParams(-2,-1));wrap.addView(tvFullscreenChannelScroll,new LinearLayout.LayoutParams(-1,0,1));tvFullscreenChannelOverlay.addView(wrap,new FrameLayout.LayoutParams(-1,-1));FrameLayout.LayoutParams op=new FrameLayout.LayoutParams(-1,dp(142),Gravity.BOTTOM);op.setMargins(dp(18),0,dp(18),dp(16));tvPreviewFrame.addView(tvFullscreenChannelOverlay,op);}tvFullscreenChannelOverlay.setVisibility(View.VISIBLE);int active=tvFullscreenChannelIndex(tvActiveChannel);if(tvFullscreenOverlayIndex<0)tvFullscreenOverlayIndex=active<0?0:active;buildTvFullscreenChannelRail();scheduleTvFullscreenOverlayHide(autoHide?4200:8000);}
 void scheduleTvFullscreenOverlayHide(long delay){if(tvInlineHandler==null)return;if(tvFullscreenOverlayHide!=null)tvInlineHandler.removeCallbacks(tvFullscreenOverlayHide);tvFullscreenOverlayHide=()->{if(tvFullscreenChannelOverlayVisible)hideTvFullscreenChannelOverlay();};tvInlineHandler.postDelayed(tvFullscreenOverlayHide,delay);}
 void buildTvFullscreenChannelRail(){if(tvFullscreenChannelRow==null||tvCurrentChannels==null||tvCurrentChannels.length()==0)return;tvFullscreenChannelRow.removeAllViews();int n=tvCurrentChannels.length();tvFullscreenOverlayIndex=tvWrapChannelIndex(tvFullscreenOverlayIndex<0?0:tvFullscreenOverlayIndex);int radius=Math.min(4,Math.max(0,(n-1)/2));View selectedView=null;for(int off=-radius;off<=radius;off++){int idx=tvWrapChannelIndex(tvFullscreenOverlayIndex+off);JSONObject ch=tvCurrentChannels.optJSONObject(idx);if(ch==null)continue;boolean selected=idx==tvFullscreenOverlayIndex;LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.HORIZONTAL);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(8),dp(5),dp(8),dp(5));GradientDrawable cg=round(selected?0xff3d1529:0xff181014,12);cg.setStroke(dp(selected?3:1),selected?GREEN:0xff514048);card.setBackground(cg);ImageView logo=new ImageView(this);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);logo.setBackgroundColor(0xff11080d);String[] logoCandidates=tvChannelLogoCandidates(ch);if(logoCandidates.length>0)Img.loadLogoBest(logo,logoCandidates);card.addView(logo,new LinearLayout.LayoutParams(dp(44),dp(44)));LinearLayout words=new LinearLayout(this);words.setOrientation(LinearLayout.VERTICAL);words.setPadding(dp(8),0,0,0);TextView num=t(String.valueOf(idx+1),10);num.setTextColor(selected?GREEN:0xffa0969d);num.setPadding(0,0,0,0);words.addView(num,new LinearLayout.LayoutParams(-1,dp(18)));TextView nm=t(tvChannelName(ch),12);nm.setTypeface(null,1);nm.setSingleLine(true);nm.setEllipsize(android.text.TextUtils.TruncateAt.END);nm.setPadding(0,0,0,0);words.addView(nm,new LinearLayout.LayoutParams(-1,dp(28)));card.addView(words,new LinearLayout.LayoutParams(0,-1,1));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(178),dp(62));cp.setMargins(dp(4),0,dp(4),0);tvFullscreenChannelRow.addView(card,cp);if(selected)selectedView=card;}final View focus=selectedView;if(focus!=null&&tvFullscreenChannelScroll!=null)tvFullscreenChannelScroll.post(()->{try{int x=Math.max(0,focus.getLeft()-(tvFullscreenChannelScroll.getWidth()-focus.getWidth())/2);tvFullscreenChannelScroll.smoothScrollTo(x,0);}catch(Exception ignored){}});}
 void moveTvFullscreenOverlaySelection(int delta){if(tvCurrentChannels==null||tvCurrentChannels.length()==0)return;if(tvFullscreenOverlayIndex<0){int active=tvFullscreenChannelIndex(tvActiveChannel);tvFullscreenOverlayIndex=active<0?0:active;}tvFullscreenOverlayIndex=tvWrapChannelIndex(tvFullscreenOverlayIndex+delta);buildTvFullscreenChannelRail();scheduleTvFullscreenOverlayHide(8000);}
 void selectTvFullscreenOverlayChannel(){if(tvCurrentChannels==null||tvCurrentChannels.length()==0)return;int idx=tvWrapChannelIndex(tvFullscreenOverlayIndex);JSONObject chosen=idx<0?null:tvCurrentChannels.optJSONObject(idx);if(chosen!=null){queueTvChannelSwitch(chosen);tvFullscreenOverlayIndex=idx;buildTvFullscreenChannelRail();scheduleTvFullscreenOverlayHide(2800);}}
 void hideTvFullscreenChannelOverlay(){tvFullscreenChannelOverlayVisible=false;if(tvInlineHandler!=null&&tvFullscreenOverlayHide!=null)tvInlineHandler.removeCallbacks(tvFullscreenOverlayHide);tvFullscreenOverlayHide=null;if(tvFullscreenChannelOverlay!=null){try{tvFullscreenChannelOverlay.setVisibility(View.GONE);}catch(Exception ignored){}}if(tvInlineFullscreen)showTvEpgOverlayTemporarily();}
 void destroyTvFullscreenChannelOverlay(){tvFullscreenChannelOverlayVisible=false;if(tvInlineHandler!=null&&tvFullscreenOverlayHide!=null)tvInlineHandler.removeCallbacks(tvFullscreenOverlayHide);tvFullscreenOverlayHide=null;if(tvFullscreenChannelOverlay!=null&&tvFullscreenChannelOverlay.getParent() instanceof ViewGroup){try{((ViewGroup)tvFullscreenChannelOverlay.getParent()).removeView(tvFullscreenChannelOverlay);}catch(Exception ignored){}}tvFullscreenChannelOverlay=null;tvFullscreenChannelScroll=null;tvFullscreenChannelRow=null;tvFullscreenOverlayIndex=-1;}
 String tvLiveUrl(JSONObject x){if(x==null)return "";String[] keys={"video_1080","video_720","video_480","video_320","stream_url","url","video"};for(String k:keys){String u=x.optString(k,"").trim();if(!u.isEmpty())return u;}return "";}
 void tvBuildSources(JSONObject x){
  tvInlineSources.clear();if(x==null)return;
  // v16.116: as quatro chaves de qualidade do backend apontam para o mesmo stream Xtream.
  // Nao reiniciar a mesma fonte em cada buffering: mantemos uma URL unica e deixamos o ExoPlayer bufferizar.
  tvAddSource(x.optString("video_1080",""));tvAddSource(x.optString("video_720",""));tvAddSource(x.optString("video_480",""));tvAddSource(x.optString("video_320",""));tvAddSource(x.optString("stream_url",""));tvAddSource(x.optString("url",""));tvAddSource(x.optString("video",""));
 }
 void tvAddSource(String u){if(u==null)return;u=u.trim();if(!u.isEmpty()&&!tvInlineSources.contains(u))tvInlineSources.add(u);}
 String tvChannelKey(JSONObject x){if(x==null)return "";return x.optString("id",x.optString("channel_id",x.optString("stream_id","")));}
 void queueTvChannelSwitch(JSONObject x){
  if(x==null||tvInlineHandler==null)return;String target=tvChannelKey(x);String active=tvChannelKey(tvActiveChannel);if(!target.isEmpty()&&target.equals(active)){playLiveInline(x);return;}tvQueuedChannel=x;final int generation=++tvChannelSwitchGeneration;if(tvQueuedChannelSwitch!=null)tvInlineHandler.removeCallbacks(tvQueuedChannelSwitch);tvQueuedChannelSwitch=()->{if(generation!=tvChannelSwitchGeneration||tvQueuedChannel==null||tvInlinePlayerView==null)return;JSONObject chosen=tvQueuedChannel;tvQueuedChannel=null;tvQueuedChannelSwitch=null;playLiveInline(chosen);};tvInlineHandler.postDelayed(tvQueuedChannelSwitch,180);
 }
 void playLiveInline(JSONObject x){
  if(x==null||tvInlinePlayerView==null||!isRealLiveChannel(x))return;JSONObject cached=readCachedAccessStatus();if(accessDenied(cached)){showAccessExpiredDialog(accessDeniedMessage(cached));refreshEntitlements(null);return;}
  playLiveInlineAllowed(x);
 }
 void playLiveInlineAllowed(JSONObject x){
  if(blockTamperedPlayback())return;
  if(x!=null){String remember=tvChannelKey(x);if(!remember.isEmpty())sp.edit().putString(tvLastChannelPrefKey(),remember).apply();}
  if(x==null||tvInlinePlayerView==null)return;String u=tvLiveUrl(x);if(u.isEmpty()){Toast.makeText(this,"Canal indisponível",Toast.LENGTH_SHORT).show();return;}
  String old=tvChannelKey(tvActiveChannel),now=tvChannelKey(x);if(!now.isEmpty()&&now.equals(old)&&tvInlinePlayer!=null&&tvInlinePlayer.getPlaybackState()!=androidx.media3.common.Player.STATE_IDLE){tvActiveChannel=x;loadTvEpgForChannel(x);showTvEpgOverlayTemporarily();refreshTvChannelSelection();try{int st=tvInlinePlayer.getPlaybackState();if(st==androidx.media3.common.Player.STATE_ENDED){tvBuildSources(x);if(!tvInlineSources.isEmpty())tvStartInlineSource(Math.min(tvInlineSourceIndex,tvInlineSources.size()-1));}else if(!tvInlinePlayer.isPlaying()){tvInlinePlayer.play();}}catch(Exception ignored){}return;}
  tvPlaybackGeneration++;tvInlineSwitching=false;tvInlineRecoveryCount=0;tvInlineFormatAttemptIndex=-1;tvInlineFormatAttemptMask=0;tvInlineFormatMode=0;if(tvInlineWatchdog!=null&&tvInlineHandler!=null)tvInlineHandler.removeCallbacks(tvInlineWatchdog);tvActiveChannel=x;loadTvEpgForChannel(x);showTvEpgOverlayTemporarily();refreshTvChannelSelection();tvBuildSources(x);tvInlineSourceIndex=0;tvInlinePrepared=false;if(!tvMode&&CastHelper.isConnected(this)){String title=tvChannelName(x);if(tvPreviewPlaceholder!=null)tvPreviewPlaceholder.setVisibility(View.VISIBLE);if(tvPreviewTitle!=null)tvPreviewTitle.setText("Transmitindo na TV");if(tvPreviewSubtitle!=null)tvPreviewSubtitle.setText(title);if(tvInlinePlayerView!=null)tvInlinePlayerView.setVisibility(View.GONE);if(tvSoundButton!=null)tvSoundButton.setVisibility(View.GONE);if(tvFullButton!=null)tvFullButton.setVisibility(View.GONE);CastHelper.cast(this,u,title,true,null);return;}showTvPreviewLoading(tvChannelName(x));acquireTvInlineSession(()->tvStartInlineSource(0));
 }
 void buildTvPreviewPlaceholder(boolean wide){
  tvPreviewPlaceholder=new LinearLayout(this);tvPreviewPlaceholder.setOrientation(LinearLayout.VERTICAL);tvPreviewPlaceholder.setGravity(Gravity.CENTER);tvPreviewPlaceholder.setPadding(dp(wide?36:24),dp(wide?24:18),dp(wide?36:24),dp(wide?24:18));tvPreviewPlaceholder.setBackgroundColor(0xff010604);

  LinearLayout brandRow=new LinearLayout(this);brandRow.setGravity(Gravity.CENTER);brandRow.setOrientation(LinearLayout.HORIZONTAL);
  tvPreviewLoadingLogo=new ImageView(this);tvPreviewLoadingLogo.setScaleType(ImageView.ScaleType.FIT_CENTER);tvPreviewLoadingLogo.setImageResource(R.drawable.ic_nav_tv);if(Build.VERSION.SDK_INT>=21)tvPreviewLoadingLogo.setImageTintList(android.content.res.ColorStateList.valueOf(GREEN));
  brandRow.addView(tvPreviewLoadingLogo,new LinearLayout.LayoutParams(dp(wide?58:48),dp(wide?58:48)));
  tvPreviewPlaceholder.addView(brandRow,new LinearLayout.LayoutParams(-1,dp(wide?62:52)));

  tvPreviewLoadingStatus=t("GREENPLAY • AO VIVO",wide?10:9);tvPreviewLoadingStatus.setTextColor(GREEN);tvPreviewLoadingStatus.setTypeface(null,1);tvPreviewLoadingStatus.setGravity(Gravity.CENTER);tvPreviewLoadingStatus.setLetterSpacing(.10f);tvPreviewLoadingStatus.setIncludeFontPadding(true);tvPreviewLoadingStatus.setPadding(0,dp(2),0,dp(2));LinearLayout.LayoutParams stp=new LinearLayout.LayoutParams(-1,-2);stp.setMargins(0,dp(wide?9:7),0,dp(3));tvPreviewPlaceholder.addView(tvPreviewLoadingStatus,stp);

  tvPreviewTitle=t("Selecione um canal",wide?21:18);tvPreviewTitle.setTypeface(null,1);tvPreviewTitle.setGravity(Gravity.CENTER);tvPreviewTitle.setTextColor(Color.WHITE);tvPreviewTitle.setIncludeFontPadding(true);tvPreviewTitle.setPadding(0,dp(1),0,dp(1));tvPreviewPlaceholder.addView(tvPreviewTitle,new LinearLayout.LayoutParams(-1,-2));

  tvPreviewSubtitle=t(wide?"Escolha um canal na lista para começar":"Escolha um canal para começar",wide?12:11);tvPreviewSubtitle.setTextColor(0xff999096);tvPreviewSubtitle.setGravity(Gravity.CENTER);tvPreviewSubtitle.setMaxLines(2);tvPreviewSubtitle.setEllipsize(android.text.TextUtils.TruncateAt.END);tvPreviewSubtitle.setIncludeFontPadding(true);LinearLayout.LayoutParams subp=new LinearLayout.LayoutParams(-1,-2);subp.setMargins(0,dp(5),0,0);tvPreviewPlaceholder.addView(tvPreviewSubtitle,subp);

  tvPreviewLoadingProgress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);tvPreviewLoadingProgress.setIndeterminate(true);if(Build.VERSION.SDK_INT>=21)tvPreviewLoadingProgress.setIndeterminateTintList(android.content.res.ColorStateList.valueOf(GREEN));tvPreviewLoadingProgress.setVisibility(View.GONE);
  LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(dp(wide?220:170),dp(3));pp.gravity=Gravity.CENTER_HORIZONTAL;pp.setMargins(0,dp(wide?16:13),0,0);tvPreviewPlaceholder.addView(tvPreviewLoadingProgress,pp);
 }
 void showTvPreviewLoading(String name){
  clearTvBackdrop();
  if(tvPreviewPlaceholder!=null){tvPreviewPlaceholder.animate().cancel();tvPreviewPlaceholder.setScaleX(.985f);tvPreviewPlaceholder.setScaleY(.985f);tvPreviewPlaceholder.setAlpha(0f);tvPreviewPlaceholder.setVisibility(View.VISIBLE);tvPreviewPlaceholder.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(150).start();}
  if(tvPreviewLoadingStatus!=null){tvPreviewLoadingStatus.setText("CONECTANDO AO VIVO");tvPreviewLoadingStatus.setTextColor(GREEN);}
  if(tvPreviewLoadingProgress!=null)tvPreviewLoadingProgress.setVisibility(View.VISIBLE);
  if(tvPreviewLoadingLogo!=null){
   tvPreviewLoadingLogo.setImageResource(R.drawable.ic_nav_tv);
   if(Build.VERSION.SDK_INT>=21)tvPreviewLoadingLogo.setImageTintList(android.content.res.ColorStateList.valueOf(GREEN));
   if(tvActiveChannel!=null){
    String a=tvActiveChannel.optString("provider_icon",tvActiveChannel.optString("stream_icon",""));
    String b=tvActiveChannel.optString("thumbnail",tvActiveChannel.optString("image",""));
    String c=tvActiveChannel.optString("epg_logo",tvActiveChannel.optString("fallback_logo",""));
    if(!a.isEmpty()||!b.isEmpty()||!c.isEmpty()){if(Build.VERSION.SDK_INT>=21)tvPreviewLoadingLogo.setImageTintList(null);Img.loadBest(tvPreviewLoadingLogo,a,b,c);}
   }
  }
  if(tvPreviewTitle!=null)tvPreviewTitle.setText(name==null||name.trim().isEmpty()?"Abrindo transmissão":name.trim());
  if(tvPreviewSubtitle!=null)tvPreviewSubtitle.setText("Preparando o sinal…");
  if(tvSoundButton!=null)tvSoundButton.setVisibility(View.GONE);if(tvCastButton!=null)tvCastButton.setVisibility(View.GONE);if(tvFullButton!=null)tvFullButton.setVisibility(View.GONE);hideTvEpgOverlay();if(tvInlinePlayerView!=null)tvInlinePlayerView.setVisibility(View.VISIBLE);
 }
 void showTvPreviewError(String msg){tvInlinePrepared=false;if(tvInlinePlayerView!=null)tvInlinePlayerView.setVisibility(View.GONE);if(tvPreviewPlaceholder!=null){tvPreviewPlaceholder.animate().cancel();tvPreviewPlaceholder.setAlpha(1f);tvPreviewPlaceholder.setVisibility(View.VISIBLE);}if(tvPreviewLoadingProgress!=null)tvPreviewLoadingProgress.setVisibility(View.GONE);if(tvPreviewLoadingStatus!=null){tvPreviewLoadingStatus.setText("SINAL INDISPONÍVEL");tvPreviewLoadingStatus.setTextColor(0xffff7078);}if(tvPreviewTitle!=null)tvPreviewTitle.setText("Não foi possível reproduzir");if(tvPreviewSubtitle!=null)tvPreviewSubtitle.setText(msg==null||msg.isEmpty()?"Tente outro canal.":msg);if(tvSoundButton!=null)tvSoundButton.setVisibility(View.GONE);if(tvCastButton!=null)tvCastButton.setVisibility(View.GONE);if(tvFullButton!=null)tvFullButton.setVisibility(View.GONE);hideTvEpgOverlay();}
 void clearTvBackdrop(){tvBackdropCapturePending=false;if(tvInlineHandler!=null&&tvBackdropBeat!=null)tvInlineHandler.removeCallbacks(tvBackdropBeat);tvBackdropBeat=null;if(tvVideoBackdrop!=null){tvVideoBackdrop.setImageDrawable(null);tvVideoBackdrop.setVisibility(View.GONE);}}
 void startTvBackdropUpdates(){/* v16.172: sem fundo duplicado do canal */}
 void applyTvSafeSideFill(int videoW,int videoH,float pixelRatio){
  if(tvInlinePlayerView==null||tvPreviewFrame==null)return;if(videoW>0)tvVideoWidth=videoW;if(videoH>0)tvVideoHeight=videoH;if(pixelRatio>0)tvVideoPixelRatio=pixelRatio;tvPreviewFrame.post(()->{try{
   if(tvInlinePlayerView==null||tvPreviewFrame==null)return;tvPreviewFrame.setPadding(0,0,0,0);FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER);lp.setMargins(0,0,0,0);tvInlinePlayerView.setLayoutParams(lp);tvInlinePlayerView.setResizeMode(androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FILL);tvInlinePlayerView.setScaleX(1f);tvInlinePlayerView.setScaleY(1f);tvInlinePlayerView.setShutterBackgroundColor(Color.BLACK);tvInlinePlayerView.setBackgroundColor(Color.BLACK);tvInlinePlayerView.requestLayout();tvPreviewFrame.requestLayout();if(tvPreviewFrame.getParent() instanceof ViewGroup)((ViewGroup)tvPreviewFrame.getParent()).setPadding(0,0,0,0);if(tvEpgOverlay!=null)tvEpgOverlay.bringToFront();if(tvFullscreenChannelOverlayVisible&&tvFullscreenChannelOverlay!=null)tvFullscreenChannelOverlay.bringToFront();
  }catch(Exception ignored){}});
 }
 void ensureTvInlinePlayer(){
  if(tvInlinePlayer!=null){if(tvInlinePlayerView!=null&&tvInlinePlayerView.getPlayer()!=tvInlinePlayer)tvInlinePlayerView.setPlayer(tvInlinePlayer);return;}
  // v16.135: buffer equilibrado para live. O buffer ultrabaixo da 16.134 deixava alguns MPEG-TS/HLS sem margem para jitter e o decoder podia congelar em quadros corrompidos.
  androidx.media3.exoplayer.DefaultLoadControl loadControl=new androidx.media3.exoplayer.DefaultLoadControl.Builder().setBufferDurationsMs(4000,30000,1400,2800).setPrioritizeTimeOverSizeThresholds(true).setBackBuffer(2000,true).build();
  androidx.media3.datasource.DefaultHttpDataSource.Factory http=new androidx.media3.datasource.DefaultHttpDataSource.Factory().setUserAgent("VLC/3.0.18 LibVLC/3.0.18").setConnectTimeoutMs(10000).setReadTimeoutMs(30000).setAllowCrossProtocolRedirects(true);
  androidx.media3.datasource.DefaultDataSource.Factory dataSource=new androidx.media3.datasource.DefaultDataSource.Factory(this,http);
  androidx.media3.exoplayer.source.DefaultMediaSourceFactory mediaSourceFactory=new androidx.media3.exoplayer.source.DefaultMediaSourceFactory(dataSource);
  androidx.media3.exoplayer.DefaultRenderersFactory renderers=new androidx.media3.exoplayer.DefaultRenderersFactory(this).setEnableDecoderFallback(true);
  tvInlinePlayer=new androidx.media3.exoplayer.ExoPlayer.Builder(this,renderers).setLoadControl(loadControl).setMediaSourceFactory(mediaSourceFactory).build();tvInlinePlayer.setPlayWhenReady(true);tvInlinePlayer.setVideoScalingMode(androidx.media3.common.C.VIDEO_SCALING_MODE_SCALE_TO_FIT);tvInlinePlayer.setVolume(tvInlineMuted?0f:1f);
  tvInlinePlayer.addListener(new androidx.media3.common.Player.Listener(){
   @Override public void onPlaybackStateChanged(int state){
    if(state==androidx.media3.common.Player.STATE_READY){tvInlinePrepared=true;tvInlineSwitching=false;tvInlineBufferStarts=0;tvInlineBufferingSince=0;tvInlineLastPosition=tvInlinePlayer==null?-1:tvInlinePlayer.getCurrentPosition();tvInlineLastAdvanceAt=android.os.SystemClock.elapsedRealtime();if(tvPreviewLoadingProgress!=null)tvPreviewLoadingProgress.setVisibility(View.GONE);if(tvPreviewPlaceholder!=null)tvPreviewPlaceholder.setVisibility(View.GONE);if(tvInlinePlayerView!=null){tvInlinePlayerView.setVisibility(View.VISIBLE);tvInlinePlayerView.setKeepScreenOn(true);}try{getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);}catch(Exception ignored){}applyTvSafeSideFill(tvVideoWidth,tvVideoHeight,tvVideoPixelRatio);if(tvSoundButton!=null){tvSoundButton.setVisibility(View.GONE);tvSoundButton.setText(tvInlineMuted?"Sem som":"Som");}if(tvCastButton!=null)tvCastButton.setVisibility(View.VISIBLE);if(tvFullButton!=null)tvFullButton.setVisibility(View.GONE);if(tvNowPlaying!=null&&tvActiveChannel!=null)tvNowPlaying.setText(tvChannelName(tvActiveChannel));showTvEpgOverlayTemporarily();refreshTvChannelSelection();startTvInlineWatchdog();if(wideTvUi()&&!tvInlineFullscreen&&currentNavIndex==2){/* v16.237: não trocar automaticamente para outro layout; a tela TV mantém uma única largura estável. */}}
    else if(state==androidx.media3.common.Player.STATE_BUFFERING){long now=android.os.SystemClock.elapsedRealtime();if(tvInlineBufferingSince==0)tvInlineBufferingSince=now;if(tvInlinePrepared)tvInlineBufferStarts++;else if(tvPreviewPlaceholder!=null)tvPreviewPlaceholder.setVisibility(View.VISIBLE);}
    else if(state==androidx.media3.common.Player.STATE_IDLE||state==androidx.media3.common.Player.STATE_ENDED){tvInlineBufferingSince=0;}
   }
   @Override public void onVideoSizeChanged(androidx.media3.common.VideoSize videoSize){if(videoSize!=null)applyTvSafeSideFill(videoSize.width,videoSize.height,videoSize.pixelWidthHeightRatio);}
   @Override public void onPlayerError(androidx.media3.common.PlaybackException error){recoverTvInlinePlayback(true);}
  });
  if(tvInlinePlayerView!=null)tvInlinePlayerView.setPlayer(tvInlinePlayer);
 }
 void tvStartInlineSource(int index){
  if(tvInlinePlayerView==null||index<0||index>=tvInlineSources.size()){showTvPreviewError("Tente outro canal.");return;}tvInlineSourceIndex=index;tvInlinePrepared=false;tvInlineSwitching=false;tvInlineBufferingSince=0;tvInlineLastPosition=-1;tvInlineLastAdvanceAt=android.os.SystemClock.elapsedRealtime();String url=tvInlineSources.get(index);String name=tvChannelName(tvActiveChannel);showTvPreviewLoading(name);
  try{ensureTvInlinePlayer();clearTvBackdrop();tvVideoWidth=0;tvVideoHeight=0;tvVideoPixelRatio=1f;if(tvInlinePlayerView!=null){tvInlinePlayerView.setResizeMode(androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FILL);tvInlinePlayerView.setShutterBackgroundColor(Color.BLACK);tvInlinePlayerView.setBackgroundColor(Color.BLACK);tvInlinePlayerView.setScaleX(1f);tvInlinePlayerView.setScaleY(1f);tvInlinePlayerView.setLayoutParams(new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));}androidx.media3.common.MediaItem.Builder itemBuilder=new androidx.media3.common.MediaItem.Builder().setUri(Uri.parse(url));if(tvInlineFormatAttemptIndex==index&&tvInlineFormatMode==1)itemBuilder.setMimeType("video/mp2t");else if(tvInlineFormatAttemptIndex==index&&tvInlineFormatMode==2)itemBuilder.setMimeType(androidx.media3.common.MimeTypes.APPLICATION_M3U8);androidx.media3.common.MediaItem item=itemBuilder.build();tvInlinePlayer.stop();tvInlinePlayer.clearMediaItems();tvInlinePlayer.setMediaItem(item);tvInlinePlayer.prepare();tvInlinePlayer.play();startTvInlineWatchdog();}catch(Exception e){recoverTvInlinePlayback(true);}
 }
 void startTvInlineWatchdog(){
  if(tvInlineHandler==null)return;if(tvInlineWatchdog!=null)tvInlineHandler.removeCallbacks(tvInlineWatchdog);tvInlineWatchdog=new Runnable(){public void run(){
   if(tvInlinePlayer==null||tvActiveChannel==null||tvInlinePlayerView==null)return;if(tvUiTransitioning||tvOrientationTransition){if(tvInlineHandler!=null)tvInlineHandler.postDelayed(this,1200);return;}long now=android.os.SystemClock.elapsedRealtime();try{
    int st=tvInlinePlayer.getPlaybackState();long pos=tvInlinePlayer.getCurrentPosition();
    if(st==androidx.media3.common.Player.STATE_READY&&tvInlinePlayer.isPlaying()){
     if(tvInlineLastPosition<0||Math.abs(pos-tvInlineLastPosition)>=350){tvInlineLastPosition=pos;tvInlineLastAdvanceAt=now;tvInlineBufferingSince=0;tvInlineRecoveryCount=0;}
     else if(tvInlineLastAdvanceAt>0&&now-tvInlineLastAdvanceAt>15000){recoverTvInlinePlayback(false);return;}
    }else if(st==androidx.media3.common.Player.STATE_BUFFERING){if(tvInlineBufferingSince==0)tvInlineBufferingSince=now;if(now-tvInlineBufferingSince>15000){recoverTvInlinePlayback(false);return;}}
   }catch(Exception ignored){}
   if(tvInlineHandler!=null)tvInlineHandler.postDelayed(this,2000);
  }};tvInlineHandler.postDelayed(tvInlineWatchdog,2000);
 }
 void recoverTvInlinePlayback(boolean fromError){
  if(tvInlineSwitching||tvInlineSources.isEmpty()||tvInlinePlayerView==null)return;if(tvInlineRecoveryCount>=4){tvInlineSwitching=false;if(tvInlineWatchdog!=null&&tvInlineHandler!=null)tvInlineHandler.removeCallbacks(tvInlineWatchdog);if(tvPreviewPlaceholder!=null)tvPreviewPlaceholder.setVisibility(View.VISIBLE);if(tvPreviewLoadingProgress!=null)tvPreviewLoadingProgress.setVisibility(View.GONE);if(tvPreviewLoadingStatus!=null){tvPreviewLoadingStatus.setText("SINAL INSTÁVEL");tvPreviewLoadingStatus.setTextColor(0xffffb75e);}if(tvPreviewTitle!=null)tvPreviewTitle.setText("Canal instável");if(tvPreviewSubtitle!=null)tvPreviewSubtitle.setText(tvMode?"Use ↑ ou ↓ para trocar de canal":"Volte à lista e escolha outro canal");if(tvMode&&tvInlineFullscreen)showTvFullscreenChannelOverlay(false);return;}tvInlineSwitching=true;if(tvInlineWatchdog!=null)tvInlineHandler.removeCallbacks(tvInlineWatchdog);tvInlineBufferingSince=0;tvInlineLastPosition=-1;tvInlineLastAdvanceAt=android.os.SystemClock.elapsedRealtime();
  int current=Math.max(0,Math.min(tvInlineSourceIndex,tvInlineSources.size()-1));String currentUrl=tvInlineSources.get(current);int target=current;boolean changedFormat=false;if(fromError){if(tvInlineFormatAttemptIndex!=current){tvInlineFormatAttemptIndex=current;tvInlineFormatAttemptMask=0;tvInlineFormatMode=0;}String path="";try{path=Uri.parse(currentUrl==null?"":currentUrl).getPath();}catch(Exception ignored){}String low=(path==null?"":path).toLowerCase(java.util.Locale.US);boolean dottedHls=low.endsWith(".m3u8")||low.endsWith(".m3u");boolean bareHls=low.endsWith("/m3u8")||low.endsWith("/m3u")||low.equals("m3u8")||low.equals("m3u");boolean ts=low.endsWith(".ts")||low.endsWith("/ts")||low.equals("ts");boolean knownProgressive=low.endsWith(".mp4")||low.endsWith(".mkv")||low.endsWith(".avi")||low.endsWith(".webm")||low.endsWith(".mov")||low.endsWith(".m4v");int nextMode=0;if(dottedHls){if((tvInlineFormatAttemptMask&1)==0)nextMode=1;}else if(bareHls){if((tvInlineFormatAttemptMask&2)==0)nextMode=2;else if((tvInlineFormatAttemptMask&1)==0)nextMode=1;}else if(ts){if((tvInlineFormatAttemptMask&2)==0)nextMode=2;}else if(!knownProgressive){if((tvInlineFormatAttemptMask&2)==0)nextMode=2;else if((tvInlineFormatAttemptMask&1)==0)nextMode=1;}if(nextMode!=0){tvInlineFormatMode=nextMode;tvInlineFormatAttemptMask|=nextMode==1?1:2;changedFormat=true;}}if(!changedFormat){boolean canRetrySame=!fromError&&tvInlineRecoveryCount<1;target=canRetrySame?current:(current+1<tvInlineSources.size()?current+1:current);}tvInlineRecoveryCount++;final int generation=tvPlaybackGeneration;final int retryTarget=target;
  tvInlineHandler.postDelayed(()->{if(generation!=tvPlaybackGeneration){tvInlineSwitching=false;return;}tvInlineSwitching=false;if(tvActiveChannel!=null&&tvInlinePlayerView!=null)tvStartInlineSource(retryTarget);},fromError?350:500);
 }
 void toggleTvInlineMute(){tvInlineMuted=!tvInlineMuted;try{if(tvInlinePlayer!=null)tvInlinePlayer.setVolume(tvInlineMuted?0f:1f);}catch(Exception ignored){}if(tvSoundButton!=null)tvSoundButton.setText(tvInlineMuted?"Sem som":"Som");}
 void castTvInlineToTv(){if(tvActiveChannel==null){showAppNotice("Escolha um canal antes de transmitir.",true);return;}String url=(tvInlineSourceIndex>=0&&tvInlineSourceIndex<tvInlineSources.size())?tvInlineSources.get(tvInlineSourceIndex):tvLiveUrl(tvActiveChannel);if(url.isEmpty()){showAppNotice("Este canal não está disponível para transmissão.",true);return;}String title=tvChannelName(tvActiveChannel);CastHelper.cast(this,url,title,true,()->{try{if(tvInlinePlayer!=null&&tvInlinePlayer.isPlaying())tvInlinePlayer.pause();}catch(Exception ignored){}});}
 View tvFindFocusedOrActiveChannelView(){if(tvChannelHost==null)return null;View current=getCurrentFocus();if(current!=null&&current.getParent()==tvChannelHost)return current;String id=tvChannelKey(tvActiveChannel);if(!id.isEmpty()){for(int i=0;i<tvChannelHost.getChildCount();i++){View c=tvChannelHost.getChildAt(i);if(c!=null&&id.equals(String.valueOf(c.getTag())))return c;}}return firstFocusableChild(tvChannelHost);}
 void openTvInlineFullscreen(){
  if(tvActiveChannel==null||tvInlinePlayerView==null||tvPreviewFrame==null||tvInlineFullscreen||tvUiTransitioning)return;
  // v16.209 TV-only: em Android TV/TV Box nao reparentamos o SurfaceView.
  // Alguns decoders de TV ficam verdes ou perdem o Surface ao remover/adicionar o player.
  if(tvMode&&wideTvUi()){
   tvUiTransitioning=true;tvInlineFullscreen=true;tvSavedScrollY=0;
   if(tvInlineWatchdog!=null&&tvInlineHandler!=null)tvInlineHandler.removeCallbacks(tvInlineWatchdog);
   tvPreviewHomeParent=null;tvPreviewHomeLayoutParams=null;tvPreviewHomeIndex=-1;
   if(contentFrame!=null)contentFrame.setBackgroundColor(Color.BLACK);
   if(navBar!=null)navBar.setVisibility(View.GONE);if(tvTopBar!=null)tvTopBar.setVisibility(View.GONE);if(tvTabsBar!=null)tvTabsBar.setVisibility(View.GONE);if(tvWideLeftPanel!=null)tvWideLeftPanel.setVisibility(View.GONE);if(tvPanesView!=null)tvPanesView.setVisibility(View.GONE);if(tvWideSplit!=null){tvWideSplit.setVisibility(View.VISIBLE);tvWideSplit.requestLayout();}
   if(body!=null){body.setVisibility(View.VISIBLE);body.setPadding(0,0,0,0);}if(root!=null){root.setPadding(0,0,0,0);root.setBackgroundColor(Color.BLACK);}tvPreviewFrame.setBackgroundColor(Color.BLACK);tvPreviewFrame.setPadding(0,0,0,0);
   if(tvInlinePlayerView!=null){tvInlinePlayerView.setBackgroundColor(Color.BLACK);tvInlinePlayerView.setShutterBackgroundColor(Color.BLACK);tvInlinePlayerView.setScaleX(1f);tvInlinePlayerView.setScaleY(1f);tvInlinePlayerView.setResizeMode(androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FILL);}if(tvFullButton!=null)tvFullButton.setText("Sair");
   try{if(tvInlinePlayer!=null&&!tvInlinePlayer.isPlaying())tvInlinePlayer.play();}catch(Exception ignored){}
   try{getWindow().setStatusBarColor(Color.BLACK);getWindow().setNavigationBarColor(Color.BLACK);getWindow().getDecorView().setBackgroundColor(Color.BLACK);getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE);}catch(Exception ignored){}
   tvOrientationTransition=false;applyTvInlineFullscreenSize();showTvEpgOverlayTemporarily();tvInlineHandler.postDelayed(()->{tvUiTransitioning=false;if(tvInlineFullscreen&&tvPreviewFrame!=null)applyTvInlineFullscreenSize();startTvInlineWatchdog();},120);return;
  }
  tvUiTransitioning=true;tvInlineFullscreen=true;tvSavedScrollY=0;
  if(tvInlineWatchdog!=null&&tvInlineHandler!=null)tvInlineHandler.removeCallbacks(tvInlineWatchdog);
  ViewParent currentParent=tvPreviewFrame.getParent();if(currentParent instanceof ViewGroup){tvPreviewHomeParent=(ViewGroup)currentParent;tvPreviewHomeIndex=tvPreviewHomeParent.indexOfChild(tvPreviewFrame);tvPreviewHomeLayoutParams=tvPreviewFrame.getLayoutParams();tvPreviewHomeParent.removeView(tvPreviewFrame);}if(contentFrame!=null){contentFrame.setBackgroundColor(Color.BLACK);contentFrame.addView(tvPreviewFrame,new FrameLayout.LayoutParams(-1,-1));tvPreviewFrame.bringToFront();}tvPreviewFrame.setBackgroundColor(Color.BLACK);tvPreviewFrame.setPadding(0,0,0,0);if(tvInlinePlayerView!=null){tvInlinePlayerView.setBackgroundColor(Color.BLACK);tvInlinePlayerView.setShutterBackgroundColor(Color.BLACK);tvInlinePlayerView.setLayoutParams(new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));tvInlinePlayerView.setScaleX(1f);tvInlinePlayerView.setScaleY(1f);tvInlinePlayerView.setResizeMode(androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FILL);}
  if(tvTopBar!=null)tvTopBar.setVisibility(View.GONE);if(tvTabsBar!=null)tvTabsBar.setVisibility(View.GONE);if(tvPanesView!=null)tvPanesView.setVisibility(View.GONE);if(navBar!=null)navBar.setVisibility(View.GONE);if(tvFullButton!=null)tvFullButton.setText("Sair");if(body!=null)body.setPadding(0,0,0,0);if(root!=null){root.setPadding(0,0,0,0);root.setBackgroundColor(Color.BLACK);}try{if(tvInlinePlayer!=null&&!tvInlinePlayer.isPlaying())tvInlinePlayer.play();}catch(Exception ignored){}
  try{getWindow().setStatusBarColor(Color.BLACK);getWindow().setNavigationBarColor(Color.BLACK);getWindow().getDecorView().setBackgroundColor(Color.BLACK);getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE);}catch(Exception ignored){}
  if(!tvMode&&getResources().getConfiguration().orientation!=android.content.res.Configuration.ORIENTATION_LANDSCAPE){tvOrientationTransition=true;tvInlineHandler.postDelayed(()->{try{setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);}catch(Exception ignored){}},16);}else tvOrientationTransition=false;
  applyTvInlineFullscreenSize();showTvEpgOverlayTemporarily();tvInlineHandler.postDelayed(()->{tvUiTransitioning=false;if(tvInlineFullscreen&&tvPreviewFrame!=null)applyTvInlineFullscreenSize();startTvInlineWatchdog();},180);
 }
 void applyTvInlineFullscreenSize(){
  if(!tvInlineFullscreen||tvPreviewFrame==null)return;tvPreviewFrame.setBackgroundColor(Color.BLACK);tvPreviewFrame.setPadding(0,0,0,0);
  if(tvMode&&tvPreviewFrame.getParent() instanceof FrameLayout){FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER);lp.setMargins(0,0,0,0);tvPreviewFrame.setLayoutParams(lp);}
  else if(tvPreviewFrame.getParent()==contentFrame){FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(-1,-1);lp.setMargins(0,0,0,0);tvPreviewFrame.setLayoutParams(lp);}
  else{LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-1);lp.setMargins(0,0,0,0);tvPreviewFrame.setLayoutParams(lp);}
  if(tvInlinePlayerView!=null){tvInlinePlayerView.setResizeMode(androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FILL);tvInlinePlayerView.setScaleX(1f);tvInlinePlayerView.setScaleY(1f);}tvPreviewFrame.requestLayout();tvPreviewFrame.post(()->applyTvSafeSideFill(tvVideoWidth,tvVideoHeight,tvVideoPixelRatio));
 }
 void closeTvInlineFullscreen(){
  if(!tvInlineFullscreen||tvUiTransitioning)return;
  // v16.209 TV-only: restaura o layout sem destacar/reanexar o Surface do player.
  if(tvMode&&wideTvUi()){
   destroyTvFullscreenChannelOverlay();tvUiTransitioning=true;tvInlineFullscreen=false;if(tvInlineWatchdog!=null&&tvInlineHandler!=null)tvInlineHandler.removeCallbacks(tvInlineWatchdog);
   tvPreviewHomeParent=null;tvPreviewHomeLayoutParams=null;tvPreviewHomeIndex=-1;tvCinemaMode=false;tvCinemaDrawerOpen=false;
   if(contentFrame!=null)contentFrame.setBackgroundColor(Color.TRANSPARENT);if(root!=null){root.setBackgroundColor(BG);root.setPadding(0,0,0,0);}if(body!=null){body.setVisibility(View.VISIBLE);body.setPadding(0,0,0,0);}if(tvWideSplit!=null)tvWideSplit.setVisibility(View.VISIBLE);if(tvWideLeftPanel!=null)tvWideLeftPanel.setVisibility(View.VISIBLE);if(tvPanesView!=null)tvPanesView.setVisibility(View.VISIBLE);if(navBar!=null)navBar.setVisibility(View.VISIBLE);if(tvTopBar!=null)tvTopBar.setVisibility(View.VISIBLE);if(tvTabsBar!=null)tvTabsBar.setVisibility(View.VISIBLE);if(tvFullButton!=null)tvFullButton.setText("Tela cheia");
   if(tvPreviewFrame!=null){tvPreviewFrame.setVisibility(View.VISIBLE);tvPreviewFrame.setBackgroundColor(Color.BLACK);tvPreviewFrame.setPadding(0,0,0,0);ViewParent parent=tvPreviewFrame.getParent();if(parent instanceof FrameLayout){FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER);lp.setMargins(0,0,0,0);tvPreviewFrame.setLayoutParams(lp);}}
   if(tvInlinePlayerView!=null){tvInlinePlayerView.setVisibility(View.VISIBLE);tvInlinePlayerView.setResizeMode(androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FILL);tvInlinePlayerView.setScaleX(1f);tvInlinePlayerView.setScaleY(1f);tvInlinePlayerView.setBackgroundColor(Color.BLACK);tvInlinePlayerView.setShutterBackgroundColor(Color.BLACK);}try{if(tvInlinePlayer!=null&&!tvInlinePlayer.isPlaying())tvInlinePlayer.play();}catch(Exception ignored){}
   tvOrientationTransition=false;try{enterTvImmersiveUi();getWindow().getDecorView().setBackgroundColor(BG);}catch(Exception ignored){}
   tvInlineHandler.postDelayed(()->{tvUiTransitioning=false;ensureTvPageVisibleAfterFullscreen();if(tvPreviewFrame!=null)applyTvSafeSideFill(tvVideoWidth,tvVideoHeight,tvVideoPixelRatio);showTvEpgOverlayTemporarily();startTvInlineWatchdog();View hit=tvFindFocusedOrActiveChannelView();if(hit!=null)requestTvFocus(hit);else if(tvCategoryHost!=null&&tvFocusedCategoryIndex>=0&&tvFocusedCategoryIndex<tvCategoryHost.getChildCount())requestTvFocus(tvCategoryHost.getChildAt(tvFocusedCategoryIndex));else if(navTv!=null)requestTvFocus(navTv);},90);return;
  }
  destroyTvFullscreenChannelOverlay();tvUiTransitioning=true;tvInlineFullscreen=false;if(tvInlineWatchdog!=null&&tvInlineHandler!=null)tvInlineHandler.removeCallbacks(tvInlineWatchdog);
  ViewParent current=tvPreviewFrame==null?null:tvPreviewFrame.getParent();if(current instanceof ViewGroup)((ViewGroup)current).removeView(tvPreviewFrame);if(tvPreviewFrame!=null&&tvPreviewHomeParent!=null){int idx=Math.max(0,Math.min(tvPreviewHomeIndex,tvPreviewHomeParent.getChildCount()));try{tvPreviewHomeParent.addView(tvPreviewFrame,idx,tvPreviewHomeLayoutParams);}catch(Exception e){try{tvPreviewHomeParent.addView(tvPreviewFrame,idx);}catch(Exception ignored){}}}tvPreviewHomeParent=null;tvPreviewHomeLayoutParams=null;tvPreviewHomeIndex=-1;
  if(contentFrame!=null)contentFrame.setBackgroundColor(Color.TRANSPARENT);if(root!=null)root.setBackgroundColor(BG);if(tvPreviewFrame!=null)tvPreviewFrame.setBackgroundColor(Color.BLACK);try{getWindow().getDecorView().setBackgroundColor(BG);}catch(Exception ignored){}
  tvCinemaMode=false;tvCinemaDrawerOpen=false;if(tvWideSplit!=null)tvWideSplit.setVisibility(View.VISIBLE);if(tvWideLeftPanel!=null)tvWideLeftPanel.setVisibility(View.VISIBLE);
  if(wideTvUi()){standardRootInsets();if(body!=null)body.setPadding(0,dp(12),0,dp(18));}else{tvRootInsets();if(body!=null)body.setPadding(0,0,0,0);}if(navBar!=null)navBar.setVisibility(View.VISIBLE);if(tvTopBar!=null)tvTopBar.setVisibility(View.VISIBLE);if(tvTabsBar!=null)tvTabsBar.setVisibility(View.VISIBLE);if(tvPanesView!=null)tvPanesView.setVisibility(View.VISIBLE);if(tvFullButton!=null)tvFullButton.setText("Tela cheia");if(tvInlinePlayerView!=null){tvInlinePlayerView.setResizeMode(androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FILL);tvInlinePlayerView.setScaleX(1f);tvInlinePlayerView.setScaleY(1f);}if(wideTvUi()&&tvPreviewFrame!=null){ViewParent tvParent=tvPreviewFrame.getParent();if(tvParent instanceof ViewGroup)((ViewGroup)tvParent).setPadding(0,0,0,0);}if(tvPreviewFrame!=null&&tvPreviewFrame.getParent() instanceof LinearLayout){LinearLayout.LayoutParams lp=wideTvUi()?new LinearLayout.LayoutParams(-1,0,1):new LinearLayout.LayoutParams(-1,tvPreviewHeightPx());lp.setMargins(0,0,0,0);tvPreviewFrame.setLayoutParams(lp);}try{if(tvInlinePlayer!=null&&!tvInlinePlayer.isPlaying())tvInlinePlayer.play();}catch(Exception ignored){}
  if(tvMode){tvOrientationTransition=false;try{enterTvImmersiveUi();}catch(Exception ignored){}tvInlineHandler.postDelayed(()->{tvUiTransitioning=false;ensureTvPageVisibleAfterFullscreen();if(tvPreviewFrame!=null)applyTvSafeSideFill(tvVideoWidth,tvVideoHeight,tvVideoPixelRatio);showTvEpgOverlayTemporarily();startTvInlineWatchdog();View hit=tvChannelHost==null?null:firstFocusableChild(tvChannelHost);if(hit!=null)requestTvFocus(hit);else if(tvPreviewFrame!=null)requestTvFocus(tvPreviewFrame);},90);return;}
  try{getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);}catch(Exception ignored){}
  boolean needPortrait=getResources().getConfiguration().orientation!=android.content.res.Configuration.ORIENTATION_PORTRAIT;tvOrientationTransition=needPortrait;if(needPortrait)tvInlineHandler.postDelayed(()->{try{setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);}catch(Exception ignored){}},16);
  tvInlineHandler.postDelayed(()->{tvUiTransitioning=false;if(tvPreviewFrame!=null)applyTvSafeSideFill(tvVideoWidth,tvVideoHeight,tvVideoPixelRatio);showTvEpgOverlayTemporarily();startTvInlineWatchdog();},needPortrait?280:90);
 }
 void ensureTvPageVisibleAfterFullscreen(){
  if(!tvMode||currentNavIndex!=2||!wideTvUi())return;
  try{if(body!=null)body.setVisibility(View.VISIBLE);}catch(Exception ignored){}
  try{if(tvWideSplit!=null){tvWideSplit.setVisibility(View.VISIBLE);tvWideSplit.requestLayout();}}catch(Exception ignored){}
  try{if(tvWideLeftPanel!=null)tvWideLeftPanel.setVisibility(View.VISIBLE);}catch(Exception ignored){}
  try{if(tvPanesView!=null)tvPanesView.setVisibility(View.VISIBLE);}catch(Exception ignored){}
  try{if(navBar!=null)navBar.setVisibility(View.VISIBLE);}catch(Exception ignored){}
  boolean broken=body==null||body.getChildCount()==0||tvWideSplit==null||tvWideSplit.getParent()==null||tvPreviewFrame==null||tvPreviewFrame.getParent()==null;
  if(broken){
   // Fallback defensivo: se o parent do player foi perdido durante uma troca/buffering, remonta a tela TV em vez de deixar a tela vazia.
   try{liveContentWideTv();}catch(Exception ignored){}
  }
 }
 void tvDowngradeInlineQuality(){/* v16.116: removido. As qualidades do backend usam a mesma URL; reiniciar piorava o buffering. */}
 void enableIndependentTvScroll(ScrollView sc){if(sc==null)return;sc.setOnTouchListener((v,e)->{int a=e.getActionMasked();if(a==android.view.MotionEvent.ACTION_DOWN||a==android.view.MotionEvent.ACTION_MOVE){ViewParent p=v.getParent();while(p!=null){p.requestDisallowInterceptTouchEvent(true);p=p.getParent();}}else if(a==android.view.MotionEvent.ACTION_UP||a==android.view.MotionEvent.ACTION_CANCEL){ViewParent p=v.getParent();while(p!=null){p.requestDisallowInterceptTouchEvent(false);p=p.getParent();}}return false;});}
 @Override public void onConfigurationChanged(android.content.res.Configuration newConfig){super.onConfigurationChanged(newConfig);tvOrientationTransition=false;if(tvUiTransitioning&&tvInlineHandler!=null)tvInlineHandler.postDelayed(()->tvUiTransitioning=false,80);if(modeSwitchPending){int wanted=modeSwitchTargetTv?android.content.res.Configuration.ORIENTATION_LANDSCAPE:android.content.res.Configuration.ORIENTATION_PORTRAIT;if(newConfig.orientation==wanted){modeSwitchOrientationReady=true;modeSwitchHandler.postDelayed(()->finishModeSwitchClean(),40);}return;}if(tvInlineFullscreen)tvInlineHandler.postDelayed(()->applyTvInlineFullscreenSize(),80);}

 void acquireTvInlineSession(Runnable ok){
  if(tvInlineSessionHeld){if(ok!=null)ok.run();return;}if(ok!=null)tvInlinePendingAcquire=ok;if(tvInlineSessionAcquiring)return;tvInlineSessionAcquiring=true;String did=deviceId();Api.post("stream_session",Api.m("user_id",uid,"device_id",did,"action","acquire"),new Api.CB(){public void ok(JSONObject j){tvInlineSessionAcquiring=false;Runnable pending=tvInlinePendingAcquire;tvInlinePendingAcquire=null;JSONArray a=j.optJSONArray("result");if(j.optInt("status")!=200||a==null||a.length()==0){runOnUiThread(()->{String m=j.optString("message","Não foi possível iniciar a reprodução.");if(isAccessExpiredResponse(j)){JSONObject cached=readCachedAccessStatus();showAccessExpiredDialog(cached!=null?accessDeniedMessage(cached):m);refreshEntitlements(null);}else if(pending!=null)showAppNotice(m,true);});return;}runOnUiThread(()->{if(tvInlinePlayerView==null){Api.post("stream_session",Api.m("user_id",uid,"device_id",did,"action","release"),new Api.CB(){public void ok(JSONObject z){}public void err(String e){}});return;}tvInlineSessionHeld=true;startTvInlineHeartbeat();if(pending!=null)pending.run();});}public void err(String x){tvInlineSessionAcquiring=false;Runnable pending=tvInlinePendingAcquire;tvInlinePendingAcquire=null;if(pending!=null)runOnUiThread(()->showAppNotice(x==null||x.isEmpty()?"Não foi possível validar o limite de telas.":x,true));}});
 }
 void startTvInlineHeartbeat(){if(tvInlineHandler==null)return;if(tvInlineBeat!=null)tvInlineHandler.removeCallbacks(tvInlineBeat);tvInlineBeat=new Runnable(){public void run(){try{if(!tvInlineSessionHeld||isFinishing()||(android.os.Build.VERSION.SDK_INT>=17&&isDestroyed()))return;Api.post("stream_session",Api.m("user_id",uid,"device_id",deviceId(),"action","heartbeat"),new Api.CB(){public void ok(JSONObject j){}public void err(String e){}});if(tvInlineHandler!=null)tvInlineHandler.postDelayed(this,45000);}catch(Exception ignored){if(tvInlineSessionHeld&&tvInlineHandler!=null)tvInlineHandler.postDelayed(this,45000);}}};tvInlineHandler.postDelayed(tvInlineBeat,45000);}
 void releaseTvInlineSession(){if(tvInlineBeat!=null)tvInlineHandler.removeCallbacks(tvInlineBeat);tvInlineBeat=null;if(!tvInlineSessionHeld)return;tvInlineSessionHeld=false;Api.post("stream_session",Api.m("user_id",uid,"device_id",deviceId(),"action","release"),new Api.CB(){public void ok(JSONObject j){}public void err(String e){}});}
 void handoffTvInlineSession(){if(tvInlineBeat!=null)tvInlineHandler.removeCallbacks(tvInlineBeat);tvInlineBeat=null;tvInlineSessionHeld=false;}
 void releaseTvInlinePlayer(){
  // v16.236: transição entre TV/Destaque/Futebol/Filmes/Séries/Kids/Favoritos NÃO
  // destrói o ExoPlayer na thread principal. Alguns decoders de TV Box podem levar
  // vários segundos dentro de release(), gerando ANR. Pausamos, soltamos a Surface
  // e mantemos uma única instância para reutilização quando o usuário voltar à TV.
  tvChannelSwitchGeneration++;tvPlaybackGeneration++;tvChannelListGeneration++;tvChannelChunkPending=false;if(tvChannelRefreshTask!=null&&tvChannelHost!=null){try{tvChannelHost.removeCallbacks(tvChannelRefreshTask);}catch(Exception ignored){}}tvChannelRefreshTask=null;tvQueuedChannel=null;tvQueuedChannelSwitch=null;if(tvInlineHandler!=null)tvInlineHandler.removeCallbacksAndMessages(null);releaseTvInlineSession();
  try{if(tvInlinePlayer!=null){tvInlinePlayer.setPlayWhenReady(false);tvInlinePlayer.pause();}}catch(Exception ignored){}try{if(tvInlinePlayerView!=null)tvInlinePlayerView.setPlayer(null);}catch(Exception ignored){}
  tvInlineSessionAcquiring=false;tvInlinePendingAcquire=null;destroyTvFullscreenChannelOverlay();tvCurrentChannels=new JSONArray();if(tvInlineWatchdog!=null&&tvInlineHandler!=null)tvInlineHandler.removeCallbacks(tvInlineWatchdog);tvInlineWatchdog=null;tvEpgBeat=null;tvEpgHide=null;tvEpgOverlay=null;clearTvBackdrop();tvVideoBackdrop=null;tvPreviewHomeParent=null;tvPreviewHomeLayoutParams=null;tvPreviewHomeIndex=-1;tvInlinePlayerView=null;tvPreviewFrame=null;tvPreviewPlaceholder=null;tvPreviewLoadingLogo=null;tvPreviewLoadingProgress=null;tvPreviewLoadingStatus=null;tvPreviewTitle=null;tvPreviewSubtitle=null;tvNowPlaying=null;tvEpgNow=null;tvEpgNext=null;tvSoundButton=null;tvCastButton=null;tvFullButton=null;tvActiveChannel=null;tvInlinePrepared=false;tvInlineSwitching=false;tvInlineBufferStarts=0;tvInlineRecoveryCount=0;tvInlineFormatAttemptIndex=-1;tvInlineFormatAttemptMask=0;tvInlineFormatMode=0;tvInlineBufferingSince=0;tvInlineLastPosition=-1;tvInlineLastAdvanceAt=0;tvInlineSources.clear();tvResumeAfterFullscreen=false;tvResumeAfterBackground=false;tvInlineFullscreen=false;tvOrientationTransition=false;tvUiTransitioning=false;tvBackgroundAt=0;tvEpgRequestToken++;tvEpgCache.clear();tvEpgCacheAt.clear();tvCategoryScroll=null;tvCategoryRail=null;tvChannelScroll=null;tvFocusedCategoryIndex=-1;tvTopBar=null;tvTabsBar=null;tvPanesView=null;tvWideLeftPanel=null;tvWideSplit=null;tvCinemaMode=false;tvCinemaDrawerOpen=false;
 }
 void destroyTvInlinePlayer(){
  releaseTvInlinePlayer();androidx.media3.exoplayer.ExoPlayer doomed=tvInlinePlayer;tvInlinePlayer=null;if(doomed!=null){try{doomed.release();}catch(Exception ignored){}}
 }
 JSONArray liveFavArray(){try{return new JSONArray(sp.getString("live_favs","[]"));}catch(Exception e){return new JSONArray();}}
 boolean isLiveFav(JSONObject x){JSONArray a=liveFavArray();String id=x.optString("id",x.optString("channel_id",""));for(int i=0;i<a.length();i++){JSONObject y=a.optJSONObject(i);if(y!=null&&id.equals(y.optString("id",y.optString("channel_id",""))))return true;}return false;}
 void toggleLiveFav(JSONObject x){try{JSONArray a=liveFavArray();String id=x.optString("id",x.optString("channel_id",""));for(int i=0;i<a.length();i++){JSONObject y=a.optJSONObject(i);if(y!=null&&id.equals(y.optString("id",y.optString("channel_id","")))){a.remove(i);sp.edit().putString("live_favs",a.toString()).apply();return;}}a.put(new JSONObject(x.toString()));sp.edit().putString("live_favs",a.toString()).apply();}catch(Exception ignored){}}
 void openLive(JSONObject x){if(x==null)return;guardPlaybackAction(()->openLiveAllowed(x));}
 void openLiveAllowed(JSONObject x){String u=x.optString("video_1080",x.optString("video_720",x.optString("video_480",x.optString("video_320",""))));if(u.isEmpty()){Toast.makeText(this,"Canal indisponível",0).show();return;}Intent in=new Intent(this,PlayerActivity.class);in.putExtra("url",u);in.putExtra("url_1080",x.optString("video_1080",""));in.putExtra("url_720",x.optString("video_720",""));in.putExtra("url_480",x.optString("video_480",""));in.putExtra("url_320",x.optString("video_320",""));in.putExtra("title",x.optString("name","Canal"));in.putExtra("live",true);launchOnlinePlayer(in);}
 void pageTitle(String title,Runnable back){LinearLayout h=new LinearLayout(this);h.setGravity(Gravity.CENTER_VERTICAL);TextView b=t("‹",30);b.setTextColor(GREEN);b.setGravity(Gravity.CENTER);b.setOnClickListener(v->back.run());h.addView(b,new LinearLayout.LayoutParams(dp(48),dp(52)));TextView tt=t(title,24);tt.setTypeface(null,1);h.addView(tt,new LinearLayout.LayoutParams(0,dp(52),1));body.addView(h);}
 String fixTitle(String s){if(s==null)return "";return s.replace("Action & Adventure","Ação e Aventura").replace("Sci-Fi & Fantasy","Ficção Científica e Fantasia").replace("Science Fiction & Fantasy","Ficção Científica e Fantasia").replace("Family","Família").replace("Animation","Animação").replace("Crime","Crime").replace("Mystery","Mistério").replace("Comedy","Comédia").replace("Documentary","Documentário").replace("Acao","Ação").replace("acao","ação").replace("Animacao","Animação").replace("animacao","animação").replace("Series","Séries").replace("series","séries");}
 String shortsCategoryKey(String raw){if(raw==null)return "";String n=java.text.Normalizer.normalize(raw,java.text.Normalizer.Form.NFD).replaceAll("\\p{M}+","").toLowerCase(java.util.Locale.ROOT).replaceAll("[^a-z0-9]+","").trim();return n;}
 boolean isShortsCategoryTitle(String raw){String n=shortsCategoryKey(raw);return n.contains("relshort")||n.contains("reelshort")||n.contains("reelsshort")||(n.contains("reel")&&n.contains("short"))||n.contains("greenshort");}
 boolean isShortsSection(JSONObject sec){if(sec==null)return false;return isShortsCategoryTitle(sec.optString("title",sec.optString("category_name",sec.optString("name",""))));}
 String greenShortsCoverCandidate(String raw){if(raw==null)return "";String v=raw.trim();if(v.isEmpty())return "";String s=v.toLowerCase(java.util.Locale.ROOT);String flat=s.replaceAll("[^a-z0-9]","");if(flat.contains("reelshort")||flat.contains("reelsshort")||flat.contains("reelshorttv")||flat.contains("shortslogo")||flat.contains("reelshortlogo"))return "";return v;}
 void loadGreenShortsCover(ImageView im,JSONObject x){if(im==null)return;im.setScaleType(ImageView.ScaleType.CENTER_CROP);im.setBackgroundColor(CARD);im.setImageResource(R.drawable.greenshorts_fallback);if(x==null)return;Img.loadBest(im,greenShortsCoverCandidate(x.optString("portrait_img","")),greenShortsCoverCandidate(x.optString("poster","")),greenShortsCoverCandidate(x.optString("image","")),greenShortsCoverCandidate(x.optString("thumbnail","")),greenShortsCoverCandidate(x.optString("landscape","")),greenShortsCoverCandidate(x.optString("landscape_img","")),greenShortsCoverCandidate(x.optString("backdrop","")));}
 boolean isShortsCategory(JSONObject cat){if(cat==null)return false;return isShortsCategoryTitle(cat.optString("category_name",cat.optString("name",cat.optString("title",""))));}
 String cleanCategoryDisplayTitle(String raw,int typeId){
  String title=fixTitle(raw);if(title==null)title="";title=title.trim();
  if(isShortsCategoryTitle(title))return "Yelly Doramas";
  // 5.28.16: os provedores costumam decorar nomes com ♦ ⭐ ✔ ⚔ ☠ etc.
  // Isso continua intacto na fonte; limpamos SOMENTE a apresentação no app.
  title=title.replaceAll("^[^\\p{L}\\p{N}]+","").replaceAll("[^\\p{L}\\p{N}]+$","").trim();
  title=title.replaceAll("\\s+"," ").trim();
  if(title.isEmpty())title=typeId==2?"Séries":(typeId==1?"Filmes":"Conteúdos");
  return title;
 }
 String typedCategoryTitle(String raw,int typeId){
  String title=cleanCategoryDisplayTitle(raw,typeId);
  if(typeId!=1&&typeId!=2)return title;
  // Dentro das abas fixas Filmes/Séries o tipo já está óbvio: não repetir
  // “• Filmes” / “• Séries” em todas as categorias. Na Home principal,
  // mantém a identificação discreta porque Filmes e Séries aparecem juntos.
  boolean dedicated=(typeId==1&&"Filmes".equals(activeHomeTab))||(typeId==2&&"Séries".equals(activeHomeTab));
  if(dedicated)return title;
  String n=title.toLowerCase(java.util.Locale.ROOT);n=java.text.Normalizer.normalize(n,java.text.Normalizer.Form.NFD).replaceAll("\\p{M}+","");
  boolean already=typeId==2?(n.matches(".*\\b(series?|seriados?|tv series)\\b.*")):(n.matches(".*\\b(filmes?|movies?)\\b.*"));
  if(already)return title;
  return title+"  ·  "+(typeId==2?"Séries":"Filmes");
 }
  void row(JSONArray a){HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);r.setPadding(dp(2),0,dp(8),0);hs.addView(r);if(a!=null)for(int i=0;i<Math.min(16,a.length());i++){JSONObject x=a.optJSONObject(i);LinearLayout c=card(x);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(112),dp(202));cp.setMargins(dp(3),0,dp(8),0);r.addView(c,cp);}body.addView(hs,new LinearLayout.LayoutParams(-1,dp(204)));}
 LinearLayout card(JSONObject x){JSONObject merged=isYoutubeShort(x)?x:mergeDetailJson(x,readDetailCache(x));final JSONObject use=merged==null?x:merged;LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(2),dp(2),dp(2),0);c.setFocusable(true);FrameLayout poster=new FrameLayout(this);poster.setBackground(round(CARD,13));poster.setClipToOutline(true);ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);if("Shorts".equals(activeHomeTab))loadGreenShortsCover(im,use);else Img.loadBest(im,use.optString("thumbnail",""),use.optString("portrait_img",""),use.optString("image",""),use.optString("poster",""),use.optString("landscape",""),use.optString("landscape_img",""),use.optString("backdrop",""));poster.addView(im,new FrameLayout.LayoutParams(-1,-1));{String kind="Filmes".equals(activeHomeTab)||"Shorts".equals(activeHomeTab)?"FILME":("Turcas".equals(activeHomeTab)?"TURCA":"SÉRIE");TextView badge=t(kind,9);badge.setTextColor(Color.WHITE);badge.setTypeface(null,1);badge.setGravity(Gravity.CENTER);badge.setPadding(dp(7),0,dp(7),0);badge.setBackground(round(0xccb8007d,12));FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(-2,dp(23),Gravity.TOP|Gravity.LEFT);bp.setMargins(dp(7),dp(7),0,0);poster.addView(badge,bp);}c.addView(poster,new LinearLayout.LayoutParams(-1,dp(158)));TextView n=t(use.optString("name",use.optString("title","")),13);n.setPadding(dp(2),dp(6),dp(2),0);n.setMaxLines(2);n.setEllipsize(android.text.TextUtils.TruncateAt.END);c.addView(n,new LinearLayout.LayoutParams(-1,dp(42)));c.setOnClickListener(v->details(use));c.setOnLongClickListener(v->{toggleFav(use);return true;});return c;}

 void details(JSONObject x){
  if(detailOpen||detailPreparing||x==null)return;
  saveDetailCache(x,x);
  JSONObject cached=mergeDetailJson(x,readDetailCache(x));
  // v16.71: se o detalhe já foi preparado/prefetchado, abre instantaneamente.
  // Caso contrário, mantém a Home visível por um instante e só entra na tela
  // depois que detalhe + enriquecimento terminarem. Assim nenhum campo aparece
  // "chegando depois" diante do usuário.
  if(cached!=null&&!detailNeedsEnrich(cached)){openPreparedDetails(x,cached);return;}
  detailPreparing=true;showDetailPrepareOverlay();
  prepareDetailForOpen(x,new DetailPrepareCB(){public void done(JSONObject ready){runOnUiThread(()->{
   if(!detailPreparing)return;detailPreparing=false;hideDetailPrepareOverlay();
   JSONObject merged=mergeDetailJson(x,ready);openPreparedDetails(x,merged==null?x:merged);
  });}});
 }
 void showDetailPrepareOverlay(){
  if(contentFrame==null||detailPrepareOverlay!=null)return;
  FrameLayout ov=new FrameLayout(this);ov.setClickable(true);ov.setFocusable(true);ov.setBackgroundColor(0x7211070c);
  LinearLayout card=new LinearLayout(this);card.setGravity(Gravity.CENTER);card.setBackground(round(0xf221181c,22));card.setElevation(dp(8));
  ProgressBar pb=new ProgressBar(this);try{pb.getIndeterminateDrawable().setColorFilter(GREEN,android.graphics.PorterDuff.Mode.SRC_IN);}catch(Exception ignored){}
  card.addView(pb,new LinearLayout.LayoutParams(dp(34),dp(34)));
  FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(dp(72),dp(72),Gravity.CENTER);ov.addView(card,cp);
  detailPrepareOverlay=ov;contentFrame.addView(ov,new FrameLayout.LayoutParams(-1,-1));
 }
 void hideDetailPrepareOverlay(){if(detailPrepareOverlay!=null){try{if(detailPrepareOverlay.getParent() instanceof ViewGroup)((ViewGroup)detailPrepareOverlay.getParent()).removeView(detailPrepareOverlay);}catch(Exception ignored){}detailPrepareOverlay=null;}}
 
 java.util.Map<String,String> doramaEnrichArgs(JSONObject source){if(source==null)return Api.m();String q=source.optString("original_title",source.optString("name",source.optString("title","")));return Api.m("title",q,"display_name",source.optString("name",source.optString("title","")),"thumbnail",source.optString("thumbnail",source.optString("portrait_img","")),"landscape",source.optString("landscape",source.optString("backdrop","")),"series_key",source.optString("series_key",""),"category_name",source.optString("category_name","Yelly Doramas"),"language","pt-BR","lang","pt-BR","locale","pt-BR");}
 void prefetchGreenShortDetails(JSONArray rows,int limit){if(rows==null)return;for(int i=0;i<Math.min(limit,rows.length());i++){JSONObject x=rows.optJSONObject(i);if(x!=null&&isYoutubeShort(x))queueDetailPrefetch(x);}pumpDetailPrefetch();}
 void prepareDetailForOpen(JSONObject source,DetailPrepareCB cb){
  saveDetailCache(source,source);JSONObject first=mergeDetailJson(source,readDetailCache(source));
  if(first!=null&&!detailNeedsEnrich(first)){cb.done(first);return;}
  final boolean[] delivered={false};
  final Runnable deliver=()->{if(delivered[0])return;JSONObject ready=mergeDetailJson(source,readDetailCache(source));if(ready==null||detailNeedsEnrich(ready))return;delivered[0]=true;cb.done(ready);};
  if(isYoutubeShort(source)){Api.post("dorama_enrich",doramaEnrichArgs(source),new Api.CB(){public void ok(JSONObject j){JSONArray a=j.optJSONArray("result");JSONObject d=(a!=null&&a.length()>0)?a.optJSONObject(0):null;if(d!=null)saveDetailCache(source,d);deliver.run();if(!delivered[0]){detailPreparing=false;hideDetailPrepareOverlay();Toast.makeText(MainActivity.this,"Não foi possível carregar todos os dados.",Toast.LENGTH_SHORT).show();}}public void err(String e){detailPreparing=false;hideDetailPrepareOverlay();Toast.makeText(MainActivity.this,"Não foi possível carregar os dados.",Toast.LENGTH_SHORT).show();}});return;}
  int vt=source.optInt("video_type",source.optInt("type_id",1));String vid=source.optString("id",source.optString("video_id",""));
  Api.post("content_detail",Api.m("user_id",uid,"video_id",vid,"video_type",String.valueOf(vt),"category_id",source.optString("category_id",""),"provider_id",source.optString("provider_id","")),new Api.CB(){
   public void ok(JSONObject j){JSONArray a=j.optJSONArray("result");JSONObject d=(a!=null&&a.length()>0)?a.optJSONObject(0):null;if(d!=null)saveDetailCache(source,d);JSONObject ready=mergeDetailJson(source,readDetailCache(source));if(ready!=null&&!detailNeedsEnrich(ready)){deliver.run();return;}
    Api.post("content_enrich",Api.m("user_id",uid,"video_id",vid,"video_type",String.valueOf(vt)),new Api.CB(){public void ok(JSONObject e){JSONArray ea=e.optJSONArray("result");JSONObject ed=(ea!=null&&ea.length()>0)?ea.optJSONObject(0):null;if(ed!=null)saveDetailCache(source,ed);deliver.run();if(!delivered[0]){detailPreparing=false;hideDetailPrepareOverlay();Toast.makeText(MainActivity.this,"Ainda faltam informações desta série.",Toast.LENGTH_SHORT).show();}}public void err(String z){detailPreparing=false;hideDetailPrepareOverlay();Toast.makeText(MainActivity.this,"Não foi possível carregar todos os dados.",Toast.LENGTH_SHORT).show();}});}
   public void err(String e){detailPreparing=false;hideDetailPrepareOverlay();Toast.makeText(MainActivity.this,"Não foi possível carregar os dados.",Toast.LENGTH_SHORT).show();}
  });
 }
 void openPreparedDetails(JSONObject x,JSONObject prepared){
  if(detailOpen)return;
  detailOpen=true;savedViewGen=viewGen;viewGen++;
  if(root!=null)root.setPadding(0,standardPageTopPx(),0,0);
  savedScroll=mainScroll;savedBody=body;savedNavIndex=currentNavIndex;
  if(savedScroll!=null)savedScroll.setVisibility(View.GONE);
  // Em páginas TV (Filmes/Séries/Kids), o host não é um ScrollView.
  // Ele também precisa sumir; caso contrário fica aparecendo por trás do detalhe.
  if(tvPageRoot!=null&&tvPageRoot.getParent()==contentFrame)tvPageRoot.setVisibility(View.GONE);
  if(navBar!=null)navBar.setVisibility(View.GONE);
  mainScroll=new ScrollView(this);mainScroll.setFillViewport(true);mainScroll.setClipToPadding(false);mainScroll.setVerticalScrollBarEnabled(false);mainScroll.setSmoothScrollingEnabled(false);mainScroll.setBackgroundColor(BG);
  body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(0,0,0,dp(28));body.setBackgroundColor(BG);mainScroll.setPadding(0,0,0,0);mainScroll.setClipToPadding(false);mainScroll.addView(body);
  if(contentFrame!=null){contentFrame.setBackgroundColor(BG);contentFrame.addView(mainScroll,new FrameLayout.LayoutParams(-1,-1));bindScrollTopButton(mainScroll);mainScroll.bringToFront();if(scrollTopButton!=null)scrollTopButton.bringToFront();}
  setNav(savedNavIndex);
  final String title=x.optString("name",x.optString("title",""));JSONObject ready=mergeDetailJson(x,prepared);if(ready==null)ready=x;saveDetailCache(x,ready);

  FrameLayout hero=new FrameLayout(this);hero.setBackgroundColor(BG);hero.setClipToPadding(false);
  ImageView p=new ImageView(this);p.setScaleType(ImageView.ScaleType.CENTER_CROP);String heroStart=detailValue(ready,"landscape","landscape_img","backdrop","backdrop_path","thumbnail","portrait_img");if(heroStart.isEmpty())heroStart=x.optString("landscape",x.optString("landscape_img",x.optString("thumbnail",x.optString("portrait_img",""))));Img.loadVisible(p,heroStart);hero.addView(p,new FrameLayout.LayoutParams(-1,-1));
  GradientDrawable topShade=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0x8f000000,0x20000000,0x00000000});View tsh=new View(this);tsh.setBackground(topShade);hero.addView(tsh,new FrameLayout.LayoutParams(-1,-1));
  GradientDrawable bottomShade=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0x00000000,0x18000000,0xaa0d070a,0xff11070c});View bsh=new View(this);bsh.setBackground(bottomShade);hero.addView(bsh,new FrameLayout.LayoutParams(-1,-1));
  TextView back=t("‹",29);back.setTextColor(Color.WHITE);back.setGravity(Gravity.CENTER);back.setIncludeFontPadding(false);back.setPadding(0,0,0,dp(2));back.setBackground(detailGlassCircle());back.setElevation(dp(3));back.setFocusable(true);back.setFocusableInTouchMode(false);back.setOnClickListener(v->closeDetails());FrameLayout.LayoutParams blp=new FrameLayout.LayoutParams(dp(46),dp(46),Gravity.TOP|Gravity.LEFT);blp.setMargins(dp(14),dp(14),0,0);hero.addView(back,blp);
  TextView heart=t(isFav(x)?"♥":"♡",22);heart.setTextColor(Color.WHITE);heart.setGravity(Gravity.CENTER);heart.setIncludeFontPadding(false);heart.setPadding(0,0,0,0);heart.setBackground(detailGlassCircle());heart.setElevation(dp(3));FrameLayout.LayoutParams hlp=new FrameLayout.LayoutParams(dp(46),dp(46),Gravity.TOP|Gravity.RIGHT);hlp.setMargins(0,dp(14),dp(14),0);hero.addView(heart,hlp);
  heart.setOnClickListener(v->{toggleFav(x);heart.setText(isFav(x)?"♥":"♡");});
  LinearLayout heroInfo=new LinearLayout(this);heroInfo.setOrientation(LinearLayout.VERTICAL);heroInfo.setPadding(dp(18),dp(8),dp(18),dp(10));int detailMax=tvMode?Math.min(getResources().getDisplayMetrics().widthPixels-dp(100),dp(1120)):-1;FrameLayout.LayoutParams ilp=new FrameLayout.LayoutParams(detailMax,-2,Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);hero.addView(heroInfo,ilp);
  String readyTitle=detailValue(ready,"name","title");if(readyTitle.isEmpty())readyTitle=title;TextView hn=t(readyTitle,27);hn.setTypeface(null,1);hn.setMaxLines(2);hn.setLineSpacing(0,1.02f);hn.setPadding(0,0,0,0);heroInfo.addView(hn);
  LinearLayout.LayoutParams heroLp=new LinearLayout.LayoutParams(-1,dp(365));heroLp.setMargins(0,0,0,dp(6));body.addView(hero,heroLp);

  final LinearLayout detailHost=new LinearLayout(this);detailHost.setOrientation(LinearLayout.VERTICAL);detailHost.setPadding(dp(18),0,dp(18),0);LinearLayout detailWrap=new LinearLayout(this);detailWrap.setGravity(Gravity.CENTER_HORIZONTAL);detailWrap.addView(detailHost,new LinearLayout.LayoutParams(tvMode?Math.min(getResources().getDisplayMetrics().widthPixels-dp(100),dp(1120)):-1,-2));body.addView(detailWrap,new LinearLayout.LayoutParams(-1,-2));
  renderDetailContent(detailHost,x,ready,hn,p,heart,readyTitle,false);
  // 52704: temporadas/episódios são a parte estrutural da série e não podem
  // depender do TMDB. Se a tela abriu com um snapshot antigo/incompleto, busca
  // novamente o detalhe rápido; o enriquecimento TMDB atualiza a mesma tela
  // quando chegar, sem transformar série em um detalhe com aparência de filme.
  final int detailGen=viewGen;
  int readyVt=ready.optInt("video_type",ready.optInt("type_id",x.optInt("video_type",x.optInt("type_id",1))));
  if(readyVt==2){if(detailNeedsEnrich(ready))requestSeriesCoreDetail(x,hn,p,heart,readyTitle,detailHost,detailGen);else requestSeriesMetadataEnrich(x,hn,p,heart,readyTitle,detailHost,detailGen);}
  else requestDetailEnrich(x,hn,p,heart,readyTitle,detailHost,detailGen);
  // TV: a tela de detalhes deve SEMPRE nascer no topo com o banner visível.
  // Alguns aparelhos davam foco automático ao botão Assistir e faziam o ScrollView
  // pular para baixo antes do primeiro frame, escondendo quase todo o hero.
  Runnable pinDetailTop=()->{if(!detailOpen||mainScroll==null)return;try{mainScroll.scrollTo(0,0);if(tvMode&&back.isShown()&&!back.hasFocus())back.requestFocus();mainScroll.scrollTo(0,0);}catch(Exception ignored){}};
  pinDetailTop.run();mainScroll.post(pinDetailTop);mainScroll.postDelayed(pinDetailTop,60);mainScroll.postDelayed(pinDetailTop,180);mainScroll.postDelayed(pinDetailTop,420);
 }
 JSONObject readDetailCache(JSONObject x){try{String k=detailCacheKey(x);String mem=detailMemoryCache.get(k);if(mem!=null&&!mem.isEmpty())return new JSONObject(mem);String raw=sp.getString("detail_"+k,"");if(raw.isEmpty())return null;detailMemoryCache.put(k,raw);return new JSONObject(raw);}catch(Exception e){return null;}}
 void saveDetailCache(JSONObject x,JSONObject d){if(d==null)return;try{JSONObject merged=mergeDetailJson(readDetailCache(x),d);String k=detailCacheKey(x),raw=merged.toString();detailMemoryCache.put(k,raw);sp.edit().putString("detail_"+k,raw).apply();}catch(Exception ignored){}}
 JSONObject mergeDetailJson(JSONObject base,JSONObject add){JSONObject out=new JSONObject();try{if(base!=null){java.util.Iterator<String> it=base.keys();while(it.hasNext()){String k=it.next();out.put(k,base.opt(k));}}if(add!=null){java.util.Iterator<String> it=add.keys();while(it.hasNext()){String k=it.next();Object v=add.opt(k);boolean useful=v!=null&&v!=JSONObject.NULL;if(v instanceof String)useful=!((String)v).trim().isEmpty();if(v instanceof JSONArray)useful=((JSONArray)v).length()>0;if(useful)out.put(k,v);}}}catch(Exception ignored){}return out;}
 boolean detailNeedsEnrich(JSONObject d){if(d==null)return true;if(isYoutubeShort(d)){String desc=doramaDescriptionPt(d);return d.optInt("tmdb_enriched",0)!=1||desc.trim().isEmpty();}String desc=detailValue(d,"description","plot","overview"),genre=detailValue(d,"category_name","genre","genres"),rating=detailValue(d,"imdb_rating","rating","vote_average","score"),back=detailValue(d,"landscape","landscape_img","backdrop","backdrop_path");JSONArray cast=d.optJSONArray("cast_list");int vt=d.optInt("video_type",d.optInt("type_id",1));boolean series=vt==2||"series".equalsIgnoreCase(d.optString("type",""));if(series){JSONArray seasons=detailSeriesSeasons(d);JSONObject eps=d.optJSONObject("episodes_by_season");if(seasons.length()==0||eps==null||eps.length()==0)return true;java.util.Iterator<String> it=eps.keys();while(it.hasNext()){JSONArray a=eps.optJSONArray(it.next());if(a==null)continue;for(int i=0;i<a.length();i++){JSONObject ep=a.optJSONObject(i);if(ep!=null&&!detailPlayUrl(ep).isEmpty())return false;}}return true;}return desc.isEmpty()||genre.isEmpty()||rating.isEmpty()||back.isEmpty()||cast==null||cast.length()==0;}
 void requestSeriesCoreDetail(JSONObject source,TextView hn,ImageView heroImage,TextView heart,String fallbackTitle,LinearLayout detailHost,int gen){
  if(source==null)return;int vt=source.optInt("video_type",source.optInt("type_id",1));if(vt!=2)return;
  Api.post("content_detail",Api.m("user_id",uid,"video_id",source.optString("id"),"video_type","2","category_id",source.optString("category_id",""),"provider_id",source.optString("provider_id","")),new Api.CB(){public void ok(JSONObject j){if(gen!=viewGen||!detailOpen)return;JSONArray a=j.optJSONArray("result");JSONObject d=(a!=null&&a.length()>0)?a.optJSONObject(0):null;if(d==null||detailSeriesSeasons(d).length()==0)return;saveDetailCache(source,d);JSONObject merged=mergeDetailJson(source,readDetailCache(source));if(merged==null)return;int y=mainScroll==null?0:mainScroll.getScrollY();detailHost.removeAllViews();renderDetailContent(detailHost,source,merged,hn,heroImage,heart,fallbackTitle,false);if(mainScroll!=null)mainScroll.post(()->mainScroll.scrollTo(0,Math.max(0,y)));requestSeriesMetadataEnrich(source,hn,heroImage,heart,fallbackTitle,detailHost,gen);}public void err(String e){}});
 }
 boolean seriesNeedsMetadata(JSONObject d){if(d==null)return true;return detailValue(d,"description","plot","overview").isEmpty()||detailValue(d,"category_name","genre","genres").isEmpty()||detailValue(d,"landscape","landscape_img","backdrop","backdrop_path").isEmpty()||d.optInt("tmdb_id",0)<=0;}
 void requestSeriesMetadataEnrich(JSONObject source,TextView hn,ImageView heroImage,TextView heart,String fallbackTitle,LinearLayout detailHost,int gen){
  JSONObject cur=readDetailCache(source);if(cur!=null&&!seriesNeedsMetadata(cur))return;
  Api.post("content_enrich",Api.m("user_id",uid,"video_id",source.optString("id"),"video_type","2","category_id",source.optString("category_id",""),"provider_id",source.optString("provider_id","")),new Api.CB(){public void ok(JSONObject j){if(gen!=viewGen||!detailOpen)return;JSONArray a=j.optJSONArray("result");JSONObject d=(a!=null&&a.length()>0)?a.optJSONObject(0):null;if(d==null)return;saveDetailCache(source,d);JSONObject merged=mergeDetailJson(source,readDetailCache(source));if(merged==null)return;int y=mainScroll==null?0:mainScroll.getScrollY();detailHost.removeAllViews();renderDetailContent(detailHost,source,merged,hn,heroImage,heart,fallbackTitle,false);if(mainScroll!=null)mainScroll.post(()->mainScroll.scrollTo(0,Math.max(0,y)));}public void err(String e){}});
 }
 
 void requestDetailEnrich(JSONObject source,TextView hn,ImageView heroImage,TextView heart,String fallbackTitle,LinearLayout detailHost,int gen){
  if(isYoutubeShort(source)){String q=source.optString("original_title",source.optString("name",fallbackTitle));Api.post("dorama_enrich",Api.m("title",q,"display_name",source.optString("name",source.optString("title","")),"thumbnail",source.optString("thumbnail",source.optString("portrait_img","")),"landscape",source.optString("landscape",source.optString("backdrop","")),"series_key",source.optString("series_key",""),"category_name",source.optString("category_name","Yelly Doramas")),new Api.CB(){public void ok(JSONObject j){if(gen!=viewGen||!detailOpen)return;JSONArray a=j.optJSONArray("result");JSONObject d=(a!=null&&a.length()>0)?a.optJSONObject(0):null;if(d==null)return;saveDetailCache(source,d);JSONObject merged=mergeDetailJson(source,readDetailCache(source));if(merged==null)return;int y=mainScroll==null?0:mainScroll.getScrollY();detailHost.removeAllViews();renderDetailContent(detailHost,source,merged,hn,heroImage,heart,fallbackTitle,false);if(mainScroll!=null)mainScroll.post(()->mainScroll.scrollTo(0,Math.max(0,y)));}public void err(String e){}});return;}
  JSONObject cur=readDetailCache(source);if(cur!=null&&!detailNeedsEnrich(cur))return;
  Api.post("content_detail",Api.m("user_id",uid,"video_id",source.optString("id"),"video_type",String.valueOf(source.optInt("video_type",source.optInt("type_id",1))),"category_id",source.optString("category_id",""),"provider_id",source.optString("provider_id","")),new Api.CB(){
   public void ok(JSONObject j){if(gen!=viewGen||!detailOpen)return;JSONArray a=j.optJSONArray("result");JSONObject d=(a!=null&&a.length()>0)?a.optJSONObject(0):null;if(d==null)return;saveDetailCache(source,d);JSONObject merged=readDetailCache(source);if(merged==null)return;int y=mainScroll==null?0:mainScroll.getScrollY();detailHost.removeAllViews();renderDetailContent(detailHost,source,merged,hn,heroImage,heart,fallbackTitle,false);if(mainScroll!=null&&y>0)mainScroll.post(()->mainScroll.scrollTo(0,y));}
   public void err(String e){}
  });
 }
 void openResolvedContent(JSONObject source,String title,boolean offline){
  // v16.49: reprodução parte sempre do item autenticado recebido da fonte Xtream.
  // Isso elimina a falha em que categorias carregadas depois da Home vinham sem URL
  // por não enviarem user_id ao content_by_category.
  JSONObject cached=readDetailCache(source);JSONObject ready=mergeDetailJson(cached,source);String u=detailPlayUrl(ready);
  if(!u.isEmpty()){openPlayableUrl(ready,title,offline,u);return;}
  // Primeiro tenta o detalhe. Se o provedor não responder get_vod_info, refaz somente
  // a categoria do item, autenticada, e recupera a URL pronta direto da fonte.
  Api.post("content_detail",Api.m("user_id",uid,"video_id",source.optString("id"),"video_type",String.valueOf(source.optInt("video_type",source.optInt("type_id",1))),"category_id",source.optString("category_id",""),"provider_id",source.optString("provider_id","")),new Api.CB(){public void ok(JSONObject j){JSONArray a=j.optJSONArray("result");JSONObject fresh=(a!=null&&a.length()>0)?a.optJSONObject(0):null;if(fresh!=null){JSONObject withSource=mergeDetailJson(source,fresh);saveDetailCache(source,withSource);JSONObject merged=mergeDetailJson(source,readDetailCache(source));String url=detailPlayUrl(merged);if(!url.isEmpty()){openPlayableUrl(merged,title,offline,url);return;}}resolvePlayableFromCategory(source,title,offline);}public void err(String e){resolvePlayableFromCategory(source,title,offline);}});
 }
 String detailCacheKey(JSONObject x){String provider=x==null?"":x.optString("provider_id","").trim();if(provider.isEmpty())provider=Api.PROVIDER==null?"":Api.PROVIDER;String type=String.valueOf(x.optInt("video_type",x.optInt("type_id",1)));String id=x.optString("id",x.optString("video_id",x.optString("tmdb_id",x.optString("name","item"))));return ("meta67_"+provider+"_"+type+"_"+id).replaceAll("[^a-zA-Z0-9._-]","_");}
 String detailValue(JSONObject d,String...keys){if(d==null)return "";for(String k:keys){String v=d.optString(k,"");if(v!=null&&!v.trim().isEmpty()&&!"null".equalsIgnoreCase(v.trim()))return v.trim();}return "";}
 String doramaDescriptionPt(JSONObject d){String pt=detailValue(d,"description_pt","overview_pt","synopsis_pt","sinopse","plot_pt","description_pt_br","overview_pt_br");if(!pt.isEmpty())return pt;String raw=detailValue(d,"description","plot","overview");if(raw.isEmpty())return "";String l=raw.toLowerCase(java.util.Locale.ROOT);int en=0,br=0;String[] ew={" the "," and "," with "," her "," his "," she "," he "," after "," when "," must "," their "," from "," into "," becomes "," discovers "," love "};for(String w:ew)if((" "+l+" ").contains(w))en++;String[] pw={" que "," com "," ela "," ele "," depois "," quando "," seu "," sua "," seus "," suas "," para "," uma "," um "," amor "," descobre "," precisa "," entre "};for(String w:pw)if((" "+l+" ").contains(w))br++;if(en>=3&&en>br+1)return "";return raw;}
 String cleanCastName(String raw){if(raw==null)return "";String n=raw.trim();n=n.replaceAll("(?i)\\s*[·•|/\\-–—]?\\s*\\(?\\d+\\s*(filmes?|movies?|obras?|t[ií]tulos?)\\)?\\s*$","").trim();return n;}
 JSONArray detailSeriesSeasons(JSONObject d){
  JSONArray out=new JSONArray();if(d==null)return out;java.util.TreeMap<Integer,String> names=new java.util.TreeMap<>();
  Object raw=d.opt("season");if(!(raw instanceof JSONArray))raw=d.opt("seasons");
  if(raw instanceof JSONArray){JSONArray a=(JSONArray)raw;for(int i=0;i<a.length();i++){Object v=a.opt(i);int sn=0;String nm="";if(v instanceof JSONObject){JSONObject s=(JSONObject)v;sn=s.optInt("season_number",s.optInt("id",s.optInt("season",0)));nm=s.optString("name","");}else if(v instanceof Number)sn=((Number)v).intValue();else if(v instanceof String){try{sn=Integer.parseInt(((String)v).replaceAll("[^0-9]",""));}catch(Exception ignored){}}if(sn<=0)sn=i+1;if(nm.isEmpty())nm="Temporada "+sn;names.put(sn,nm);}}
  JSONObject by=d.optJSONObject("episodes_by_season");if(by!=null){java.util.Iterator<String> it=by.keys();while(it.hasNext()){String k=it.next();try{int sn=Integer.parseInt(k.replaceAll("[^0-9]",""));if(sn>0&&!names.containsKey(sn))names.put(sn,"Temporada "+sn);}catch(Exception ignored){}}}
  for(java.util.Map.Entry<Integer,String> e:names.entrySet()){JSONObject s=new JSONObject();try{s.put("id",e.getKey());s.put("season_number",e.getKey());s.put("name",e.getValue());}catch(Exception ignored){}out.put(s);}return out;
 }
  boolean isYoutubeShort(JSONObject x){return x!=null&&(!x.optString("youtube_id","").trim().isEmpty()||"youtube".equalsIgnoreCase(x.optString("source",""))||"external".equalsIgnoreCase(x.optString("source",""))||!x.optString("provider_source","").trim().isEmpty());}
 String youtubeVideoId(JSONObject x){if(x==null)return "";String id=x.optString("youtube_id","").trim();if(id.isEmpty()){String raw=x.optString("youtube_url","");try{Uri u=Uri.parse(raw);id=u.getQueryParameter("v");}catch(Exception ignored){}}return id==null?"":id.replaceAll("[^A-Za-z0-9_-]","");}
 String greenShortResumeKey(String videoId){return "greenshorts_resume_"+(videoId==null?"":videoId).replaceAll("[^a-zA-Z0-9._-]","_");}
 JSONObject greenShortResume(JSONObject source){String id=youtubeVideoId(source);if(id.isEmpty())return null;String raw=sp.getString(greenShortResumeKey(id),"");if(raw.isEmpty())return null;try{JSONObject r=new JSONObject(raw);long pos=r.optLong("position",0),dur=r.optLong("duration",0);if(pos<4000||dur<=0||pos>=dur-4000)return null;return r;}catch(Exception e){return null;}}
 int greenShortResumePosition(JSONObject source){JSONObject r=greenShortResume(source);if(r==null)return 0;long p=r.optLong("position",0);return p>Integer.MAX_VALUE?Integer.MAX_VALUE:(int)p;}
 void clearGreenShortResume(JSONObject source){String id=youtubeVideoId(source);if(!id.isEmpty())sp.edit().remove(greenShortResumeKey(id)).apply();}
 void openYoutubeVideo(JSONObject source,String title){openYoutubeVideo(source,title,false);}
 void openYoutubeVideo(JSONObject source,String title,boolean restart){
  if(source==null)return;
  if(isExternalDorama(source)){
   String u=detailPlayUrl(source);
   if(!u.isEmpty()){openPlayableUrl(source,title==null?"Yelly Doramas":title,false,u);return;}
   ExternalDoramas.resolve(source,new ExternalDoramas.CB(){
    public void ok(JSONArray a){JSONObject r=(a!=null&&a.length()>0)?a.optJSONObject(0):null;String ru=detailPlayUrl(r);if(ru.isEmpty()){runOnUiThread(()->Toast.makeText(MainActivity.this,"Esta fonte não entregou vídeo direto.",Toast.LENGTH_SHORT).show());return;}runOnUiThread(()->openPlayableUrl(r,title==null?"Yelly Doramas":title,false,ru));}
    public void err(String e){runOnUiThread(()->Toast.makeText(MainActivity.this,"Fonte indisponível agora.",Toast.LENGTH_SHORT).show());}
   });return;
  }
  String id=youtubeVideoId(source);
  if(id.isEmpty()){Toast.makeText(this,"Vídeo do YouTube indisponível.",Toast.LENGTH_SHORT).show();return;}
  if(restart)clearGreenShortResume(source);
  Intent in=new Intent(this,YouTubePlayerActivity.class);
  in.putExtra("youtube_id",id);in.putExtra("greenshorts_id",id);
  in.putExtra("title",title==null?"Yelly Doramas":title);
  in.putExtra("poster",detailValue(source,"thumbnail","portrait_img","poster","image"));
  in.putExtra("tv_mode",tvMode);
  int resume=restart?0:greenShortResumePosition(source);if(resume>0)in.putExtra("resume_ms",resume);
  startActivity(in);
 }
 void renderGreenShortsResume(JSONObject source,LinearLayout host,String title){}
 void showGreenShortsActions(JSONObject source,String title){openYoutubeVideo(source,title,false);}
 String detailPlayUrl(JSONObject d){return detailValue(d,"video_1080","video_720","video_480","video_320","video_url","stream_url","url");}
 boolean sameContentId(JSONObject a,JSONObject b){if(a==null||b==null)return false;String ai=a.optString("id",a.optString("video_id",""));String bi=b.optString("id",b.optString("video_id",""));return !ai.isEmpty()&&ai.equals(bi);}
 void openPlayableUrl(JSONObject source,String title,boolean offline,String url){if(url==null||url.trim().isEmpty())return;if(offline){downloadOffline(source,url,title.isEmpty()?"conteudo":title,detailValue(source,"thumbnail","portrait_img","poster","poster_path"),source.optString("id","0"),source.optString("video_type","1"));}else{Intent in=new Intent(MainActivity.this,PlayerActivity.class);in.putExtra("url",url);in.putExtra("url_1080",detailValue(source,"video_1080"));in.putExtra("url_720",detailValue(source,"video_720"));in.putExtra("url_480",detailValue(source,"video_480"));in.putExtra("url_320",detailValue(source,"video_320"));in.putExtra("title",title);in.putExtra("force_portrait",!tvMode&&("Shorts".equals(activeHomeTab)||isYoutubeShort(source)));int vt=source.optInt("video_type",source.optInt("type_id",1));if(vt==1){String movieId=source.optString("id",source.optString("video_id",""));in.putExtra("movie_id",movieId);in.putExtra("movie_title",title);in.putExtra("movie_poster",detailValue(source,"thumbnail","portrait_img","poster","poster_path"));in.putExtra("movie_landscape",detailValue(source,"landscape","landscape_img","backdrop","backdrop_path"));int resume=movieResumePosition(movieId);if(resume>0)in.putExtra("resume_ms",resume);JSONObject access=readCachedAccessStatus();if((uid==null||uid.isEmpty())||accessDenied(access)){in.putExtra("preview_mode",true);in.putExtra("preview_movie_ms",sp.getInt("preview_movie_minutes",5)*60000L);}}launchOnlinePlayer(in);}}
 void resolvePlayableFromCategory(JSONObject source,String title,boolean offline){
  int vt=source.optInt("video_type",source.optInt("type_id",1));String cid=source.optString("category_id","");
  if(vt!=1||cid.isEmpty()){Toast.makeText(MainActivity.this,"Conteúdo indisponível agora.",0).show();return;}
  int n;try{n=Integer.parseInt(cid);}catch(Exception e){Toast.makeText(MainActivity.this,"Conteúdo indisponível agora.",0).show();return;}
  Api.post("content_by_category",Api.m("user_id",uid,"type","movie","category_id",String.valueOf(n),"page_no","1"),new Api.CB(){public void ok(JSONObject j){JSONArray a=j.optJSONArray("result");JSONObject found=null;if(a!=null)for(int i=0;i<a.length();i++){JSONObject row=a.optJSONObject(i);if(sameContentId(source,row)){found=row;break;}}if(found==null){Toast.makeText(MainActivity.this,"Conteúdo indisponível agora.",0).show();return;}JSONObject merged=mergeDetailJson(source,found);saveDetailCache(source,merged);String url=detailPlayUrl(merged);if(url.isEmpty()){Toast.makeText(MainActivity.this,"Conteúdo indisponível agora.",0).show();return;}openPlayableUrl(merged,title,offline,url);}public void err(String e){Toast.makeText(MainActivity.this,"Não foi possível abrir o conteúdo.",0).show();}});
 }
 void renderDetailContent(LinearLayout host,JSONObject source,JSONObject d,TextView hn,ImageView heroImage,TextView heart,String fallbackTitle,boolean partial){
  if(host==null||d==null)return;
  String tmdbTitle=detailValue(d,"name","title");if(tmdbTitle.isEmpty())tmdbTitle=fallbackTitle;if(!tmdbTitle.isEmpty())hn.setText(tmdbTitle);
  String heroUrl=detailValue(d,"landscape","landscape_img","backdrop","backdrop_path");if(!heroUrl.isEmpty())Img.loadVisible(heroImage,heroUrl);
  String desc=(isYoutubeShort(source)||isYoutubeShort(d))?doramaDescriptionPt(d):detailValue(d,"description","plot","overview");String date=detailValue(d,"release_date","date","first_air_date");String genre=detailValue(d,"category_name","genre","genres");String cast=detailValue(d,"cast");JSONArray castList=d.optJSONArray("cast_list");String dur=detailValue(d,"video_duration","duration","runtime");String rating=detailValue(d,"imdb_rating","rating","vote_average","score");final String displayTitle=tmdbTitle;
  int vt=d.optInt("video_type",source.optInt("video_type",source.optInt("type_id",1)));boolean isSeries=vt==2||"series".equalsIgnoreCase(d.optString("type",""));final boolean isYoutube=isYoutubeShort(source)||isYoutubeShort(d);
  JSONArray seasons=detailSeriesSeasons(d);

  if(isYoutube&&isExternalDorama(source)){View srcBadge=detailIdBadge("Fonte:  "+doramaSourceName(source));LinearLayout.LayoutParams slp0=new LinearLayout.LayoutParams(-2,-2);slp0.setMargins(0,dp(2),0,dp(12));host.addView(srcBadge,slp0);}
  String providerId=source.optString("id",d.optString("id",""));if(!isYoutube&&!providerId.isEmpty()){View idBadge=detailIdBadge("ID:  "+providerId);LinearLayout.LayoutParams idlp=new LinearLayout.LayoutParams(-2,-2);idlp.setMargins(0,dp(2),0,dp(12));host.addView(idBadge,idlp);}

  LinearLayout metaRow=new LinearLayout(this);metaRow.setOrientation(LinearLayout.HORIZONTAL);metaRow.setGravity(Gravity.CENTER_VERTICAL);metaRow.setPadding(0,0,0,dp(2));
  if(!rating.isEmpty()&&!rating.equals("0")&&!rating.equals("0.0")){metaRow.addView(detailMetaItem("★",formatRatingDisplay(rating),0xffffcf4a));}
  if(!date.isEmpty()){metaRow.addView(detailMetaItem("▣",shortDate(date),0xffc0b4bc));}
  if(isSeries&&seasons!=null&&seasons.length()>0){String s=seasons.length()+" "+(seasons.length()==1?"Temporada":"Temporadas");metaRow.addView(detailMetaItem("▰",s,0xffc0b4bc));}
  else if(!dur.isEmpty()&&!dur.equals("0")){metaRow.addView(detailMetaItem("◷",formatDurationDisplay(dur),0xffc0b4bc));}
  if(metaRow.getChildCount()>0){LinearLayout.LayoutParams mlp=new LinearLayout.LayoutParams(-1,dp(42));mlp.setMargins(0,0,0,dp(4));host.addView(metaRow,mlp);}

  if(!genre.isEmpty()){TextView gt=t("♣  "+fixTitle(genre),14);gt.setTextColor(0xffb3a8af);gt.setPadding(dp(2),0,0,dp(8));gt.setMaxLines(2);host.addView(gt,new LinearLayout.LayoutParams(-1,-2));}

  if(!isSeries){
   if(!isYoutube)renderMovieResume(source,d,host,displayTitle);
   boolean canResume=isYoutube?greenShortResumePosition(source)>0:movieResumePosition(source.optString("id",d.optString("id","")))>0;
   View play=detailPrimaryAction(canResume?"Continuar assistindo":"Assistir");LinearLayout.LayoutParams plp=new LinearLayout.LayoutParams(-1,dp(62));plp.setMargins(0,dp(8),0,dp(12));host.addView(play,plp);
   play.setOnClickListener(v->guardPlaybackAction(()->{if(isYoutube){if(canResume)showGreenShortsActions(source,displayTitle);else openYoutubeVideo(source,displayTitle,false);}else showMovieActions(source,d,displayTitle);}));
  }

  if(!desc.isEmpty()||!partial){
   TextView st=detailSectionTitle("Sinopse");LinearLayout.LayoutParams stlp=new LinearLayout.LayoutParams(-1,-2);stlp.setMargins(0,dp(12),0,dp(4));host.addView(st,stlp);
   LinearLayout synCard=new LinearLayout(this);synCard.setOrientation(LinearLayout.VERTICAL);GradientDrawable sg=round(0xff1b1518,18);sg.setStroke(dp(1),0xff2d2a2c);synCard.setBackground(sg);synCard.setPadding(dp(14),dp(14),dp(14),dp(12));
   String fullDesc=desc.isEmpty()?"Sinopse em português ainda não disponível.":desc;final boolean expandable=fullDesc.length()>165;final boolean[] expanded=new boolean[]{false};
   TextView synopsis=t(fullDesc,15);synopsis.setTextColor(0xffe2d4dd);synopsis.setLineSpacing(dp(3),1.15f);synopsis.setPadding(0,0,0,0);if(expandable){synopsis.setMaxLines(3);synopsis.setEllipsize(android.text.TextUtils.TruncateAt.END);}synCard.addView(synopsis);
   if(expandable){TextView more=t("Ler mais  ⌄",14);more.setTextColor(GREEN);more.setTypeface(null,1);more.setPadding(0,dp(10),0,0);more.setOnClickListener(v->{expanded[0]=!expanded[0];if(expanded[0]){synopsis.setMaxLines(Integer.MAX_VALUE);synopsis.setEllipsize(null);more.setText("Ler menos  ⌃");}else{synopsis.setMaxLines(3);synopsis.setEllipsize(android.text.TextUtils.TruncateAt.END);more.setText("Ler mais  ⌄");}});synCard.addView(more);}
   LinearLayout.LayoutParams slp=new LinearLayout.LayoutParams(-1,-2);slp.setMargins(0,0,0,dp(14));host.addView(synCard,slp);
  }

  if(isSeries&&seasons!=null&&seasons.length()>0){renderSeriesSeasons(source,d,seasons,host);}

  if((castList!=null&&castList.length()>0)||!cast.isEmpty()){
   TextView ct=detailSectionTitle("Elenco");LinearLayout.LayoutParams ctlp=new LinearLayout.LayoutParams(-1,-2);ctlp.setMargins(0,dp(12),0,dp(2));host.addView(ct,ctlp);
   HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);hs.setOverScrollMode(View.OVER_SCROLL_NEVER);LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setPadding(dp(2),0,dp(8),0);
   if(castList!=null&&castList.length()>0){for(int ci=0;ci<Math.min(12,castList.length());ci++){JSONObject ca=castList.optJSONObject(ci);if(ca!=null)row.addView(castPerson(ca));}}
   else{String[] names=cast.split(",");int added=0;for(String raw:names){String n=raw.trim();if(n.isEmpty())continue;JSONObject ca=new JSONObject();try{ca.put("name",n);}catch(Exception ignored){}row.addView(castPerson(ca));added++;if(added>=12)break;}}
   hs.addView(row);LinearLayout.LayoutParams clp=new LinearLayout.LayoutParams(-1,dp(140));clp.setMargins(0,0,0,dp(8));host.addView(hs,clp);
  }
  Space bottomSpace=new Space(this);host.addView(bottomSpace,new LinearLayout.LayoutParams(1,dp(22)));
 }

 void renderSeriesSeasons(JSONObject source,JSONObject detail,JSONArray seasons,LinearLayout host){
  TextView seasonsTitle=detailSectionTitle("Temporadas");host.addView(seasonsTitle,new LinearLayout.LayoutParams(-1,-2));
  HorizontalScrollView shs=new HorizontalScrollView(this);shs.setHorizontalScrollBarEnabled(false);shs.setOverScrollMode(View.OVER_SCROLL_NEVER);LinearLayout srow=new LinearLayout(this);srow.setOrientation(LinearLayout.HORIZONTAL);srow.setPadding(0,0,dp(8),0);shs.addView(srow);
  LinearLayout.LayoutParams shlp=new LinearLayout.LayoutParams(-1,dp(62));shlp.setMargins(0,0,0,dp(8));host.addView(shs,shlp);

  // v16.63: cartão de continuar aparece entre temporadas e episódios, igual ao fluxo
  // da referência. O progresso é salvo localmente apenas para retomada, sem cachear catálogo.
  final LinearLayout resumeHost=new LinearLayout(this);resumeHost.setOrientation(LinearLayout.VERTICAL);host.addView(resumeHost,new LinearLayout.LayoutParams(-1,-2));
  activeSeriesResumeHost=resumeHost;activeSeriesDetail=detail;activeSeriesSource=source;renderSeriesResume(source,detail,resumeHost);

  TextView episodesTitle=detailSectionTitle("Episódios");host.addView(episodesTitle,new LinearLayout.LayoutParams(-1,-2));
  final LinearLayout episodesHost=new LinearLayout(this);episodesHost.setOrientation(LinearLayout.VERTICAL);host.addView(episodesHost,new LinearLayout.LayoutParams(-1,-2));
  final java.util.ArrayList<TextView> chips=new java.util.ArrayList<>();final int[] selected={0};
  for(int i=0;i<seasons.length();i++){JSONObject s=seasons.optJSONObject(i);if(s==null)continue;final int idx=i;final int sid=s.optInt("id",s.optInt("season_number",i+1));String label=s.optString("name","Temporada "+sid);TextView chip=t(label,14);chip.setTypeface(null,1);chip.setGravity(Gravity.CENTER);chip.setPadding(dp(14),0,dp(14),0);styleSeasonChip(chip,i==0);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,dp(50));lp.setMargins(0,0,dp(10),0);srow.addView(chip,lp);chips.add(chip);chip.setOnClickListener(v->guardPlaybackAction(()->{if(selected[0]==idx){if(episodesHost.getChildCount()==0)loadSeriesEpisodes(source,detail,sid,episodesHost);return;}selected[0]=idx;for(int k=0;k<chips.size();k++)styleSeasonChip(chips.get(k),k==idx);loadSeriesEpisodes(source,detail,sid,episodesHost);}));if(i==0)loadSeriesEpisodes(source,detail,sid,episodesHost);}
 }
 void renderSeriesResume(JSONObject source,JSONObject detail,LinearLayout host){
  if(host==null)return;host.removeAllViews();if(source==null||detail==null)return;String sid=source.optString("id",detail.optString("id",""));if(sid.isEmpty())return;String raw=sp.getString(seriesResumeKey(sid),"");if(raw.isEmpty())return;try{JSONObject r=new JSONObject(raw);long pos=r.optLong("position",0),dur=r.optLong("duration",0);if(pos<4000||dur<=0||pos>=dur-4000)return;String eid=r.optString("episode_id","");JSONObject ep=findSeriesEpisode(detail,eid);if(ep==null)return;String epNo=r.optString("episode_number",ep.optString("episode_number",ep.optString("episode_num","")));String title=r.optString("episode_title",ep.optString("name","Episódio"));LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(14),dp(10),dp(14),dp(9));GradientDrawable cg=round(0xff1b1518,14);cg.setStroke(dp(1),0xff5b3146);card.setBackground(cg);LinearLayout line=new LinearLayout(this);line.setGravity(Gravity.CENTER_VERTICAL);TextView play=t("▶",18);play.setTextColor(GREEN);play.setGravity(Gravity.CENTER);line.addView(play,new LinearLayout.LayoutParams(dp(38),dp(42)));LinearLayout words=new LinearLayout(this);words.setOrientation(LinearLayout.VERTICAL);TextView small=t("Continuar"+(epNo.isEmpty()?"":" · Ep. "+epNo),12);small.setTextColor(0xffa79da4);small.setPadding(0,0,0,0);words.addView(small);TextView tt=t(title,13);tt.setTextColor(Color.WHITE);tt.setTypeface(null,1);tt.setSingleLine(true);tt.setEllipsize(android.text.TextUtils.TruncateAt.END);tt.setPadding(0,dp(2),0,0);words.addView(tt);line.addView(words,new LinearLayout.LayoutParams(0,dp(44),1));card.addView(line,new LinearLayout.LayoutParams(-1,dp(44)));FrameLayout bar=new FrameLayout(this);View track=new View(this);track.setBackground(round(0xff31282d,2));bar.addView(track,new FrameLayout.LayoutParams(-1,dp(4),Gravity.CENTER_VERTICAL));View fill=new View(this);fill.setBackground(round(GREEN,2));FrameLayout.LayoutParams fp=new FrameLayout.LayoutParams(0,dp(4),Gravity.CENTER_VERTICAL);int full=Math.max(dp(40),getResources().getDisplayMetrics().widthPixels-dp(96));fp.width=(int)Math.max(dp(12),Math.min(full,full*(pos/(float)dur)));bar.addView(fill,fp);card.addView(bar,new LinearLayout.LayoutParams(-1,dp(12)));card.setOnClickListener(v->guardPlaybackAction(()->openSeriesEpisode(detail,ep,title,(int)pos)));LinearLayout.LayoutParams clp=new LinearLayout.LayoutParams(-1,dp(72));clp.setMargins(0,0,0,dp(10));host.addView(card,clp);}catch(Exception ignored){}
 }
 String seriesResumeKey(String seriesId){String provider=Api.PROVIDER==null?"":Api.PROVIDER;return "series_resume_"+(provider+"_"+seriesId).replaceAll("[^a-zA-Z0-9._-]","_");}
 JSONObject findSeriesEpisode(JSONObject detail,String episodeId){if(detail==null||episodeId==null||episodeId.isEmpty())return null;JSONObject by=detail.optJSONObject("episodes_by_season");if(by==null)return null;java.util.Iterator<String> it=by.keys();while(it.hasNext()){JSONArray a=by.optJSONArray(it.next());if(a==null)continue;for(int i=0;i<a.length();i++){JSONObject ep=a.optJSONObject(i);if(ep==null)continue;String id=ep.optString("id",ep.optString("video_id",""));if(episodeId.equals(id))return ep;}}return null;}
 void styleSeasonChip(TextView chip,boolean selected){if(chip==null)return;if(selected){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{GREEN,0xffe94999});g.setCornerRadius(dp(16));chip.setBackground(g);chip.setTextColor(0xff11040a);}else{GradientDrawable g=round(0xff1b1518,16);g.setStroke(dp(1),0xff5b3146);chip.setBackground(g);chip.setTextColor(0xffdfd2db);}}
 void loadSeriesEpisodes(JSONObject source,JSONObject detail,int seasonId,LinearLayout host){
  if(host==null)return;host.removeAllViews();
  // v16.62: usa primeiro todos os episódios já entregues no detalhe. Não exibe
  // estado de carregamento; o fallback de rede é silencioso.
  JSONObject bySeason=detail==null?null:detail.optJSONObject("episodes_by_season");JSONArray ready=bySeason==null?null:bySeason.optJSONArray(String.valueOf(seasonId));
  if(ready!=null&&ready.length()>0){renderSeriesEpisodeRow(detail,ready,host,seasonId);return;}
  Api.post("get_video_by_season_id",Api.m("user_id",uid,"show_id",source.optString("id"),"season_id",String.valueOf(seasonId)),new Api.CB(){public void ok(JSONObject j){if(!detailOpen||host.getParent()==null)return;if(isAccessExpiredResponse(j)){host.removeAllViews();JSONObject cached=readCachedAccessStatus();showAccessExpiredDialog(cached!=null?accessDeniedMessage(cached):"Seu acesso expirou");refreshEntitlements(null);return;}JSONArray a=j.optJSONArray("result");host.removeAllViews();if(a==null||a.length()==0){TextView empty=t("Nenhum episódio disponível.",14);empty.setTextColor(0xff9d949a);host.addView(empty);return;}try{JSONObject map=detail.optJSONObject("episodes_by_season");if(map==null){map=new JSONObject();detail.put("episodes_by_season",map);}map.put(String.valueOf(seasonId),a);}catch(Exception ignored){}renderSeriesEpisodeRow(detail,a,host,seasonId);}public void err(String e){if(!detailOpen||host.getParent()==null)return;host.removeAllViews();String msg=e==null?"":e.toLowerCase(java.util.Locale.ROOT);if(msg.contains("expir")||msg.contains("assinatura")||msg.contains("plano vencido")||msg.contains("teste")){JSONObject cached=readCachedAccessStatus();showAccessExpiredDialog(cached!=null?accessDeniedMessage(cached):"Seu acesso expirou");refreshEntitlements(null);return;}TextView err=t("Nenhum episódio disponível.",14);err.setTextColor(0xff9d949a);host.addView(err);}});
 }
 void renderSeriesEpisodeRow(JSONObject detail,JSONArray a,LinearLayout host,int seasonId){
  if(host==null)return;host.removeAllViews();if(a==null||a.length()==0){TextView empty=t("Nenhum episódio disponível.",14);empty.setTextColor(0xff9d949a);host.addView(empty);return;}
  HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);hs.setOverScrollMode(View.OVER_SCROLL_NEVER);LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setPadding(0,0,dp(8),0);
  for(int i=0;i<a.length();i++){JSONObject ep=a.optJSONObject(i);if(ep==null)continue;final JSONObject episode=ep;String num=episode.optString("episode_number",episode.optString("episode_num",""));String label=num.isEmpty()?String.valueOf(i+1):num;TextView cell=t(label,18);cell.setTypeface(null,1);cell.setTextColor(GREEN);cell.setGravity(Gravity.CENTER);GradientDrawable eg=round(0xff1b1518,12);eg.setStroke(dp(1),0xff5b3146);cell.setBackground(eg);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(64),dp(62));cp.setMargins(0,0,dp(10),0);row.addView(cell,cp);cell.setOnClickListener(v->guardPlaybackAction(()->{String url=detailPlayUrl(episode);if(url.isEmpty()){Toast.makeText(MainActivity.this,"Episódio indisponível agora.",0).show();return;}String et=episode.optString("name","Episódio "+label);showEpisodeActions(detail,episode,et,seasonId,label);}));}
  hs.addView(row);host.addView(hs,new LinearLayout.LayoutParams(-1,dp(68)));
 }
 java.util.ArrayList<java.util.HashMap<String,String>> buildSeriesEpisodeQueue(JSONObject detail){
  java.util.ArrayList<java.util.HashMap<String,String>> out=new java.util.ArrayList<>();if(detail==null)return out;JSONObject by=detail.optJSONObject("episodes_by_season");if(by==null)return out;
  java.util.TreeSet<Integer> seasonNumbers=new java.util.TreeSet<>();java.util.HashMap<Integer,String> seasonKeys=new java.util.HashMap<>();java.util.ArrayList<String> otherKeys=new java.util.ArrayList<>();java.util.Iterator<String> it=by.keys();while(it.hasNext()){String k=it.next();try{int n=Integer.parseInt(k.replaceAll("[^0-9]",""));if(n>0){seasonNumbers.add(n);seasonKeys.put(n,k);}else otherKeys.add(k);}catch(Exception e){otherKeys.add(k);}}
  java.util.ArrayList<String> keys=new java.util.ArrayList<>();for(Integer n:seasonNumbers)keys.add(seasonKeys.get(n));keys.addAll(otherKeys);
  for(String k:keys){JSONArray arr=by.optJSONArray(k);if(arr==null)continue;for(int i=0;i<arr.length();i++){JSONObject ep=arr.optJSONObject(i);if(ep==null)continue;java.util.HashMap<String,String> m=new java.util.HashMap<>();m.put("id",ep.optString("id",ep.optString("video_id","")));m.put("title",ep.optString("name",ep.optString("title","Episódio "+(i+1))));m.put("season",k.replaceAll("[^0-9]",""));m.put("episode",ep.optString("episode_number",ep.optString("episode_num",String.valueOf(i+1))));m.put("url",detailPlayUrl(ep));m.put("url_1080",detailValue(ep,"video_1080"));m.put("url_720",detailValue(ep,"video_720"));m.put("url_480",detailValue(ep,"video_480"));m.put("url_320",detailValue(ep,"video_320"));if(!m.get("url").isEmpty())out.add(m);}}
  return out;
 }

 void showEpisodeActions(JSONObject detail,JSONObject episode,String title,int seasonId,String episodeLabel){
  final Dialog d=tvMode?new Dialog(this,R.style.TvActionDialogTheme):new Dialog(this);FrameLayout actionRoot=new FrameLayout(this);actionRoot.setPadding(tvMode?0:dp(14),0,tvMode?0:dp(14),tvMode?0:dp(6));LinearLayout sheet=new LinearLayout(this);sheet.setOrientation(LinearLayout.VERTICAL);sheet.setPadding(dp(18),dp(12),dp(18),dp(18));GradientDrawable sb=round(0xff171114,22);sb.setStroke(dp(1),0xff35282e);sheet.setBackground(sb);
  View handle=new View(this);handle.setBackground(round(0xff605a5e,3));LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(dp(44),dp(4));hp.gravity=Gravity.CENTER_HORIZONTAL;hp.setMargins(0,0,0,dp(10));sheet.addView(handle,hp);
  LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);TextView num=t(episodeLabel,17);num.setTextColor(GREEN);num.setTypeface(null,1);num.setGravity(Gravity.CENTER);GradientDrawable nb=round(0xff22181d,10);nb.setStroke(dp(1),0xff5b3146);num.setBackground(nb);head.addView(num,new LinearLayout.LayoutParams(dp(46),dp(46)));LinearLayout htxt=new LinearLayout(this);htxt.setOrientation(LinearLayout.VERTICAL);TextView small=t("Episódio "+episodeLabel,11);small.setTextColor(0xffa0969d);small.setPadding(0,0,0,0);htxt.addView(small);TextView nm=t(title,14);nm.setTypeface(null,1);nm.setSingleLine(true);nm.setEllipsize(android.text.TextUtils.TruncateAt.END);nm.setPadding(0,dp(2),0,0);htxt.addView(nm);LinearLayout.LayoutParams htp=new LinearLayout.LayoutParams(0,dp(48),1);htp.setMargins(dp(12),0,0,0);head.addView(htxt,htp);sheet.addView(head,new LinearLayout.LayoutParams(-1,dp(54)));
  View watch=episodeActionRow("▶","Assistir Episódio","Reproduzir agora");View cast=null;View down=episodeActionRow("⇩","Baixar Episódio","Disponível sem internet");LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,dp(62));ap.setMargins(0,dp(8),0,0);sheet.addView(watch,ap);LinearLayout.LayoutParams dpv=new LinearLayout.LayoutParams(-1,dp(62));dpv.setMargins(0,dp(8),0,0);sheet.addView(down,dpv);
  watch.setOnClickListener(v->{d.dismiss();openSeriesEpisode(detail,episode,title,0);});if(cast!=null)cast.setOnClickListener(v->{String url=detailPlayUrl(episode);if(url.isEmpty()){Toast.makeText(MainActivity.this,"Episódio indisponível para transmitir.",Toast.LENGTH_LONG).show();return;}d.dismiss();CastHelper.cast(MainActivity.this,url,title,false,null);});down.setOnClickListener(v->{String url=detailPlayUrl(episode);if(url.isEmpty()){Toast.makeText(MainActivity.this,"Episódio indisponível para download.",0).show();return;}d.dismiss();downloadOffline(episode,url,title,detailValue(episode,"thumbnail","portrait_img","poster","poster_path"),episode.optString("id",episode.optString("video_id","0")),"2");});
  FrameLayout.LayoutParams sheetLp=new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM);actionRoot.addView(sheet,sheetLp);d.setContentView(actionRoot);Window w=d.getWindow();if(w!=null){w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));w.setDimAmount(.55f);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);w.setGravity(tvMode?Gravity.CENTER:Gravity.BOTTOM);w.setLayout(-1,tvMode?-1:-2);}d.setOnShowListener(x->{Window ww=d.getWindow();if(ww!=null){try{ww.getDecorView().setPadding(0,0,0,0);}catch(Exception ignored){}if(tvMode){WindowManager.LayoutParams lp=ww.getAttributes();lp.width=WindowManager.LayoutParams.MATCH_PARENT;lp.height=WindowManager.LayoutParams.MATCH_PARENT;lp.gravity=Gravity.CENTER;ww.setAttributes(lp);ww.setLayout(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.MATCH_PARENT);ViewGroup.LayoutParams rootLp=actionRoot.getLayoutParams();if(rootLp!=null){rootLp.width=ViewGroup.LayoutParams.MATCH_PARENT;rootLp.height=ViewGroup.LayoutParams.MATCH_PARENT;actionRoot.setLayoutParams(rootLp);}sheet.requestLayout();}else{ww.setLayout(-1,-2);ww.setGravity(Gravity.BOTTOM);}}if(tvMode){prepareTvFocusTree(sheet);requestTvFocus(watch);}});d.show();
 }
 View episodeActionRow(String icon,String title,String sub){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);if(tvMode){row.setFocusable(true);row.setFocusableInTouchMode(false);armTvFocus(row);}row.setPadding(dp(12),0,dp(10),0);row.setBackground(round(0xff20171c,13));TextView ic=t(icon,18);ic.setTextColor(GREEN);ic.setGravity(Gravity.CENTER);row.addView(ic,new LinearLayout.LayoutParams(dp(44),dp(48)));LinearLayout words=new LinearLayout(this);words.setOrientation(LinearLayout.VERTICAL);TextView tt=t(title,14);tt.setTypeface(null,1);tt.setPadding(0,0,0,0);words.addView(tt);TextView ss=t(sub,11);ss.setTextColor(0xff9a9197);ss.setPadding(0,dp(2),0,0);words.addView(ss);row.addView(words,new LinearLayout.LayoutParams(0,dp(48),1));TextView ar=t("›",24);ar.setTextColor(0xffaea4ab);ar.setGravity(Gravity.CENTER);row.addView(ar,new LinearLayout.LayoutParams(dp(32),dp(48)));return row;}
 void openSeriesEpisode(JSONObject detail,JSONObject episode,String title){openSeriesEpisode(detail,episode,title,0);}
 void openSeriesEpisode(JSONObject detail,JSONObject episode,String title,int resumeMs){
  JSONObject access=readCachedAccessStatus();boolean preview=(uid==null||uid.isEmpty())||accessDenied(access);int freeEpisodes=sp.getInt("preview_series_episodes",3);java.util.ArrayList<java.util.HashMap<String,String>> previewQueue=buildSeriesEpisodeQueue(detail);String previewId=episode.optString("id",episode.optString("video_id",""));int previewIndex=-1;for(int pi=0;pi<previewQueue.size();pi++){if(!previewId.isEmpty()&&previewId.equals(previewQueue.get(pi).get("id"))){previewIndex=pi;break;}}if(preview&&previewIndex>=freeEpisodes){showAccessExpiredDialog("Você pode assistir aos primeiros "+freeEpisodes+" episódios grátis. Assine para continuar a série.");return;}
  String url=detailPlayUrl(episode);if(url.isEmpty()){Toast.makeText(this,"Episódio indisponível agora.",0).show();return;}java.util.ArrayList<java.util.HashMap<String,String>> queue=buildSeriesEpisodeQueue(detail);int current=-1;String id=episode.optString("id",episode.optString("video_id",""));for(int i=0;i<queue.size();i++){if(!id.isEmpty()&&id.equals(queue.get(i).get("id"))){current=i;break;}}PlayerActivity.setEpisodeQueue(queue,current);
  String seriesId="";if(activeSeriesSource!=null)seriesId=activeSeriesSource.optString("id","");String season=episode.optString("season_number",episode.optString("season",""));String epNo=episode.optString("episode_number",episode.optString("episode_num",""));
  Intent in=new Intent(MainActivity.this,PlayerActivity.class);in.putExtra("url",url);in.putExtra("url_1080",detailValue(episode,"video_1080"));in.putExtra("url_720",detailValue(episode,"video_720"));in.putExtra("url_480",detailValue(episode,"video_480"));in.putExtra("url_320",detailValue(episode,"video_320"));in.putExtra("title",title);in.putExtra("episode_queue",current>=0&&queue.size()>1);in.putExtra("episode_index",current);in.putExtra("series_id",seriesId);in.putExtra("episode_id",id);in.putExtra("episode_title",title);in.putExtra("season_number",season);in.putExtra("episode_number",epNo);if(resumeMs>0)in.putExtra("resume_ms",resumeMs);if(preview){in.putExtra("preview_mode",true);in.putExtra("preview_episode_limit",freeEpisodes);}launchOnlinePlayer(in);
 }


 String movieResumeKey(String movieId){String provider=Api.PROVIDER==null?"":Api.PROVIDER;return "movie_resume_"+(provider+"_"+movieId).replaceAll("[^a-zA-Z0-9._-]","_");}
 JSONObject movieResume(String movieId){if(movieId==null||movieId.isEmpty())return null;String raw=sp.getString(movieResumeKey(movieId),"");if(raw.isEmpty())return null;try{JSONObject r=new JSONObject(raw);long pos=r.optLong("position",0),dur=r.optLong("duration",0);if(pos<4000||dur<=0||pos>=dur-4000)return null;return r;}catch(Exception e){return null;}}
 int movieResumePosition(String movieId){JSONObject r=movieResume(movieId);return r==null?0:(int)Math.min(Integer.MAX_VALUE,r.optLong("position",0));}
 void clearMovieResume(String movieId){if(movieId==null||movieId.isEmpty())return;sp.edit().remove(movieResumeKey(movieId)).apply();}
 void renderMovieResume(JSONObject source,JSONObject detail,LinearLayout host,String title){if(source==null||host==null)return;String id=source.optString("id",detail==null?"":detail.optString("id",""));JSONObject r=movieResume(id);if(r==null)return;long pos=r.optLong("position",0),dur=r.optLong("duration",0);LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(14),dp(10),dp(14),dp(9));GradientDrawable cg=round(0xff1b1518,14);cg.setStroke(dp(1),0xff5b3146);card.setBackground(cg);LinearLayout line=new LinearLayout(this);line.setGravity(Gravity.CENTER_VERTICAL);TextView play=t("▶",18);play.setTextColor(GREEN);play.setGravity(Gravity.CENTER);line.addView(play,new LinearLayout.LayoutParams(dp(38),dp(42)));LinearLayout words=new LinearLayout(this);words.setOrientation(LinearLayout.VERTICAL);TextView small=t("Continuar assistindo",12);small.setTextColor(0xffa79da4);small.setPadding(0,0,0,0);words.addView(small);TextView tt=t(title,13);tt.setTextColor(Color.WHITE);tt.setTypeface(null,1);tt.setSingleLine(true);tt.setEllipsize(android.text.TextUtils.TruncateAt.END);tt.setPadding(0,dp(2),0,0);words.addView(tt);line.addView(words,new LinearLayout.LayoutParams(0,dp(44),1));card.addView(line,new LinearLayout.LayoutParams(-1,dp(44)));FrameLayout bar=new FrameLayout(this);View track=new View(this);track.setBackground(round(0xff31282d,2));bar.addView(track,new FrameLayout.LayoutParams(-1,dp(4),Gravity.CENTER_VERTICAL));View fill=new View(this);fill.setBackground(round(GREEN,2));FrameLayout.LayoutParams fp=new FrameLayout.LayoutParams(0,dp(4),Gravity.CENTER_VERTICAL);int full=Math.max(dp(40),getResources().getDisplayMetrics().widthPixels-dp(96));fp.width=(int)Math.max(dp(12),Math.min(full,full*(pos/(float)dur)));bar.addView(fill,fp);card.addView(bar,new LinearLayout.LayoutParams(-1,dp(12)));card.setOnClickListener(v->openResolvedContent(source,title,false));LinearLayout.LayoutParams clp=new LinearLayout.LayoutParams(-1,dp(72));clp.setMargins(0,dp(6),0,dp(6));host.addView(card,clp);}
 void showMovieActions(JSONObject source,JSONObject detail,String title){String movieId=source.optString("id",detail==null?"":detail.optString("id",""));JSONObject resume=movieResume(movieId);final Dialog d=tvMode?new Dialog(this,R.style.TvActionDialogTheme):new Dialog(this);FrameLayout actionRoot=new FrameLayout(this);actionRoot.setPadding(tvMode?0:dp(14),0,tvMode?0:dp(14),tvMode?0:dp(6));LinearLayout sheet=new LinearLayout(this);sheet.setOrientation(LinearLayout.VERTICAL);sheet.setPadding(dp(18),dp(12),dp(18),dp(18));GradientDrawable sb=round(0xff171114,22);sb.setStroke(dp(1),0xff35282e);sheet.setBackground(sb);View handle=new View(this);handle.setBackground(round(0xff605a5e,3));LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(dp(44),dp(4));hp.gravity=Gravity.CENTER_HORIZONTAL;hp.setMargins(0,0,0,dp(10));sheet.addView(handle,hp);LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);TextView icon=t("▶",18);icon.setTextColor(GREEN);icon.setGravity(Gravity.CENTER);GradientDrawable ib=round(0xff22181d,10);ib.setStroke(dp(1),0xff5b3146);icon.setBackground(ib);head.addView(icon,new LinearLayout.LayoutParams(dp(46),dp(46)));LinearLayout htxt=new LinearLayout(this);htxt.setOrientation(LinearLayout.VERTICAL);TextView small=t("Filme",11);small.setTextColor(0xffa0969d);small.setPadding(0,0,0,0);htxt.addView(small);TextView nm=t(title,14);nm.setTypeface(null,1);nm.setSingleLine(true);nm.setEllipsize(android.text.TextUtils.TruncateAt.END);nm.setPadding(0,dp(2),0,0);htxt.addView(nm);LinearLayout.LayoutParams htp=new LinearLayout.LayoutParams(0,dp(48),1);htp.setMargins(dp(12),0,0,0);head.addView(htxt,htp);sheet.addView(head,new LinearLayout.LayoutParams(-1,dp(54)));
  View watch=episodeActionRow("▶",resume!=null?"Continuar Filme":"Assistir Filme",resume!=null?"Retomar de onde parou":"Reproduzir agora");LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,dp(62));ap.setMargins(0,dp(8),0,0);sheet.addView(watch,ap);View restart=null;if(resume!=null){restart=episodeActionRow("↺","Assistir do início","Recomeçar o filme");LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(62));rp.setMargins(0,dp(8),0,0);sheet.addView(restart,rp);}View cast=null;View down=episodeActionRow("⇩","Baixar Filme","Disponível sem internet");LinearLayout.LayoutParams dlp=new LinearLayout.LayoutParams(-1,dp(62));dlp.setMargins(0,dp(8),0,0);sheet.addView(down,dlp);watch.setOnClickListener(v->{d.dismiss();openResolvedContent(source,title,false);});if(restart!=null){final View rr=restart;rr.setOnClickListener(v->{clearMovieResume(movieId);d.dismiss();openResolvedContent(source,title,false);});}if(cast!=null)cast.setOnClickListener(v->{d.dismiss();castMovieToTv(source,detail,title);});down.setOnClickListener(v->{d.dismiss();openResolvedContent(source,title,true);});FrameLayout.LayoutParams sheetLp=new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM);actionRoot.addView(sheet,sheetLp);d.setContentView(actionRoot);Window w=d.getWindow();if(w!=null){w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));w.setDimAmount(.55f);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);w.setGravity(tvMode?Gravity.CENTER:Gravity.BOTTOM);w.setLayout(-1,tvMode?-1:-2);}d.setOnShowListener(x->{Window ww=d.getWindow();if(ww!=null){try{ww.getDecorView().setPadding(0,0,0,0);}catch(Exception ignored){}if(tvMode){WindowManager.LayoutParams lp=ww.getAttributes();lp.width=WindowManager.LayoutParams.MATCH_PARENT;lp.height=WindowManager.LayoutParams.MATCH_PARENT;lp.gravity=Gravity.CENTER;ww.setAttributes(lp);ww.setLayout(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.MATCH_PARENT);ViewGroup.LayoutParams rootLp=actionRoot.getLayoutParams();if(rootLp!=null){rootLp.width=ViewGroup.LayoutParams.MATCH_PARENT;rootLp.height=ViewGroup.LayoutParams.MATCH_PARENT;actionRoot.setLayoutParams(rootLp);}sheet.requestLayout();}else{ww.setLayout(-1,-2);ww.setGravity(Gravity.BOTTOM);}}if(tvMode){prepareTvFocusTree(sheet);requestTvFocus(watch);}});d.show();}
 void castMovieToTv(JSONObject source,JSONObject detail,String title){
  JSONObject ready=mergeDetailJson(source,detail);String url=detailPlayUrl(ready);if(!url.isEmpty()){CastHelper.cast(this,url,title,false,null);return;}
  Api.post("content_detail",Api.m("user_id",uid,"video_id",source.optString("id"),"video_type",String.valueOf(source.optInt("video_type",source.optInt("type_id",1))),"category_id",source.optString("category_id",""),"provider_id",source.optString("provider_id","")),new Api.CB(){public void ok(JSONObject j){JSONArray a=j.optJSONArray("result");JSONObject fresh=(a!=null&&a.length()>0)?a.optJSONObject(0):null;JSONObject merged=mergeDetailJson(source,fresh);String u=detailPlayUrl(merged);if(u.isEmpty()){runOnUiThread(()->showAppNotice("Não foi possível preparar este filme para transmissão.",true));return;}saveDetailCache(source,merged);runOnUiThread(()->CastHelper.cast(MainActivity.this,u,title,false,null));}public void err(String e){runOnUiThread(()->showAppNotice("Não foi possível preparar este filme para transmissão.",true));}});
 }
 JSONArray localMovieContinueItems(){JSONArray out=new JSONArray();String provider=Api.PROVIDER==null?"":Api.PROVIDER;String prefix="movie_resume_"+(provider+"_").replaceAll("[^a-zA-Z0-9._-]","_");java.util.ArrayList<JSONObject> list=new java.util.ArrayList<>();for(java.util.Map.Entry<String,?> e:sp.getAll().entrySet()){if(e.getKey()==null||!e.getKey().startsWith(prefix)||!(e.getValue() instanceof String))continue;try{JSONObject r=new JSONObject((String)e.getValue());long pos=r.optLong("position",0),dur=r.optLong("duration",0);if(pos<4000||dur<=0||pos>=dur-4000)continue;list.add(r);}catch(Exception ignored){}}java.util.Collections.sort(list,(a,b)->Long.compare(b.optLong("updated_at",0),a.optLong("updated_at",0)));for(int i=0;i<Math.min(8,list.size());i++){JSONObject r=list.get(i);JSONObject x=new JSONObject();try{x.put("id",r.optString("movie_id"));x.put("name",r.optString("movie_title","Filme"));x.put("title",r.optString("movie_title","Filme"));x.put("thumbnail",r.optString("movie_poster"));x.put("portrait_img",r.optString("movie_poster"));x.put("landscape",r.optString("movie_landscape"));x.put("landscape_img",r.optString("movie_landscape"));x.put("video_type",1);x.put("type_id",1);x.put("resume_position",r.optLong("position",0));x.put("resume_duration",r.optLong("duration",0));out.put(x);}catch(Exception ignored){}}return out;}
 JSONArray mergeContinueItems(JSONArray server,JSONArray local){JSONArray out=new JSONArray();java.util.HashSet<String> seen=new java.util.HashSet<>();JSONArray[] all={local,server};for(JSONArray a:all){if(a==null)continue;for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;String key=x.optInt("video_type",x.optInt("type_id",1))+"|"+x.optString("id",x.optString("video_id",x.optString("name","")));if(seen.add(key))out.put(x);}}return out;}
 void renderContinueItems(LinearLayout target,JSONArray a){if(target==null||a==null||a.length()==0)return;target.removeAllViews();TextView h=t("Continue assistindo",20);h.setTypeface(null,1);target.addView(h);HorizontalScrollView hs=new HorizontalScrollView(MainActivity.this);hs.setHorizontalScrollBarEnabled(false);LinearLayout r=new LinearLayout(MainActivity.this);r.setOrientation(LinearLayout.HORIZONTAL);hs.addView(r);for(int i=0;i<Math.min(12,a.length());i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;LinearLayout c=card(x);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(112),dp(202));cp.setMargins(dp(3),0,dp(8),0);r.addView(c,cp);}target.addView(hs,new LinearLayout.LayoutParams(-1,dp(204)));}


 View detailPrimaryAction(String label){
  LinearLayout box=new LinearLayout(this);box.setGravity(Gravity.CENTER_VERTICAL);box.setPadding(dp(18),0,dp(18),0);GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0xffe72284,0xffee53a1});g.setCornerRadius(dp(22));g.setStroke(dp(1),0xfff576b6);box.setBackground(g);box.setElevation(dp(3));
  TextView play=t("▶",21);play.setTextColor(0xff11040a);play.setGravity(Gravity.CENTER);box.addView(play,new LinearLayout.LayoutParams(dp(54),-1));TextView txt=t(label,20);txt.setTextColor(0xff11040a);txt.setTypeface(null,1);txt.setGravity(Gravity.CENTER);box.addView(txt,new LinearLayout.LayoutParams(0,-1,1));TextView ar=t("›",30);ar.setTextColor(0xff11040a);ar.setGravity(Gravity.CENTER);box.addView(ar,new LinearLayout.LayoutParams(dp(42),-1));return box;
 }
 View detailSecondaryAction(String label){
  LinearLayout box=new LinearLayout(this);box.setGravity(Gravity.CENTER);GradientDrawable g=round(0xaa150b10,20);g.setStroke(dp(1),0xffc74284);box.setBackground(g);TextView ic=t("⇩",20);ic.setTextColor(0xfff4e5ef);ic.setGravity(Gravity.CENTER);box.addView(ic,new LinearLayout.LayoutParams(dp(44),-1));TextView txt=t(label,16);txt.setTextColor(0xfff4f6f5);txt.setTypeface(null,1);txt.setGravity(Gravity.CENTER_VERTICAL);box.addView(txt,new LinearLayout.LayoutParams(-2,-1));return box;
 }
 void showDetailBottomNav(){
  if(contentFrame==null)return;if(detailNavOverlay!=null&&detailNavOverlay.getParent() instanceof ViewGroup)((ViewGroup)detailNavOverlay.getParent()).removeView(detailNavOverlay);
  detailNavOverlay=new LinearLayout(this);detailNavOverlay.setGravity(Gravity.CENTER);detailNavOverlay.setPadding(dp(4),dp(4),dp(4),dp(2));GradientDrawable bg=round(0xf2120a0e,18);bg.setStroke(dp(1),0xff351726);detailNavOverlay.setBackground(bg);detailNavOverlay.setElevation(dp(9));
  detailNavOverlay.addView(detailBottomNavItem("⌂","Início",false,v->goHomeNow()),new LinearLayout.LayoutParams(0,-1,1));
  detailNavOverlay.addView(detailBottomNavItem("⌕","Buscar",false,v->{closeDetails();searchDialog();}),new LinearLayout.LayoutParams(0,-1,1));
  detailNavOverlay.addView(detailBottomNavItem("▶","Yelly",true,v->goHomeNow()),new LinearLayout.LayoutParams(0,-1,1));
  detailNavOverlay.addView(detailBottomNavItem("♡","Minha Lista",false,v->{closeDetails();if(navFav!=null)navFav.performClick();}),new LinearLayout.LayoutParams(0,-1,1));
  detailNavOverlay.addView(detailBottomNavItem("♙","Perfil",false,v->{closeDetails();if(navProfile!=null)navProfile.performClick();}),new LinearLayout.LayoutParams(0,-1,1));
  if(tvMode){for(int i=0;i+1<detailNavOverlay.getChildCount();i++)linkTvHorizontal(detailNavOverlay.getChildAt(i),detailNavOverlay.getChildAt(i+1));}
  FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(-1,dp(62),Gravity.BOTTOM);lp.setMargins(0,0,0,0);contentFrame.addView(detailNavOverlay,lp);
 }
 View detailBottomNavItem(String icon,String label,boolean active,View.OnClickListener click){LinearLayout item=new LinearLayout(this);item.setOrientation(LinearLayout.VERTICAL);item.setGravity(Gravity.CENTER);TextView ic=t(icon,active?18:17);ic.setGravity(Gravity.CENTER);ic.setTextColor(active?0xff11040a:0xffc8bcc4);if(active){GradientDrawable cg=round(GREEN,18);ic.setBackground(cg);item.addView(ic,new LinearLayout.LayoutParams(dp(34),dp(34)));}else item.addView(ic,new LinearLayout.LayoutParams(dp(34),dp(30)));TextView tx=t(label,10);tx.setGravity(Gravity.CENTER);tx.setTextColor(active?GREEN:0xffbeb3ba);tx.setTypeface(null,active?1:0);tx.setPadding(0,0,0,0);item.addView(tx,new LinearLayout.LayoutParams(-1,dp(20)));item.setOnClickListener(click);return item;}
 void closeDetails(){
  if(!detailOpen)return;
  viewGen=savedViewGen;
  ScrollView detailScroll=mainScroll;
  if(contentFrame!=null&&detailScroll!=null)contentFrame.removeView(detailScroll);
  if(detailNavOverlay!=null&&detailNavOverlay.getParent() instanceof ViewGroup)((ViewGroup)detailNavOverlay.getParent()).removeView(detailNavOverlay);detailNavOverlay=null;
  mainScroll=savedScroll;body=savedBody;savedScroll=null;savedBody=null;detailOpen=false;activeSeriesResumeHost=null;activeSeriesDetail=null;activeSeriesSource=null;
  standardRootInsets();
  if(navBar!=null){navBar.setVisibility(View.VISIBLE);enforceGlobalBottomNav();}
  if(mainScroll!=null){
   mainScroll.setVisibility(View.VISIBLE);
   bindScrollTopButton(mainScroll);
   mainScroll.post(()->{mainScroll.requestLayout();if(scrollTopButton!=null){scrollTopButton.setVisibility(mainScroll.getScrollY()>dp(360)?View.VISIBLE:View.GONE);if(scrollTopButton.getVisibility()==View.VISIBLE)scrollTopButton.bringToFront();}});
  }else hideScrollTopButton();
  if(tvPageRoot!=null&&tvPageRoot.getParent()==contentFrame&&body==tvPageRoot){tvPageRoot.setVisibility(View.VISIBLE);tvPageRoot.bringToFront();tvPageRoot.post(()->tvPageRoot.requestLayout());}
  setNav(savedNavIndex);
 }
 @Override public void onBackPressed(){
  if(tvInlineFullscreen&&tvFullscreenChannelOverlayVisible){hideTvFullscreenChannelOverlay();return;}
  if(tvInlineFullscreen){closeTvInlineFullscreen();return;}
  if(tvCinemaMode){if(tvCinemaDrawerOpen)hideTvChannelDrawer();else exitTvCinemaMode();return;}
  if(accessExpiredOverlay!=null){dismissAccessExpiredOverlay();return;}
  if(authScreen){
   hideKeyboard(getCurrentFocus());
   showExitConfirm();
   return;
  }
  if(providerSwitchScreen){cancelProviderSwitch();return;}
  if(detailOpen){closeDetails();return;}
  if(searchScreenOpen){closeSearchScreen();return;}
  if(sectionPageOpen){closeSectionPage();return;}
  if(plansScreen){if(planFlowStage>0){if(pixTimer!=null){try{pixTimer.cancel();}catch(Exception ignored){}pixTimer=null;}plans();}else profile();return;}
  if(uid!=null&&!uid.isEmpty()&&contentFrame!=null){
   // Nunca fecha o app a partir de uma tela interna. Primeiro volta para a Home.
   if(currentNavIndex!=0){goHomeNow();return;}
   if(mainScroll!=homeScrollCache||body!=homeBodyCache){goHomeNow();return;}
   // Na Home do Yelly, Back deve realmente oferecer saída.
   showExitConfirm();return;
  }
  super.onBackPressed();
 }
 Button detailPrimaryButton(String s){Button b=new Button(this);b.setText(s);b.setTextColor(0xff11030a);uiTextSize(b,19);b.setTypeface(null,1);b.setAllCaps(false);GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0xffdc207e,0xfff054a2});g.setCornerRadius(dp(22));g.setStroke(dp(1),0xfff576b6);b.setBackground(g);b.setElevation(dp(3));b.setFocusable(true);return b;}
 Button detailOutlineButton(String s){Button b=new Button(this);b.setText(s);b.setTextColor(0xfff2f5f3);uiTextSize(b,16);b.setTypeface(null,1);b.setAllCaps(false);GradientDrawable g=new GradientDrawable();g.setColor(0xdd170d12);g.setCornerRadius(dp(20));g.setStroke(dp(1),0xff703f58);b.setBackground(g);b.setFocusable(true);return b;}
 String formatRatingDisplay(String raw){try{double v=Double.parseDouble(raw.replace(",","."));return String.format(java.util.Locale.US,"%.1f",v);}catch(Exception e){return raw;}}
 String formatDurationDisplay(String raw){if(raw==null)return "";String s=raw.trim().toLowerCase(java.util.Locale.ROOT);if(s.isEmpty())return "";try{long total=-1;if(s.contains(":")){String[] p=s.split(":");if(p.length>=3){long h=Long.parseLong(p[p.length-3].replaceAll("[^0-9]",""));long m=Long.parseLong(p[p.length-2].replaceAll("[^0-9]",""));total=h*60+m;}else if(p.length==2){long a=Long.parseLong(p[0].replaceAll("[^0-9]",""));long b=Long.parseLong(p[1].replaceAll("[^0-9]",""));total=a*60+b;}}if(total<0){java.util.regex.Matcher mh=java.util.regex.Pattern.compile("(\\d+)\\s*h").matcher(s);java.util.regex.Matcher mm=java.util.regex.Pattern.compile("(\\d+)\\s*(?:min|m)").matcher(s);long h=mh.find()?Long.parseLong(mh.group(1)):0;long min=mm.find()?Long.parseLong(mm.group(1)):0;if(h>0||min>0)total=h*60+min;}if(total<0){String digits=s.replaceAll("[^0-9]","");if(!digits.isEmpty())total=Long.parseLong(digits);}if(total>=0){long h=total/60,mn=total%60;if(h>0)return mn>0?h+"h "+mn+"min":h+"h";return mn+" min";}}catch(Exception ignored){}return raw;}
 View detailIdBadge(String s){TextView v=t(s,12);v.setTypeface(null,1);v.setTextColor(GREEN);v.setPadding(dp(11),dp(6),dp(11),dp(6));GradientDrawable g=round(0x24d81777,12);g.setStroke(dp(1),0x66dc3589);v.setBackground(g);return v;}
 View detailMetaItem(String icon,String value,int iconColor){LinearLayout box=new LinearLayout(this);box.setGravity(Gravity.CENTER_VERTICAL);TextView ic=t(icon,14);ic.setTextColor(iconColor);box.addView(ic);TextView txt=t(value,14);txt.setTextColor(0xffe5d7e0);txt.setPadding(dp(6),0,dp(8),0);box.addView(txt);return box;}
 View detailMetaDivider(){View d=new View(this);d.setBackgroundColor(0xff43333b);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(1),dp(18));lp.setMargins(dp(4),0,dp(10),0);d.setLayoutParams(lp);return d;}
 TextView detailSectionTitle(String label){TextView v=t(label,22);v.setTypeface(null,1);v.setTextColor(Color.WHITE);v.setPadding(0,0,0,dp(10));return v;}
 GradientDrawable detailGlassCircle(){GradientDrawable g=new GradientDrawable();g.setShape(GradientDrawable.OVAL);g.setColor(0x75150b10);g.setStroke(dp(1),0x66895770);return g;}
 View castPerson(JSONObject ca){
  LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setGravity(Gravity.CENTER_HORIZONTAL);
  String name=cleanCastName(ca.optString("name",ca.optString("original_name","")));
  String photo=ca.optString("photo",ca.optString("profile",ca.optString("profile_path",ca.optString("image",ca.optString("avatar","")))));photo=normalizeTmdbPersonPhoto(photo);
  FrameLayout avatar=new FrameLayout(this);GradientDrawable bg=round(0xff22171c,48);bg.setStroke(dp(1),0xff663d52);avatar.setBackground(bg);avatar.setClipToOutline(true);avatar.setElevation(dp(2));
  TextView initials=t(personInitials(name),18);initials.setTypeface(null,1);initials.setTextColor(0xffa59ba2);initials.setGravity(Gravity.CENTER);avatar.addView(initials,new FrameLayout.LayoutParams(-1,-1));
  if(!photo.isEmpty()){ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);im.setAdjustViewBounds(false);Img.loadVisible(im,photo);avatar.addView(im,new FrameLayout.LayoutParams(-1,-1));}
  box.addView(avatar,new LinearLayout.LayoutParams(dp(94),dp(94)));
  TextView n=t(name,12);n.setGravity(Gravity.CENTER);n.setTextColor(0xfff0f3f1);n.setMaxLines(1);n.setEllipsize(android.text.TextUtils.TruncateAt.END);n.setPadding(0,dp(7),0,0);box.addView(n,new LinearLayout.LayoutParams(dp(126),dp(28)));
  LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(126),dp(132));lp.setMargins(0,0,dp(10),0);box.setLayoutParams(lp);return box;
 }
 String normalizeTmdbPersonPhoto(String photo){if(photo==null)return "";String x=photo.trim();if(x.isEmpty()||"null".equalsIgnoreCase(x))return "";if(x.startsWith("//"))return "https:"+x;if(x.startsWith("http://image.tmdb.org"))return "https://image.tmdb.org"+x.substring("http://image.tmdb.org".length());if(x.startsWith("https://"))return x;if(x.startsWith("http://"))return x;if(x.startsWith("/"))return "https://image.tmdb.org/t/p/w342"+x;if(x.startsWith("profile/"))x=x.substring(8);if(x.startsWith("t/p/"))return "https://image.tmdb.org/"+x;if(x.matches("[A-Za-z0-9_\\-]+\\.(jpg|jpeg|png|webp)"))return "https://image.tmdb.org/t/p/w342/"+x;return x;}
 String personInitials(String name){if(name==null||name.trim().isEmpty())return "•";String[] p=name.trim().split("\\s+");String a=p[0].substring(0,1);String b=p.length>1?p[p.length-1].substring(0,1):"";return (a+b).toUpperCase(java.util.Locale.getDefault());}
 boolean validTmdbId(String raw){if(raw==null)return false;String d=raw.replaceAll("[^0-9]","");if(d.isEmpty())return false;try{return Long.parseLong(d)>0;}catch(Exception e){return false;}}
 TextView chip(String s){TextView c=t(s,12);c.setTextColor(0xffe5d7e0);c.setGravity(Gravity.CENTER);GradientDrawable g=round(0xff23171d,14);g.setStroke(dp(1),0xff46303b);c.setBackground(g);c.setPadding(dp(13),0,dp(13),0);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,dp(32));lp.setMargins(0,0,dp(7),0);c.setLayoutParams(lp);return c;}
 boolean isFav(JSONObject x){try{JSONArray a=new JSONArray(sp.getString("favs","[]"));String id=x.optString("id");for(int i=0;i<a.length();i++){JSONObject y=a.optJSONObject(i);if(y!=null&&id.equals(y.optString("id")))return true;}}catch(Exception ignored){}return false;}
 JSONArray offlineArray(){try{JSONArray a=new JSONArray(sp.getString("offline_items","[]"));boolean dirty=false;for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;String legacy=o.optString("source_url","");JSONArray old=o.optJSONArray("source_urls");if(!legacy.isEmpty()||(old!=null&&old.length()>0)){JSONArray urls=old!=null?old:new JSONArray();if(urls.length()==0&&!legacy.isEmpty())urls.put(legacy);String blob=secureOfflineBlob(legacy,urls);if(!blob.isEmpty())o.put("source_blob",blob);o.remove("source_url");o.remove("source_urls");dirty=true;}}if(dirty)saveOfflineArray(a);return a;}catch(Exception e){return new JSONArray();}}
 void saveOfflineArray(JSONArray a){sp.edit().putString("offline_items",a.toString()).apply();}
 String secureOfflineBlob(String primary,JSONArray urls){try{JSONObject x=new JSONObject();x.put("primary",primary==null?"":primary);x.put("urls",urls==null?new JSONArray():urls);return SecretStore.encrypt(x.toString());}catch(Exception e){return "";}}
 JSONArray secureOfflineUrls(JSONObject o){JSONArray out=new JSONArray();try{String raw=SecretStore.decrypt(o==null?"":o.optString("source_blob",""));if(raw.isEmpty())return out;JSONObject x=new JSONObject(raw);JSONArray a=x.optJSONArray("urls");java.util.HashSet<String> seen=new java.util.HashSet<>();String p=x.optString("primary","");addOfflineUrl(out,seen,p);if(a!=null)for(int i=0;i<a.length();i++)addOfflineUrl(out,seen,a.optString(i,""));}catch(Exception ignored){}return out;}
 JSONObject offlineItemById(String contentId){JSONArray a=offlineArray();for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null&&contentId.equals(o.optString("content_id")))return o;}return null;}
 void downloadOffline(JSONObject source,String url,String name,String poster,String contentId,String videoType){
  JSONArray urls=new JSONArray();java.util.HashSet<String> seen=new java.util.HashSet<>();addOfflineUrl(urls,seen,url);if(source!=null){String[] keys={"video_1080","video_720","video_480","video_320","video_url","stream_url","url"};for(String k:keys)addOfflineUrl(urls,seen,source.optString(k,""));}downloadOfflineUrls(urls,name,poster,contentId,videoType,null);
 }
 void downloadOffline(String url,String name,String poster,String contentId,String videoType){JSONArray urls=new JSONArray();addOfflineUrl(urls,new java.util.HashSet<String>(),url);downloadOfflineUrls(urls,name,poster,contentId,videoType,null);}
 void addOfflineUrl(JSONArray urls,java.util.HashSet<String> seen,String url){if(url==null)return;String u=url.trim();if(u.isEmpty()||!seen.add(u))return;urls.put(u);}
 void downloadOfflineUrls(JSONArray urls,String name,String poster,String contentId,String videoType,String existingPath){
  try{
   if(urls==null||urls.length()==0){Toast.makeText(this,"Conteúdo indisponível para download.",Toast.LENGTH_SHORT).show();return;}
   java.io.File dir=new java.io.File(getFilesDir(),"offline");if(!dir.exists()&&!dir.mkdirs()){Toast.makeText(this,"Armazenamento indisponível.",1).show();return;}
   String primary=urls.optString(0,"");String ext=offlineExtension(primary);String safe=(videoType+"_"+contentId+"_"+name).replaceAll("[^a-zA-Z0-9._-]","_");if(!safe.endsWith(ext))safe+=ext;java.io.File dest=(existingPath==null||existingPath.isEmpty())?new java.io.File(dir,safe):new java.io.File(existingPath);
   JSONArray a=offlineArray();for(int i=a.length()-1;i>=0;i--){JSONObject old=a.optJSONObject(i);if(old!=null&&contentId.equals(old.optString("content_id"))&&videoType.equals(old.optString("video_type","1")))a.remove(i);}JSONObject o=new JSONObject();o.put("content_id",contentId);o.put("video_type",videoType);o.put("title",name);o.put("poster",poster);o.put("path",dest.getAbsolutePath());String sourceBlob=secureOfflineBlob(primary,urls);if(!sourceBlob.isEmpty())o.put("source_blob",sourceBlob);o.put("status","queued");o.put("downloaded",0);o.put("total",0);o.put("created_at",System.currentTimeMillis());a.put(o);saveOfflineArray(a);
   startOfflineService(o,primary,urls);Toast.makeText(this,"Preparando download.",Toast.LENGTH_SHORT).show();
  }catch(Exception e){Toast.makeText(this,"Não foi possível iniciar o download.",1).show();}
 }
 String offlineExtension(String url){try{String p=android.net.Uri.parse(url).getPath();if(p!=null){String l=p.toLowerCase(java.util.Locale.ROOT);String[] exts={".mp4",".mkv",".webm",".avi",".mov",".m4v",".ts"};for(String e:exts)if(l.endsWith(e))return e;}}catch(Exception ignored){}return ".mp4";}
 void startOfflineService(JSONObject o,String primary,JSONArray urls){try{Intent it=new Intent(this,OfflineDownloadService.class);it.setAction(OfflineDownloadService.ACTION_START);it.putExtra("url",primary==null?"":primary);it.putExtra("urls",urls==null?"":urls.toString());it.putExtra("title",o.optString("title","Conteúdo"));it.putExtra("poster",o.optString("poster",""));it.putExtra("content_id",o.optString("content_id","0"));it.putExtra("video_type",o.optString("video_type","1"));it.putExtra("path",o.optString("path",""));if(Build.VERSION.SDK_INT>=26)startForegroundService(it);else startService(it);}catch(Exception e){Toast.makeText(this,"Não foi possível iniciar o download.",Toast.LENGTH_SHORT).show();}}
 void retryOffline(JSONObject old){if(old==null)return;try{JSONArray urls=secureOfflineUrls(old);if(urls.length()==0){Toast.makeText(this,"Link protegido indisponível. Abra o conteúdo novamente para baixar.",Toast.LENGTH_SHORT).show();return;}downloadOfflineUrls(urls,old.optString("title","Conteúdo"),old.optString("poster",""),old.optString("content_id","0"),old.optString("video_type","1"),old.optString("path",""));}catch(Exception ignored){}}
 String offlineStateText(JSONObject o){String st=o.optString("status","queued");long done=o.optLong("downloaded",0),total=o.optLong("total",0);if("ready".equals(st))return "Pronto para assistir";if("downloading".equals(st)){if(total>0)return "Baixando "+Math.min(100,(int)(100*done/total))+"%";return "Baixando";}if("queued".equals(st))return "Preparando download";if("failed".equals(st))return "Não foi possível baixar · toque para tentar";return "Preparando download";}
 void removeOffline(int index,JSONObject o){try{String cid=o.optString("content_id","");Intent it=new Intent(this,OfflineDownloadService.class);it.setAction(OfflineDownloadService.ACTION_CANCEL);it.putExtra("content_id",cid);it.putExtra("path",o.optString("path",""));startService(it);String path=o.optString("path","");if(!path.isEmpty()){new java.io.File(path).delete();new java.io.File(path+".part").delete();}JSONArray a=offlineArray();for(int i=a.length()-1;i>=0;i--){JSONObject x=a.optJSONObject(i);if(x!=null&&cid.equals(x.optString("content_id")))a.remove(i);}saveOfflineArray(a);downloads();}catch(Exception e){Toast.makeText(this,"Não foi possível excluir",1).show();}}
 View offlineCard(JSONObject snapshot,int index){
  String cid=snapshot.optString("content_id","");JSONObject current=offlineItemById(cid);final JSONObject o=current!=null?current:snapshot;
  LinearLayout card=new LinearLayout(this);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(8),dp(8),dp(10),dp(8));card.setBackground(round(0xff1c1418,14));ImageView poster=new ImageView(this);poster.setScaleType(ImageView.ScaleType.CENTER_CROP);poster.setClipToOutline(true);poster.setBackground(round(0xff201018,10));Img.load(poster,o.optString("poster",""));card.addView(poster,new LinearLayout.LayoutParams(dp(62),dp(86)));
  LinearLayout mid=new LinearLayout(this);mid.setOrientation(LinearLayout.VERTICAL);mid.setPadding(dp(12),0,dp(4),0);TextView title=t(o.optString("title","Conteúdo offline"),15);title.setTypeface(null,1);title.setMaxLines(2);mid.addView(title);String st=o.optString("status","queued");TextView sub=t(offlineStateText(o),13);sub.setTextColor("ready".equals(st)?GREEN:0xffa69ca3);mid.addView(sub);card.addView(mid,new LinearLayout.LayoutParams(0,-2,1));TextView arrow=t("ready".equals(st)?"▶":"⋮",22);arrow.setGravity(Gravity.CENTER);arrow.setTextColor("ready".equals(st)?GREEN:0xffa69ca3);card.addView(arrow,new LinearLayout.LayoutParams(dp(40),dp(72)));
  card.setOnClickListener(v->{JSONObject fresh=offlineItemById(cid);if(fresh==null)return;String state=fresh.optString("status","");java.io.File f=new java.io.File(fresh.optString("path",""));if("ready".equals(state)&&f.exists()){Intent in=new Intent(MainActivity.this,PlayerActivity.class);in.putExtra("url",f.getAbsolutePath());in.putExtra("title",fresh.optString("title","Offline"));in.putExtra("offline",true);startActivity(in);}else if("failed".equals(state)){retryOffline(fresh);}else Toast.makeText(MainActivity.this,"Download em andamento.",0).show();});
  card.setOnLongClickListener(v->{new AlertDialog.Builder(MainActivity.this).setTitle("Excluir download offline?").setMessage(o.optString("title","")).setNegativeButton("Cancelar",null).setPositiveButton("Excluir",(d,w)->removeOffline(index,o)).show();return true;});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(102));lp.setMargins(0,0,0,dp(8));card.setLayoutParams(lp);return card;
 }
 boolean hasActiveOfflineDownloads(){JSONArray a=offlineArray();for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;String st=o.optString("status","");if("queued".equals(st)||"downloading".equals(st))return true;}return false;}
 void libraryPageHeader(String title,String subtitle,int iconRes,Runnable back){
  LinearLayout h=new LinearLayout(this);h.setGravity(Gravity.CENTER_VERTICAL);h.setPadding(0,dp(5),0,dp(12));TextView b=t("‹",28);b.setTextColor(GREEN);b.setGravity(Gravity.CENTER);GradientDrawable bb=new GradientDrawable();bb.setShape(GradientDrawable.OVAL);bb.setColor(0xff1b0d14);bb.setStroke(dp(1),0xff563144);b.setBackground(bb);b.setOnClickListener(v->{if(back!=null)back.run();});h.addView(b,new LinearLayout.LayoutParams(dp(44),dp(44)));ImageView icon=new ImageView(this);icon.setImageResource(iconRes);icon.setColorFilter(GREEN);icon.setPadding(dp(10),dp(10),dp(10),dp(10));LinearLayout.LayoutParams ilp=new LinearLayout.LayoutParams(dp(44),dp(44));ilp.setMargins(dp(10),0,dp(10),0);h.addView(icon,ilp);LinearLayout words=new LinearLayout(this);words.setOrientation(LinearLayout.VERTICAL);TextView tt=t(title,24);tt.setTypeface(null,1);tt.setPadding(0,0,0,0);TextView ss=t(subtitle,12);ss.setTextColor(0xffa399a0);ss.setPadding(0,dp(2),0,0);words.addView(tt);words.addView(ss);h.addView(words,new LinearLayout.LayoutParams(0,-2,1));body.addView(h,new LinearLayout.LayoutParams(-1,dp(70)));
 }
 void addLibraryEmptyState(int iconRes,String title,String subtitle,String action,Runnable click){
  LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setGravity(Gravity.CENTER_HORIZONTAL);box.setPadding(dp(18),dp(22),dp(18),dp(20));GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xff190b12,0xff210d17});bg.setCornerRadius(dp(24));bg.setStroke(dp(1),0xff5d2a44);box.setBackground(bg);FrameLayout iconWrap=new FrameLayout(this);GradientDrawable ib=new GradientDrawable();ib.setShape(GradientDrawable.OVAL);ib.setColor(0x33e02080);ib.setStroke(dp(2),0x99e02080);iconWrap.setBackground(ib);ImageView icon=new ImageView(this);icon.setImageResource(iconRes);icon.setColorFilter(GREEN);icon.setPadding(dp(18),dp(18),dp(18),dp(18));iconWrap.addView(icon,new FrameLayout.LayoutParams(-1,-1));box.addView(iconWrap,new LinearLayout.LayoutParams(dp(78),dp(78)));TextView tt=t(title,20);tt.setTypeface(null,1);tt.setGravity(Gravity.CENTER);tt.setPadding(dp(4),dp(15),dp(4),0);box.addView(tt);TextView sub=t(subtitle,14);sub.setTextColor(0xffaaa0a7);sub.setGravity(Gravity.CENTER);sub.setLineSpacing(0,1.12f);sub.setPadding(dp(10),dp(8),dp(10),dp(15));box.addView(sub);LinearLayout chips=new LinearLayout(this);chips.setGravity(Gravity.CENTER);chips.setOrientation(LinearLayout.HORIZONTAL);java.util.ArrayList<String> names=new java.util.ArrayList<>();if(sp.getInt("provider_movies_count",0)>0)names.add("Filmes");if(sp.getInt("provider_series_count",0)>0)names.add("Séries");if(currentProviderHasLive())names.add("TV");if(names.isEmpty())names.add("Conteúdo");for(String n:names){TextView c=t(n,11);c.setGravity(Gravity.CENTER);c.setTextColor(0xffe5d7e0);GradientDrawable cg=round(0xff27121c,16);cg.setStroke(dp(1),0xff583144);c.setBackground(cg);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,dp(34),1);cp.setMargins(dp(4),0,dp(4),0);chips.addView(c,cp);}LinearLayout.LayoutParams chipsLp=new LinearLayout.LayoutParams(-1,-2);chipsLp.setMargins(dp(34),0,dp(34),dp(14));box.addView(chips,chipsLp);TextView btn=t(action,15);btn.setTypeface(null,1);btn.setTextColor(0xff11040a);btn.setGravity(Gravity.CENTER);btn.setPadding(dp(14),0,dp(14),0);GradientDrawable bb=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{GREEN,0xffec55a0});bb.setCornerRadius(dp(18));btn.setBackground(bb);btn.setOnClickListener(v->{if(click!=null)click.run();});box.addView(btn,new LinearLayout.LayoutParams(-1,dp(50)));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(4),0,0);body.addView(box,lp);
 }
 JSONArray librarySuggestions(int max){JSONArray out=new JSONArray();try{JSONObject cache=readHomeCache();JSONArray secs=cache==null?null:cache.optJSONArray("result");java.util.HashSet<String> seen=new java.util.HashSet<>();if(secs!=null)for(int i=0;i<secs.length()&&out.length()<max;i++){JSONObject sec=secs.optJSONObject(i);JSONArray d=sec==null?null:sec.optJSONArray("data");if(d==null)continue;for(int k=0;k<d.length()&&out.length()<max;k++){JSONObject x=d.optJSONObject(k);if(x==null)continue;String id=x.optString("id",x.optString("video_id",""));String key=x.optInt("video_type",x.optInt("type_id",1))+"|"+id;if(id.isEmpty()||!seen.add(key))continue;out.put(x);}}}catch(Exception ignored){}return out;}
 void renderLibraryGrid(JSONArray a){int cols=wideTvUi()?6:2;GridLayout g=new GridLayout(this);g.setColumnCount(cols);g.setUseDefaultMargins(false);int width=getResources().getDisplayMetrics().widthPixels-(wideTvUi()?2*tvContentSide():dp(36));int gap=dp(10),cardW=Math.max(dp(120),(width-gap*(cols-1))/cols);int posterH=(int)(cardW*1.42f);for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(2),dp(2),dp(2),0);c.setFocusable(true);FrameLayout poster=new FrameLayout(this);poster.setBackground(round(CARD,14));poster.setClipToOutline(true);ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);Img.loadBest(im,x.optString("thumbnail",""),x.optString("portrait_img",""),x.optString("image",""),x.optString("landscape",""),x.optString("landscape_img",""));poster.addView(im,new FrameLayout.LayoutParams(-1,-1));c.addView(poster,new LinearLayout.LayoutParams(-1,posterH));TextView nm=t(x.optString("name",x.optString("title","")),13);nm.setPadding(dp(3),dp(7),dp(3),0);nm.setMaxLines(2);nm.setEllipsize(android.text.TextUtils.TruncateAt.END);c.addView(nm,new LinearLayout.LayoutParams(-1,dp(44)));c.setOnClickListener(v->details(x));c.setOnLongClickListener(v->{toggleFav(x);favorites();return true;});if(tvMode)armTvFocus(c);GridLayout.LayoutParams cp=new GridLayout.LayoutParams();cp.width=cardW;cp.height=posterH+dp(48);cp.setMargins(0,0,(i%cols==cols-1)?0:gap,dp(14));g.addView(c,cp);}body.addView(g,new LinearLayout.LayoutParams(-1,-2));}
 void downloads(){clear();setNav(3);standardPageInsets();final int gen=viewGen;libraryPageHeader("Downloads","Sua biblioteca offline",R.drawable.ic_nav_download,()->goHomeNow());JSONArray a=offlineArray();if(a.length()==0){addLibraryEmptyState(R.drawable.ic_nav_download,"Nenhum download por enquanto","Quando você baixar um filme ou episódio, ele aparece aqui pronto para assistir mesmo sem internet.","Explorar conteúdos",()->goHomeNow());JSONArray sug=librarySuggestions(8);if(sug.length()>0){TextView st=t("Sugestões para baixar",18);st.setTypeface(null,1);st.setPadding(dp(4),dp(20),0,dp(9));body.addView(st);row(sug);}return;}TextView info=t(a.length()+" download"+(a.length()==1?" salvo":"s salvos")+" no aparelho",13);info.setTextColor(0xffa69ca3);info.setPadding(dp(4),0,0,dp(12));body.addView(info);for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null)body.addView(offlineCard(o,i));}if(hasActiveOfflineDownloads())new Handler(Looper.getMainLooper()).postDelayed(()->{if(gen==viewGen&&currentNavIndex==3&&!detailOpen)downloads();},1500);
 }
 void searchDialog(){openSearchScreen();}
 void openSearchScreen(){
  if(detailOpen)closeDetails();
  if(mainScroll==homeScrollCache)leaveHomeForPage();else createTransientPageHost();
  searchScreenOpen=true;clear();setNav(0);
  // v16.75: barra ativa mantém exatamente a geometria da barra da Home,
  // usando componentes simples já presentes no projeto para máxima compatibilidade de compilação.
  body.setPadding(0,0,0,dp(18));

  LinearLayout topWrap=new LinearLayout(this);topWrap.setOrientation(LinearLayout.VERTICAL);topWrap.setPadding(0,dp(34),0,0);
  LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);top.setPadding(0,0,0,0);

  LinearLayout backSlot=new LinearLayout(this);backSlot.setGravity(Gravity.CENTER);backSlot.setPadding(0,0,0,0);
  TextView back=t("‹",32);back.setGravity(Gravity.CENTER);back.setTextColor(Color.WHITE);back.setPadding(0,0,0,0);GradientDrawable bb=round(0xff1a1115,18);bb.setStroke(dp(1),0xff3b2b33);back.setBackground(bb);back.setOnClickListener(v->closeSearchScreen());backSlot.addView(back,new LinearLayout.LayoutParams(dp(36),dp(36)));
  LinearLayout.LayoutParams backLp=new LinearLayout.LayoutParams(dp(56),dp(36));backLp.setMargins(0,0,dp(9),0);top.addView(backSlot,backLp);

  LinearLayout box=new LinearLayout(this);box.setGravity(Gravity.CENTER_VERTICAL);box.setPadding(dp(13),0,dp(5),0);GradientDrawable bg=round(0xff292b2c,21);bg.setStroke(dp(1),0xff444748);box.setBackground(bg);
  EditText q=new EditText(this);if(tvMode)prepareTvTextInput(q);q.setHint("Buscar");q.setHintTextColor(0xffaeb2b4);q.setTextColor(Color.WHITE);uiTextSize(q,14);q.setSingleLine(true);q.setPadding(0,0,0,0);q.setBackgroundColor(Color.TRANSPARENT);q.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);box.addView(q,new LinearLayout.LayoutParams(0,dp(38),1));
  TextView icon=t("⌕",22);icon.setTextColor(Color.WHITE);icon.setGravity(Gravity.CENTER);icon.setPadding(0,0,0,0);box.addView(icon,new LinearLayout.LayoutParams(dp(34),dp(38)));top.addView(box,new LinearLayout.LayoutParams(0,dp(38),1));
  topWrap.addView(top,new LinearLayout.LayoutParams(-1,dp(38)));body.addView(topWrap,new LinearLayout.LayoutParams(-1,dp(72)));

  LinearLayout results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);body.addView(results,new LinearLayout.LayoutParams(-1,-2));
  renderSearchResults("",results);
  final Runnable doSearch=()->renderSearchResults(q.getText().toString(),results);
  q.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){results.removeCallbacks(doSearch);results.postDelayed(doSearch,350);}public void afterTextChanged(android.text.Editable e){}});
  q.setOnEditorActionListener((v,action,event)->{if(action==android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH||(tvMode&&action==android.view.inputmethod.EditorInfo.IME_ACTION_UNSPECIFIED)||isEnterKey(event)){renderSearchResults(q.getText().toString(),results);if(tvMode){hideKeyboard(q);requestFirstTvFocus(results);}return true;}return false;});if(tvMode)q.setOnKeyListener((v,key,event)->{if(event!=null&&event.getAction()==KeyEvent.ACTION_DOWN&&isTvConfirmKeyCode(key)){renderSearchResults(q.getText().toString(),results);hideKeyboard(q);requestFirstTvFocus(results);return true;}return false;});
  icon.setOnClickListener(v->{renderSearchResults(q.getText().toString(),results);q.requestFocus();});
  q.requestFocus();q.postDelayed(()->{try{android.view.inputmethod.InputMethodManager im=(android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);im.showSoftInput(q,android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT);}catch(Exception ignored){}},120);
 }
 void closeSearchScreen(){
  searchScreenOpen=false;try{android.view.inputmethod.InputMethodManager im=(android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);View f=getCurrentFocus();if(im!=null&&f!=null)im.hideSoftInputFromWindow(f.getWindowToken(),0);}catch(Exception ignored){}
  restoreHomeView();
 }
 JSONArray localSearchResults(String q){
  JSONArray out=new JSONArray();String needle=q==null?"":q.trim().toLowerCase(java.util.Locale.ROOT);if(needle.length()<2)return out;JSONObject prepared=readHomeCache();if(prepared==null)return out;java.util.HashSet<String> seen=new java.util.HashSet<>();JSONArray secs=prepared.optJSONArray("result");if(secs==null)return out;
  for(int i=0;i<secs.length()&&out.length()<72;i++){JSONObject sec=secs.optJSONObject(i);if(sec==null)continue;JSONArray d=sec.optJSONArray("data");if(d==null)continue;for(int k=0;k<d.length()&&out.length()<72;k++){JSONObject x=d.optJSONObject(k);if(x==null)continue;String name=x.optString("name",x.optString("title","")).toLowerCase(java.util.Locale.ROOT);if(!name.contains(needle))continue;String key=x.optInt("video_type",x.optInt("type_id",1))+"|"+x.optString("id",x.optString("video_id",""));if(seen.add(key))out.put(x);}}
  return out;
 }
 void renderSearchGrid(JSONArray a,LinearLayout host){
  if(host==null)return;TextView title=t(a!=null&&a.length()>0?"Resultados":"Nenhum resultado encontrado",19);title.setTypeface(null,1);title.setPadding(dp(2),dp(10),dp(2),dp(10));host.addView(title);
  if(a==null||a.length()==0)return;
  GridLayout g=new GridLayout(this);g.setColumnCount(3);g.setUseDefaultMargins(false);host.addView(g,new LinearLayout.LayoutParams(-1,-2));int w=(getResources().getDisplayMetrics().widthPixels-dp(52))/3;
  for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;LinearLayout c=card(x);GridLayout.LayoutParams lp=new GridLayout.LayoutParams();lp.width=w;lp.height=dp(196);lp.setMargins(dp(3),dp(4),dp(5),dp(8));g.addView(c,lp);}
 }
 void renderSearchResults(String query,LinearLayout host){
  if(host==null)return;host.removeAllViews();String q=query==null?"":query.trim();
  if(q.length()<2){host.setTag(null);TextView hint=t("Digite pelo menos 2 letras para buscar.",14);hint.setTextColor(0xff999096);hint.setPadding(dp(4),dp(18),dp(4),0);host.addView(hint);return;}
  final String requestKey="search|"+q.toLowerCase(java.util.Locale.ROOT);host.setTag(requestKey);
  final JSONArray local=localSearchResults(q);
  TextView wait=t(local.length()>0?"Atualizando resultados…":"Buscando em todo o catálogo…",13);wait.setTextColor(0xff999096);wait.setPadding(dp(3),dp(13),dp(3),dp(10));host.addView(wait);
  if(local.length()>0)renderSearchGrid(local,host);
  Api.post("search_catalog",Api.m("user_id",uid,"search",q,"limit","72"),new Api.CB(){public void ok(JSONObject j){runOnUiThread(()->{
    Object tag=host.getTag();if(!searchScreenOpen||tag==null||!requestKey.equals(String.valueOf(tag)))return;
    JSONArray remote=j.optJSONArray("result");host.removeAllViews();if(j.optInt("status",200)==200&&remote!=null){renderSearchGrid(remote,host);return;}
    if(local.length()>0){renderSearchGrid(local,host);return;}TextView e=t("Não foi possível concluir a pesquisa agora.",14);e.setTextColor(0xffa69ca3);e.setPadding(dp(3),dp(18),dp(3),0);host.addView(e);
  });}public void err(String e){runOnUiThread(()->{Object tag=host.getTag();if(!searchScreenOpen||tag==null||!requestKey.equals(String.valueOf(tag)))return;host.removeAllViews();if(local.length()>0){renderSearchGrid(local,host);return;}TextView m=t("Não foi possível pesquisar agora.",14);m.setTextColor(0xffa69ca3);m.setPadding(dp(3),dp(18),dp(3),0);host.addView(m);});}});
 }
 void search(String q){
  if(searchScreenOpen){return;}
  openSearchScreen();
 }
 void showExitConfirm(){
  if(exitDialogOpen)return;exitDialogOpen=true;
  showAppConfirm("Sair do aplicativo?","Deseja realmente fechar o Yelly Doramas?","Sair",false,()->{try{finishAndRemoveTask();}catch(Exception e){try{finishAffinity();}catch(Exception ignored){finish();}}},()->exitDialogOpen=false);
 }
 void showLogoutConfirm(){showAppConfirm("Sair da conta?","Você precisará entrar novamente para acessar o Yelly Doramas.","Sair da conta",false,()->{String oldUid=uid,oldDevice=deviceId();Api.post("logout_device_sync",Api.m("user_id",oldUid,"device_id",oldDevice),new Api.CB(){public void ok(JSONObject j){}public void err(String e){}});sp.edit().clear().apply();uid="";login();},null);}
 void showDeleteConfirm(){showAppConfirm("Excluir conta definitivamente?","Sua conta, sessões e dados de acesso serão removidos do Yelly Doramas e também deixarão de aparecer no painel.","EXCLUIR CONTA",true,()->{
  Api.post("delete_account",Api.m("user_id",uid,"device_id",deviceId()),new Api.CB(){public void ok(JSONObject j){runOnUiThread(()->{if(j.optInt("status",200)!=200){showAppNotice(j.optString("message","Não foi possível excluir a conta."),true);return;}try{java.io.File f=persistentHomeFile();if(f.exists())f.delete();}catch(Exception ignored){}sp.edit().clear().apply();uid="";reseller="";showAppNotice("Conta excluída",false);new Handler(Looper.getMainLooper()).postDelayed(()->login(),700);});}public void err(String e){runOnUiThread(()->showAppNotice(e==null||e.isEmpty()?"Não foi possível excluir a conta.":e,true));}});
 },null);}
 void showAppConfirm(String titleText,String messageText,String positiveText,boolean danger,Runnable positiveAction,Runnable onDismiss){
  final Dialog d=new Dialog(this);LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(22),dp(20),dp(22),dp(18));GradientDrawable cb=round(0xff170d12,24);cb.setStroke(dp(1),0xff482938);card.setBackground(cb);
  LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);TextView mark=t(danger?"!":"✓",18);mark.setGravity(Gravity.CENTER);mark.setTypeface(null,1);mark.setPadding(0,0,0,0);mark.setTextColor(danger?0xffff6a70:GREEN);GradientDrawable mb=round(danger?0x332b1114:0x33e02080,18);mb.setStroke(dp(1),danger?0x66ff5b63:0x66e02080);mark.setBackground(mb);head.addView(mark,new LinearLayout.LayoutParams(dp(36),dp(36)));TextView title=t(titleText,22);title.setTypeface(null,1);title.setPadding(dp(12),0,0,0);head.addView(title,new LinearLayout.LayoutParams(0,dp(42),1));card.addView(head);
  TextView msg=t(messageText,15);msg.setTextColor(0xffb7acb3);msg.setPadding(0,dp(12),0,dp(22));card.addView(msg);
  LinearLayout actions=new LinearLayout(this);actions.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);TextView cancel=t("Cancelar",15);cancel.setTextColor(0xffcec2ca);cancel.setTypeface(null,1);cancel.setGravity(Gravity.CENTER);cancel.setPadding(0,0,0,0);GradientDrawable cancelBg=round(0xff23171d,14);cancelBg.setStroke(dp(1),0xff433039);cancel.setBackground(cancelBg);actions.addView(cancel,new LinearLayout.LayoutParams(dp(116),dp(50)));TextView ok=t(positiveText,15);ok.setTextColor(danger?Color.WHITE:0xff11060c);ok.setTypeface(null,1);ok.setGravity(Gravity.CENTER);ok.setPadding(dp(10),0,dp(10),0);GradientDrawable okBg=round(danger?0xffb9343d:GREEN,14);okBg.setStroke(dp(1),danger?0xffd94a52:GREEN);ok.setBackground(okBg);LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(0,dp(50),1);op.setMargins(dp(10),0,0,0);actions.addView(ok,op);card.addView(actions,new LinearLayout.LayoutParams(-1,dp(50)));
  cancel.setOnClickListener(v->d.dismiss());ok.setOnClickListener(v->{d.dismiss();if(positiveAction!=null)positiveAction.run();});d.setContentView(card);Window w=d.getWindow();if(w!=null){w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));w.setDimAmount(.72f);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);w.setGravity(Gravity.CENTER);WindowManager.LayoutParams lp=w.getAttributes();lp.windowAnimations=0;w.setAttributes(lp);}d.setOnDismissListener(x->{if(onDismiss!=null)onDismiss.run();});d.setOnShowListener(x->{Window ww=d.getWindow();if(ww!=null){WindowManager.LayoutParams lp=ww.getAttributes();lp.windowAnimations=0;ww.setAttributes(lp);ww.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(38),dp(500)),-2);}if(tvMode){prepareTvFocusTree(card);requestTvFocus(cancel);}});d.show();
 }
 void showAppNotice(String message,boolean error){
  final Dialog d=new Dialog(this);LinearLayout box=new LinearLayout(this);box.setGravity(Gravity.CENTER_VERTICAL);box.setPadding(dp(16),dp(12),dp(16),dp(12));GradientDrawable bg=round(0xff201018,16);bg.setStroke(dp(1),error?0x99d65259:0x99e02080);box.setBackground(bg);TextView dot=t(error?"!":"✓",15);dot.setTypeface(null,1);dot.setGravity(Gravity.CENTER);dot.setTextColor(error?0xffff7379:GREEN);dot.setPadding(0,0,0,0);box.addView(dot,new LinearLayout.LayoutParams(dp(28),dp(28)));TextView txt=t(message,14);txt.setTextColor(Color.WHITE);txt.setPadding(dp(10),0,0,0);box.addView(txt,new LinearLayout.LayoutParams(0,-2,1));d.setContentView(box);Window w=d.getWindow();if(w!=null){w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));w.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);w.setGravity(Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);}d.setOnShowListener(x->{Window ww=d.getWindow();if(ww!=null){ww.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(42),dp(460)),-2);WindowManager.LayoutParams lp=ww.getAttributes();lp.y=dp(90);ww.setAttributes(lp);}});d.show();new Handler(Looper.getMainLooper()).postDelayed(()->{try{if(d.isShowing())d.dismiss();}catch(Exception ignored){}},1500);
 }
 void toggleFav(JSONObject x){try{JSONArray a=new JSONArray(sp.getString("favs","[]"));String key=itemKey(x);String yt=x==null?"":x.optString("youtube_id","");if(!yt.isEmpty())key="yt|"+yt;for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;String ok=itemKey(o);String oy=o.optString("youtube_id","");if(!oy.isEmpty())ok="yt|"+oy;if(key.equals(ok)){a.remove(i);sp.edit().putString("favs",a.toString()).apply();Toast.makeText(this,"Removido dos favoritos",Toast.LENGTH_SHORT).show();return;}}a.put(x);sp.edit().putString("favs",a.toString()).apply();Toast.makeText(this,"Adicionado aos favoritos",Toast.LENGTH_SHORT).show();}catch(Exception ignored){}}
 void favorites(){clear();setNav(1);standardPageInsets();libraryPageHeader("Favoritos","Doramas e minisséries que você guardou",R.drawable.ic_nav_favorite,()->goHomeNow());try{JSONArray a=new JSONArray(sp.getString("favs","[]"));if(a.length()==0){addLibraryEmptyState(R.drawable.ic_nav_favorite,"Sua lista está vazia","Toque no coração de qualquer dorama e ele fica guardado aqui para você encontrar rápido.","Explorar conteúdos",()->goHomeNow());JSONArray sug=librarySuggestions(8);if(sug.length()>0){TextView st=t("Descubra algo para favoritar",18);st.setTypeface(null,1);st.setPadding(dp(4),dp(20),0,dp(9));body.addView(st);row(sug);}return;}TextView info=t(a.length()+" favorito"+(a.length()==1?"":"s"),13);info.setTextColor(0xffa49aa1);info.setPadding(dp(4),0,0,dp(12));body.addView(info);renderLibraryGrid(a);}catch(Exception ignored){addLibraryEmptyState(R.drawable.ic_nav_favorite,"Favoritos indisponíveis","Não foi possível abrir sua lista agora.","Voltar ao início",()->goHomeNow());}
 }
 void profile(){if(uid==null||uid.isEmpty()){login();return;}if(mainScroll==homeScrollCache&&currentNavIndex==0)leaveHomeForPage();plansScreen=false;if(navBar!=null)navBar.setVisibility(View.VISIBLE);clear();setNav(4);
  if(body!=null){int side=tvMode?Math.max(dp(34),(getResources().getDisplayMetrics().widthPixels-dp(1120))/2):dp(16);body.setPadding(side,tvMode?dp(18):dp(8),side,dp(26));}

  LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);top.setPadding(dp(2),0,dp(2),dp(8));
  ImageView profileIcon=profileIconView(R.drawable.ic_nav_profile,false);top.addView(profileIcon,new LinearLayout.LayoutParams(dp(46),dp(46)));
  LinearLayout titleBox=new LinearLayout(this);titleBox.setOrientation(LinearLayout.VERTICAL);titleBox.setPadding(dp(10),0,0,0);TextView title=t("Minha conta",tvMode?24:25);title.setTypeface(null,1);title.setPadding(0,0,0,0);TextView titleSub=t("Perfil, segurança e assinatura",12);titleSub.setTextColor(0xff9a9197);titleSub.setPadding(0,dp(2),0,0);titleBox.addView(title);titleBox.addView(titleSub);top.addView(titleBox,new LinearLayout.LayoutParams(0,dp(54),1));
  ImageButton logout=profileActionIcon(R.drawable.ic_logout,"Sair da conta");logout.setOnClickListener(v->showLogoutConfirm());top.addView(logout,new LinearLayout.LayoutParams(dp(48),dp(48)));body.addView(top,new LinearLayout.LayoutParams(-1,dp(66)));

  LinearLayout person=new LinearLayout(this);person.setGravity(Gravity.CENTER_VERTICAL);person.setPadding(dp(16),dp(14),dp(16),dp(14));GradientDrawable personBg=round(0xff1a1015,24);personBg.setStroke(dp(1),0xff3b2631);person.setBackground(personBg);person.setClickable(true);person.setFocusable(true);person.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);person.setOnClickListener(v->editAccount());applyProfileRowFocus(person,false);
  FrameLayout avatarWrap=new FrameLayout(this);GradientDrawable avBg=round(0xff8f0d4e,40);avBg.setStroke(dp(2),GREEN);TextView avatarInitials=t(personInitials(sp.getString("name","Cliente")),22);avatarInitials.setTextColor(Color.WHITE);avatarInitials.setTypeface(null,1);avatarInitials.setGravity(Gravity.CENTER);avatarInitials.setPadding(0,0,0,0);avatarInitials.setFocusable(false);avatarInitials.setBackground(avBg);avatarWrap.addView(avatarInitials,new FrameLayout.LayoutParams(dp(72),dp(72)));String photoUri=savedProfilePhoto();if(!photoUri.isEmpty()){try{ImageView profilePhoto=new ImageView(this);profilePhoto.setScaleType(ImageView.ScaleType.CENTER_CROP);profilePhoto.setImageURI(Uri.parse(photoUri));GradientDrawable photoShape=round(0xff8f0d4e,40);photoShape.setStroke(dp(2),GREEN);profilePhoto.setBackground(photoShape);profilePhoto.setClipToOutline(true);profilePhoto.setFocusable(false);avatarWrap.addView(profilePhoto,new FrameLayout.LayoutParams(dp(72),dp(72)));}catch(Exception ignored){}}if(!tvMode){ImageView cam=new ImageView(this);cam.setImageResource(android.R.drawable.ic_menu_camera);cam.setColorFilter(Color.WHITE);cam.setPadding(dp(6),dp(6),dp(6),dp(6));cam.setBackground(round(GREEN,15));cam.setFocusable(false);FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(dp(30),dp(30),Gravity.RIGHT|Gravity.BOTTOM);avatarWrap.addView(cam,cp);avatarWrap.setOnClickListener(v->chooseProfilePhoto());}person.addView(avatarWrap,new LinearLayout.LayoutParams(dp(80),dp(80)));
  LinearLayout who=new LinearLayout(this);who.setOrientation(LinearLayout.VERTICAL);who.setPadding(dp(14),0,0,0);TextView nm=t(sp.getString("name","Cliente"),20);nm.setTypeface(null,1);nm.setPadding(0,0,0,0);nm.setFocusable(false);who.addView(nm);TextView em=t(sp.getString("email",""),13);em.setTextColor(0xffa89ea5);em.setPadding(0,dp(4),0,0);em.setFocusable(false);who.addView(em);TextView rv=t("Yelly Doramas",12);rv.setTextColor(GREEN);rv.setPadding(0,dp(7),0,0);rv.setFocusable(false);who.addView(rv);person.addView(who,new LinearLayout.LayoutParams(0,-2,1));body.addView(person);profileGap(12);

  LinearLayout renewal=new LinearLayout(this);renewal.setGravity(Gravity.CENTER_VERTICAL);renewal.setPadding(dp(16),dp(10),dp(13),dp(10));GradientDrawable renewBg=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0xff290d1b,0xff1d1117});renewBg.setCornerRadius(dp(22));renewBg.setStroke(dp(1),GREEN);renewal.setBackground(renewBg);renewal.setVisibility(View.GONE);renewal.setFocusable(true);renewal.setClickable(true);applyProfileRowFocus(renewal,false);
  ImageView warn=profileIconView(R.drawable.ic_plans,false);renewal.addView(warn,new LinearLayout.LayoutParams(dp(42),dp(42)));LinearLayout renewText=new LinearLayout(this);renewText.setOrientation(LinearLayout.VERTICAL);renewText.setPadding(dp(10),0,0,0);TextView renewTitle=t("Assinatura necessária",15);renewTitle.setTypeface(null,1);renewTitle.setPadding(0,0,0,0);renewTitle.setFocusable(false);TextView renewSub=t("Escolha um plano para continuar",11);renewSub.setTextColor(0xffb0a5ac);renewSub.setPadding(0,dp(3),0,0);renewSub.setFocusable(false);renewText.addView(renewTitle);renewText.addView(renewSub);renewal.addView(renewText,new LinearLayout.LayoutParams(0,-2,1));TextView renewBtn=t("VER PLANOS",11);renewBtn.setTypeface(null,1);renewBtn.setTextColor(0xff11060c);renewBtn.setGravity(Gravity.CENTER);renewBtn.setFocusable(false);renewBtn.setBackground(round(GREEN,17));renewal.addView(renewBtn,new LinearLayout.LayoutParams(dp(110),dp(40)));renewal.setOnClickListener(v->plans());body.addView(renewal,new LinearLayout.LayoutParams(-1,dp(72)));

  LinearLayout infoCard=profileSectionCard("Informações da conta");
  TextView planValue=profileInfoLine(infoCard,"✦","Plano","—",GREEN);TextView validityValue=profileInfoLine(infoCard,"◷","Validade","—",0xffd3d7d5);TextView screensValue=profileInfoLine(infoCard,"▣","Telas","—",0xfff1f1f1);TextView serverValue=profileInfoLine(infoCard,"◉","Catálogo","Yelly Doramas",0xfff1f1f1);TextView subscriptionValue=profileInfoLine(infoCard,"✓","Assinatura","—",GREEN);body.addView(infoCard);profileGap(12);

  LinearLayout account=profileSectionCard("Conta e assinatura");
  profileOptionRow(account,R.drawable.ic_plans,"Ver planos","Planos, renovação e quantidade de telas",v->plans(),false);
  boolean nativeTvDevice=DeviceCompat.isTelevisionDevice(this);
  Switch tvModeSwitch=profileSwitchRow(account,R.drawable.ic_devices,"Modo TV / Android TV Box","Use o layout para controle remoto e TV Box",nativeTvDevice||sp.getBoolean("force_tv_mode",false));
  tvModeSwitch.setClickable(false);
  View tvModeRow=(View)tvModeSwitch.getTag();
  if(tvModeRow!=null)tvModeRow.setOnClickListener(v->{
   if(nativeTvDevice){showAppNotice("Modo TV automático neste aparelho.",false);tvModeSwitch.setChecked(true);return;}
   boolean enable=!sp.getBoolean("force_tv_mode",false);tvModeSwitch.setChecked(enable);
   relaunchForModeChange(enable);
  });
  profileOptionRow(account,R.drawable.ic_devices,"Dispositivos conectados","Veja e desconecte aparelhos da sua conta",v->showConnectedDevices(),false);
  profileOptionRow(account,R.drawable.ic_support,"Suporte","Fale com o suporte do seu vendedor",v->openSupport(),false);
  body.addView(account);profileGap(12);

  LinearLayout security=profileSectionCard("Segurança e privacidade");
  profileOptionRow(security,R.drawable.ic_password,"Redefinir senha","Troque a senha de acesso da conta",v->changePassword(),false);
  Switch adultSwitch=profileSwitchRow(security,R.drawable.ic_adult,"Conteúdo adulto","Protegido por PIN de 4 dígitos",adultContentVisible());adultSwitch.setClickable(false);View adultRow=(View)adultSwitch.getTag();if(adultRow!=null)adultRow.setOnClickListener(v->requestAdultToggle(adultSwitch));
  profileOptionRow(security,R.drawable.ic_pin,"Alterar PIN","PIN usado para liberar conteúdo +18",v->changePin(),false);
  profileOptionRow(security,R.drawable.ic_delete,"Excluir conta","Remove a conta e os dados do painel",v->showDeleteConfirm(),true);
  body.addView(security);profileGap(10);

  JSONObject cachedAccess=readCachedAccessStatus();if(cachedAccess!=null)applyProfileAccessUi(cachedAccess,planValue,validityValue,screensValue,serverValue,subscriptionValue,renewal,renewTitle,renewSub);
  Api.post("access_status",Api.m("user_id",uid),new Api.CB(){public void ok(JSONObject j){JSONArray a=j.optJSONArray("result");if(a==null||a.length()==0){runOnUiThread(()->{planValue.setText("Sem plano");validityValue.setText("—");screensValue.setText("1 de 1");subscriptionValue.setText("Inativa");});return;}JSONObject st=a.optJSONObject(0);if(st!=null)applyEntitlements(st);runOnUiThread(()->applyProfileAccessUi(st,planValue,validityValue,screensValue,serverValue,subscriptionValue,renewal,renewTitle,renewSub));}public void err(String x){if(readCachedAccessStatus()==null)runOnUiThread(()->{subscriptionValue.setText("Indisponível");subscriptionValue.setTextColor(0xffb4a9b0);});}});
  refreshAccountContext(()->rv.setText("Yelly Doramas"));
  syncDevice(null);
 }
 LinearLayout profileSectionCard(String title){LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(10),dp(8),dp(10),dp(9));GradientDrawable bg=round(0xff171013,24);bg.setStroke(dp(1),0xff34262d);card.setBackground(bg);TextView h=t(title,13);h.setTypeface(null,1);h.setTextColor(0xffa0969d);h.setLetterSpacing(.05f);h.setPadding(dp(12),dp(7),dp(8),dp(8));h.setFocusable(false);card.addView(h,new LinearLayout.LayoutParams(-1,dp(42)));return card;}
 ImageView profileIconView(int res,boolean danger){ImageView v=new ImageView(this);v.setImageResource(res);v.setColorFilter(danger?0xffff6972:GREEN);v.setScaleType(ImageView.ScaleType.CENTER_INSIDE);v.setPadding(dp(11),dp(11),dp(11),dp(11));GradientDrawable bg=round(danger?0x332c1115:0x33e02080,16);bg.setStroke(dp(1),danger?0x665c2229:0x66b93074);v.setBackground(bg);v.setFocusable(false);return v;}
 ImageButton profileActionIcon(int res,String description){ImageButton b=new ImageButton(this);b.setImageResource(res);b.setColorFilter(Color.WHITE);b.setScaleType(ImageView.ScaleType.CENTER_INSIDE);b.setPadding(dp(12),dp(12),dp(12),dp(12));b.setContentDescription(description);b.setBackground(profileFocusDrawable(false,true));b.setFocusable(true);b.setFocusableInTouchMode(false);return b;}
 Drawable profileFocusDrawable(boolean danger,boolean compact){StateListDrawable st=new StateListDrawable();GradientDrawable f=round(danger?0xff421c21:0xff361526,compact?18:17);f.setStroke(dp(2),danger?0xffff6972:GREEN);GradientDrawable n=round(compact?0xff1f151a:0xff1a1115,compact?18:17);n.setStroke(dp(1),danger?0xff51252b:0xff392931);st.addState(new int[]{android.R.attr.state_focused},f);st.addState(new int[]{android.R.attr.state_pressed},f);st.addState(new int[]{},n);return st;}
 void applyProfileRowFocus(View row,boolean danger){if(row==null)return;row.setFocusable(true);row.setFocusableInTouchMode(false);row.setClickable(true);row.setBackground(profileFocusDrawable(danger,false));if(tvMode)armTvFocus(row);}
 void profileOptionRow(LinearLayout host,int iconRes,String title,String subtitle,View.OnClickListener click,boolean danger){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(10),dp(5),dp(8),dp(5));row.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);ImageView ic=profileIconView(iconRes,danger);row.addView(ic,new LinearLayout.LayoutParams(dp(42),dp(42)));LinearLayout mid=new LinearLayout(this);mid.setOrientation(LinearLayout.VERTICAL);mid.setPadding(dp(12),0,0,0);TextView tt=t(title,15);tt.setTypeface(null,1);tt.setTextColor(danger?0xffff7a82:Color.WHITE);tt.setPadding(0,0,0,0);tt.setFocusable(false);TextView sub=t(subtitle,11);sub.setTextColor(0xff91888e);sub.setPadding(0,dp(2),0,0);sub.setFocusable(false);mid.addView(tt);mid.addView(sub);row.addView(mid,new LinearLayout.LayoutParams(0,dp(54),1));TextView ar=t("›",25);ar.setTextColor(0xff7b7479);ar.setGravity(Gravity.CENTER);ar.setPadding(0,0,0,0);ar.setFocusable(false);row.addView(ar,new LinearLayout.LayoutParams(dp(34),dp(54)));applyProfileRowFocus(row,danger);row.setOnClickListener(click);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(66));lp.setMargins(0,0,0,dp(5));host.addView(row,lp);}
 Switch profileSwitchRow(LinearLayout host,int iconRes,String title,String subtitle,boolean checked){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(10),dp(5),dp(8),dp(5));row.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);ImageView ic=profileIconView(iconRes,false);row.addView(ic,new LinearLayout.LayoutParams(dp(42),dp(42)));LinearLayout mid=new LinearLayout(this);mid.setOrientation(LinearLayout.VERTICAL);mid.setPadding(dp(12),0,0,0);TextView tt=t(title,15);tt.setTypeface(null,1);tt.setPadding(0,0,0,0);tt.setFocusable(false);TextView sub=t(subtitle,11);sub.setTextColor(0xff91888e);sub.setPadding(0,dp(2),0,0);sub.setFocusable(false);mid.addView(tt);mid.addView(sub);row.addView(mid,new LinearLayout.LayoutParams(0,dp(54),1));Switch sw=new Switch(this);sw.setChecked(checked);sw.setShowText(false);sw.setFocusable(false);sw.setClickable(false);row.addView(sw,new LinearLayout.LayoutParams(dp(66),dp(48)));sw.setTag(row);applyProfileRowFocus(row,false);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(66));lp.setMargins(0,0,0,dp(5));host.addView(row,lp);return sw;}
 TextView profileInfoLine(LinearLayout host,String icon,String label,String value,int valueColor){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(4),0,dp(2),0);TextView ic=t(icon,16);ic.setGravity(Gravity.CENTER);ic.setTextColor(0xff968d93);ic.setPadding(0,0,0,0);ic.setFocusable(false);row.addView(ic,new LinearLayout.LayoutParams(dp(38),dp(58)));TextView lb=t(label,14);lb.setTextColor(0xff968d93);lb.setPadding(0,0,0,0);lb.setGravity(Gravity.CENTER_VERTICAL);lb.setFocusable(false);row.addView(lb,new LinearLayout.LayoutParams(0,dp(58),1));TextView val=t(value,14);val.setTypeface(null,1);val.setTextColor(valueColor);val.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);val.setPadding(dp(8),0,dp(6),0);val.setMaxLines(2);val.setFocusable(false);row.addView(val,new LinearLayout.LayoutParams(0,dp(58),1));host.addView(row,new LinearLayout.LayoutParams(-1,dp(58)));profileDivider(host,dp(42));return val;}
 void profileDivider(LinearLayout host,int left){View line=new View(this);line.setBackgroundColor(0xff33242c);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(1));lp.setMargins(left,0,dp(4),0);host.addView(line,lp);}
 void profileOptionRow(LinearLayout host,String icon,String title,View.OnClickListener click,boolean danger){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(5),0,dp(2),0);TextView ic=t(icon,18);ic.setGravity(Gravity.CENTER);ic.setTextColor(danger?0xffff5963:0xff9d949a);ic.setPadding(0,0,0,0);row.addView(ic,new LinearLayout.LayoutParams(dp(45),dp(62)));TextView tt=t(title,15);tt.setTypeface(null,1);tt.setTextColor(danger?0xffff7078:Color.WHITE);tt.setGravity(Gravity.CENTER_VERTICAL);tt.setPadding(dp(2),0,0,0);tt.setSingleLine(true);row.addView(tt,new LinearLayout.LayoutParams(0,dp(62),1));TextView ar=t("›",26);ar.setTextColor(0xff716a6f);ar.setGravity(Gravity.CENTER);ar.setPadding(0,0,0,0);row.addView(ar,new LinearLayout.LayoutParams(dp(34),dp(62)));row.setOnClickListener(click);host.addView(row,new LinearLayout.LayoutParams(-1,dp(62)));profileDivider(host,dp(52));}
 Switch profileSwitchRow(LinearLayout host,String icon,String title,boolean checked){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(5),0,dp(8),0);TextView ic=t(icon,18);ic.setGravity(Gravity.CENTER);ic.setTextColor(0xff9d949a);ic.setPadding(0,0,0,0);row.addView(ic,new LinearLayout.LayoutParams(dp(45),dp(62)));TextView tt=t(title,15);tt.setTypeface(null,1);tt.setGravity(Gravity.CENTER_VERTICAL);tt.setPadding(dp(2),0,0,0);row.addView(tt,new LinearLayout.LayoutParams(0,dp(62),1));Switch sw=new Switch(this);sw.setChecked(checked);sw.setShowText(false);row.addView(sw,new LinearLayout.LayoutParams(dp(68),dp(48)));sw.setTag(row);host.addView(row,new LinearLayout.LayoutParams(-1,dp(62)));profileDivider(host,dp(52));return sw;}
 TextView metric(String label,String value){TextView v=t(label+"\n"+value,12);v.setGravity(Gravity.CENTER);v.setTextColor(0xffd1c4cd);v.setMaxLines(3);return v;}
 String shortDate(String x){try{return x.length()>=10?x.substring(8,10)+"/"+x.substring(5,7)+"/"+x.substring(0,4):x;}catch(Exception e){return x;}}
 void profileGap(int h){Space s=new Space(this);body.addView(s,new LinearLayout.LayoutParams(1,dp(h)));}
 void addProfileOption2(String icon,String title,String subtitle,View.OnClickListener click,boolean danger){LinearLayout box=new LinearLayout(this);box.setGravity(Gravity.CENTER_VERTICAL);box.setPadding(dp(12),0,dp(10),0);box.setBackground(round(CARD,14));TextView ic=t(icon,18);ic.setGravity(Gravity.CENTER);ic.setTextColor(danger?0xffff5963:GREEN);box.addView(ic,new LinearLayout.LayoutParams(dp(38),dp(58)));TextView tt=t(title,15);tt.setTypeface(null,1);if(danger)tt.setTextColor(0xffff686f);tt.setGravity(Gravity.CENTER_VERTICAL);tt.setSingleLine(true);box.addView(tt,new LinearLayout.LayoutParams(0,dp(58),1));TextView ar=t("›",24);ar.setTextColor(0xff938a90);ar.setGravity(Gravity.CENTER);box.addView(ar,new LinearLayout.LayoutParams(dp(30),dp(58)));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(58));lp.setMargins(0,0,0,dp(6));body.addView(box,lp);box.setOnClickListener(click);}

 void editAccount(){LinearLayout f=new LinearLayout(this);f.setOrientation(LinearLayout.VERTICAL);f.setPadding(dp(18),0,dp(18),0);EditText n=e("Nome",false);n.setText(sp.getString("name",""));EditText w=e("WhatsApp",false);f.addView(n);f.addView(w);new AlertDialog.Builder(this).setTitle("Minha conta").setView(f).setNegativeButton("Cancelar",null).setPositiveButton("Salvar",(d,x)->Api.post("update_profile",Api.m("user_id",uid,"name",n.getText().toString().trim(),"mobile_number",w.getText().toString().trim()),new Api.CB(){public void ok(JSONObject j){if(j.optInt("status")==200){sp.edit().putString("name",n.getText().toString().trim()).apply();Toast.makeText(MainActivity.this,"Dados atualizados",0).show();profile();}else Toast.makeText(MainActivity.this,j.optString("message","Não foi possível salvar"),1).show();}public void err(String z){Toast.makeText(MainActivity.this,z,1).show();}})).show();}
 void chooseProvider(){providerSelectAfterLogin(true);}
 void loadProvidersFromSettings(){loadProvidersLegacy();}
 void loadProvidersLegacy(){Api.post("get_providers",Api.m("user_id",uid,"reseller_code",reseller),new Api.CB(){public void ok(JSONObject j){JSONArray a=j.optJSONArray("result");if(a==null||a.length()==0){body.addView(t("Nenhum servidor disponível.",16));return;}for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null)providerCard(o);}}public void err(String z){TextView e=t("Não foi possível carregar os servidores. Atualize o painel e tente novamente.",16);e.setTextColor(0xffff7777);body.addView(e);}});}
 void providerCard(JSONObject o){String id=o.optString("id",o.optString("provider_id",""));String name=o.optString("name","Servidor");String active=Api.PROVIDER==null?"":Api.PROVIDER;int movies=providerCount(o,"movies"),series=providerCount(o,"series"),live=providerCount(o,"live");rememberProviderCaps(id,name,movies,series,live);String caps="";if(movies>0)caps="Filmes";if(series>0)caps+=(caps.isEmpty()?"":"  •  ")+"Séries";if(live>0)caps+=(caps.isEmpty()?"":"  •  ")+"TV ao vivo";if(caps.isEmpty())caps="Conteúdo em preparação";LinearLayout card=new LinearLayout(this);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(14),dp(10),dp(12),dp(10));GradientDrawable g=round(0xff1e171a,20);g.setStroke(dp(id.equals(active)?2:1),id.equals(active)?GREEN:0xff33272d);card.setBackground(g);TextView icon=t("▦",24);icon.setTextColor(GREEN);icon.setGravity(Gravity.CENTER);icon.setBackground(round(0xff321222,15));card.addView(icon,new LinearLayout.LayoutParams(dp(58),dp(58)));LinearLayout mid=new LinearLayout(this);mid.setOrientation(LinearLayout.VERTICAL);mid.setPadding(dp(12),0,0,0);TextView n=t(name,17);n.setTypeface(null,1);mid.addView(n);TextView c=t(caps,14);c.setTextColor(0xffa69ca3);mid.addView(c);card.addView(mid,new LinearLayout.LayoutParams(0,-2,1));TextView ar=t(id.equals(active)?"✓":"›",26);ar.setTextColor(id.equals(active)?GREEN:0xffb0a5ac);ar.setGravity(Gravity.CENTER);card.addView(ar,new LinearLayout.LayoutParams(dp(42),dp(62)));final int providerMovies=movies,providerSeries=series,providerLive=live;card.setOnClickListener(v->connectProviderReady(id,name,providerMovies,providerSeries,providerLive,card,ar));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(78));lp.setMargins(dp(4),0,dp(4),dp(10));body.addView(card,lp);}
  void showProviderLoading(String name){clear();setNav(4);TextView title=t("Carregando conteúdo",25);title.setTypeface(null,1);title.setGravity(Gravity.CENTER);body.addView(new Space(this),new LinearLayout.LayoutParams(1,dp(120)));body.addView(title);TextView sub=t("Conectando ao servidor "+name+"…",15);sub.setTextColor(0xffa79da4);sub.setGravity(Gravity.CENTER);body.addView(sub);ProgressBar p=new ProgressBar(this);p.setIndeterminate(true);LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(dp(52),dp(52));pp.gravity=Gravity.CENTER_HORIZONTAL;pp.setMargins(0,dp(24),0,0);body.addView(p,pp);fetchPreparedHome(-1,-1,new PreparedHomeCB(){public void ok(JSONObject j){JSONArray a=j.optJSONArray("result");if(a!=null&&a.length()>0){stripUnverifiedCatalogArt(j);saveHomeCache(j);sp.edit().putBoolean(homeExtrasKey(),false).apply();homeExtrasStarted=false;prepareCriticalDetails(j,()->warmHomeImages(j,()->home()));}else home();}public void err(String e){home();}});}
 void stabilizeInputDialog(Dialog d,View card){
  if(card!=null){if(tvMode){card.setFocusable(false);prepareTvFocusTree(card);}else{card.setFocusableInTouchMode(true);card.requestFocus();}}
  Window w=d.getWindow();if(w!=null){w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));w.setDimAmount(.72f);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);w.setGravity(Gravity.CENTER);w.setSoftInputMode((tvMode?WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE:WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING)|WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);WindowManager.LayoutParams lp=w.getAttributes();lp.windowAnimations=0;w.setAttributes(lp);}
  d.setOnDismissListener(x->{tvImeActive=false;if(tvMode)new Handler(Looper.getMainLooper()).postDelayed(()->{try{enterTvImmersiveUi();}catch(Exception ignored){}},180);});
 }
 void sizeStableInputDialog(Dialog d,View focusRoot){Window w=d.getWindow();if(w==null)return;w.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(38),dp(500)),-2);WindowManager.LayoutParams lp=w.getAttributes();lp.windowAnimations=0;w.setAttributes(lp);if(focusRoot!=null){if(tvMode)prepareTvFocusTree(focusRoot);else{focusRoot.setFocusableInTouchMode(true);focusRoot.requestFocus();}}}
 void changePassword(){
  final Dialog d=new Dialog(this);LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(20),dp(18),dp(20),dp(18));GradientDrawable bg=round(0xff170d12,24);bg.setStroke(dp(1),0xff482938);card.setBackground(bg);TextView title=t("Redefinir senha",22);title.setTypeface(null,1);title.setPadding(0,0,0,dp(6));card.addView(title);TextView sub=t("Crie uma nova senha para sua conta.",14);sub.setTextColor(0xffaaa0a7);sub.setPadding(0,0,0,dp(14));card.addView(sub);EditText p1=e("Nova senha",true),p2=e("Confirmar nova senha",true);GradientDrawable i1=round(0xff221019,14);i1.setStroke(dp(1),0xff452b38);p1.setBackground(i1);GradientDrawable i2=round(0xff221019,14);i2.setStroke(dp(1),0xff452b38);p2.setBackground(i2);card.addView(p1,new LinearLayout.LayoutParams(-1,dp(54)));LinearLayout.LayoutParams p2lp=new LinearLayout.LayoutParams(-1,dp(54));p2lp.setMargins(0,dp(9),0,0);card.addView(p2,p2lp);TextView err=t("",12);err.setTextColor(0xffff7379);err.setPadding(dp(2),dp(7),0,dp(4));card.addView(err);
  LinearLayout actions=new LinearLayout(this);actions.setGravity(Gravity.RIGHT);TextView cancel=t("Cancelar",14);cancel.setGravity(Gravity.CENTER);cancel.setTypeface(null,1);cancel.setTextColor(0xffcec2ca);GradientDrawable cb=round(0xff23171d,13);cb.setStroke(dp(1),0xff433039);cancel.setBackground(cb);actions.addView(cancel,new LinearLayout.LayoutParams(dp(112),dp(48)));TextView save=t("Salvar",14);save.setGravity(Gravity.CENTER);save.setTypeface(null,1);save.setTextColor(0xff11060c);save.setBackground(round(GREEN,13));LinearLayout.LayoutParams slp=new LinearLayout.LayoutParams(dp(112),dp(48));slp.setMargins(dp(9),0,0,0);actions.addView(save,slp);card.addView(actions);
  cancel.setOnClickListener(v->d.dismiss());save.setOnClickListener(v->{String a=p1.getText().toString();if(a.length()<6){err.setText("Use pelo menos 6 caracteres.");return;}if(!a.equals(p2.getText().toString())){err.setText("As senhas não coincidem.");return;}save.setEnabled(false);err.setText("");Api.post("change_password",Api.m("user_id",uid,"password",a),new Api.CB(){public void ok(JSONObject j){runOnUiThread(()->{if(j.optInt("status",200)!=200){save.setEnabled(true);err.setText(j.optString("message","Não foi possível alterar a senha."));return;}d.dismiss();showAppNotice("Senha atualizada",false);});}public void err(String z){runOnUiThread(()->{save.setEnabled(true);err.setText(z==null||z.isEmpty()?"Não foi possível alterar a senha.":z);});}});});if(tvMode){bindImeMove(p1,p2,android.view.inputmethod.EditorInfo.IME_ACTION_NEXT);bindImeMove(p2,save,android.view.inputmethod.EditorInfo.IME_ACTION_DONE);linkTvVertical(p1,p2);linkTvVertical(p2,save);}d.setContentView(card);stabilizeInputDialog(d,card);d.setOnShowListener(x->{sizeStableInputDialog(d,card);if(tvMode)requestTvFocus(p1);});d.show();
 }
 void requestAdultToggle(Switch sw){
  if(!planAdultAllowed){sp.edit().putBoolean("adult",false).apply();if(sw!=null)sw.setChecked(false);showAppNotice("Seu plano não inclui conteúdo adulto.",true);return;}
  if(adultContentVisible()){
   Api.post("parent_control_update",Api.m("user_id",uid,"enabled","0"),new Api.CB(){public void ok(JSONObject j){runOnUiThread(()->{sp.edit().putBoolean("adult",false).apply();if(sw!=null)sw.setChecked(false);showAppNotice("Conteúdo adulto bloqueado",false);profile();});}public void err(String e){runOnUiThread(()->showAppNotice("Não foi possível bloquear o conteúdo adulto.",true));}});return;
  }
  if(sp.getBoolean("parent_pin_set",false))showAdultPinVerify(sw);else showAdultPinCreate(sw,true);
 }
 void toggleAdult(){requestAdultToggle(null);}
 void showAdultPinVerify(Switch sw){
  final Dialog d=new Dialog(this);LinearLayout card=pinDialogCard("Liberar conteúdo adulto","Digite seu PIN de 4 dígitos para acessar categorias +18.");EditText pin=pinInput("PIN");card.addView(pin,new LinearLayout.LayoutParams(-1,dp(54)));TextView err=pinError();card.addView(err);LinearLayout actions=pinActions(d,"Liberar",()->{String p=pin.getText().toString();if(!p.matches("\\d{4}")){err.setText("Digite os 4 números do PIN.");return;}Api.post("parent_control_update",Api.m("user_id",uid,"current_pin",p,"enabled","1"),new Api.CB(){public void ok(JSONObject j){runOnUiThread(()->{if(j.optInt("status",200)!=200){err.setText(j.optString("message","PIN incorreto."));return;}sp.edit().putBoolean("adult",true).putBoolean("parent_pin_set",true).apply();if(sw!=null)sw.setChecked(true);d.dismiss();showAppNotice("Conteúdo adulto liberado",false);profile();});}public void err(String e){runOnUiThread(()->err.setText("Não foi possível validar o PIN."));}});});card.addView(actions);showPinDialog(d,card,pin);
 }
 void showAdultPinCreate(Switch sw,boolean enableAfter){
  final Dialog d=new Dialog(this);LinearLayout card=pinDialogCard("Criar PIN adulto","Crie um PIN de 4 dígitos. Ele será exigido sempre que o conteúdo adulto for liberado.");EditText p1=pinInput("Novo PIN");EditText p2=pinInput("Confirmar PIN");card.addView(p1,new LinearLayout.LayoutParams(-1,dp(54)));LinearLayout.LayoutParams p2lp=new LinearLayout.LayoutParams(-1,dp(54));p2lp.setMargins(0,dp(9),0,0);card.addView(p2,p2lp);TextView err=pinError();card.addView(err);LinearLayout actions=pinActions(d,"Salvar",()->{String a=p1.getText().toString(),b=p2.getText().toString();if(!a.matches("\\d{4}")){err.setText("Use exatamente 4 números.");return;}if(!a.equals(b)){err.setText("Os PINs não coincidem.");return;}Api.post("parent_control_update",Api.m("user_id",uid,"new_pin",a,"enabled",enableAfter?"1":"0"),new Api.CB(){public void ok(JSONObject j){runOnUiThread(()->{if(j.optInt("status",200)!=200){err.setText(j.optString("message","Não foi possível salvar o PIN."));return;}sp.edit().putBoolean("parent_pin_set",true).putBoolean("adult",enableAfter).apply();if(sw!=null)sw.setChecked(enableAfter);d.dismiss();showAppNotice(enableAfter?"PIN criado e conteúdo adulto liberado":"PIN criado",false);profile();});}public void err(String e){runOnUiThread(()->err.setText("Não foi possível salvar o PIN."));}});});card.addView(actions);showPinDialog(d,card,p1);
 }
 void changePin(){
  boolean has=sp.getBoolean("parent_pin_set",false);if(!has){showAdultPinCreate(null,false);return;}
  final Dialog d=new Dialog(this);LinearLayout card=pinDialogCard("Alterar PIN","Confirme o PIN atual e escolha um novo código de 4 dígitos.");EditText oldPin=pinInput("PIN atual"),p1=pinInput("Novo PIN"),p2=pinInput("Confirmar novo PIN");card.addView(oldPin,new LinearLayout.LayoutParams(-1,dp(54)));LinearLayout.LayoutParams lp1=new LinearLayout.LayoutParams(-1,dp(54));lp1.setMargins(0,dp(9),0,0);card.addView(p1,lp1);LinearLayout.LayoutParams lp2=new LinearLayout.LayoutParams(-1,dp(54));lp2.setMargins(0,dp(9),0,0);card.addView(p2,lp2);TextView err=pinError();card.addView(err);LinearLayout actions=pinActions(d,"Atualizar",()->{String o=oldPin.getText().toString(),a=p1.getText().toString(),b=p2.getText().toString();if(!o.matches("\\d{4}")||!a.matches("\\d{4}")){err.setText("O PIN deve ter exatamente 4 números.");return;}if(!a.equals(b)){err.setText("Os novos PINs não coincidem.");return;}Api.post("parent_control_update",Api.m("user_id",uid,"current_pin",o,"new_pin",a,"enabled",adultContentVisible()?"1":"0"),new Api.CB(){public void ok(JSONObject j){runOnUiThread(()->{if(j.optInt("status",200)!=200){err.setText(j.optString("message","PIN atual incorreto."));return;}sp.edit().putBoolean("parent_pin_set",true).apply();d.dismiss();showAppNotice("PIN atualizado",false);});}public void err(String e){runOnUiThread(()->err.setText("Não foi possível alterar o PIN."));}});});card.addView(actions);showPinDialog(d,card,oldPin);
 }
 LinearLayout pinDialogCard(String title,String subtitle){LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(22),dp(20),dp(22),dp(18));GradientDrawable bg=round(0xff170d12,24);bg.setStroke(dp(1),0xff523142);card.setBackground(bg);TextView t1=t(title,21);t1.setTypeface(null,1);t1.setPadding(0,0,0,dp(5));t1.setFocusable(false);card.addView(t1);TextView t2=t(subtitle,13);t2.setTextColor(0xffa89ea5);t2.setPadding(0,0,0,dp(15));t2.setFocusable(false);card.addView(t2);return card;}
 EditText pinInput(String hint){EditText pin=e(hint,true);pin.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);pin.setSingleLine(true);pin.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(4)});GradientDrawable ib=round(0xff221019,14);ib.setStroke(dp(1),0xff452b38);pin.setBackground(ib);return pin;}
 TextView pinError(){TextView err=t("",12);err.setTextColor(0xffff7379);err.setPadding(dp(2),dp(7),0,dp(5));err.setFocusable(false);return err;}
 LinearLayout pinActions(Dialog d,String positive,Runnable action){LinearLayout actions=new LinearLayout(this);actions.setGravity(Gravity.RIGHT);TextView cancel=t("Cancelar",14);cancel.setGravity(Gravity.CENTER);cancel.setTypeface(null,1);cancel.setTextColor(0xffcec2ca);cancel.setBackground(profileFocusDrawable(false,true));cancel.setFocusable(true);cancel.setOnClickListener(v->d.dismiss());actions.addView(cancel,new LinearLayout.LayoutParams(dp(112),dp(48)));TextView save=t(positive,14);save.setGravity(Gravity.CENTER);save.setTypeface(null,1);save.setTextColor(0xff11060c);save.setBackground(round(GREEN,14));save.setFocusable(true);save.setOnClickListener(v->action.run());LinearLayout.LayoutParams slp=new LinearLayout.LayoutParams(dp(122),dp(48));slp.setMargins(dp(9),0,0,0);actions.addView(save,slp);if(tvMode)linkTvHorizontal(cancel,save);return actions;}
 void showPinDialog(Dialog d,LinearLayout card,EditText first){d.setContentView(card);stabilizeInputDialog(d,card);d.setOnShowListener(x->{sizeStableInputDialog(d,card);if(tvMode)requestTvFocus(first);});d.show();}
 void showConnectedDevices(){
  final Dialog d=new Dialog(this);LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(18),dp(16),dp(18),dp(16));GradientDrawable bg=round(0xff170d12,24);bg.setStroke(dp(1),0xff523142);card.setBackground(bg);TextView title=t("Dispositivos conectados",21);title.setTypeface(null,1);title.setPadding(0,0,0,dp(4));title.setFocusable(false);card.addView(title);TextView sub=t("Aparelhos que acessaram sua conta recentemente",12);sub.setTextColor(0xffa0969d);sub.setPadding(0,0,0,dp(12));sub.setFocusable(false);card.addView(sub);ScrollView sv=new ScrollView(this);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);TextView loading=t("Carregando dispositivos…",13);loading.setTextColor(0xff9a9197);loading.setGravity(Gravity.CENTER);loading.setFocusable(false);list.addView(loading,new LinearLayout.LayoutParams(-1,dp(64)));sv.addView(list);card.addView(sv,new LinearLayout.LayoutParams(-1,Math.min(dp(tvMode?360:420),getResources().getDisplayMetrics().heightPixels/2)));TextView close=t("Fechar",14);close.setGravity(Gravity.CENTER);close.setTypeface(null,1);close.setBackground(profileFocusDrawable(false,true));close.setFocusable(true);close.setOnClickListener(v->d.dismiss());LinearLayout.LayoutParams clp=new LinearLayout.LayoutParams(-1,dp(48));clp.setMargins(0,dp(12),0,0);card.addView(close,clp);d.setContentView(card);stabilizeInputDialog(d,card);d.setOnShowListener(x->{Window w=d.getWindow();if(w!=null)w.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-dp(38),dp(tvMode?680:520)),-2);});d.show();Api.post("get_device_sync_list",Api.m("user_id",uid,"device_id",deviceId()),new Api.CB(){public void ok(JSONObject j){runOnUiThread(()->{list.removeAllViews();JSONArray a=j.optJSONArray("result");if(a==null||a.length()==0){TextView empty=t("Nenhum outro dispositivo conectado.",13);empty.setTextColor(0xff9a9197);empty.setGravity(Gravity.CENTER);empty.setFocusable(false);list.addView(empty,new LinearLayout.LayoutParams(-1,dp(72)));return;}for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;String did=o.optString("device_id","");boolean current=did.equals(deviceId())||o.optInt("is_current",0)==1;LinearLayout row=new LinearLayout(MainActivity.this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(10),dp(8),dp(10),dp(8));row.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);ImageView ic=profileIconView(R.drawable.ic_devices,false);row.addView(ic,new LinearLayout.LayoutParams(dp(42),dp(42)));LinearLayout mid=new LinearLayout(MainActivity.this);mid.setOrientation(LinearLayout.VERTICAL);mid.setPadding(dp(11),0,0,0);TextView n=t(o.optString("device_name","Android"),14);n.setTypeface(null,1);n.setPadding(0,0,0,0);n.setFocusable(false);TextView meta=t((current?"Este aparelho • ":"")+o.optString("last_seen_label",o.optString("last_seen","")),10);meta.setTextColor(current?GREEN:0xff90878d);meta.setPadding(0,dp(2),0,0);meta.setFocusable(false);mid.addView(n);mid.addView(meta);row.addView(mid,new LinearLayout.LayoutParams(0,dp(50),1));if(!current){TextView remove=t("Desconectar",11);remove.setTextColor(0xffff7d84);remove.setGravity(Gravity.CENTER);remove.setFocusable(false);row.addView(remove,new LinearLayout.LayoutParams(dp(100),dp(42)));row.setOnClickListener(v->{Api.post("logout_device_sync",Api.m("user_id",uid,"device_id",did),new Api.CB(){public void ok(JSONObject x){runOnUiThread(()->{showAppNotice("Dispositivo desconectado",false);d.dismiss();showConnectedDevices();});}public void err(String e){runOnUiThread(()->showAppNotice("Não foi possível desconectar.",true));}});});}applyProfileRowFocus(row,false);LinearLayout.LayoutParams rlp=new LinearLayout.LayoutParams(-1,dp(66));rlp.setMargins(0,0,0,dp(6));list.addView(row,rlp);}});}public void err(String e){runOnUiThread(()->{list.removeAllViews();TextView er=t("Não foi possível carregar os dispositivos.",13);er.setTextColor(0xffff7d84);er.setGravity(Gravity.CENTER);er.setFocusable(false);list.addView(er,new LinearLayout.LayoutParams(-1,dp(72)));});}});}
 void plans(){
  plansScreen=true;planFlowStage=0;if(pixTimer!=null){try{pixTimer.cancel();}catch(Exception ignored){}pixTimer=null;}clear();setNav(4);if(navBar!=null)navBar.setVisibility(View.GONE);
  LinearLayout h=new LinearLayout(this);h.setGravity(Gravity.CENTER_VERTICAL);h.setPadding(0,dp(2),0,dp(3));
  TextView back=t("‹",31);back.setTextColor(Color.WHITE);back.setGravity(Gravity.CENTER);back.setPadding(0,0,0,0);back.setOnClickListener(v->profile());h.addView(back,new LinearLayout.LayoutParams(dp(42),dp(48)));
  TextView tt=t("Planos",22);tt.setTypeface(null,1);tt.setPadding(dp(3),0,0,0);tt.setGravity(Gravity.CENTER_VERTICAL);h.addView(tt,new LinearLayout.LayoutParams(0,dp(48),1));body.addView(h,new LinearLayout.LayoutParams(-1,dp(54)));
  TextView intro=t("Escolha o plano que combina com você",12);intro.setTextColor(0xff857d82);intro.setPadding(dp(3),0,0,dp(12));body.addView(intro,new LinearLayout.LayoutParams(-1,dp(32)));
  LinearLayout loading=planLoadingState();body.addView(loading,new LinearLayout.LayoutParams(-1,-2));
  Api.post("subscription_package",Api.m("user_id",uid,"reseller_code",reseller),new Api.CB(){public void ok(JSONObject j){runOnUiThread(()->{if(loading.getParent()!=null)body.removeView(loading);JSONArray a=j.optJSONArray("result");if(a==null||a.length()==0){LinearLayout empty=planEmptyState("Nenhum plano disponível","Sua revenda ainda não publicou planos para esta conta.");body.addView(empty,new LinearLayout.LayoutParams(-1,-2));return;}for(int i=0;i<a.length();i++){JSONObject plan=a.optJSONObject(i);if(plan!=null)renderPlanCard(plan);}});}public void err(String x){runOnUiThread(()->{if(loading.getParent()!=null)body.removeView(loading);LinearLayout error=planEmptyState("Não foi possível carregar os planos",x==null||x.isEmpty()?"Verifique sua conexão e tente novamente.":x);body.addView(error,new LinearLayout.LayoutParams(-1,-2));});}});
 }
 LinearLayout planLoadingState(){
  LinearLayout wrap=new LinearLayout(this);wrap.setOrientation(LinearLayout.VERTICAL);wrap.setPadding(0,dp(6),0,dp(16));
  LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);head.setPadding(dp(14),dp(11),dp(14),dp(11));GradientDrawable hb=round(0xff171013,14);hb.setStroke(dp(1),0xff2b1d24);head.setBackground(hb);ProgressBar spin=new ProgressBar(this);if(android.os.Build.VERSION.SDK_INT>=21)spin.setIndeterminateTintList(android.content.res.ColorStateList.valueOf(GREEN));head.addView(spin,new LinearLayout.LayoutParams(dp(24),dp(24)));LinearLayout ht=new LinearLayout(this);ht.setOrientation(LinearLayout.VERTICAL);ht.setPadding(dp(11),0,0,0);TextView a=t("Preparando seus planos",13);a.setTypeface(null,1);a.setTextColor(0xffe4d6df);a.setPadding(0,0,0,dp(1));ht.addView(a);TextView b=t("Buscando preços e benefícios atualizados",10);b.setTextColor(0xff80787d);b.setPadding(0,0,0,0);ht.addView(b);head.addView(ht,new LinearLayout.LayoutParams(0,-2,1));wrap.addView(head,new LinearLayout.LayoutParams(-1,dp(62)));
  for(int i=0;i<2;i++){LinearLayout sk=new LinearLayout(this);sk.setOrientation(LinearLayout.VERTICAL);sk.setPadding(dp(14),dp(13),dp(14),dp(13));GradientDrawable sg=round(0xff161013,16);sg.setStroke(dp(1),0xff291c22);sk.setBackground(sg);View l1=new View(this);l1.setBackground(round(0xff2b2026,6));sk.addView(l1,new LinearLayout.LayoutParams(i==0?dp(150):dp(125),dp(17)));LinearLayout chips=new LinearLayout(this);chips.setPadding(0,dp(11),0,dp(10));for(int j=0;j<3;j++){View c=new View(this);c.setBackground(round(0xff251b20,8));LinearLayout.LayoutParams cl=new LinearLayout.LayoutParams(dp(64),dp(24));if(j>0)cl.setMargins(dp(7),0,0,0);chips.addView(c,cl);}sk.addView(chips);for(int j=0;j<3;j++){View line=new View(this);line.setBackground(round(0xff21181c,4));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(j==2?dp(190):-1,dp(11));lp.setMargins(0,0,0,dp(9));sk.addView(line,lp);}View btn=new View(this);btn.setBackground(round(0xff2b1b23,11));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(42));bp.setMargins(0,dp(4),0,0);sk.addView(btn,bp);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.setMargins(0,dp(10),0,0);wrap.addView(sk,sp);android.animation.ObjectAnimator pulse=android.animation.ObjectAnimator.ofFloat(sk,"alpha",.62f,1f);pulse.setDuration(850);pulse.setRepeatMode(android.animation.ValueAnimator.REVERSE);pulse.setRepeatCount(android.animation.ValueAnimator.INFINITE);pulse.start();}
  return wrap;
 }
 LinearLayout planEmptyState(String title,String message){
  LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setGravity(Gravity.CENTER);c.setPadding(dp(20),dp(48),dp(20),dp(48));TextView icon=t("◌",28);icon.setTextColor(GREEN);icon.setGravity(Gravity.CENTER);c.addView(icon,new LinearLayout.LayoutParams(-1,dp(42)));TextView a=t(title,16);a.setTypeface(null,1);a.setGravity(Gravity.CENTER);a.setPadding(0,dp(4),0,dp(4));c.addView(a);TextView b=t(message,11);b.setTextColor(0xff8c8489);b.setGravity(Gravity.CENTER);b.setPadding(dp(16),0,dp(16),0);c.addView(b);return c;
 }
 String cleanPlanEmoji(String raw){if(raw==null)return "";String s=raw.trim();if(s.isEmpty())return "";if(s.matches("\\?{2,}"))return "";return s.replaceAll("\\?{3,}","").trim();}
 String cleanPlanFeature(String raw){if(raw==null)return "";return raw.trim().replaceAll("\\?{3,}","").trim();}
 void renderPlanCard(JSONObject p){
  boolean featured=p.optInt("featured",0)==1;LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(15),dp(13),dp(15),dp(13));GradientDrawable bg=new GradientDrawable();bg.setColor(0xff111816);bg.setCornerRadius(dp(18));bg.setStroke(dp(1),featured?0xffdc2b84:0xff32262c);card.setBackground(bg);if(android.os.Build.VERSION.SDK_INT>=21)card.setElevation(dp(1));
  LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);TextView name=t(p.optString("name","Plano"),17);name.setTypeface(null,1);name.setTextColor(0xfff4f7f5);name.setPadding(0,0,dp(8),0);top.addView(name,new LinearLayout.LayoutParams(0,dp(34),1));TextView price=t("R$ "+planPrice(p),17);price.setTypeface(null,1);price.setTextColor(featured?GREEN:0xfff0f4f2);price.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);top.addView(price,new LinearLayout.LayoutParams(-2,dp(34)));card.addView(top);
  int days=Math.max(1,p.optInt("days",p.optInt("time",1))),sc=Math.max(1,p.optInt("screens",1));LinearLayout chips=new LinearLayout(this);chips.setGravity(Gravity.CENTER_VERTICAL);TextView d=planMiniChip(days+(days==1?" dia":" dias"));chips.addView(d,new LinearLayout.LayoutParams(-2,dp(26)));TextView scr=planMiniChip(sc+(sc==1?" tela":" telas"));LinearLayout.LayoutParams slp=new LinearLayout.LayoutParams(-2,dp(26));slp.setMargins(dp(6),0,0,0);chips.addView(scr,slp);String badge=p.optString("badge","").trim();if(featured&&badge.isEmpty())badge="RECOMENDADO";if(!badge.isEmpty()){TextView b=planMiniChip(badge.toUpperCase(java.util.Locale.ROOT));b.setTextColor(GREEN);LinearLayout.LayoutParams bl=new LinearLayout.LayoutParams(-2,dp(26));bl.setMargins(dp(6),0,0,0);chips.addView(b,bl);}LinearLayout.LayoutParams chipsLp=new LinearLayout.LayoutParams(-1,dp(34));chipsLp.setMargins(0,dp(1),0,dp(6));card.addView(chips,chipsLp);
  JSONArray features=p.optJSONArray("features");int shown=0,total=0;if(features!=null){for(int i=0;i<features.length();i++){String f=cleanPlanFeature(features.optString(i,""));if(!f.isEmpty())total++;}for(int i=0;i<features.length()&&shown<4;i++){String f=cleanPlanFeature(features.optString(i,""));if(f.isEmpty())continue;TextView row=t("✓  "+f,11);row.setTextColor(0xffc2b6be);row.setPadding(0,dp(1),0,dp(1));card.addView(row,new LinearLayout.LayoutParams(-1,dp(24)));shown++;}}if(total>shown){TextView more=t("+ "+(total-shown)+" "+((total-shown)==1?"benefício":"benefícios"),10);more.setTextColor(0xff827a7f);more.setPadding(dp(16),0,0,dp(1));card.addView(more,new LinearLayout.LayoutParams(-1,dp(21)));}
  TextView buy=t("Escolher plano",13);buy.setTypeface(null,1);buy.setGravity(Gravity.CENTER);buy.setTextColor(0xff11040a);GradientDrawable buyBg=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0xffdf2280,0xffe94999});buyBg.setCornerRadius(dp(12));buy.setBackground(buyBg);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(46));bp.setMargins(0,dp(10),0,0);card.addView(buy,bp);buy.setOnClickListener(v->showPlanSummary(p));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,0,0,dp(10));body.addView(card,cp);if(tvMode)prepareTvFocusTree(card);
 }
 TextView planMiniChip(String text){TextView v=t(text,9);v.setTextColor(0xffa99fa6);v.setGravity(Gravity.CENTER);v.setPadding(dp(9),0,dp(9),0);GradientDrawable g=round(0xff241b20,9);g.setStroke(dp(1),0xff352a30);v.setBackground(g);return v;}
 void planFlowHeader(LinearLayout host,String titleText,Runnable backAction){
  LinearLayout h=new LinearLayout(this);h.setGravity(Gravity.CENTER_VERTICAL);h.setPadding(0,dp(3),0,dp(9));TextView back=t("‹",31);back.setTextColor(0xfff4e5ef);back.setGravity(Gravity.CENTER);back.setPadding(0,0,0,0);back.setOnClickListener(v->{if(backAction!=null)backAction.run();});h.addView(back,new LinearLayout.LayoutParams(dp(42),dp(48)));TextView title=t(titleText,22);title.setTypeface(null,1);title.setPadding(dp(4),0,0,0);title.setGravity(Gravity.CENTER_VERTICAL);h.addView(title,new LinearLayout.LayoutParams(0,dp(48),1));host.addView(h,new LinearLayout.LayoutParams(-1,dp(58)));
 }
 TextView planChip(String text){TextView v=t(text,11);v.setTypeface(null,1);v.setGravity(Gravity.CENTER);v.setTextColor(GREEN);v.setPadding(dp(10),0,dp(10),0);GradientDrawable g=round(0x22d81777,14);g.setStroke(dp(1),0x55de3087);v.setBackground(g);return v;}
 void summaryRow(LinearLayout card,String icon,String label,String value,boolean positive){
  LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);TextView ic=t(icon,12);ic.setTextColor(positive?GREEN:0xff7d767a);ic.setGravity(Gravity.CENTER);ic.setPadding(0,0,0,0);row.addView(ic,new LinearLayout.LayoutParams(dp(28),dp(38)));TextView l=t(label,12);l.setTextColor(0xffa89ea5);l.setPadding(dp(3),0,dp(8),0);row.addView(l,new LinearLayout.LayoutParams(0,dp(38),1));TextView val=t(value,12);val.setTypeface(null,1);val.setTextColor(positive?GREEN:0xfff2e3ed);val.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);val.setPadding(dp(8),0,0,0);row.addView(val,new LinearLayout.LayoutParams(-2,dp(38)));card.addView(row);View line=new View(this);line.setBackgroundColor(0xff2b2226);card.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));
 }
 String planPrice(JSONObject p){String v=p.optString("price_formatted","").trim();if(v.isEmpty())v=String.format(java.util.Locale.US,"%.2f",p.optDouble("price",0)).replace('.',',');return v;}
 String planValidUntil(JSONObject p){int days=Math.max(1,p.optInt("days",p.optInt("time",1)));java.util.Calendar c=java.util.Calendar.getInstance();c.add(java.util.Calendar.DAY_OF_YEAR,days);return new java.text.SimpleDateFormat("dd/MM/yyyy",java.util.Locale.getDefault()).format(c.getTime());}
 void showPlanSummary(JSONObject p){
  plansScreen=true;planFlowStage=1;if(navBar!=null)navBar.setVisibility(View.GONE);clear();LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setPadding(dp(2),0,dp(2),dp(10));page.setMinimumHeight(Math.max(dp(570),getResources().getDisplayMetrics().heightPixels-dp(125)));body.addView(page,new LinearLayout.LayoutParams(-1,-2));planFlowHeader(page,"Resumo do plano",()->plans());
  LinearLayout chosen=new LinearLayout(this);chosen.setGravity(Gravity.CENTER_VERTICAL);chosen.setPadding(dp(14),dp(11),dp(14),dp(11));GradientDrawable chosenBg=round(0xff191115,18);chosenBg.setStroke(dp(1),0xff362930);chosen.setBackground(chosenBg);TextView icon=t("✓",16);icon.setTypeface(null,1);icon.setGravity(Gravity.CENTER);icon.setTextColor(0xff11030a);GradientDrawable iconBg=round(GREEN,20);icon.setBackground(iconBg);chosen.addView(icon,new LinearLayout.LayoutParams(dp(40),dp(40)));LinearLayout texts=new LinearLayout(this);texts.setOrientation(LinearLayout.VERTICAL);texts.setPadding(dp(12),0,dp(6),0);TextView cap=t("PLANO SELECIONADO",9);cap.setLetterSpacing(.12f);cap.setTextColor(0xff80787d);cap.setPadding(0,0,0,dp(2));texts.addView(cap);TextView nm=t(p.optString("name","Plano"),16);nm.setTypeface(null,1);texts.addView(nm);chosen.addView(texts,new LinearLayout.LayoutParams(0,-2,1));TextView pr=t("R$ "+planPrice(p),16);pr.setTypeface(null,1);pr.setTextColor(GREEN);pr.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);chosen.addView(pr,new LinearLayout.LayoutParams(-2,dp(44)));LinearLayout.LayoutParams chlp=new LinearLayout.LayoutParams(-1,-2);chlp.setMargins(0,0,0,dp(11));page.addView(chosen,chlp);
  LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(dp(13),dp(7),dp(13),dp(7));GradientDrawable ib=round(0xff171013,17);ib.setStroke(dp(1),0xff32262c);info.setBackground(ib);int days=Math.max(1,p.optInt("days",p.optInt("time",1))),screens=Math.max(1,p.optInt("screens",1));summaryRow(info,"•","Valor","R$ "+planPrice(p),false);summaryRow(info,"◷","Duração",days+(days==1?" dia":" dias"),false);summaryRow(info,"▣","Telas simultâneas",screens+(screens==1?" tela":" telas"),false);summaryRow(info,"✓","Ativação","Após confirmação do PIX",true);JSONArray fs=p.optJSONArray("features");if(fs!=null){for(int i=0;i<fs.length();i++){String f=cleanPlanFeature(fs.optString(i,""));if(f.isEmpty())continue;summaryRow(info,"✓",f,"Incluído",true);}}page.addView(info,new LinearLayout.LayoutParams(-1,-2));TextView safe=t("Pagamento via PIX com confirmação automática",10);safe.setTextColor(0xff80787d);safe.setGravity(Gravity.CENTER);safe.setPadding(0,dp(10),0,0);page.addView(safe);
  Space flex=new Space(this);page.addView(flex,new LinearLayout.LayoutParams(1,0,1));TextView go=t("Continuar para pagamento",14);go.setTypeface(null,1);go.setGravity(Gravity.CENTER);go.setTextColor(0xff11040a);GradientDrawable gb=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0xffdf2280,0xffea4d9b});gb.setCornerRadius(dp(14));go.setBackground(gb);LinearLayout.LayoutParams glp=new LinearLayout.LayoutParams(-1,dp(52));glp.setMargins(0,dp(14),0,dp(2));page.addView(go,glp);go.setOnClickListener(v->showGeneratingPayment(p));if(tvMode){prepareTvFocusTree(page);requestTvFocus(go);}
 }
 void showGeneratingPayment(JSONObject p){
  plansScreen=true;planFlowStage=2;if(navBar!=null)navBar.setVisibility(View.GONE);clear();final int gen=viewGen;LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setGravity(Gravity.CENTER);page.setPadding(dp(26),dp(20),dp(26),dp(20));page.setMinimumHeight(Math.max(dp(560),getResources().getDisplayMetrics().heightPixels-dp(110)));LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setGravity(Gravity.CENTER_HORIZONTAL);card.setPadding(dp(24),dp(26),dp(24),dp(24));GradientDrawable cb=round(0xff191115,22);cb.setStroke(dp(1),0xff34262d);card.setBackground(cb);if(android.os.Build.VERSION.SDK_INT>=21)card.setElevation(dp(2));TextView seal=t("✓",18);seal.setTypeface(null,1);seal.setGravity(Gravity.CENTER);seal.setTextColor(0xff11030a);seal.setBackground(round(GREEN,23));card.addView(seal,new LinearLayout.LayoutParams(dp(46),dp(46)));TextView title=t("Preparando seu PIX",19);title.setTypeface(null,1);title.setGravity(Gravity.CENTER);title.setPadding(0,dp(15),0,dp(4));card.addView(title);TextView sub=t("Estamos criando uma cobrança segura para "+p.optString("name","seu plano")+".",11);sub.setTextColor(0xff8c8489);sub.setGravity(Gravity.CENTER);sub.setPadding(dp(8),0,dp(8),dp(16));card.addView(sub);ProgressBar bar=new ProgressBar(this);if(android.os.Build.VERSION.SDK_INT>=21)bar.setIndeterminateTintList(android.content.res.ColorStateList.valueOf(GREEN));card.addView(bar,new LinearLayout.LayoutParams(dp(34),dp(34)));TextView stage=t("Validando os dados do plano…",11);stage.setTextColor(0xffb8adb4);stage.setGravity(Gravity.CENTER);stage.setPadding(0,dp(13),0,dp(2));card.addView(stage);TextView hint=t("Isso normalmente leva poucos segundos.",9);hint.setTextColor(0xff70696e);hint.setGravity(Gravity.CENTER);card.addView(hint);page.addView(card,new LinearLayout.LayoutParams(-1,-2));body.addView(page,new LinearLayout.LayoutParams(-1,-2));new Handler(Looper.getMainLooper()).postDelayed(()->{if(gen==viewGen)stage.setText("Gerando QR Code e código PIX…");},750);createCheckout(p);
 }
 String firstNonEmpty(JSONObject o,String...keys){if(o==null)return "";for(String k:keys){String v=o.optString(k,"").trim();if(!v.isEmpty()&&!v.equalsIgnoreCase("null"))return v;}return "";}
 void createCheckout(JSONObject p){
  Api.post("create_checkout",Api.m("user_id",uid,"package_id",p.optString("id"),"reseller_code",reseller),new Api.CB(){public void ok(JSONObject j){JSONArray a=j.optJSONArray("result");JSONObject r=(a!=null&&a.length()>0)?a.optJSONObject(0):null;if(r==null){runOnUiThread(()->{showAppNotice(j.optString("message","Não foi possível gerar o PIX."),true);showPlanSummary(p);});return;}runOnUiThread(()->showPixDialog(p,r));}public void err(String x){runOnUiThread(()->{showAppNotice(x==null||x.isEmpty()?"Não foi possível gerar o PIX.":x,true);showPlanSummary(p);});}});
 }
 android.graphics.Bitmap qrBitmap(String raw){try{if(raw==null||raw.trim().isEmpty())return null;String v=raw.trim();int comma=v.indexOf(',');if(comma>=0)v=v.substring(comma+1);byte[] b=android.util.Base64.decode(v,android.util.Base64.DEFAULT);return android.graphics.BitmapFactory.decodeByteArray(b,0,b.length);}catch(Exception e){return null;}}
 void showPixDialog(JSONObject p,JSONObject r){
  plansScreen=true;planFlowStage=3;if(navBar!=null)navBar.setVisibility(View.GONE);if(pixTimer!=null){try{pixTimer.cancel();}catch(Exception ignored){}}clear();final int gen=viewGen;LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setPadding(dp(2),0,dp(2),dp(12));body.addView(page,new LinearLayout.LayoutParams(-1,-2));planFlowHeader(page,"Pagamento PIX",()->{if(pixTimer!=null)pixTimer.cancel();plans();});
  TextView mini=t("TOTAL A PAGAR",9);mini.setLetterSpacing(.12f);mini.setGravity(Gravity.CENTER);mini.setTextColor(0xff80787d);mini.setPadding(0,0,0,dp(1));page.addView(mini);TextView amount=t("R$ "+planPrice(p),29);amount.setGravity(Gravity.CENTER);amount.setTypeface(null,1);amount.setPadding(0,0,0,dp(6));page.addView(amount);int days=Math.max(1,p.optInt("days",p.optInt("time",1)));TextView chip=planChip(p.optString("name","Plano")+"  •  "+days+(days==1?" dia":" dias"));LinearLayout.LayoutParams chipLp=new LinearLayout.LayoutParams(-2,dp(30));chipLp.gravity=Gravity.CENTER_HORIZONTAL;chipLp.setMargins(0,0,0,dp(13));page.addView(chip,chipLp);
  String pix=firstNonEmpty(r,"pix_copy_paste","copyPaste","copy_paste","pix");String sale=r.optString("transaction_id","");String qr64=firstNonEmpty(r,"qr_code_base64","qrCodeBase64");String qrUrl=firstNonEmpty(r,"qr_code_url","qrcodeUrl");
  LinearLayout qrCard=new LinearLayout(this);qrCard.setOrientation(LinearLayout.VERTICAL);qrCard.setGravity(Gravity.CENTER_HORIZONTAL);qrCard.setPadding(dp(14),dp(12),dp(14),dp(12));qrCard.setBackground(round(Color.WHITE,20));if(android.os.Build.VERSION.SDK_INT>=21)qrCard.setElevation(dp(3));TextView countdown=t("Expira em 15:00",10);countdown.setTextColor(0xffaa6d18);countdown.setGravity(Gravity.CENTER);countdown.setPadding(dp(10),dp(4),dp(10),dp(4));GradientDrawable cdbg=round(0xfffff5e6,12);cdbg.setStroke(dp(1),0xffffdfad);countdown.setBackground(cdbg);qrCard.addView(countdown,new LinearLayout.LayoutParams(-2,dp(28)));ImageView qr=new ImageView(this);qr.setScaleType(ImageView.ScaleType.FIT_CENTER);android.graphics.Bitmap bm=qrBitmap(qr64);if(bm!=null)qr.setImageBitmap(bm);else if(!qrUrl.isEmpty())Img.load(qr,qrUrl);LinearLayout.LayoutParams qlp=new LinearLayout.LayoutParams(dp(196),dp(196));qlp.setMargins(0,dp(8),0,dp(4));qrCard.addView(qr,qlp);TextView secure=t("✓  Ambiente de pagamento seguro",10);secure.setTextColor(0xff7f2f57);secure.setTypeface(null,1);secure.setGravity(Gravity.CENTER);qrCard.addView(secure,new LinearLayout.LayoutParams(-1,dp(28)));LinearLayout.LayoutParams qcardLp=new LinearLayout.LayoutParams(-1,-2);qcardLp.setMargins(dp(32),0,dp(32),dp(12));page.addView(qrCard,qcardLp);
  TextView help=t("Abra seu banco, escolha PIX e escaneie o QR Code. Se preferir, copie o código abaixo.",10);help.setTextColor(0xffa2989f);help.setPadding(dp(14),dp(11),dp(14),dp(11));help.setBackground(round(0xff171013,13));LinearLayout.LayoutParams hlp=new LinearLayout.LayoutParams(-1,-2);hlp.setMargins(0,0,0,dp(10));page.addView(help,hlp);
  TextView copy=t("Copiar código PIX",14);copy.setTypeface(null,1);copy.setGravity(Gravity.CENTER);copy.setTextColor(0xff11040a);GradientDrawable copyBg=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0xffdf2280,0xffea4d9b});copyBg.setCornerRadius(dp(14));copy.setBackground(copyBg);page.addView(copy,new LinearLayout.LayoutParams(-1,dp(50)));
  LinearLayout statusCard=new LinearLayout(this);statusCard.setOrientation(LinearLayout.VERTICAL);statusCard.setPadding(dp(14),dp(11),dp(14),dp(11));statusCard.setBackground(round(0xff171013,13));LinearLayout stateRow=new LinearLayout(this);stateRow.setGravity(Gravity.CENTER_VERTICAL);ProgressBar statusSpin=new ProgressBar(this);if(android.os.Build.VERSION.SDK_INT>=21)statusSpin.setIndeterminateTintList(android.content.res.ColorStateList.valueOf(GREEN));stateRow.addView(statusSpin,new LinearLayout.LayoutParams(dp(18),dp(18)));TextView state=t("Aguardando confirmação",12);state.setTextColor(0xffe7d9e2);state.setTypeface(null,1);state.setPadding(dp(10),0,0,0);stateRow.addView(state,new LinearLayout.LayoutParams(0,dp(28),1));statusCard.addView(stateRow);TextView auto=t("A confirmação é automática. Você pode permanecer nesta tela.",9);auto.setTextColor(0xff827a7f);auto.setPadding(dp(28),dp(1),0,0);statusCard.addView(auto);LinearLayout.LayoutParams stlp=new LinearLayout.LayoutParams(-1,-2);stlp.setMargins(0,dp(10),0,0);page.addView(statusCard,stlp);
  copy.setOnClickListener(v->{if(pix.isEmpty())return;((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(android.content.ClipData.newPlainText("PIX",pix));showCopyConfirmation();});long seconds=Math.max(60,r.optLong("auto_check_seconds",900));pixTimer=new android.os.CountDownTimer(seconds*1000L,1000L){public void onTick(long ms){if(gen!=viewGen){cancel();return;}long sec=ms/1000L;countdown.setText(String.format(java.util.Locale.ROOT,"Expira em %02d:%02d",sec/60,sec%60));}public void onFinish(){if(gen==viewGen){countdown.setText("PIX expirado");statusSpin.setVisibility(View.GONE);state.setText("Pagamento não confirmado");auto.setText("Volte aos planos para gerar um novo PIX.");}}};pixTimer.start();pollCheckoutScreen(p,sale,state,auto,statusSpin,gen);
 }
 void showCopyConfirmation(){Toast toast=new Toast(this);TextView v=t("✓  Código PIX copiado",12);v.setTextColor(0xfff5e6f0);v.setTypeface(null,1);v.setGravity(Gravity.CENTER);v.setPadding(dp(16),dp(10),dp(16),dp(10));GradientDrawable bg=round(0xff22171c,18);bg.setStroke(dp(1),0xff442a37);v.setBackground(bg);toast.setView(v);toast.setDuration(Toast.LENGTH_SHORT);toast.setGravity(Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL,0,dp(74));toast.show();}
 void pollCheckoutScreen(JSONObject p,String sale,TextView state,TextView auto,ProgressBar statusSpin,int gen){
  if(gen!=viewGen)return;if(sale==null||sale.trim().isEmpty()){state.setText("Identificador da transação indisponível");auto.setText("Gere um novo PIX para continuar.");return;}Api.post("check_checkout",Api.m("user_id",uid,"transaction_id",sale),new Api.CB(){public void ok(JSONObject j){if(gen!=viewGen)return;JSONArray a=j.optJSONArray("result");JSONObject r=(a!=null&&a.length()>0)?a.optJSONObject(0):null;boolean paid=r!=null&&(r.optInt("paid",0)==1||r.optInt("activated",0)==1);String st=r==null?"PENDENTE":r.optString("payment_status","PENDENTE");if(paid){if(pixTimer!=null){try{pixTimer.cancel();}catch(Exception ignored){}}runOnUiThread(()->{statusSpin.setVisibility(View.GONE);state.setTextColor(GREEN);state.setText("Pagamento confirmado");auto.setText("Ativando sua assinatura…");refreshEntitlements(()->new Handler(Looper.getMainLooper()).postDelayed(()->{if(gen!=viewGen)return;showAppNotice("Assinatura ativada com sucesso!",false);profile();},700));});return;}runOnUiThread(()->{state.setText("PENDENTE".equalsIgnoreCase(st)?"Aguardando confirmação":"Status: "+st);auto.setText("A confirmação é automática. Você pode permanecer nesta tela.");});new Handler(Looper.getMainLooper()).postDelayed(()->pollCheckoutScreen(p,sale,state,auto,statusSpin,gen),4500);}public void err(String x){if(gen!=viewGen)return;runOnUiThread(()->{state.setText("Reconectando…");auto.setText("Tentando consultar o pagamento novamente.");});new Handler(Looper.getMainLooper()).postDelayed(()->pollCheckoutScreen(p,sale,state,auto,statusSpin,gen),5500);}});
 }
 void dismissAccessExpiredOverlay(){
  if(accessExpiredOverlay==null)return;try{ViewParent p=accessExpiredOverlay.getParent();if(p instanceof ViewGroup)((ViewGroup)p).removeView(accessExpiredOverlay);}catch(Exception ignored){}accessExpiredOverlay=null;
 }
 void showAccessExpiredDialog(String backendMessage){
  JSONObject st=readCachedAccessStatus();boolean trial=isTrialAccessStatus(st);if(st==null){String raw=backendMessage==null?"":backendMessage.trim().toLowerCase(java.util.Locale.ROOT);trial=raw.contains("teste")||raw.contains("trial");}
  String titleText=trial?"Teste expirado":"Acesso expirado";String messageText=trial?"Seu teste terminou. Escolha um plano para continuar assistindo.":"Sua assinatura venceu. Renove seu plano para continuar assistindo.";
  dismissAccessExpiredOverlay();if(root==null)return;ViewParent rp=root.getParent();if(!(rp instanceof FrameLayout)){showAppNotice(messageText,true);return;}FrameLayout host=(FrameLayout)rp;
  FrameLayout overlay=new FrameLayout(this);overlay.setClickable(true);overlay.setFocusable(true);overlay.setBackgroundColor(0xe9000000);accessExpiredOverlay=overlay;
  LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setGravity(Gravity.CENTER_HORIZONTAL);content.setPadding(dp(8),dp(10),dp(8),dp(10));
  View accent=new View(this);accent.setBackground(round(GREEN,4));LinearLayout.LayoutParams alp=new LinearLayout.LayoutParams(dp(46),dp(4));alp.setMargins(0,0,0,dp(18));content.addView(accent,alp);
  TextView title=t(titleText,24);title.setTypeface(null,1);title.setGravity(Gravity.CENTER);title.setSingleLine(false);content.addView(title,new LinearLayout.LayoutParams(-1,-2));
  TextView msg=t(messageText,14);msg.setTextColor(0xffb7acb3);msg.setGravity(Gravity.CENTER);msg.setSingleLine(false);msg.setLineSpacing(dp(2),1.08f);LinearLayout.LayoutParams mlp=new LinearLayout.LayoutParams(-1,-2);mlp.setMargins(dp(8),dp(10),dp(8),dp(24));content.addView(msg,mlp);
  TextView subscribe=t(trial?"Ver planos":"Renovar assinatura",16);subscribe.setTypeface(null,1);subscribe.setGravity(Gravity.CENTER);subscribe.setTextColor(0xff11060c);GradientDrawable sb=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{GREEN,0xffe84b9a});sb.setCornerRadius(dp(28));subscribe.setBackground(sb);LinearLayout.LayoutParams slp=new LinearLayout.LayoutParams(-1,dp(54));slp.setMargins(dp(12),0,dp(12),0);content.addView(subscribe,slp);
  TextView later=t("Agora não",14);later.setTypeface(null,1);later.setGravity(Gravity.CENTER);later.setTextColor(0xffb2a7ae);later.setBackgroundColor(Color.TRANSPARENT);LinearLayout.LayoutParams llp=new LinearLayout.LayoutParams(-1,dp(46));llp.setMargins(dp(12),dp(6),dp(12),0);content.addView(later,llp);
  int sw=getResources().getDisplayMetrics().widthPixels;int cw=Math.min(sw-dp(52),dp(tvMode?520:360));FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(cw,-2,Gravity.CENTER);overlay.addView(content,cp);host.addView(overlay,new FrameLayout.LayoutParams(-1,-1));
  subscribe.setOnClickListener(v->{dismissAccessExpiredOverlay();plans();});later.setOnClickListener(v->dismissAccessExpiredOverlay());overlay.setOnClickListener(v->{});if(tvMode){prepareTvFocusTree(content);requestTvFocus(subscribe);}
 }

 boolean isTrialAccessStatus(JSONObject st){if(st==null)return false;String plan=planNameFrom(st).trim().toLowerCase(java.util.Locale.ROOT);if(!plan.isEmpty()&&!plan.contains("teste")&&!plan.contains("trial")&&!plan.contains("grátis")&&!plan.contains("gratis"))return false;if(st.optInt("is_trial",0)==1||st.optInt("trial_active",0)==1||st.optBoolean("is_trial",false)||st.optBoolean("trial_active",false))return true;String mode=st.optString("mode","").toLowerCase(java.util.Locale.ROOT);return mode.contains("trial")||mode.contains("teste")||plan.contains("teste")||plan.contains("trial");}
 boolean accessDenied(JSONObject st){if(st==null)return false;return !st.optBoolean("allowed",st.optBoolean("active",true));}
 String accessDeniedMessage(JSONObject st){return isTrialAccessStatus(st)?"Seu teste expirou":"Seu acesso expirou";}
 void guardPlaybackAction(Runnable allowedAction){
  if(uid==null||uid.isEmpty()){if(allowedAction!=null)allowedAction.run();return;}
  JSONObject cached=readCachedAccessStatus();if(accessDenied(cached)){showAccessExpiredDialog(accessDeniedMessage(cached));refreshEntitlements(null);return;}
  Api.post("access_status",Api.m("user_id",uid),new Api.CB(){public void ok(JSONObject j){JSONArray a=j.optJSONArray("result");JSONObject st=(a!=null&&a.length()>0)?a.optJSONObject(0):null;if(st!=null){applyEntitlements(st);if(accessDenied(st)){runOnUiThread(()->showAccessExpiredDialog(accessDeniedMessage(st)));return;}}runOnUiThread(allowedAction);}public void err(String e){runOnUiThread(allowedAction);}});
 }
 boolean isAccessExpiredResponse(JSONObject j){if(j==null)return false;int st=j.optInt("status",0);String m=j.optString("message","").toLowerCase(java.util.Locale.ROOT);return st==403||m.contains("teste grátis terminou")||m.contains("teste gratis terminou")||m.contains("teste expirou")||m.contains("acesso expirou")||m.contains("assinatura inativa")||m.contains("assinatura venceu")||m.contains("plano vencido")||m.contains("escolha um plano");}
 boolean blockTamperedPlayback(){if(!SecurityGuard.tamperRisk())return false;showAppNotice("Ambiente de depuração ou instrumentação detectado.",true);return true;}
 void rememberPlayerReturnState(){playerRoundTrip=true;playerReturnScroll=mainScroll;playerReturnBody=body;playerReturnY=mainScroll==null?0:mainScroll.getScrollY();playerReturnNav=currentNavIndex;playerReturnTab=activeHomeTab==null?"":activeHomeTab;}
 void restorePlayerReturnState(){if(!playerRoundTrip)return;playerRoundTrip=false;if(contentFrame!=null&&playerReturnScroll!=null&&playerReturnBody!=null){if(mainScroll!=playerReturnScroll){if(mainScroll!=null&&mainScroll.getParent()==contentFrame)try{contentFrame.removeView(mainScroll);}catch(Exception ignored){}ViewParent pp=playerReturnScroll.getParent();if(pp instanceof ViewGroup&&pp!=contentFrame)((ViewGroup)pp).removeView(playerReturnScroll);mainScroll=playerReturnScroll;body=playerReturnBody;if(playerReturnScroll.getParent()==null)contentFrame.addView(playerReturnScroll,new FrameLayout.LayoutParams(-1,-1));bindScrollTopButton(mainScroll);}activeHomeTab=playerReturnTab==null||playerReturnTab.isEmpty()?activeHomeTab:playerReturnTab;setNav(playerReturnNav);final int y=Math.max(0,playerReturnY);mainScroll.setVisibility(View.VISIBLE);mainScroll.post(()->{if(mainScroll==playerReturnScroll)mainScroll.scrollTo(0,y);});ensureGlobalCastButton();}playerReturnScroll=null;playerReturnBody=null;}
 void launchOnlinePlayer(Intent in){if(blockVpnProtectedContent())return;if(blockTamperedPlayback())return;if(in!=null&&in.getBooleanExtra("preview_mode",false)){in.putExtra("gp_user_id",uid);in.putExtra("gp_device_id",deviceId());rememberPlayerReturnState();startActivity(in);return;}if(in!=null&&!tvMode&&CastHelper.isConnected(this)){String cu=in.getStringExtra("url"),ct=in.getStringExtra("title");boolean cl=in.getBooleanExtra("live",false);if(cu!=null&&!cu.trim().isEmpty()){JSONObject cached=readCachedAccessStatus();if(accessDenied(cached)){showAccessExpiredDialog(accessDeniedMessage(cached));return;}CastHelper.cast(this,cu,ct,cl,null);return;}}String did=deviceId();Api.post("stream_session",Api.m("user_id",uid,"device_id",did,"action","acquire"),new Api.CB(){public void ok(JSONObject j){JSONArray a=j.optJSONArray("result");if(j.optInt("status")!=200||a==null||a.length()==0){runOnUiThread(()->{String m=j.optString("message","Não foi possível iniciar a reprodução.");if(isAccessExpiredResponse(j)){JSONObject cached=readCachedAccessStatus();showAccessExpiredDialog(cached!=null?accessDeniedMessage(cached):m);refreshEntitlements(null);}else showAppNotice(m,true);});return;}runOnUiThread(()->{in.putExtra("gp_user_id",uid);in.putExtra("gp_device_id",did);rememberPlayerReturnState();startActivity(in);});}public void err(String x){runOnUiThread(()->showAppNotice(x==null||x.isEmpty()?"Não foi possível validar o limite de telas.":x,true));}});}
 void addGap(){Space s=new Space(this);root.addView(s,new LinearLayout.LayoutParams(1,dp(10)));}
}

