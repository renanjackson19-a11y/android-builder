package com.greenplay.v5.data.repository;

import android.os.Handler;
import android.os.Looper;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.stream.JsonReader;
import com.greenplay.v5.core.network.HostNormalizer;
import com.greenplay.v5.core.network.NetworkProvider;
import com.greenplay.v5.core.network.XtreamApi;
import com.greenplay.v5.data.model.series.SeriesCategory;
import com.greenplay.v5.data.model.series.SeriesDetails;
import com.greenplay.v5.data.model.series.SeriesEpisode;
import com.greenplay.v5.data.model.series.SeriesItem;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import okhttp3.HttpUrl;
import okhttp3.Request;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public final class SeriesRepository {
    public interface CategoriesResult { void success(List<SeriesCategory> rows); void error(String message); }
    public interface SeriesResult { void success(List<SeriesItem> rows); void error(String message); }
    public interface ProgressiveSeriesResult {
        void partial(List<SeriesItem> rows);
        void success(List<SeriesItem> rows);
        void error(String message);
    }
    public interface DetailResult { void success(SeriesDetails detail); void error(String message); }

    // The complete catalog can contain tens of thousands of series and take a
    // long time to parse. Categories and episode details must never wait in
    // the same single-thread queue behind that job.
    private static final ExecutorService CATALOG_PARSER = Executors.newSingleThreadExecutor();
    private static final ExecutorService FAST_PARSER = Executors.newFixedThreadPool(2);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private final XtreamApi api;
    private final XtreamApi detailApi;
    private final String host;
    private final String user;
    private final String pass;
    private final boolean includeAdult;

    public SeriesRepository(String host, String user, String pass) {
        this(host, user, pass, false);
    }

    public SeriesRepository(String host, String user, String pass, boolean includeAdult) {
        this.host = HostNormalizer.normalize(host);
        this.api = NetworkProvider.xtream(host);
        this.detailApi = NetworkProvider.xtreamDetails(host);
        this.user = user;
        this.pass = pass;
        this.includeAdult = includeAdult;
    }

    public void categories(CategoriesResult result) {
        api.list(user, pass, "get_series_categories").enqueue(new Callback<JsonArray>() {
            @Override public void onResponse(Call<JsonArray> call, Response<JsonArray> response) {
                JsonArray body = response.body();
                if (!response.isSuccessful() || body == null) { result.error("Categorias de séries indisponíveis"); return; }
                FAST_PARSER.execute(() -> {
                    List<SeriesCategory> out = new ArrayList<>();
                    SeriesCategory all = new SeriesCategory(); all.id=""; all.name="TODOS"; out.add(all);
                    for (JsonElement e : body) {
                        if (!e.isJsonObject()) continue;
                        JsonObject o=e.getAsJsonObject();
                        SeriesCategory c=new SeriesCategory();
                        c.id=str(o,"category_id"); c.name=clean(str(o,"category_name"));
                        if (!c.id.isEmpty() && !c.name.isEmpty()) out.add(c);
                    }
                    MAIN.post(() -> result.success(out));
                });
            }
            @Override public void onFailure(Call<JsonArray> call, Throwable t) { result.error("Falha ao carregar categorias de séries"); }
        });
    }

    public void series(String categoryId, SeriesResult result) {
        Call<JsonArray> call = categoryId == null || categoryId.trim().isEmpty()
                ? api.list(user, pass, "get_series")
                : api.listByCategory(user, pass, "get_series", categoryId.trim());
        call.enqueue(new Callback<JsonArray>() {
            @Override public void onResponse(Call<JsonArray> call, Response<JsonArray> response) {
                JsonArray body=response.body();
                if(!response.isSuccessful()||body==null){result.error("Séries indisponíveis");return;}
                CATALOG_PARSER.execute(() -> {
                    List<SeriesItem> out=new ArrayList<>(); Set<Long> ids=new HashSet<>(); Map<String,SeriesItem> grouped=new LinkedHashMap<>();
                    for(JsonElement e:body){if(!e.isJsonObject())continue;JsonObject o=e.getAsJsonObject();if(!includeAdult && boolVal(o,"is_adult"))continue;long id=longVal(o,"series_id");if(id<=0||!ids.add(id))continue;
                        SeriesItem row=new SeriesItem();row.id=id;row.name=clean(first(str(o,"name"),str(o,"title"),"Série"));row.cover=image(first(str(o,"cover"),str(o,"stream_icon")));row.categoryId=str(o,"category_id");row.year=first(str(o,"year"),yearFromDate(str(o,"releaseDate")),yearFromDate(str(o,"release_date")));row.rating=str(o,"rating");row.plot=first(str(o,"plot"),str(o,"description"));row.genre=first(str(o,"genre"),str(o,"genres"));row.isAdult=boolVal(o,"is_adult");row.mediaType=first(str(o,"media_type"),str(o,"mediaType"));row.vodType=first(str(o,"vod_type"),str(o,"vodType"));row.filterType=first(str(o,"filter_type"),str(o,"filterType"));
                        mergeSeries(out,grouped,row);
                    }
                    MAIN.post(() -> result.success(out));
                });
            }
            @Override public void onFailure(Call<JsonArray> call, Throwable t){result.error("Falha ao carregar séries");}
        });
    }


    /** Progressive reader for very large Xtream series catalogs. */
    public void seriesProgressive(String categoryId, int previewStep, int previewLimit, ProgressiveSeriesResult result) {
        final int step = Math.max(24, previewStep);
        final int limit = Math.max(step, previewLimit);
        try {
            HttpUrl base = HttpUrl.get(host + "/player_api.php");
            HttpUrl.Builder ub = base.newBuilder()
                    .addQueryParameter("username", user)
                    .addQueryParameter("password", pass)
                    .addQueryParameter("action", "get_series");
            if (categoryId != null && !categoryId.trim().isEmpty()) ub.addQueryParameter("category_id", categoryId.trim());
            Request request = new Request.Builder().url(ub.build()).get().build();
            NetworkProvider.xtreamHttp().newCall(request).enqueue(new okhttp3.Callback() {
                @Override public void onFailure(okhttp3.Call call, java.io.IOException e) {
                    MAIN.post(() -> result.error("Falha ao carregar séries"));
                }

                @Override public void onResponse(okhttp3.Call call, okhttp3.Response response) {
                    final ResponseBody body = response.body();
                    if (!response.isSuccessful() || body == null) {
                        if (body != null) body.close();
                        response.close();
                        MAIN.post(() -> result.error("Séries indisponíveis"));
                        return;
                    }
                    CATALOG_PARSER.execute(() -> {
                        List<SeriesItem> out = new ArrayList<>();
                        Set<Long> ids = new HashSet<>();
                        Map<String,SeriesItem> grouped = new LinkedHashMap<>();
                        int nextEmit = step;
                        try (ResponseBody ignored = body;
                             JsonReader reader = new JsonReader(new InputStreamReader(body.byteStream(), StandardCharsets.UTF_8))) {
                            reader.beginArray();
                            while (reader.hasNext()) {
                                JsonElement parsed = JsonParser.parseReader(reader);
                                if (parsed == null || !parsed.isJsonObject()) continue;
                                JsonObject o = parsed.getAsJsonObject();
                                if (!includeAdult && boolVal(o, "is_adult")) continue;
                                long id = longVal(o, "series_id");
                                if (id <= 0 || !ids.add(id)) continue;
                                SeriesItem row = new SeriesItem();
                                row.id = id;
                                row.name = clean(first(str(o, "name"), str(o, "title"), "Série"));
                                row.cover = image(first(str(o, "cover"), str(o, "stream_icon")));
                                row.categoryId = str(o, "category_id");
                                row.year = first(str(o, "year"), yearFromDate(str(o, "releaseDate")), yearFromDate(str(o, "release_date")));
                                row.rating = str(o, "rating");
                                row.plot = first(str(o, "plot"), str(o, "description"));
                                row.genre = first(str(o, "genre"), str(o, "genres"));
                                row.isAdult = boolVal(o, "is_adult");
                                row.mediaType = first(str(o, "media_type"), str(o, "mediaType"));
                                row.vodType = first(str(o, "vod_type"), str(o, "vodType"));
                                row.filterType = first(str(o, "filter_type"), str(o, "filterType"));
                                if (!mergeSeries(out, grouped, row)) continue;
                                if (out.size() >= nextEmit && nextEmit <= limit) {
                                    List<SeriesItem> snapshot = new ArrayList<>(out);
                                    MAIN.post(() -> result.partial(snapshot));
                                    nextEmit += step;
                                }
                            }
                            reader.endArray();
                            List<SeriesItem> complete = new ArrayList<>(out);
                            MAIN.post(() -> result.success(complete));
                        } catch (Exception e) {
                            MAIN.post(() -> result.error("Não foi possível ler o catálogo de séries"));
                        } finally {
                            response.close();
                        }
                    });
                }
            });
        } catch (Exception e) {
            MAIN.post(() -> result.error("Falha ao preparar catálogo de séries"));
        }
    }

    public void detail(long seriesId, DetailResult result) {
        detailApi.seriesInfo(user, pass, "get_series_info", seriesId).enqueue(new Callback<JsonObject>() {
            @Override public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                JsonObject body=response.body(); if(!response.isSuccessful()||body==null){result.error("Detalhes da série indisponíveis");return;}
                FAST_PARSER.execute(() -> {
                    SeriesDetails d=new SeriesDetails();
                    JsonObject info=obj(body,"info");
                    d.name=clean(first(str(info,"name"),str(info,"title"),"Série"));
                    d.cover=image(first(str(info,"cover"),str(info,"movie_image"),str(info,"stream_icon")));
                    JsonArray backs=array(info,"backdrop_path"); if(backs!=null&&backs.size()>0) d.backdrop=image(asString(backs.get(0)));
                    d.plot=first(str(info,"plot"),str(info,"description")); d.genre=str(info,"genre"); d.releaseDate=first(str(info,"releaseDate"),str(info,"release_date")); d.rating=str(info,"rating");
                    parseEpisodes(body.get("episodes"), d);
                    Collections.sort(d.episodes, Comparator.comparingInt((SeriesEpisode x)->x.season).thenComparingInt(x->x.episode));
                    MAIN.post(() -> result.success(d));
                });
            }
            @Override public void onFailure(Call<JsonObject> call, Throwable t){result.error("Falha ao carregar temporadas");}
        });
    }

    /** Accepts both the standard season-object and array variants used by XC panels. */
    private void parseEpisodes(JsonElement raw, SeriesDetails d) {
        if (raw == null || raw.isJsonNull()) return;
        if (raw.isJsonObject()) {
            JsonObject groups = raw.getAsJsonObject();
            for (String seasonKey : groups.keySet()) parseEpisodeGroup(groups.get(seasonKey), parseInt(seasonKey, 0), d);
        } else if (raw.isJsonArray()) {
            parseEpisodeGroup(raw, 0, d);
        }
    }

    private void parseEpisodeGroup(JsonElement raw, int seasonHint, SeriesDetails d) {
        if (raw == null || raw.isJsonNull()) return;
        if (raw.isJsonObject()) {
            JsonObject wrapper = raw.getAsJsonObject();
            JsonElement nested = wrapper.get("episodes");
            if (nested == null) nested = wrapper.get("data");
            if (nested != null) parseEpisodeGroup(nested, seasonHint > 0 ? seasonHint : intVal(wrapper, "season_number"), d);
            else parseEpisode(wrapper, seasonHint, d);
            return;
        }
        if (!raw.isJsonArray()) return;
        for (JsonElement ee : raw.getAsJsonArray()) {
            if (ee != null && ee.isJsonArray()) parseEpisodeGroup(ee, seasonHint, d);
            else if (ee != null && ee.isJsonObject()) parseEpisode(ee.getAsJsonObject(), seasonHint, d);
        }
    }

    private void parseEpisode(JsonObject o, int seasonHint, SeriesDetails d) {
        SeriesEpisode ep = new SeriesEpisode();
        ep.id = longVal(o,"id"); if(ep.id<=0)ep.id=longVal(o,"stream_id"); if(ep.id<=0)ep.id=longVal(o,"episode_id");
        if(ep.id<=0)return;
        ep.season=seasonHint>0?seasonHint:intVal(o,"season");if(ep.season<=0)ep.season=intVal(o,"season_number");if(ep.season<=0)ep.season=1;
        ep.episode=intVal(o,"episode_num");if(ep.episode<=0)ep.episode=intVal(o,"episode_number");if(ep.episode<=0)ep.episode=intVal(o,"episode");
        ep.title=clean(first(str(o,"title"),str(o,"name"),"Episódio "+(ep.episode>0?ep.episode:"")));
        ep.extension=first(str(o,"container_extension"),str(o,"container_ext"),"mp4");
        JsonObject ei=obj(o,"info");
        ep.image=image(first(str(ei,"movie_image"),str(ei,"cover_big"),str(ei,"cover"),str(o,"stream_icon")));
        ep.plot=first(str(ei,"plot"),str(ei,"description"),str(o,"plot"));ep.duration=first(str(ei,"duration"),str(ei,"duration_secs"));ep.rating=str(ei,"rating");d.episodes.add(ep);
    }

    /**
     * Some universal Xtream panels publish the same series more than once and
     * only one of those records contains episodes. Resolve all equivalent IDs
     * together and return the first complete response.
     */
    public void bestDetail(long primaryId, long[] alternateIds, DetailResult result) {
        ArrayList<Long> candidates = new ArrayList<>();
        if (primaryId > 0) candidates.add(primaryId);
        if (alternateIds != null) for (long id : alternateIds) if (id > 0 && !candidates.contains(id)) candidates.add(id);
        if (candidates.size() <= 1) { detail(primaryId, result); return; }
        final Object lock = new Object();
        final int total = candidates.size();
        final int[] finished = {0};
        final boolean[] delivered = {false};
        final SeriesDetails[] fallback = {null};
        final String[] lastError = {"Detalhes da série indisponíveis"};
        for (long id : candidates) detail(id, new DetailResult() {
            @Override public void success(SeriesDetails d) {
                synchronized (lock) {
                    if (delivered[0]) return;
                    finished[0]++;
                    if (fallback[0] == null) fallback[0] = d;
                    if (d != null && !d.episodes.isEmpty()) { delivered[0] = true; result.success(d); }
                    else if (finished[0] == total) { delivered[0] = true; result.success(fallback[0] == null ? new SeriesDetails() : fallback[0]); }
                }
            }
            @Override public void error(String message) {
                synchronized (lock) {
                    if (delivered[0]) return;
                    finished[0]++; lastError[0] = message;
                    if (finished[0] == total) {
                        delivered[0] = true;
                        if (fallback[0] != null) result.success(fallback[0]); else result.error(lastError[0]);
                    }
                }
            }
        });
    }

    private static boolean mergeSeries(List<SeriesItem> out, Map<String,SeriesItem> grouped, SeriesItem row) {
        String k = key(row.name, row.year);
        SeriesItem current = grouped.get(k);
        if (current == null || k.isEmpty()) {
            row.alternateIds.add(row.id);
            out.add(row);
            if (!k.isEmpty()) grouped.put(k, row);
            return true;
        }
        if (!current.alternateIds.contains(row.id)) current.alternateIds.add(row.id);
        if (current.cover.isEmpty() && !row.cover.isEmpty()) current.cover = row.cover;
        if (current.rating.isEmpty() && !row.rating.isEmpty()) current.rating = row.rating;
        return false;
    }

    private String image(String raw){if(raw==null)return "";String u=raw.trim().replace("\\/","/").replace(" ","%20");if(u.isEmpty())return "";if(u.startsWith("//"))return(host.startsWith("https://")?"https:":"http:")+u;if(u.startsWith("http://")||u.startsWith("https://"))return u;if(u.startsWith("/"))return host+u;return host+"/"+u;}
    private static JsonObject obj(JsonObject o,String k){try{JsonElement e=o.get(k);return e!=null&&e.isJsonObject()?e.getAsJsonObject():null;}catch(Exception e){return null;}}
    private static JsonArray array(JsonObject o,String k){try{JsonElement e=o.get(k);return e!=null&&e.isJsonArray()?e.getAsJsonArray():null;}catch(Exception e){return null;}}
    private static String str(JsonObject o,String k){try{if(o==null)return "";JsonElement e=o.get(k);return e==null||e.isJsonNull()?"":e.getAsString();}catch(Exception e){return "";}}
    private static long longVal(JsonObject o,String k){try{return o.get(k).getAsLong();}catch(Exception e){return 0L;}}
    private static int intVal(JsonObject o,String k){try{return o.get(k).getAsInt();}catch(Exception e){return 0;}}
    private static int parseInt(String s,int f){try{return Integer.parseInt(s);}catch(Exception e){return f;}}
    private static String asString(JsonElement e){try{return e==null||e.isJsonNull()?"":e.getAsString();}catch(Exception ex){return "";}}
    private static String clean(String s){if(s==null)return "";return s.replace("\\/","/").replace("\n"," ").replace("\r"," ").replaceAll("\\s{2,}"," ").trim();}
    private static String key(String n,String y){
        String name=n==null?"":java.text.Normalizer.normalize(n.toLowerCase(Locale.ROOT),java.text.Normalizer.Form.NFD).replaceAll("\\p{M}+","");
        String year=y==null?"":y.replaceAll("[^0-9]",""); if(year.length()>4)year=year.substring(0,4);
        if(year.isEmpty()){java.util.regex.Matcher m=java.util.regex.Pattern.compile("(?:19|20)\\d{2}").matcher(name);if(m.find())year=m.group();}
        name=name.replaceAll("\\[(?:l|d|4k|fhd|hd)\\]", " ").replaceAll("(?:19|20)\\d{2}"," ").replaceAll("[^a-z0-9]+","").trim();
        // Xtream resellers commonly duplicate the same series with a decorated
        // year/tag in only one record. Group by the cleaned title so an empty
        // primary record can fall back to its populated sibling.
        return name;
    }
    private static String yearFromDate(String raw){if(raw==null)return "";String s=raw.trim();return s.length()>=4?s.substring(0,4):"";}
    private static String first(String...v){if(v!=null)for(String x:v)if(x!=null&&!x.trim().isEmpty())return x.trim();return "";}

    private static boolean boolVal(JsonObject o,String k){
        try{
            JsonElement e=o.get(k); if(e==null||e.isJsonNull())return false;
            if(e.getAsJsonPrimitive().isBoolean())return e.getAsBoolean();
            String v=e.getAsString().trim(); return "1".equals(v)||"true".equalsIgnoreCase(v)||"yes".equalsIgnoreCase(v);
        }catch(Exception e){return false;}
    }
}
