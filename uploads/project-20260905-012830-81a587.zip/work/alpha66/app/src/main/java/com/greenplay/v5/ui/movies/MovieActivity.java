package com.greenplay.v5.ui.movies;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.greenplay.v5.core.catalog.CatalogMemory;
import com.greenplay.v5.core.catalog.CatalogCoverWarmer;
import com.greenplay.v5.core.config.BrandingStore;
import com.greenplay.v5.core.config.BrandingUi;
import com.greenplay.v5.core.config.AppControlStore;
import com.greenplay.v5.core.config.NavConfigUi;
import com.greenplay.v5.core.config.AppNoticeUi;
import com.greenplay.v5.core.config.AppControlSync;
import com.greenplay.v5.core.session.SessionStore;
import com.greenplay.v5.data.model.movie.Movie;
import com.greenplay.v5.data.model.movie.MovieCategory;
import com.greenplay.v5.data.repository.MovieRepository;
import com.greenplay.v5.databinding.ActivityMoviesBinding;
import com.greenplay.v5.ui.series.SeriesActivity;
import com.greenplay.v5.ui.settings.SettingsActivity;
import com.squareup.picasso.Target;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MovieActivity extends AppCompatActivity {
    private static final long AUTO_REFRESH_MS = 60_000L;
    private static final long SEARCH_DEBOUNCE_MS = 220L;
    private static final int PAGE_SIZE = 180;
    private static final int PAGE_PREFETCH_THRESHOLD = 36;

    private ActivityMoviesBinding b;
    private SessionStore session;
    private BrandingStore branding;
    private Target brandingBackgroundTarget;
    private MovieRepository repo;
    private MovieFavoritesStore favorites;
    private MovieCacheStore cache;
    private MovieCategoryAdapter categoryAdapter;
    private MovieAdapter movieAdapter;
    private GridLayoutManager movieGridManager;

    private final List<MovieCategory> rawCategories = new ArrayList<>();
    private volatile List<Movie> allMovies = Collections.emptyList();
    private final List<Movie> filteredMovies = new ArrayList<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService filterExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService cacheExecutor = Executors.newSingleThreadExecutor();

    private String categoryId = "";
    private String categoryName = "TODOS";
    private String searchQuery = "";
    private String specialMode = "";
    private final Set<String> allowedCategoryIds = new HashSet<>();
    private boolean favoriteMode = false;
    private boolean loading = false;
    private boolean filtering = false;
    private long lastRefreshAt = 0L;
    private int movieRequestGeneration = 0;
    private int filterGeneration = 0;
    private int renderedCount = 0;
    private boolean networkCatalogComplete = false;
    private boolean usingNetworkPreview = false;

    private final Runnable autoRefresh = new Runnable() {
        @Override public void run() {
            refresh(false);
            handler.postDelayed(this, AUTO_REFRESH_MS);
        }
    };

    private final Runnable delayedSearch = this::rebuildVisibleAsync;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        b = ActivityMoviesBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        com.greenplay.v5.core.ui.UniversalUi.apply(this, b.getRoot());
        session = new SessionStore(this);
        branding = new BrandingStore(this);
        if (!session.isLogged() || session.host().trim().isEmpty()) { finish(); return; }
        specialMode = normalizeSpecialMode(getIntent().getStringExtra(com.greenplay.v5.core.ui.SpecialSections.EXTRA_MODE));
        repo = new MovieRepository(session.host(), session.user(), session.pass(), com.greenplay.v5.core.ui.SpecialSections.HOT.equals(specialMode));
        favorites = new MovieFavoritesStore(this, session.host(), session.user());
        cache = new MovieCacheStore(this, session.host(), session.user());
        setupLists();
        setupSearch();
        bindTopNav();
        AppNoticeUi.show(this,new AppControlStore(this));
        AppControlSync.refresh(this, ok -> runOnUiThread(() -> { if(ok && !isFinishing()){
            branding=new BrandingStore(this); applyBranding(); applyConfiguredNav(); AppNoticeUi.show(this,new AppControlStore(this));
        }}));
        applyBranding();
        configureSpecialModeUi();
        b.movieFavorites.setVisibility(View.GONE);

        boolean ready = showPreloadedCatalog();
        if (!specialMode.isEmpty()) loadCachedCategoriesOnly();
        if (!ready) loadCachedCatalog();
        // A tela nunca fica esperando o catálogo inteiro: cache/memória aparecem já,
        // enquanto a leitura progressiva atualiza o conteúdo em segundo plano.
        if (ready) {
            if (specialMode.isEmpty()) handler.postDelayed(() -> refresh(false), 8000L);
            else {
                // KIDS/ANIMES must not stay restricted to an old/preloaded category list.
                // Ask the current server for category names immediately, while keeping the
                // already loaded catalog visible for a fast opening.
                loadCategories();
                handler.postDelayed(() -> loadAllMovies(false), 250L);
            }
        } else refresh(true);
        handler.postDelayed(autoRefresh, AUTO_REFRESH_MS);
    }

    private void applyBranding() {
        BrandingUi.applyHeaderBrand(b.brandNameMovies, b.brandLogoMovies, branding);
        brandingBackgroundTarget = BrandingUi.applyBackground(b.getRoot(), branding);
        int accent = BrandingUi.color(branding.accent(), 0xFF29E76F);
        b.movieFavorites.setTextColor(accent);
        if (movieAdapter != null) { String fallback=branding.movieCover(); if(fallback==null||fallback.trim().isEmpty()) fallback=branding.fallback(); movieAdapter.setFallbackPoster(branding.absolute(fallback)); }
    }

    private void setupLists() {
        categoryAdapter = new MovieCategoryAdapter(category -> {
            categoryId = category.id;
            categoryName = category.name;
            favoriteMode = false;
            b.movieFavorites.setSelected(false);
            b.movieFavorites.setText("☆ FAVORITOS");
            categoryAdapter.select(categoryId);
            rebuildVisibleAsync();
        });
        b.movieCategories.setLayoutManager(new LinearLayoutManager(this));
        b.movieCategories.setAdapter(categoryAdapter);
        b.movieCategories.setItemAnimator(null);

        movieAdapter = new MovieAdapter(new MovieAdapter.Listener() {
            @Override public void onOpen(Movie movie) { openDetails(movie); }
            @Override public void onFavorite(Movie movie) {
                favorites.toggle(movie.id);
                if (favoriteMode) rebuildVisibleAsync();
                else movieAdapter.refreshFavorite(movie.id);
            }
            @Override public boolean isFavorite(Movie movie) { return favorites.isFavorite(movie.id); }
        });
        movieGridManager = new GridLayoutManager(this, com.greenplay.v5.core.ui.UniversalUi.catalogSpanCount(this));
        b.movieGrid.setLayoutManager(movieGridManager);
        b.movieGrid.setAdapter(movieAdapter);
        b.movieGrid.setItemAnimator(null);
        b.movieGrid.setHasFixedSize(true);
        b.movieGrid.setItemViewCacheSize(18);
        b.movieGrid.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                if (dy <= 0 || renderedCount >= filteredMovies.size()) return;
                int last = movieGridManager.findLastVisibleItemPosition();
                if (last >= movieAdapter.getItemCount() - PAGE_PREFETCH_THRESHOLD) appendNextPage();
            }
        });
    }

    private void setupSearch() {
        b.movieSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                searchQuery = s == null ? "" : s.toString().trim();
                handler.removeCallbacks(delayedSearch);
                handler.postDelayed(delayedSearch, SEARCH_DEBOUNCE_MS);
            }
            @Override public void afterTextChanged(Editable s) {}
        });
    }

    private void bindTopNav() {
        b.navTv.setOnClickListener(v -> finish());
        b.navFootball.setOnClickListener(v -> startActivity(new Intent(this, com.greenplay.v5.ui.games.GamesActivity.class)));
        b.navMovies.setOnClickListener(v -> {
            if (specialMode.isEmpty()) b.movieSearch.requestFocus();
            else startActivity(new Intent(this, MovieActivity.class));
        });
        b.navSeries.setOnClickListener(v -> startActivity(new Intent(this, SeriesActivity.class)));
        b.navKids.setOnClickListener(v -> com.greenplay.v5.core.ui.SpecialSections.open(this, com.greenplay.v5.core.ui.SpecialSections.KIDS));
        b.navAnime.setOnClickListener(v -> com.greenplay.v5.core.ui.SpecialSections.open(this, com.greenplay.v5.core.ui.SpecialSections.ANIME));
        b.navHot.setOnClickListener(v -> com.greenplay.v5.core.ui.SpecialSections.open(this, com.greenplay.v5.core.ui.SpecialSections.HOT));
        b.movieSettings.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        applyConfiguredNav();
        b.movieFavorites.setOnClickListener(v -> {
            favoriteMode = !favoriteMode;
            b.movieFavorites.setSelected(favoriteMode);
            b.movieFavorites.setText(favoriteMode ? "★ FAVORITOS" : "☆ FAVORITOS");
            if (favoriteMode) {
                categoryId = "";
                categoryName = "FAVORITOS";
                categoryAdapter.select("");
            }
            rebuildVisibleAsync();
        });
    }


    private void applyConfiguredNav(){
        AppControlStore control=new AppControlStore(this);
        NavConfigUi.apply(control,
                NavConfigUi.e("tv",b.navTv,10), NavConfigUi.e("football",b.navFootball,20),
                NavConfigUi.e("movies",b.navMovies,30), NavConfigUi.e("series",b.navSeries,40),
                NavConfigUi.e("kids",b.navKids,50), NavConfigUi.e("anime",b.navAnime,60),
                NavConfigUi.e("hot",b.navHot,70));
        b.movieFavorites.setVisibility(View.GONE);
    }
    /** Uses the fresh catalog prepared before TvActivity opened. No network wait here. */
    private boolean showPreloadedCatalog() {
        if (com.greenplay.v5.core.ui.SpecialSections.HOT.equals(specialMode)) return false;
        List<MovieCategory> preparedCategories = CatalogMemory.movieCategories();
        List<Movie> preparedMovies = CatalogMemory.movies();
        if (preparedCategories.isEmpty() || preparedMovies.isEmpty()) return false;

        allMovies = preparedMovies;
        applyCategoryScope(preparedCategories);
        rebuildVisibleAsync();
        warmMovieArtwork(preparedMovies, true);
        lastRefreshAt = CatalogMemory.updatedAt();
        b.movieLoading.setVisibility(View.GONE);
        b.movieError.setText("");
        return true;
    }


    private void loadCachedCategoriesOnly() {
        cacheAsync(() -> {
            final List<MovieCategory> cachedCategories = cache.categories();
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed() || cachedCategories.isEmpty()) return;
                applyCategoryScope(cachedCategories);
            });
        });
    }

    /** Reads the previous successful catalog off the UI thread for instant opening. */
    private void loadCachedCatalog() {
        if (com.greenplay.v5.core.ui.SpecialSections.HOT.equals(specialMode)) return;
        cacheAsync(() -> {
            final List<MovieCategory> cachedCategories = cache.categories();
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed() || networkCatalogComplete) return;
                if (!cachedCategories.isEmpty() && rawCategories.isEmpty()) {
                    applyCategoryScope(cachedCategories);
                    if (specialMode.isEmpty()) CatalogMemory.setMovieCategories(cachedCategories);
                }
            });

            // Do not hold the lightweight category sidebar until the very
            // large movie cache has finished decoding.
            final List<Movie> cachedMovies = cache.movies();
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed() || networkCatalogComplete) return;
                if (!cachedMovies.isEmpty() && (allMovies.isEmpty() || usingNetworkPreview || cachedMovies.size() > allMovies.size())) {
                    usingNetworkPreview = false;
                    allMovies = cachedMovies;
                    if (specialMode.isEmpty()) CatalogMemory.setMovies(cachedMovies);
                    b.movieLoading.setVisibility(View.GONE);
                    b.movieError.setText("");
                    rebuildVisibleAsync();
                    warmMovieArtwork(cachedMovies, false);
                }
            });
        });
    }

    /**
     * Filters the potentially huge VOD catalog on a worker thread. Only the first
     * page is handed to RecyclerView; following pages are appended while scrolling.
     */
    private void rebuildVisibleAsync() {
        final int generation = ++filterGeneration;
        final List<Movie> snapshot = allMovies;
        final String wantedCategory = categoryId == null ? "" : categoryId;
        final String wantedQuery = searchQuery == null ? "" : searchQuery.toLowerCase(Locale.ROOT);
        final boolean onlyFavorites = favoriteMode;
        final boolean scoped = !specialMode.isEmpty();
        final Set<String> allowedIds = scoped ? new HashSet<>(allowedCategoryIds) : Collections.emptySet();
        final Set<String> favoriteIds = onlyFavorites ? favorites.snapshotIds() : Collections.emptySet();
        filtering = true;
        updateEmpty();

        filterExecutor.execute(() -> {
            ArrayList<Movie> result = new ArrayList<>();
            for (Movie movie : snapshot) {
                if (movie == null) continue;
                if (onlyFavorites && !favoriteIds.contains(String.valueOf(movie.id))) continue;
                if (scoped) {
                    if (allowedIds.isEmpty() || !allowedIds.contains(movie.categoryId)) continue;
                }
                if (!onlyFavorites && !wantedCategory.isEmpty() && !wantedCategory.equals(movie.categoryId)) continue;
                if (!wantedQuery.isEmpty()) {
                    String name = movie.name == null ? "" : movie.name.toLowerCase(Locale.ROOT);
                    if (!name.contains(wantedQuery)) continue;
                }
                result.add(movie);
            }

            runOnUiThread(() -> {
                if (generation != filterGeneration || isFinishing() || isDestroyed()) return;
                filtering = false;
                filteredMovies.clear();
                filteredMovies.addAll(result);
                renderedCount = Math.min(PAGE_SIZE, filteredMovies.size());
                if (renderedCount == 0) {
                    movieAdapter.replace(Collections.emptyList());
                } else {
                    movieAdapter.replace(new ArrayList<>(filteredMovies.subList(0, renderedCount)));
                }
                if (movieGridManager != null) movieGridManager.scrollToPosition(0);
                updateEmpty();
            });
        });
    }

    private void appendNextPage() {
        if (renderedCount >= filteredMovies.size()) return;
        int start = renderedCount;
        int end = Math.min(filteredMovies.size(), start + PAGE_SIZE);
        renderedCount = end;
        movieAdapter.append(new ArrayList<>(filteredMovies.subList(start, end)));
    }

    private void updateEmpty() {
        b.movieEmpty.setVisibility(movieAdapter.getItemCount() == 0 && !loading && !filtering ? View.VISIBLE : View.GONE);
    }

    private void refresh(boolean showSpinner) {
        if (loading) return;
        loadCategories();
        loadAllMovies(showSpinner);
    }

    private void loadCategories() {
        repo.categories(new MovieRepository.CategoriesResult() {
            @Override public void success(List<MovieCategory> rows) {
                applyCategoryScope(rows);
                if (specialMode.isEmpty()) CatalogMemory.setMovieCategories(rows);
                cacheAsync(() -> cache.saveCategories(rows));
            }
            @Override public void error(String message) {
                if (rawCategories.isEmpty()) b.movieError.setText(message);
            }
        });
    }

    private void loadAllMovies(boolean showSpinner) {
        final int generation = ++movieRequestGeneration;
        loading = true;
        networkCatalogComplete = false;
        if (showSpinner && allMovies.isEmpty()) {
            b.movieLoading.setVisibility(View.GONE);
            handler.postDelayed(() -> {
                if (loading && allMovies.isEmpty() && !isFinishing() && !isDestroyed()) b.movieLoading.setVisibility(View.VISIBLE);
            }, 350L);
        }
        b.movieError.setText("");

        repo.moviesProgressive("", 24, 240, new MovieRepository.ProgressiveMoviesResult() {
            @Override public void partial(List<Movie> rows) {
                if (generation != movieRequestGeneration || rows == null || rows.isEmpty()) return;
                // Só usa a prévia quando ainda não existe um catálogo completo/cache.
                if (allMovies.isEmpty() || usingNetworkPreview) {
                    usingNetworkPreview = true;
                    allMovies = rows;
                    if (specialMode.isEmpty()) CatalogMemory.setMovies(rows);
                    b.movieLoading.setVisibility(View.GONE);
                    rebuildVisibleAsync();
                    warmMovieArtwork(rows, true);
                }
            }

            @Override public void success(List<Movie> rows) {
                if (generation != movieRequestGeneration) return;
                loading = false;
                networkCatalogComplete = true;
                usingNetworkPreview = false;
                b.movieLoading.setVisibility(View.GONE);
                lastRefreshAt = android.os.SystemClock.elapsedRealtime();
                allMovies = rows == null ? Collections.emptyList() : rows;
                if (specialMode.isEmpty()) CatalogMemory.setMovies(allMovies);
                rebuildVisibleAsync();
                final List<Movie> saveRows = allMovies;
                if (specialMode.isEmpty()) cacheAsync(() -> cache.saveMovies(saveRows));
                warmMovieArtwork(allMovies, false);
            }

            @Override public void error(String message) {
                if (generation != movieRequestGeneration) return;
                loading = false;
                b.movieLoading.setVisibility(View.GONE);
                if (allMovies.isEmpty()) b.movieError.setText(message);
                updateEmpty();
            }
        });
    }

    private void warmMovieArtwork(List<Movie> rows, boolean priorityOnly) {
        if (rows == null || rows.isEmpty()) return;
        ArrayList<String> urls = new ArrayList<>();
        int max = priorityOnly ? Math.min(96, rows.size()) : Math.min(360, rows.size());
        for (int i = 0; i < max; i++) {
            Movie m = rows.get(i);
            if (m != null && m.poster != null && !m.poster.trim().isEmpty()) urls.add(m.poster);
        }
        if (urls.isEmpty()) return;
        if (priorityOnly) CatalogCoverWarmer.warmPriority(urls, 96, null);
        else CatalogCoverWarmer.enqueue(urls);
    }

    private void cacheAsync(Runnable task) {
        try {
            if (!cacheExecutor.isShutdown()) cacheExecutor.execute(task);
        } catch (RuntimeException ignored) { }
    }

    private void openDetails(Movie movie) {
        Intent i = new Intent(this, MovieDetailActivity.class);
        i.putExtra("id", movie.id);
        i.putExtra("name", movie.name);
        i.putExtra("poster", movie.poster);
        i.putExtra("year", movie.year);
        i.putExtra("rating", movie.rating);
        i.putExtra("extension", movie.extension);
        i.putExtra("direct_source", movie.directSource);
        startActivity(i);
    }

    private void configureSpecialModeUi() {
        b.navMovies.setSelected(specialMode.isEmpty());
        b.navKids.setSelected(com.greenplay.v5.core.ui.SpecialSections.KIDS.equals(specialMode));
        b.navAnime.setSelected(com.greenplay.v5.core.ui.SpecialSections.ANIME.equals(specialMode));
        b.navHot.setSelected(com.greenplay.v5.core.ui.SpecialSections.HOT.equals(specialMode));
        if (specialMode.isEmpty()) {
            b.movieSectionLabel.setText("FILMES");
            b.specialModeChooser.setVisibility(View.GONE);
            return;
        }
        String label = com.greenplay.v5.core.ui.SpecialSections.label(specialMode);
        b.movieSectionLabel.setText(label);
        b.specialModeChooser.setVisibility(View.VISIBLE);
        b.specialMoviesChoice.setSelected(true);
        b.specialSeriesChoice.setSelected(false);
        b.specialMoviesChoice.setOnClickListener(v -> {
            // Já estamos em Filmes; mantém a seleção e evita recarregar a tela.
            b.specialMoviesChoice.setSelected(true);
            b.specialSeriesChoice.setSelected(false);
        });
        b.specialSeriesChoice.setOnClickListener(v -> {
            Intent i = new Intent(this, SeriesActivity.class);
            i.putExtra(com.greenplay.v5.core.ui.SpecialSections.EXTRA_MODE, specialMode);
            i.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_NO_ANIMATION);
            startActivity(i);
            overridePendingTransition(0, 0);
        });
    }

    private void applyCategoryScope(List<MovieCategory> rows) {
        ArrayList<MovieCategory> visible = new ArrayList<>();
        MovieCategory all = new MovieCategory("", "TODOS");
        visible.add(all);
        HashSet<String> nextAllowed = new HashSet<>();

        if (rows != null) {
            for (MovieCategory c : rows) {
                if (c == null || c.id == null || c.id.trim().isEmpty()) continue;
                if (!specialMode.isEmpty() && !com.greenplay.v5.core.ui.SpecialSections.matches(specialMode, c.name)) continue;
                visible.add(c);
                if (!specialMode.isEmpty()) nextAllowed.add(c.id);
            }
        }

        if (specialMode.isEmpty()) {
            visible.clear();
            if (rows != null) visible.addAll(rows);
        } else if (nextAllowed.isEmpty() && !allowedCategoryIds.isEmpty()) {
            // Preserve the last good category scope instead of blanking the
            // section when a refresh temporarily returns no usable names.
            return;
        } else {
            allowedCategoryIds.clear();
            allowedCategoryIds.addAll(nextAllowed);
        }

        rawCategories.clear();
        rawCategories.addAll(visible);
        boolean selectedStillAllowed = categoryId.isEmpty();
        for (MovieCategory c : visible) if (categoryId.equals(c.id)) { selectedStillAllowed = true; break; }
        if (!selectedStillAllowed) { categoryId = ""; categoryName = "TODOS"; favoriteMode = false; }
        categoryAdapter.submit(visible, categoryId);
        rebuildVisibleAsync();
    }

    private static String normalizeSpecialMode(String raw) {
        String m = raw == null ? "" : raw.trim().toLowerCase(Locale.ROOT);
        return com.greenplay.v5.core.ui.SpecialSections.valid(m) ? m : "";
    }

    @Override protected void onResume() {
        super.onResume();
        if (movieAdapter != null) {
            if (favoriteMode) rebuildVisibleAsync();
            else movieAdapter.refreshVisible();
            long now = android.os.SystemClock.elapsedRealtime();
            if (!loading && lastRefreshAt > 0 && now - lastRefreshAt >= AUTO_REFRESH_MS) refresh(false);
        }
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (favoriteMode) {
                favoriteMode = false;
                b.movieFavorites.setSelected(false);
                b.movieFavorites.setText("☆ FAVORITOS");
                rebuildVisibleAsync();
                return true;
            }
            if (b.movieSearch.getText() != null && b.movieSearch.getText().length() > 0) {
                b.movieSearch.setText("");
                hideKeyboard();
                b.movieGrid.requestFocus();
                return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(b.movieSearch.getWindowToken(), 0);
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        filterGeneration++;
        movieRequestGeneration++;
        filterExecutor.shutdownNow();
        cacheExecutor.shutdownNow();
        super.onDestroy();
    }
}
