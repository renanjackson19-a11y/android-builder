package com.greenplay.v5.ui.login;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import androidx.appcompat.app.AlertDialog;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.greenplay.v5.BuildConfig;
import com.greenplay.v5.R;
import com.greenplay.v5.core.network.NetworkProvider;
import com.greenplay.v5.core.network.PanelHost;
import com.greenplay.v5.core.session.SessionStore;
import com.greenplay.v5.core.config.BrandingStore;
import com.greenplay.v5.data.model.LoginResponse;
import com.greenplay.v5.data.model.StatusResponse;
import com.greenplay.v5.data.model.TrialStatusResponse;
import com.greenplay.v5.data.model.AppConfigResponse;
import com.greenplay.v5.data.model.DiagnosticsResponse;
import com.greenplay.v5.data.repository.AuthRepository;
import com.greenplay.v5.databinding.ActivityLoginBinding;
import com.greenplay.v5.ui.preload.CatalogPreloadActivity;
import com.squareup.picasso.Picasso;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public final class LoginActivity extends AppCompatActivity {
    private ActivityLoginBinding b;
    private AuthRepository auth;
    private int trialHours = 3;
    private boolean trialEnabled = false;
    private boolean panelTrialEnabled = false;
    private boolean passwordVisible = false;
    private String deviceId = "";

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        b = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        auth = new AuthRepository(this);

        SessionStore session = new SessionStore(this);
        if (session.isLogged() && !session.host().trim().isEmpty() && !session.user().trim().isEmpty() && !session.pass().isEmpty()) {
            openTv();
            return;
        }

        deviceId = resolveDeviceId();
        b.txtDevice.setText("ID Dispositivo: " + (deviceId.isEmpty() ? "NÃO DISPONÍVEL" : deviceId.toUpperCase()));
        b.txtVersion.setText("Versão: " + BuildConfig.VERSION_NAME);

        // O botão nasce oculto. Quem decide se ele aparece é o servidor.
        b.btnTrial.setVisibility(View.GONE);
        b.btnTrial.setEnabled(false);

        b.btnEnter.setOnClickListener(v -> login());
        b.btnConnection.setOnClickListener(v -> testConnection());
        b.btnTrial.setOnClickListener(v -> createTrial());
        configurePasswordEye();

        // Branding e autorização do teste são consultados em paralelo para abrir rápido.
        loadPanelBranding();
        loadAppConfig();
        loadTrialEligibility(false);
    }

    @Override protected void onResume() {
        super.onResume();
        if (b != null && !deviceId.isEmpty()) loadTrialEligibility(false);
    }

    private String resolveDeviceId() {
        String device = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        return device == null ? "" : device.trim();
    }

    private void configurePasswordEye() {
        b.inputPass.setOnTouchListener((v, event) -> {
            if (event.getAction() != MotionEvent.ACTION_UP) return false;
            if (b.inputPass.getCompoundDrawablesRelative()[2] == null) return false;
            int touchStart = b.inputPass.getWidth() - b.inputPass.getPaddingEnd()
                    - b.inputPass.getCompoundDrawablesRelative()[2].getBounds().width() - 24;
            if (event.getX() < touchStart) return false;

            int cursor = b.inputPass.getSelectionStart();
            passwordVisible = !passwordVisible;
            b.inputPass.setTransformationMethod(passwordVisible
                    ? HideReturnsTransformationMethod.getInstance()
                    : PasswordTransformationMethod.getInstance());
            b.inputPass.setSelection(Math.max(0, cursor));
            v.performClick();
            return true;
        });
    }

    private void loadPanelBranding() {
        setServerOnline(false);
        NetworkProvider.panel().status().enqueue(new Callback<StatusResponse>() {
            @Override public void onResponse(Call<StatusResponse> call, Response<StatusResponse> response) {
                StatusResponse st = response.body();
                if (!response.isSuccessful() || st == null) {
                    runOnUiThread(() -> setServerOnline(false));
                    return;
                }
                runOnUiThread(() -> {
                    setServerOnline(true);
                    applyStatus(st);
                });
            }
            @Override public void onFailure(Call<StatusResponse> call, Throwable t) {
                runOnUiThread(() -> setServerOnline(false));
            }
        });
    }

    private void applyStatus(StatusResponse st) {
        String bg = absoluteAsset(st.loginBackground);
        if (!bg.isEmpty()) {
            Picasso.get()
                    .load(bg)
                    .placeholder(R.drawable.login_green_play_default)
                    .error(R.drawable.login_green_play_default)
                    .noFade()
                    .into(b.loginBackground);
        }

        String logo = absoluteAsset(st.appLogo);
        if (!logo.isEmpty()) {
            Picasso.get().load(logo).noFade().into(b.appLogo, new com.squareup.picasso.Callback() {
                @Override public void onSuccess() { b.appLogo.setVisibility(View.VISIBLE); }
                @Override public void onError(Exception e) { b.appLogo.setVisibility(View.GONE); }
            });
        } else {
            b.appLogo.setVisibility(View.GONE);
        }

        // Duração também vem do painel, mas a exibição do botão depende do status por aparelho.
        trialHours = Math.max(1, st.trialHours);
        panelTrialEnabled = st.trialEnabled;
        if (!st.trialEnabled) {
            trialEnabled = false;
            b.btnTrial.setVisibility(View.GONE);
            b.btnTrial.setEnabled(false);
        } else {
            // Mostra rápido quando o painel está ligado; a consulta por aparelho pode esconder em seguida se já foi usado.
            showTrialFallback();
        }
    }

    private void loadAppConfig() {
        NetworkProvider.panel().appConfig().enqueue(new Callback<AppConfigResponse>() {
            @Override public void onResponse(Call<AppConfigResponse> call, Response<AppConfigResponse> response) {
                AppConfigResponse cfg=response.body();
                if(response.isSuccessful() && cfg!=null && cfg.ok && cfg.branding!=null){
                    new BrandingStore(LoginActivity.this).save(cfg.branding);
                }
            }
            @Override public void onFailure(Call<AppConfigResponse> call, Throwable t) { }
        });
    }

    private void showTrialFallback() {
        trialEnabled = panelTrialEnabled;
        if (trialEnabled) {
            b.btnTrial.setText("TESTE AUTOMÁTICO  •  " + trialHours + (trialHours == 1 ? " HORA" : " HORAS"));
            b.btnTrial.setVisibility(View.VISIBLE);
            b.btnTrial.setEnabled(true);
        } else {
            b.btnTrial.setVisibility(View.GONE);
            b.btnTrial.setEnabled(false);
        }
    }

    private void loadTrialEligibility(boolean showBlockedMessage) {
        if (deviceId.isEmpty()) {
            trialEnabled = false;
            b.btnTrial.setVisibility(View.GONE);
            return;
        }
        NetworkProvider.panel().trialStatus(deviceId).enqueue(new Callback<TrialStatusResponse>() {
            @Override public void onResponse(Call<TrialStatusResponse> call, Response<TrialStatusResponse> response) {
                TrialStatusResponse st = response.body();
                runOnUiThread(() -> {
                    if (!response.isSuccessful() || st == null || !st.ok) {
                        showTrialFallback();
                        return;
                    }
                    trialHours = Math.max(1, st.trialHours);

                    // Painel V9.0.70+ informa elegibilidade por aparelho.
                    // Painel V9.0.69 não enviava o campo eligible; nesse caso mostramos
                    // o botão quando trial_enabled estiver ativo. A criação continua sendo
                    // validada no servidor por trial.php, então o APK não cria teste sozinho.
                    boolean hasEligibility = st.eligible != null;
                    boolean eligibleNow = hasEligibility ? Boolean.TRUE.equals(st.eligible) : st.enabled;
                    trialEnabled = st.enabled && eligibleNow;

                    if (trialEnabled) {
                        b.btnTrial.setText("TESTE AUTOMÁTICO  •  " + trialHours + (trialHours == 1 ? " HORA" : " HORAS"));
                        b.btnTrial.setVisibility(View.VISIBLE);
                        b.btnTrial.setEnabled(true);
                    } else {
                        b.btnTrial.setVisibility(View.GONE);
                        b.btnTrial.setEnabled(false);
                        if (showBlockedMessage && Boolean.TRUE.equals(st.used)) {
                            b.txtError.setTextColor(ContextCompat.getColor(LoginActivity.this, R.color.gp_muted));
                            b.txtError.setText(Boolean.TRUE.equals(st.active) ? "Teste deste aparelho já está em uso" : "Teste deste aparelho já foi utilizado");
                        }
                    }
                });
            }

            @Override public void onFailure(Call<TrialStatusResponse> call, Throwable t) {
                runOnUiThread(() -> showTrialFallback());
            }
        });
    }

    private void testConnection() {
        b.btnConnection.setEnabled(false);

        View content = getLayoutInflater().inflate(R.layout.dialog_connection_test, null, false);
        final AlertDialog dialog = new AlertDialog.Builder(this).setView(content).create();
        dialog.setCancelable(false);
        dialog.setOnShowListener(d -> {
            Window w = dialog.getWindow();
            if (w != null) {
                w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                int screen = getResources().getDisplayMetrics().widthPixels;
                int max = (int) (760f * getResources().getDisplayMetrics().density);
                int width = Math.min(max, (int) (screen * 0.76f));
                w.setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT);
                WindowManager.LayoutParams lp = w.getAttributes();
                lp.dimAmount = 0.78f;
                w.setAttributes(lp);
                w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            }
        });

        TextView iptvName = content.findViewById(R.id.txtIptvName);
        TextView sourceName = content.findViewById(R.id.txtSourceName);
        TextView internetView = content.findViewById(R.id.statusInternet);
        TextView panelView = content.findViewById(R.id.statusPanel);
        TextView configView = content.findViewById(R.id.statusConfig);
        TextView serverView = content.findViewById(R.id.statusServer);
        TextView resultView = content.findViewById(R.id.txtConnectionResult);
        TextView closeButton = content.findViewById(R.id.btnCloseConnection);
        View spinner = content.findViewById(R.id.connectionProgress);

        closeButton.setEnabled(false);
        closeButton.setAlpha(0.45f);
        closeButton.setOnClickListener(v -> dialog.dismiss());
        dialog.show();

        boolean internet = hasInternet();
        setConnectionStep(internetView, internet ? "OK" : "ERRO", internet ? 0xFF4BE17A : 0xFFFF6B76);
        if (!internet) {
            setConnectionStep(panelView, "NÃO TESTADO", 0xFF8F9A94);
            finishConnectionTest(dialog, spinner, closeButton, resultView, "Sem conexão com a internet", false);
            return;
        }

        setConnectionStep(panelView, "TESTANDO...", 0xFFF6C84C);
        NetworkProvider.panel().status().enqueue(new Callback<StatusResponse>() {
            @Override public void onResponse(Call<StatusResponse> call, Response<StatusResponse> response) {
                StatusResponse st = response.body();
                if (!response.isSuccessful() || st == null) {
                    runOnUiThread(() -> {
                        setConnectionStep(panelView, "ERRO", 0xFFFF6B76);
                        finishConnectionTest(dialog, spinner, closeButton, resultView, "Painel indisponível", false);
                    });
                    return;
                }
                runOnUiThread(() -> {
                    setServerOnline(true);
                    applyStatus(st);
                    setConnectionStep(panelView, "OK", 0xFF4BE17A);
                    if (st.name != null && !st.name.trim().isEmpty()) iptvName.setText("IPTV: " + st.name.trim().toUpperCase());
                    setConnectionStep(configView, "TESTANDO...", 0xFFF6C84C);
                });

                NetworkProvider.panel().appConfig().enqueue(new Callback<AppConfigResponse>() {
                    @Override public void onResponse(Call<AppConfigResponse> c, Response<AppConfigResponse> r) {
                        AppConfigResponse cfg = r.body();
                        boolean configOk = r.isSuccessful() && cfg != null && cfg.ok;
                        if (configOk && cfg.branding != null) {
                            new BrandingStore(LoginActivity.this).save(cfg.branding);
                        }
                        if (configOk && cfg.universal != null && cfg.universal.servers != null && !cfg.universal.servers.isEmpty()) {
                            AppConfigResponse.Server chosen = cfg.universal.servers.get(0);
                            for (AppConfigResponse.Server candidate : cfg.universal.servers) {
                                if (candidate != null && candidate.isDefault) { chosen = candidate; break; }
                            }
                            final String serverLabel = chosen != null && chosen.name != null ? chosen.name.trim() : "";
                            if (!serverLabel.isEmpty()) {
                                runOnUiThread(() -> iptvName.setText("IPTV: " + serverLabel.toUpperCase()));
                            }
                        } else if (configOk && cfg.branding != null && cfg.branding.appName != null && !cfg.branding.appName.trim().isEmpty()) {
                            runOnUiThread(() -> iptvName.setText("IPTV: " + cfg.branding.appName.trim().toUpperCase()));
                        }
                        runOnUiThread(() -> {
                            setConnectionStep(configView, configOk ? "OK" : "ERRO", configOk ? 0xFF4BE17A : 0xFFFF6B76);
                            setConnectionStep(serverView, "TESTANDO...", 0xFFF6C84C);
                        });

                        NetworkProvider.panel().diagnostics().enqueue(new Callback<DiagnosticsResponse>() {
                            @Override public void onResponse(Call<DiagnosticsResponse> dc, Response<DiagnosticsResponse> dr) {
                                DiagnosticsResponse x = dr.body();
                                boolean ok = dr.isSuccessful() && x != null && x.ok;
                                runOnUiThread(() -> {
                                    if (ok) {
                                        if (x.iptvName != null && !x.iptvName.trim().isEmpty()) {
                                            iptvName.setText("IPTV: " + x.iptvName.trim().toUpperCase());
                                        }
                                        if (x.sourceName != null && !x.sourceName.trim().isEmpty()) {
                                            sourceName.setText("Fonte IPTV: " + x.sourceName.trim());
                                            sourceName.setVisibility(View.VISIBLE);
                                        } else if (x.activeSources > 1) {
                                            sourceName.setText(x.activeSources + " fontes IPTV ativas");
                                            sourceName.setVisibility(View.VISIBLE);
                                        }
                                        setConnectionStep(serverView, x.serverReady ? "OK" : "ATENÇÃO", x.serverReady ? 0xFF4BE17A : 0xFFF6C84C);
                                        finishConnectionTest(dialog, spinner, closeButton, resultView,
                                                x.serverReady ? "Conexão estável • serviços disponíveis" : "Conexão realizada • servidor requer atenção",
                                                x.serverReady && configOk);
                                    } else {
                                        setConnectionStep(serverView, "ERRO", 0xFFFF6B76);
                                        finishConnectionTest(dialog, spinner, closeButton, resultView, "Falha no diagnóstico do servidor IPTV", false);
                                    }
                                });
                            }
                            @Override public void onFailure(Call<DiagnosticsResponse> dc, Throwable t) {
                                runOnUiThread(() -> {
                                    setConnectionStep(serverView, "ERRO", 0xFFFF6B76);
                                    finishConnectionTest(dialog, spinner, closeButton, resultView, "Falha ao consultar servidor IPTV", false);
                                });
                            }
                        });
                    }

                    @Override public void onFailure(Call<AppConfigResponse> c, Throwable t) {
                        runOnUiThread(() -> {
                            setConnectionStep(configView, "ERRO", 0xFFFF6B76);
                            setConnectionStep(serverView, "NÃO TESTADO", 0xFF8F9A94);
                            finishConnectionTest(dialog, spinner, closeButton, resultView, "Falha ao carregar configurações do app", false);
                        });
                    }
                });
            }

            @Override public void onFailure(Call<StatusResponse> call, Throwable t) {
                runOnUiThread(() -> {
                    setServerOnline(false);
                    setConnectionStep(panelView, "ERRO", 0xFFFF6B76);
                    finishConnectionTest(dialog, spinner, closeButton, resultView, "Sem conexão com o painel", false);
                });
            }
        });
    }

    private void setConnectionStep(TextView view, String value, int color) {
        if (view == null) return;
        view.setText(value);
        view.setTextColor(color);
    }


    private boolean hasInternet(){
        try{
            ConnectivityManager cm=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
            android.net.Network n=cm.getActiveNetwork();
            if(n==null)return false;
            NetworkCapabilities c=cm.getNetworkCapabilities(n);
            return c!=null&&c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
        }catch(Exception e){return true;}
    }

    private void finishConnectionTest(AlertDialog dialog, View spinner, TextView closeButton, TextView resultView, String summary, boolean ok){
        b.btnConnection.setEnabled(true);
        b.txtError.setTextColor(ok ? ContextCompat.getColor(this, R.color.gp_green_soft) : 0xFFFF7979);
        b.txtError.setText(summary);
        if (spinner != null) spinner.setVisibility(View.GONE);
        if (resultView != null) {
            resultView.setText(summary);
            resultView.setTextColor(ok ? 0xFF4BE17A : 0xFFFF8B94);
        }
        if (closeButton != null) {
            closeButton.setEnabled(true);
            closeButton.setAlpha(1f);
            closeButton.requestFocus();
        }
        if(ok){ loadTrialEligibility(false); loadAppConfig(); }
    }

    private void setServerOnline(boolean online) {
        b.serverDot.setBackgroundResource(online ? R.drawable.bg_status_online : R.drawable.bg_status_offline);
    }

    private String absoluteAsset(String raw) {
        if (raw == null) return "";
        String s = raw.trim();
        if (s.isEmpty()) return "";
        if (s.startsWith("http://") || s.startsWith("https://")) return s;
        String root = PanelHost.root();
        if (root.endsWith("/")) root = root.substring(0, root.length() - 1);
        return root + (s.startsWith("/") ? s : "/" + s);
    }

    private void setLoading(boolean loading, String text) {
        b.progress.setVisibility(loading ? View.VISIBLE : View.GONE);
        b.btnEnter.setEnabled(!loading);
        b.btnConnection.setEnabled(!loading);
        b.btnTrial.setEnabled(!loading && trialEnabled);
        if (text != null) b.txtError.setText(text);
    }

    private void login() {
        String user = b.inputUser.getText().toString().trim();
        String pass = b.inputPass.getText().toString();
        if (user.isEmpty() || pass.isEmpty()) {
            b.txtError.setTextColor(0xFFFF7979);
            b.txtError.setText("Digite usuário e senha");
            return;
        }
        b.txtError.setTextColor(0xFFFF7979);
        setLoading(true, "");
        auth.login(user, pass, deviceId, new AuthRepository.Result() {
            @Override public void success(LoginResponse login) { runOnUiThread(() -> openTv()); }
            @Override public void error(String message) { runOnUiThread(() -> setLoading(false, message)); }
        });
    }

    private void createTrial() {
        if (!trialEnabled || deviceId.isEmpty()) return;
        // O APK não envia duração, plano ou bouquet. O servidor decide tudo.
        b.txtError.setTextColor(ContextCompat.getColor(this, R.color.gp_muted));
        setLoading(true, "Solicitando teste ao painel...");
        NetworkProvider.panel().trial(deviceId).enqueue(new Callback<LoginResponse>() {
            @Override public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                LoginResponse body = response.body();
                if (!response.isSuccessful() || body == null || !body.ok) {
                    String msg = body != null && body.message != null ? body.message : "Teste indisponível no momento";
                    runOnUiThread(() -> {
                        b.txtError.setTextColor(0xFFFF7979);
                        setLoading(false, msg);
                        loadTrialEligibility(false);
                    });
                    return;
                }
                String user = body.username == null ? "" : body.username.trim();
                String pass = body.xtreamPassword == null ? "" : body.xtreamPassword;
                String host = body.xtreamHost == null || body.xtreamHost.trim().isEmpty() ? PanelHost.root() : body.xtreamHost.trim();
                new SessionStore(LoginActivity.this).save(host, user, pass, body.expiresAt, body.plan, body.adultAccess, body.userToken);
                trialEnabled = false;
                runOnUiThread(() -> {
                    b.btnTrial.setVisibility(View.GONE);
                    openTv();
                });
            }
            @Override public void onFailure(Call<LoginResponse> call, Throwable t) {
                runOnUiThread(() -> {
                    b.txtError.setTextColor(0xFFFF7979);
                    setLoading(false, "Sem conexão com o painel");
                    loadTrialEligibility(false);
                });
            }
        });
    }

    private void openTv() {
        startActivity(new Intent(LoginActivity.this, CatalogPreloadActivity.class));
        finish();
    }
}
