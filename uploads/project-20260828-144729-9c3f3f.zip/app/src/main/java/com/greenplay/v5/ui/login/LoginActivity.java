package com.greenplay.v5.ui.login;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import com.greenplay.v5.core.session.SessionStore;
import com.greenplay.v5.data.model.LoginResponse;
import com.greenplay.v5.data.repository.AuthRepository;
import com.greenplay.v5.databinding.ActivityLoginBinding;
import com.greenplay.v5.ui.home.HomeActivity;

public final class LoginActivity extends AppCompatActivity {
    private ActivityLoginBinding b;
    private AuthRepository auth;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        b = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        auth = new AuthRepository(this);
        SessionStore session = new SessionStore(this);
        if (session.isLogged() && !session.host().trim().isEmpty() && !session.user().trim().isEmpty() && !session.pass().isEmpty()) {
            startActivity(new Intent(LoginActivity.this, HomeActivity.class));
            finish();
            return;
        }
        b.btnEnter.setOnClickListener(v -> login());
    }

    private void login() {
        String user = b.inputUser.getText().toString().trim();
        String pass = b.inputPass.getText().toString();
        if (user.isEmpty() || pass.isEmpty()) { b.txtError.setText("Digite usuário e senha"); return; }
        b.progress.setVisibility(View.VISIBLE);
        b.btnEnter.setEnabled(false);
        String device = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        auth.login(user, pass, device, new AuthRepository.Result() {
            @Override public void success(LoginResponse login) {
                runOnUiThread(() -> { startActivity(new Intent(LoginActivity.this, HomeActivity.class)); finish(); });
            }
            @Override public void error(String message) {
                runOnUiThread(() -> { b.progress.setVisibility(View.GONE); b.btnEnter.setEnabled(true); b.txtError.setText(message); });
            }
        });
    }
}
