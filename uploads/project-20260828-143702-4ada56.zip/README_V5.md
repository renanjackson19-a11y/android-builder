# GREEN PLAY V5 — Alpha 15 TV Fullscreen estilo referência V4

Esta versão mantém a base V5 nova e usa o V4 apenas como referência de comportamento visual.

## TV — fullscreen refeito
- O mesmo PlayerView/stream do preview é movido para fullscreen; não recria URL nem dá prepare novamente ao abrir/fechar.
- Fullscreen normal: vídeo + painel inferior fixo com logo, número/nome, AO VIVO, EPG atual/próximo e progresso.
- OK/toque no fullscreen: abre a lista lateral de canais sobre o vídeo, no formato da referência antiga.
- Lista lateral: trilho estreito com busca/recentes/favoritos/todos + lista de canais.
- Selecionar outro canal pela lista lateral troca o canal e volta ao fullscreen normal.
- VOLTAR com lista aberta: fecha somente a lista.
- VOLTAR no fullscreen normal: retorna para a tela principal de TV.
- Mesmo applicationId/assinatura das Alphas anteriores para atualização por cima.

VersionCode: 5015


## Alpha 16 – ajustes TV
- Painel EPG fullscreen na altura proporcional à referência (~25% da tela).
- EPG cacheado aparece imediatamente ao entrar em tela cheia.
- Ao voltar do segundo plano, mantém o mesmo canal mas reconecta no ponto AO VIVO.
- Indicador de consumo/velocidade de rede no canto superior direito em tela cheia.
- Removido RECENTES da barra lateral fullscreen; permanecem busca, favoritos e todos.


## Alpha 17 — polimento TV
- painel EPG normal mais compacto;
- painel inferior fullscreen reduzido para ~20% da altura real da tela;
- lista lateral limitada a 40% da largura;
- lista permanece aberta ao trocar canal e BACK fecha a lista;
- indicador de rede menor e separado;
- linhas de canais mais compactas;
- sem mudanças na camada de login, API ou núcleo do player.


## Alpha 18 - TV refinada
- Lista de canais com título centralizado e sem botão TODOS redundante.
- Favoritos compacto e estrelas verdes.
- Fullscreen: EPG/info some automaticamente após ~4,2 s.
- Barra de progresso do EPG atualiza a cada 5 s e renova o EPG ao virar o programa.
- Lateral mais estreita com Busca, EPG, Favoritos e Lista.
- Hora + consumo de rede em bloco próprio no canto superior direito.
- Mesmo player/stream preservado ao abrir e fechar os overlays.


## Alpha 20 — TV / EPG compacto
- remove contador de quantidade da lista de canais;
- Favoritos permanece na barra superior, compacto e em uma linha;
- EPG pequeno e tela cheia usam o mesmo desenho compacto;
- Atual em vermelho, Próximo em branco e progresso real em verde;
- carregamento central verde ao trocar de canal;
- mantém o mesmo player e não altera o contrato do painel.
