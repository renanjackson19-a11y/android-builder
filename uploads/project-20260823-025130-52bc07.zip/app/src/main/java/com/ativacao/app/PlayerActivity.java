package com.ativacao.app;

import android.app.Activity;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.MediaController;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

public class PlayerActivity extends Activity {
    private VideoView video;
    private ProgressBar loading;

    @Override public void onCreate(Bundle b){
        super.onCreate(b); immersive();
        FrameLayout root=new FrameLayout(this);root.setBackgroundColor(Color.BLACK);
        video=new VideoView(this);root.addView(video,new FrameLayout.LayoutParams(-1,-1));
        loading=new ProgressBar(this);FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(Ui.dp(this,55),Ui.dp(this,55),Gravity.CENTER);root.addView(loading,lp);
        TextView name=Ui.text(this,getIntent().getStringExtra("name")==null?"Dubai Play":getIntent().getStringExtra("name"),16,Color.WHITE,true);name.setPadding(Ui.dp(this,20),Ui.dp(this,10),Ui.dp(this,20),Ui.dp(this,10));name.setBackgroundColor(0x88000000);FrameLayout.LayoutParams np=new FrameLayout.LayoutParams(-1,Ui.dp(this,50),Gravity.TOP);root.addView(name,np);
        setContentView(root);
        long id=getIntent().getLongExtra("id",0);String url=ApiClient.streamUrl(this,id);if(url.isEmpty()){Toast.makeText(this,"Chave da API não configurada.",Toast.LENGTH_LONG).show();finish();return;}
        MediaController controls=new MediaController(this);controls.setAnchorView(video);video.setMediaController(controls);
        video.setOnPreparedListener(mp->{loading.setVisibility(View.GONE);mp.setScreenOnWhilePlaying(true);video.start();});
        video.setOnErrorListener((mp,what,extra)->{loading.setVisibility(View.GONE);Toast.makeText(this,"Não foi possível reproduzir este conteúdo.",Toast.LENGTH_LONG).show();return true;});
        video.setVideoURI(Uri.parse(url));video.requestFocus();
    }
    @Override protected void onStop(){if(video!=null)video.stopPlayback();super.onStop();}
    private void immersive(){getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);}
}
