package com.ativacao.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;

public class CatalogActivity extends Activity {
    private final List<ApiClient.Item> all = new ArrayList<>();
    private final List<ApiClient.Item> shown = new ArrayList<>();
    private GridView grid;
    private TextView status;
    private Adapter adapter;
    private String type;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b); immersive();
        type=getIntent().getStringExtra("type"); if(type==null) type="live";
        setContentView(build()); load();
    }

    private View build() {
        LinearLayout root=Ui.column(this); root.setBackgroundColor(Ui.BG); root.setPadding(Ui.dp(this,30),Ui.dp(this,22),Ui.dp(this,30),Ui.dp(this,20));
        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL);
        TextView back=Ui.button(this,"‹ VOLTAR"); back.setOnClickListener(v->finish());
        TextView title=Ui.text(this,getIntent().getStringExtra("title")==null?"Conteúdos":getIntent().getStringExtra("title"),26,Ui.TEXT,true);
        EditText search=new EditText(this); search.setHint("Pesquisar..."); search.setHintTextColor(Ui.MUTED); search.setTextColor(Ui.TEXT); search.setSingleLine(true); search.setPadding(Ui.dp(this,16),0,Ui.dp(this,16),0); search.setBackground(Ui.stroke(Ui.PANEL_2,Color.rgb(50,68,95),14,this));
        bar.addView(back,new LinearLayout.LayoutParams(Ui.dp(this,150),Ui.dp(this,52)));
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,Ui.dp(this,52),1); tp.leftMargin=Ui.dp(this,18); bar.addView(title,tp);
        bar.addView(search,new LinearLayout.LayoutParams(Ui.dp(this,320),Ui.dp(this,48)));
        root.addView(bar);
        status=Ui.text(this,"Carregando catálogo...",13,Ui.MUTED,false); root.addView(status,new LinearLayout.LayoutParams(-1,Ui.dp(this,44)));
        grid=new GridView(this); grid.setNumColumns(5); grid.setHorizontalSpacing(Ui.dp(this,14)); grid.setVerticalSpacing(Ui.dp(this,14)); grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH); grid.setSelector(android.R.color.transparent); grid.setPadding(0,Ui.dp(this,4),0,Ui.dp(this,12));
        adapter=new Adapter(); grid.setAdapter(adapter); root.addView(grid,new LinearLayout.LayoutParams(-1,0,1));
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){filter(s.toString());} public void afterTextChanged(Editable e){}});
        back.requestFocus(); return root;
    }

    private void load(){
        ApiClient.catalog(this,type,new ApiClient.Callback<List<ApiClient.Item>>(){public void ok(List<ApiClient.Item> v){runOnUiThread(()->{all.clear();all.addAll(v);filter("");status.setText(v.size()+" itens disponíveis"); if(!shown.isEmpty())grid.requestFocus();});} public void error(String m){runOnUiThread(()->status.setText("Não foi possível carregar: "+m+" • Abra Configurações e informe a chave da API."));}});
    }
    private void filter(String q){String n=q==null?"":q.trim().toLowerCase(Locale.ROOT);shown.clear();for(ApiClient.Item i:all){if(n.isEmpty()||i.name.toLowerCase(Locale.ROOT).contains(n)||i.group.toLowerCase(Locale.ROOT).contains(n))shown.add(i);}adapter.notifyDataSetChanged();}

    private class Adapter extends BaseAdapter {
        private final ConcurrentHashMap<String,Bitmap> cache=new ConcurrentHashMap<>();
        public int getCount(){return shown.size();} public Object getItem(int p){return shown.get(p);} public long getItemId(int p){return shown.get(p).id;}
        public View getView(int p,View convert,android.view.ViewGroup parent){
            LinearLayout card; ImageView image; TextView title,group;
            if(convert==null){card=Ui.column(CatalogActivity.this);card.setPadding(Ui.dp(CatalogActivity.this,10),Ui.dp(CatalogActivity.this,10),Ui.dp(CatalogActivity.this,10),Ui.dp(CatalogActivity.this,10));card.setBackground(Ui.stroke(Ui.PANEL,Color.rgb(33,50,75),14,CatalogActivity.this));card.setFocusable(true);Ui.focus(card,CatalogActivity.this);image=new ImageView(CatalogActivity.this);image.setId(1001);image.setScaleType(ImageView.ScaleType.CENTER_CROP);image.setBackgroundColor(Color.rgb(21,32,50));card.addView(image,new LinearLayout.LayoutParams(-1,Ui.dp(CatalogActivity.this,105)));title=Ui.text(CatalogActivity.this,"",14,Ui.TEXT,true);title.setId(1002);title.setMaxLines(1);card.addView(title,new LinearLayout.LayoutParams(-1,Ui.dp(CatalogActivity.this,32)));group=Ui.text(CatalogActivity.this,"",11,Ui.MUTED,false);group.setId(1003);group.setMaxLines(1);card.addView(group,new LinearLayout.LayoutParams(-1,Ui.dp(CatalogActivity.this,24)));convert=card;}else card=(LinearLayout)convert;
            image=convert.findViewById(1001);title=convert.findViewById(1002);group=convert.findViewById(1003);ApiClient.Item item=shown.get(p);title.setText(item.name);group.setText(item.group.isEmpty()?"Dubai Play":item.group);image.setImageDrawable(null);image.setTag(item.logo);Bitmap bm=cache.get(item.logo);if(bm!=null)image.setImageBitmap(bm);else if(!item.logo.isEmpty()){final ImageView target=image;final String logo=item.logo;ApiClient.IO.execute(()->{try{Bitmap x=BitmapFactory.decodeStream(new URL(logo).openStream());if(x!=null){cache.put(logo,x);runOnUiThread(()->{if(logo.equals(target.getTag()))target.setImageBitmap(x);});}}catch(Exception ignored){}});} card.setOnClickListener(v->{Intent in=new Intent(CatalogActivity.this,PlayerActivity.class);in.putExtra("id",item.id);in.putExtra("name",item.name);in.putExtra("group",item.group);startActivity(in);});return convert;
        }
    }
    private void immersive(){getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);}
}
