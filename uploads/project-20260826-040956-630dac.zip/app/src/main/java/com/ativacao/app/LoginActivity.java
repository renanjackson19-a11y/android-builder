package com.ativacao.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class LoginActivity extends Activity {
    private EditText user,pass; private TextView message,serverBadge,enter,trial,brandMark,loadTitle,loadStep; private ImageView bgImage,brandLogo; private FrameLayout loadingOverlay; private boolean phone; private int trialHours=3;
    @Override public void onCreate(Bundle b){super.onCreate(b);ApiClient.setUserToken(Session.token(this));getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);Ui.immersive(this);if(Session.isLogged(this)){openHome();return;}phone=Ui.phone(this);setContentView(build());checkServer();}
    @Override protected void onResume(){super.onResume();Ui.immersive(this);}

    private View build(){
        FrameLayout root=new FrameLayout(this); root.setBackgroundColor(Color.BLACK);

        // Fundo e logo vêm sempre do painel. O app só organiza/apresenta.
        bgImage=new ImageView(this); bgImage.setScaleType(ImageView.ScaleType.CENTER_CROP); bgImage.setBackgroundColor(0xFF020705); root.addView(bgImage,new FrameLayout.LayoutParams(-1,-1));
        View dim=new View(this); dim.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0x9C000000,0x6A001007,0xD9000000})); root.addView(dim,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout shell=new LinearLayout(this); shell.setOrientation(LinearLayout.HORIZONTAL); shell.setGravity(Gravity.CENTER); shell.setPadding(Ui.dp(this,phone?18:34),Ui.dp(this,phone?16:26),Ui.dp(this,phone?18:34),Ui.dp(this,phone?16:26)); root.addView(shell,new FrameLayout.LayoutParams(-1,-1));

        // LADO ESQUERDO: somente identidade enviada pelo painel + dados do dispositivo.
        FrameLayout leftFrame=new FrameLayout(this);
        LinearLayout brand=Ui.column(this); brand.setGravity(Gravity.CENTER); brand.setPadding(Ui.dp(this,24),Ui.dp(this,20),Ui.dp(this,24),Ui.dp(this,20));
        brandLogo=new ImageView(this); brandLogo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        String savedLogo=BrandConfig.logo(this);
        if(savedLogo!=null&&!savedLogo.trim().isEmpty()) ImageLoader.into(this,brandLogo,savedLogo);
        else { brandLogo.setImageDrawable(null); brandLogo.setBackgroundColor(Color.TRANSPARENT); }
        LinearLayout.LayoutParams blp=new LinearLayout.LayoutParams(-1,0,1f); blp.leftMargin=Ui.dp(this,28); blp.rightMargin=Ui.dp(this,28); brand.addView(brandLogo,blp);
        brandMark=Ui.text(this,"DUBAI PLAY",phone?24:34,Color.WHITE,true); brandMark.setGravity(Gravity.CENTER); if(savedLogo!=null&&!savedLogo.trim().isEmpty())brandMark.setVisibility(View.GONE); brand.addView(brandMark,new LinearLayout.LayoutParams(-1,Ui.dp(this,48)));
        TextView dev=Ui.text(this,"▣  ID Dispositivo: "+DeviceInfo.macOrId(this)+"
ⓘ  Versão: 4.0.121",phone?9:11,0xFFD6DDD8,false); dev.setLineSpacing(Ui.dp(this,2),1.15f); dev.setPadding(Ui.dp(this,12),Ui.dp(this,6),Ui.dp(this,12),Ui.dp(this,6)); dev.setBackground(Ui.stroke(0x76050B08,0x3328E86B,12,this)); LinearLayout.LayoutParams dv=new LinearLayout.LayoutParams(-1,Ui.dp(this,62)); dv.topMargin=Ui.dp(this,12); brand.addView(dev,dv);
        leftFrame.addView(brand,new FrameLayout.LayoutParams(-1,-1));
        shell.addView(leftFrame,new LinearLayout.LayoutParams(0,-1,1.02f));

        // Divisor verde curvo/vertical para aproximar o visual da referência sem usar arte fixa.
        View divider=new View(this); GradientDrawable dg=new GradientDrawable(); dg.setColor(0x00000000); dg.setStroke(Ui.dp(this,1),0xAA22E566); dg.setCornerRadius(Ui.dp(this,48)); divider.setBackground(dg); LinearLayout.LayoutParams dlp=new LinearLayout.LayoutParams(Ui.dp(this,12),-1); dlp.leftMargin=Ui.dp(this,8); dlp.rightMargin=Ui.dp(this,20); shell.addView(divider,dlp);

        // LADO DIREITO: formulário centralizado e limpo.
        LinearLayout rightWrap=Ui.column(this); rightWrap.setGravity(Gravity.CENTER); rightWrap.setPadding(Ui.dp(this,10),0,Ui.dp(this,10),0);
        LinearLayout right=Ui.column(this); right.setGravity(Gravity.CENTER_VERTICAL); right.setPadding(Ui.dp(this,phone?18:30),Ui.dp(this,phone?16:22),Ui.dp(this,phone?18:30),Ui.dp(this,phone?16:22)); right.setBackground(Ui.stroke(0xB30A0F0D,0x2628E86B,26,this));

        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView head=Ui.text(this,"BEM-VINDO!",phone?25:32,Color.WHITE,true); top.addView(head,new LinearLayout.LayoutParams(0,Ui.dp(this,42),1));
        serverBadge=Ui.text(this,"●",16,Ui.GOLD,true); serverBadge.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); top.addView(serverBadge,new LinearLayout.LayoutParams(Ui.dp(this,36),Ui.dp(this,36))); right.addView(top,new LinearLayout.LayoutParams(-1,Ui.dp(this,46)));
        TextView desc=Ui.text(this,"Digite seu usuário e senha para acessar o aplicativo.",phone?10:12,0xFFC7CCC9,false); LinearLayout.LayoutParams desp=new LinearLayout.LayoutParams(-1,Ui.dp(this,30)); desp.bottomMargin=Ui.dp(this,8); right.addView(desc,desp);

        right.addView(label("Usuário"),new LinearLayout.LayoutParams(-1,Ui.dp(this,22))); user=field("Por favor insira seu usuário",false); LinearLayout.LayoutParams up=new LinearLayout.LayoutParams(-1,Ui.dp(this,54)); up.bottomMargin=Ui.dp(this,12); right.addView(user,up);
        right.addView(label("Senha"),new LinearLayout.LayoutParams(-1,Ui.dp(this,22)));
        FrameLayout passBox=new FrameLayout(this); pass=field("Por favor insira sua senha",true); passBox.addView(pass,new FrameLayout.LayoutParams(-1,Ui.dp(this,54)));
        TextView eye=Ui.text(this,"◉",22,Ui.GREEN,true); eye.setGravity(Gravity.CENTER); eye.setFocusable(true); eye.setClickable(true); FrameLayout.LayoutParams eyp=new FrameLayout.LayoutParams(Ui.dp(this,58),Ui.dp(this,54),Gravity.RIGHT|Gravity.CENTER_VERTICAL); passBox.addView(eye,eyp); pass.setPadding(Ui.dp(this,18),0,Ui.dp(this,62),0);
        final boolean[] showing={false}; eye.setOnClickListener(v->{ showing[0]=!showing[0]; int pos=pass.getSelectionStart(); pass.setInputType(InputType.TYPE_CLASS_TEXT|(showing[0]?InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD:InputType.TYPE_TEXT_VARIATION_PASSWORD)); pass.setSelection(Math.max(0,Math.min(pos,pass.length()))); eye.setText(showing[0]?"◌":"◉"); });
        LinearLayout.LayoutParams pbp=new LinearLayout.LayoutParams(-1,Ui.dp(this,54)); pbp.bottomMargin=Ui.dp(this,14); right.addView(passBox,pbp);

        enter=Ui.primaryButton(this,"↪   ENTRAR"); LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,Ui.dp(this,58)); ep.topMargin=Ui.dp(this,2); right.addView(enter,ep);
        TextView test=Ui.button(this,"⌁   TESTAR CONEXÃO"); LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,Ui.dp(this,50)); tp.topMargin=Ui.dp(this,10); right.addView(test,tp);
        trial=Ui.button(this,"◷   TESTE AUTOMÁTICO  •  3 HORAS"); LinearLayout.LayoutParams trp=new LinearLayout.LayoutParams(-1,Ui.dp(this,50)); trp.topMargin=Ui.dp(this,10); right.addView(trial,trp);
        message=Ui.text(this,"",10,Ui.MUTED,false); message.setGravity(Gravity.CENTER); LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,Ui.dp(this,22)); mp.topMargin=Ui.dp(this,5); right.addView(message,mp);

        rightWrap.addView(right,new LinearLayout.LayoutParams(-1,phone?Ui.dp(this,500):Ui.dp(this,560)));
        shell.addView(rightWrap,new LinearLayout.LayoutParams(0,-1,0.98f));

        enter.setOnClickListener(v->doLogin()); trial.setOnClickListener(v->doTrial()); test.setOnClickListener(v->showDiagnostic()); pass.setOnEditorActionListener((v,a,e)->{doLogin();return true;}); user.requestFocus();
        loadingOverlay=buildLoadingOverlay(); root.addView(loadingOverlay,new FrameLayout.LayoutParams(-1,-1)); loadingOverlay.setVisibility(View.GONE); return root;
    }
    private TextView label(String s){return Ui.text(this,s,10,Color.WHITE,true);}
    private EditText field(String hint,boolean password){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(0xFF727B86);e.setTextColor(Color.WHITE);e.setTextSize(phone?12:14);e.setSingleLine(true);e.setPadding(Ui.dp(this,18),0,Ui.dp(this,18),0);e.setBackground(Ui.stroke(0xD9141921,0xFF31404B,20,this));if(password)e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);e.setOnFocusChangeListener((v,f)->e.setBackground(Ui.stroke(0xD9141921,f?Ui.GREEN:0xFF31404B,20,this)));return e;}
    private void doLogin(){String u=user.getText().toString().trim(),p=pass.getText().toString();if(u.isEmpty()||p.isEmpty()){message.setText("Informe usuário e senha.");message.setTextColor(Ui.RED);return;}enter.setEnabled(false);enter.setText("ENTRANDO...");message.setText("Validando acesso...");message.setTextColor(Ui.MUTED);ApiClient.login(u,p,DeviceInfo.macOrId(this),new ApiClient.Callback<ApiClient.LoginResult>(){public void ok(ApiClient.LoginResult r){runOnUiThread(()->{Session.save(LoginActivity.this,r.username,r.expiresAt,r.plan,r.adultAccess,r.bouquet,r.userToken);ApiClient.setUserToken(r.userToken);if(CatalogPreloader.isPrepared(LoginActivity.this)){message.setText("Conteúdo pronto.");openHome();}else{startInitialPreparation();}});}public void error(String m){runOnUiThread(()->{enter.setEnabled(true);enter.setText("ENTRAR");message.setText(m);message.setTextColor(Ui.RED);});}});}
    private void checkServer(){ApiClient.statusInfo(new ApiClient.Callback<ApiClient.AppStatus>(){public void ok(ApiClient.AppStatus st){runOnUiThread(()->{serverBadge.setText("● SERVIDOR ONLINE");serverBadge.setTextColor(Ui.GREEN);trialHours=Math.max(1,st.trialHours);trial.setVisibility(View.VISIBLE);trial.setEnabled(st.trialEnabled);trial.setText((st.trialEnabled?"TESTE AUTOMÁTICO • ":"TESTE INDISPONÍVEL • ")+trialHours+(trialHours==1?" HORA":" HORAS"));if(st.loginBackground!=null&&!st.loginBackground.trim().isEmpty())ImageLoader.into(LoginActivity.this,bgImage,st.loginBackground); if(st.appLogo!=null&&!st.appLogo.trim().isEmpty()){BrandConfig.save(LoginActivity.this,st.appLogo); if(brandLogo!=null)ImageLoader.into(LoginActivity.this,brandLogo,st.appLogo); if(brandMark!=null)brandMark.setVisibility(View.GONE);}});}public void error(String m){runOnUiThread(()->{serverBadge.setText("● SERVIDOR OFFLINE");serverBadge.setTextColor(Ui.RED);trial.setEnabled(false);trial.setText("TESTE AUTOMÁTICO • SERVIDOR OFFLINE");});}});}
    private void doTrial(){if(trial==null)return;trial.setEnabled(false);trial.setText("CRIANDO TESTE...");message.setText("Gerando acesso de teste...");message.setTextColor(Ui.MUTED);ApiClient.trial(DeviceInfo.macOrId(this),new ApiClient.Callback<ApiClient.LoginResult>(){public void ok(ApiClient.LoginResult r){runOnUiThread(()->{Session.save(LoginActivity.this,r.username,r.expiresAt,r.plan,r.adultAccess,r.bouquet,r.userToken);ApiClient.setUserToken(r.userToken);if(CatalogPreloader.isPrepared(LoginActivity.this)){message.setText("Conteúdo pronto.");openHome();}else{startInitialPreparation();}});}public void error(String m){runOnUiThread(()->{trial.setEnabled(true);trial.setText("TESTE AUTOMÁTICO • "+trialHours+(trialHours==1?" HORA":" HORAS"));message.setText(m);message.setTextColor(Ui.RED);});}});}
    private FrameLayout buildLoadingOverlay(){
        FrameLayout ov=new FrameLayout(this); ov.setBackgroundColor(0xF7000905); ov.setClickable(true); ov.setFocusable(true);
        LinearLayout box=Ui.column(this); box.setGravity(Gravity.CENTER); box.setPadding(Ui.dp(this,24),Ui.dp(this,24),Ui.dp(this,24),Ui.dp(this,24));
        ImageView logo=new ImageView(this); logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE); String l=BrandConfig.logo(this); if(l!=null&&!l.trim().isEmpty())ImageLoader.into(this,logo,l); else logo.setImageResource(R.mipmap.ic_launcher);
        box.addView(logo,new LinearLayout.LayoutParams(Ui.dp(this,180),Ui.dp(this,82)));
        loadTitle=Ui.text(this,"Preparando seu conteúdo",phone?20:27,Color.WHITE,true); loadTitle.setGravity(Gravity.CENTER); LinearLayout.LayoutParams t=new LinearLayout.LayoutParams(-1,Ui.dp(this,48)); t.topMargin=Ui.dp(this,12); box.addView(loadTitle,t);
        loadStep=Ui.text(this,"Atualizando canais, filmes e séries...",phone?11:14,Ui.MUTED,true); loadStep.setGravity(Gravity.CENTER); box.addView(loadStep,new LinearLayout.LayoutParams(-1,Ui.dp(this,34)));
        TextView hint=Ui.text(this,"Isso acontece somente na primeira entrada deste cliente.",phone?9:11,0xFF8FA79A,false); hint.setGravity(Gravity.CENTER); box.addView(hint,new LinearLayout.LayoutParams(-1,Ui.dp(this,28)));
        FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(phone?Ui.dp(this,560):Ui.dp(this,720),Ui.dp(this,240),Gravity.CENTER); ov.addView(box,bp); return ov;
    }

    private void startInitialPreparation(){
        if(loadingOverlay!=null){loadingOverlay.setVisibility(View.VISIBLE);loadingOverlay.bringToFront();loadingOverlay.requestFocus();}
        CatalogPreloader.start(this,true,(text,done,total)->runOnUiThread(()->{
            if(loadStep!=null)loadStep.setText(text+(total>0?"   "+done+"/"+total:""));
        }),()->runOnUiThread(this::openHome));
    }

    private boolean hasNetwork(){try{ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);NetworkInfo n=cm==null?null:cm.getActiveNetworkInfo();return n!=null&&n.isConnected();}catch(Throwable e){return false;}}
    private void showDiagnostic(){final Dialog d=new Dialog(this);d.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout box=Ui.column(this);box.setPadding(Ui.dp(this,24),Ui.dp(this,20),Ui.dp(this,24),Ui.dp(this,20));box.setBackground(Ui.stroke(Ui.PANEL,Ui.BORDER,18,this));TextView t=Ui.text(this,"Diagnóstico de rede",18,Ui.TEXT,true);t.setGravity(Gravity.CENTER);box.addView(t,new LinearLayout.LayoutParams(-1,Ui.dp(this,40)));LinearLayout steps=new LinearLayout(this);steps.setGravity(Gravity.CENTER);TextView a=step("BOX",Ui.GREEN),b=step("REDE",hasNetwork()?Ui.GREEN:Ui.RED),c=step("INTERNET",hasNetwork()?Ui.GREEN:Ui.RED),s=step("SERVIDOR",Ui.MUTED);for(TextView v:new TextView[]{a,b,c,s}){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(Ui.dp(this,95),Ui.dp(this,60));p.leftMargin=Ui.dp(this,5);p.rightMargin=Ui.dp(this,5);steps.addView(v,p);}box.addView(steps,new LinearLayout.LayoutParams(-1,Ui.dp(this,72)));TextView result=Ui.text(this,"Testando servidor...",11,Ui.MUTED,true);result.setGravity(Gravity.CENTER);box.addView(result,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));TextView close=Ui.button(this,"FECHAR");close.setOnClickListener(v->d.dismiss());box.addView(close,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));d.setContentView(box);Window w=d.getWindow();d.show();if(w!=null){w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));w.setLayout(Math.min(Ui.dp(this,520),getResources().getDisplayMetrics().widthPixels-Ui.dp(this,24)),WindowManager.LayoutParams.WRAP_CONTENT);}ApiClient.status(new ApiClient.Callback<String>(){public void ok(String x){runOnUiThread(()->{s.setTextColor(Ui.GREEN);result.setText("✓ Servidor online e acessível");result.setTextColor(Ui.GREEN);});}public void error(String m){runOnUiThread(()->{s.setTextColor(Ui.RED);result.setText("Falha: "+m);result.setTextColor(Ui.RED);});}});}
    private TextView step(String txt,int color){TextView v=Ui.text(this,"●\n"+txt,10,color,true);v.setGravity(Gravity.CENTER);v.setBackground(Ui.stroke(Color.rgb(12,16,20),color,11,this));return v;}
    private void openHome(){Intent in=new Intent(this,LiveTvActivity.class);in.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(in);finish();}
}
