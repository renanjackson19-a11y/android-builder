package com.ativacao.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.InputType;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.graphics.drawable.Drawable;
import android.widget.LinearLayout;
import android.widget.TextView;

public class LoginActivity extends Activity {
    private EditText user,pass; private TextView message,serverBadge,enter,trial,brandMark,loadTitle,loadStep; private ImageView bgImage,brandLogo; private FrameLayout loadingOverlay; private boolean phone; private int trialHours=3;
    @Override public void onCreate(Bundle b){super.onCreate(b);ApiClient.setUserToken(Session.token(this));getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);Ui.immersive(this);if(Session.isLogged(this)){openHome();return;}phone=Ui.phone(this);setContentView(build());checkServer();}
    @Override protected void onResume(){super.onResume();Ui.immersive(this);}

    private View build(){
        FrameLayout root=new FrameLayout(this); root.setBackgroundColor(Color.BLACK);
        final int sw=getResources().getDisplayMetrics().widthPixels;
        final int sh=getResources().getDisplayMetrics().heightPixels;
        final boolean landscape=sw>sh;

        // Fundo do login: sempre vem do painel e ocupa a tela inteira.
        bgImage=new ImageView(this);
        bgImage.setScaleType(ImageView.ScaleType.FIT_XY);
        bgImage.setBackgroundColor(Color.BLACK);
        bgImage.setBackgroundColor(0xFF020705);
        root.addView(bgImage,new FrameLayout.LayoutParams(-1,-1));
        ImageLoader.intoBackground(this,bgImage,"https://i.postimg.cc/Y0gvd14L/file-00000000e184820e9e1ac36d0c3e2978.png");

        // Escurece somente a região direita para o formulário continuar legível
        // sem criar um card sólido sobre a arte enviada pelo painel.
        if(landscape){
            View shade=new View(this);
            shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{0x00000000,0x26000000,0xB5000000}));
            FrameLayout.LayoutParams slp=new FrameLayout.LayoutParams(Math.round(sw*0.54f),-1,Gravity.RIGHT);
            root.addView(shade,slp);
        }

        // IMPORTANTE: TV/TV Box em paisagem usa largura fixa proporcional à tela.
        // Não depende de Ui.phone(), pois alguns boxes eram detectados como telefone
        // e o formulário acabava ocupando 72% da tela e ficando cortado.
        LinearLayout right=Ui.column(this);
        int formPad=Ui.dp(this,landscape?14:18);
        right.setPadding(formPad,0,formPad,0);
        int formW=landscape?Math.round(sw*0.42f):Math.round(sw*0.90f);
        FrameLayout.LayoutParams rightLp=new FrameLayout.LayoutParams(formW,FrameLayout.LayoutParams.WRAP_CONTENT,
                landscape?(Gravity.RIGHT|Gravity.CENTER_VERTICAL):(Gravity.CENTER_HORIZONTAL|Gravity.CENTER_VERTICAL));
        if(landscape) rightLp.rightMargin=Ui.dp(this,28);
        if(landscape) rightLp.topMargin=Ui.dp(this,10);
        root.addView(right,rightLp);

        // Cabeçalho centralizado no bloco. O indicador de servidor continua funcional,
        // mas fica oculto para não criar o ponto verde solto no canto da tela.
        TextView head=Ui.text(this,"BEM-VINDO!",landscape?23:23,Color.WHITE,true);
        head.setGravity(Gravity.CENTER);
        SpannableString hs=new SpannableString("BEM-VINDO!");
        hs.setSpan(new ForegroundColorSpan(Ui.GREEN),4,10,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        head.setText(hs);
        head.setGravity(Gravity.CENTER);
        right.addView(head,new LinearLayout.LayoutParams(-1,Ui.dp(this,32)));
        serverBadge=Ui.text(this,"",1,Color.TRANSPARENT,false);
TextView desc=Ui.text(this,"Digite seu usuário e senha para acessar o aplicativo.",landscape?11:10,0xFFD0D4D2,false);
        desc.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams descLp=new LinearLayout.LayoutParams(-1,Ui.dp(this,20));
        descLp.bottomMargin=Ui.dp(this,8); right.addView(desc,descLp);

        right.addView(label("Usuário"),new LinearLayout.LayoutParams(-1,Ui.dp(this,16)));
        user=field("Por favor insira seu usuário",false);
        user.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_NEXT);
        setFieldIcon(user,R.drawable.ic_login_user);
        LinearLayout.LayoutParams up=new LinearLayout.LayoutParams(-1,Ui.dp(this,48));
        up.bottomMargin=Ui.dp(this,8); right.addView(user,up);

        right.addView(label("Senha"),new LinearLayout.LayoutParams(-1,Ui.dp(this,16)));
        FrameLayout passBox=new FrameLayout(this);
        pass=field("Por favor insira sua senha",true);
        pass.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_DONE);
        setFieldIcon(pass,R.drawable.ic_login_lock);
        passBox.addView(pass,new FrameLayout.LayoutParams(-1,Ui.dp(this,48)));
        ImageView eye=new ImageView(this); eye.setImageResource(R.drawable.ic_login_eye); eye.setScaleType(ImageView.ScaleType.CENTER_INSIDE); eye.setPadding(Ui.dp(this,12),Ui.dp(this,12),Ui.dp(this,12),Ui.dp(this,12)); eye.setFocusable(true); eye.setClickable(true);
        FrameLayout.LayoutParams eyp=new FrameLayout.LayoutParams(Ui.dp(this,48),Ui.dp(this,48),Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        passBox.addView(eye,eyp); pass.setPadding(Ui.dp(this,18),0,Ui.dp(this,58),0);
        final boolean[] showing={false};
        eye.setOnClickListener(v->{showing[0]=!showing[0];int pos=pass.getSelectionStart();pass.setInputType(InputType.TYPE_CLASS_TEXT|(showing[0]?InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD:InputType.TYPE_TEXT_VARIATION_PASSWORD));pass.setSelection(Math.max(0,Math.min(pos,pass.length())));eye.setImageResource(showing[0]?R.drawable.ic_login_eye_off:R.drawable.ic_login_eye);});
        LinearLayout.LayoutParams pbp=new LinearLayout.LayoutParams(-1,Ui.dp(this,48));
        pbp.bottomMargin=Ui.dp(this,10); right.addView(passBox,pbp);

        enter=Ui.primaryButton(this,"ENTRAR");
        softenButton(enter,true);
        setButtonIcon(enter,R.drawable.ic_login_enter);
        right.addView(enter,new LinearLayout.LayoutParams(-1,Ui.dp(this,48)));

        TextView test=Ui.button(this,"TESTAR CONEXÃO");
        softenButton(test,false);
        setButtonIcon(test,R.drawable.ic_login_wifi);
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,Ui.dp(this,42));
        tp.topMargin=Ui.dp(this,8); right.addView(test,tp);

        trial=Ui.button(this,"TESTE AUTOMÁTICO  •  3 HORAS");
        softenButton(trial,false);
        setButtonIcon(trial,R.drawable.ic_login_clock);
        LinearLayout.LayoutParams trp=new LinearLayout.LayoutParams(-1,Ui.dp(this,42));
        trp.topMargin=Ui.dp(this,7); right.addView(trial,trp);

        message=Ui.text(this,"",10,Ui.MUTED,false); message.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,Ui.dp(this,14));
        mp.topMargin=Ui.dp(this,3); right.addView(message,mp);

        // ID e versão ficam discretos no canto inferior esquerdo, por cima do fundo.
        TextView dev=Ui.text(this,"▣  ID Dispositivo: "+DeviceInfo.macOrId(this)+"\nⓘ  Versão: 4.0.144",landscape?10:9,0xFFE0E6E2,false);
        dev.setLineSpacing(Ui.dp(this,2),1.10f);
        FrameLayout.LayoutParams devLp=new FrameLayout.LayoutParams(landscape?Ui.dp(this,470):Math.round(sw*0.88f),Ui.dp(this,52),Gravity.LEFT|Gravity.BOTTOM);
        devLp.leftMargin=Ui.dp(this,landscape?42:18); devLp.bottomMargin=Ui.dp(this,landscape?18:16);
        root.addView(dev,devLp);

        // Logo/fundo não são fixos no APK: o painel continua sendo a única fonte da arte.
        brandLogo=new ImageView(this); brandMark=null;

        enter.setOnClickListener(v->doLogin()); trial.setOnClickListener(v->doTrial()); test.setOnClickListener(v->showDiagnostic());
        pass.setOnEditorActionListener((v,a,e)->{doLogin();return true;}); user.requestFocus();
        loadingOverlay=buildLoadingOverlay(); root.addView(loadingOverlay,new FrameLayout.LayoutParams(-1,-1)); loadingOverlay.setVisibility(View.GONE);
        return root;
    }
    private TextView label(String s){return Ui.text(this,s,10,Color.WHITE,true);}
    private EditText field(String hint,boolean password){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(0xFF727B86);e.setTextColor(Color.WHITE);e.setTextSize(phone?12:14);e.setSingleLine(true);e.setPadding(Ui.dp(this,18),0,Ui.dp(this,18),0);e.setBackground(Ui.stroke(0xD9141921,0xFF33414B,28,this));if(password)e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);e.setOnFocusChangeListener((v,f)->e.setBackground(Ui.stroke(0xD9141921,f?Ui.GREEN:0xFF33414B,28,this)));return e;}
    private void doLogin(){
        String u=user.getText().toString().trim(),p=pass.getText().toString();
        if(u.isEmpty()||p.isEmpty()){
            message.setText("Informe usuário e senha.");
            message.setTextColor(Ui.RED);
            return;
        }

        // Ao tocar em CONCLUÍDO/ENTER, some com o teclado imediatamente
        // e mostra a tela de carregamento. O usuário não fica olhando a tela parada.
        hideKeyboard();
        showLoginLoading("Conectando...","Validando usuário e senha...");

        enter.setEnabled(false);
        enter.setText("ENTRANDO...");
        message.setText("Validando acesso...");
        message.setTextColor(Ui.MUTED);

        ApiClient.login(u,p,DeviceInfo.macOrId(this),new ApiClient.Callback<ApiClient.LoginResult>(){
            public void ok(ApiClient.LoginResult r){
                runOnUiThread(()->{
                    Session.save(LoginActivity.this,r.username,r.expiresAt,r.plan,r.adultAccess,r.bouquet,r.userToken);
                    ApiClient.setUserToken(r.userToken);

                    if(loadTitle!=null)loadTitle.setText("Carregando conteúdos");
                    if(loadStep!=null)loadStep.setText("Preparando canais, filmes e séries...");

                    if(CatalogPreloader.isPrepared(LoginActivity.this)){
                        if(loadStep!=null)loadStep.setText("Conteúdo pronto");
                        openHome();
                    }else{
                        startInitialPreparation();
                    }
                });
            }

            public void error(String m){
                runOnUiThread(()->{
                    if(loadingOverlay!=null)loadingOverlay.setVisibility(View.GONE);
                    enter.setEnabled(true);
                    enter.setText("ENTRAR");
                    message.setText(m);
                    message.setTextColor(Ui.RED);
                    user.requestFocus();
                });
            }
        });
    }

    private void hideKeyboard(){
        try{
            InputMethodManager imm=(InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            View v=getCurrentFocus();
            if(imm!=null&&v!=null)imm.hideSoftInputFromWindow(v.getWindowToken(),0);
        }catch(Throwable ignored){}
        user.clearFocus();
        pass.clearFocus();
    }

    private void showLoginLoading(String title,String step){
        if(loadingOverlay==null)return;
        if(loadTitle!=null)loadTitle.setText(title);
        if(loadStep!=null)loadStep.setText(step);
        loadingOverlay.setVisibility(View.VISIBLE);
        loadingOverlay.bringToFront();
        loadingOverlay.requestFocus();
    }

    private void checkServer(){ApiClient.statusInfo(new ApiClient.Callback<ApiClient.AppStatus>(){public void ok(ApiClient.AppStatus st){runOnUiThread(()->{

trialHours=Math.max(1,st.trialHours);trial.setVisibility(View.VISIBLE);trial.setEnabled(st.trialEnabled);trial.setText((st.trialEnabled?"TESTE AUTOMÁTICO • ":"TESTE INDISPONÍVEL • ")+trialHours+(trialHours==1?" HORA":" HORAS"));if(st.loginBackground!=null&&!st.loginBackground.trim().isEmpty())ImageLoader.intoBackground(LoginActivity.this,bgImage,st.loginBackground); else ImageLoader.intoBackground(LoginActivity.this,bgImage,"https://i.postimg.cc/Y0gvd14L/file-00000000e184820e9e1ac36d0c3e2978.png"); if(st.appLogo!=null&&!st.appLogo.trim().isEmpty()){BrandConfig.save(LoginActivity.this,st.appLogo);}
                    BrandConfig.saveInternalBackground(LoginActivity.this,st.internalBackground);});}public void error(String m){runOnUiThread(()->{

trial.setEnabled(false);trial.setText("TESTE AUTOMÁTICO • SERVIDOR OFFLINE");});}});}
    private void doTrial(){if(trial==null)return;trial.setEnabled(false);trial.setText("CRIANDO TESTE...");message.setText("Gerando acesso de teste...");message.setTextColor(Ui.MUTED);ApiClient.trial(DeviceInfo.macOrId(this),new ApiClient.Callback<ApiClient.LoginResult>(){public void ok(ApiClient.LoginResult r){runOnUiThread(()->{Session.save(LoginActivity.this,r.username,r.expiresAt,r.plan,r.adultAccess,r.bouquet,r.userToken);ApiClient.setUserToken(r.userToken);if(CatalogPreloader.isPrepared(LoginActivity.this)){message.setText("Conteúdo pronto.");openHome();}else{startInitialPreparation();}});}public void error(String m){runOnUiThread(()->{trial.setEnabled(true);trial.setText("TESTE AUTOMÁTICO • "+trialHours+(trialHours==1?" HORA":" HORAS"));message.setText(m);message.setTextColor(Ui.RED);});}});}
    private FrameLayout buildLoadingOverlay(){
        FrameLayout ov=new FrameLayout(this); ov.setBackgroundColor(0xF7000905); ov.setClickable(true); ov.setFocusable(true);
        LinearLayout box=Ui.column(this); box.setGravity(Gravity.CENTER); box.setPadding(Ui.dp(this,24),Ui.dp(this,24),Ui.dp(this,24),Ui.dp(this,24));
        ImageView logo=new ImageView(this); logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE); String l=BrandConfig.logo(this); if(l!=null&&!l.trim().isEmpty())ImageLoader.into(this,logo,l); else logo.setImageResource(R.mipmap.ic_launcher);
        box.addView(logo,new LinearLayout.LayoutParams(Ui.dp(this,180),Ui.dp(this,82)));
        loadTitle=Ui.text(this,"Preparando seu conteúdo",phone?20:27,Color.WHITE,true); loadTitle.setGravity(Gravity.CENTER); LinearLayout.LayoutParams t=new LinearLayout.LayoutParams(-1,Ui.dp(this,48)); t.topMargin=Ui.dp(this,12); box.addView(loadTitle,t);
        loadStep=Ui.text(this,"Atualizando canais, filmes e séries...",phone?11:14,Ui.MUTED,true); loadStep.setGravity(Gravity.CENTER); box.addView(loadStep,new LinearLayout.LayoutParams(-1,Ui.dp(this,34)));
        TextView hint=Ui.text(this,"Isso acontece somente na primeira entrada deste cliente.",phone?9:11,0xFF8FA79A,false); hint.setGravity(Gravity.CENTER); box.addView(hint,new LinearLayout.LayoutParams(-1,Ui.dp(this,28)));
        FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(phone?Ui.dp(this,560):Ui.dp(this,720),Ui.dp(this,240),Gravity.CENTER); ov.addView(box,bp); return ov;
    }

    private void startInitialPreparation(){
        showLoginLoading("Carregando conteúdos","Atualizando canais, filmes e séries...");
        CatalogPreloader.start(this,true,(text,done,total)->runOnUiThread(()->{
            if(loadStep!=null)loadStep.setText(text+(total>0?"   "+done+"/"+total:""));
        }),()->runOnUiThread(this::openHome));
    }

    private boolean hasNetwork(){try{ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);NetworkInfo n=cm==null?null:cm.getActiveNetworkInfo();return n!=null&&n.isConnected();}catch(Throwable e){return false;}}
    private void showDiagnostic(){
        final Dialog d=new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box=Ui.column(this);
        box.setPadding(Ui.dp(this,24),Ui.dp(this,20),Ui.dp(this,24),Ui.dp(this,20));
        box.setBackground(Ui.stroke(Ui.PANEL,Ui.BORDER,18,this));

        TextView t=Ui.text(this,"Diagnóstico de rede",18,Ui.TEXT,true);
        t.setGravity(Gravity.CENTER);
        box.addView(t,new LinearLayout.LayoutParams(-1,Ui.dp(this,40)));

        LinearLayout steps=new LinearLayout(this);
        steps.setGravity(Gravity.CENTER);
        TextView a=step("BOX",Ui.MUTED),b=step("REDE",Ui.MUTED),c=step("INTERNET",Ui.MUTED),sv=step("SERVIDOR",Ui.MUTED);
        for(TextView v:new TextView[]{a,b,c,sv}){
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(Ui.dp(this,95),Ui.dp(this,60));
            p.leftMargin=Ui.dp(this,5);p.rightMargin=Ui.dp(this,5);steps.addView(v,p);
        }
        box.addView(steps,new LinearLayout.LayoutParams(-1,Ui.dp(this,72)));

        TextView result=Ui.text(this,"Verificando dispositivo...",11,Ui.MUTED,true);
        result.setGravity(Gravity.CENTER);
        box.addView(result,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));

        TextView close=Ui.button(this,"FECHAR");
        close.setOnClickListener(v->d.dismiss());
        box.addView(close,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));

        d.setContentView(box); d.show();
        Window w=d.getWindow();
        if(w!=null){
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setLayout(Math.min(Ui.dp(this,520),getResources().getDisplayMetrics().widthPixels-Ui.dp(this,24)),
                    WindowManager.LayoutParams.WRAP_CONTENT);
        }

        final android.os.Handler h=new android.os.Handler(android.os.Looper.getMainLooper());
        h.postDelayed(()->{
            if(!d.isShowing())return;
            setStepState(a,"BOX",true);
            result.setText("Verificando rede...");
        },350);

        h.postDelayed(()->{
            if(!d.isShowing())return;
            boolean network=hasNetwork();
            setStepState(b,"REDE",network);
            if(!network){
                result.setText("✕ Sem conexão de rede");
                result.setTextColor(Ui.RED);
                return;
            }
            result.setText("Testando acesso à internet...");
            h.postDelayed(()->{
                if(!d.isShowing())return;
                setStepState(c,"INTERNET",true);
                result.setText("Conectando ao servidor...");
                ApiClient.status(new ApiClient.Callback<String>(){
                    public void ok(String x){runOnUiThread(()->{
                        if(!d.isShowing())return;
                        setStepState(sv,"SERVIDOR",true);
                        result.setText("✓ Tudo funcionando corretamente");
                        result.setTextColor(Ui.GREEN);
                    });}
                    public void error(String m){runOnUiThread(()->{
                        if(!d.isShowing())return;
                        setStepState(sv,"SERVIDOR",false);
                        result.setText("✕ Servidor indisponível");
                        result.setTextColor(Ui.RED);
                    });}
                });
            },450);
        },800);
    }

    private void setStepState(TextView v,String name,boolean ok){
        int color=ok?Ui.GREEN:Ui.RED;
        v.setText((ok?"✓":"✕")+"\n"+name);
        v.setTextColor(color);
        v.setBackground(Ui.stroke(Color.rgb(12,16,20),color,11,this));
    }

    private TextView step(String txt,int color){TextView v=Ui.text(this,"●\n"+txt,10,color,true);v.setGravity(Gravity.CENTER);v.setBackground(Ui.stroke(Color.rgb(12,16,20),color,11,this));return v;}
    private void openHome(){Intent in=new Intent(this,LiveTvActivity.class);in.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(in);finish();}

    private void setFieldIcon(EditText e,int res){
        Drawable d=getResources().getDrawable(res);
        int sz=Ui.dp(this,22); d.setBounds(0,0,sz,sz);
        e.setCompoundDrawables(d,null,null,null);
        e.setCompoundDrawablePadding(Ui.dp(this,12));
        e.setPadding(Ui.dp(this,18),0,Ui.dp(this,18),0);
    }

    private void setButtonIcon(TextView v,int res){
        Drawable d=getResources().getDrawable(res);
        int sz=Ui.dp(this,21); d.setBounds(0,0,sz,sz);
        v.setCompoundDrawables(d,null,null,null);
        v.setCompoundDrawablePadding(Ui.dp(this,10));
    }

    private android.graphics.drawable.GradientDrawable roundedBtnBg(int color, int strokeColor, int radiusDp){
        android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(Ui.dp(this,radiusDp));
        if(strokeColor!=0) g.setStroke(Ui.dp(this,1),strokeColor);
        return g;
    }

    private void softenButton(android.widget.TextView v, boolean primary){
        v.setAllCaps(false);
        v.setGravity(android.view.Gravity.CENTER);
        v.setTextSize(16);
        v.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        v.setBackground(roundedBtnBg(
            primary?android.graphics.Color.rgb(33,215,95):android.graphics.Color.rgb(25,31,35),
            primary?android.graphics.Color.rgb(88,255,135):android.graphics.Color.rgb(56,67,73),
            24
        ));
        v.setTextColor(primary?android.graphics.Color.BLACK:android.graphics.Color.WHITE);
        v.setElevation(Ui.dp(this,2));
    }
}
