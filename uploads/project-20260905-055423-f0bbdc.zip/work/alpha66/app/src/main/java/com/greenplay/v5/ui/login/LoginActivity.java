package com.greenplay.v5.ui.login;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.os.Bundle;
import android.provider.Settings;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.greenplay.v5.BuildConfig;
import com.greenplay.v5.R;
import com.greenplay.v5.core.config.BrandingStore;
import com.greenplay.v5.core.config.AppControlStore;
import com.greenplay.v5.core.config.ServerDirectoryStore;
import com.greenplay.v5.core.network.NetworkProvider;
import com.greenplay.v5.core.network.PanelHost;
import com.greenplay.v5.core.session.SessionStore;
import com.greenplay.v5.core.catalog.LoginCatalogPreloader;
import com.greenplay.v5.data.model.AppConfigResponse;
import com.greenplay.v5.data.model.LoginResponse;
import com.greenplay.v5.data.model.StatusResponse;
import com.greenplay.v5.data.repository.AuthRepository;
import com.greenplay.v5.databinding.ActivityLoginBinding;
import com.greenplay.v5.ui.tv.TvActivity;
import com.greenplay.v5.ui.movies.MovieActivity;
import com.greenplay.v5.ui.series.SeriesActivity;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/** Login universal: painel separado fornece apenas os DNS; autenticação ocorre direto no Xtream. */
public final class LoginActivity extends AppCompatActivity {
    private ActivityLoginBinding b;
    private AuthRepository auth;
    private boolean passwordVisible = false;
    private String deviceId = "";

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        b = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        com.greenplay.v5.core.ui.UniversalUi.apply(this, b.getRoot());
        auth = new AuthRepository(this);
        deviceId = resolveDeviceId();
        b.txtDevice.setText("ID Dispositivo: " + (deviceId.isEmpty() ? "NÃO DISPONÍVEL" : deviceId.toUpperCase()));
        b.txtVersion.setText("Versão: " + BuildConfig.VERSION_NAME);
        b.btnTrial.setVisibility(View.GONE);
        b.btnTrial.setEnabled(false);
        b.btnEnter.setOnClickListener(v -> login());
        b.btnConnection.setOnClickListener(v -> testConnection());
        configurePasswordEye();
        applyCachedBranding();
        refreshControlPanel();

        SessionStore session = new SessionStore(this);
        if (session.isLogged() && !session.user().trim().isEmpty() && !session.pass().isEmpty()) {
            // Nunca reutiliza cegamente o host salvo de uma versão anterior.
            // Revalida as credenciais contra a lista ATUAL do painel separado e
            // migra a sessão automaticamente para o DNS ativo que aceitar a conta.
            b.inputUser.setText(session.user());
            b.inputPass.setText(session.pass());
            setLoading(true, "Validando servidor atual...");
            auth.login(session.user(), session.pass(), deviceId, new AuthRepository.Result() {
                @Override public void success(LoginResponse login) { runOnUiThread(LoginActivity.this::preloadAndOpen); }
                @Override public void error(String message) {
                    runOnUiThread(() -> {
                        session.clear();
                        setLoading(false, message);
                    });
                }
            });
        }
    }

    private String resolveDeviceId() {
        String device = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        return device == null ? "" : device.trim();
    }

    private void configurePasswordEye() {
        b.inputPass.setOnTouchListener((v, event) -> {
            if (event.getAction() != MotionEvent.ACTION_UP || b.inputPass.getCompoundDrawablesRelative()[2] == null) return false;
            int touchStart = b.inputPass.getWidth() - b.inputPass.getPaddingEnd() - b.inputPass.getCompoundDrawablesRelative()[2].getBounds().width() - 24;
            if (event.getX() < touchStart) return false;
            int cursor = b.inputPass.getSelectionStart();
            passwordVisible = !passwordVisible;
            b.inputPass.setTransformationMethod(passwordVisible ? HideReturnsTransformationMethod.getInstance() : PasswordTransformationMethod.getInstance());
            b.inputPass.setSelection(Math.max(0, cursor));
            v.performClick();
            return true;
        });
    }

    private void applyCachedBranding() {
        BrandingStore store = new BrandingStore(this);
        String bg = store.absolute(store.loginBackground());
        if (bg.isEmpty()) bg = store.absolute(store.background());
        if (!bg.isEmpty()) Picasso.get().load(bg).placeholder(R.drawable.login_green_play_default).error(R.drawable.login_green_play_default).noFade().into(b.loginBackground);
        if (!store.showLoginLogo()) {
            b.appLogo.setVisibility(View.GONE);
        } else {
            String logo = store.absolute(store.logo());
            if (!logo.isEmpty()) Picasso.get().load(logo).noFade().into(b.appLogo, new com.squareup.picasso.Callback() {
                @Override public void onSuccess() { b.appLogo.setVisibility(View.VISIBLE); }
                @Override public void onError(Exception e) { b.appLogo.setVisibility(View.GONE); }
            });
            else b.appLogo.setVisibility(View.GONE);
        }
    }

    private void refreshControlPanel() {
        setServerOnline(false);
        NetworkProvider.panel().status().enqueue(new Callback<StatusResponse>() {
            @Override public void onResponse(Call<StatusResponse> call, Response<StatusResponse> response) {
                if (!response.isSuccessful() || response.body() == null) return;
                runOnUiThread(() -> { setServerOnline(true); applyStatus(response.body()); });
            }
            @Override public void onFailure(Call<StatusResponse> call, Throwable t) { runOnUiThread(() -> setServerOnline(false)); }
        });
        NetworkProvider.panel().appConfig().enqueue(new Callback<AppConfigResponse>() {
            @Override public void onResponse(Call<AppConfigResponse> call, Response<AppConfigResponse> response) {
                AppConfigResponse cfg = response.body();
                if (!response.isSuccessful() || cfg == null || !cfg.ok) return;
                if (cfg.branding != null) new BrandingStore(LoginActivity.this).save(cfg.branding);
                new AppControlStore(LoginActivity.this).save(cfg);
                if (cfg.universal != null && cfg.universal.servers != null) new ServerDirectoryStore(LoginActivity.this).save(cfg.universal.servers);
                runOnUiThread(() -> applyCachedBranding());
            }
            @Override public void onFailure(Call<AppConfigResponse> call, Throwable t) { }
        });
    }

    private void applyStatus(StatusResponse st) {
        String bg = absoluteAsset(st.loginBackground);
        if (!bg.isEmpty()) Picasso.get().load(bg).placeholder(R.drawable.login_green_play_default).error(R.drawable.login_green_play_default).noFade().into(b.loginBackground);
        String logo = absoluteAsset(st.appLogo);
        if (!st.showLoginLogo) {
            b.appLogo.setVisibility(View.GONE);
        } else if (!logo.isEmpty()) Picasso.get().load(logo).noFade().into(b.appLogo, new com.squareup.picasso.Callback() {
            @Override public void onSuccess() { b.appLogo.setVisibility(View.VISIBLE); }
            @Override public void onError(Exception e) { b.appLogo.setVisibility(View.GONE); }
        });
    }

    private void login() {
        String user = b.inputUser.getText().toString().trim();
        String pass = b.inputPass.getText().toString();
        if (user.isEmpty() || pass.isEmpty()) { setLoading(false, "Digite usuário e senha"); return; }
        setLoading(true, "Conectando ao servidor IPTV...");
        auth.login(user, pass, deviceId, new AuthRepository.Result() {
            @Override public void success(LoginResponse login) { runOnUiThread(LoginActivity.this::preloadAndOpen); }
            @Override public void error(String message) { runOnUiThread(() -> setLoading(false, message)); }
        });
    }

    private void openTv() {
        AppControlStore control = new AppControlStore(this);
        String start = control.startSection();
        Class<?> target = TvActivity.class;
        if ("movies".equalsIgnoreCase(start) && control.sectionEnabled("movies")) target = MovieActivity.class;
        else if ("series".equalsIgnoreCase(start) && control.sectionEnabled("series")) target = SeriesActivity.class;
        Intent next = new Intent(this, target);
        next.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(next);
        finish();
    }

    private void preloadAndOpen(){
        SessionStore session=new SessionStore(this);
        if(!session.isLogged()){setLoading(false,"Sessão inválida");return;}
        new LoginCatalogPreloader(this,session.host(),session.user(),session.pass(),new LoginCatalogPreloader.Listener(){
            @Override public void status(String text){runOnUiThread(()->setLoading(true,text));}
            @Override public void success(){runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())openTv();});}
            @Override public void error(String message){runOnUiThread(()->setLoading(false,message+" • toque em ENTRAR para tentar novamente"));}
        }).start();
    }

    private void testConnection() {
        b.btnConnection.setEnabled(false);
        View content = getLayoutInflater().inflate(R.layout.dialog_connection_test, null, false);
        AlertDialog dialog = new AlertDialog.Builder(this).setView(content).create();
        dialog.setCancelable(false);
        dialog.setOnShowListener(d -> {
            Window w = dialog.getWindow(); if (w == null) return;
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            int screen = getResources().getDisplayMetrics().widthPixels;
            int max = (int)(760f * getResources().getDisplayMetrics().density);
            w.setLayout(Math.min(max, (int)(screen * 0.76f)), WindowManager.LayoutParams.WRAP_CONTENT);
        });
        TextView iptvName=content.findViewById(R.id.txtIptvName), sourceName=content.findViewById(R.id.txtSourceName), internet=content.findViewById(R.id.statusInternet), panel=content.findViewById(R.id.statusPanel), config=content.findViewById(R.id.statusConfig), server=content.findViewById(R.id.statusServer), result=content.findViewById(R.id.txtConnectionResult), close=content.findViewById(R.id.btnCloseConnection);
        View spinner=content.findViewById(R.id.connectionProgress);
        close.setEnabled(false); close.setAlpha(.45f); close.setOnClickListener(v->dialog.dismiss()); dialog.show();
        boolean net=hasInternet(); setStep(internet, net?"OK":"ERRO", net?0xFF4BE17A:0xFFFF6B76);
        if(!net){finishConnection(dialog,spinner,close,result,"Sem internet",false);return;}
        setStep(panel,"TESTANDO...",0xFFF6C84C);
        NetworkProvider.panel().appConfig().enqueue(new Callback<AppConfigResponse>() {
            @Override public void onResponse(Call<AppConfigResponse> call, Response<AppConfigResponse> response) {
                AppConfigResponse cfg=response.body(); boolean ok=response.isSuccessful()&&cfg!=null&&cfg.ok;
                runOnUiThread(()->setStep(panel,ok?"OK":"ERRO",ok?0xFF4BE17A:0xFFFF6B76));
                if(!ok){runOnUiThread(()->finishConnection(dialog,spinner,close,result,"Painel do aplicativo indisponível",false));return;}
                if(cfg.branding!=null)new BrandingStore(LoginActivity.this).save(cfg.branding);
                new AppControlStore(LoginActivity.this).save(cfg);
                List<AppConfigResponse.Server> servers=cfg.universal!=null&&cfg.universal.servers!=null?cfg.universal.servers:new ArrayList<>();
                new ServerDirectoryStore(LoginActivity.this).save(servers);
                runOnUiThread(()->setStep(config,servers.isEmpty()?"SEM SERVIDOR":"OK",servers.isEmpty()?0xFFFF6B76:0xFF4BE17A));
                if(servers.isEmpty()){runOnUiThread(()->finishConnection(dialog,spinner,close,result,"Cadastre um servidor IPTV no painel do app",false));return;}
                AppConfigResponse.Server s=servers.get(0); runOnUiThread(()->{iptvName.setText("IPTV: "+(s.name==null?"SERVIDOR":s.name.toUpperCase()));sourceName.setText(s.host);sourceName.setVisibility(View.VISIBLE);setStep(server,"TESTANDO...",0xFFF6C84C);});
                String u=b.inputUser.getText().toString().trim(), p=b.inputPass.getText().toString();
                if(u.isEmpty()||p.isEmpty()){runOnUiThread(()->{setStep(server,"CONFIGURADO",0xFF4BE17A);finishConnection(dialog,spinner,close,result,"Servidor configurado • informe usuário e senha para validar a conta",true);});return;}
                NetworkProvider.xtream(s.host).authenticate(u,p).enqueue(new Callback<JsonObject>() {
                    @Override public void onResponse(Call<JsonObject> c, Response<JsonObject> r) { boolean authOk=r.isSuccessful()&&r.body()!=null&&authorized(r.body());runOnUiThread(()->{setStep(server,authOk?"OK":"ACESSO NEGADO",authOk?0xFF4BE17A:0xFFFF6B76);finishConnection(dialog,spinner,close,result,authOk?"Conexão e credenciais válidas":"Servidor respondeu, mas usuário/senha não foram aceitos",authOk);}); }
                    @Override public void onFailure(Call<JsonObject> c, Throwable t) { runOnUiThread(()->{setStep(server,"ERRO",0xFFFF6B76);finishConnection(dialog,spinner,close,result,"Servidor IPTV não respondeu",false);}); }
                });
            }
            @Override public void onFailure(Call<AppConfigResponse> call, Throwable t) { runOnUiThread(()->{setStep(panel,"ERRO",0xFFFF6B76);finishConnection(dialog,spinner,close,result,"Sem conexão com o painel do aplicativo",false);}); }
        });
    }

    private static boolean authorized(JsonObject root){try{JsonElement e=root.get("user_info");if(e==null||!e.isJsonObject())return false;JsonObject u=e.getAsJsonObject();String a=u.has("auth")&&!u.get("auth").isJsonNull()?u.get("auth").getAsString():"";String s=u.has("status")&&!u.get("status").isJsonNull()?u.get("status").getAsString():"";return "1".equals(a)||"true".equalsIgnoreCase(a)||"active".equalsIgnoreCase(s);}catch(Exception ex){return false;}}
    private void setStep(TextView v,String text,int color){if(v!=null){v.setText(text);v.setTextColor(color);}}
    private void finishConnection(AlertDialog d,View spinner,TextView close,TextView result,String msg,boolean ok){b.btnConnection.setEnabled(true);if(spinner!=null)spinner.setVisibility(View.GONE);if(result!=null){result.setText(msg);result.setTextColor(ok?0xFF4BE17A:0xFFFF8B94);}if(close!=null){close.setEnabled(true);close.setAlpha(1f);close.requestFocus();}}
    private boolean hasInternet(){try{ConnectivityManager cm=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);android.net.Network n=cm.getActiveNetwork();if(n==null)return false;NetworkCapabilities c=cm.getNetworkCapabilities(n);return c!=null&&c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);}catch(Exception e){return true;}}
    private void setServerOnline(boolean online){b.serverDot.setBackgroundResource(online?R.drawable.bg_status_online:R.drawable.bg_status_offline);}
    private String absoluteAsset(String raw){if(raw==null)return "";String s=raw.trim();if(s.isEmpty())return "";if(s.startsWith("http://")||s.startsWith("https://"))return s;String root=PanelHost.root();if(root.endsWith("/"))root=root.substring(0,root.length()-1);return root+(s.startsWith("/")?s:"/"+s);}
    private void setLoading(boolean loading,String text){
        b.progress.setVisibility(View.GONE);
        b.btnEnter.setEnabled(!loading);
        b.btnConnection.setEnabled(!loading);
        if(loading){
            b.loadingCard.setVisibility(View.VISIBLE);
            b.loadingCenterProgress.setVisibility(View.VISIBLE);
            b.loadingStatus.setText(text==null||text.trim().isEmpty()?"Preparando...":text.trim());
            b.txtError.setText("");
            b.txtError.setVisibility(View.GONE);
        }else{
            b.loadingCard.setVisibility(View.GONE);
            String msg=text==null?"":text.trim();
            b.txtError.setTextColor(0xFFFF7979);
            b.txtError.setText(msg);
            b.txtError.setVisibility(msg.isEmpty()?View.GONE:View.VISIBLE);
        }
    }
}
