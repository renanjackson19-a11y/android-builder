package com.greenplay.v5.data.repository;

import android.content.Context;
import android.os.Build;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.greenplay.v5.core.config.BrandingStore;
import com.greenplay.v5.core.config.ServerDirectoryStore;
import com.greenplay.v5.core.network.HostNormalizer;
import com.greenplay.v5.core.network.NetworkProvider;
import com.greenplay.v5.core.session.SessionStore;
import com.greenplay.v5.data.model.AppConfigResponse;
import com.greenplay.v5.data.model.LoginResponse;
import com.greenplay.v5.data.model.DeviceResponse;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.net.NetworkInterface;
import java.util.Collections;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/** Login universal: painel do app entrega DNS; usuário/senha são validados direto no Xtream. */
public final class AuthRepository {
    public interface Result { void success(LoginResponse login); void error(String message); }

    private final Context context;
    private final SessionStore session;
    private final ServerDirectoryStore directory;

    public AuthRepository(Context context) {
        this.context = context.getApplicationContext();
        this.session = new SessionStore(this.context);
        this.directory = new ServerDirectoryStore(this.context);
    }

    public void login(String user, String pass, String deviceId, Result result) {
        NetworkProvider.panel().appConfig().enqueue(new Callback<AppConfigResponse>() {
            @Override public void onResponse(Call<AppConfigResponse> call, Response<AppConfigResponse> response) {
                AppConfigResponse cfg = response.body();
                List<AppConfigResponse.Server> servers = new ArrayList<>();
                if (response.isSuccessful() && cfg != null && cfg.ok) {
                    if (cfg.branding != null) new BrandingStore(context).save(cfg.branding);
                    if (cfg.universal != null && cfg.universal.servers != null) {
                        servers.addAll(cfg.universal.servers);
                        directory.save(servers);
                    }
                }
                if (servers.isEmpty()) servers.addAll(directory.load());
                tryServers(servers, 0, user, pass, deviceId, result);
            }

            @Override public void onFailure(Call<AppConfigResponse> call, Throwable t) {
                tryServers(directory.load(), 0, user, pass, deviceId, result);
            }
        });
    }

    private void tryServers(List<AppConfigResponse.Server> servers, int index, String user, String pass, String deviceId, Result result) {
        if (servers == null || servers.isEmpty()) {
            result.error("Nenhum servidor IPTV ativo no painel do aplicativo");
            return;
        }
        if (index >= servers.size()) {
            result.error("Usuário ou senha inválidos nos servidores disponíveis");
            return;
        }
        AppConfigResponse.Server server = servers.get(index);
        if (server == null || server.host == null || server.host.trim().isEmpty() || (server.type != null && !server.type.isEmpty() && !"xtream".equalsIgnoreCase(server.type))) {
            tryServers(servers, index + 1, user, pass, deviceId, result);
            return;
        }
        String host = HostNormalizer.normalize(server.host);
        NetworkProvider.xtream(host).authenticate(user, pass).enqueue(new Callback<JsonObject>() {
            @Override public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (!response.isSuccessful() || response.body() == null || !isAuthorized(response.body())) {
                    tryServers(servers, index + 1, user, pass, deviceId, result);
                    return;
                }
                JsonObject root = response.body();
                JsonObject ui = object(root, "user_info");
                LoginResponse out = new LoginResponse();
                out.ok = true;
                out.username = first(str(ui, "username"), user);
                out.xtreamPassword = pass;
                out.xtreamHost = host;
                out.expiresAt = expiry(str(ui, "exp_date"));
                out.plan = first(str(ui, "status"), "Active");
                out.maxConnections = intVal(ui, "max_connections");
                out.adultAccess = explicitAdultAccess(ui);
                out.adultPin = str(ui, "adult_pin");
                out.userToken = "";
                registerDeviceAndFinish(deviceId, out.username, pass, host, out, result);
            }

            @Override public void onFailure(Call<JsonObject> call, Throwable t) {
                tryServers(servers, index + 1, user, pass, deviceId, result);
            }
        });
    }


    private void registerDeviceAndFinish(String deviceId, String user, String pass, String host, LoginResponse out, Result result) {
        String id = deviceId == null ? "" : deviceId.trim();
        if (id.isEmpty()) {
            session.save(host, out.username, pass, out.expiresAt, out.plan, out.adultAccess, "");
            result.success(out);
            return;
        }
        NetworkProvider.panel().registerDevice(
                id,
                resolveMac(),
                user,
                pass,
                host,
                Build.MANUFACTURER == null ? "" : Build.MANUFACTURER,
                Build.MODEL == null ? "" : Build.MODEL,
                Build.VERSION.RELEASE == null ? "" : Build.VERSION.RELEASE,
                com.greenplay.v5.BuildConfig.VERSION_NAME
        ).enqueue(new Callback<DeviceResponse>() {
            @Override public void onResponse(Call<DeviceResponse> call, Response<DeviceResponse> response) {
                DeviceResponse d = response.body();
                if (response.isSuccessful() && d != null && (d.blocked || !d.allowed)) {
                    session.clear();
                    result.error(d.message == null || d.message.trim().isEmpty() ? "Este aparelho foi bloqueado no painel" : d.message);
                    return;
                }
                session.save(host, out.username, pass, out.expiresAt, out.plan, out.adultAccess, "");
                result.success(out);
            }
            @Override public void onFailure(Call<DeviceResponse> call, Throwable t) {
                // O painel de controle não deve impedir uma autenticação IPTV válida se estiver momentaneamente offline.
                session.save(host, out.username, pass, out.expiresAt, out.plan, out.adultAccess, "");
                result.success(out);
            }
        });
    }

    private static String resolveMac() {
        try {
            for (NetworkInterface nif : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                byte[] mac = nif.getHardwareAddress();
                if (mac == null || mac.length == 0) continue;
                String name = nif.getName() == null ? "" : nif.getName().toLowerCase(Locale.ROOT);
                if (!(name.startsWith("wlan") || name.startsWith("eth") || name.startsWith("en"))) continue;
                StringBuilder out = new StringBuilder();
                for (byte b : mac) {
                    if (out.length() > 0) out.append(':');
                    out.append(String.format(Locale.US, "%02X", b));
                }
                String value = out.toString();
                if (!value.isEmpty() && !"02:00:00:00:00:00".equals(value)) return value;
            }
        } catch (Exception ignored) { }
        return "";
    }

    private static boolean isAuthorized(JsonObject root) {
        JsonObject ui = object(root, "user_info");
        String auth = str(ui, "auth");
        String status = str(ui, "status");
        return "1".equals(auth) || "true".equalsIgnoreCase(auth) || "active".equalsIgnoreCase(status);
    }

    private static JsonObject object(JsonObject root, String key) {
        try { JsonElement e = root.get(key); return e != null && e.isJsonObject() ? e.getAsJsonObject() : new JsonObject(); }
        catch (Exception e) { return new JsonObject(); }
    }
    private static String str(JsonObject o, String key) {
        try { JsonElement e = o.get(key); return e == null || e.isJsonNull() ? "" : e.getAsString().trim(); }
        catch (Exception e) { return ""; }
    }
    /**
     * Velox-style rule: adult is an explicit server capability, not a guessed title.
     * Legacy external Xtream servers usually omit this field, so they remain compatible.
     */
    private static boolean explicitAdultAccess(JsonObject ui) {
        if (ui == null || !ui.has("adult_access")) return true;
        String v = str(ui, "adult_access");
        return "1".equals(v) || "true".equalsIgnoreCase(v) || "yes".equalsIgnoreCase(v) || "enabled".equalsIgnoreCase(v);
    }

    private static int intVal(JsonObject o, String key) { try { return Integer.parseInt(str(o,key)); } catch(Exception e){ return 0; } }
    private static String first(String a, String b) { return a != null && !a.trim().isEmpty() ? a.trim() : (b == null ? "" : b.trim()); }
    private static String expiry(String unix) {
        try {
            long sec = Long.parseLong(unix);
            if (sec <= 0) return "";
            return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date(sec * 1000L));
        } catch (Exception e) { return unix == null ? "" : unix; }
    }
}
