package com.greenplay.v5.ui.special;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.greenplay.v5.R;
import com.greenplay.v5.core.catalog.CatalogMemory;
import com.greenplay.v5.core.catalog.SpecialCatalogIndex;
import com.greenplay.v5.core.config.AppControlStore;
import com.greenplay.v5.core.config.AppControlSync;
import com.greenplay.v5.core.config.AppNoticeUi;
import com.greenplay.v5.core.config.BrandingStore;
import com.greenplay.v5.core.config.BrandingUi;
import com.greenplay.v5.core.config.NavConfigUi;
import com.greenplay.v5.core.session.SessionStore;
import com.greenplay.v5.core.ui.SpecialSections;
import com.greenplay.v5.data.model.movie.Movie;
import com.greenplay.v5.data.model.movie.MovieCategory;
import com.greenplay.v5.data.model.series.SeriesCategory;
import com.greenplay.v5.data.model.series.SeriesItem;
import com.greenplay.v5.data.repository.MovieRepository;
import com.greenplay.v5.data.repository.SeriesRepository;
import com.greenplay.v5.databinding.ActivitySpecialCatalogBinding;
import com.greenplay.v5.ui.games.GamesActivity;
import com.greenplay.v5.ui.movies.MovieActivity;
import com.greenplay.v5.ui.movies.MovieAdapter;
import com.greenplay.v5.ui.movies.MovieDetailActivity;
import com.greenplay.v5.ui.movies.MovieFavoritesStore;
import com.greenplay.v5.ui.series.SeriesActivity;
import com.greenplay.v5.ui.series.SeriesAdapter;
import com.greenplay.v5.ui.series.SeriesDetailActivity;
import com.greenplay.v5.ui.settings.SettingsActivity;
import com.greenplay.v5.ui.tv.TvActivity;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * V5.0.104 — mantém o layout V5.0.102 e troca KIDS/ANIMES sem travar a tela.
 *
 * A entrada segue a referência enviada pelo usuário: seleção visual menor, com
 * FILMES/SÉRIES e uma faixa de destaques reais do catálogo. A lista continua
 * abrindo na mesma Activity, sem recriação e sem alterar a classificação V5.0.90.
 */
public final class SpecialCatalogActivity extends AppCompatActivity {
    private static final int PAGE_SIZE = 180;
    private static final int PREFETCH = 36;

    private ActivitySpecialCatalogBinding b;
    private SessionStore session;
    private BrandingStore branding;
    private AppControlStore control;
    private Target backgroundTarget;
    private MovieFavoritesStore favorites;
    private MovieAdapter movieAdapter;
    private SeriesAdapter seriesAdapter;
    private GridLayoutManager movieGrid;
    private GridLayoutManager seriesGrid;

    private String mode = "";
    private boolean moviesMode = true;
    private boolean catalogLanding = true;
    private String categoryId = "";
    private String query = "";
    private SpecialCatalogIndex.Scope scope;

    private volatile List<Movie> movieRows = Collections.emptyList();
    private volatile List<SeriesItem> seriesRows = Collections.emptyList();
    private List<MovieCategory> movieCategories = Collections.emptyList();
    private List<SeriesCategory> seriesCategories = Collections.emptyList();
    private final List<Movie> filteredMovies = new ArrayList<>();
    private final List<SeriesItem> filteredSeries = new ArrayList<>();
    private int renderedMovies = 0;
    private int renderedSeries = 0;
    private int generation = 0;
    private boolean hotMoviesDone = true;
    private boolean hotSeriesDone = true;
    private int modeLoadGeneration = 0;
    private int hotScopeBuildGeneration = 0;

    private final ExecutorService modeLoader = Executors.newSingleThreadExecutor();
    private final ExecutorService filter = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Runnable delayedSearch = this::rebuild;
    private final Runnable delayedHotScope = this::buildHotScopeAsync;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        b = ActivitySpecialCatalogBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        com.greenplay.v5.core.ui.UniversalUi.apply(this, b.getRoot());

        session = new SessionStore(this);
        if (!session.isLogged() || session.host().trim().isEmpty()) { finish(); return; }
        mode = normalizeMode(getIntent().getStringExtra(SpecialSections.EXTRA_MODE));
        if (!SpecialSections.valid(mode)) { finish(); return; }

        branding = new BrandingStore(this);
        control = new AppControlStore(this);
        favorites = new MovieFavoritesStore(this, session.host(), session.user());

        setupAdapters();
        bindSearch();
        bindNav();
        bindMediaChooser();
        applyBranding();
        applyModeUi();
        AppNoticeUi.show(this, control);
        AppControlSync.refresh(this, ok -> runOnUiThread(() -> {
            if (ok && !isFinishing()) {
                branding = new BrandingStore(this);
                control = new AppControlStore(this);
                applyBranding();
                applyNavVisibility();
                AppNoticeUi.show(this, control);
            }
        }));

        loadCurrentMode();
    }

    private void loadCurrentMode() {
        final int token = ++modeLoadGeneration;
        final String targetMode = mode;
        categoryId = "";
        query = "";
        if (b.specialSearch.getText() != null && b.specialSearch.getText().length() > 0) b.specialSearch.setText("");
        b.specialError.setText("");
        movieCategories = CatalogMemory.movieCategories();
        seriesCategories = CatalogMemory.seriesCategories();

        if (SpecialSections.HOT.equals(targetMode)) {
            hotMoviesDone = false;
            hotSeriesDone = false;
            movieRows = Collections.emptyList();
            seriesRows = Collections.emptyList();
            scope = SpecialCatalogIndex.buildScope(targetMode, movieCategories, movieRows, seriesCategories, seriesRows);
            showLoading(true);
            showCatalogLanding();
            loadAdultInclusiveCatalog(token);
            return;
        }

        hotMoviesDone = true;
        hotSeriesDone = true;

        // O índice já foi montado no login. Aqui só lemos o cache; não reconstruímos nada na UI.
        scope = SpecialCatalogIndex.cachedScope(targetMode);

        // Prévia já montada no login: resposta instantânea, sem varrer catálogo na thread da tela.
        movieRows = scope.moviePreview;
        seriesRows = scope.seriesPreview;
        showLoading(false);
        showCatalogLanding();

        final SpecialCatalogIndex.Scope targetScope = scope;
        try {
            modeLoader.execute(() -> {
                // A cópia/filtragem completa fica fora da thread da tela.
                List<Movie> allMovies = CatalogMemory.moviesForIds(targetScope.movieIds);
                List<SeriesItem> allSeries = CatalogMemory.seriesForIds(targetScope.seriesIds);
                main.post(() -> {
                    if (isFinishing() || isDestroyed() || token != modeLoadGeneration || !targetMode.equals(mode)) return;
                    movieRows = allMovies == null ? Collections.emptyList() : allMovies;
                    seriesRows = allSeries == null ? Collections.emptyList() : allSeries;
                    if (catalogLanding) updateCatalogPreviews(); else rebuild();
                });
            });
        } catch (java.util.concurrent.RejectedExecutionException ignored) { }
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        String next = normalizeMode(intent == null ? null : intent.getStringExtra(SpecialSections.EXTRA_MODE));
        if (!SpecialSections.valid(next)) return;
        if (next.equals(mode)) return;
        mode = next;
        applyModeUi();
        loadCurrentMode();
    }

    private void setupAdapters() {
        movieAdapter = new MovieAdapter(new MovieAdapter.Listener() {
            @Override public void onOpen(Movie movie) { openMovie(movie); }
            @Override public void onFavorite(Movie movie) { favorites.toggle(movie.id); movieAdapter.refreshFavorite(movie.id); }
            @Override public boolean isFavorite(Movie movie) { return favorites.isFavorite(movie.id); }
        });
        String movieFallback = branding == null ? "" : branding.movieCover();
        if (branding != null && (movieFallback == null || movieFallback.trim().isEmpty())) movieFallback = branding.fallback();
        if (branding != null) movieAdapter.setFallbackPoster(branding.absolute(movieFallback));

        seriesAdapter = new SeriesAdapter(this::openSeries);
        String seriesFallback = branding == null ? "" : branding.seriesCover();
        if (branding != null && (seriesFallback == null || seriesFallback.trim().isEmpty())) seriesFallback = branding.fallback();
        if (branding != null) seriesAdapter.setFallback(branding.absolute(seriesFallback));

        int span = com.greenplay.v5.core.ui.UniversalUi.catalogSpanCount(this);
        movieGrid = new GridLayoutManager(this, span);
        seriesGrid = new GridLayoutManager(this, span);
        b.specialMovieGrid.setLayoutManager(movieGrid);
        b.specialMovieGrid.setAdapter(movieAdapter);
        b.specialMovieGrid.setItemAnimator(null);
        b.specialMovieGrid.setHasFixedSize(true);
        b.specialMovieGrid.setItemViewCacheSize(18);
        b.specialSeriesGrid.setLayoutManager(seriesGrid);
        b.specialSeriesGrid.setAdapter(seriesAdapter);
        b.specialSeriesGrid.setItemAnimator(null);
        b.specialSeriesGrid.setHasFixedSize(true);
        b.specialSeriesGrid.setItemViewCacheSize(18);

        b.specialMovieGrid.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override public void onScrolled(RecyclerView rv, int dx, int dy) {
                if (!moviesMode || dy <= 0 || renderedMovies >= filteredMovies.size()) return;
                if (movieGrid.findLastVisibleItemPosition() >= movieAdapter.getItemCount() - PREFETCH) appendMovies();
            }
        });
        b.specialSeriesGrid.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override public void onScrolled(RecyclerView rv, int dx, int dy) {
                if (moviesMode || dy <= 0 || renderedSeries >= filteredSeries.size()) return;
                if (seriesGrid.findLastVisibleItemPosition() >= seriesAdapter.getItemCount() - PREFETCH) appendSeries();
            }
        });
    }

    private void bindSearch() {
        b.specialSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                query = s == null ? "" : s.toString().trim();
                main.removeCallbacks(delayedSearch);
                main.postDelayed(delayedSearch, 160L);
            }
            @Override public void afterTextChanged(Editable s) { }
        });
    }

    private void bindMediaChooser() {
        b.specialMoviesChoice.setOnClickListener(v -> openMediaCatalog(true));
        b.specialSeriesChoice.setOnClickListener(v -> openMediaCatalog(false));
        b.specialHeroMoviesButton.setOnClickListener(v -> openMediaCatalog(true));
        b.specialHeroSeriesButton.setOnClickListener(v -> openMediaCatalog(false));
    }

    private void showCatalogLanding() {
        catalogLanding = true;
        b.specialCatalogContent.setVisibility(View.GONE);
        b.specialCatalogLanding.setVisibility(View.VISIBLE);
        b.specialCatalogLandingLabel.setText("CATÁLOGO");
        b.specialCatalogLandingTitle.setText(SpecialSections.label(mode));
        updateCatalogPreviews();
        main.post(() -> {
            if (!isFinishing() && !isDestroyed()) b.specialHeroOpenButton.requestFocus();
        });
    }

    private void openMediaCatalog(boolean showMovies) {
        catalogLanding = false;
        b.specialCatalogLanding.setVisibility(View.GONE);
        b.specialCatalogContent.setVisibility(View.VISIBLE);
        switchMedia(showMovies, false);
        main.postDelayed(() -> {
            if (isFinishing() || isDestroyed()) return;
            if (showMovies) b.specialMovieGrid.requestFocus(); else b.specialSeriesGrid.requestFocus();
        }, 70L);
    }

    /** V5.0.101 — home de catálogo no formato das referências Dubai/YellowGo. */
    private void updateCatalogPreviews() {
        final SpecialCatalogIndex.Scope current = scope;
        if (current == null) return;

        ArrayList<Movie> movies = new ArrayList<>();
        for (Movie x : movieRows) {
            if (x == null || !current.movieIds.contains(x.id)) continue;
            movies.add(x);
            if (movies.size() >= 12) break;
        }
        ArrayList<SeriesItem> series = new ArrayList<>();
        for (SeriesItem x : seriesRows) {
            if (x == null || !current.seriesIds.contains(x.id)) continue;
            series.add(x);
            if (series.size() >= 12) break;
        }

        LandingEntry hero = chooseHero(movies, series);
        bindHero(hero);

        ArrayList<LandingEntry> cards = new ArrayList<>();
        int mi = 0, si = 0;
        while (cards.size() < 6 && (mi < movies.size() || si < series.size())) {
            if (si < series.size()) {
                LandingEntry e = LandingEntry.of(series.get(si++));
                if (!sameEntry(hero, e)) cards.add(e);
            }
            if (cards.size() >= 6) break;
            if (mi < movies.size()) {
                LandingEntry e = LandingEntry.of(movies.get(mi++));
                if (!sameEntry(hero, e)) cards.add(e);
            }
        }
        if (cards.isEmpty() && hero != null) cards.add(hero);
        while (!cards.isEmpty() && cards.size() < 6) cards.add(cards.get(cards.size() % Math.max(1, cards.size())));

        bindLandingCard(b.specialMiniCard1, b.specialMiniPoster1, b.specialMiniTitle1, entryAt(cards, 0), true);
        bindLandingCard(b.specialMiniCard2, b.specialMiniPoster2, b.specialMiniTitle2, entryAt(cards, 1), true);
        bindLandingCard(b.specialMiniCard3, b.specialMiniPoster3, b.specialMiniTitle3, entryAt(cards, 2), true);
        bindLandingCard(b.specialMiniCard4, b.specialMiniPoster4, b.specialMiniTitle4, entryAt(cards, 3), true);
        bindRightLandingCard(b.specialRightCard1, b.specialRightBackdrop1, b.specialRightPoster1, b.specialRightTitle1, entryAt(cards, 4));
        bindRightLandingCard(b.specialRightCard2, b.specialRightBackdrop2, b.specialRightPoster2, b.specialRightTitle2, entryAt(cards, 5));
    }

    private LandingEntry chooseHero(List<Movie> movies, List<SeriesItem> series) {
        if (series != null) {
            for (SeriesItem x : series) {
                if (x != null && x.plot != null && !x.plot.trim().isEmpty()) return LandingEntry.of(x);
            }
        }
        if (movies != null && !movies.isEmpty()) return LandingEntry.of(movies.get(0));
        if (series != null && !series.isEmpty()) return LandingEntry.of(series.get(0));
        return null;
    }

    private LandingEntry entryAt(List<LandingEntry> rows, int index) {
        if (rows == null || rows.isEmpty()) return null;
        return rows.get(Math.min(index, rows.size() - 1));
    }

    private boolean sameEntry(LandingEntry a, LandingEntry b) {
        return a != null && b != null && a.series == b.series && a.id == b.id;
    }

    private void bindHero(LandingEntry hero) {
        if (hero == null) {
            b.specialHeroTitle.setText(SpecialSections.label(mode));
            b.specialHeroMeta.setText("CATÁLOGO");
            b.specialHeroSynopsis.setText("Escolha FILMES ou SÉRIES para abrir o catálogo completo.");
            b.specialHeroSection.setText(SpecialSections.label(mode) + " • DESTAQUE");
            b.specialHeroOpenButton.setVisibility(View.GONE);
            loadLandingImage(b.specialHeroBackdrop, "", R.drawable.bg_tv_screen, true);
            loadLandingImage(b.specialHeroPoster, "", R.drawable.nav_movies, false);
            return;
        }

        b.specialHeroSection.setText(SpecialSections.label(mode) + " • DESTAQUE");
        b.specialHeroTitle.setText(hero.name());
        String meta = "";
        if (!hero.year().isEmpty()) meta = hero.year();
        if (!hero.rating().isEmpty()) meta += (meta.isEmpty() ? "" : "  •  ") + "★ " + hero.rating();
        if (meta.isEmpty()) meta = hero.series ? "SÉRIE" : "FILME";
        b.specialHeroMeta.setText(meta);
        String plot = hero.plot();
        b.specialHeroSynopsis.setText(plot.isEmpty() ? "Abra o destaque para ver os detalhes completos deste título." : plot);
        b.specialHeroOpenButton.setVisibility(View.VISIBLE);
        b.specialHeroOpenButton.setOnClickListener(v -> openLandingEntry(hero));
        loadLandingImage(b.specialHeroBackdrop, hero.art(), hero.series ? R.drawable.nav_series : R.drawable.nav_movies, true);
        loadLandingImage(b.specialHeroPoster, hero.art(), hero.series ? R.drawable.nav_series : R.drawable.nav_movies, false);
    }

    private void bindLandingCard(View card, ImageView poster, TextView title, LandingEntry entry, boolean crop) {
        if (card == null || poster == null || title == null) return;
        if (entry == null) {
            card.setVisibility(View.INVISIBLE);
            card.setOnClickListener(null);
            return;
        }
        card.setVisibility(View.VISIBLE);
        title.setText(entry.name());
        loadLandingImage(poster, entry.art(), entry.series ? R.drawable.nav_series : R.drawable.nav_movies, crop);
        card.setOnClickListener(v -> openLandingEntry(entry));
    }

    /** V5.0.102 — pôsteres da direita: fundo preenchido + capa inteira por cima.
     * Evita as faixas pretas grandes do FIT_CENTER sem deformar nem cortar a capa principal. */
    private void bindRightLandingCard(View card, ImageView backdrop, ImageView poster, TextView title, LandingEntry entry) {
        if (card == null || backdrop == null || poster == null || title == null) return;
        if (entry == null) {
            card.setVisibility(View.INVISIBLE);
            card.setOnClickListener(null);
            return;
        }
        card.setVisibility(View.VISIBLE);
        title.setText(entry.name());
        int fallback = entry.series ? R.drawable.nav_series : R.drawable.nav_movies;
        // Fundo ocupa o card inteiro; a capa frontal permanece inteira e proporcional.
        loadLandingImage(backdrop, entry.art(), fallback, true);
        loadLandingImage(poster, entry.art(), fallback, false);
        card.setOnClickListener(v -> openLandingEntry(entry));
    }

    private void openLandingEntry(LandingEntry entry) {
        if (entry == null) return;
        if (entry.series) openSeries(entry.seriesItem); else openMovie(entry.movie);
    }

    private void loadLandingImage(ImageView view, String url, int fallback, boolean crop) {
        if (view == null) return;
        if (url != null && !url.trim().isEmpty()) {
            view.setScaleType(crop ? ImageView.ScaleType.CENTER_CROP : ImageView.ScaleType.FIT_CENTER);
            if (crop) {
                Picasso.get().load(url.trim()).fit().centerCrop().noFade().placeholder(fallback).error(fallback).into(view);
            } else {
                Picasso.get().load(url.trim()).fit().centerInside().noFade().placeholder(fallback).error(fallback).into(view);
            }
        } else {
            view.setImageResource(fallback);
            view.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        }
    }

    private static final class LandingEntry {
        final boolean series;
        final long id;
        final Movie movie;
        final SeriesItem seriesItem;

        private LandingEntry(Movie movie) {
            this.series = false;
            this.movie = movie;
            this.seriesItem = null;
            this.id = movie == null ? 0L : movie.id;
        }

        private LandingEntry(SeriesItem item) {
            this.series = true;
            this.movie = null;
            this.seriesItem = item;
            this.id = item == null ? 0L : item.id;
        }

        static LandingEntry of(Movie movie) { return movie == null ? null : new LandingEntry(movie); }
        static LandingEntry of(SeriesItem series) { return series == null ? null : new LandingEntry(series); }

        String name() {
            String n = series ? seriesItem.name : movie.name;
            return n == null || n.trim().isEmpty() ? (series ? "Série" : "Filme") : n.trim();
        }

        String art() {
            String a = series ? seriesItem.cover : movie.poster;
            return a == null ? "" : a.trim();
        }

        String year() {
            String y = series ? seriesItem.year : movie.year;
            return y == null ? "" : y.trim();
        }

        String rating() {
            String r = series ? seriesItem.rating : movie.rating;
            return r == null ? "" : r.trim();
        }

        String plot() {
            if (!series || seriesItem.plot == null) return "";
            return seriesItem.plot.trim();
        }
    }

    private void switchMedia(boolean showMovies, boolean userAction) {
        if (moviesMode == showMovies && userAction) {
            if (showMovies) b.specialMovieGrid.requestFocus(); else b.specialSeriesGrid.requestFocus();
            return;
        }
        moviesMode = showMovies;
        categoryId = "";
        b.specialMoviesChoice.setSelected(showMovies);
        b.specialSeriesChoice.setSelected(!showMovies);

        // Keep both grids attached. INVISIBLE avoids Activity recreation and black flashes.
        b.specialMovieGrid.setVisibility(showMovies ? View.VISIBLE : View.INVISIBLE);
        b.specialSeriesGrid.setVisibility(showMovies ? View.INVISIBLE : View.VISIBLE);
        b.specialEmpty.setText(showMovies ? "Nenhum filme encontrado" : "Nenhuma série encontrada");
        b.specialEmpty.setVisibility(View.GONE);
        updateLoadingState();
        rebuild();
    }

    private void rebuild() {
        final int g = ++generation;
        final boolean movieSide = moviesMode;
        final String cat = categoryId == null ? "" : categoryId;
        final String q = query == null ? "" : query.toLowerCase(Locale.ROOT);
        final SpecialCatalogIndex.Scope current = scope;
        final List<Movie> movies = movieRows;
        final List<SeriesItem> series = seriesRows;
        if (current == null) return;

        filter.execute(() -> {
            if (movieSide) {
                ArrayList<Movie> out = new ArrayList<>();
                Set<Long> allowed = current.movieIds;
                for (Movie x : movies) {
                    if (x == null || !allowed.contains(x.id)) continue;
                    if (!cat.isEmpty() && !cat.equals(x.categoryId)) continue;
                    if (!q.isEmpty() && (x.name == null || !x.name.toLowerCase(Locale.ROOT).contains(q))) continue;
                    out.add(x);
                }
                runOnUiThread(() -> {
                    if (g != generation || isFinishing() || isDestroyed() || !moviesMode) return;
                    filteredMovies.clear(); filteredMovies.addAll(out);
                    renderedMovies = Math.min(PAGE_SIZE, filteredMovies.size());
                    movieAdapter.replace(renderedMovies == 0 ? Collections.emptyList() : new ArrayList<>(filteredMovies.subList(0, renderedMovies)));
                    b.specialEmpty.setVisibility(filteredMovies.isEmpty() && !isLoading() ? View.VISIBLE : View.GONE);
                    if (movieGrid != null) movieGrid.scrollToPosition(0);
                });
            } else {
                ArrayList<SeriesItem> out = new ArrayList<>();
                Set<Long> allowed = current.seriesIds;
                for (SeriesItem x : series) {
                    if (x == null || !allowed.contains(x.id)) continue;
                    if (!cat.isEmpty() && !cat.equals(x.categoryId)) continue;
                    if (!q.isEmpty() && (x.name == null || !x.name.toLowerCase(Locale.ROOT).contains(q))) continue;
                    out.add(x);
                }
                runOnUiThread(() -> {
                    if (g != generation || isFinishing() || isDestroyed() || moviesMode) return;
                    filteredSeries.clear(); filteredSeries.addAll(out);
                    renderedSeries = Math.min(PAGE_SIZE, filteredSeries.size());
                    seriesAdapter.submit(renderedSeries == 0 ? Collections.emptyList() : new ArrayList<>(filteredSeries.subList(0, renderedSeries)));
                    b.specialEmpty.setVisibility(filteredSeries.isEmpty() && !isLoading() ? View.VISIBLE : View.GONE);
                    if (seriesGrid != null) seriesGrid.scrollToPosition(0);
                });
            }
        });
    }

    private void appendMovies() {
        int end = Math.min(filteredMovies.size(), renderedMovies + PAGE_SIZE);
        if (end <= renderedMovies) return;
        List<Movie> add = new ArrayList<>(filteredMovies.subList(renderedMovies, end));
        renderedMovies = end;
        movieAdapter.append(add);
    }

    private void appendSeries() {
        int end = Math.min(filteredSeries.size(), renderedSeries + PAGE_SIZE);
        if (end <= renderedSeries) return;
        renderedSeries = end;
        seriesAdapter.submit(new ArrayList<>(filteredSeries.subList(0, renderedSeries)));
    }

    private void loadAdultInclusiveCatalog(final int token) {
        MovieRepository movieRepo = new MovieRepository(session.host(), session.user(), session.pass(), true);
        SeriesRepository seriesRepo = new SeriesRepository(session.host(), session.user(), session.pass(), true);

        movieRepo.moviesProgressive("", 48, 240, new MovieRepository.ProgressiveMoviesResult() {
            @Override public void partial(List<Movie> rows) { publishHotMovies(rows, false, token); }
            @Override public void success(List<Movie> rows) { publishHotMovies(rows, true, token); }
            @Override public void error(String message) {
                runOnUiThread(() -> {
                    if (token != modeLoadGeneration || !SpecialSections.HOT.equals(mode)) return;
                    hotMoviesDone = true;
                    updateLoadingState();
                    if (moviesMode && movieRows.isEmpty()) b.specialError.setText(message);
                });
            }
        });
        seriesRepo.seriesProgressive("", 48, 240, new SeriesRepository.ProgressiveSeriesResult() {
            @Override public void partial(List<SeriesItem> rows) { publishHotSeries(rows, false, token); }
            @Override public void success(List<SeriesItem> rows) { publishHotSeries(rows, true, token); }
            @Override public void error(String message) {
                runOnUiThread(() -> {
                    if (token != modeLoadGeneration || !SpecialSections.HOT.equals(mode)) return;
                    hotSeriesDone = true;
                    updateLoadingState();
                    if (!moviesMode && seriesRows.isEmpty()) b.specialError.setText(message);
                });
            }
        });
    }

    private void publishHotMovies(List<Movie> rows, boolean done, int token) {
        runOnUiThread(() -> {
            if (isFinishing() || isDestroyed() || token != modeLoadGeneration || !SpecialSections.HOT.equals(mode)) return;
            movieRows = rows == null ? Collections.emptyList() : rows;
            if (done) hotMoviesDone = true;
            rebuildHotScope();
        });
    }

    private void publishHotSeries(List<SeriesItem> rows, boolean done, int token) {
        runOnUiThread(() -> {
            if (isFinishing() || isDestroyed() || token != modeLoadGeneration || !SpecialSections.HOT.equals(mode)) return;
            seriesRows = rows == null ? Collections.emptyList() : rows;
            if (done) hotSeriesDone = true;
            rebuildHotScope();
        });
    }

    /**
     * V5.0.106: HOT pode receber catálogos muito grandes. Não monta o índice na
     * thread da tela a cada bloco recebido; isso era capaz de congelar/encerrar o app
     * depois de várias trocas rápidas de seção.
     */
    private void rebuildHotScope() {
        updateLoadingState();
        main.removeCallbacks(delayedHotScope);
        main.postDelayed(delayedHotScope, 90L);
    }

    private void buildHotScopeAsync() {
        if (!SpecialSections.HOT.equals(mode) || isFinishing() || isDestroyed()) return;
        final int modeToken = modeLoadGeneration;
        final int buildToken = ++hotScopeBuildGeneration;
        final List<MovieCategory> movieCats = movieCategories;
        final List<SeriesCategory> seriesCats = seriesCategories;
        final List<Movie> moviesSnapshot = movieRows;
        final List<SeriesItem> seriesSnapshot = seriesRows;
        try {
            modeLoader.execute(() -> {
                SpecialCatalogIndex.Scope built = SpecialCatalogIndex.buildScope(
                        SpecialSections.HOT, movieCats, moviesSnapshot, seriesCats, seriesSnapshot);
                main.post(() -> {
                    if (isFinishing() || isDestroyed()
                            || modeToken != modeLoadGeneration
                            || buildToken != hotScopeBuildGeneration
                            || !SpecialSections.HOT.equals(mode)) return;
                    scope = built;
                    if (catalogLanding) updateCatalogPreviews(); else rebuild();
                });
            });
        } catch (java.util.concurrent.RejectedExecutionException ignored) { }
    }

    private void updateLoadingState() { showLoading(isLoading()); }
    private boolean isLoading() { return SpecialSections.HOT.equals(mode) && (moviesMode ? !hotMoviesDone : !hotSeriesDone); }
    private void showLoading(boolean show) {
        b.specialLoading.setVisibility(show ? View.VISIBLE : View.GONE);
        if (show) b.specialEmpty.setVisibility(View.GONE);
    }

    private void bindNav() {
        b.navTv.setOnClickListener(v -> com.greenplay.v5.core.ui.TopNavRouter.open(this, TvActivity.class));
        b.navFootball.setOnClickListener(v -> com.greenplay.v5.core.ui.TopNavRouter.open(this, GamesActivity.class));
        b.navMovies.setOnClickListener(v -> com.greenplay.v5.core.ui.TopNavRouter.open(this, MovieActivity.class));
        b.navSeries.setOnClickListener(v -> com.greenplay.v5.core.ui.TopNavRouter.open(this, SeriesActivity.class));
        b.navKids.setOnClickListener(v -> openSpecial(SpecialSections.KIDS));
        b.navAnime.setOnClickListener(v -> openSpecial(SpecialSections.ANIME));
        b.navHot.setOnClickListener(v -> openSpecial(SpecialSections.HOT));
        b.specialSettings.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        applyNavVisibility();
    }

    private void openSpecial(String target) {
        if (!SpecialSections.valid(target)) return;
        if (mode.equals(target)) { showCatalogLanding(); return; }

        // KIDS <-> ANIMES troca dentro da própria Activity.
        // Assim não existe tela preta nem recriação pesada. HOT mantém o PIN/permissão centralizado.
        if (!SpecialSections.HOT.equals(target)) {
            mode = target;
            applyModeUi();
            loadCurrentMode();
            return;
        }
        SpecialSections.open(this, target);
    }

    private void applyNavVisibility() {
        NavConfigUi.apply(control,
                NavConfigUi.e("tv", b.navTv, 10), NavConfigUi.e("football", b.navFootball, 20),
                NavConfigUi.e("movies", b.navMovies, 30), NavConfigUi.e("series", b.navSeries, 40),
                NavConfigUi.e("kids", b.navKids, 50), NavConfigUi.e("anime", b.navAnime, 60),
                NavConfigUi.e("hot", b.navHot, 70));
    }

    private void applyModeUi() {
        b.specialSectionLabel.setText(SpecialSections.label(mode));
        b.specialCatalogLandingLabel.setText(SpecialSections.label(mode));
        b.navKids.setSelected(SpecialSections.KIDS.equals(mode));
        b.navAnime.setSelected(SpecialSections.ANIME.equals(mode));
        b.navHot.setSelected(SpecialSections.HOT.equals(mode));
    }

    private void applyBranding() {
        BrandingUi.applyHeaderBrand(b.brandNameSpecial, b.brandLogoSpecial, branding);
        backgroundTarget = BrandingUi.applyBackground(b.getRoot(), branding);
        if (movieAdapter != null) {
            String fallback = branding.movieCover();
            if (fallback == null || fallback.trim().isEmpty()) fallback = branding.fallback();
            movieAdapter.setFallbackPoster(branding.absolute(fallback));
        }
        if (seriesAdapter != null) {
            String fallback = branding.seriesCover();
            if (fallback == null || fallback.trim().isEmpty()) fallback = branding.fallback();
            seriesAdapter.setFallback(branding.absolute(fallback));
        }
    }

    private void openMovie(Movie movie) {
        Intent i = new Intent(this, MovieDetailActivity.class);
        i.putExtra("id", movie.id);
        i.putExtra("name", movie.name);
        i.putExtra("poster", movie.poster);
        i.putExtra("year", movie.year);
        i.putExtra("rating", movie.rating);
        i.putExtra("extension", movie.extension);
        i.putExtra("direct_source", movie.directSource);
        startActivity(i);
    }

    private void openSeries(SeriesItem x) {
        Intent i = new Intent(this, SeriesDetailActivity.class);
        i.putExtra("id", x.id);
        i.putExtra("name", x.name);
        i.putExtra("cover", x.cover);
        i.putExtra("year", x.year);
        i.putExtra("rating", x.rating);
        if (x.alternateIds != null && !x.alternateIds.isEmpty()) {
            long[] ids = new long[x.alternateIds.size()];
            for (int p = 0; p < ids.length; p++) ids[p] = x.alternateIds.get(p);
            i.putExtra("alternate_ids", ids);
        }
        startActivity(i);
    }

    private static String normalizeMode(String raw) {
        String m = raw == null ? "" : raw.trim().toLowerCase(Locale.ROOT);
        return SpecialSections.valid(m) ? m : "";
    }

    @Override public void onBackPressed() {
        if (!catalogLanding) {
            showCatalogLanding();
            return;
        }
        super.onBackPressed();
    }

    @Override protected void onResume() {
        super.onResume();
        if (movieAdapter != null) movieAdapter.refreshVisible();
    }

    @Override protected void onDestroy() {
        generation++;
        modeLoadGeneration++;
        hotScopeBuildGeneration++;
        main.removeCallbacksAndMessages(null);
        try { modeLoader.shutdownNow(); } catch (Exception ignored) { }
        try { filter.shutdownNow(); } catch (Exception ignored) { }
        super.onDestroy();
    }
}
