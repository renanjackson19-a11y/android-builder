package com.greenplay.v5.data.model.series;
public final class SeriesCategory {
    public String id="";
    public String name="";
    /** Explicit adult marker published by compatible Xtream/panel APIs. */
    public boolean isAdult=false;
}
