package com.greenplay.v5.core.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.text.InputType;
import android.widget.EditText;
import android.widget.Toast;
import com.greenplay.v5.core.session.SessionStore;
import com.greenplay.v5.ui.special.SpecialCatalogActivity;
import com.greenplay.v5.data.model.series.SeriesItem;
import java.text.Normalizer;
import java.util.Locale;

/** Shared navigation/filter rules for the dedicated KIDS, ANIME and HOT sections. */
public final class SpecialSections {
    public static final String EXTRA_MODE = "special_mode";
    public static final String KIDS = "kids";
    public static final String ANIME = "anime";
    public static final String HOT = "hot";

    private SpecialSections() {}

    public static boolean valid(String mode) {
        return KIDS.equals(mode) || ANIME.equals(mode) || HOT.equals(mode);
    }

    public static String label(String mode) {
        if (KIDS.equals(mode)) return "KIDS";
        if (ANIME.equals(mode)) return "ANIMES";
        if (HOT.equals(mode)) return "HOT";
        return "";
    }

    public static boolean matches(String mode, String categoryName) {
        if (!valid(mode)) return true;
        String n = normalize(categoryName);
        if (n.isEmpty() || "todos".equals(n)) return false;
        if (KIDS.equals(mode)) {
            // KIDS must be strict. Generic provider names such as "Disney Plus" or
            // "Discovery Plus" carry normal/adult catalog too and must not be
            // classified as children's content just because of the brand name.
            return has(n,
                    "kids", "kid ", " kid", "infantil", "infantis", "crianca", "criancas",
                    "desenho", "desenhos", "cartoon", "cartoons", "baby", "bebe",
                    "discovery kids", "cartoon network", "disney junior", "disney channel kids",
                    "nickelodeon", "nick jr", "nick junior", "gloob", "gloobinho",
                    "boomerang", "tooncast", "cartoonito", "pbs kids", "family kids",
                    "animacao infantil", "animation kids");
        }
        if (ANIME.equals(mode)) {
            // Some Xtream servers organize anime by provider instead of using the
            // word ANIME in the category name (e.g. "Series | Crunchyroll").
            return has(n,
                    "anime", "animes", "otaku", "manga", "japan", "japao", "japones",
                    "japonesa", "japoneses", "japonesas", "animacao japonesa", "animation japan",
                    "crunchyroll", "crunchy roll", "funimation", "funimation now", "hidive", "anime onegai", "retrocrush", "aniplus");
        }
        return has(n,
                "hot", "adult", "adulto", "adultos", "adulta", "adultas", "xxx",
                "+18", "18+", "18 anos", "maiores de 18", "erotico", "erotica",
                "eroticos", "eroticas", "porno", "porn", "sexy", "sex", "playboy",
                "onlyfans", "only fans", "privacy", "privacidade", "adult content", "adult_vod");
    }


    /**
     * Item-level fallback used when the provider does not expose dedicated KIDS/ANIME
     * categories. Many Xtream lists put children's series inside a generic provider
     * category (for example Disney Plus), while still publishing useful plot/genre
     * metadata on get_series. Category matches remain authoritative; metadata only
     * widens the result when a dedicated category does not exist.
     */
    public static boolean matchesSeriesItem(String mode, String categoryName, SeriesItem item) {
        if (!valid(mode) || item == null) return !valid(mode);
        if (matches(mode, categoryName)) return true;
        if (HOT.equals(mode)) return item.isAdult;

        String title = normalize(item.name);
        String genre = normalize(item.genre);
        String plot = normalize(item.plot);
        String text = (title + " " + genre + " " + plot).trim();

        if (ANIME.equals(mode)) {
            return has(text,
                    " anime ", "anime", "manga", "otaku", "japanese animation",
                    "animacao japonesa", "shonen", "shoujo", "seinen", "isekai");
        }

        // KIDS (V5.0.89): do NOT use plot/synopsis as a positive signal.
        // A normal drama can easily mention a child/family in its synopsis and that was
        // the cause of regular series leaking into KIDS in V5.0.88.
        //
        // Outside an explicitly child category, accept only strong catalog metadata:
        //   1) a clearly child/family/animation genre, OR
        //   2) an unmistakably child-oriented title.
        // Generic providers such as Disney Plus / Discovery Plus are never sufficient.
        String g = " " + genre + " ";
        String t = " " + title + " ";

        boolean explicitKidsGenre = has(g,
                " kids ", " kid ", " children ", " childrens ", " child ",
                " infantil ", " infantis ", " crianca ", " criancas ",
                " preschool ", " pre school ", " family ", " familia ",
                " animation ", " animacao ", " animated ", " cartoon ", " cartoons ");

        boolean unmistakableKidsTitle = has(t,
                " mickey ", " minnie ", " bluey ", " peppa ", " paw patrol ",
                " patrulha canina ", " masha ", " cocomelon ", " galinha pintadinha ",
                " turma da monica ", " bob esponja ", " spongebob ", " miraculous ",
                " pj masks ", " pocoyo ", " dora a aventureira ", " dora the explorer ",
                " my little pony ", " show da luna ", " mundo bita ", " backyardigans ",
                " teletubbies ", " patrulha das patas ", " baby shark ", " pepa pig ",
                " turma do bairro ", " sesame street ", " vila sesamo ", " barney ",
                " thomas e seus amigos ", " thomas & friends ", " super wings ",
                " pj mask ", " powerpuff ", " meninas superpoderosas ", " doraemon ");

        if (!explicitKidsGenre && !unmistakableKidsTitle) return false;

        // Hard rejection for clearly mature catalog metadata / adult-animation titles.
        // This check is intentionally based on title+genre, never on plot.
        boolean mature = has(g + t,
                " adult ", " adults ", " adulto ", " adultos ", " erotic ", " erotico ",
                " porn ", " sexual ", " horror ", " terror ", " thriller ", " crime ",
                " true crime ", " slasher ", " gore ", " war ", " guerra ",
                " family guy ", " south park ", " rick and morty ", " american dad ",
                " bojack horseman ", " big mouth ", " f is for family ", " paradise pd ",
                " brickleberry ", " solar opposites ", " inside job ", " archer ");
        return !mature;
    }

    public static void open(Activity activity, String mode) {
        if (activity == null || !valid(mode)) return;
        if (HOT.equals(mode)) {
            SessionStore session = new SessionStore(activity);
            if (!session.adult()) {
                Toast.makeText(activity, "Conteúdo HOT não está liberado para esta conta", Toast.LENGTH_SHORT).show();
                return;
            }
            String saved = activity.getSharedPreferences("green_play_parental", Activity.MODE_PRIVATE).getString("pin", "");
            if (saved != null && !saved.trim().isEmpty()) {
                EditText input = new EditText(activity);
                input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
                input.setHint("PIN de 4 dígitos");
                input.setSingleLine(true);
                new AlertDialog.Builder(activity)
                        .setTitle("Conteúdo HOT")
                        .setMessage("Digite o PIN configurado neste aparelho.")
                        .setView(input)
                        .setPositiveButton("ENTRAR", (d, w) -> {
                            if (saved.equals(input.getText().toString().trim())) launch(activity, mode);
                            else Toast.makeText(activity, "PIN incorreto", Toast.LENGTH_SHORT).show();
                        })
                        .setNegativeButton("CANCELAR", null)
                        .show();
                return;
            }
        }
        launch(activity, mode);
    }

    private static void launch(Activity activity, String mode) {
        Intent i = new Intent(activity, SpecialCatalogActivity.class);
        i.putExtra(EXTRA_MODE, mode);
        i.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NO_ANIMATION);
        activity.startActivity(i);
        activity.overridePendingTransition(0, 0);
    }

    private static boolean has(String source, String... words) {
        for (String word : words) if (source.contains(word)) return true;
        return false;
    }

    private static String normalize(String raw) {
        if (raw == null) return "";
        String s = Normalizer.normalize(raw, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        return s.toLowerCase(Locale.ROOT).replaceAll("\\s+", " ").trim();
    }
}
