package com.greenplay.v5.ui.movies;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.greenplay.v5.R;
import com.greenplay.v5.core.config.BrandingStore;
import com.greenplay.v5.data.model.movie.Movie;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public final class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.Holder> {
    public interface Listener {
        void onOpen(Movie movie);
        void onFavorite(Movie movie);
        boolean isFavorite(Movie movie);
    }

    private final Listener listener;
    private final List<Movie> source = new ArrayList<>();
    private final List<Movie> rows = new ArrayList<>();
    private String query = "";
    private boolean favoritesOnly = false;

    public MovieAdapter(Listener listener) {
        this.listener = listener;
        setHasStableIds(true);
    }

    public void submit(List<Movie> items) {
        source.clear();
        if (items != null) {
            Set<String> seen = new HashSet<>();
            for (Movie movie : items) {
                if (movie == null) continue;
                String key = visualDuplicateKey(movie);
                if (!key.isEmpty() && !seen.add(key)) continue;
                source.add(movie);
            }
        }
        apply();
    }

    public void search(String value) {
        query = value == null ? "" : value.trim();
        apply();
    }

    public void favoritesOnly(boolean enabled) {
        favoritesOnly = enabled;
        apply();
    }

    public void refreshFavorite(long id) {
        if (favoritesOnly) { apply(); return; }
        for (int i = 0; i < rows.size(); i++) if (rows.get(i).id == id) { notifyItemChanged(i); return; }
    }

    private void apply() {
        rows.clear();
        String q = query.toLowerCase(Locale.ROOT);
        for (Movie m : source) {
            if (favoritesOnly && !listener.isFavorite(m)) continue;
            if (!q.isEmpty() && (m.name == null || !m.name.toLowerCase(Locale.ROOT).contains(q))) continue;
            rows.add(m);
        }
        notifyDataSetChanged();
    }

    private static String visualDuplicateKey(Movie movie) {
        String title = canonical(movie.name);
        String variant = variant(movie.name);
        String poster = normalizedUrl(movie.poster);
        if (!poster.isEmpty()) return "poster|" + poster + "|" + variant;
        if (title.isEmpty()) return "id|" + movie.id;
        String year = movie.year == null ? "" : movie.year.trim();
        if ("0".equals(year) || "0000".equals(year)) year = "";
        return "title|" + title + "|" + year + "|" + variant;
    }

    private static String canonical(String value) {
        if (value == null) return "";
        String s = value.toLowerCase(Locale.ROOT)
                .replaceAll("\\b(?:2160p|1080p|720p|480p|4k|uhd|fhd|full\\s*hd|hd|h\\.?265|hevc|h\\.?264|x265|x264|web[- .]?dl|webrip|bluray|brrip|hdr|sdr)\\b", " ")
                .replaceAll("[\\s._-]*(?:\\(|\\[)?(?:19|20)\\d{2}(?:\\)|\\])?\\s*$", "")
                .replaceAll("\\s+", " ").trim();
        return s.replaceAll("[^\\p{L}\\p{N}]+", "").trim();
    }

    private static String variant(String value) {
        if (value == null) return "padrao";
        String s=value.toLowerCase(Locale.ROOT);
        if (s.matches(".*(?:\\[|\\(|\\b)(?:leg|legendado|legendada|sub|subtitled|l)(?:\\]|\\)|\\b).*$")) return "legendado";
        if (s.matches(".*(?:\\[|\\(|\\b)(?:dub|dublado|dublada|dual|d)(?:\\]|\\)|\\b).*$")) return "dublado";
        return "padrao";
    }

    private static String normalizedUrl(String value) {
        if (value == null) return "";
        String s = value.trim().toLowerCase(Locale.ROOT);
        int q = s.indexOf('?');
        if (q > 0) s = s.substring(0, q);
        return s;
    }

    private static String cleanLabel(String raw) {
        if (raw == null) return "";
        String s = raw.replace("\\/", "/").replace("\n", " ").replace("\r", " ").trim();
        s = s.replaceAll("^[^\\p{L}\\p{N}(]+", "");
        return s.replaceAll("\\s{2,}", " ").trim();
    }

    @Override public long getItemId(int position) { return rows.get(position).id; }

    @NonNull @Override public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new Holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_movie, parent, false));
    }

    @Override public void onBindViewHolder(@NonNull Holder h, int position) {
        Movie m = rows.get(position);
        h.title.setText(cleanLabel(m.name));
        String meta = meta(m);
        h.meta.setText(meta);
        h.meta.setVisibility(meta.isEmpty() ? View.GONE : View.VISIBLE);
        h.favorite.setText(listener.isFavorite(m) ? "★" : "☆");
        h.poster.setImageDrawable(null);
        h.poster.setBackgroundResource(R.drawable.bg_movie_poster_placeholder);
        String posterUrl = m.poster == null ? "" : m.poster.trim();
        if (posterUrl.isEmpty()) {
            BrandingStore branding = new BrandingStore(h.itemView.getContext());
            posterUrl = branding.absolute(branding.fallback());
        }
        if (!posterUrl.isEmpty()) Picasso.get().load(posterUrl).fit().centerCrop().noFade().into(h.poster);
        h.itemView.setOnClickListener(v -> listener.onOpen(m));
        h.favorite.setOnClickListener(v -> {
            listener.onFavorite(m);
            h.favorite.setText(listener.isFavorite(m) ? "★" : "☆");
        });
    }

    private static String meta(Movie m) {
        String y = m.year == null ? "" : m.year.trim();
        if ("0".equals(y) || "0000".equals(y)) y = "";
        String r = m.rating == null ? "" : m.rating.trim();
        if (!r.isEmpty() && !"0".equals(r) && !"0.0".equals(r)) return y.isEmpty() ? "★ " + r : y + "  •  ★ " + r;
        return y;
    }

    @Override public int getItemCount() { return rows.size(); }

    static final class Holder extends RecyclerView.ViewHolder {
        final ImageView poster;
        final TextView title, meta, favorite;
        Holder(View itemView) {
            super(itemView);
            poster = itemView.findViewById(R.id.moviePoster);
            title = itemView.findViewById(R.id.movieTitle);
            meta = itemView.findViewById(R.id.movieMeta);
            favorite = itemView.findViewById(R.id.movieFavorite);
        }
    }
}
