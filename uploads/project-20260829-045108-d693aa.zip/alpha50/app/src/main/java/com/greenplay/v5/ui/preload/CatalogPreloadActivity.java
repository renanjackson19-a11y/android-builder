package com.greenplay.v5.ui.preload;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.greenplay.v5.R;
import com.greenplay.v5.core.catalog.CatalogCoverWarmer;
import com.greenplay.v5.core.catalog.CatalogMemory;
import com.greenplay.v5.core.config.BrandingStore;
import com.greenplay.v5.core.config.BrandingUi;
import com.greenplay.v5.core.network.NetworkProvider;
import com.greenplay.v5.core.session.SessionStore;
import com.greenplay.v5.data.model.AppConfigResponse;
import com.greenplay.v5.data.model.movie.Movie;
import com.greenplay.v5.data.model.movie.MovieCategory;
import com.greenplay.v5.data.model.series.SeriesItem;
import com.greenplay.v5.data.model.tv.TvChannel;
import com.greenplay.v5.data.repository.MovieRepository;
import com.greenplay.v5.data.repository.SeriesWarmRepository;
import com.greenplay.v5.data.repository.TvRepository;
import com.greenplay.v5.databinding.ActivityCatalogPreloadBinding;
import com.greenplay.v5.ui.tv.TvActivity;
import java.util.ArrayList;
import java.util.List;
import com.squareup.picasso.Picasso;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * GREEN PLAY startup preparation. Catalog queries remain fresh on every cold
 * start so a bouquet/source change is reflected immediately. Only image bytes
 * use persistent cache.
 */
public final class CatalogPreloadActivity extends AppCompatActivity {
    private ActivityCatalogPreloadBinding b;
    private SessionStore session;
    private BrandingStore branding;
    private TvRepository tvRepo;
    private MovieRepository movieRepo;
    private SeriesWarmRepository seriesRepo;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private boolean channelsDone;
    private boolean moviesDone;
    private boolean movieCategoriesDone;
    private boolean seriesDone;
    private boolean priorityImagesDone;
    private boolean imageWarmStarted;
    private boolean opened;
    private boolean serverConfirmed;
    private int serverFailures;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        b = ActivityCatalogPreloadBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());

        session = new SessionStore(this);
        branding = new BrandingStore(this);
        applyBranding();
        refreshBranding();
        if (!session.isLogged() || session.host().trim().isEmpty() || session.user().trim().isEmpty()) {
            finish();
            return;
        }

        CatalogMemory.clear();
        tvRepo = new TvRepository(session.host(), session.user(), session.pass());
        movieRepo = new MovieRepository(session.host(), session.user(), session.pass());
        seriesRepo = new SeriesWarmRepository(session.host(), session.user(), session.pass());

        updateCatalogProgress(3);
        runConnectionDiagnostic();
        loadChannels();
        loadMovieCategories();
        loadMovies();
        loadSeries();
    }


    private void applyBranding() {
        if (branding == null || b == null) return;
        BrandingUi.applyName(b.brandingName, branding);
        BrandingUi.applyLogo(b.brandingLogo, branding);
        BrandingUi.applyBanner(b.brandingBanner, branding);
        String bg = branding.absolute(branding.background());
        if (!bg.isEmpty()) {
            Picasso.get().load(bg).fit().centerCrop().noFade().into(b.brandingBackground);
        }
        int accent = BrandingUi.color(branding.accent(), 0xFF29E76F);
        b.catalogPercent.setTextColor(accent);
        try { b.catalogProgress.getProgressDrawable().setTint(accent); } catch (Exception ignored) { }
    }

    private void refreshBranding() {
        NetworkProvider.panel().appConfig().enqueue(new Callback<AppConfigResponse>() {
            @Override public void onResponse(Call<AppConfigResponse> call, Response<AppConfigResponse> response) {
                AppConfigResponse cfg = response.body();
                if (response.isSuccessful() && cfg != null && cfg.ok && cfg.branding != null) {
                    branding.save(cfg.branding);
                    runOnUiThread(() -> applyBranding());
                }
            }
            @Override public void onFailure(Call<AppConfigResponse> call, Throwable t) { }
        });
    }

    private void runConnectionDiagnostic() {
        setStep(b.diagDevice, true, false);
        b.diagDots1.setTextColor(0xFF29E76F);
        handler.postDelayed(() -> {
            boolean network = hasNetwork();
            setStep(b.diagNetwork, network, !network);
            b.diagDots2.setTextColor(network ? 0xFF29E76F : 0xFF604044);
            handler.postDelayed(() -> {
                boolean internet = hasInternetCapability();
                setStep(b.diagInternet, internet, !internet);
                b.diagDots3.setTextColor(internet ? 0xFF29E76F : 0xFF604044);
                b.catalogPhaseTitle.setText(internet ? "Conexão pronta • consultando servidor" : "Rede detectada • tentando servidor GREEN PLAY");
            }, 180L);
        }, 180L);
    }

    private boolean hasNetwork() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            return cm != null && cm.getActiveNetwork() != null;
        } catch (Exception e) { return false; }
    }

    private boolean hasInternetCapability() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return false;
            Network n = cm.getActiveNetwork();
            if (n == null) return false;
            NetworkCapabilities c = cm.getNetworkCapabilities(n);
            return c != null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
        } catch (Exception e) { return false; }
    }

    private void setStep(TextView view, boolean ok, boolean error) {
        view.setBackgroundResource(error ? R.drawable.bg_preload_step_error : (ok ? R.drawable.bg_preload_step_ok : R.drawable.bg_preload_step));
        view.setTextColor(error ? 0xFFFFA0A0 : (ok ? 0xFFFFFFFF : 0xFFB9C7BF));
    }

    private void confirmServer() {
        if (serverConfirmed) return;
        serverConfirmed = true;
        setStep(b.diagServer, true, false);
        b.diagDots3.setTextColor(0xFF29E76F);
        b.catalogPhaseTitle.setText("Servidor conectado • preparando catálogo");
    }

    private void serverFailure() {
        serverFailures++;
        if (serverFailures >= 3 && !serverConfirmed) {
            setStep(b.diagServer, false, true);
            b.catalogPhaseTitle.setText("Servidor respondeu parcialmente • usando o que estiver disponível");
        }
    }

    private void loadChannels() {
        b.statusChannels.setText("○  Canais\nConsultando bouquet…");
        tvRepo.channels("", new TvRepository.ChannelsResult() {
            @Override public void success(List<TvChannel> rows) {
                confirmServer();
                CatalogMemory.setChannels(rows);
                channelsDone = true;
                b.statusChannels.setBackgroundResource(R.drawable.bg_preload_step_ok);
                b.statusChannels.setText("✓  Canais\n" + rows.size() + " prontos");
                b.statusChannels.setTextColor(0xFFFFFFFF);
                updateProgressAndMaybeWarm();
            }

            @Override public void error(String message) {
                serverFailure();
                channelsDone = true;
                b.statusChannels.setBackgroundResource(R.drawable.bg_preload_step_error);
                b.statusChannels.setText("!  Canais\n" + message);
                updateProgressAndMaybeWarm();
            }
        });
    }

    private void loadMovieCategories() {
        movieRepo.categories(new MovieRepository.CategoriesResult() {
            @Override public void success(List<MovieCategory> rows) {
                confirmServer();
                CatalogMemory.setMovieCategories(rows);
                movieCategoriesDone = true;
                updateProgressAndMaybeWarm();
            }

            @Override public void error(String message) {
                serverFailure();
                movieCategoriesDone = true;
                updateProgressAndMaybeWarm();
            }
        });
    }

    private void loadMovies() {
        b.statusMovies.setText("○  Filmes\nCarregando catálogo…");
        movieRepo.movies("", new MovieRepository.MoviesResult() {
            @Override public void success(List<Movie> rows) {
                confirmServer();
                CatalogMemory.setMovies(rows);
                moviesDone = true;
                b.statusMovies.setBackgroundResource(R.drawable.bg_preload_step_ok);
                b.statusMovies.setText("✓  Filmes\n" + rows.size() + " prontos");
                b.statusMovies.setTextColor(0xFFFFFFFF);
                updateProgressAndMaybeWarm();
            }

            @Override public void error(String message) {
                serverFailure();
                moviesDone = true;
                b.statusMovies.setBackgroundResource(R.drawable.bg_preload_step_error);
                b.statusMovies.setText("!  Filmes\n" + message);
                updateProgressAndMaybeWarm();
            }
        });
    }

    private void loadSeries() {
        b.statusSeries.setText("○  Séries\nCarregando catálogo…");
        seriesRepo.series(new SeriesWarmRepository.Result() {
            @Override public void success(List<SeriesItem> rows) {
                confirmServer();
                CatalogMemory.setSeries(rows);
                seriesDone = true;
                b.statusSeries.setBackgroundResource(R.drawable.bg_preload_step_ok);
                b.statusSeries.setText("✓  Séries\n" + rows.size() + " prontas");
                b.statusSeries.setTextColor(0xFFFFFFFF);
                updateProgressAndMaybeWarm();
            }

            @Override public void error(String message) {
                serverFailure();
                seriesDone = true;
                b.statusSeries.setBackgroundResource(R.drawable.bg_preload_step_error);
                b.statusSeries.setText("!  Séries\n" + message);
                updateProgressAndMaybeWarm();
            }
        });
    }

    private void updateProgressAndMaybeWarm() {
        int done = 0;
        if (channelsDone) done++;
        if (moviesDone && movieCategoriesDone) done++;
        if (seriesDone) done++;
        updateCatalogProgress(done == 0 ? 8 : (done == 1 ? 30 : (done == 2 ? 52 : 68)));

        if (channelsDone && moviesDone && movieCategoriesDone && seriesDone && !imageWarmStarted) {
            imageWarmStarted = true;
            warmPriorityImages();
        }
    }

    private void warmPriorityImages() {
        List<String> urls = allArtwork();
        if (urls.isEmpty()) {
            priorityImagesDone = true;
            updateCatalogProgress(100);
            openWhenReady();
            return;
        }
        b.catalogPhaseTitle.setText("Preparando capas e logos para abrir sem espera");
        b.catalogMessage.setText("A primeira abertura prepara imagens; as próximas ficam mais rápidas");

        // Prioritize enough artwork for immediate navigation; the entire remaining
        // catalog continues to warm after the main UI opens.
        CatalogCoverWarmer.warmPriority(urls, 420, new CatalogCoverWarmer.ProgressListener() {
            @Override public void onProgress(int done, int total) {
                if (priorityImagesDone) return;
                int p = 68 + (int) Math.round((done / (double) Math.max(1, total)) * 30.0);
                updateCatalogProgress(Math.min(98, p));
                b.catalogMessage.setText("Capas preparadas  " + done + " / " + total);
            }

            @Override public void onComplete(int total) {
                if (priorityImagesDone) return;
                priorityImagesDone = true;
                updateCatalogProgress(100);
                b.catalogMessage.setText("Conteúdo pronto • abrindo GREEN PLAY");
                CatalogCoverWarmer.enqueue(urls);
                openWhenReady();
            }
        });

        // A bad image host must never trap the user on startup.
        handler.postDelayed(() -> {
            if (priorityImagesDone || opened) return;
            priorityImagesDone = true;
            updateCatalogProgress(100);
            b.catalogMessage.setText("Catálogo pronto • capas restantes continuam em segundo plano");
            CatalogCoverWarmer.enqueue(urls);
            openWhenReady();
        }, 12_000L);
    }

    private List<String> allArtwork() {
        List<String> urls = new ArrayList<>();
        for (TvChannel row : CatalogMemory.channels()) if (row != null && row.logo != null) urls.add(row.logo);
        for (Movie row : CatalogMemory.movies()) if (row != null && row.poster != null) urls.add(row.poster);
        for (SeriesItem row : CatalogMemory.series()) if (row != null && row.cover != null) urls.add(row.cover);
        return urls;
    }

    private void openWhenReady() {
        if (!channelsDone || !moviesDone || !movieCategoriesDone || !seriesDone || !priorityImagesDone || opened) return;
        opened = true;
        handler.postDelayed(this::openTv, 320L);
    }

    private void updateCatalogProgress(int value) {
        int p = Math.max(0, Math.min(100, value));
        b.catalogProgress.setProgress(p);
        b.catalogPercent.setText(p + "%");
    }

    private void openTv() {
        if (isFinishing()) return;
        startActivity(new Intent(this, TvActivity.class));
        finish();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
