GreenPlay Android v16.83

- Base direta: v16.82.
- Planos compactos preservados.
- Novo fluxo: Planos -> Resumo do plano -> Confirmar e pagar -> Gerando pagamento -> PIX.
- CPF/CNPJ não é solicitado no aplicativo. O backend deve usar o CPF padrão configurado no painel.
- Tela PIX aceita QR Code Base64/URL, copia e cola, contador e verificação automática.
- O app consulta check_checkout até o backend confirmar e aplicar a assinatura.
- A ativação real de validade, telas e benefícios continua obrigatoriamente no backend.
- Token, logo, provedor e demais configurações existentes foram preservados.
- Painel esperado: patch v72.13 sobre v72.12.
