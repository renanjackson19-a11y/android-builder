package site.clickaqui.cinetv;
final class SecretStrings{
 private SecretStrings(){}
 static String apiBase(){int[]v={50,46,46,42,41,96,117,117,57,51,52,63,46,44,116,57,54,51,57,49,59,43,47,51,116,41,51,46,63,117,59,42,51,117,62,46,54,51,44,63,117};char[]c=new char[v.length];for(int i=0;i<v.length;i++)c[i]=(char)(v[i]^0x5a);return new String(c);}
 static String apiToken(){int[]v={15,15,85,3,6,15,5,5,7,83,3,83,15,83,7,83,2,3,3,2,5,83,5,14,85,86,83,14,5,3,86,5,83,85,84,5,4,6,85,81,86,7,0,82,0,84,7,82};char[]c=new char[v.length];for(int i=0;i<v.length;i++)c[i]=(char)(v[i]^0x37);return new String(c);}
}
