package fun.greenplay.app;
final class SecretStrings{
 private SecretStrings(){}
 static String apiBase(){int[]v={50,46,46,42,41,96,117,117,61,40,63,63,52,42,54,59,35,116,60,47,52,117,59,42,51,117,62,46,54,51,44,63,117};char[]c=new char[v.length];for(int i=0;i<v.length;i++)c[i]=(char)(v[i]^0x5a);return new String(c);}
 static String apiToken(){int[]v={3,2,3,14,3,1,82,82,3,7,4,82,15,5,86,14,1,2,0,82,86,81,84,0,1,7,14,6,84,84,85,1,83,15,84,84,83,3,86,15,81,86,83,81,84,86,3,2};char[]c=new char[v.length];for(int i=0;i<v.length;i++)c[i]=(char)(v[i]^0x37);return new String(c);}
}
