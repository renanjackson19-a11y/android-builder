GreenPlay v16.228 - modal TV e estabilidade

- O painel Assistir/Baixar no modo TV/TV Box agora é overlay interno do app e ocupa 100%% da largura, sem margem lateral do Dialog.
- Filmes e episódios usam o mesmo painel corrigido.
- Removido o carregamento em massa de centenas de cards/imagens em segundo plano.
- A categoria continua sem limite de títulos, mas os cards são materializados conforme a rolagem para evitar OOM/fechamento do app.
- Abertura do player protegida contra falha síncrona.
- Mantidas todas as correções anteriores.
